package vea.raceremote.app;

import android.content.Context;
import java.util.List;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import org.koin.core.definition.BeanDefinition;
import org.koin.core.definition.BeanDefinitionKt;
import org.koin.core.definition.Kind;
import org.koin.core.instance.SingleInstanceFactory;
import org.koin.core.module.Module;
import org.koin.core.parameter.ParametersHolder;
import org.koin.core.qualifier.Qualifier;
import org.koin.core.registry.ScopeRegistry;
import org.koin.core.scope.Scope;
import org.koin.dsl.ModuleKt;
import vea.raceremote.features.remote_control.data.IRemoteDeviceRepository;
import vea.raceremote.features.remote_control.presentation.IWifiNetworkFinder;
import vea.raceremote.features.remote_control.presentation.WifiNetworkFinder;
import vea.raceremote.features.remote_control.utils.ICompoundCommandExtractor;
import vea.raceremote.utils.bluetooth.BluetoothConnection;
import vea.raceremote.utils.bluetooth.IBluetoothConnection;

/* JADX INFO: compiled from: AppModule.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\"\u0011\u0010\u0000\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"appModule", "Lorg/koin/core/module/Module;", "getAppModule", "()Lorg/koin/core/module/Module;", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class AppModuleKt {
    private static final Module appModule = ModuleKt.module$default(false, new Function1<Module, Unit>() { // from class: vea.raceremote.app.AppModuleKt$appModule$1
        @Override // kotlin.jvm.functions.Function1
        public /* bridge */ /* synthetic */ Unit invoke(Module module) {
            invoke2(module);
            return Unit.INSTANCE;
        }

        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
        public final void invoke2(Module $this$module) {
            Intrinsics.checkNotNullParameter($this$module, "$this$module");
            Function2 definition$iv = new Function2<Scope, ParametersHolder, IBluetoothConnection>() { // from class: vea.raceremote.app.AppModuleKt$appModule$1.1
                @Override // kotlin.jvm.functions.Function2
                public final IBluetoothConnection invoke(Scope $this$single, ParametersHolder it) {
                    Intrinsics.checkNotNullParameter($this$single, "$this$single");
                    Intrinsics.checkNotNullParameter(it, "it");
                    return new BluetoothConnection((ICompoundCommandExtractor) $this$single.get(Reflection.getOrCreateKotlinClass(ICompoundCommandExtractor.class), null, null));
                }
            };
            Kind kind$iv$iv = Kind.Singleton;
            Qualifier scopeQualifier$iv$iv = ScopeRegistry.Companion.getRootScopeQualifier();
            List secondaryTypes$iv$iv = CollectionsKt.emptyList();
            BeanDefinition def$iv = new BeanDefinition(scopeQualifier$iv$iv, Reflection.getOrCreateKotlinClass(IBluetoothConnection.class), null, definition$iv, kind$iv$iv, secondaryTypes$iv$iv);
            String mapping$iv = BeanDefinitionKt.indexKey(def$iv.getPrimaryType(), null, ScopeRegistry.Companion.getRootScopeQualifier());
            SingleInstanceFactory<?> singleInstanceFactory = new SingleInstanceFactory<>(def$iv);
            Module.saveMapping$default($this$module, mapping$iv, singleInstanceFactory, false, 4, null);
            if ($this$module.getCreatedAtStart()) {
                $this$module.getEagerInstances().add(singleInstanceFactory);
            }
            new Pair($this$module, singleInstanceFactory);
            Function2 definition$iv2 = new Function2<Scope, ParametersHolder, IWifiNetworkFinder>() { // from class: vea.raceremote.app.AppModuleKt$appModule$1.2
                @Override // kotlin.jvm.functions.Function2
                public final IWifiNetworkFinder invoke(Scope $this$single, ParametersHolder it) {
                    Intrinsics.checkNotNullParameter($this$single, "$this$single");
                    Intrinsics.checkNotNullParameter(it, "it");
                    return new WifiNetworkFinder((Context) $this$single.get(Reflection.getOrCreateKotlinClass(Context.class), null, null), (IRemoteDeviceRepository) $this$single.get(Reflection.getOrCreateKotlinClass(IRemoteDeviceRepository.class), null, null));
                }
            };
            Kind kind$iv$iv2 = Kind.Singleton;
            Qualifier scopeQualifier$iv$iv2 = ScopeRegistry.Companion.getRootScopeQualifier();
            List secondaryTypes$iv$iv2 = CollectionsKt.emptyList();
            BeanDefinition def$iv2 = new BeanDefinition(scopeQualifier$iv$iv2, Reflection.getOrCreateKotlinClass(IWifiNetworkFinder.class), null, definition$iv2, kind$iv$iv2, secondaryTypes$iv$iv2);
            String mapping$iv2 = BeanDefinitionKt.indexKey(def$iv2.getPrimaryType(), null, ScopeRegistry.Companion.getRootScopeQualifier());
            SingleInstanceFactory<?> singleInstanceFactory2 = new SingleInstanceFactory<>(def$iv2);
            Module.saveMapping$default($this$module, mapping$iv2, singleInstanceFactory2, false, 4, null);
            if ($this$module.getCreatedAtStart()) {
                $this$module.getEagerInstances().add(singleInstanceFactory2);
            }
            new Pair($this$module, singleInstanceFactory2);
        }
    }, 1, null);

    public static final Module getAppModule() {
        return appModule;
    }
}
