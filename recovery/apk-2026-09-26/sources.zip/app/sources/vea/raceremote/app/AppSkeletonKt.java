package vea.raceremote.app;

import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.ui.Modifier;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function2;
import vea.raceremote.features.remote_control.presentation.view.RemoteControlScreenKt;
import vea.raceremote.ui.theme.ThemeKt;

/* JADX INFO: compiled from: AppSkeleton.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\u001a\r\u0010\u0000\u001a\u00020\u0001H\u0003¢\u0006\u0002\u0010\u0002\u001a\r\u0010\u0003\u001a\u00020\u0001H\u0007¢\u0006\u0002\u0010\u0002\u001a\r\u0010\u0004\u001a\u00020\u0001H\u0007¢\u0006\u0002\u0010\u0002¨\u0006\u0005"}, d2 = {"ActionsPreview", "", "(Landroidx/compose/runtime/Composer;I)V", "App", "AppPreview", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class AppSkeletonKt {
    public static final void AppPreview(Composer $composer, final int $changed) {
        Composer $composer2 = $composer.startRestartGroup(1873454343);
        ComposerKt.sourceInformation($composer2, "C(AppPreview)13@410L5:AppSkeleton.kt#2oxwre");
        if ($changed != 0 || !$composer2.getSkipping()) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1873454343, $changed, -1, "vea.raceremote.app.AppPreview (AppSkeleton.kt:12)");
            }
            App($composer2, 0);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            $composer2.skipToGroupEnd();
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.app.AppSkeletonKt.AppPreview.1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i) {
                AppSkeletonKt.AppPreview(composer, $changed | 1);
            }
        });
    }

    public static final void App(Composer $composer, final int $changed) {
        Composer $composer2 = $composer.startRestartGroup(2104999849);
        ComposerKt.sourceInformation($composer2, "C(App)18@447L80:AppSkeleton.kt#2oxwre");
        if ($changed != 0 || !$composer2.getSkipping()) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(2104999849, $changed, -1, "vea.raceremote.app.App (AppSkeleton.kt:17)");
            }
            ThemeKt.RaceRemoteTheme(LiveLiterals$AppSkeletonKt.INSTANCE.m5975Boolean$arg0$callRaceRemoteTheme$funApp(), ComposableSingletons$AppSkeletonKt.INSTANCE.m5973getLambda2$app_debug(), $composer2, 48, 0);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            $composer2.skipToGroupEnd();
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.app.AppSkeletonKt.App.1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i) {
                AppSkeletonKt.App(composer, $changed | 1);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void ActionsPreview(Composer $composer, final int $changed) {
        Composer $composer2 = $composer.startRestartGroup(-1528916253);
        ComposerKt.sourceInformation($composer2, "C(ActionsPreview)26@587L30:AppSkeleton.kt#2oxwre");
        if ($changed != 0 || !$composer2.getSkipping()) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1528916253, $changed, -1, "vea.raceremote.app.ActionsPreview (AppSkeleton.kt:25)");
            }
            RemoteControlScreenKt.Actions(Modifier.INSTANCE, CollectionsKt.emptyList(), $composer2, 54, 0);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            $composer2.skipToGroupEnd();
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.app.AppSkeletonKt.ActionsPreview.1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i) {
                AppSkeletonKt.ActionsPreview(composer, $changed | 1);
            }
        });
    }
}
