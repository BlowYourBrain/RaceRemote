package vea.raceremote.app;

import androidx.compose.material.SurfaceKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import vea.raceremote.control.CarControlScreenKt;

/* JADX INFO: compiled from: AppSkeleton.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
public final class ComposableSingletons$AppSkeletonKt {
    public static final ComposableSingletons$AppSkeletonKt INSTANCE = new ComposableSingletons$AppSkeletonKt();

    /* JADX INFO: renamed from: lambda-1, reason: not valid java name */
    public static Function2<Composer, Integer, Unit> f33lambda1 = ComposableLambdaKt.composableLambdaInstance(656631199, false, new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.app.ComposableSingletons$AppSkeletonKt$lambda-1$1
        @Override // kotlin.jvm.functions.Function2
        public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
            invoke(composer, num.intValue());
            return Unit.INSTANCE;
        }

        public final void invoke(Composer $composer, int $changed) {
            ComposerKt.sourceInformation($composer, "C19@501L18:AppSkeleton.kt#2oxwre");
            if (($changed & 11) == 2 && $composer.getSkipping()) {
                $composer.skipToGroupEnd();
                return;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(656631199, $changed, -1, "vea.raceremote.app.ComposableSingletons$AppSkeletonKt.lambda-1.<anonymous> (AppSkeleton.kt:19)");
            }
            CarControlScreenKt.CarControlScreen(null, 0, $composer, 0, 3);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
    });

    /* JADX INFO: renamed from: lambda-2, reason: not valid java name */
    public static Function2<Composer, Integer, Unit> f34lambda2 = ComposableLambdaKt.composableLambdaInstance(-129823389, false, new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.app.ComposableSingletons$AppSkeletonKt$lambda-2$1
        @Override // kotlin.jvm.functions.Function2
        public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
            invoke(composer, num.intValue());
            return Unit.INSTANCE;
        }

        public final void invoke(Composer $composer, int $changed) {
            ComposerKt.sourceInformation($composer, "C19@491L30:AppSkeleton.kt#2oxwre");
            if (($changed & 11) == 2 && $composer.getSkipping()) {
                $composer.skipToGroupEnd();
                return;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-129823389, $changed, -1, "vea.raceremote.app.ComposableSingletons$AppSkeletonKt.lambda-2.<anonymous> (AppSkeleton.kt:18)");
            }
            SurfaceKt.m1177SurfaceFjzlyU(null, null, 0L, 0L, null, 0.0f, ComposableSingletons$AppSkeletonKt.INSTANCE.m5972getLambda1$app_debug(), $composer, 1572864, 63);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
    });

    /* JADX INFO: renamed from: getLambda-1$app_debug, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m5972getLambda1$app_debug() {
        return f33lambda1;
    }

    /* JADX INFO: renamed from: getLambda-2$app_debug, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m5973getLambda2$app_debug() {
        return f34lambda2;
    }
}
