package vea.raceremote.app;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: AppSkeleton.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/app/AppSkeleton.kt")
public final class LiveLiterals$AppSkeletonKt {

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-RaceRemoteTheme$fun-App, reason: not valid java name */
    private static State<Boolean> f37State$Boolean$arg0$callRaceRemoteTheme$funApp;
    public static final LiveLiterals$AppSkeletonKt INSTANCE = new LiveLiterals$AppSkeletonKt();

    /* JADX INFO: renamed from: Boolean$arg-0$call-RaceRemoteTheme$fun-App, reason: not valid java name */
    private static boolean f36Boolean$arg0$callRaceRemoteTheme$funApp = true;

    @LiveLiteralInfo(key = "Boolean$arg-0$call-RaceRemoteTheme$fun-App", offset = 475)
    /* JADX INFO: renamed from: Boolean$arg-0$call-RaceRemoteTheme$fun-App, reason: not valid java name */
    public final boolean m5975Boolean$arg0$callRaceRemoteTheme$funApp() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f36Boolean$arg0$callRaceRemoteTheme$funApp;
        }
        State<Boolean> stateLiveLiteral = f37State$Boolean$arg0$callRaceRemoteTheme$funApp;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-RaceRemoteTheme$fun-App", Boolean.valueOf(f36Boolean$arg0$callRaceRemoteTheme$funApp));
            f37State$Boolean$arg0$callRaceRemoteTheme$funApp = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }
}
