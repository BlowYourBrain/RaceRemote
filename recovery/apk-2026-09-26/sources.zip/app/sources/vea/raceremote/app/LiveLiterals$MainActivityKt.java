package vea.raceremote.app;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: MainActivity.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/app/MainActivity.kt")
public final class LiveLiterals$MainActivityKt {

    /* JADX INFO: renamed from: Boolean$arg-1$call-setDecorFitsSystemWindows$fun-hideSystemBars$class-MainActivity, reason: not valid java name */
    private static boolean f38Boolean$arg1$callsetDecorFitsSystemWindows$funhideSystemBars$classMainActivity;
    public static final LiveLiterals$MainActivityKt INSTANCE = new LiveLiterals$MainActivityKt();

    /* JADX INFO: renamed from: Int$class-MainActivity, reason: not valid java name */
    private static int f39Int$classMainActivity = 8;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-setDecorFitsSystemWindows$fun-hideSystemBars$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f40State$Boolean$arg1$callsetDecorFitsSystemWindows$funhideSystemBars$classMainActivity;

    /* JADX INFO: renamed from: State$Int$class-MainActivity, reason: not valid java name */
    private static State<Integer> f41State$Int$classMainActivity;

    @LiveLiteralInfo(key = "Boolean$arg-1$call-setDecorFitsSystemWindows$fun-hideSystemBars$class-MainActivity", offset = 2644)
    /* JADX INFO: renamed from: Boolean$arg-1$call-setDecorFitsSystemWindows$fun-hideSystemBars$class-MainActivity, reason: not valid java name */
    public final boolean m5976Boolean$arg1$callsetDecorFitsSystemWindows$funhideSystemBars$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f38Boolean$arg1$callsetDecorFitsSystemWindows$funhideSystemBars$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f40State$Boolean$arg1$callsetDecorFitsSystemWindows$funhideSystemBars$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-setDecorFitsSystemWindows$fun-hideSystemBars$class-MainActivity", Boolean.valueOf(f38Boolean$arg1$callsetDecorFitsSystemWindows$funhideSystemBars$classMainActivity));
            f40State$Boolean$arg1$callsetDecorFitsSystemWindows$funhideSystemBars$classMainActivity = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Int$class-MainActivity", offset = -1)
    /* JADX INFO: renamed from: Int$class-MainActivity, reason: not valid java name */
    public final int m5977Int$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f39Int$classMainActivity;
        }
        State<Integer> stateLiveLiteral = f41State$Int$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-MainActivity", Integer.valueOf(f39Int$classMainActivity));
            f41State$Int$classMainActivity = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }
}
