package vea.raceremote.app;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: MainApplicationModule.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/app/MainApplicationModule.kt")
public final class LiveLiterals$MainApplicationModuleKt {
    public static final LiveLiterals$MainApplicationModuleKt INSTANCE = new LiveLiterals$MainApplicationModuleKt();

    /* JADX INFO: renamed from: Int$class-MainApplicationModule, reason: not valid java name */
    private static int f42Int$classMainApplicationModule;

    /* JADX INFO: renamed from: State$Int$class-MainApplicationModule, reason: not valid java name */
    private static State<Integer> f43State$Int$classMainApplicationModule;

    @LiveLiteralInfo(key = "Int$class-MainApplicationModule", offset = -1)
    /* JADX INFO: renamed from: Int$class-MainApplicationModule, reason: not valid java name */
    public final int m5978Int$classMainApplicationModule() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f42Int$classMainApplicationModule;
        }
        State<Integer> stateLiveLiteral = f43State$Int$classMainApplicationModule;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-MainApplicationModule", Integer.valueOf(f42Int$classMainApplicationModule));
            f43State$Int$classMainApplicationModule = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }
}
