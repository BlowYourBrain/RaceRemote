package vea.raceremote.app;

import android.bluetooth.BluetoothDevice;
import android.content.ComponentCallbacks;
import android.content.Intent;
import android.os.Bundle;
import androidx.activity.ComponentActivity;
import androidx.activity.compose.ComponentActivityKt;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.lifecycle.LifecycleOwnerKt;
import androidx.lifecycle.ViewModelLazy;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.savedstate.SavedStateRegistryOwner;
import java.util.Collection;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.LazyThreadSafetyMode;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowCollector;
import org.koin.android.ext.android.AndroidKoinScopeExtKt;
import org.koin.androidx.viewmodel.ViewModelOwner;
import org.koin.androidx.viewmodel.ViewModelParameter;
import org.koin.androidx.viewmodel.ViewModelResolverKt;
import org.koin.core.parameter.ParametersHolder;
import org.koin.core.qualifier.Qualifier;
import org.koin.core.scope.Scope;
import vea.raceremote.features.remote_control.presentation.ActionsViewModel;
import vea.raceremote.features.remote_control.presentation.RemoteDeviceConnection;
import vea.raceremote.features.remote_control.presentation.model.RemoteDevice;
import vea.raceremote.features.remote_control.utils.activity_result_handler.BluetoothResultHandler;
import vea.raceremote.features.remote_control.utils.activity_result_handler.HandlerList;
import vea.raceremote.utils.bluetooth.BluetoothUtilsKt;

/* JADX INFO: compiled from: MainActivity.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\u0010\u001a\u00020\u0011H\u0002J\"\u0010\u0012\u001a\u00020\u00112\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u00142\b\u0010\u0016\u001a\u0004\u0018\u00010\u0017H\u0014J\u0012\u0010\u0018\u001a\u00020\u00112\b\u0010\u0019\u001a\u0004\u0018\u00010\u001aH\u0014J\b\u0010\u001b\u001a\u00020\u0011H\u0002J\b\u0010\u001c\u001a\u00020\u0011H\u0002J\b\u0010\u001d\u001a\u00020\u0011H\u0002R\u001b\u0010\u0003\u001a\u00020\u00048BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u0007\u0010\b\u001a\u0004\b\u0005\u0010\u0006R\u000e\u0010\t\u001a\u00020\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u001b\u0010\u000b\u001a\u00020\f8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u000f\u0010\b\u001a\u0004\b\r\u0010\u000e¨\u0006\u001e"}, d2 = {"Lvea/raceremote/app/MainActivity;", "Landroidx/activity/ComponentActivity;", "()V", "actionsViewModel", "Lvea/raceremote/features/remote_control/presentation/ActionsViewModel;", "getActionsViewModel", "()Lvea/raceremote/features/remote_control/presentation/ActionsViewModel;", "actionsViewModel$delegate", "Lkotlin/Lazy;", "activityResultHandler", "Lvea/raceremote/features/remote_control/utils/activity_result_handler/HandlerList;", "remoteDeviceConnection", "Lvea/raceremote/features/remote_control/presentation/RemoteDeviceConnection;", "getRemoteDeviceConnection", "()Lvea/raceremote/features/remote_control/presentation/RemoteDeviceConnection;", "remoteDeviceConnection$delegate", "hideSystemBars", "", "onActivityResult", "requestCode", "", "resultCode", "data", "Landroid/content/Intent;", "onCreate", "savedInstanceState", "Landroid/os/Bundle;", "setupActivityHandlerList", "setupViewModel", "setupWindow", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class MainActivity extends ComponentActivity {
    public static final int $stable = LiveLiterals$MainActivityKt.INSTANCE.m5977Int$classMainActivity();

    /* JADX INFO: renamed from: actionsViewModel$delegate, reason: from kotlin metadata */
    private final Lazy actionsViewModel;
    private final HandlerList activityResultHandler = new HandlerList();

    /* JADX INFO: renamed from: remoteDeviceConnection$delegate, reason: from kotlin metadata */
    private final Lazy remoteDeviceConnection;

    public MainActivity() {
        final MainActivity $this$viewModel_u24default$iv = this;
        final Qualifier qualifier$iv = null;
        final Function0<ViewModelOwner> function0 = new Function0<ViewModelOwner>() { // from class: vea.raceremote.app.MainActivity$special$$inlined$viewModel$default$1
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public final ViewModelOwner invoke() {
                ViewModelOwner.Companion companion = ViewModelOwner.INSTANCE;
                ComponentActivity componentActivity = $this$viewModel_u24default$iv;
                return companion.from(componentActivity, componentActivity instanceof SavedStateRegistryOwner ? componentActivity : null);
            }
        };
        final Function0 parameters$iv = null;
        final Scope scope$iv = AndroidKoinScopeExtKt.getKoinScope($this$viewModel_u24default$iv);
        this.actionsViewModel = new ViewModelLazy(Reflection.getOrCreateKotlinClass(ActionsViewModel.class), new Function0<ViewModelStore>() { // from class: vea.raceremote.app.MainActivity$special$$inlined$viewModel$default$3
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelStore invoke() {
                ViewModelStore viewModelStore = getViewModelStore();
                Intrinsics.checkNotNullExpressionValue(viewModelStore, "viewModelStore");
                return viewModelStore;
            }
        }, new Function0<ViewModelProvider.Factory>() { // from class: vea.raceremote.app.MainActivity$special$$inlined$viewModel$default$2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final ViewModelProvider.Factory invoke() {
                Function0 owner$iv = function0;
                Qualifier qualifier$iv2 = qualifier$iv;
                Function0 parameters$iv2 = parameters$iv;
                Scope scope$iv2 = scope$iv;
                ViewModelOwner ownerValue$iv = (ViewModelOwner) owner$iv.invoke();
                ViewModelParameter viewModelParameters$iv = new ViewModelParameter(Reflection.getOrCreateKotlinClass(ActionsViewModel.class), qualifier$iv2, null, parameters$iv2, ownerValue$iv.getStoreOwner(), ownerValue$iv.getStateRegistry());
                return ViewModelResolverKt.pickFactory(scope$iv2, viewModelParameters$iv);
            }
        });
        final MainActivity $this$inject_u24default$iv = this;
        final Qualifier qualifier$iv2 = null;
        LazyThreadSafetyMode mode$iv = LazyThreadSafetyMode.SYNCHRONIZED;
        final Function0 parameters$iv2 = null;
        this.remoteDeviceConnection = LazyKt.lazy(mode$iv, (Function0) new Function0<RemoteDeviceConnection>() { // from class: vea.raceremote.app.MainActivity$special$$inlined$inject$default$1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object, vea.raceremote.features.remote_control.presentation.RemoteDeviceConnection] */
            @Override // kotlin.jvm.functions.Function0
            public final RemoteDeviceConnection invoke() {
                ComponentCallbacks $this$get$iv = $this$inject_u24default$iv;
                Qualifier qualifier$iv3 = qualifier$iv2;
                Function0<? extends ParametersHolder> function1 = parameters$iv2;
                Scope this_$iv$iv = AndroidKoinScopeExtKt.getKoinScope($this$get$iv);
                return this_$iv$iv.get(Reflection.getOrCreateKotlinClass(RemoteDeviceConnection.class), qualifier$iv3, function1);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final ActionsViewModel getActionsViewModel() {
        return (ActionsViewModel) getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final RemoteDeviceConnection getRemoteDeviceConnection() {
        return (RemoteDeviceConnection) getValue();
    }

    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupWindow();
        hideSystemBars();
        setupViewModel();
        setupActivityHandlerList();
        ComponentActivityKt.setContent$default(this, null, ComposableSingletons$MainActivityKt.INSTANCE.m5974getLambda1$app_debug(), 1, null);
    }

    private final void setupWindow() {
        setRequestedOrientation(6);
    }

    /* JADX INFO: renamed from: vea.raceremote.app.MainActivity$setupViewModel$1, reason: invalid class name */
    /* JADX INFO: compiled from: MainActivity.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\u008a@"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "vea.raceremote.app.MainActivity$setupViewModel$1", f = "MainActivity.kt", i = {}, l = {45}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return MainActivity.this.new AnonymousClass1(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    Flow<RemoteDevice> remoteDevice = MainActivity.this.getActionsViewModel().getRemoteDevice();
                    final MainActivity mainActivity = MainActivity.this;
                    this.label = 1;
                    if (remoteDevice.collect(new FlowCollector<RemoteDevice>() { // from class: vea.raceremote.app.MainActivity.setupViewModel.1.1
                        @Override // kotlinx.coroutines.flow.FlowCollector
                        public /* bridge */ /* synthetic */ Object emit(RemoteDevice remoteDevice2, Continuation $completion) {
                            return emit2(remoteDevice2, (Continuation<? super Unit>) $completion);
                        }

                        /* JADX INFO: renamed from: emit, reason: avoid collision after fix types in other method */
                        public final Object emit2(RemoteDevice remoteDevice2, Continuation<? super Unit> continuation) {
                            mainActivity.getRemoteDeviceConnection().chooseRemoteDevice(mainActivity, remoteDevice2);
                            return Unit.INSTANCE;
                        }
                    }, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    private final void setupViewModel() {
        LifecycleOwnerKt.getLifecycleScope(this).launchWhenResumed(new AnonymousClass1(null));
        LifecycleOwnerKt.getLifecycleScope(this).launchWhenResumed(new AnonymousClass2(null));
    }

    /* JADX INFO: renamed from: vea.raceremote.app.MainActivity$setupViewModel$2, reason: invalid class name */
    /* JADX INFO: compiled from: MainActivity.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\u008a@"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "vea.raceremote.app.MainActivity$setupViewModel$2", f = "MainActivity.kt", i = {}, l = {54}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass2(Continuation<? super AnonymousClass2> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return MainActivity.this.new AnonymousClass2(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    Flow<Unit> requestBluetoothPermissions = MainActivity.this.getActionsViewModel().getRequestBluetoothPermissions();
                    final MainActivity mainActivity = MainActivity.this;
                    this.label = 1;
                    if (requestBluetoothPermissions.collect(new FlowCollector<Unit>() { // from class: vea.raceremote.app.MainActivity.setupViewModel.2.1
                        @Override // kotlinx.coroutines.flow.FlowCollector
                        public /* bridge */ /* synthetic */ Object emit(Unit unit, Continuation $completion) {
                            return emit2(unit, (Continuation<? super Unit>) $completion);
                        }

                        /* JADX INFO: renamed from: emit, reason: avoid collision after fix types in other method */
                        public final Object emit2(Unit it, Continuation<? super Unit> continuation) {
                            MainActivity mainActivity2 = mainActivity;
                            Collection $this$toTypedArray$iv = BluetoothUtilsKt.getBluetoothPermissions();
                            mainActivity2.requestPermissions((String[]) $this$toTypedArray$iv.toArray(new String[0]), RemoteDevice.Bluetooth.getRequestCode());
                            return Unit.INSTANCE;
                        }
                    }, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    private final void setupActivityHandlerList() {
        HandlerList $this$setupActivityHandlerList_u24lambda_u240 = this.activityResultHandler;
        $this$setupActivityHandlerList_u24lambda_u240.addHandler(new BluetoothResultHandler(new Function1<BluetoothDevice, Unit>() { // from class: vea.raceremote.app.MainActivity$setupActivityHandlerList$1$1
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(BluetoothDevice bluetoothDevice) {
                invoke2(bluetoothDevice);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(BluetoothDevice bluetoothDevice) {
                Intrinsics.checkNotNullParameter(bluetoothDevice, "bluetoothDevice");
                ActionsViewModel actionsViewModel = this.this$0.getActionsViewModel();
                String address = bluetoothDevice.getAddress();
                Intrinsics.checkNotNullExpressionValue(address, "bluetoothDevice.address");
                actionsViewModel.connectBluetooth(address);
            }
        }, null, 2));
    }

    private final void hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(getWindow(), LiveLiterals$MainActivityKt.INSTANCE.m5976Boolean$arg1$callsetDecorFitsSystemWindows$funhideSystemBars$classMainActivity());
        getWindow().getAttributes().layoutInDisplayCutoutMode = 1;
        WindowInsetsControllerCompat windowInsetsController = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        Intrinsics.checkNotNullExpressionValue(windowInsetsController, "getInsetsController(window, window.decorView)");
        windowInsetsController.setSystemBarsBehavior(2);
        windowInsetsController.hide(WindowInsetsCompat.Type.systemBars());
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        this.activityResultHandler.handle(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
    }
}
