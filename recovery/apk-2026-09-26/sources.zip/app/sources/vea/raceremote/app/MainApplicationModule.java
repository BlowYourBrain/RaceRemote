package vea.raceremote.app;

import android.app.Application;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.koin.android.ext.koin.KoinExtKt;
import org.koin.core.KoinApplication;
import org.koin.core.context.GlobalContext;
import org.koin.core.logger.Level;
import vea.raceremote.BuildConfig;
import vea.raceremote.features.remote_control.di.NetworModuleKt;
import vea.raceremote.features.remote_control.di.RemoteControlModuleKt;

/* JADX INFO: compiled from: MainApplicationModule.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0016¨\u0006\u0005"}, d2 = {"Lvea/raceremote/app/MainApplicationModule;", "Landroid/app/Application;", "()V", "onCreate", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class MainApplicationModule extends Application {
    public static final int $stable = LiveLiterals$MainApplicationModuleKt.INSTANCE.m5978Int$classMainApplicationModule();

    @Override // android.app.Application
    public void onCreate() {
        super.onCreate();
        GlobalContext.INSTANCE.startKoin(new Function1<KoinApplication, Unit>() { // from class: vea.raceremote.app.MainApplicationModule.onCreate.1
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(KoinApplication koinApplication) {
                invoke2(koinApplication);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(KoinApplication $this$startKoin) {
                Intrinsics.checkNotNullParameter($this$startKoin, "$this$startKoin");
                KoinExtKt.androidLogger($this$startKoin, BuildConfig.DEBUG ? Level.ERROR : Level.NONE);
                KoinExtKt.androidContext($this$startKoin, MainApplicationModule.this);
                $this$startKoin.modules(AppModuleKt.getAppModule(), RemoteControlModuleKt.getRemoteControlModule(), NetworModuleKt.getNetworkModule());
            }
        });
    }
}
