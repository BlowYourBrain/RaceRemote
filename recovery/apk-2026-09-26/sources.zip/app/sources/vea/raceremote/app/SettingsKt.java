package vea.raceremote.app;

import kotlin.Metadata;

/* JADX INFO: compiled from: Settings.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u0000\b\n\u0000\n\u0002\u0010\u000e\n\u0000\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0002"}, d2 = {"REMOTE_DEVICE_IP_ADDRESS", "", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class SettingsKt {
    private static final String REMOTE_DEVICE_IP_ADDRESS = "192.168.1.100:80";
}
