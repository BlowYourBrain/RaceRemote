package vea.raceremote.control;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: CarControlClient.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0015\b\u0087\b\u0018\u00002\u00020\u0001B7\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0007\u001a\u00020\b\u0012\b\b\u0002\u0010\t\u001a\u00020\b¢\u0006\u0002\u0010\nJ\t\u0010\u0013\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0016\u001a\u00020\bHÆ\u0003J\t\u0010\u0017\u001a\u00020\bHÆ\u0003J;\u0010\u0018\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\bHÆ\u0001J\u0013\u0010\u0019\u001a\u00020\u00052\b\u0010\u001a\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001b\u001a\u00020\bHÖ\u0001J\t\u0010\u001c\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\fR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\t\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0011¨\u0006\u001d"}, d2 = {"Lvea/raceremote/control/CarConnectionState;", "", "message", "", "connected", "", "connecting", "throttle", "", "steering", "(Ljava/lang/String;ZZII)V", "getConnected", "()Z", "getConnecting", "getMessage", "()Ljava/lang/String;", "getSteering", "()I", "getThrottle", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "other", "hashCode", "toString", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final /* data */ class CarConnectionState {
    public static final int $stable = LiveLiterals$CarControlClientKt.INSTANCE.m6039Int$classCarConnectionState();
    private final boolean connected;
    private final boolean connecting;
    private final String message;
    private final int steering;
    private final int throttle;

    public CarConnectionState() {
        this(null, false, false, 0, 0, 31);
    }

    public static /* synthetic */ CarConnectionState copy$default(CarConnectionState carConnectionState, String str, boolean z, boolean z2, int i, int i2, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            str = carConnectionState.message;
        }
        if ((i3 & 2) != 0) {
            z = carConnectionState.connected;
        }
        boolean z3 = z;
        if ((i3 & 4) != 0) {
            z2 = carConnectionState.connecting;
        }
        boolean z4 = z2;
        if ((i3 & 8) != 0) {
            i = carConnectionState.throttle;
        }
        int i4 = i;
        if ((i3 & 16) != 0) {
            i2 = carConnectionState.steering;
        }
        return carConnectionState.copy(str, z3, z4, i4, i2);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getMessage() {
        return this.message;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final boolean getConnected() {
        return this.connected;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final boolean getConnecting() {
        return this.connecting;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final int getThrottle() {
        return this.throttle;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final int getSteering() {
        return this.steering;
    }

    public final CarConnectionState copy(String message, boolean connected, boolean connecting, int throttle, int steering) {
        Intrinsics.checkNotNullParameter(message, "message");
        return new CarConnectionState(message, connected, connecting, throttle, steering);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return LiveLiterals$CarControlClientKt.INSTANCE.m5993Boolean$branch$when$funequals$classCarConnectionState();
        }
        if (!(other instanceof CarConnectionState)) {
            return LiveLiterals$CarControlClientKt.INSTANCE.m5994Boolean$branch$when1$funequals$classCarConnectionState();
        }
        CarConnectionState carConnectionState = (CarConnectionState) other;
        if (!Intrinsics.areEqual(this.message, carConnectionState.message)) {
            return LiveLiterals$CarControlClientKt.INSTANCE.m5995Boolean$branch$when2$funequals$classCarConnectionState();
        }
        if (this.connected != carConnectionState.connected) {
            return LiveLiterals$CarControlClientKt.INSTANCE.m5996Boolean$branch$when3$funequals$classCarConnectionState();
        }
        if (this.connecting != carConnectionState.connecting) {
            return LiveLiterals$CarControlClientKt.INSTANCE.m5997Boolean$branch$when4$funequals$classCarConnectionState();
        }
        if (this.throttle != carConnectionState.throttle) {
            return LiveLiterals$CarControlClientKt.INSTANCE.m5998Boolean$branch$when5$funequals$classCarConnectionState();
        }
        return this.steering != carConnectionState.steering ? LiveLiterals$CarControlClientKt.INSTANCE.m5999Boolean$branch$when6$funequals$classCarConnectionState() : LiveLiterals$CarControlClientKt.INSTANCE.m6000Boolean$funequals$classCarConnectionState();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v5, types: [int] */
    /* JADX WARN: Type inference failed for: r1v3, types: [int] */
    /* JADX WARN: Type inference failed for: r2v1, types: [int] */
    /* JADX WARN: Type inference failed for: r2v7 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r3v0 */
    /* JADX WARN: Type inference failed for: r3v1, types: [int] */
    /* JADX WARN: Type inference failed for: r3v2 */
    public int hashCode() {
        int iM6029Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCarConnectionState = LiveLiterals$CarControlClientKt.INSTANCE.m6029Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCarConnectionState() * this.message.hashCode();
        boolean z = this.connected;
        ?? r2 = z;
        if (z) {
            r2 = 1;
        }
        int iM6030Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classCarConnectionState = LiveLiterals$CarControlClientKt.INSTANCE.m6030Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classCarConnectionState() * (iM6029Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCarConnectionState + r2);
        boolean z2 = this.connecting;
        return (LiveLiterals$CarControlClientKt.INSTANCE.m6032Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classCarConnectionState() * ((LiveLiterals$CarControlClientKt.INSTANCE.m6031Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classCarConnectionState() * (iM6030Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classCarConnectionState + (z2 ? 1 : z2))) + Integer.hashCode(this.throttle))) + Integer.hashCode(this.steering);
    }

    public String toString() {
        return LiveLiterals$CarControlClientKt.INSTANCE.m6064String$0$str$funtoString$classCarConnectionState() + LiveLiterals$CarControlClientKt.INSTANCE.m6065String$1$str$funtoString$classCarConnectionState() + this.message + LiveLiterals$CarControlClientKt.INSTANCE.m6076String$3$str$funtoString$classCarConnectionState() + LiveLiterals$CarControlClientKt.INSTANCE.m6080String$4$str$funtoString$classCarConnectionState() + this.connected + LiveLiterals$CarControlClientKt.INSTANCE.m6083String$6$str$funtoString$classCarConnectionState() + LiveLiterals$CarControlClientKt.INSTANCE.m6084String$7$str$funtoString$classCarConnectionState() + this.connecting + LiveLiterals$CarControlClientKt.INSTANCE.m6085String$9$str$funtoString$classCarConnectionState() + LiveLiterals$CarControlClientKt.INSTANCE.m6066String$10$str$funtoString$classCarConnectionState() + this.throttle + LiveLiterals$CarControlClientKt.INSTANCE.m6067String$12$str$funtoString$classCarConnectionState() + LiveLiterals$CarControlClientKt.INSTANCE.m6068String$13$str$funtoString$classCarConnectionState() + this.steering + LiveLiterals$CarControlClientKt.INSTANCE.m6069String$15$str$funtoString$classCarConnectionState();
    }

    public CarConnectionState(String message, boolean connected, boolean connecting, int throttle, int steering) {
        Intrinsics.checkNotNullParameter(message, "message");
        this.message = message;
        this.connected = connected;
        this.connecting = connecting;
        this.throttle = throttle;
        this.steering = steering;
    }

    public final String getMessage() {
        return this.message;
    }

    public final boolean getConnected() {
        return this.connected;
    }

    public final boolean getConnecting() {
        return this.connecting;
    }

    public final int getThrottle() {
        return this.throttle;
    }

    public final int getSteering() {
        return this.steering;
    }
}
