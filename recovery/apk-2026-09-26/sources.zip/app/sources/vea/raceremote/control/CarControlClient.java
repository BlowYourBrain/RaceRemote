package vea.raceremote.control;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import javax.net.SocketFactory;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.ranges.IntRange;
import kotlin.ranges.LongRange;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlow;
import kotlinx.coroutines.flow.StateFlowKt;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;

/* JADX INFO: compiled from: CarControlClient.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000j\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B5\u0012\u0014\b\u0002\u0010\u0002\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00050\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u0012\u000e\b\u0002\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\t¢\u0006\u0002\u0010\u000bJ\u0006\u0010#\u001a\u00020\u0005J1\u0010$\u001a\u00020\u00052\u0006\u0010%\u001a\u00020\u00042\u0006\u0010&\u001a\u00020'2\b\b\u0002\u0010(\u001a\u00020\u001d2\n\b\u0002\u0010)\u001a\u0004\u0018\u00010\n¢\u0006\u0002\u0010*J\u0010\u0010+\u001a\u00020\u00052\b\b\u0002\u0010,\u001a\u00020\u0004J\u0010\u0010-\u001a\u00020\u00052\u0006\u0010.\u001a\u00020/H\u0002J\u0016\u00100\u001a\u00020\u00052\u0006\u0010\u001e\u001a\u0002012\u0006\u0010\u001c\u001a\u000201J\b\u00102\u001a\u00020\u0005H\u0002R\u0014\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0002\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00050\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u0012\u0010\r\u001a\u0004\u0018\u00010\nX\u0082\u000e¢\u0006\u0004\n\u0002\u0010\u000eR\u0014\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00110\u0010X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u0012\u0010\u0013\u001a\u0004\u0018\u00010\nX\u0082\u000e¢\u0006\u0004\n\u0002\u0010\u000eR\u000e\u0010\u0014\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0016\u001a\u0004\u0018\u00010\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R\u0017\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00110\u0019¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001bR\u000e\u0010\u001c\u001a\u00020\u001dX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u001dX\u0082\u000e¢\u0006\u0002\n\u0000R\u0016\u0010\u001f\u001a\n !*\u0004\u0018\u00010 0 X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000¨\u00063"}, d2 = {"Lvea/raceremote/control/CarControlClient;", "", "diagnostics", "Lkotlin/Function1;", "", "", "traceAllCommands", "", "clockMs", "Lkotlin/Function0;", "", "(Lkotlin/jvm/functions/Function1;ZLkotlin/jvm/functions/Function0;)V", "generation", "lastTickAt", "Ljava/lang/Long;", "mutableState", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Lvea/raceremote/control/CarConnectionState;", "opened", "pending", "sentAt", "sequence", "socket", "Lokhttp3/WebSocket;", "state", "Lkotlinx/coroutines/flow/StateFlow;", "getState", "()Lkotlinx/coroutines/flow/StateFlow;", "steering", "", "throttle", "timer", "Ljava/util/concurrent/ScheduledExecutorService;", "kotlin.jvm.PlatformType", "token", "close", "connect", "host", "httpClient", "Lokhttp3/OkHttpClient;", "port", "expectedChipId", "(Ljava/lang/String;Lokhttp3/OkHttpClient;ILjava/lang/Long;)V", "disconnect", "message", "send", "p", "Lvea/raceremote/control/ControlPacket;", "setInput", "", "tick", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class CarControlClient {
    public static final int $stable = LiveLiterals$CarControlClientKt.INSTANCE.m6040Int$classCarControlClient();
    private final Function0<Long> clockMs;
    private final Function1<String, Unit> diagnostics;
    private long generation;
    private Long lastTickAt;
    private final MutableStateFlow<CarConnectionState> mutableState;
    private boolean opened;
    private Long pending;
    private long sentAt;
    private long sequence;
    private WebSocket socket;
    private final StateFlow<CarConnectionState> state;
    private int steering;
    private int throttle;
    private final ScheduledExecutorService timer;
    private long token;
    private final boolean traceAllCommands;

    public CarControlClient() {
        this(null, false, null, 7);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public CarControlClient(Function1<? super String, Unit> function1, boolean traceAllCommands, Function0<Long> function0) {
        Intrinsics.checkNotNullParameter(function1, "diagnostics");
        Intrinsics.checkNotNullParameter(function0, "clockMs");
        this.diagnostics = function1;
        this.traceAllCommands = traceAllCommands;
        this.clockMs = function0;
        MutableStateFlow<CarConnectionState> MutableStateFlow = StateFlowKt.MutableStateFlow(new CarConnectionState(null, false, false, 0, 0, 31));
        this.mutableState = MutableStateFlow;
        this.state = FlowKt.asStateFlow(MutableStateFlow);
        ScheduledExecutorService scheduledExecutorServiceNewSingleThreadScheduledExecutor = Executors.newSingleThreadScheduledExecutor();
        this.timer = scheduledExecutorServiceNewSingleThreadScheduledExecutor;
        scheduledExecutorServiceNewSingleThreadScheduledExecutor.scheduleAtFixedRate(new Runnable() { // from class: vea.raceremote.control.CarControlClient$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                CarControlClient._init_$lambda$1(this.f$0);
            }
        }, LiveLiterals$CarControlClientKt.INSTANCE.m6053Long$arg1$callscheduleAtFixedRate$classCarControlClient(), LiveLiterals$CarControlClientKt.INSTANCE.m6054Long$arg2$callscheduleAtFixedRate$classCarControlClient(), TimeUnit.MILLISECONDS);
    }

    public final StateFlow<CarConnectionState> getState() {
        return this.state;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void _init_$lambda$1(CarControlClient this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        synchronized (this$0) {
            this$0.tick();
            Unit unit = Unit.INSTANCE;
        }
    }

    public static /* synthetic */ void connect$default(CarControlClient carControlClient, String str, OkHttpClient okHttpClient, int i, Long l, int i2, Object obj) {
        if ((i2 & 4) != 0) {
            i = LiveLiterals$CarControlClientKt.INSTANCE.m6041Int$paramport$funconnect$classCarControlClient();
        }
        if ((i2 & 8) != 0) {
            l = null;
        }
        carControlClient.connect(str, okHttpClient, i, l);
    }

    /* JADX WARN: Code duplicated, block: B:64:0x0145  */
    /* JADX WARN: Code duplicated, block: B:71:0x014f A[Catch: all -> 0x0266, TryCatch #0 {, blocks: (B:4:0x0007, B:5:0x0044, B:7:0x004a, B:8:0x005b, B:10:0x006d, B:12:0x0075, B:28:0x00b9, B:34:0x00c9, B:40:0x00db, B:52:0x0101, B:71:0x014f, B:79:0x0168, B:81:0x0184, B:84:0x01a1, B:86:0x01f5, B:88:0x01fe, B:91:0x0249, B:55:0x0116, B:57:0x011c, B:43:0x00e5, B:45:0x00ed, B:48:0x00f7, B:37:0x00d2, B:31:0x00c2, B:15:0x0080, B:16:0x0084, B:18:0x008a, B:20:0x0094), top: B:97:0x0007 }] */
    /* JADX WARN: Code duplicated, block: B:73:0x015d A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:75:0x0161  */
    /* JADX WARN: Code duplicated, block: B:77:0x0164  */
    /* JADX WARN: Code duplicated, block: B:78:0x0166  */
    /* JADX WARN: Code duplicated, block: B:79:0x0168 A[Catch: all -> 0x0266, TryCatch #0 {, blocks: (B:4:0x0007, B:5:0x0044, B:7:0x004a, B:8:0x005b, B:10:0x006d, B:12:0x0075, B:28:0x00b9, B:34:0x00c9, B:40:0x00db, B:52:0x0101, B:71:0x014f, B:79:0x0168, B:81:0x0184, B:84:0x01a1, B:86:0x01f5, B:88:0x01fe, B:91:0x0249, B:55:0x0116, B:57:0x011c, B:43:0x00e5, B:45:0x00ed, B:48:0x00f7, B:37:0x00d2, B:31:0x00c2, B:15:0x0080, B:16:0x0084, B:18:0x008a, B:20:0x0094), top: B:97:0x0007 }] */
    /* JADX WARN: Code duplicated, block: B:86:0x01f5 A[Catch: all -> 0x0266, TryCatch #0 {, blocks: (B:4:0x0007, B:5:0x0044, B:7:0x004a, B:8:0x005b, B:10:0x006d, B:12:0x0075, B:28:0x00b9, B:34:0x00c9, B:40:0x00db, B:52:0x0101, B:71:0x014f, B:79:0x0168, B:81:0x0184, B:84:0x01a1, B:86:0x01f5, B:88:0x01fe, B:91:0x0249, B:55:0x0116, B:57:0x011c, B:43:0x00e5, B:45:0x00ed, B:48:0x00f7, B:37:0x00d2, B:31:0x00c2, B:15:0x0080, B:16:0x0084, B:18:0x008a, B:20:0x0094), top: B:97:0x0007 }] */
    /* JADX WARN: Code duplicated, block: B:87:0x01fc  */
    public final synchronized void connect(String host, OkHttpClient httpClient, int port, final Long expectedChipId) {
        boolean z;
        boolean z2;
        boolean local;
        boolean z3;
        String strM6107String$branch$if$valpath$funconnect$classCarControlClient;
        boolean z4;
        Intrinsics.checkNotNullParameter(host, "host");
        Intrinsics.checkNotNullParameter(httpClient, "httpClient");
        disconnect$default(this, null, 1, null);
        Iterable $this$map$iv = StringsKt.split$default((CharSequence) host, new char[]{LiveLiterals$CarControlClientKt.INSTANCE.m6004Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$funconnect$classCarControlClient()}, false, 0, 6, (Object) null);
        Collection destination$iv$iv = new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10));
        for (Object item$iv$iv : $this$map$iv) {
            destination$iv$iv.add(StringsKt.toIntOrNull((String) item$iv$iv));
        }
        List octets = (List) destination$iv$iv;
        if (octets.size() == LiveLiterals$CarControlClientKt.INSTANCE.m6037Int$arg1$callEQEQ$cond$cond$vallocal$funconnect$classCarControlClient()) {
            List $this$all$iv = octets;
            if (!($this$all$iv instanceof Collection) || !$this$all$iv.isEmpty()) {
                Iterator it = $this$all$iv.iterator();
                while (true) {
                    if (!it.hasNext()) {
                        z4 = true;
                        break;
                    }
                    Object element$iv = it.next();
                    Integer it2 = (Integer) element$iv;
                    if (!(it2 != null && new IntRange(LiveLiterals$CarControlClientKt.INSTANCE.m6012Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$vallocal$funconnect$classCarControlClient(), LiveLiterals$CarControlClientKt.INSTANCE.m6028Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$vallocal$funconnect$classCarControlClient()).contains(it2.intValue()))) {
                        z4 = false;
                        break;
                    }
                }
            } else {
                z4 = true;
            }
            if (z4) {
                Integer num = (Integer) octets.get(0);
                if (num != null && num.intValue() == 10) {
                    z = true;
                } else {
                    Integer num2 = (Integer) octets.get(0);
                    if (num2 != null && num2.intValue() == 127) {
                        z = true;
                    } else {
                        Integer num3 = (Integer) octets.get(0);
                        if (num3 != null && num3.intValue() == 192) {
                            z = true;
                            Integer num4 = (Integer) octets.get(1);
                            if (num4 != null && num4.intValue() == 168) {
                            }
                            local = z2;
                            if (local) {
                                int iM6010Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient = LiveLiterals$CarControlClientKt.INSTANCE.m6010Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient();
                                if (port <= LiveLiterals$CarControlClientKt.INSTANCE.m6026Int$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient() || iM6010Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient > port) {
                                    z3 = false;
                                } else {
                                    z3 = z;
                                }
                                if (z3) {
                                    if (expectedChipId == null && !new LongRange(LiveLiterals$CarControlClientKt.INSTANCE.m6009Int$$this$callrangeTo$$this$callcontains$$this$callnot$branch$cond$if1$funconnect$classCarControlClient(), LiveLiterals$CarControlClientKt.INSTANCE.m6048Long$arg0$callrangeTo$$this$callcontains$$this$callnot$branch$cond$if1$funconnect$classCarControlClient()).contains(expectedChipId.longValue())) {
                                        setValue(new CarConnectionState(LiveLiterals$CarControlClientKt.INSTANCE.m6087String$arg0$call$init$$arg0$call$setvalue$$branch$if1$funconnect$classCarControlClient(), false, false, 0, 0, 30));
                                        return;
                                    }
                                    final long current = this.generation;
                                    final Ref.ObjectRef identityToken = new Ref.ObjectRef();
                                    this.sentAt = invoke().longValue();
                                    setValue(new CarConnectionState(LiveLiterals$CarControlClientKt.INSTANCE.m6089String$arg0$call$init$$arg0$call$setvalue$$funconnect$classCarControlClient(), false, LiveLiterals$CarControlClientKt.INSTANCE.m5992Boolean$arg2$call$init$$arg0$call$setvalue$$funconnect$classCarControlClient(), 0, 0, 26));
                                    OkHttpClient.Builder builderNewBuilder = httpClient.newBuilder();
                                    SocketFactory socketFactory = httpClient.socketFactory();
                                    Intrinsics.checkNotNullExpressionValue(socketFactory, "httpClient.socketFactory()");
                                    OkHttpClient transport = builderNewBuilder.socketFactory(new ControlSocketFactory(socketFactory)).build();
                                    if (expectedChipId == null) {
                                        strM6107String$branch$if$valpath$funconnect$classCarControlClient = LiveLiterals$CarControlClientKt.INSTANCE.m6107String$branch$if$valpath$funconnect$classCarControlClient();
                                    } else {
                                        strM6107String$branch$if$valpath$funconnect$classCarControlClient = "/control/identity";
                                    }
                                    String path = strM6107String$branch$if$valpath$funconnect$classCarControlClient;
                                    this.socket = transport.newWebSocket(new Request.Builder().url(LiveLiterals$CarControlClientKt.INSTANCE.m6063String$0$str$arg0$callurl$$this$callbuild$arg0$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + host + LiveLiterals$CarControlClientKt.INSTANCE.m6075String$2$str$arg0$callurl$$this$callbuild$arg0$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + port + path).build(), new WebSocketListener() { // from class: vea.raceremote.control.CarControlClient.connect.1
                                        @Override // okhttp3.WebSocketListener
                                        public void onOpen(WebSocket webSocket, Response response) {
                                            Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                                            Intrinsics.checkNotNullParameter(response, "response");
                                            CarControlClient carControlClient = CarControlClient.this;
                                            long j = current;
                                            synchronized (carControlClient) {
                                                carControlClient.diagnostics.invoke(LiveLiterals$CarControlClientKt.INSTANCE.m6106String$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonOpen$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                                if (j == carControlClient.generation) {
                                                    carControlClient.opened = LiveLiterals$CarControlClientKt.INSTANCE.m5988Boolean$arg0$call$setopened$$branch$if$fun$anonymous$$arg1$callsynchronized$funonOpen$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient();
                                                } else {
                                                    webSocket.cancel();
                                                }
                                                Unit unit = Unit.INSTANCE;
                                            }
                                        }

                                        /* JADX WARN: Code duplicated, block: B:58:0x01e9 A[Catch: all -> 0x029a, TryCatch #0 {, blocks: (B:5:0x001a, B:8:0x0024, B:10:0x0028, B:12:0x0078, B:14:0x0084, B:15:0x008e, B:17:0x009a, B:18:0x00a4, B:20:0x00b0, B:22:0x00c6, B:24:0x00d0, B:36:0x0158, B:37:0x0163, B:39:0x0171, B:41:0x0179, B:43:0x0187, B:45:0x0193, B:47:0x019f, B:49:0x01bd, B:51:0x01ca, B:57:0x01de, B:54:0x01d5, B:58:0x01e9, B:59:0x0214, B:61:0x021c, B:63:0x0228, B:66:0x0233, B:68:0x023b, B:70:0x0259, B:71:0x0263, B:72:0x028c, B:26:0x00df, B:28:0x0106, B:30:0x0110, B:32:0x0120, B:34:0x012a, B:74:0x0296), top: B:80:0x001a }] */
                                        /* JADX WARN: Code duplicated, block: B:72:0x028c A[Catch: all -> 0x029a, TryCatch #0 {, blocks: (B:5:0x001a, B:8:0x0024, B:10:0x0028, B:12:0x0078, B:14:0x0084, B:15:0x008e, B:17:0x009a, B:18:0x00a4, B:20:0x00b0, B:22:0x00c6, B:24:0x00d0, B:36:0x0158, B:37:0x0163, B:39:0x0171, B:41:0x0179, B:43:0x0187, B:45:0x0193, B:47:0x019f, B:49:0x01bd, B:51:0x01ca, B:57:0x01de, B:54:0x01d5, B:58:0x01e9, B:59:0x0214, B:61:0x021c, B:63:0x0228, B:66:0x0233, B:68:0x023b, B:70:0x0259, B:71:0x0263, B:72:0x028c, B:26:0x00df, B:28:0x0106, B:30:0x0110, B:32:0x0120, B:34:0x012a, B:74:0x0296), top: B:80:0x001a }] */
                                        /* JADX WARN: Type inference failed for: r0v32, types: [T, java.lang.Long] */
                                        @Override // okhttp3.WebSocketListener
                                        public void onMessage(WebSocket webSocket, ByteString bytes) {
                                            Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                                            Intrinsics.checkNotNullParameter(bytes, "bytes");
                                            CarControlClient carControlClient = CarControlClient.this;
                                            long j = current;
                                            Long l = expectedChipId;
                                            Ref.ObjectRef<Long> objectRef = identityToken;
                                            synchronized (carControlClient) {
                                                if (j == carControlClient.generation) {
                                                    if (l != null && objectRef.element == null) {
                                                        carControlClient.diagnostics.invoke(LiveLiterals$CarControlClientKt.INSTANCE.m6058String$0$str$arg0$callinvoke$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + bytes.size());
                                                        IdentityPacket identityPacket = IdentityPacket.INSTANCE;
                                                        byte[] byteArray = bytes.toByteArray();
                                                        Intrinsics.checkNotNullExpressionValue(byteArray, "bytes.toByteArray()");
                                                        CarIdentity identity = identityPacket.decode(byteArray);
                                                        if (((Number) carControlClient.clockMs.invoke()).longValue() - carControlClient.sentAt >= LiveLiterals$CarControlClientKt.INSTANCE.m6017Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient()) {
                                                            carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6101String$arg0$calldisconnect$branch$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                                        } else if (identity == null) {
                                                            carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6102String$arg0$calldisconnect$branch1$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                                        } else if (identity.getChipId() != l.longValue()) {
                                                            carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6103String$arg0$calldisconnect$branch2$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                                        } else {
                                                            objectRef.element = Long.valueOf(identity.getToken());
                                                        }
                                                    } else {
                                                        ControlPacket.Companion companion = ControlPacket.INSTANCE;
                                                        byte[] byteArray2 = bytes.toByteArray();
                                                        Intrinsics.checkNotNullExpressionValue(byteArray2, "bytes.toByteArray()");
                                                        ControlPacket p = companion.decode(byteArray2);
                                                        if (carControlClient.traceAllCommands || carControlClient.token == 0 || carControlClient.sequence <= LiveLiterals$CarControlClientKt.INSTANCE.m6019Int$$this$calltoLong$arg1$calllessOrEqual$else$cond$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient()) {
                                                            carControlClient.diagnostics.invoke(LiveLiterals$CarControlClientKt.INSTANCE.m6060String$0$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + bytes.size() + LiveLiterals$CarControlClientKt.INSTANCE.m6073String$2$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + (p != null ? Integer.valueOf(p.getKind()) : null) + LiveLiterals$CarControlClientKt.INSTANCE.m6079String$4$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + (p != null ? Long.valueOf(p.getSequence()) : null) + LiveLiterals$CarControlClientKt.INSTANCE.m6082String$6$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + (((Number) carControlClient.clockMs.invoke()).longValue() - carControlClient.sentAt));
                                                        }
                                                        if (p == null) {
                                                            carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6100String$arg0$calldisconnect$branch$if3$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                                        } else if (carControlClient.token == LiveLiterals$CarControlClientKt.INSTANCE.m6051Long$arg1$callEQEQ$cond$cond$cond$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() && p.getKind() == 128 && p.getSequence() == LiveLiterals$CarControlClientKt.INSTANCE.m6050Long$arg1$callEQEQ$branch$cond$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() && p.getThrottle() == LiveLiterals$CarControlClientKt.INSTANCE.m6035Int$arg1$callEQEQ$branch$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() && p.getSteering() == LiveLiterals$CarControlClientKt.INSTANCE.m6036Int$arg1$callEQEQ$branch$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient()) {
                                                            if (((Number) carControlClient.clockMs.invoke()).longValue() - carControlClient.sentAt >= LiveLiterals$CarControlClientKt.INSTANCE.m6014Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient()) {
                                                                carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6090String$arg0$calldisconnect$branch$if$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                                            } else if (l != null) {
                                                                long token = p.getToken();
                                                                Long l2 = objectRef.element;
                                                                if (l2 != null && token == l2.longValue()) {
                                                                    carControlClient.token = p.getToken();
                                                                    carControlClient.sequence = LiveLiterals$CarControlClientKt.INSTANCE.m6044Long$arg0$call$setsequence$$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient();
                                                                    carControlClient.send(new ControlPacket(1, carControlClient.token, carControlClient.sequence, 0, 0, 24, null));
                                                                } else {
                                                                    carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6096String$arg0$calldisconnect$branch$if1$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                                                }
                                                            } else {
                                                                carControlClient.token = p.getToken();
                                                                carControlClient.sequence = LiveLiterals$CarControlClientKt.INSTANCE.m6044Long$arg0$call$setsequence$$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient();
                                                                carControlClient.send(new ControlPacket(1, carControlClient.token, carControlClient.sequence, 0, 0, 24, null));
                                                            }
                                                        } else if (p.getKind() == 129 && p.getToken() == carControlClient.token) {
                                                            long sequence = p.getSequence();
                                                            Long l3 = carControlClient.pending;
                                                            if (l3 == null || sequence != l3.longValue()) {
                                                                carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6104String$arg0$calldisconnect$else$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                                            } else if (((Number) carControlClient.clockMs.invoke()).longValue() - carControlClient.sentAt >= LiveLiterals$CarControlClientKt.INSTANCE.m6015Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient()) {
                                                                carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6091String$arg0$calldisconnect$branch$if$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                                            } else {
                                                                carControlClient.pending = null;
                                                                carControlClient.mutableState.setValue(new CarConnectionState(LiveLiterals$CarControlClientKt.INSTANCE.m6088String$arg0$call$init$$arg0$call$setvalue$$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient(), LiveLiterals$CarControlClientKt.INSTANCE.m5990Boolean$arg1$call$init$$arg0$call$setvalue$$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient(), false, p.getThrottle(), p.getSteering(), 4));
                                                            }
                                                        } else {
                                                            carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6104String$arg0$calldisconnect$else$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                                        }
                                                    }
                                                }
                                                Unit unit = Unit.INSTANCE;
                                            }
                                        }

                                        @Override // okhttp3.WebSocketListener
                                        public void onMessage(WebSocket webSocket, String text) {
                                            Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                                            Intrinsics.checkNotNullParameter(text, "text");
                                            CarControlClient carControlClient = CarControlClient.this;
                                            long j = current;
                                            synchronized (carControlClient) {
                                                if (j == carControlClient.generation) {
                                                    carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6094String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonMessage1$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                                }
                                                Unit unit = Unit.INSTANCE;
                                            }
                                        }

                                        @Override // okhttp3.WebSocketListener
                                        public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                                            Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                                            Intrinsics.checkNotNullParameter(t, "t");
                                            CarControlClient carControlClient = CarControlClient.this;
                                            long j = current;
                                            synchronized (carControlClient) {
                                                carControlClient.diagnostics.invoke(LiveLiterals$CarControlClientKt.INSTANCE.m6061String$0$str$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + t.getClass().getSimpleName() + LiveLiterals$CarControlClientKt.INSTANCE.m6074String$2$str$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + t.getMessage());
                                                if (j == carControlClient.generation) {
                                                    carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6093String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                                }
                                                Unit unit = Unit.INSTANCE;
                                            }
                                        }

                                        @Override // okhttp3.WebSocketListener
                                        public void onClosing(WebSocket webSocket, int code, String reason) {
                                            Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                                            Intrinsics.checkNotNullParameter(reason, "reason");
                                            CarControlClient carControlClient = CarControlClient.this;
                                            long j = current;
                                            synchronized (carControlClient) {
                                                if (carControlClient.traceAllCommands && j == carControlClient.generation) {
                                                    carControlClient.diagnostics.invoke(LiveLiterals$CarControlClientKt.INSTANCE.m6056String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg1$callsynchronized$funonClosing$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + code);
                                                }
                                                if (j == carControlClient.generation) {
                                                    carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6097String$arg0$calldisconnect$branch$if1$fun$anonymous$$arg1$callsynchronized$funonClosing$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                                }
                                                Unit unit = Unit.INSTANCE;
                                            }
                                        }

                                        @Override // okhttp3.WebSocketListener
                                        public void onClosed(WebSocket webSocket, int code, String reason) {
                                            Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                                            Intrinsics.checkNotNullParameter(reason, "reason");
                                            CarControlClient carControlClient = CarControlClient.this;
                                            long j = current;
                                            synchronized (carControlClient) {
                                                if (j == carControlClient.generation) {
                                                    carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6092String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonClosed$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                                }
                                                Unit unit = Unit.INSTANCE;
                                            }
                                        }
                                    });
                                    return;
                                }
                            }
                            setValue(new CarConnectionState(LiveLiterals$CarControlClientKt.INSTANCE.m6086String$arg0$call$init$$arg0$call$setvalue$$branch$if$funconnect$classCarControlClient(), false, false, 0, 0, 30));
                        }
                        z = true;
                        Integer num5 = (Integer) octets.get(LiveLiterals$CarControlClientKt.INSTANCE.m6024Int$arg0$callget$arg0$callEQEQ$cond$else$branch$vallocal$funconnect$classCarControlClient());
                        int iM6038Int$arg1$callEQEQ$cond$else$branch$vallocal$funconnect$classCarControlClient = LiveLiterals$CarControlClientKt.INSTANCE.m6038Int$arg1$callEQEQ$cond$else$branch$vallocal$funconnect$classCarControlClient();
                        if (num5 != null && num5.intValue() == iM6038Int$arg1$callEQEQ$cond$else$branch$vallocal$funconnect$classCarControlClient) {
                            int iM6011Int$$this$callrangeTo$$this$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient = LiveLiterals$CarControlClientKt.INSTANCE.m6011Int$$this$callrangeTo$$this$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient();
                            int iM6027Int$arg0$callrangeTo$$this$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient = LiveLiterals$CarControlClientKt.INSTANCE.m6027Int$arg0$callrangeTo$$this$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient();
                            Object obj = octets.get(LiveLiterals$CarControlClientKt.INSTANCE.m6023Int$arg0$callget$arg0$callCHECK_NOT_NULL$arg0$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient());
                            Intrinsics.checkNotNull(obj);
                            int iIntValue = ((Number) obj).intValue();
                            if ((iM6011Int$$this$callrangeTo$$this$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient > iIntValue || iIntValue > iM6027Int$arg0$callrangeTo$$this$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient) ? false : z) {
                            }
                        }
                    }
                }
                z2 = z;
                local = z2;
                if (local) {
                    int iM6010Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient2 = LiveLiterals$CarControlClientKt.INSTANCE.m6010Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient();
                    if (port <= LiveLiterals$CarControlClientKt.INSTANCE.m6026Int$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient()) {
                        z3 = false;
                    } else {
                        z3 = false;
                    }
                    if (z3) {
                        if (expectedChipId == null) {
                        }
                        final long current2 = this.generation;
                        final Ref.ObjectRef<Long> identityToken2 = new Ref.ObjectRef();
                        this.sentAt = invoke().longValue();
                        setValue(new CarConnectionState(LiveLiterals$CarControlClientKt.INSTANCE.m6089String$arg0$call$init$$arg0$call$setvalue$$funconnect$classCarControlClient(), false, LiveLiterals$CarControlClientKt.INSTANCE.m5992Boolean$arg2$call$init$$arg0$call$setvalue$$funconnect$classCarControlClient(), 0, 0, 26));
                        OkHttpClient.Builder builderNewBuilder2 = httpClient.newBuilder();
                        SocketFactory socketFactory2 = httpClient.socketFactory();
                        Intrinsics.checkNotNullExpressionValue(socketFactory2, "httpClient.socketFactory()");
                        OkHttpClient transport2 = builderNewBuilder2.socketFactory(new ControlSocketFactory(socketFactory2)).build();
                        if (expectedChipId == null) {
                            strM6107String$branch$if$valpath$funconnect$classCarControlClient = LiveLiterals$CarControlClientKt.INSTANCE.m6107String$branch$if$valpath$funconnect$classCarControlClient();
                        } else {
                            strM6107String$branch$if$valpath$funconnect$classCarControlClient = "/control/identity";
                        }
                        String path2 = strM6107String$branch$if$valpath$funconnect$classCarControlClient;
                        this.socket = transport2.newWebSocket(new Request.Builder().url(LiveLiterals$CarControlClientKt.INSTANCE.m6063String$0$str$arg0$callurl$$this$callbuild$arg0$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + host + LiveLiterals$CarControlClientKt.INSTANCE.m6075String$2$str$arg0$callurl$$this$callbuild$arg0$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + port + path2).build(), new WebSocketListener() { // from class: vea.raceremote.control.CarControlClient.connect.1
                            @Override // okhttp3.WebSocketListener
                            public void onOpen(WebSocket webSocket, Response response) {
                                Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                                Intrinsics.checkNotNullParameter(response, "response");
                                CarControlClient carControlClient = CarControlClient.this;
                                long j = current2;
                                synchronized (carControlClient) {
                                    carControlClient.diagnostics.invoke(LiveLiterals$CarControlClientKt.INSTANCE.m6106String$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonOpen$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                    if (j == carControlClient.generation) {
                                        carControlClient.opened = LiveLiterals$CarControlClientKt.INSTANCE.m5988Boolean$arg0$call$setopened$$branch$if$fun$anonymous$$arg1$callsynchronized$funonOpen$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient();
                                    } else {
                                        webSocket.cancel();
                                    }
                                    Unit unit = Unit.INSTANCE;
                                }
                            }

                            /* JADX WARN: Code duplicated, block: B:58:0x01e9 A[Catch: all -> 0x029a, TryCatch #0 {, blocks: (B:5:0x001a, B:8:0x0024, B:10:0x0028, B:12:0x0078, B:14:0x0084, B:15:0x008e, B:17:0x009a, B:18:0x00a4, B:20:0x00b0, B:22:0x00c6, B:24:0x00d0, B:36:0x0158, B:37:0x0163, B:39:0x0171, B:41:0x0179, B:43:0x0187, B:45:0x0193, B:47:0x019f, B:49:0x01bd, B:51:0x01ca, B:57:0x01de, B:54:0x01d5, B:58:0x01e9, B:59:0x0214, B:61:0x021c, B:63:0x0228, B:66:0x0233, B:68:0x023b, B:70:0x0259, B:71:0x0263, B:72:0x028c, B:26:0x00df, B:28:0x0106, B:30:0x0110, B:32:0x0120, B:34:0x012a, B:74:0x0296), top: B:80:0x001a }] */
                            /* JADX WARN: Code duplicated, block: B:72:0x028c A[Catch: all -> 0x029a, TryCatch #0 {, blocks: (B:5:0x001a, B:8:0x0024, B:10:0x0028, B:12:0x0078, B:14:0x0084, B:15:0x008e, B:17:0x009a, B:18:0x00a4, B:20:0x00b0, B:22:0x00c6, B:24:0x00d0, B:36:0x0158, B:37:0x0163, B:39:0x0171, B:41:0x0179, B:43:0x0187, B:45:0x0193, B:47:0x019f, B:49:0x01bd, B:51:0x01ca, B:57:0x01de, B:54:0x01d5, B:58:0x01e9, B:59:0x0214, B:61:0x021c, B:63:0x0228, B:66:0x0233, B:68:0x023b, B:70:0x0259, B:71:0x0263, B:72:0x028c, B:26:0x00df, B:28:0x0106, B:30:0x0110, B:32:0x0120, B:34:0x012a, B:74:0x0296), top: B:80:0x001a }] */
                            /* JADX WARN: Type inference failed for: r0v32, types: [T, java.lang.Long] */
                            @Override // okhttp3.WebSocketListener
                            public void onMessage(WebSocket webSocket, ByteString bytes) {
                                Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                                Intrinsics.checkNotNullParameter(bytes, "bytes");
                                CarControlClient carControlClient = CarControlClient.this;
                                long j = current2;
                                Long l = expectedChipId;
                                Ref.ObjectRef<Long> objectRef = identityToken2;
                                synchronized (carControlClient) {
                                    if (j == carControlClient.generation) {
                                        if (l != null && objectRef.element == null) {
                                            carControlClient.diagnostics.invoke(LiveLiterals$CarControlClientKt.INSTANCE.m6058String$0$str$arg0$callinvoke$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + bytes.size());
                                            IdentityPacket identityPacket = IdentityPacket.INSTANCE;
                                            byte[] byteArray = bytes.toByteArray();
                                            Intrinsics.checkNotNullExpressionValue(byteArray, "bytes.toByteArray()");
                                            CarIdentity identity = identityPacket.decode(byteArray);
                                            if (((Number) carControlClient.clockMs.invoke()).longValue() - carControlClient.sentAt >= LiveLiterals$CarControlClientKt.INSTANCE.m6017Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient()) {
                                                carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6101String$arg0$calldisconnect$branch$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                            } else if (identity == null) {
                                                carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6102String$arg0$calldisconnect$branch1$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                            } else if (identity.getChipId() != l.longValue()) {
                                                carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6103String$arg0$calldisconnect$branch2$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                            } else {
                                                objectRef.element = Long.valueOf(identity.getToken());
                                            }
                                        } else {
                                            ControlPacket.Companion companion = ControlPacket.INSTANCE;
                                            byte[] byteArray2 = bytes.toByteArray();
                                            Intrinsics.checkNotNullExpressionValue(byteArray2, "bytes.toByteArray()");
                                            ControlPacket p = companion.decode(byteArray2);
                                            if (carControlClient.traceAllCommands || carControlClient.token == 0 || carControlClient.sequence <= LiveLiterals$CarControlClientKt.INSTANCE.m6019Int$$this$calltoLong$arg1$calllessOrEqual$else$cond$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient()) {
                                                carControlClient.diagnostics.invoke(LiveLiterals$CarControlClientKt.INSTANCE.m6060String$0$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + bytes.size() + LiveLiterals$CarControlClientKt.INSTANCE.m6073String$2$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + (p != null ? Integer.valueOf(p.getKind()) : null) + LiveLiterals$CarControlClientKt.INSTANCE.m6079String$4$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + (p != null ? Long.valueOf(p.getSequence()) : null) + LiveLiterals$CarControlClientKt.INSTANCE.m6082String$6$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + (((Number) carControlClient.clockMs.invoke()).longValue() - carControlClient.sentAt));
                                            }
                                            if (p == null) {
                                                carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6100String$arg0$calldisconnect$branch$if3$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                            } else if (carControlClient.token == LiveLiterals$CarControlClientKt.INSTANCE.m6051Long$arg1$callEQEQ$cond$cond$cond$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() && p.getKind() == 128 && p.getSequence() == LiveLiterals$CarControlClientKt.INSTANCE.m6050Long$arg1$callEQEQ$branch$cond$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() && p.getThrottle() == LiveLiterals$CarControlClientKt.INSTANCE.m6035Int$arg1$callEQEQ$branch$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() && p.getSteering() == LiveLiterals$CarControlClientKt.INSTANCE.m6036Int$arg1$callEQEQ$branch$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient()) {
                                                if (((Number) carControlClient.clockMs.invoke()).longValue() - carControlClient.sentAt >= LiveLiterals$CarControlClientKt.INSTANCE.m6014Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient()) {
                                                    carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6090String$arg0$calldisconnect$branch$if$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                                } else if (l != null) {
                                                    long token = p.getToken();
                                                    Long l2 = objectRef.element;
                                                    if (l2 != null && token == l2.longValue()) {
                                                        carControlClient.token = p.getToken();
                                                        carControlClient.sequence = LiveLiterals$CarControlClientKt.INSTANCE.m6044Long$arg0$call$setsequence$$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient();
                                                        carControlClient.send(new ControlPacket(1, carControlClient.token, carControlClient.sequence, 0, 0, 24, null));
                                                    } else {
                                                        carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6096String$arg0$calldisconnect$branch$if1$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                                    }
                                                } else {
                                                    carControlClient.token = p.getToken();
                                                    carControlClient.sequence = LiveLiterals$CarControlClientKt.INSTANCE.m6044Long$arg0$call$setsequence$$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient();
                                                    carControlClient.send(new ControlPacket(1, carControlClient.token, carControlClient.sequence, 0, 0, 24, null));
                                                }
                                            } else if (p.getKind() == 129 && p.getToken() == carControlClient.token) {
                                                long sequence = p.getSequence();
                                                Long l3 = carControlClient.pending;
                                                if (l3 == null || sequence != l3.longValue()) {
                                                    carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6104String$arg0$calldisconnect$else$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                                } else if (((Number) carControlClient.clockMs.invoke()).longValue() - carControlClient.sentAt >= LiveLiterals$CarControlClientKt.INSTANCE.m6015Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient()) {
                                                    carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6091String$arg0$calldisconnect$branch$if$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                                } else {
                                                    carControlClient.pending = null;
                                                    carControlClient.mutableState.setValue(new CarConnectionState(LiveLiterals$CarControlClientKt.INSTANCE.m6088String$arg0$call$init$$arg0$call$setvalue$$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient(), LiveLiterals$CarControlClientKt.INSTANCE.m5990Boolean$arg1$call$init$$arg0$call$setvalue$$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient(), false, p.getThrottle(), p.getSteering(), 4));
                                                }
                                            } else {
                                                carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6104String$arg0$calldisconnect$else$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                            }
                                        }
                                    }
                                    Unit unit = Unit.INSTANCE;
                                }
                            }

                            @Override // okhttp3.WebSocketListener
                            public void onMessage(WebSocket webSocket, String text) {
                                Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                                Intrinsics.checkNotNullParameter(text, "text");
                                CarControlClient carControlClient = CarControlClient.this;
                                long j = current2;
                                synchronized (carControlClient) {
                                    if (j == carControlClient.generation) {
                                        carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6094String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonMessage1$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                    }
                                    Unit unit = Unit.INSTANCE;
                                }
                            }

                            @Override // okhttp3.WebSocketListener
                            public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                                Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                                Intrinsics.checkNotNullParameter(t, "t");
                                CarControlClient carControlClient = CarControlClient.this;
                                long j = current2;
                                synchronized (carControlClient) {
                                    carControlClient.diagnostics.invoke(LiveLiterals$CarControlClientKt.INSTANCE.m6061String$0$str$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + t.getClass().getSimpleName() + LiveLiterals$CarControlClientKt.INSTANCE.m6074String$2$str$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + t.getMessage());
                                    if (j == carControlClient.generation) {
                                        carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6093String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                    }
                                    Unit unit = Unit.INSTANCE;
                                }
                            }

                            @Override // okhttp3.WebSocketListener
                            public void onClosing(WebSocket webSocket, int code, String reason) {
                                Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                                Intrinsics.checkNotNullParameter(reason, "reason");
                                CarControlClient carControlClient = CarControlClient.this;
                                long j = current2;
                                synchronized (carControlClient) {
                                    if (carControlClient.traceAllCommands && j == carControlClient.generation) {
                                        carControlClient.diagnostics.invoke(LiveLiterals$CarControlClientKt.INSTANCE.m6056String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg1$callsynchronized$funonClosing$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + code);
                                    }
                                    if (j == carControlClient.generation) {
                                        carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6097String$arg0$calldisconnect$branch$if1$fun$anonymous$$arg1$callsynchronized$funonClosing$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                    }
                                    Unit unit = Unit.INSTANCE;
                                }
                            }

                            @Override // okhttp3.WebSocketListener
                            public void onClosed(WebSocket webSocket, int code, String reason) {
                                Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                                Intrinsics.checkNotNullParameter(reason, "reason");
                                CarControlClient carControlClient = CarControlClient.this;
                                long j = current2;
                                synchronized (carControlClient) {
                                    if (j == carControlClient.generation) {
                                        carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6092String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonClosed$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                    }
                                    Unit unit = Unit.INSTANCE;
                                }
                            }
                        });
                        return;
                    }
                }
                setValue(new CarConnectionState(LiveLiterals$CarControlClientKt.INSTANCE.m6086String$arg0$call$init$$arg0$call$setvalue$$branch$if$funconnect$classCarControlClient(), false, false, 0, 0, 30));
            }
            z = true;
        } else {
            z = true;
        }
        z2 = false;
        local = z2;
        if (local) {
            int iM6010Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient3 = LiveLiterals$CarControlClientKt.INSTANCE.m6010Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient();
            if (port <= LiveLiterals$CarControlClientKt.INSTANCE.m6026Int$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient()) {
                z3 = false;
            } else {
                z3 = false;
            }
            if (z3) {
                if (expectedChipId == null) {
                }
                final long current3 = this.generation;
                final Ref.ObjectRef<Long> identityToken3 = new Ref.ObjectRef();
                this.sentAt = invoke().longValue();
                setValue(new CarConnectionState(LiveLiterals$CarControlClientKt.INSTANCE.m6089String$arg0$call$init$$arg0$call$setvalue$$funconnect$classCarControlClient(), false, LiveLiterals$CarControlClientKt.INSTANCE.m5992Boolean$arg2$call$init$$arg0$call$setvalue$$funconnect$classCarControlClient(), 0, 0, 26));
                OkHttpClient.Builder builderNewBuilder3 = httpClient.newBuilder();
                SocketFactory socketFactory3 = httpClient.socketFactory();
                Intrinsics.checkNotNullExpressionValue(socketFactory3, "httpClient.socketFactory()");
                OkHttpClient transport3 = builderNewBuilder3.socketFactory(new ControlSocketFactory(socketFactory3)).build();
                if (expectedChipId == null) {
                    strM6107String$branch$if$valpath$funconnect$classCarControlClient = LiveLiterals$CarControlClientKt.INSTANCE.m6107String$branch$if$valpath$funconnect$classCarControlClient();
                } else {
                    strM6107String$branch$if$valpath$funconnect$classCarControlClient = "/control/identity";
                }
                String path3 = strM6107String$branch$if$valpath$funconnect$classCarControlClient;
                this.socket = transport3.newWebSocket(new Request.Builder().url(LiveLiterals$CarControlClientKt.INSTANCE.m6063String$0$str$arg0$callurl$$this$callbuild$arg0$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + host + LiveLiterals$CarControlClientKt.INSTANCE.m6075String$2$str$arg0$callurl$$this$callbuild$arg0$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + port + path3).build(), new WebSocketListener() { // from class: vea.raceremote.control.CarControlClient.connect.1
                    @Override // okhttp3.WebSocketListener
                    public void onOpen(WebSocket webSocket, Response response) {
                        Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                        Intrinsics.checkNotNullParameter(response, "response");
                        CarControlClient carControlClient = CarControlClient.this;
                        long j = current3;
                        synchronized (carControlClient) {
                            carControlClient.diagnostics.invoke(LiveLiterals$CarControlClientKt.INSTANCE.m6106String$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonOpen$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                            if (j == carControlClient.generation) {
                                carControlClient.opened = LiveLiterals$CarControlClientKt.INSTANCE.m5988Boolean$arg0$call$setopened$$branch$if$fun$anonymous$$arg1$callsynchronized$funonOpen$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient();
                            } else {
                                webSocket.cancel();
                            }
                            Unit unit = Unit.INSTANCE;
                        }
                    }

                    /* JADX WARN: Code duplicated, block: B:58:0x01e9 A[Catch: all -> 0x029a, TryCatch #0 {, blocks: (B:5:0x001a, B:8:0x0024, B:10:0x0028, B:12:0x0078, B:14:0x0084, B:15:0x008e, B:17:0x009a, B:18:0x00a4, B:20:0x00b0, B:22:0x00c6, B:24:0x00d0, B:36:0x0158, B:37:0x0163, B:39:0x0171, B:41:0x0179, B:43:0x0187, B:45:0x0193, B:47:0x019f, B:49:0x01bd, B:51:0x01ca, B:57:0x01de, B:54:0x01d5, B:58:0x01e9, B:59:0x0214, B:61:0x021c, B:63:0x0228, B:66:0x0233, B:68:0x023b, B:70:0x0259, B:71:0x0263, B:72:0x028c, B:26:0x00df, B:28:0x0106, B:30:0x0110, B:32:0x0120, B:34:0x012a, B:74:0x0296), top: B:80:0x001a }] */
                    /* JADX WARN: Code duplicated, block: B:72:0x028c A[Catch: all -> 0x029a, TryCatch #0 {, blocks: (B:5:0x001a, B:8:0x0024, B:10:0x0028, B:12:0x0078, B:14:0x0084, B:15:0x008e, B:17:0x009a, B:18:0x00a4, B:20:0x00b0, B:22:0x00c6, B:24:0x00d0, B:36:0x0158, B:37:0x0163, B:39:0x0171, B:41:0x0179, B:43:0x0187, B:45:0x0193, B:47:0x019f, B:49:0x01bd, B:51:0x01ca, B:57:0x01de, B:54:0x01d5, B:58:0x01e9, B:59:0x0214, B:61:0x021c, B:63:0x0228, B:66:0x0233, B:68:0x023b, B:70:0x0259, B:71:0x0263, B:72:0x028c, B:26:0x00df, B:28:0x0106, B:30:0x0110, B:32:0x0120, B:34:0x012a, B:74:0x0296), top: B:80:0x001a }] */
                    /* JADX WARN: Type inference failed for: r0v32, types: [T, java.lang.Long] */
                    @Override // okhttp3.WebSocketListener
                    public void onMessage(WebSocket webSocket, ByteString bytes) {
                        Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                        Intrinsics.checkNotNullParameter(bytes, "bytes");
                        CarControlClient carControlClient = CarControlClient.this;
                        long j = current3;
                        Long l = expectedChipId;
                        Ref.ObjectRef<Long> objectRef = identityToken3;
                        synchronized (carControlClient) {
                            if (j == carControlClient.generation) {
                                if (l != null && objectRef.element == null) {
                                    carControlClient.diagnostics.invoke(LiveLiterals$CarControlClientKt.INSTANCE.m6058String$0$str$arg0$callinvoke$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + bytes.size());
                                    IdentityPacket identityPacket = IdentityPacket.INSTANCE;
                                    byte[] byteArray = bytes.toByteArray();
                                    Intrinsics.checkNotNullExpressionValue(byteArray, "bytes.toByteArray()");
                                    CarIdentity identity = identityPacket.decode(byteArray);
                                    if (((Number) carControlClient.clockMs.invoke()).longValue() - carControlClient.sentAt >= LiveLiterals$CarControlClientKt.INSTANCE.m6017Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient()) {
                                        carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6101String$arg0$calldisconnect$branch$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                    } else if (identity == null) {
                                        carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6102String$arg0$calldisconnect$branch1$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                    } else if (identity.getChipId() != l.longValue()) {
                                        carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6103String$arg0$calldisconnect$branch2$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                    } else {
                                        objectRef.element = Long.valueOf(identity.getToken());
                                    }
                                } else {
                                    ControlPacket.Companion companion = ControlPacket.INSTANCE;
                                    byte[] byteArray2 = bytes.toByteArray();
                                    Intrinsics.checkNotNullExpressionValue(byteArray2, "bytes.toByteArray()");
                                    ControlPacket p = companion.decode(byteArray2);
                                    if (carControlClient.traceAllCommands || carControlClient.token == 0 || carControlClient.sequence <= LiveLiterals$CarControlClientKt.INSTANCE.m6019Int$$this$calltoLong$arg1$calllessOrEqual$else$cond$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient()) {
                                        carControlClient.diagnostics.invoke(LiveLiterals$CarControlClientKt.INSTANCE.m6060String$0$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + bytes.size() + LiveLiterals$CarControlClientKt.INSTANCE.m6073String$2$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + (p != null ? Integer.valueOf(p.getKind()) : null) + LiveLiterals$CarControlClientKt.INSTANCE.m6079String$4$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + (p != null ? Long.valueOf(p.getSequence()) : null) + LiveLiterals$CarControlClientKt.INSTANCE.m6082String$6$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + (((Number) carControlClient.clockMs.invoke()).longValue() - carControlClient.sentAt));
                                    }
                                    if (p == null) {
                                        carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6100String$arg0$calldisconnect$branch$if3$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                    } else if (carControlClient.token == LiveLiterals$CarControlClientKt.INSTANCE.m6051Long$arg1$callEQEQ$cond$cond$cond$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() && p.getKind() == 128 && p.getSequence() == LiveLiterals$CarControlClientKt.INSTANCE.m6050Long$arg1$callEQEQ$branch$cond$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() && p.getThrottle() == LiveLiterals$CarControlClientKt.INSTANCE.m6035Int$arg1$callEQEQ$branch$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() && p.getSteering() == LiveLiterals$CarControlClientKt.INSTANCE.m6036Int$arg1$callEQEQ$branch$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient()) {
                                        if (((Number) carControlClient.clockMs.invoke()).longValue() - carControlClient.sentAt >= LiveLiterals$CarControlClientKt.INSTANCE.m6014Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient()) {
                                            carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6090String$arg0$calldisconnect$branch$if$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                        } else if (l != null) {
                                            long token = p.getToken();
                                            Long l2 = objectRef.element;
                                            if (l2 != null && token == l2.longValue()) {
                                                carControlClient.token = p.getToken();
                                                carControlClient.sequence = LiveLiterals$CarControlClientKt.INSTANCE.m6044Long$arg0$call$setsequence$$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient();
                                                carControlClient.send(new ControlPacket(1, carControlClient.token, carControlClient.sequence, 0, 0, 24, null));
                                            } else {
                                                carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6096String$arg0$calldisconnect$branch$if1$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                            }
                                        } else {
                                            carControlClient.token = p.getToken();
                                            carControlClient.sequence = LiveLiterals$CarControlClientKt.INSTANCE.m6044Long$arg0$call$setsequence$$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient();
                                            carControlClient.send(new ControlPacket(1, carControlClient.token, carControlClient.sequence, 0, 0, 24, null));
                                        }
                                    } else if (p.getKind() == 129 && p.getToken() == carControlClient.token) {
                                        long sequence = p.getSequence();
                                        Long l3 = carControlClient.pending;
                                        if (l3 == null || sequence != l3.longValue()) {
                                            carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6104String$arg0$calldisconnect$else$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                        } else if (((Number) carControlClient.clockMs.invoke()).longValue() - carControlClient.sentAt >= LiveLiterals$CarControlClientKt.INSTANCE.m6015Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient()) {
                                            carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6091String$arg0$calldisconnect$branch$if$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                        } else {
                                            carControlClient.pending = null;
                                            carControlClient.mutableState.setValue(new CarConnectionState(LiveLiterals$CarControlClientKt.INSTANCE.m6088String$arg0$call$init$$arg0$call$setvalue$$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient(), LiveLiterals$CarControlClientKt.INSTANCE.m5990Boolean$arg1$call$init$$arg0$call$setvalue$$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient(), false, p.getThrottle(), p.getSteering(), 4));
                                        }
                                    } else {
                                        carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6104String$arg0$calldisconnect$else$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                                    }
                                }
                            }
                            Unit unit = Unit.INSTANCE;
                        }
                    }

                    @Override // okhttp3.WebSocketListener
                    public void onMessage(WebSocket webSocket, String text) {
                        Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                        Intrinsics.checkNotNullParameter(text, "text");
                        CarControlClient carControlClient = CarControlClient.this;
                        long j = current3;
                        synchronized (carControlClient) {
                            if (j == carControlClient.generation) {
                                carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6094String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonMessage1$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                            }
                            Unit unit = Unit.INSTANCE;
                        }
                    }

                    @Override // okhttp3.WebSocketListener
                    public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                        Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                        Intrinsics.checkNotNullParameter(t, "t");
                        CarControlClient carControlClient = CarControlClient.this;
                        long j = current3;
                        synchronized (carControlClient) {
                            carControlClient.diagnostics.invoke(LiveLiterals$CarControlClientKt.INSTANCE.m6061String$0$str$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + t.getClass().getSimpleName() + LiveLiterals$CarControlClientKt.INSTANCE.m6074String$2$str$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + t.getMessage());
                            if (j == carControlClient.generation) {
                                carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6093String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                            }
                            Unit unit = Unit.INSTANCE;
                        }
                    }

                    @Override // okhttp3.WebSocketListener
                    public void onClosing(WebSocket webSocket, int code, String reason) {
                        Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                        Intrinsics.checkNotNullParameter(reason, "reason");
                        CarControlClient carControlClient = CarControlClient.this;
                        long j = current3;
                        synchronized (carControlClient) {
                            if (carControlClient.traceAllCommands && j == carControlClient.generation) {
                                carControlClient.diagnostics.invoke(LiveLiterals$CarControlClientKt.INSTANCE.m6056String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg1$callsynchronized$funonClosing$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() + code);
                            }
                            if (j == carControlClient.generation) {
                                carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6097String$arg0$calldisconnect$branch$if1$fun$anonymous$$arg1$callsynchronized$funonClosing$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                            }
                            Unit unit = Unit.INSTANCE;
                        }
                    }

                    @Override // okhttp3.WebSocketListener
                    public void onClosed(WebSocket webSocket, int code, String reason) {
                        Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                        Intrinsics.checkNotNullParameter(reason, "reason");
                        CarControlClient carControlClient = CarControlClient.this;
                        long j = current3;
                        synchronized (carControlClient) {
                            if (j == carControlClient.generation) {
                                carControlClient.disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6092String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonClosed$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient());
                            }
                            Unit unit = Unit.INSTANCE;
                        }
                    }
                });
                return;
            }
        }
        setValue(new CarConnectionState(LiveLiterals$CarControlClientKt.INSTANCE.m6086String$arg0$call$init$$arg0$call$setvalue$$branch$if$funconnect$classCarControlClient(), false, false, 0, 0, 30));
    }

    public final synchronized void setInput(float throttle, float steering) {
        boolean z = true;
        if ((Float.isInfinite(throttle) || Float.isNaN(throttle)) ? false : true) {
            if (Float.isInfinite(steering) || Float.isNaN(steering)) {
                z = false;
            }
            if (z) {
                if (getValue().getConnected()) {
                    this.throttle = (int) (RangesKt.coerceIn(throttle, LiveLiterals$CarControlClientKt.INSTANCE.m6006Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient(), LiveLiterals$CarControlClientKt.INSTANCE.m6008Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient()) * LiveLiterals$CarControlClientKt.INSTANCE.m6034Int$arg0$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient());
                    this.steering = (int) (RangesKt.coerceIn(steering, LiveLiterals$CarControlClientKt.INSTANCE.m6005Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient(), LiveLiterals$CarControlClientKt.INSTANCE.m6007Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient()) * LiveLiterals$CarControlClientKt.INSTANCE.m6033Int$arg0$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient());
                    return;
                }
                return;
            }
        }
        disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6095String$arg0$calldisconnect$branch$if$funsetInput$classCarControlClient());
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code duplicated, block: B:15:0x008e  */
    public final void send(ControlPacket p) {
        boolean z;
        if (p.getKind() == 1) {
            invoke(LiveLiterals$CarControlClientKt.INSTANCE.m6105String$arg0$callinvoke$branch$if$funsend$classCarControlClient());
        }
        if (this.traceAllCommands || p.getSequence() <= LiveLiterals$CarControlClientKt.INSTANCE.m6018Int$$this$calltoLong$arg1$calllessOrEqual$else$cond$if1$funsend$classCarControlClient()) {
            invoke(LiveLiterals$CarControlClientKt.INSTANCE.m6059String$0$str$arg0$callinvoke$branch$if1$funsend$classCarControlClient() + p.getKind() + LiveLiterals$CarControlClientKt.INSTANCE.m6072String$2$str$arg0$callinvoke$branch$if1$funsend$classCarControlClient() + p.getSequence());
        }
        this.pending = Long.valueOf(p.getSequence());
        this.sentAt = invoke().longValue();
        WebSocket webSocket = this.socket;
        if (webSocket != null) {
            byte[] bArrEncode = p.encode();
            z = webSocket.send(ByteString.of(Arrays.copyOf(bArrEncode, bArrEncode.length))) == LiveLiterals$CarControlClientKt.INSTANCE.m5991Boolean$arg1$callEQEQ$$this$callnot$cond$if2$funsend$classCarControlClient();
        }
        if (!z) {
            disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6098String$arg0$calldisconnect$branch$if2$funsend$classCarControlClient());
        }
    }

    private final void tick() {
        Long l;
        if (this.socket == null) {
            return;
        }
        long now = invoke().longValue();
        if (this.traceAllCommands && (l = this.lastTickAt) != null) {
            long it = l.longValue();
            if (now - it >= LiveLiterals$CarControlClientKt.INSTANCE.m6016Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient()) {
                Function1<String, Unit> function1 = this.diagnostics;
                StringBuilder sbAppend = new StringBuilder().append(LiveLiterals$CarControlClientKt.INSTANCE.m6055String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient()).append(now - it).append(LiveLiterals$CarControlClientKt.INSTANCE.m6070String$2$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient()).append(this.pending).append(LiveLiterals$CarControlClientKt.INSTANCE.m6077String$4$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient());
                WebSocket webSocket = this.socket;
                function1.invoke(sbAppend.append(webSocket != null ? Long.valueOf(webSocket.queueSize()) : null).toString());
            }
        }
        this.lastTickAt = Long.valueOf(now);
        long elapsed = now - this.sentAt;
        if ((this.pending != null && elapsed >= 200) || (this.token == LiveLiterals$CarControlClientKt.INSTANCE.m6052Long$arg1$callEQEQ$cond$else$cond$if2$funtick$classCarControlClient() && elapsed >= LiveLiterals$CarControlClientKt.INSTANCE.m6013Int$$this$calltoLong$arg1$callgreaterOrEqual$branch$else$cond$if2$funtick$classCarControlClient())) {
            disconnect(LiveLiterals$CarControlClientKt.INSTANCE.m6099String$arg0$calldisconnect$branch$if2$funtick$classCarControlClient());
        } else if (this.opened && getValue().getConnected() && this.pending == null) {
            this.sequence = (this.sequence + ((long) LiveLiterals$CarControlClientKt.INSTANCE.m6025Int$arg0$callplus$$this$calland$arg0$call$setsequence$$branch$if3$funtick$classCarControlClient())) & LiveLiterals$CarControlClientKt.INSTANCE.m6047Long$arg0$calland$arg0$call$setsequence$$branch$if3$funtick$classCarControlClient();
            send(new ControlPacket(2, this.token, this.sequence, this.throttle, this.steering));
        }
    }

    public static /* synthetic */ void disconnect$default(CarControlClient carControlClient, String str, int i, Object obj) {
        if ((i & 1) != 0) {
            str = LiveLiterals$CarControlClientKt.INSTANCE.m6109String$parammessage$fundisconnect$classCarControlClient();
        }
        carControlClient.disconnect(str);
    }

    public final synchronized void disconnect(String message) {
        Intrinsics.checkNotNullParameter(message, "message");
        if (this.traceAllCommands && this.socket != null) {
            Function1<String, Unit> function1 = this.diagnostics;
            StringBuilder sbAppend = new StringBuilder().append(LiveLiterals$CarControlClientKt.INSTANCE.m6057String$0$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient()).append(this.sequence).append(LiveLiterals$CarControlClientKt.INSTANCE.m6071String$2$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient()).append(this.pending).append(LiveLiterals$CarControlClientKt.INSTANCE.m6078String$4$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient()).append(invoke().longValue() - this.sentAt).append(LiveLiterals$CarControlClientKt.INSTANCE.m6081String$6$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient());
            WebSocket webSocket = this.socket;
            function1.invoke(sbAppend.append(webSocket != null ? Long.valueOf(webSocket.queueSize()) : null).toString());
        }
        invoke(LiveLiterals$CarControlClientKt.INSTANCE.m6062String$0$str$arg0$callinvoke$fundisconnect$classCarControlClient() + message);
        this.generation++;
        WebSocket old = this.socket;
        this.socket = null;
        if (this.token != LiveLiterals$CarControlClientKt.INSTANCE.m6049Long$arg1$callEQEQ$$this$callnot$cond$if1$fundisconnect$classCarControlClient() && old != null) {
            byte[] bArrEncode = new ControlPacket(3, this.token, this.sequence, 0, 0, 24, null).encode();
            old.send(ByteString.of(Arrays.copyOf(bArrEncode, bArrEncode.length)));
        }
        if (old != null) {
            old.cancel();
        }
        this.token = LiveLiterals$CarControlClientKt.INSTANCE.m6046Long$arg0$call$settoken$$fundisconnect$classCarControlClient();
        this.sequence = LiveLiterals$CarControlClientKt.INSTANCE.m6045Long$arg0$call$setsequence$$fundisconnect$classCarControlClient();
        this.pending = null;
        this.throttle = LiveLiterals$CarControlClientKt.INSTANCE.m6021Int$arg0$call$setthrottle$$fundisconnect$classCarControlClient();
        this.steering = LiveLiterals$CarControlClientKt.INSTANCE.m6020Int$arg0$call$setsteering$$fundisconnect$classCarControlClient();
        this.opened = LiveLiterals$CarControlClientKt.INSTANCE.m5989Boolean$arg0$call$setopened$$fundisconnect$classCarControlClient();
        this.lastTickAt = null;
        setValue(new CarConnectionState(message, false, false, 0, 0, 30));
    }

    public final synchronized void close() {
        disconnect$default(this, null, 1, null);
        this.timer.shutdownNow();
    }
}
