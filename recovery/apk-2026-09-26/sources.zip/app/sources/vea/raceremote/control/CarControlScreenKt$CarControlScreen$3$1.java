package vea.raceremote.control;

import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.State;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;

/* JADX INFO: compiled from: CarControlScreen.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@DebugMetadata(c = "vea.raceremote.control.CarControlScreenKt$CarControlScreen$3$1", f = "CarControlScreen.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
final class CarControlScreenKt$CarControlScreen$3$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    final /* synthetic */ State<CarConnectionState> $state$delegate;
    final /* synthetic */ MutableState<Float> $steering$delegate;
    final /* synthetic */ MutableState<Float> $throttle$delegate;
    int label;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    CarControlScreenKt$CarControlScreen$3$1(State<CarConnectionState> state, MutableState<Float> mutableState, MutableState<Float> mutableState2, Continuation<? super CarControlScreenKt$CarControlScreen$3$1> continuation) {
        super(2, continuation);
        this.$state$delegate = state;
        this.$throttle$delegate = mutableState;
        this.$steering$delegate = mutableState2;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new CarControlScreenKt$CarControlScreen$3$1(this.$state$delegate, this.$throttle$delegate, this.$steering$delegate, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
        return ((CarControlScreenKt$CarControlScreen$3$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object invokeSuspend(Object obj) {
        IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch (this.label) {
            case 0:
                ResultKt.throwOnFailure(obj);
                if (!CarControlScreenKt.CarControlScreen$lambda$1(this.$state$delegate).getConnected()) {
                    CarControlScreenKt.CarControlScreen$lambda$12(this.$throttle$delegate, LiveLiterals$CarControlScreenKt.INSTANCE.m6181Float$arg0$call$setthrottle$$branch$if$fun$anonymous$$arg1$callLaunchedEffect1$funCarControlScreen());
                    CarControlScreenKt.CarControlScreen$lambda$15(this.$steering$delegate, LiveLiterals$CarControlScreenKt.INSTANCE.m6173Float$arg0$call$setsteering$$branch$if$fun$anonymous$$arg1$callLaunchedEffect1$funCarControlScreen());
                }
                return Unit.INSTANCE;
            default:
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }
}
