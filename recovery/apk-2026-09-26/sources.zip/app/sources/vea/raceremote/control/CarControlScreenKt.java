package vea.raceremote.control;

import android.app.Activity;
import android.content.Context;
import android.net.wifi.WifiManager;
import android.view.Window;
import androidx.compose.runtime.DisposableEffectResult;
import androidx.compose.runtime.DisposableEffectScope;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.State;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleOwner;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlinx.coroutines.CoroutineScope;
import okhttp3.OkHttpClient;

/* JADX INFO: compiled from: CarControlScreen.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000&\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\u001aD\u0010\u0000\u001a\u00020\u00012+\b\u0002\u0010\u0002\u001a%\u0012\u0004\u0012\u00020\u0004\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00010\u0005\u0012\u0004\u0012\u00020\u00010\u0003¢\u0006\u0002\b\u00072\b\b\u0002\u0010\b\u001a\u00020\tH\u0007¢\u0006\u0002\u0010\n¨\u0006\u000b"}, d2 = {"CarControlScreen", "", "carPicker", "Lkotlin/Function2;", "", "Lkotlin/Function1;", "Lvea/raceremote/control/DiscoveredCar;", "Landroidx/compose/runtime/Composable;", "statusPort", "", "(Lkotlin/jvm/functions/Function4;ILandroidx/compose/runtime/Composer;II)V", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class CarControlScreenKt {
    /* JADX WARN: Code duplicated, block: B:168:0x0c8f  */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$PrimitiveArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ProcessVariables
        jadx.core.utils.exceptions.JadxRuntimeException: Method arg registers not loaded: vea.raceremote.control.CarControlConnection.<init>(kotlin.jvm.functions.Function3, kotlin.jvm.functions.Function1, int, kotlin.jvm.internal.DefaultConstructorMarker):void, class status: GENERATED_AND_UNLOADED
        	at jadx.core.dex.nodes.MethodNode.getArgRegs(MethodNode.java:309)
        	at jadx.core.dex.visitors.regions.variables.ProcessVariables$1.isArgUnused(ProcessVariables.java:146)
        	at jadx.core.dex.visitors.regions.variables.ProcessVariables$1.lambda$isVarUnused$0(ProcessVariables.java:131)
        	at jadx.core.utils.ListUtils.allMatch(ListUtils.java:224)
        	at jadx.core.dex.visitors.regions.variables.ProcessVariables$1.isVarUnused(ProcessVariables.java:131)
        	at jadx.core.dex.visitors.regions.variables.ProcessVariables$1.processBlock(ProcessVariables.java:82)
        	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverseInternal(DepthRegionTraversal.java:93)
        	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverse(DepthRegionTraversal.java:27)
        	at jadx.core.dex.visitors.regions.variables.ProcessVariables.removeUnusedResults(ProcessVariables.java:73)
        	at jadx.core.dex.visitors.regions.variables.ProcessVariables.visit(ProcessVariables.java:48)
        */
    public static final void CarControlScreen(kotlin.jvm.functions.Function4<? super java.lang.Boolean, ? super kotlin.jvm.functions.Function1<? super vea.raceremote.control.DiscoveredCar, kotlin.Unit>, ? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit> r142, int r143, androidx.compose.runtime.Composer r144, final int r145, final int r146) {
        /*
            Method dump skipped, instruction units count: 5158
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: vea.raceremote.control.CarControlScreenKt.CarControlScreen(kotlin.jvm.functions.Function4, int, androidx.compose.runtime.Composer, int, int):void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final CarConnectionState CarControlScreen$lambda$1(State<CarConnectionState> state) {
        Object thisObj$iv = state.getValue();
        return (CarConnectionState) thisObj$iv;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final String CarControlScreen$lambda$2(MutableState<String> mutableState) {
        MutableState<String> $this$getValue$iv = mutableState;
        return $this$getValue$iv.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final int CarControlScreen$lambda$4(MutableState<Integer> mutableState) {
        MutableState<Integer> $this$getValue$iv = mutableState;
        return $this$getValue$iv.getValue().intValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void CarControlScreen$lambda$5(MutableState<Integer> mutableState, int value) {
        mutableState.setValue(Integer.valueOf(value));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Long CarControlScreen$lambda$6(MutableState<Long> mutableState) {
        MutableState<Long> $this$getValue$iv = mutableState;
        return $this$getValue$iv.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final String CarControlScreen$lambda$8(MutableState<String> mutableState) {
        MutableState<String> $this$getValue$iv = mutableState;
        return $this$getValue$iv.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final float CarControlScreen$lambda$11(MutableState<Float> mutableState) {
        MutableState<Float> $this$getValue$iv = mutableState;
        return $this$getValue$iv.getValue().floatValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void CarControlScreen$lambda$12(MutableState<Float> mutableState, float value) {
        mutableState.setValue(Float.valueOf(value));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final float CarControlScreen$lambda$14(MutableState<Float> mutableState) {
        MutableState<Float> $this$getValue$iv = mutableState;
        return $this$getValue$iv.getValue().floatValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void CarControlScreen$lambda$15(MutableState<Float> mutableState, float value) {
        mutableState.setValue(Float.valueOf(value));
    }

    private static final boolean CarControlScreen$lambda$16(MutableState<Boolean> mutableState) {
        MutableState<Boolean> $this$getValue$iv = mutableState;
        return $this$getValue$iv.getValue().booleanValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void CarControlScreen$lambda$17(MutableState<Boolean> mutableState, boolean value) {
        mutableState.setValue(Boolean.valueOf(value));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean CarControlScreen$lambda$19(MutableState<Boolean> mutableState) {
        MutableState<Boolean> $this$getValue$iv = mutableState;
        return $this$getValue$iv.getValue().booleanValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void CarControlScreen$lambda$20(MutableState<Boolean> mutableState, boolean value) {
        mutableState.setValue(Boolean.valueOf(value));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean CarControlScreen$lambda$22(MutableState<Boolean> mutableState) {
        MutableState<Boolean> $this$getValue$iv = mutableState;
        return $this$getValue$iv.getValue().booleanValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void CarControlScreen$lambda$23(MutableState<Boolean> mutableState, boolean value) {
        mutableState.setValue(Boolean.valueOf(value));
    }

    /* JADX INFO: renamed from: vea.raceremote.control.CarControlScreenKt$CarControlScreen$2, reason: invalid class name */
    /* JADX INFO: compiled from: CarControlScreen.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    static final class AnonymousClass2 extends Lambda implements Function1<DisposableEffectScope, DisposableEffectResult> {
        final /* synthetic */ CarControlConnection $client;
        final /* synthetic */ Context $context;
        final /* synthetic */ OkHttpClient $http;
        final /* synthetic */ Lifecycle $lifecycle;
        final /* synthetic */ MutableState<Float> $steering$delegate;
        final /* synthetic */ MutableState<Float> $throttle$delegate;
        final /* synthetic */ WifiManager.WifiLock $wifiLock;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass2(Lifecycle lifecycle, Context context, CarControlConnection carControlConnection, WifiManager.WifiLock wifiLock, MutableState<Float> mutableState, MutableState<Float> mutableState2, OkHttpClient okHttpClient) {
            super(1);
            this.$lifecycle = lifecycle;
            this.$context = context;
            this.$client = carControlConnection;
            this.$wifiLock = wifiLock;
            this.$throttle$delegate = mutableState;
            this.$steering$delegate = mutableState2;
            this.$http = okHttpClient;
        }

        @Override // kotlin.jvm.functions.Function1
        public final DisposableEffectResult invoke(DisposableEffectScope $this$DisposableEffect) {
            Window window;
            Intrinsics.checkNotNullParameter($this$DisposableEffect, "$this$DisposableEffect");
            final CarControlConnection carControlConnection = this.$client;
            final WifiManager.WifiLock wifiLock = this.$wifiLock;
            final MutableState<Float> mutableState = this.$throttle$delegate;
            final MutableState<Float> mutableState2 = this.$steering$delegate;
            final LifecycleEventObserver observer = new LifecycleEventObserver() { // from class: vea.raceremote.control.CarControlScreenKt$CarControlScreen$2$$ExternalSyntheticLambda0
                @Override // androidx.lifecycle.LifecycleEventObserver
                public final void onStateChanged(LifecycleOwner lifecycleOwner, Lifecycle.Event event) {
                    CarControlScreenKt.AnonymousClass2.invoke$lambda$0(carControlConnection, wifiLock, mutableState, mutableState2, lifecycleOwner, event);
                }
            };
            addObserver(observer);
            Context context = this.$context;
            Activity activity = context instanceof Activity ? (Activity) context : null;
            if (activity != null && (window = activity.getWindow()) != null) {
                window.addFlags(128);
            }
            final Lifecycle lifecycle = this.$lifecycle;
            final CarControlConnection carControlConnection2 = this.$client;
            final WifiManager.WifiLock wifiLock2 = this.$wifiLock;
            final OkHttpClient okHttpClient = this.$http;
            final Context context2 = this.$context;
            return new DisposableEffectResult() { // from class: vea.raceremote.control.CarControlScreenKt$CarControlScreen$2$invoke$$inlined$onDispose$1
                @Override // androidx.compose.runtime.DisposableEffectResult
                public void dispose() {
                    Window window2;
                    removeObserver(observer);
                    carControlConnection2.close();
                    if (wifiLock2.isHeld()) {
                        wifiLock2.release();
                    }
                    dispatcher().executorService().shutdown();
                    connectionPool().evictAll();
                    Context context3 = context2;
                    Activity activity2 = context3 instanceof Activity ? (Activity) context3 : null;
                    if (activity2 == null || (window2 = activity2.getWindow()) == null) {
                        return;
                    }
                    window2.clearFlags(128);
                }
            };
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void invoke$lambda$0(CarControlConnection $client, WifiManager.WifiLock $wifiLock, MutableState $throttle$delegate, MutableState $steering$delegate, LifecycleOwner lifecycleOwner, Lifecycle.Event event) {
            Intrinsics.checkNotNullParameter($client, "$client");
            Intrinsics.checkNotNullParameter($throttle$delegate, "$throttle$delegate");
            Intrinsics.checkNotNullParameter($steering$delegate, "$steering$delegate");
            Intrinsics.checkNotNullParameter(lifecycleOwner, "<anonymous parameter 0>");
            Intrinsics.checkNotNullParameter(event, "event");
            if (event == Lifecycle.Event.ON_PAUSE || event == Lifecycle.Event.ON_STOP) {
                CarControlScreenKt.CarControlScreen$lambda$12($throttle$delegate, LiveLiterals$CarControlScreenKt.INSTANCE.m6182Float$arg0$call$setthrottle$$branch$if$fun$anonymous$$valobserver$fun$anonymous$$arg2$callDisposableEffect$funCarControlScreen());
                CarControlScreenKt.CarControlScreen$lambda$15($steering$delegate, LiveLiterals$CarControlScreenKt.INSTANCE.m6174Float$arg0$call$setsteering$$branch$if$fun$anonymous$$valobserver$fun$anonymous$$arg2$callDisposableEffect$funCarControlScreen());
                $client.disconnect(LiveLiterals$CarControlScreenKt.INSTANCE.m6231String$arg0$calldisconnect$branch$if$fun$anonymous$$valobserver$fun$anonymous$$arg2$callDisposableEffect$funCarControlScreen());
                if ($wifiLock.isHeld()) {
                    $wifiLock.release();
                }
            }
        }
    }

    /* JADX INFO: renamed from: vea.raceremote.control.CarControlScreenKt$CarControlScreen$1, reason: invalid class name */
    /* JADX INFO: compiled from: CarControlScreen.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "vea.raceremote.control.CarControlScreenKt$CarControlScreen$1", f = "CarControlScreen.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ State<CarConnectionState> $state$delegate;
        final /* synthetic */ MutableState<Boolean> $videoActive$delegate;
        final /* synthetic */ WifiManager.WifiLock $wifiLock;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(WifiManager.WifiLock wifiLock, State<CarConnectionState> state, MutableState<Boolean> mutableState, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.$wifiLock = wifiLock;
            this.$state$delegate = state;
            this.$videoActive$delegate = mutableState;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new AnonymousClass1(this.$wifiLock, this.$state$delegate, this.$videoActive$delegate, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure(obj);
                    if (CarControlScreenKt.CarControlScreen$lambda$1(this.$state$delegate).getConnected() || CarControlScreenKt.CarControlScreen$lambda$1(this.$state$delegate).getConnecting() || CarControlScreenKt.CarControlScreen$lambda$19(this.$videoActive$delegate)) {
                        if (!this.$wifiLock.isHeld()) {
                            this.$wifiLock.acquire();
                        }
                    } else if (this.$wifiLock.isHeld()) {
                        this.$wifiLock.release();
                    }
                    return Unit.INSTANCE;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }
}
