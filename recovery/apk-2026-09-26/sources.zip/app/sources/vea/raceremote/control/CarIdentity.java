package vea.raceremote.control;

import kotlin.Metadata;

/* JADX INFO: compiled from: IdentityPacket.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0002\u0010\u0005J\t\u0010\t\u001a\u00020\u0003HÆ\u0003J\t\u0010\n\u001a\u00020\u0003HÆ\u0003J\u001d\u0010\u000b\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\f\u001a\u00020\r2\b\u0010\u000e\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u000f\u001a\u00020\u0010HÖ\u0001J\t\u0010\u0011\u001a\u00020\u0012HÖ\u0001R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\u0007¨\u0006\u0013"}, d2 = {"Lvea/raceremote/control/CarIdentity;", "", "token", "", "chipId", "(JJ)V", "getChipId", "()J", "getToken", "component1", "component2", "copy", "equals", "", "other", "hashCode", "", "toString", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final /* data */ class CarIdentity {
    public static final int $stable = LiveLiterals$IdentityPacketKt.INSTANCE.m6532Int$classCarIdentity();
    private final long chipId;
    private final long token;

    public static /* synthetic */ CarIdentity copy$default(CarIdentity carIdentity, long j, long j2, int i, Object obj) {
        if ((i & 1) != 0) {
            j = carIdentity.token;
        }
        if ((i & 2) != 0) {
            j2 = carIdentity.chipId;
        }
        return carIdentity.copy(j, j2);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final long getToken() {
        return this.token;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final long getChipId() {
        return this.chipId;
    }

    public final CarIdentity copy(long token, long chipId) {
        return new CarIdentity(token, chipId);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return LiveLiterals$IdentityPacketKt.INSTANCE.m6518Boolean$branch$when$funequals$classCarIdentity();
        }
        if (!(other instanceof CarIdentity)) {
            return LiveLiterals$IdentityPacketKt.INSTANCE.m6519Boolean$branch$when1$funequals$classCarIdentity();
        }
        CarIdentity carIdentity = (CarIdentity) other;
        if (this.token != carIdentity.token) {
            return LiveLiterals$IdentityPacketKt.INSTANCE.m6520Boolean$branch$when2$funequals$classCarIdentity();
        }
        return this.chipId != carIdentity.chipId ? LiveLiterals$IdentityPacketKt.INSTANCE.m6521Boolean$branch$when3$funequals$classCarIdentity() : LiveLiterals$IdentityPacketKt.INSTANCE.m6522Boolean$funequals$classCarIdentity();
    }

    public int hashCode() {
        return (LiveLiterals$IdentityPacketKt.INSTANCE.m6529Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCarIdentity() * Long.hashCode(this.token)) + Long.hashCode(this.chipId);
    }

    public String toString() {
        return LiveLiterals$IdentityPacketKt.INSTANCE.m6538String$0$str$funtoString$classCarIdentity() + LiveLiterals$IdentityPacketKt.INSTANCE.m6539String$1$str$funtoString$classCarIdentity() + this.token + LiveLiterals$IdentityPacketKt.INSTANCE.m6540String$3$str$funtoString$classCarIdentity() + LiveLiterals$IdentityPacketKt.INSTANCE.m6541String$4$str$funtoString$classCarIdentity() + this.chipId + LiveLiterals$IdentityPacketKt.INSTANCE.m6542String$6$str$funtoString$classCarIdentity();
    }

    public CarIdentity(long token, long chipId) {
        this.token = token;
        this.chipId = chipId;
    }

    public final long getChipId() {
        return this.chipId;
    }

    public final long getToken() {
        return this.token;
    }
}
