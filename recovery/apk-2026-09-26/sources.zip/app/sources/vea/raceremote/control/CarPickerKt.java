package vea.raceremote.control;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.lazy.LazyDslKt;
import androidx.compose.foundation.lazy.LazyItemScope;
import androidx.compose.foundation.lazy.LazyListScope;
import androidx.compose.material.AndroidAlertDialog_androidKt;
import androidx.compose.material.ButtonKt;
import androidx.compose.material.TextKt;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.DisposableEffectResult;
import androidx.compose.runtime.DisposableEffectScope;
import androidx.compose.runtime.EffectsKt;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.ProvidableCompositionLocal;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.SkippableUpdater;
import androidx.compose.runtime.SnapshotStateKt;
import androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt;
import androidx.compose.runtime.State;
import androidx.compose.runtime.Updater;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.layout.LayoutKt;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;
import androidx.compose.ui.platform.CompositionLocalsKt;
import androidx.compose.ui.platform.TestTagKt;
import androidx.compose.ui.platform.ViewConfiguration;
import androidx.compose.ui.unit.Density;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.unit.LayoutDirection;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleOwner;
import java.io.IOException;
import java.net.DatagramSocket;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;

/* JADX INFO: compiled from: CarPicker.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000\u001a\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a)\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0012\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00010\u0005H\u0007¢\u0006\u0002\u0010\u0007¨\u0006\b"}, d2 = {"CarPicker", "", "enabled", "", "onPick", "Lkotlin/Function1;", "Lvea/raceremote/control/DiscoveredCar;", "(ZLkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class CarPickerKt {
    public static final void CarPicker(final boolean enabled, final Function1<? super DiscoveredCar, Unit> function1, Composer $composer, final int $changed) {
        Object value$iv$iv;
        Object value$iv$iv2;
        Composer $composer2;
        Intrinsics.checkNotNullParameter(function1, "onPick");
        Composer $composer3 = $composer.startRestartGroup(622522653);
        ComposerKt.sourceInformation($composer3, "C(CarPicker)19@736L7,20@784L7,21@822L27,22@883L16,23@916L34,31@1292L384,40@1681L122,41@1818L1030:CarPicker.kt#597736");
        int $dirty = $changed;
        if (($changed & 14) == 0) {
            $dirty |= $composer3.changed(enabled) ? 4 : 2;
        }
        if (($changed & 112) == 0) {
            $dirty |= $composer3.changed(function1) ? 32 : 16;
        }
        int $dirty2 = $dirty;
        if (($dirty2 & 91) != 18 || !$composer3.getSkipping()) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(622522653, $dirty2, -1, "vea.raceremote.control.CarPicker (CarPicker.kt:18)");
            }
            ProvidableCompositionLocal<Context> localContext = AndroidCompositionLocals_androidKt.getLocalContext();
            ComposerKt.sourceInformationMarkerStart($composer3, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume = $composer3.consume(localContext);
            ComposerKt.sourceInformationMarkerEnd($composer3);
            final Context context = (Context) objConsume;
            ProvidableCompositionLocal<LifecycleOwner> localLifecycleOwner = AndroidCompositionLocals_androidKt.getLocalLifecycleOwner();
            ComposerKt.sourceInformationMarkerStart($composer3, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume2 = $composer3.consume(localLifecycleOwner);
            ComposerKt.sourceInformationMarkerEnd($composer3);
            Lifecycle lifecycle = ((LifecycleOwner) objConsume2).getLifecycle();
            Intrinsics.checkNotNullExpressionValue(lifecycle, "LocalLifecycleOwner.current.lifecycle");
            $composer3.startReplaceableGroup(-492369756);
            ComposerKt.sourceInformation($composer3, "C(remember):Composables.kt#9igjgp");
            Object it$iv$iv = $composer3.rememberedValue();
            if (it$iv$iv == Composer.INSTANCE.getEmpty()) {
                value$iv$iv = new CarDiscovery();
                $composer3.updateRememberedValue(value$iv$iv);
            } else {
                value$iv$iv = it$iv$iv;
            }
            $composer3.endReplaceableGroup();
            final CarDiscovery discovery = (CarDiscovery) value$iv$iv;
            final State state$delegate = SnapshotStateKt.collectAsState(discovery.getState(), null, $composer3, 8, 1);
            $composer3.startReplaceableGroup(-492369756);
            ComposerKt.sourceInformation($composer3, "C(remember):Composables.kt#9igjgp");
            Object it$iv$iv2 = $composer3.rememberedValue();
            if (it$iv$iv2 == Composer.INSTANCE.getEmpty()) {
                value$iv$iv2 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(Boolean.valueOf(LiveLiterals$CarPickerKt.INSTANCE.m6295Boolean$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valopen$delegate$funCarPicker()), null, 2, null);
                $composer3.updateRememberedValue(value$iv$iv2);
            } else {
                value$iv$iv2 = it$iv$iv2;
            }
            $composer3.endReplaceableGroup();
            final MutableState open$delegate = (MutableState) value$iv$iv2;
            EffectsKt.DisposableEffect(discovery, lifecycle, new AnonymousClass1(lifecycle, discovery, open$delegate), $composer3, CarDiscovery.$stable | 64);
            $composer2 = $composer3;
            ButtonKt.Button(new Function0<Unit>() { // from class: vea.raceremote.control.CarPickerKt.CarPicker.2
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    CarPickerKt.CarPicker$lambda$4(open$delegate, LiveLiterals$CarPickerKt.INSTANCE.m6292Boolean$arg0$call$setopen$$fun$anonymous$$arg0$callButton$funCarPicker());
                    CarPickerKt.CarPicker$search(context, discovery);
                }
            }, TestTagKt.testTag(Modifier.INSTANCE, LiveLiterals$CarPickerKt.INSTANCE.m6307String$arg0$calltestTag$valtmp0_modifier$funCarPicker()), enabled, null, null, null, null, null, null, ComposableSingletons$CarPickerKt.INSTANCE.m5984getLambda1$app_debug(), $composer3, (($dirty2 << 6) & 896) | 805306368, 504);
            if (CarPicker$lambda$3(open$delegate)) {
                AndroidAlertDialog_androidKt.m886AlertDialog6oU6zVQ(new Function0<Unit>() { // from class: vea.raceremote.control.CarPickerKt.CarPicker.3
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        CarPickerKt.CarPicker$lambda$4(open$delegate, LiveLiterals$CarPickerKt.INSTANCE.m6291Boolean$arg0$call$setopen$$fun$anonymous$$arg0$callAlertDialog$branch$if$funCarPicker());
                        discovery.cancel();
                    }
                }, ComposableLambdaKt.composableLambda($composer2, 723372464, true, new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.control.CarPickerKt.CarPicker.4
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(2);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                        invoke(composer, num.intValue());
                        return Unit.INSTANCE;
                    }

                    public final void invoke(Composer $composer4, int $changed2) {
                        ComposerKt.sourceInformation($composer4, "C57@2648L83:CarPicker.kt#597736");
                        if (($changed2 & 11) == 2 && $composer4.getSkipping()) {
                            $composer4.skipToGroupEnd();
                            return;
                        }
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(723372464, $changed2, -1, "vea.raceremote.control.CarPicker.<anonymous> (CarPicker.kt:57)");
                        }
                        final Context context2 = context;
                        final CarDiscovery carDiscovery = discovery;
                        ButtonKt.TextButton(new Function0<Unit>() { // from class: vea.raceremote.control.CarPickerKt.CarPicker.4.1
                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            {
                                super(0);
                            }

                            @Override // kotlin.jvm.functions.Function0
                            public /* bridge */ /* synthetic */ Unit invoke() {
                                invoke2();
                                return Unit.INSTANCE;
                            }

                            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                            public final void invoke2() {
                                CarPickerKt.CarPicker$search(context2, carDiscovery);
                            }
                        }, null, !CarPickerKt.CarPicker$lambda$1(state$delegate).getSearching(), null, null, null, null, null, null, ComposableSingletons$CarPickerKt.INSTANCE.m5985getLambda2$app_debug(), $composer4, 805306368, 506);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    }
                }), null, ComposableLambdaKt.composableLambda($composer2, -1407978258, true, new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.control.CarPickerKt.CarPicker.5
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(2);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                        invoke(composer, num.intValue());
                        return Unit.INSTANCE;
                    }

                    public final void invoke(Composer $composer4, int $changed2) {
                        ComposerKt.sourceInformation($composer4, "C58@2761L78:CarPicker.kt#597736");
                        if (($changed2 & 11) == 2 && $composer4.getSkipping()) {
                            $composer4.skipToGroupEnd();
                            return;
                        }
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1407978258, $changed2, -1, "vea.raceremote.control.CarPicker.<anonymous> (CarPicker.kt:58)");
                        }
                        final CarDiscovery carDiscovery = discovery;
                        final MutableState<Boolean> mutableState = open$delegate;
                        ButtonKt.TextButton(new Function0<Unit>() { // from class: vea.raceremote.control.CarPickerKt.CarPicker.5.1
                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            {
                                super(0);
                            }

                            @Override // kotlin.jvm.functions.Function0
                            public /* bridge */ /* synthetic */ Unit invoke() {
                                invoke2();
                                return Unit.INSTANCE;
                            }

                            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                            public final void invoke2() {
                                CarPickerKt.CarPicker$lambda$4(mutableState, LiveLiterals$CarPickerKt.INSTANCE.m6293Boolean$arg0$call$setopen$$fun$anonymous$$arg0$callTextButton$fun$anonymous$$arg3$callAlertDialog$branch$if$funCarPicker());
                                carDiscovery.cancel();
                            }
                        }, null, false, null, null, null, null, null, null, ComposableSingletons$CarPickerKt.INSTANCE.m5986getLambda3$app_debug(), $composer4, 805306368, 510);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    }
                }), ComposableSingletons$CarPickerKt.INSTANCE.m5987getLambda4$app_debug(), ComposableLambdaKt.composableLambda($composer2, 755638316, true, new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.control.CarPickerKt.CarPicker.6
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    /* JADX WARN: Multi-variable type inference failed */
                    {
                        super(2);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                        invoke(composer, num.intValue());
                        return Unit.INSTANCE;
                    }

                    public final void invoke(Composer $composer4, int $changed2) {
                        ComposerKt.sourceInformation($composer4, "C45@1979L631:CarPicker.kt#597736");
                        if (($changed2 & 11) != 2 || !$composer4.getSkipping()) {
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventStart(755638316, $changed2, -1, "vea.raceremote.control.CarPicker.<anonymous> (CarPicker.kt:44)");
                            }
                            final State<DiscoveryState> state = state$delegate;
                            final Function1<DiscoveredCar, Unit> function2 = function1;
                            final CarDiscovery carDiscovery = discovery;
                            final MutableState<Boolean> mutableState = open$delegate;
                            $composer4.startReplaceableGroup(-483455358);
                            ComposerKt.sourceInformation($composer4, "C(Column)P(2,3,1)77@3880L61,78@3946L133:Column.kt#2w3rfo");
                            Modifier modifier$iv = Modifier.INSTANCE;
                            Arrangement.Vertical verticalArrangement$iv = Arrangement.INSTANCE.getTop();
                            Alignment.Horizontal horizontalAlignment$iv = Alignment.INSTANCE.getStart();
                            MeasurePolicy measurePolicy$iv = ColumnKt.columnMeasurePolicy(verticalArrangement$iv, horizontalAlignment$iv, $composer4, ((0 >> 3) & 14) | ((0 >> 3) & 112));
                            int $changed$iv$iv = (0 << 3) & 112;
                            $composer4.startReplaceableGroup(-1323940314);
                            ComposerKt.sourceInformation($composer4, "C(Layout)P(!1,2)74@2915L7,75@2970L7,76@3029L7,77@3041L460:Layout.kt#80mrfh");
                            ProvidableCompositionLocal<Density> localDensity = CompositionLocalsKt.getLocalDensity();
                            ComposerKt.sourceInformationMarkerStart($composer4, 2023513938, "C:CompositionLocal.kt#9igjgp");
                            Object objConsume3 = $composer4.consume(localDensity);
                            ComposerKt.sourceInformationMarkerEnd($composer4);
                            Density density$iv$iv = (Density) objConsume3;
                            ProvidableCompositionLocal<LayoutDirection> localLayoutDirection = CompositionLocalsKt.getLocalLayoutDirection();
                            ComposerKt.sourceInformationMarkerStart($composer4, 2023513938, "C:CompositionLocal.kt#9igjgp");
                            Object objConsume4 = $composer4.consume(localLayoutDirection);
                            ComposerKt.sourceInformationMarkerEnd($composer4);
                            LayoutDirection layoutDirection$iv$iv = (LayoutDirection) objConsume4;
                            ProvidableCompositionLocal<ViewConfiguration> localViewConfiguration = CompositionLocalsKt.getLocalViewConfiguration();
                            ComposerKt.sourceInformationMarkerStart($composer4, 2023513938, "C:CompositionLocal.kt#9igjgp");
                            Object objConsume5 = $composer4.consume(localViewConfiguration);
                            ComposerKt.sourceInformationMarkerEnd($composer4);
                            ViewConfiguration viewConfiguration$iv$iv = (ViewConfiguration) objConsume5;
                            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
                            Function3<SkippableUpdater<ComposeUiNode>, Composer, Integer, Unit> function3MaterializerOf = LayoutKt.materializerOf(modifier$iv);
                            int $changed$iv$iv$iv = (($changed$iv$iv << 9) & 7168) | 6;
                            if (!($composer4.getApplier() instanceof Applier)) {
                                ComposablesKt.invalidApplier();
                            }
                            $composer4.startReusableNode();
                            if ($composer4.getInserting()) {
                                $composer4.createNode(constructor);
                            } else {
                                $composer4.useNode();
                            }
                            $composer4.disableReusing();
                            Composer $this$Layout_u24lambda_u2d0$iv$iv = Updater.m1304constructorimpl($composer4);
                            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, measurePolicy$iv, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, density$iv$iv, ComposeUiNode.INSTANCE.getSetDensity());
                            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, layoutDirection$iv$iv, ComposeUiNode.INSTANCE.getSetLayoutDirection());
                            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, viewConfiguration$iv$iv, ComposeUiNode.INSTANCE.getSetViewConfiguration());
                            $composer4.enableReusing();
                            function3MaterializerOf.invoke(SkippableUpdater.m1294boximpl(SkippableUpdater.m1295constructorimpl($composer4)), $composer4, Integer.valueOf(($changed$iv$iv$iv >> 3) & 112));
                            $composer4.startReplaceableGroup(2058660585);
                            int $changed$iv = ($changed$iv$iv$iv >> 9) & 14;
                            $composer4.startReplaceableGroup(-1163856341);
                            ComposerKt.sourceInformation($composer4, "C79@3994L9:Column.kt#2w3rfo");
                            if (($changed$iv & 11) == 2 && $composer4.getSkipping()) {
                                $composer4.skipToGroupEnd();
                            } else {
                                ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                                int i = ((0 >> 6) & 112) | 6;
                                ComposerKt.sourceInformationMarkerStart($composer4, 2114098240, "C46@2004L57,47@2078L518:CarPicker.kt#597736");
                                TextKt.m1249TextfLXpl1I(CarPickerKt.CarPicker$lambda$1(state).getMessage(), TestTagKt.testTag(Modifier.INSTANCE, LiveLiterals$CarPickerKt.INSTANCE.m6306String$arg0$calltestTag$arg1$callText$fun$anonymous$$arg3$callColumn$fun$anonymous$$arg5$callAlertDialog$branch$if$funCarPicker()), 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, null, $composer4, 0, 0, 65532);
                                Modifier.Companion companion = Modifier.INSTANCE;
                                int $this$dp$iv = LiveLiterals$CarPickerKt.INSTANCE.m6297Int$$$this$call$getdp$$arg1$callheightIn$arg0$callLazyColumn$fun$anonymous$$arg3$callColumn$fun$anonymous$$arg5$callAlertDialog$branch$if$funCarPicker();
                                LazyDslKt.LazyColumn(SizeKt.m456heightInVpY3zN4$default(companion, 0.0f, Dp.m4046constructorimpl($this$dp$iv), 1, null), null, null, false, null, null, null, false, new Function1<LazyListScope, Unit>() { // from class: vea.raceremote.control.CarPickerKt$CarPicker$6$1$1
                                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                    /* JADX WARN: Multi-variable type inference failed */
                                    {
                                        super(1);
                                    }

                                    @Override // kotlin.jvm.functions.Function1
                                    public /* bridge */ /* synthetic */ Unit invoke(LazyListScope lazyListScope) {
                                        invoke2(lazyListScope);
                                        return Unit.INSTANCE;
                                    }

                                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                                    public final void invoke2(LazyListScope $this$LazyColumn) {
                                        Intrinsics.checkNotNullParameter($this$LazyColumn, "$this$LazyColumn");
                                        final List<DiscoveredCar> cars = CarPickerKt.CarPicker$lambda$1(state).getCars();
                                        final Function1 key$iv = new Function1<DiscoveredCar, Object>() { // from class: vea.raceremote.control.CarPickerKt$CarPicker$6$1$1.1
                                            @Override // kotlin.jvm.functions.Function1
                                            public final Object invoke(DiscoveredCar it) {
                                                Intrinsics.checkNotNullParameter(it, "it");
                                                return it.getChipId() + LiveLiterals$CarPickerKt.INSTANCE.m6300String$1$str$fun$anonymous$$arg1$callitems$fun$anonymous$$arg8$callLazyColumn$fun$anonymous$$arg3$callColumn$fun$anonymous$$arg5$callAlertDialog$branch$if$funCarPicker() + it.getHost();
                                            }
                                        };
                                        final Function1<DiscoveredCar, Unit> function3 = function2;
                                        final CarDiscovery carDiscovery2 = carDiscovery;
                                        final MutableState<Boolean> mutableState2 = mutableState;
                                        final Function1 contentType$iv = new Function1() { // from class: vea.raceremote.control.CarPickerKt$CarPicker$6$1$1$invoke$$inlined$items$default$1
                                            @Override // kotlin.jvm.functions.Function1
                                            public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                                                return invoke((DiscoveredCar) p1);
                                            }

                                            @Override // kotlin.jvm.functions.Function1
                                            public final Void invoke(DiscoveredCar discoveredCar) {
                                                return null;
                                            }
                                        };
                                        $this$LazyColumn.items(cars.size(), key$iv != null ? new Function1<Integer, Object>() { // from class: vea.raceremote.control.CarPickerKt$CarPicker$6$1$1$invoke$$inlined$items$default$2
                                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                            {
                                                super(1);
                                            }

                                            @Override // kotlin.jvm.functions.Function1
                                            public /* bridge */ /* synthetic */ Object invoke(Integer num) {
                                                return invoke(num.intValue());
                                            }

                                            public final Object invoke(int index) {
                                                return invoke(cars.get(index));
                                            }
                                        } : null, new Function1<Integer, Object>() { // from class: vea.raceremote.control.CarPickerKt$CarPicker$6$1$1$invoke$$inlined$items$default$3
                                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                            {
                                                super(1);
                                            }

                                            @Override // kotlin.jvm.functions.Function1
                                            public /* bridge */ /* synthetic */ Object invoke(Integer num) {
                                                return invoke(num.intValue());
                                            }

                                            public final Object invoke(int index) {
                                                return invoke(cars.get(index));
                                            }
                                        }, ComposableLambdaKt.composableLambdaInstance(-632812321, true, new Function4<LazyItemScope, Integer, Composer, Integer, Unit>() { // from class: vea.raceremote.control.CarPickerKt$CarPicker$6$1$1$invoke$$inlined$items$default$4
                                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                            {
                                                super(4);
                                            }

                                            @Override // kotlin.jvm.functions.Function4
                                            public /* bridge */ /* synthetic */ Unit invoke(LazyItemScope lazyItemScope, Integer num, Composer composer, Integer num2) {
                                                invoke(lazyItemScope, num.intValue(), composer, num2.intValue());
                                                return Unit.INSTANCE;
                                            }

                                            public final void invoke(LazyItemScope $this$items, int it, Composer $composer5, int $changed3) {
                                                Intrinsics.checkNotNullParameter($this$items, "$this$items");
                                                ComposerKt.sourceInformation($composer5, "C145@6504L22:LazyDsl.kt#428nma");
                                                int $dirty3 = $changed3;
                                                if (($changed3 & 14) == 0) {
                                                    $dirty3 |= $composer5.changed($this$items) ? 4 : 2;
                                                }
                                                if (($changed3 & 112) == 0) {
                                                    $dirty3 |= $composer5.changed(it) ? 32 : 16;
                                                }
                                                if (($dirty3 & 731) == 146 && $composer5.getSkipping()) {
                                                    $composer5.skipToGroupEnd();
                                                    return;
                                                }
                                                int i2 = $dirty3 & 14;
                                                final DiscoveredCar car = (DiscoveredCar) cars.get(it);
                                                ComposerKt.sourceInformationMarkerStart($composer5, -1025643546, "C*49@2232L324:CarPicker.kt#597736");
                                                final Function1 function4 = function3;
                                                final CarDiscovery carDiscovery3 = carDiscovery2;
                                                final MutableState mutableState3 = mutableState2;
                                                ButtonKt.TextButton(new Function0<Unit>() { // from class: vea.raceremote.control.CarPickerKt$CarPicker$6$1$1$2$1
                                                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                                    /* JADX WARN: Multi-variable type inference failed */
                                                    {
                                                        super(0);
                                                    }

                                                    @Override // kotlin.jvm.functions.Function0
                                                    public /* bridge */ /* synthetic */ Unit invoke() {
                                                        invoke2();
                                                        return Unit.INSTANCE;
                                                    }

                                                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                                                    public final void invoke2() {
                                                        invoke(car);
                                                        CarPickerKt.CarPicker$lambda$4(mutableState3, LiveLiterals$CarPickerKt.INSTANCE.m6294Boolean$arg0$call$setopen$$fun$anonymous$$arg0$callTextButton$fun$anonymous$$arg3$callitems$fun$anonymous$$arg8$callLazyColumn$fun$anonymous$$arg3$callColumn$fun$anonymous$$arg5$callAlertDialog$branch$if$funCarPicker());
                                                        carDiscovery3.cancel();
                                                    }
                                                }, TestTagKt.testTag(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), LiveLiterals$CarPickerKt.INSTANCE.m6298String$0$str$arg0$calltestTag$arg1$callTextButton$fun$anonymous$$arg3$callitems$fun$anonymous$$arg8$callLazyColumn$fun$anonymous$$arg3$callColumn$fun$anonymous$$arg5$callAlertDialog$branch$if$funCarPicker() + car.getChipId()), false, null, null, null, null, null, null, ComposableLambdaKt.composableLambda($composer5, -855749185, true, new Function3<RowScope, Composer, Integer, Unit>() { // from class: vea.raceremote.control.CarPickerKt$CarPicker$6$1$1$2$2
                                                    {
                                                        super(3);
                                                    }

                                                    @Override // kotlin.jvm.functions.Function3
                                                    public /* bridge */ /* synthetic */ Unit invoke(RowScope rowScope, Composer composer, Integer num) {
                                                        invoke(rowScope, composer, num.intValue());
                                                        return Unit.INSTANCE;
                                                    }

                                                    public final void invoke(RowScope $this$TextButton, Composer $composer6, int $changed4) {
                                                        Intrinsics.checkNotNullParameter($this$TextButton, "$this$TextButton");
                                                        ComposerKt.sourceInformation($composer6, "C51@2434L96:CarPicker.kt#597736");
                                                        if (($changed4 & 81) == 16 && $composer6.getSkipping()) {
                                                            $composer6.skipToGroupEnd();
                                                            return;
                                                        }
                                                        if (ComposerKt.isTraceInProgress()) {
                                                            ComposerKt.traceEventStart(-855749185, $changed4, -1, "vea.raceremote.control.CarPicker.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (CarPicker.kt:50)");
                                                        }
                                                        TextKt.m1249TextfLXpl1I(car.getName() + LiveLiterals$CarPickerKt.INSTANCE.m6299String$1$str$arg0$callText$fun$anonymous$$arg9$callTextButton$fun$anonymous$$arg3$callitems$fun$anonymous$$arg8$callLazyColumn$fun$anonymous$$arg3$callColumn$fun$anonymous$$arg5$callAlertDialog$branch$if$funCarPicker() + car.getHost() + LiveLiterals$CarPickerKt.INSTANCE.m6301String$3$str$arg0$callText$fun$anonymous$$arg9$callTextButton$fun$anonymous$$arg3$callitems$fun$anonymous$$arg8$callLazyColumn$fun$anonymous$$arg3$callColumn$fun$anonymous$$arg5$callAlertDialog$branch$if$funCarPicker() + (car.getBusy() ? LiveLiterals$CarPickerKt.INSTANCE.m6308String$branch$if$4$str$arg0$callText$fun$anonymous$$arg9$callTextButton$fun$anonymous$$arg3$callitems$fun$anonymous$$arg8$callLazyColumn$fun$anonymous$$arg3$callColumn$fun$anonymous$$arg5$callAlertDialog$branch$if$funCarPicker() : LiveLiterals$CarPickerKt.INSTANCE.m6309String$else$if$4$str$arg0$callText$fun$anonymous$$arg9$callTextButton$fun$anonymous$$arg3$callitems$fun$anonymous$$arg8$callLazyColumn$fun$anonymous$$arg3$callColumn$fun$anonymous$$arg5$callAlertDialog$branch$if$funCarPicker()), null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, null, $composer6, 0, 0, 65534);
                                                        if (ComposerKt.isTraceInProgress()) {
                                                            ComposerKt.traceEventEnd();
                                                        }
                                                    }
                                                }), $composer5, 805306368, 508);
                                                ComposerKt.sourceInformationMarkerEnd($composer5);
                                            }
                                        }));
                                    }
                                }, $composer4, 0, 254);
                                ComposerKt.sourceInformationMarkerEnd($composer4);
                            }
                            $composer4.endReplaceableGroup();
                            $composer4.endReplaceableGroup();
                            $composer4.endNode();
                            $composer4.endReplaceableGroup();
                            $composer4.endReplaceableGroup();
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                                return;
                            }
                            return;
                        }
                        $composer4.skipToGroupEnd();
                    }
                }), null, 0L, 0L, null, $composer2, 224304, 964);
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            $composer3.skipToGroupEnd();
            $composer2 = $composer3;
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.control.CarPickerKt.CarPicker.7
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i) {
                CarPickerKt.CarPicker(enabled, function1, composer, $changed | 1);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final DiscoveryState CarPicker$lambda$1(State<DiscoveryState> state) {
        Object thisObj$iv = state.getValue();
        return (DiscoveryState) thisObj$iv;
    }

    private static final boolean CarPicker$lambda$3(MutableState<Boolean> mutableState) {
        MutableState<Boolean> $this$getValue$iv = mutableState;
        return $this$getValue$iv.getValue().booleanValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void CarPicker$lambda$4(MutableState<Boolean> mutableState, boolean value) {
        mutableState.setValue(Boolean.valueOf(value));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void CarPicker$search(Context context, CarDiscovery discovery) {
        ConnectivityManager manager = (ConnectivityManager) context.getSystemService(ConnectivityManager.class);
        Object[] allNetworks = manager.getAllNetworks();
        Intrinsics.checkNotNullExpressionValue(allNetworks, "manager.allNetworks");
        Object[] $this$firstOrNull$iv = allNetworks;
        for (Object element$iv : $this$firstOrNull$iv) {
            Network it = (Network) element$iv;
            NetworkCapabilities networkCapabilities = manager.getNetworkCapabilities(it);
            if (networkCapabilities != null && networkCapabilities.hasTransport(1) == LiveLiterals$CarPickerKt.INSTANCE.m6296Boolean$arg1$callEQEQ$fun$anonymous$$arg0$callfirstOrNull$valwifi$funsearch$funCarPicker()) {
                final Network wifi = (Network) element$iv;
                CarDiscovery.search$default(discovery, null, new Function1<DatagramSocket, Unit>() { // from class: vea.raceremote.control.CarPickerKt$CarPicker$search$1
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(1);
                    }

                    @Override // kotlin.jvm.functions.Function1
                    public /* bridge */ /* synthetic */ Unit invoke(DatagramSocket datagramSocket) throws IOException {
                        invoke2(datagramSocket);
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2(DatagramSocket socket) throws IOException {
                        Intrinsics.checkNotNullParameter(socket, "socket");
                        Network network = wifi;
                        if (network != null) {
                            network.bindSocket(socket);
                        }
                    }
                }, 1, null);
            }
        }
        element$iv = null;
        final Network wifi2 = (Network) element$iv;
        CarDiscovery.search$default(discovery, null, new Function1<DatagramSocket, Unit>() { // from class: vea.raceremote.control.CarPickerKt$CarPicker$search$1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(DatagramSocket datagramSocket) throws IOException {
                invoke2(datagramSocket);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(DatagramSocket socket) throws IOException {
                Intrinsics.checkNotNullParameter(socket, "socket");
                Network network = wifi2;
                if (network != null) {
                    network.bindSocket(socket);
                }
            }
        }, 1, null);
    }

    /* JADX INFO: renamed from: vea.raceremote.control.CarPickerKt$CarPicker$1, reason: invalid class name */
    /* JADX INFO: compiled from: CarPicker.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    static final class AnonymousClass1 extends Lambda implements Function1<DisposableEffectScope, DisposableEffectResult> {
        final /* synthetic */ CarDiscovery $discovery;
        final /* synthetic */ Lifecycle $lifecycle;
        final /* synthetic */ MutableState<Boolean> $open$delegate;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(Lifecycle lifecycle, CarDiscovery carDiscovery, MutableState<Boolean> mutableState) {
            super(1);
            this.$lifecycle = lifecycle;
            this.$discovery = carDiscovery;
            this.$open$delegate = mutableState;
        }

        @Override // kotlin.jvm.functions.Function1
        public final DisposableEffectResult invoke(DisposableEffectScope $this$DisposableEffect) {
            Intrinsics.checkNotNullParameter($this$DisposableEffect, "$this$DisposableEffect");
            final CarDiscovery carDiscovery = this.$discovery;
            final MutableState<Boolean> mutableState = this.$open$delegate;
            final LifecycleEventObserver observer = new LifecycleEventObserver() { // from class: vea.raceremote.control.CarPickerKt$CarPicker$1$$ExternalSyntheticLambda0
                @Override // androidx.lifecycle.LifecycleEventObserver
                public final void onStateChanged(LifecycleOwner lifecycleOwner, Lifecycle.Event event) {
                    CarPickerKt.AnonymousClass1.invoke$lambda$0(carDiscovery, mutableState, lifecycleOwner, event);
                }
            };
            addObserver(observer);
            final Lifecycle lifecycle = this.$lifecycle;
            final CarDiscovery carDiscovery2 = this.$discovery;
            return new DisposableEffectResult() { // from class: vea.raceremote.control.CarPickerKt$CarPicker$1$invoke$$inlined$onDispose$1
                @Override // androidx.compose.runtime.DisposableEffectResult
                public void dispose() {
                    removeObserver(observer);
                    carDiscovery2.close();
                }
            };
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void invoke$lambda$0(CarDiscovery $discovery, MutableState $open$delegate, LifecycleOwner lifecycleOwner, Lifecycle.Event event) {
            Intrinsics.checkNotNullParameter($discovery, "$discovery");
            Intrinsics.checkNotNullParameter($open$delegate, "$open$delegate");
            Intrinsics.checkNotNullParameter(lifecycleOwner, "<anonymous parameter 0>");
            Intrinsics.checkNotNullParameter(event, "event");
            if (event == Lifecycle.Event.ON_PAUSE || event == Lifecycle.Event.ON_STOP) {
                CarPickerKt.CarPicker$lambda$4($open$delegate, LiveLiterals$CarPickerKt.INSTANCE.m6290Boolean$arg0$call$setopen$$branch$if$fun$anonymous$$valobserver$fun$anonymous$$arg2$callDisposableEffect$funCarPicker());
                $discovery.cancel();
            }
        }
    }
}
