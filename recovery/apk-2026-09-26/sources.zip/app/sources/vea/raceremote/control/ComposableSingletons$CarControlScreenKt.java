package vea.raceremote.control;

import androidx.compose.foundation.layout.RowScope;
import androidx.compose.material.TextKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: CarControlScreen.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
public final class ComposableSingletons$CarControlScreenKt {
    public static final ComposableSingletons$CarControlScreenKt INSTANCE = new ComposableSingletons$CarControlScreenKt();

    /* JADX INFO: renamed from: lambda-1, reason: not valid java name */
    public static Function4<Boolean, Function1<? super DiscoveredCar, Unit>, Composer, Integer, Unit> f44lambda1 = ComposableLambdaKt.composableLambdaInstance(2027552218, false, new Function4<Boolean, Function1<? super DiscoveredCar, ? extends Unit>, Composer, Integer, Unit>() { // from class: vea.raceremote.control.ComposableSingletons$CarControlScreenKt$lambda-1$1
        @Override // kotlin.jvm.functions.Function4
        public /* bridge */ /* synthetic */ Unit invoke(Boolean bool, Function1<? super DiscoveredCar, ? extends Unit> function1, Composer composer, Integer num) {
            invoke(bool.booleanValue(), (Function1<? super DiscoveredCar, Unit>) function1, composer, num.intValue());
            return Unit.INSTANCE;
        }

        public final void invoke(boolean enabled, Function1<? super DiscoveredCar, Unit> function1, Composer $composer, int $changed) {
            Intrinsics.checkNotNullParameter(function1, "onPick");
            ComposerKt.sourceInformation($composer, "C24@916L26:CarControlScreen.kt#597736");
            int $dirty = $changed;
            if (($changed & 14) == 0) {
                $dirty |= $composer.changed(enabled) ? 4 : 2;
            }
            if (($changed & 112) == 0) {
                $dirty |= $composer.changed(function1) ? 32 : 16;
            }
            if (($dirty & 731) == 146 && $composer.getSkipping()) {
                $composer.skipToGroupEnd();
                return;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(2027552218, $dirty, -1, "vea.raceremote.control.ComposableSingletons$CarControlScreenKt.lambda-1.<anonymous> (CarControlScreen.kt:24)");
            }
            CarPickerKt.CarPicker(enabled, function1, $composer, ($dirty & 14) | ($dirty & 112));
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
    });

    /* JADX INFO: renamed from: lambda-2, reason: not valid java name */
    public static Function2<Composer, Integer, Unit> f45lambda2 = ComposableLambdaKt.composableLambdaInstance(132578130, false, new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.control.ComposableSingletons$CarControlScreenKt$lambda-2$1
        @Override // kotlin.jvm.functions.Function2
        public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
            invoke(composer, num.intValue());
            return Unit.INSTANCE;
        }

        public final void invoke(Composer $composer, int $changed) {
            ComposerKt.sourceInformation($composer, "C72@3796L21:CarControlScreen.kt#597736");
            if (($changed & 11) == 2 && $composer.getSkipping()) {
                $composer.skipToGroupEnd();
                return;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(132578130, $changed, -1, "vea.raceremote.control.ComposableSingletons$CarControlScreenKt.lambda-2.<anonymous> (CarControlScreen.kt:72)");
            }
            TextKt.m1249TextfLXpl1I(LiveLiterals$CarControlScreenKt.INSTANCE.m6226String$arg0$callText$fun$anonymous$$arg6$callOutlinedTextField$branch$if$fun$anonymous$$arg3$callRow$fun$anonymous$$arg3$callColumn$funCarControlScreen(), null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, null, $composer, 0, 0, 65534);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
    });

    /* JADX INFO: renamed from: lambda-3, reason: not valid java name */
    public static Function3<RowScope, Composer, Integer, Unit> f46lambda3 = ComposableLambdaKt.composableLambdaInstance(-1075916120, false, new Function3<RowScope, Composer, Integer, Unit>() { // from class: vea.raceremote.control.ComposableSingletons$CarControlScreenKt$lambda-3$1
        @Override // kotlin.jvm.functions.Function3
        public /* bridge */ /* synthetic */ Unit invoke(RowScope rowScope, Composer composer, Integer num) {
            invoke(rowScope, composer, num.intValue());
            return Unit.INSTANCE;
        }

        public final void invoke(RowScope $this$Button, Composer $composer, int $changed) {
            Intrinsics.checkNotNullParameter($this$Button, "$this$Button");
            ComposerKt.sourceInformation($composer, "C87@5037L18:CarControlScreen.kt#597736");
            if (($changed & 81) == 16 && $composer.getSkipping()) {
                $composer.skipToGroupEnd();
                return;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1075916120, $changed, -1, "vea.raceremote.control.ComposableSingletons$CarControlScreenKt.lambda-3.<anonymous> (CarControlScreen.kt:87)");
            }
            TextKt.m1249TextfLXpl1I(LiveLiterals$CarControlScreenKt.INSTANCE.m6227String$arg0$callText$fun$anonymous$$arg9$callButton$branch$if$fun$anonymous$$arg3$callRow$fun$anonymous$$arg3$callColumn$funCarControlScreen(), null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, null, $composer, 0, 0, 65534);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
    });

    /* JADX INFO: renamed from: lambda-4, reason: not valid java name */
    public static Function3<RowScope, Composer, Integer, Unit> f47lambda4 = ComposableLambdaKt.composableLambdaInstance(200380036, false, new Function3<RowScope, Composer, Integer, Unit>() { // from class: vea.raceremote.control.ComposableSingletons$CarControlScreenKt$lambda-4$1
        @Override // kotlin.jvm.functions.Function3
        public /* bridge */ /* synthetic */ Unit invoke(RowScope rowScope, Composer composer, Integer num) {
            invoke(rowScope, composer, num.intValue());
            return Unit.INSTANCE;
        }

        public final void invoke(RowScope $this$Button, Composer $composer, int $changed) {
            Intrinsics.checkNotNullParameter($this$Button, "$this$Button");
            ComposerKt.sourceInformation($composer, "C96@5658L12:CarControlScreen.kt#597736");
            if (($changed & 81) == 16 && $composer.getSkipping()) {
                $composer.skipToGroupEnd();
                return;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(200380036, $changed, -1, "vea.raceremote.control.ComposableSingletons$CarControlScreenKt.lambda-4.<anonymous> (CarControlScreen.kt:96)");
            }
            TextKt.m1249TextfLXpl1I(LiveLiterals$CarControlScreenKt.INSTANCE.m6228String$arg0$callText$fun$anonymous$$arg9$callButton1$fun$anonymous$$arg3$callRow$fun$anonymous$$arg3$callColumn$funCarControlScreen(), null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, null, $composer, 0, 0, 65534);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
    });

    /* JADX INFO: renamed from: getLambda-1$app_debug, reason: not valid java name */
    public final Function4<Boolean, Function1<? super DiscoveredCar, Unit>, Composer, Integer, Unit> m5980getLambda1$app_debug() {
        return f44lambda1;
    }

    /* JADX INFO: renamed from: getLambda-2$app_debug, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m5981getLambda2$app_debug() {
        return f45lambda2;
    }

    /* JADX INFO: renamed from: getLambda-3$app_debug, reason: not valid java name */
    public final Function3<RowScope, Composer, Integer, Unit> m5982getLambda3$app_debug() {
        return f46lambda3;
    }

    /* JADX INFO: renamed from: getLambda-4$app_debug, reason: not valid java name */
    public final Function3<RowScope, Composer, Integer, Unit> m5983getLambda4$app_debug() {
        return f47lambda4;
    }
}
