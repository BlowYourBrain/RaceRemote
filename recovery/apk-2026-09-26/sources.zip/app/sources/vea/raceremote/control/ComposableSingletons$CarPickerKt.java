package vea.raceremote.control;

import androidx.compose.foundation.layout.RowScope;
import androidx.compose.material.TextKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: CarPicker.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
public final class ComposableSingletons$CarPickerKt {
    public static final ComposableSingletons$CarPickerKt INSTANCE = new ComposableSingletons$CarPickerKt();

    /* JADX INFO: renamed from: lambda-1, reason: not valid java name */
    public static Function3<RowScope, Composer, Integer, Unit> f48lambda1 = ComposableLambdaKt.composableLambdaInstance(564553997, false, new Function3<RowScope, Composer, Integer, Unit>() { // from class: vea.raceremote.control.ComposableSingletons$CarPickerKt$lambda-1$1
        @Override // kotlin.jvm.functions.Function3
        public /* bridge */ /* synthetic */ Unit invoke(RowScope rowScope, Composer composer, Integer num) {
            invoke(rowScope, composer, num.intValue());
            return Unit.INSTANCE;
        }

        public final void invoke(RowScope $this$Button, Composer $composer, int $changed) {
            Intrinsics.checkNotNullParameter($this$Button, "$this$Button");
            ComposerKt.sourceInformation($composer, "C40@1788L13:CarPicker.kt#597736");
            if (($changed & 81) == 16 && $composer.getSkipping()) {
                $composer.skipToGroupEnd();
                return;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(564553997, $changed, -1, "vea.raceremote.control.ComposableSingletons$CarPickerKt.lambda-1.<anonymous> (CarPicker.kt:40)");
            }
            TextKt.m1249TextfLXpl1I(LiveLiterals$CarPickerKt.INSTANCE.m6303String$arg0$callText$fun$anonymous$$arg9$callButton$funCarPicker(), null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, null, $composer, 0, 0, 65534);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
    });

    /* JADX INFO: renamed from: lambda-2, reason: not valid java name */
    public static Function3<RowScope, Composer, Integer, Unit> f49lambda2 = ComposableLambdaKt.composableLambdaInstance(1928963411, false, new Function3<RowScope, Composer, Integer, Unit>() { // from class: vea.raceremote.control.ComposableSingletons$CarPickerKt$lambda-2$1
        @Override // kotlin.jvm.functions.Function3
        public /* bridge */ /* synthetic */ Unit invoke(RowScope rowScope, Composer composer, Integer num) {
            invoke(rowScope, composer, num.intValue());
            return Unit.INSTANCE;
        }

        public final void invoke(RowScope $this$TextButton, Composer $composer, int $changed) {
            Intrinsics.checkNotNullParameter($this$TextButton, "$this$TextButton");
            ComposerKt.sourceInformation($composer, "C57@2713L16:CarPicker.kt#597736");
            if (($changed & 81) == 16 && $composer.getSkipping()) {
                $composer.skipToGroupEnd();
                return;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1928963411, $changed, -1, "vea.raceremote.control.ComposableSingletons$CarPickerKt.lambda-2.<anonymous> (CarPicker.kt:57)");
            }
            TextKt.m1249TextfLXpl1I(LiveLiterals$CarPickerKt.INSTANCE.m6304String$arg0$callText$fun$anonymous$$arg9$callTextButton$fun$anonymous$$arg1$callAlertDialog$branch$if$funCarPicker(), null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, null, $composer, 0, 0, 65534);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
    });

    /* JADX INFO: renamed from: lambda-3, reason: not valid java name */
    public static Function3<RowScope, Composer, Integer, Unit> f50lambda3 = ComposableLambdaKt.composableLambdaInstance(-202387311, false, new Function3<RowScope, Composer, Integer, Unit>() { // from class: vea.raceremote.control.ComposableSingletons$CarPickerKt$lambda-3$1
        @Override // kotlin.jvm.functions.Function3
        public /* bridge */ /* synthetic */ Unit invoke(RowScope rowScope, Composer composer, Integer num) {
            invoke(rowScope, composer, num.intValue());
            return Unit.INSTANCE;
        }

        public final void invoke(RowScope $this$TextButton, Composer $composer, int $changed) {
            Intrinsics.checkNotNullParameter($this$TextButton, "$this$TextButton");
            ComposerKt.sourceInformation($composer, "C58@2822L15:CarPicker.kt#597736");
            if (($changed & 81) == 16 && $composer.getSkipping()) {
                $composer.skipToGroupEnd();
                return;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-202387311, $changed, -1, "vea.raceremote.control.ComposableSingletons$CarPickerKt.lambda-3.<anonymous> (CarPicker.kt:58)");
            }
            TextKt.m1249TextfLXpl1I(LiveLiterals$CarPickerKt.INSTANCE.m6305String$arg0$callText$fun$anonymous$$arg9$callTextButton$fun$anonymous$$arg3$callAlertDialog$branch$if$funCarPicker(), null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, null, $composer, 0, 0, 65534);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
    });

    /* JADX INFO: renamed from: lambda-4, reason: not valid java name */
    public static Function2<Composer, Integer, Unit> f51lambda4 = ComposableLambdaKt.composableLambdaInstance(-326169971, false, new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.control.ComposableSingletons$CarPickerKt$lambda-4$1
        @Override // kotlin.jvm.functions.Function2
        public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
            invoke(composer, num.intValue());
            return Unit.INSTANCE;
        }

        public final void invoke(Composer $composer, int $changed) {
            ComposerKt.sourceInformation($composer, "C43@1914L32:CarPicker.kt#597736");
            if (($changed & 11) == 2 && $composer.getSkipping()) {
                $composer.skipToGroupEnd();
                return;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-326169971, $changed, -1, "vea.raceremote.control.ComposableSingletons$CarPickerKt.lambda-4.<anonymous> (CarPicker.kt:43)");
            }
            TextKt.m1249TextfLXpl1I(LiveLiterals$CarPickerKt.INSTANCE.m6302String$arg0$callText$fun$anonymous$$arg4$callAlertDialog$branch$if$funCarPicker(), null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, null, $composer, 0, 0, 65534);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
    });

    /* JADX INFO: renamed from: getLambda-1$app_debug, reason: not valid java name */
    public final Function3<RowScope, Composer, Integer, Unit> m5984getLambda1$app_debug() {
        return f48lambda1;
    }

    /* JADX INFO: renamed from: getLambda-2$app_debug, reason: not valid java name */
    public final Function3<RowScope, Composer, Integer, Unit> m5985getLambda2$app_debug() {
        return f49lambda2;
    }

    /* JADX INFO: renamed from: getLambda-3$app_debug, reason: not valid java name */
    public final Function3<RowScope, Composer, Integer, Unit> m5986getLambda3$app_debug() {
        return f50lambda3;
    }

    /* JADX INFO: renamed from: getLambda-4$app_debug, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m5987getLambda4$app_debug() {
        return f51lambda4;
    }
}
