package vea.raceremote.control;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: CarControlConnection.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0002\b\f\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0087\b\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bJ\t\u0010\u000f\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0010\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0007HÆ\u0003J'\u0010\u0012\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0007HÆ\u0001J\u0013\u0010\u0013\u001a\u00020\u00142\b\u0010\u0015\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0016\u001a\u00020\u0005HÖ\u0001J\t\u0010\u0017\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000e¨\u0006\u0018"}, d2 = {"Lvea/raceremote/control/ControlEndpoint;", "", "transport", "", "port", "", "chipId", "", "(Ljava/lang/String;IJ)V", "getChipId", "()J", "getPort", "()I", "getTransport", "()Ljava/lang/String;", "component1", "component2", "component3", "copy", "equals", "", "other", "hashCode", "toString", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final /* data */ class ControlEndpoint {
    public static final int $stable = LiveLiterals$CarControlConnectionKt.INSTANCE.m6136Int$classControlEndpoint();
    private final long chipId;
    private final int port;
    private final String transport;

    public static /* synthetic */ ControlEndpoint copy$default(ControlEndpoint controlEndpoint, String str, int i, long j, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            str = controlEndpoint.transport;
        }
        if ((i2 & 2) != 0) {
            i = controlEndpoint.port;
        }
        if ((i2 & 4) != 0) {
            j = controlEndpoint.chipId;
        }
        return controlEndpoint.copy(str, i, j);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getTransport() {
        return this.transport;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final int getPort() {
        return this.port;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final long getChipId() {
        return this.chipId;
    }

    public final ControlEndpoint copy(String transport, int port, long chipId) {
        Intrinsics.checkNotNullParameter(transport, "transport");
        return new ControlEndpoint(transport, port, chipId);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return LiveLiterals$CarControlConnectionKt.INSTANCE.m6115Boolean$branch$when$funequals$classControlEndpoint();
        }
        if (!(other instanceof ControlEndpoint)) {
            return LiveLiterals$CarControlConnectionKt.INSTANCE.m6116Boolean$branch$when1$funequals$classControlEndpoint();
        }
        ControlEndpoint controlEndpoint = (ControlEndpoint) other;
        if (!Intrinsics.areEqual(this.transport, controlEndpoint.transport)) {
            return LiveLiterals$CarControlConnectionKt.INSTANCE.m6117Boolean$branch$when2$funequals$classControlEndpoint();
        }
        if (this.port != controlEndpoint.port) {
            return LiveLiterals$CarControlConnectionKt.INSTANCE.m6118Boolean$branch$when3$funequals$classControlEndpoint();
        }
        return this.chipId != controlEndpoint.chipId ? LiveLiterals$CarControlConnectionKt.INSTANCE.m6119Boolean$branch$when4$funequals$classControlEndpoint() : LiveLiterals$CarControlConnectionKt.INSTANCE.m6120Boolean$funequals$classControlEndpoint();
    }

    public int hashCode() {
        return (LiveLiterals$CarControlConnectionKt.INSTANCE.m6132Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classControlEndpoint() * ((LiveLiterals$CarControlConnectionKt.INSTANCE.m6131Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classControlEndpoint() * this.transport.hashCode()) + Integer.hashCode(this.port))) + Long.hashCode(this.chipId);
    }

    public String toString() {
        return LiveLiterals$CarControlConnectionKt.INSTANCE.m6141String$0$str$funtoString$classControlEndpoint() + LiveLiterals$CarControlConnectionKt.INSTANCE.m6142String$1$str$funtoString$classControlEndpoint() + this.transport + LiveLiterals$CarControlConnectionKt.INSTANCE.m6143String$3$str$funtoString$classControlEndpoint() + LiveLiterals$CarControlConnectionKt.INSTANCE.m6144String$4$str$funtoString$classControlEndpoint() + this.port + LiveLiterals$CarControlConnectionKt.INSTANCE.m6145String$6$str$funtoString$classControlEndpoint() + LiveLiterals$CarControlConnectionKt.INSTANCE.m6146String$7$str$funtoString$classControlEndpoint() + this.chipId + LiveLiterals$CarControlConnectionKt.INSTANCE.m6147String$9$str$funtoString$classControlEndpoint();
    }

    public ControlEndpoint(String transport, int port, long chipId) {
        Intrinsics.checkNotNullParameter(transport, "transport");
        this.transport = transport;
        this.port = port;
        this.chipId = chipId;
    }

    public final long getChipId() {
        return this.chipId;
    }

    public final int getPort() {
        return this.port;
    }

    public final String getTransport() {
        return this.transport;
    }
}
