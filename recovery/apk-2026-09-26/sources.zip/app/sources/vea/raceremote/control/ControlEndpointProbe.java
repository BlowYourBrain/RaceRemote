package vea.raceremote.control;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.io.CloseableKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.CharsKt;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okio.BufferedSource;
import org.json.JSONObject;

/* JADX INFO: compiled from: ControlEndpointProbe.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u001e\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n¨\u0006\u000b"}, d2 = {"Lvea/raceremote/control/ControlEndpointProbe;", "", "()V", "load", "Lvea/raceremote/control/ControlEndpoint;", "host", "", "http", "Lokhttp3/OkHttpClient;", "port", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class ControlEndpointProbe {
    public static final ControlEndpointProbe INSTANCE = new ControlEndpointProbe();
    public static final int $stable = LiveLiterals$ControlEndpointProbeKt.INSTANCE.m6315Int$classControlEndpointProbe();

    private ControlEndpointProbe() {
    }

    public final ControlEndpoint load(String host, OkHttpClient http, int port) throws IOException {
        Intrinsics.checkNotNullParameter(host, "host");
        Intrinsics.checkNotNullParameter(http, "http");
        OkHttpClient bounded = http.newBuilder().followRedirects(LiveLiterals$ControlEndpointProbeKt.INSTANCE.m6310Boolean$arg0$callfollowRedirects$$this$callfollowSslRedirects$$this$callconnectTimeout$$this$callreadTimeout$$this$callcallTimeout$$this$callbuild$valbounded$funload$classControlEndpointProbe()).followSslRedirects(LiveLiterals$ControlEndpointProbeKt.INSTANCE.m6311Boolean$arg0$callfollowSslRedirects$$this$callconnectTimeout$$this$callreadTimeout$$this$callcallTimeout$$this$callbuild$valbounded$funload$classControlEndpointProbe()).connectTimeout(LiveLiterals$ControlEndpointProbeKt.INSTANCE.m6317Long$arg0$callconnectTimeout$$this$callreadTimeout$$this$callcallTimeout$$this$callbuild$valbounded$funload$classControlEndpointProbe(), TimeUnit.SECONDS).readTimeout(LiveLiterals$ControlEndpointProbeKt.INSTANCE.m6318Long$arg0$callreadTimeout$$this$callcallTimeout$$this$callbuild$valbounded$funload$classControlEndpointProbe(), TimeUnit.SECONDS).callTimeout(LiveLiterals$ControlEndpointProbeKt.INSTANCE.m6316Long$arg0$callcallTimeout$$this$callbuild$valbounded$funload$classControlEndpointProbe(), TimeUnit.SECONDS).build();
        Response responseExecute = bounded.newCall(new Request.Builder().url(LiveLiterals$ControlEndpointProbeKt.INSTANCE.m6320String$0$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$funload$classControlEndpointProbe() + host + LiveLiterals$ControlEndpointProbeKt.INSTANCE.m6321String$2$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$funload$classControlEndpointProbe() + port + LiveLiterals$ControlEndpointProbeKt.INSTANCE.m6322String$4$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$funload$classControlEndpointProbe()).build()).execute();
        try {
            Response response = responseExecute;
            if (!(response.code() == LiveLiterals$ControlEndpointProbeKt.INSTANCE.m6313Int$arg1$callEQEQ$arg0$callcheck$fun$anonymous$$arg0$calluse$funload$classControlEndpointProbe())) {
                throw new IllegalStateException("Check failed.".toString());
            }
            ResponseBody body = response.body();
            if (body == null) {
                throw new IllegalArgumentException("Required value was null.".toString());
            }
            Intrinsics.checkNotNullExpressionValue(body, "requireNotNull(response.body())");
            BufferedSource source = body.source();
            if (!(!source.request(LiveLiterals$ControlEndpointProbeKt.INSTANCE.m6319Long$arg0$callrequest$$this$callnot$arg0$callcheck1$fun$anonymous$$arg0$calluse$funload$classControlEndpointProbe()))) {
                throw new IllegalStateException(LiveLiterals$ControlEndpointProbeKt.INSTANCE.m6328String$fun$anonymous$$arg1$callcheck1$fun$anonymous$$arg0$calluse$funload$classControlEndpointProbe().toString());
            }
            JSONObject value = new JSONObject(source.readUtf8());
            if (!(value.getInt(LiveLiterals$ControlEndpointProbeKt.INSTANCE.m6324String$arg0$callgetInt$arg0$callEQEQ$arg0$callcheck2$fun$anonymous$$arg0$calluse$funload$classControlEndpointProbe()) == LiveLiterals$ControlEndpointProbeKt.INSTANCE.m6314Int$arg1$callEQEQ$arg0$callcheck2$fun$anonymous$$arg0$calluse$funload$classControlEndpointProbe())) {
                throw new IllegalStateException("Check failed.".toString());
            }
            if (!value.getBoolean(LiveLiterals$ControlEndpointProbeKt.INSTANCE.m6323String$arg0$callgetBoolean$arg0$callcheck3$fun$anonymous$$arg0$calluse$funload$classControlEndpointProbe())) {
                throw new IllegalStateException("Check failed.".toString());
            }
            String string = value.getString(LiveLiterals$ControlEndpointProbeKt.INSTANCE.m6327String$arg0$callgetString$arg0$call$init$$fun$anonymous$$arg0$calluse$funload$classControlEndpointProbe());
            Intrinsics.checkNotNullExpressionValue(string, "value.getString(\"controlTransport\")");
            int i = value.getInt(LiveLiterals$ControlEndpointProbeKt.INSTANCE.m6325String$arg0$callgetInt$arg1$call$init$$fun$anonymous$$arg0$calluse$funload$classControlEndpointProbe());
            String string2 = value.getString(LiveLiterals$ControlEndpointProbeKt.INSTANCE.m6326String$arg0$callgetString$$$this$calltoLong$arg2$call$init$$fun$anonymous$$arg0$calluse$funload$classControlEndpointProbe());
            Intrinsics.checkNotNullExpressionValue(string2, "value.getString(\"chipId\")");
            ControlEndpoint controlEndpoint = new ControlEndpoint(string, i, Long.parseLong(string2, CharsKt.checkRadix(LiveLiterals$ControlEndpointProbeKt.INSTANCE.m6312Int$arg0$calltoLong$arg2$call$init$$fun$anonymous$$arg0$calluse$funload$classControlEndpointProbe())));
            CloseableKt.closeFinally(responseExecute, null);
            return controlEndpoint;
        } catch (Throwable th) {
            try {
                throw th;
            } catch (Throwable th2) {
                CloseableKt.closeFinally(responseExecute, th);
                throw th2;
            }
        }
    }
}
