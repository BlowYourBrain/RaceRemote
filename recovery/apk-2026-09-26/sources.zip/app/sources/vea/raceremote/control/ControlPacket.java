package vea.raceremote.control;

import java.util.Iterator;
import kotlin.Metadata;
import kotlin.collections.IntIterator;
import kotlin.collections.SetsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.IntRange;

/* JADX INFO: compiled from: ControlPacket.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0002\b\u0012\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\b\u0087\b\u0018\u0000 \u001f2\u00020\u0001:\u0001\u001fB1\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0003\u0012\b\b\u0002\u0010\b\u001a\u00020\u0003¢\u0006\u0002\u0010\tJ\t\u0010\u0011\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0003HÆ\u0003J;\u0010\u0016\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\u0003HÆ\u0001J\u0006\u0010\u0017\u001a\u00020\u0018J\u0013\u0010\u0019\u001a\u00020\u001a2\b\u0010\u001b\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001c\u001a\u00020\u0003HÖ\u0001J\t\u0010\u001d\u001a\u00020\u001eHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000bR\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\r¨\u0006 "}, d2 = {"Lvea/raceremote/control/ControlPacket;", "", "kind", "", "token", "", "sequence", "throttle", "steering", "(IJJII)V", "getKind", "()I", "getSequence", "()J", "getSteering", "getThrottle", "getToken", "component1", "component2", "component3", "component4", "component5", "copy", "encode", "", "equals", "", "other", "hashCode", "toString", "", "Companion", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final /* data */ class ControlPacket {
    public static final int ACK = 129;
    public static final int ARM = 1;
    public static final int DRIVE = 2;
    public static final int HELLO = 128;
    public static final int STOP = 3;
    private final int kind;
    private final long sequence;
    private final int steering;
    private final int throttle;
    private final long token;

    /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion();
    public static final int $stable = LiveLiterals$ControlPacketKt.INSTANCE.m6383Int$classControlPacket();

    public static /* synthetic */ ControlPacket copy$default(ControlPacket controlPacket, int i, long j, long j2, int i2, int i3, int i4, Object obj) {
        if ((i4 & 1) != 0) {
            i = controlPacket.kind;
        }
        if ((i4 & 2) != 0) {
            j = controlPacket.token;
        }
        long j3 = j;
        if ((i4 & 4) != 0) {
            j2 = controlPacket.sequence;
        }
        long j4 = j2;
        if ((i4 & 8) != 0) {
            i2 = controlPacket.throttle;
        }
        int i5 = i2;
        if ((i4 & 16) != 0) {
            i3 = controlPacket.steering;
        }
        return controlPacket.copy(i, j3, j4, i5, i3);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final int getKind() {
        return this.kind;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final long getToken() {
        return this.token;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final long getSequence() {
        return this.sequence;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final int getThrottle() {
        return this.throttle;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final int getSteering() {
        return this.steering;
    }

    public final ControlPacket copy(int kind, long token, long sequence, int throttle, int steering) {
        return new ControlPacket(kind, token, sequence, throttle, steering);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return LiveLiterals$ControlPacketKt.INSTANCE.m6329Boolean$branch$when$funequals$classControlPacket();
        }
        if (!(other instanceof ControlPacket)) {
            return LiveLiterals$ControlPacketKt.INSTANCE.m6330Boolean$branch$when1$funequals$classControlPacket();
        }
        ControlPacket controlPacket = (ControlPacket) other;
        if (this.kind != controlPacket.kind) {
            return LiveLiterals$ControlPacketKt.INSTANCE.m6331Boolean$branch$when2$funequals$classControlPacket();
        }
        if (this.token != controlPacket.token) {
            return LiveLiterals$ControlPacketKt.INSTANCE.m6332Boolean$branch$when3$funequals$classControlPacket();
        }
        if (this.sequence != controlPacket.sequence) {
            return LiveLiterals$ControlPacketKt.INSTANCE.m6333Boolean$branch$when4$funequals$classControlPacket();
        }
        if (this.throttle != controlPacket.throttle) {
            return LiveLiterals$ControlPacketKt.INSTANCE.m6334Boolean$branch$when5$funequals$classControlPacket();
        }
        return this.steering != controlPacket.steering ? LiveLiterals$ControlPacketKt.INSTANCE.m6335Boolean$branch$when6$funequals$classControlPacket() : LiveLiterals$ControlPacketKt.INSTANCE.m6336Boolean$funequals$classControlPacket();
    }

    public int hashCode() {
        return (LiveLiterals$ControlPacketKt.INSTANCE.m6380Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classControlPacket() * ((LiveLiterals$ControlPacketKt.INSTANCE.m6379Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classControlPacket() * ((LiveLiterals$ControlPacketKt.INSTANCE.m6378Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classControlPacket() * ((LiveLiterals$ControlPacketKt.INSTANCE.m6377Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classControlPacket() * Integer.hashCode(this.kind)) + Long.hashCode(this.token))) + Long.hashCode(this.sequence))) + Integer.hashCode(this.throttle))) + Integer.hashCode(this.steering);
    }

    public String toString() {
        return LiveLiterals$ControlPacketKt.INSTANCE.m6391String$0$str$funtoString$classControlPacket() + LiveLiterals$ControlPacketKt.INSTANCE.m6392String$1$str$funtoString$classControlPacket() + this.kind + LiveLiterals$ControlPacketKt.INSTANCE.m6397String$3$str$funtoString$classControlPacket() + LiveLiterals$ControlPacketKt.INSTANCE.m6398String$4$str$funtoString$classControlPacket() + this.token + LiveLiterals$ControlPacketKt.INSTANCE.m6399String$6$str$funtoString$classControlPacket() + LiveLiterals$ControlPacketKt.INSTANCE.m6400String$7$str$funtoString$classControlPacket() + this.sequence + LiveLiterals$ControlPacketKt.INSTANCE.m6401String$9$str$funtoString$classControlPacket() + LiveLiterals$ControlPacketKt.INSTANCE.m6393String$10$str$funtoString$classControlPacket() + this.throttle + LiveLiterals$ControlPacketKt.INSTANCE.m6394String$12$str$funtoString$classControlPacket() + LiveLiterals$ControlPacketKt.INSTANCE.m6395String$13$str$funtoString$classControlPacket() + this.steering + LiveLiterals$ControlPacketKt.INSTANCE.m6396String$15$str$funtoString$classControlPacket();
    }

    public ControlPacket(int kind, long token, long sequence, int throttle, int steering) {
        this.kind = kind;
        this.token = token;
        this.sequence = sequence;
        this.throttle = throttle;
        this.steering = steering;
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public /* synthetic */ ControlPacket(int i, long j, long j2, int i2, int i3, int i4, DefaultConstructorMarker defaultConstructorMarker) {
        int iM6385Int$paramthrottle$classControlPacket;
        int iM6384Int$paramsteering$classControlPacket;
        if ((i4 & 8) == 0) {
            iM6385Int$paramthrottle$classControlPacket = i2;
        } else {
            iM6385Int$paramthrottle$classControlPacket = LiveLiterals$ControlPacketKt.INSTANCE.m6385Int$paramthrottle$classControlPacket();
        }
        if ((i4 & 16) == 0) {
            iM6384Int$paramsteering$classControlPacket = i3;
        } else {
            iM6384Int$paramsteering$classControlPacket = LiveLiterals$ControlPacketKt.INSTANCE.m6384Int$paramsteering$classControlPacket();
        }
        this(i, j, j2, iM6385Int$paramthrottle$classControlPacket, iM6384Int$paramsteering$classControlPacket);
    }

    public final int getKind() {
        return this.kind;
    }

    public final long getToken() {
        return this.token;
    }

    public final long getSequence() {
        return this.sequence;
    }

    public final int getThrottle() {
        return this.throttle;
    }

    public final int getSteering() {
        return this.steering;
    }

    /* JADX WARN: Code duplicated, block: B:19:0x0076  */
    /* JADX WARN: Code duplicated, block: B:34:0x00a8  */
    public final byte[] encode() {
        boolean z;
        boolean z2;
        if (!SetsKt.setOf((Object[]) new Integer[]{1, 2, 3, 128, 129}).contains(Integer.valueOf(this.kind))) {
            throw new IllegalArgumentException("Failed requirement.".toString());
        }
        int iM6347Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire1$funencode$classControlPacket = LiveLiterals$ControlPacketKt.INSTANCE.m6347Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire1$funencode$classControlPacket();
        long jM6389Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire1$funencode$classControlPacket = LiveLiterals$ControlPacketKt.INSTANCE.m6389Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire1$funencode$classControlPacket();
        long j = this.token;
        if (((long) iM6347Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire1$funencode$classControlPacket) <= j && j <= jM6389Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire1$funencode$classControlPacket) {
            int iM6343Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classControlPacket = LiveLiterals$ControlPacketKt.INSTANCE.m6343Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classControlPacket();
            long jM6388Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classControlPacket = LiveLiterals$ControlPacketKt.INSTANCE.m6388Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classControlPacket();
            long j2 = this.sequence;
            if (((long) iM6343Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classControlPacket) <= j2 && j2 <= jM6388Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classControlPacket) {
                z = true;
            } else {
                z = false;
            }
        } else {
            z = false;
        }
        if (!z) {
            throw new IllegalArgumentException("Failed requirement.".toString());
        }
        int iM6348Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire2$funencode$classControlPacket = LiveLiterals$ControlPacketKt.INSTANCE.m6348Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire2$funencode$classControlPacket();
        int iM6365Int$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire2$funencode$classControlPacket = LiveLiterals$ControlPacketKt.INSTANCE.m6365Int$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire2$funencode$classControlPacket();
        int i = this.throttle;
        if (iM6348Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire2$funencode$classControlPacket <= i && i <= iM6365Int$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire2$funencode$classControlPacket) {
            int iM6344Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire2$funencode$classControlPacket = LiveLiterals$ControlPacketKt.INSTANCE.m6344Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire2$funencode$classControlPacket();
            int iM6362Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire2$funencode$classControlPacket = LiveLiterals$ControlPacketKt.INSTANCE.m6362Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire2$funencode$classControlPacket();
            int i2 = this.steering;
            z2 = iM6344Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire2$funencode$classControlPacket <= i2 && i2 <= iM6362Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire2$funencode$classControlPacket;
        }
        if (!z2) {
            throw new IllegalArgumentException("Failed requirement.".toString());
        }
        byte[] b = new byte[LiveLiterals$ControlPacketKt.INSTANCE.m6353Int$arg0$call$init$$$$this$callalso$funencode$classControlPacket()];
        b[LiveLiterals$ControlPacketKt.INSTANCE.m6366Int$arg0$callset$fun$anonymous$$arg0$callalso$funencode$classControlPacket()] = LiveLiterals$ControlPacketKt.INSTANCE.m6337Byte$arg1$callset$fun$anonymous$$arg0$callalso$funencode$classControlPacket();
        b[LiveLiterals$ControlPacketKt.INSTANCE.m6367Int$arg0$callset1$fun$anonymous$$arg0$callalso$funencode$classControlPacket()] = LiveLiterals$ControlPacketKt.INSTANCE.m6338Byte$arg1$callset1$fun$anonymous$$arg0$callalso$funencode$classControlPacket();
        b[LiveLiterals$ControlPacketKt.INSTANCE.m6368Int$arg0$callset2$fun$anonymous$$arg0$callalso$funencode$classControlPacket()] = LiveLiterals$ControlPacketKt.INSTANCE.m6339Byte$arg1$callset2$fun$anonymous$$arg0$callalso$funencode$classControlPacket();
        b[LiveLiterals$ControlPacketKt.INSTANCE.m6369Int$arg0$callset3$fun$anonymous$$arg0$callalso$funencode$classControlPacket()] = (byte) this.kind;
        for (int i3 = 0; i3 < 4; i3++) {
            b[LiveLiterals$ControlPacketKt.INSTANCE.m6340Int$$this$callplus$arg0$callset$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket() + i3] = (byte) (this.token >> (LiveLiterals$ControlPacketKt.INSTANCE.m6350Int$$this$calltimes$arg0$callshr$$this$calltoByte$arg1$callset$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket() * i3));
            b[LiveLiterals$ControlPacketKt.INSTANCE.m6341Int$$this$callplus$arg0$callset1$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket() + i3] = (byte) (this.sequence >> (LiveLiterals$ControlPacketKt.INSTANCE.m6351Int$$this$calltimes$arg0$callshr$$this$calltoByte$arg1$callset1$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket() * i3));
        }
        b[LiveLiterals$ControlPacketKt.INSTANCE.m6370Int$arg0$callset4$fun$anonymous$$arg0$callalso$funencode$classControlPacket()] = (byte) this.throttle;
        b[LiveLiterals$ControlPacketKt.INSTANCE.m6371Int$arg0$callset5$fun$anonymous$$arg0$callalso$funencode$classControlPacket()] = (byte) (this.throttle >> LiveLiterals$ControlPacketKt.INSTANCE.m6375Int$arg0$callshr$$this$calltoByte$arg1$callset5$fun$anonymous$$arg0$callalso$funencode$classControlPacket());
        b[LiveLiterals$ControlPacketKt.INSTANCE.m6372Int$arg0$callset6$fun$anonymous$$arg0$callalso$funencode$classControlPacket()] = (byte) this.steering;
        b[LiveLiterals$ControlPacketKt.INSTANCE.m6373Int$arg0$callset7$fun$anonymous$$arg0$callalso$funencode$classControlPacket()] = (byte) (this.steering >> LiveLiterals$ControlPacketKt.INSTANCE.m6376Int$arg0$callshr$$this$calltoByte$arg1$callset7$fun$anonymous$$arg0$callalso$funencode$classControlPacket());
        return b;
    }

    /* JADX INFO: compiled from: ControlPacket.kt */
    @Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0012\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\t\u001a\u0004\u0018\u00010\n2\u0006\u0010\u000b\u001a\u00020\fR\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\r"}, d2 = {"Lvea/raceremote/control/ControlPacket$Companion;", "", "()V", "ACK", "", "ARM", "DRIVE", "HELLO", "STOP", "decode", "Lvea/raceremote/control/ControlPacket;", "b", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
        }

        public final ControlPacket decode(byte[] b) {
            Intrinsics.checkNotNullParameter(b, "b");
            if (b.length == 16) {
                boolean z = false;
                if (b[0] == 82 && b[1] == 67 && b[LiveLiterals$ControlPacketKt.INSTANCE.m6357Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classControlPacket()] == ((byte) LiveLiterals$ControlPacketKt.INSTANCE.m6352Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classControlPacket())) {
                    ControlPacket p = new ControlPacket(b[LiveLiterals$ControlPacketKt.INSTANCE.m6356Int$arg0$callget$$this$calltoInt$$this$calland$arg0$call$init$$valp$fundecode$classCompanion$classControlPacket()] & LiveLiterals$ControlPacketKt.INSTANCE.m6355Int$arg0$calland$arg0$call$init$$valp$fundecode$classCompanion$classControlPacket(), decode$u32(b, LiveLiterals$ControlPacketKt.INSTANCE.m6381Int$arg0$callu32$arg1$call$init$$valp$fundecode$classCompanion$classControlPacket()), decode$u32(b, LiveLiterals$ControlPacketKt.INSTANCE.m6382Int$arg0$callu32$arg2$call$init$$valp$fundecode$classCompanion$classControlPacket()), decode$i16(b, LiveLiterals$ControlPacketKt.INSTANCE.m6358Int$arg0$calli16$arg3$call$init$$valp$fundecode$classCompanion$classControlPacket()), decode$i16(b, LiveLiterals$ControlPacketKt.INSTANCE.m6359Int$arg0$calli16$arg4$call$init$$valp$fundecode$classCompanion$classControlPacket()));
                    if (SetsKt.setOf((Object[]) new Integer[]{1, 2, 3, 128, 129}).contains(Integer.valueOf(p.getKind())) && p.getToken() != LiveLiterals$ControlPacketKt.INSTANCE.m6390Long$arg1$callEQEQ$$this$callnot$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket()) {
                        int iM6345Int$$this$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket = LiveLiterals$ControlPacketKt.INSTANCE.m6345Int$$this$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket();
                        int iM6363Int$arg0$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket = LiveLiterals$ControlPacketKt.INSTANCE.m6363Int$arg0$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket();
                        int throttle = p.getThrottle();
                        if (iM6345Int$$this$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket <= throttle && throttle <= iM6363Int$arg0$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket) {
                            int iM6346Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket = LiveLiterals$ControlPacketKt.INSTANCE.m6346Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket();
                            int iM6364Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket = LiveLiterals$ControlPacketKt.INSTANCE.m6364Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket();
                            int steering = p.getSteering();
                            if (iM6346Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket <= steering && steering <= iM6364Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket) {
                                z = true;
                            }
                        }
                    }
                    if (z) {
                        return p;
                    }
                    return null;
                }
            }
            return null;
        }

        private static final long decode$u32(byte[] $b, int offset) {
            Iterable $this$fold$iv = new IntRange(LiveLiterals$ControlPacketKt.INSTANCE.m6342Int$$this$callrangeTo$$$this$callfold$funu32$fundecode$classCompanion$classControlPacket(), LiveLiterals$ControlPacketKt.INSTANCE.m6361Int$arg0$callrangeTo$$$this$callfold$funu32$fundecode$classCompanion$classControlPacket());
            long initial$iv = LiveLiterals$ControlPacketKt.INSTANCE.m6387Long$arg0$callfold$funu32$fundecode$classCompanion$classControlPacket();
            long accumulator$iv = initial$iv;
            Iterator<Integer> it = $this$fold$iv.iterator();
            while (it.hasNext()) {
                int element$iv = ((IntIterator) it).nextInt();
                long n = accumulator$iv;
                accumulator$iv = n | ((((long) $b[offset + element$iv]) & LiveLiterals$ControlPacketKt.INSTANCE.m6386Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funu32$fundecode$classCompanion$classControlPacket()) << (LiveLiterals$ControlPacketKt.INSTANCE.m6349Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funu32$fundecode$classCompanion$classControlPacket() * element$iv));
            }
            return accumulator$iv;
        }

        private static final int decode$i16(byte[] $b, int offset) {
            return (short) (($b[offset] & LiveLiterals$ControlPacketKt.INSTANCE.m6354Int$arg0$calland$$this$callor$$this$calltoShort$$this$calltoInt$funi16$fundecode$classCompanion$classControlPacket()) | ($b[LiveLiterals$ControlPacketKt.INSTANCE.m6360Int$arg0$callplus$arg0$callget$$this$calltoInt$$this$callshl$arg0$callor$$this$calltoShort$$this$calltoInt$funi16$fundecode$classCompanion$classControlPacket() + offset] << LiveLiterals$ControlPacketKt.INSTANCE.m6374Int$arg0$callshl$arg0$callor$$this$calltoShort$$this$calltoInt$funi16$fundecode$classCompanion$classControlPacket()));
        }
    }
}
