package vea.raceremote.control;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import javax.net.SocketFactory;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: ControlSocketFactory.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0001¢\u0006\u0002\u0010\u0003J\b\u0010\u0004\u001a\u00020\u0005H\u0016J\u0018\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tH\u0016J(\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\tH\u0016J\u0018\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\f2\u0006\u0010\b\u001a\u00020\tH\u0016J(\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\f2\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\tH\u0016J\f\u0010\r\u001a\u00020\u0005*\u00020\u0005H\u0002R\u000e\u0010\u0002\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000e"}, d2 = {"Lvea/raceremote/control/ControlSocketFactory;", "Ljavax/net/SocketFactory;", "delegate", "(Ljavax/net/SocketFactory;)V", "createSocket", "Ljava/net/Socket;", "host", "Ljava/net/InetAddress;", "port", "", "local", "localPort", "", "immediate", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class ControlSocketFactory extends SocketFactory {
    public static final int $stable = LiveLiterals$ControlSocketFactoryKt.INSTANCE.m6403Int$classControlSocketFactory();
    private final SocketFactory delegate;

    public ControlSocketFactory(SocketFactory delegate) {
        Intrinsics.checkNotNullParameter(delegate, "delegate");
        this.delegate = delegate;
    }

    private final Socket immediate(Socket $this$immediate) throws SocketException {
        $this$immediate.setTcpNoDelay(LiveLiterals$ControlSocketFactoryKt.INSTANCE.m6402Boolean$arg0$callsetTcpNoDelay$fun$anonymous$$arg0$callapply$funimmediate$classControlSocketFactory());
        return $this$immediate;
    }

    @Override // javax.net.SocketFactory
    public Socket createSocket() throws IOException {
        Socket socketCreateSocket = this.delegate.createSocket();
        Intrinsics.checkNotNullExpressionValue(socketCreateSocket, "delegate.createSocket()");
        return immediate(socketCreateSocket);
    }

    @Override // javax.net.SocketFactory
    public Socket createSocket(String host, int port) throws IOException {
        Intrinsics.checkNotNullParameter(host, "host");
        Socket socketCreateSocket = this.delegate.createSocket(host, port);
        Intrinsics.checkNotNullExpressionValue(socketCreateSocket, "delegate.createSocket(host, port)");
        return immediate(socketCreateSocket);
    }

    @Override // javax.net.SocketFactory
    public Socket createSocket(String host, int port, InetAddress local, int localPort) throws IOException {
        Intrinsics.checkNotNullParameter(host, "host");
        Intrinsics.checkNotNullParameter(local, "local");
        Socket socketCreateSocket = this.delegate.createSocket(host, port, local, localPort);
        Intrinsics.checkNotNullExpressionValue(socketCreateSocket, "delegate.createSocket(ho…, port, local, localPort)");
        return immediate(socketCreateSocket);
    }

    @Override // javax.net.SocketFactory
    public Socket createSocket(InetAddress host, int port) throws IOException {
        Intrinsics.checkNotNullParameter(host, "host");
        Socket socketCreateSocket = this.delegate.createSocket(host, port);
        Intrinsics.checkNotNullExpressionValue(socketCreateSocket, "delegate.createSocket(host, port)");
        return immediate(socketCreateSocket);
    }

    @Override // javax.net.SocketFactory
    public Socket createSocket(InetAddress host, int port, InetAddress local, int localPort) throws IOException {
        Intrinsics.checkNotNullParameter(host, "host");
        Intrinsics.checkNotNullParameter(local, "local");
        Socket socketCreateSocket = this.delegate.createSocket(host, port, local, localPort);
        Intrinsics.checkNotNullExpressionValue(socketCreateSocket, "delegate.createSocket(ho…, port, local, localPort)");
        return immediate(socketCreateSocket);
    }
}
