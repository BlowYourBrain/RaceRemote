package vea.raceremote.control;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.CharsKt;

/* JADX INFO: compiled from: DiscoveryPacket.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u001b\b\u0087\b\u0018\u00002\u00020\u0001B9\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\b\b\u0002\u0010\n\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u000b\u001a\u00020\u0005¢\u0006\u0002\u0010\fJ\t\u0010\u0019\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001a\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001b\u001a\u00020\u0007HÆ\u0003J\t\u0010\u001c\u001a\u00020\tHÆ\u0003J\t\u0010\u001d\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001e\u001a\u00020\u0005HÆ\u0003JE\u0010\u001f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\n\u001a\u00020\u00032\b\b\u0002\u0010\u000b\u001a\u00020\u0005HÆ\u0001J\u0013\u0010 \u001a\u00020\t2\b\u0010!\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\"\u001a\u00020\u0005HÖ\u0001J\t\u0010#\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u000b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\u0015\u001a\u00020\u00038F¢\u0006\u0006\u001a\u0004\b\u0016\u0010\u0014R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0012R\u0011\u0010\n\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0014¨\u0006$"}, d2 = {"Lvea/raceremote/control/DiscoveredCar;", "", "host", "", "port", "", "chipId", "", "busy", "", "transport", "discoveryVersion", "(Ljava/lang/String;IJZLjava/lang/String;I)V", "getBusy", "()Z", "getChipId", "()J", "getDiscoveryVersion", "()I", "getHost", "()Ljava/lang/String;", "name", "getName", "getPort", "getTransport", "component1", "component2", "component3", "component4", "component5", "component6", "copy", "equals", "other", "hashCode", "toString", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final /* data */ class DiscoveredCar {
    public static final int $stable = LiveLiterals$DiscoveryPacketKt.INSTANCE.m6460Int$classDiscoveredCar();
    private final boolean busy;
    private final long chipId;
    private final int discoveryVersion;
    private final String host;
    private final int port;
    private final String transport;

    public static /* synthetic */ DiscoveredCar copy$default(DiscoveredCar discoveredCar, String str, int i, long j, boolean z, String str2, int i2, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            str = discoveredCar.host;
        }
        if ((i3 & 2) != 0) {
            i = discoveredCar.port;
        }
        int i4 = i;
        if ((i3 & 4) != 0) {
            j = discoveredCar.chipId;
        }
        long j2 = j;
        if ((i3 & 8) != 0) {
            z = discoveredCar.busy;
        }
        boolean z2 = z;
        if ((i3 & 16) != 0) {
            str2 = discoveredCar.transport;
        }
        String str3 = str2;
        if ((i3 & 32) != 0) {
            i2 = discoveredCar.discoveryVersion;
        }
        return discoveredCar.copy(str, i4, j2, z2, str3, i2);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getHost() {
        return this.host;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final int getPort() {
        return this.port;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final long getChipId() {
        return this.chipId;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final boolean getBusy() {
        return this.busy;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final String getTransport() {
        return this.transport;
    }

    /* JADX INFO: renamed from: component6, reason: from getter */
    public final int getDiscoveryVersion() {
        return this.discoveryVersion;
    }

    public final DiscoveredCar copy(String host, int port, long chipId, boolean busy, String transport, int discoveryVersion) {
        Intrinsics.checkNotNullParameter(host, "host");
        Intrinsics.checkNotNullParameter(transport, "transport");
        return new DiscoveredCar(host, port, chipId, busy, transport, discoveryVersion);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return LiveLiterals$DiscoveryPacketKt.INSTANCE.m6404Boolean$branch$when$funequals$classDiscoveredCar();
        }
        if (!(other instanceof DiscoveredCar)) {
            return LiveLiterals$DiscoveryPacketKt.INSTANCE.m6405Boolean$branch$when1$funequals$classDiscoveredCar();
        }
        DiscoveredCar discoveredCar = (DiscoveredCar) other;
        if (!Intrinsics.areEqual(this.host, discoveredCar.host)) {
            return LiveLiterals$DiscoveryPacketKt.INSTANCE.m6406Boolean$branch$when2$funequals$classDiscoveredCar();
        }
        if (this.port != discoveredCar.port) {
            return LiveLiterals$DiscoveryPacketKt.INSTANCE.m6407Boolean$branch$when3$funequals$classDiscoveredCar();
        }
        if (this.chipId != discoveredCar.chipId) {
            return LiveLiterals$DiscoveryPacketKt.INSTANCE.m6408Boolean$branch$when4$funequals$classDiscoveredCar();
        }
        if (this.busy != discoveredCar.busy) {
            return LiveLiterals$DiscoveryPacketKt.INSTANCE.m6409Boolean$branch$when5$funequals$classDiscoveredCar();
        }
        if (Intrinsics.areEqual(this.transport, discoveredCar.transport)) {
            return this.discoveryVersion != discoveredCar.discoveryVersion ? LiveLiterals$DiscoveryPacketKt.INSTANCE.m6411Boolean$branch$when7$funequals$classDiscoveredCar() : LiveLiterals$DiscoveryPacketKt.INSTANCE.m6412Boolean$funequals$classDiscoveredCar();
        }
        return LiveLiterals$DiscoveryPacketKt.INSTANCE.m6410Boolean$branch$when6$funequals$classDiscoveredCar();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v7, types: [int] */
    /* JADX WARN: Type inference failed for: r2v10 */
    /* JADX WARN: Type inference failed for: r2v11 */
    /* JADX WARN: Type inference failed for: r2v5, types: [int] */
    public int hashCode() {
        int iM6449Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classDiscoveredCar = LiveLiterals$DiscoveryPacketKt.INSTANCE.m6449Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classDiscoveredCar() * ((LiveLiterals$DiscoveryPacketKt.INSTANCE.m6448Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classDiscoveredCar() * ((LiveLiterals$DiscoveryPacketKt.INSTANCE.m6447Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classDiscoveredCar() * this.host.hashCode()) + Integer.hashCode(this.port))) + Long.hashCode(this.chipId));
        boolean z = this.busy;
        ?? r2 = z;
        if (z) {
            r2 = 1;
        }
        return (LiveLiterals$DiscoveryPacketKt.INSTANCE.m6451Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classDiscoveredCar() * ((LiveLiterals$DiscoveryPacketKt.INSTANCE.m6450Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classDiscoveredCar() * (iM6449Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classDiscoveredCar + r2)) + this.transport.hashCode())) + Integer.hashCode(this.discoveryVersion);
    }

    public String toString() {
        return LiveLiterals$DiscoveryPacketKt.INSTANCE.m6469String$0$str$funtoString$classDiscoveredCar() + LiveLiterals$DiscoveryPacketKt.INSTANCE.m6470String$1$str$funtoString$classDiscoveredCar() + this.host + LiveLiterals$DiscoveryPacketKt.INSTANCE.m6477String$3$str$funtoString$classDiscoveredCar() + LiveLiterals$DiscoveryPacketKt.INSTANCE.m6478String$4$str$funtoString$classDiscoveredCar() + this.port + LiveLiterals$DiscoveryPacketKt.INSTANCE.m6479String$6$str$funtoString$classDiscoveredCar() + LiveLiterals$DiscoveryPacketKt.INSTANCE.m6480String$7$str$funtoString$classDiscoveredCar() + this.chipId + LiveLiterals$DiscoveryPacketKt.INSTANCE.m6481String$9$str$funtoString$classDiscoveredCar() + LiveLiterals$DiscoveryPacketKt.INSTANCE.m6471String$10$str$funtoString$classDiscoveredCar() + this.busy + LiveLiterals$DiscoveryPacketKt.INSTANCE.m6472String$12$str$funtoString$classDiscoveredCar() + LiveLiterals$DiscoveryPacketKt.INSTANCE.m6473String$13$str$funtoString$classDiscoveredCar() + this.transport + LiveLiterals$DiscoveryPacketKt.INSTANCE.m6474String$15$str$funtoString$classDiscoveredCar() + LiveLiterals$DiscoveryPacketKt.INSTANCE.m6475String$16$str$funtoString$classDiscoveredCar() + this.discoveryVersion + LiveLiterals$DiscoveryPacketKt.INSTANCE.m6476String$18$str$funtoString$classDiscoveredCar();
    }

    public DiscoveredCar(String host, int port, long chipId, boolean busy, String transport, int discoveryVersion) {
        Intrinsics.checkNotNullParameter(host, "host");
        Intrinsics.checkNotNullParameter(transport, "transport");
        this.host = host;
        this.port = port;
        this.chipId = chipId;
        this.busy = busy;
        this.transport = transport;
        this.discoveryVersion = discoveryVersion;
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public /* synthetic */ DiscoveredCar(String str, int i, long j, boolean z, String str2, int i2, int i3, DefaultConstructorMarker defaultConstructorMarker) {
        String strM6486String$paramtransport$classDiscoveredCar;
        int iM6462Int$paramdiscoveryVersion$classDiscoveredCar;
        if ((i3 & 16) == 0) {
            strM6486String$paramtransport$classDiscoveredCar = str2;
        } else {
            strM6486String$paramtransport$classDiscoveredCar = LiveLiterals$DiscoveryPacketKt.INSTANCE.m6486String$paramtransport$classDiscoveredCar();
        }
        if ((i3 & 32) == 0) {
            iM6462Int$paramdiscoveryVersion$classDiscoveredCar = i2;
        } else {
            iM6462Int$paramdiscoveryVersion$classDiscoveredCar = LiveLiterals$DiscoveryPacketKt.INSTANCE.m6462Int$paramdiscoveryVersion$classDiscoveredCar();
        }
        this(str, i, j, z, strM6486String$paramtransport$classDiscoveredCar, iM6462Int$paramdiscoveryVersion$classDiscoveredCar);
    }

    public final boolean getBusy() {
        return this.busy;
    }

    public final long getChipId() {
        return this.chipId;
    }

    public final String getHost() {
        return this.host;
    }

    public final int getPort() {
        return this.port;
    }

    public final int getDiscoveryVersion() {
        return this.discoveryVersion;
    }

    public final String getTransport() {
        return this.transport;
    }

    public final String getName() {
        StringBuilder sbAppend = new StringBuilder().append(LiveLiterals$DiscoveryPacketKt.INSTANCE.m6468String$0$str$fun$getname$$get$valname$classDiscoveredCar());
        String string = Long.toString(this.chipId >>> LiveLiterals$DiscoveryPacketKt.INSTANCE.m6453Int$arg0$callushr$$$this$calltoString$1$str$fun$getname$$get$valname$classDiscoveredCar(), CharsKt.checkRadix(LiveLiterals$DiscoveryPacketKt.INSTANCE.m6452Int$arg0$calltoString$1$str$fun$getname$$get$valname$classDiscoveredCar()));
        Intrinsics.checkNotNullExpressionValue(string, "toString(this, checkRadix(radix))");
        return sbAppend.append(string).toString();
    }
}
