package vea.raceremote.control;

import java.util.Iterator;
import kotlin.Metadata;
import kotlin.collections.IntIterator;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

/* JADX INFO: compiled from: DiscoveryPacket.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0018\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\u0004J \u0010\n\u001a\u0004\u0018\u00010\u000b2\u0006\u0010\f\u001a\u00020\u00062\u0006\u0010\r\u001a\u00020\b2\u0006\u0010\u000e\u001a\u00020\u000fR\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0010"}, d2 = {"Lvea/raceremote/control/DiscoveryPacket;", "", "()V", "PORT", "", "query", "", "nonce", "", "version", "reply", "Lvea/raceremote/control/DiscoveredCar;", "bytes", "expectedNonce", "host", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class DiscoveryPacket {
    public static final int PORT = 3333;
    public static final DiscoveryPacket INSTANCE = new DiscoveryPacket();
    public static final int $stable = LiveLiterals$DiscoveryPacketKt.INSTANCE.m6461Int$classDiscoveryPacket();

    private DiscoveryPacket() {
    }

    public static /* synthetic */ byte[] query$default(DiscoveryPacket discoveryPacket, long j, int i, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            i = LiveLiterals$DiscoveryPacketKt.INSTANCE.m6463Int$paramversion$funquery$classDiscoveryPacket();
        }
        return discoveryPacket.query(j, i);
    }

    /* JADX WARN: Code duplicated, block: B:16:0x0033  */
    public final byte[] query(long nonce, int version) {
        boolean z;
        if (!(nonce <= LiveLiterals$DiscoveryPacketKt.INSTANCE.m6467Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$funquery$classDiscoveryPacket() && ((long) LiveLiterals$DiscoveryPacketKt.INSTANCE.m6428Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$funquery$classDiscoveryPacket()) <= nonce)) {
            z = false;
        } else if (version <= LiveLiterals$DiscoveryPacketKt.INSTANCE.m6445Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funquery$classDiscoveryPacket() && LiveLiterals$DiscoveryPacketKt.INSTANCE.m6427Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funquery$classDiscoveryPacket() <= version) {
            z = true;
        } else {
            z = false;
        }
        if (!z) {
            throw new IllegalArgumentException("Failed requirement.".toString());
        }
        byte[] bytes = new byte[12];
        bytes[0] = LiveLiterals$DiscoveryPacketKt.INSTANCE.m6413Byte$0$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket();
        bytes[1] = LiveLiterals$DiscoveryPacketKt.INSTANCE.m6414Byte$1$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket();
        bytes[2] = LiveLiterals$DiscoveryPacketKt.INSTANCE.m6417Byte$2$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket();
        bytes[3] = (byte) version;
        bytes[4] = LiveLiterals$DiscoveryPacketKt.INSTANCE.m6418Byte$4$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket();
        bytes[5] = LiveLiterals$DiscoveryPacketKt.INSTANCE.m6419Byte$5$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket();
        bytes[6] = LiveLiterals$DiscoveryPacketKt.INSTANCE.m6420Byte$6$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket();
        bytes[7] = LiveLiterals$DiscoveryPacketKt.INSTANCE.m6421Byte$7$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket();
        bytes[8] = LiveLiterals$DiscoveryPacketKt.INSTANCE.m6422Byte$8$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket();
        bytes[9] = LiveLiterals$DiscoveryPacketKt.INSTANCE.m6423Byte$9$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket();
        bytes[10] = LiveLiterals$DiscoveryPacketKt.INSTANCE.m6415Byte$10$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket();
        bytes[11] = LiveLiterals$DiscoveryPacketKt.INSTANCE.m6416Byte$11$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket();
        int iM6446Int$arg0$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket = LiveLiterals$DiscoveryPacketKt.INSTANCE.m6446Int$arg0$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket();
        for (int i = 0; i < iM6446Int$arg0$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket; i++) {
            int it = i;
            bytes[LiveLiterals$DiscoveryPacketKt.INSTANCE.m6425Int$$this$callplus$arg0$callset$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket() + it] = (byte) (nonce >>> (LiveLiterals$DiscoveryPacketKt.INSTANCE.m6430Int$$this$calltimes$arg0$callushr$$this$calltoByte$arg1$callset$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket() * it));
        }
        return bytes;
    }

    public final DiscoveredCar reply(byte[] bytes, long expectedNonce, String host) {
        String strM6485String$branch2$when$valtransport$funreply$classDiscoveryPacket;
        Intrinsics.checkNotNullParameter(bytes, "bytes");
        Intrinsics.checkNotNullParameter(host, "host");
        if (bytes.length == 24 && bytes[0] == 82 && bytes[1] == 82 && bytes[2] == 68) {
            byte b = bytes[3];
            if ((1 <= b && b < 3) && bytes[4] == 2 && bytes[5] == 0 && bytes[20] == 1) {
                byte b2 = bytes[21];
                if ((b2 >= 0 && b2 < 2) && bytes[LiveLiterals$DiscoveryPacketKt.INSTANCE.m6436Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$funreply$classDiscoveryPacket()] == ((byte) LiveLiterals$DiscoveryPacketKt.INSTANCE.m6431Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$funreply$classDiscoveryPacket())) {
                    int version = bytes[LiveLiterals$DiscoveryPacketKt.INSTANCE.m6441Int$arg0$callget$$this$calltoInt$valversion$funreply$classDiscoveryPacket()];
                    if (version == LiveLiterals$DiscoveryPacketKt.INSTANCE.m6454Int$arg1$callEQEQ$cond$cond$when$valtransport$funreply$classDiscoveryPacket() && bytes[LiveLiterals$DiscoveryPacketKt.INSTANCE.m6438Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond$when$valtransport$funreply$classDiscoveryPacket()] == ((byte) LiveLiterals$DiscoveryPacketKt.INSTANCE.m6433Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond$when$valtransport$funreply$classDiscoveryPacket())) {
                        strM6485String$branch2$when$valtransport$funreply$classDiscoveryPacket = LiveLiterals$DiscoveryPacketKt.INSTANCE.m6483String$branch$when$valtransport$funreply$classDiscoveryPacket();
                    } else if (version == LiveLiterals$DiscoveryPacketKt.INSTANCE.m6455Int$arg1$callEQEQ$cond$cond1$when$valtransport$funreply$classDiscoveryPacket() && bytes[LiveLiterals$DiscoveryPacketKt.INSTANCE.m6439Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond1$when$valtransport$funreply$classDiscoveryPacket()] == ((byte) LiveLiterals$DiscoveryPacketKt.INSTANCE.m6434Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond1$when$valtransport$funreply$classDiscoveryPacket())) {
                        strM6485String$branch2$when$valtransport$funreply$classDiscoveryPacket = LiveLiterals$DiscoveryPacketKt.INSTANCE.m6484String$branch1$when$valtransport$funreply$classDiscoveryPacket();
                    } else {
                        if (version != LiveLiterals$DiscoveryPacketKt.INSTANCE.m6456Int$arg1$callEQEQ$cond$cond2$when$valtransport$funreply$classDiscoveryPacket() || bytes[LiveLiterals$DiscoveryPacketKt.INSTANCE.m6440Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond2$when$valtransport$funreply$classDiscoveryPacket()] != ((byte) LiveLiterals$DiscoveryPacketKt.INSTANCE.m6435Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond2$when$valtransport$funreply$classDiscoveryPacket())) {
                            return null;
                        }
                        strM6485String$branch2$when$valtransport$funreply$classDiscoveryPacket = LiveLiterals$DiscoveryPacketKt.INSTANCE.m6485String$branch2$when$valtransport$funreply$classDiscoveryPacket();
                    }
                    String transport = strM6485String$branch2$when$valtransport$funreply$classDiscoveryPacket;
                    if (expectedNonce == 0 || reply$number(bytes, LiveLiterals$DiscoveryPacketKt.INSTANCE.m6443Int$arg0$callnumber$arg0$callEQEQ$$this$callnot$else$cond$if1$funreply$classDiscoveryPacket(), LiveLiterals$DiscoveryPacketKt.INSTANCE.m6458Int$arg1$callnumber$arg0$callEQEQ$$this$callnot$else$cond$if1$funreply$classDiscoveryPacket()) != expectedNonce) {
                        return null;
                    }
                    int port = (int) reply$number(bytes, LiveLiterals$DiscoveryPacketKt.INSTANCE.m6442Int$arg0$callnumber$$this$calltoInt$valport$funreply$classDiscoveryPacket(), LiveLiterals$DiscoveryPacketKt.INSTANCE.m6457Int$arg1$callnumber$$this$calltoInt$valport$funreply$classDiscoveryPacket());
                    long chipId = reply$number(bytes, LiveLiterals$DiscoveryPacketKt.INSTANCE.m6444Int$arg0$callnumber$valchipId$funreply$classDiscoveryPacket(), LiveLiterals$DiscoveryPacketKt.INSTANCE.m6459Int$arg1$callnumber$valchipId$funreply$classDiscoveryPacket());
                    if (port != 0) {
                        if (chipId <= LiveLiterals$DiscoveryPacketKt.INSTANCE.m6466Long$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if2$funreply$classDiscoveryPacket() && ((long) LiveLiterals$DiscoveryPacketKt.INSTANCE.m6426Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if2$funreply$classDiscoveryPacket()) <= chipId) {
                            if (!Intrinsics.areEqual(transport, LiveLiterals$DiscoveryPacketKt.INSTANCE.m6482String$arg1$callEQEQ$cond$cond$if3$funreply$classDiscoveryPacket()) || port == 3334) {
                                return new DiscoveredCar(host, port, chipId, bytes[LiveLiterals$DiscoveryPacketKt.INSTANCE.m6437Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$arg3$call$init$$funreply$classDiscoveryPacket()] == ((byte) LiveLiterals$DiscoveryPacketKt.INSTANCE.m6432Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$arg3$call$init$$funreply$classDiscoveryPacket()), transport, version);
                            }
                            return null;
                        }
                    }
                    return null;
                }
            }
        }
        return null;
    }

    private static final long reply$number(byte[] $bytes, int offset, int count) {
        Iterable $this$fold$iv = RangesKt.until(LiveLiterals$DiscoveryPacketKt.INSTANCE.m6424Int$$$this$calluntil$$$this$callfold$funnumber$funreply$classDiscoveryPacket(), count);
        long initial$iv = LiveLiterals$DiscoveryPacketKt.INSTANCE.m6465Long$arg0$callfold$funnumber$funreply$classDiscoveryPacket();
        long accumulator$iv = initial$iv;
        Iterator<Integer> it = $this$fold$iv.iterator();
        while (it.hasNext()) {
            int element$iv = ((IntIterator) it).nextInt();
            long value = accumulator$iv;
            accumulator$iv = value | ((((long) $bytes[offset + element$iv]) & LiveLiterals$DiscoveryPacketKt.INSTANCE.m6464Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$funreply$classDiscoveryPacket()) << (LiveLiterals$DiscoveryPacketKt.INSTANCE.m6429Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$funreply$classDiscoveryPacket() * element$iv));
        }
        return accumulator$iv;
    }
}
