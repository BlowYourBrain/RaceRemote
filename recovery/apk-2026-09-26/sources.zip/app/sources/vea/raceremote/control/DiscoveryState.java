package vea.raceremote.control;

import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: CarDiscovery.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u000e\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B)\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\u000e\b\u0002\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\b\b\u0002\u0010\u0007\u001a\u00020\b¢\u0006\u0002\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\u000f\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005HÆ\u0003J\t\u0010\u0012\u001a\u00020\bHÆ\u0003J-\u0010\u0013\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\u000e\b\u0002\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\b\b\u0002\u0010\u0007\u001a\u00020\bHÆ\u0001J\u0013\u0010\u0014\u001a\u00020\u00032\b\u0010\u0015\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0016\u001a\u00020\u0017HÖ\u0001J\t\u0010\u0018\u001a\u00020\bHÖ\u0001R\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u0019"}, d2 = {"Lvea/raceremote/control/DiscoveryState;", "", "searching", "", "cars", "", "Lvea/raceremote/control/DiscoveredCar;", "message", "", "(ZLjava/util/List;Ljava/lang/String;)V", "getCars", "()Ljava/util/List;", "getMessage", "()Ljava/lang/String;", "getSearching", "()Z", "component1", "component2", "component3", "copy", "equals", "other", "hashCode", "", "toString", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final /* data */ class DiscoveryState {
    public static final int $stable = LiveLiterals$CarDiscoveryKt.INSTANCE.m6271Int$classDiscoveryState();
    private final List<DiscoveredCar> cars;
    private final String message;
    private final boolean searching;

    public DiscoveryState() {
        this(false, null, null, 7);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ DiscoveryState copy$default(DiscoveryState discoveryState, boolean z, List list, String str, int i, Object obj) {
        if ((i & 1) != 0) {
            z = discoveryState.searching;
        }
        if ((i & 2) != 0) {
            list = discoveryState.cars;
        }
        if ((i & 4) != 0) {
            str = discoveryState.message;
        }
        return discoveryState.copy(z, list, str);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final boolean getSearching() {
        return this.searching;
    }

    public final List<DiscoveredCar> component2() {
        return this.cars;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getMessage() {
        return this.message;
    }

    public final DiscoveryState copy(boolean searching, List<DiscoveredCar> cars, String message) {
        Intrinsics.checkNotNullParameter(cars, "cars");
        Intrinsics.checkNotNullParameter(message, "message");
        return new DiscoveryState(searching, cars, message);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return LiveLiterals$CarDiscoveryKt.INSTANCE.m6253Boolean$branch$when$funequals$classDiscoveryState();
        }
        if (!(other instanceof DiscoveryState)) {
            return LiveLiterals$CarDiscoveryKt.INSTANCE.m6254Boolean$branch$when1$funequals$classDiscoveryState();
        }
        DiscoveryState discoveryState = (DiscoveryState) other;
        if (this.searching != discoveryState.searching) {
            return LiveLiterals$CarDiscoveryKt.INSTANCE.m6255Boolean$branch$when2$funequals$classDiscoveryState();
        }
        if (Intrinsics.areEqual(this.cars, discoveryState.cars)) {
            return !Intrinsics.areEqual(this.message, discoveryState.message) ? LiveLiterals$CarDiscoveryKt.INSTANCE.m6257Boolean$branch$when4$funequals$classDiscoveryState() : LiveLiterals$CarDiscoveryKt.INSTANCE.m6258Boolean$funequals$classDiscoveryState();
        }
        return LiveLiterals$CarDiscoveryKt.INSTANCE.m6256Boolean$branch$when3$funequals$classDiscoveryState();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [int] */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r1v2, types: [int] */
    public int hashCode() {
        boolean z = this.searching;
        ?? r0 = z;
        if (z) {
            r0 = 1;
        }
        return (LiveLiterals$CarDiscoveryKt.INSTANCE.m6265Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classDiscoveryState() * ((LiveLiterals$CarDiscoveryKt.INSTANCE.m6264Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classDiscoveryState() * r0) + this.cars.hashCode())) + this.message.hashCode();
    }

    public String toString() {
        return LiveLiterals$CarDiscoveryKt.INSTANCE.m6275String$0$str$funtoString$classDiscoveryState() + LiveLiterals$CarDiscoveryKt.INSTANCE.m6276String$1$str$funtoString$classDiscoveryState() + this.searching + LiveLiterals$CarDiscoveryKt.INSTANCE.m6278String$3$str$funtoString$classDiscoveryState() + LiveLiterals$CarDiscoveryKt.INSTANCE.m6279String$4$str$funtoString$classDiscoveryState() + this.cars + LiveLiterals$CarDiscoveryKt.INSTANCE.m6280String$6$str$funtoString$classDiscoveryState() + LiveLiterals$CarDiscoveryKt.INSTANCE.m6281String$7$str$funtoString$classDiscoveryState() + this.message + LiveLiterals$CarDiscoveryKt.INSTANCE.m6282String$9$str$funtoString$classDiscoveryState();
    }

    public DiscoveryState(boolean searching, List<DiscoveredCar> list, String message) {
        Intrinsics.checkNotNullParameter(list, "cars");
        Intrinsics.checkNotNullParameter(message, "message");
        this.searching = searching;
        this.cars = list;
        this.message = message;
    }

    public final List<DiscoveredCar> getCars() {
        return this.cars;
    }

    public final String getMessage() {
        return this.message;
    }

    public final boolean getSearching() {
        return this.searching;
    }
}
