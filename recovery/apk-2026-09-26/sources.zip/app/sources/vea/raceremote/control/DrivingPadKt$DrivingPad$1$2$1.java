package vea.raceremote.control;

import androidx.compose.runtime.State;
import androidx.compose.ui.input.pointer.AwaitPointerEventScope;
import androidx.compose.ui.input.pointer.PointerInputScope;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.RestrictedSuspendLambda;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;

/* JADX INFO: compiled from: DrivingPad.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@DebugMetadata(c = "vea.raceremote.control.DrivingPadKt$DrivingPad$1$2$1", f = "DrivingPad.kt", i = {}, l = {48}, m = "invokeSuspend", n = {}, s = {})
final class DrivingPadKt$DrivingPad$1$2$1 extends SuspendLambda implements Function2<PointerInputScope, Continuation<? super Unit>, Object> {
    final /* synthetic */ State<Function1<Float, Unit>> $change$delegate;
    final /* synthetic */ boolean $enabled;
    final /* synthetic */ boolean $vertical;
    private /* synthetic */ Object L$0;
    int label;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    DrivingPadKt$DrivingPad$1$2$1(boolean z, boolean z2, State<? extends Function1<? super Float, Unit>> state, Continuation<? super DrivingPadKt$DrivingPad$1$2$1> continuation) {
        super(2, continuation);
        this.$enabled = z;
        this.$vertical = z2;
        this.$change$delegate = state;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        DrivingPadKt$DrivingPad$1$2$1 drivingPadKt$DrivingPad$1$2$1 = new DrivingPadKt$DrivingPad$1$2$1(this.$enabled, this.$vertical, this.$change$delegate, continuation);
        drivingPadKt$DrivingPad$1$2$1.L$0 = obj;
        return drivingPadKt$DrivingPad$1$2$1;
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(PointerInputScope pointerInputScope, Continuation<? super Unit> continuation) {
        return ((DrivingPadKt$DrivingPad$1$2$1) create(pointerInputScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    /* JADX INFO: renamed from: vea.raceremote.control.DrivingPadKt$DrivingPad$1$2$1$1, reason: invalid class name */
    /* JADX INFO: compiled from: DrivingPad.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "vea.raceremote.control.DrivingPadKt$DrivingPad$1$2$1$1", f = "DrivingPad.kt", i = {0, 1, 1, 1, 1, 1, 2}, l = {50, 58, 74}, m = "invokeSuspend", n = {"$this$awaitPointerEventScope", "$this$awaitPointerEventScope", "down", "origin", "travel", "deadZone", "$this$awaitPointerEventScope"}, s = {"L$0", "L$0", "L$1", "J$0", "F$0", "F$1", "L$0"})
    static final class AnonymousClass1 extends RestrictedSuspendLambda implements Function2<AwaitPointerEventScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ State<Function1<Float, Unit>> $change$delegate;
        final /* synthetic */ boolean $vertical;
        float F$0;
        float F$1;
        long J$0;
        private /* synthetic */ Object L$0;
        Object L$1;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        AnonymousClass1(boolean z, State<? extends Function1<? super Float, Unit>> state, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.$vertical = z;
            this.$change$delegate = state;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            AnonymousClass1 anonymousClass1 = new AnonymousClass1(this.$vertical, this.$change$delegate, continuation);
            anonymousClass1.L$0 = obj;
            return anonymousClass1;
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(AwaitPointerEventScope awaitPointerEventScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(awaitPointerEventScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code duplicated, block: B:112:0x0136 A[SYNTHETIC] */
        /* JADX WARN: Code duplicated, block: B:33:0x011d A[Catch: all -> 0x026a, TRY_LEAVE, TryCatch #3 {all -> 0x026a, blocks: (B:30:0x0109, B:31:0x0117, B:33:0x011d), top: B:105:0x0109 }] */
        /* JADX WARN: Code duplicated, block: B:38:0x0137 A[LOOP:1: B:31:0x0117->B:38:0x0137, LOOP_END] */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:71:0x01f2 -> B:26:0x00e8). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:72:0x01fe -> B:73:0x0214). Please report as a decompilation issue!!! */
        /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
            jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
            	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
            	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
            	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
            */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object r19) {
            /*
                Method dump skipped, instruction units count: 658
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: vea.raceremote.control.DrivingPadKt$DrivingPad$1$2$1.AnonymousClass1.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object invokeSuspend(Object $result) {
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch (this.label) {
            case 0:
                ResultKt.throwOnFailure($result);
                PointerInputScope $this$pointerInput = (PointerInputScope) this.L$0;
                if (!this.$enabled) {
                    return Unit.INSTANCE;
                }
                this.label = 1;
                if ($this$pointerInput.awaitPointerEventScope(new AnonymousClass1(this.$vertical, this.$change$delegate, null), this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
                break;
                break;
            case 1:
                ResultKt.throwOnFailure($result);
                break;
            default:
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return Unit.INSTANCE;
    }
}
