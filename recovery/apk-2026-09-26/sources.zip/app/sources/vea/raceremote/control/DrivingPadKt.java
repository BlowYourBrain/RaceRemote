package vea.raceremote.control;

import androidx.compose.foundation.BackgroundKt;
import androidx.compose.foundation.CanvasKt;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.material.MaterialTheme;
import androidx.compose.material.TextKt;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.ProvidableCompositionLocal;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.SkippableUpdater;
import androidx.compose.runtime.SnapshotStateKt;
import androidx.compose.runtime.State;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.geometry.Offset;
import androidx.compose.ui.geometry.OffsetKt;
import androidx.compose.ui.geometry.Size;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.graphics.drawscope.DrawScope;
import androidx.compose.ui.input.pointer.SuspendingPointerInputFilterKt;
import androidx.compose.ui.layout.LayoutKt;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.platform.CompositionLocalsKt;
import androidx.compose.ui.platform.TestTagKt;
import androidx.compose.ui.platform.ViewConfiguration;
import androidx.compose.ui.semantics.SemanticsModifierKt;
import androidx.compose.ui.semantics.SemanticsPropertiesKt;
import androidx.compose.ui.semantics.SemanticsPropertyReceiver;
import androidx.compose.ui.unit.Density;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.unit.LayoutDirection;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

/* JADX INFO: compiled from: DrivingPad.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000*\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001aK\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u00052\b\b\u0002\u0010\t\u001a\u00020\n2\u0012\u0010\u000b\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00010\fH\u0007¢\u0006\u0002\u0010\r¨\u0006\u000e"}, d2 = {"DrivingPad", "", "label", "", "vertical", "", "value", "", "enabled", "modifier", "Landroidx/compose/ui/Modifier;", "onValueChange", "Lkotlin/Function1;", "(Ljava/lang/String;ZFZLandroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class DrivingPadKt {
    /* JADX WARN: Code duplicated, block: B:102:0x03b3  */
    /* JADX WARN: Code duplicated, block: B:105:0x0417  */
    /* JADX WARN: Code duplicated, block: B:108:0x0422  */
    /* JADX WARN: Code duplicated, block: B:109:0x0427  */
    /* JADX WARN: Code duplicated, block: B:113:0x0480  */
    /* JADX WARN: Code duplicated, block: B:116:0x048b  */
    /* JADX WARN: Code duplicated, block: B:117:0x0492  */
    /* JADX WARN: Code duplicated, block: B:121:0x04b8  */
    /* JADX WARN: Code duplicated, block: B:122:0x04bd  */
    /* JADX WARN: Code duplicated, block: B:126:0x0513  */
    /* JADX WARN: Code duplicated, block: B:130:0x051d  */
    /* JADX WARN: Code duplicated, block: B:132:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:69:0x00d6 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:70:0x00d8  */
    /* JADX WARN: Code duplicated, block: B:71:0x00df  */
    /* JADX WARN: Code duplicated, block: B:74:0x00e7  */
    /* JADX WARN: Code duplicated, block: B:77:0x00f7  */
    /* JADX WARN: Code duplicated, block: B:78:0x010f  */
    /* JADX WARN: Code duplicated, block: B:81:0x01f5  */
    /* JADX WARN: Code duplicated, block: B:84:0x0201  */
    /* JADX WARN: Code duplicated, block: B:85:0x0205  */
    /* JADX WARN: Code duplicated, block: B:88:0x026e  */
    /* JADX WARN: Code duplicated, block: B:92:0x0296  */
    /* JADX WARN: Code duplicated, block: B:94:0x0357  */
    /* JADX WARN: Code duplicated, block: B:95:0x035c  */
    /* JADX WARN: Code duplicated, block: B:98:0x03a0  */
    public static final void DrivingPad(final String label, final boolean vertical, final float value, final boolean enabled, Modifier modifier, final Function1<? super Float, Unit> function1, Composer $composer, final int $changed, final int i) {
        Modifier modifier2;
        int i2;
        int $dirty;
        Modifier modifier3;
        State change$delegate;
        long jM1659copywmQWz5c;
        final long accent;
        int $changed$iv;
        Function0<ComposeUiNode> constructor;
        int $changed$iv$iv$iv;
        LiveLiterals$DrivingPadKt liveLiterals$DrivingPadKt;
        String strM6517String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        boolean invalid$iv$iv;
        final float f;
        final boolean z;
        Object value$iv$iv;
        boolean invalid$iv$iv2;
        DrivingPadKt$DrivingPad$1$2$1 value$iv$iv2;
        boolean invalid$iv$iv3;
        Object value$iv$iv3;
        LiveLiterals$DrivingPadKt liveLiterals$DrivingPadKt2;
        String strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad;
        Object key1$iv;
        Object key2$iv;
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup;
        Intrinsics.checkNotNullParameter(label, "label");
        Intrinsics.checkNotNullParameter(function1, "onValueChange");
        Composer $composer2 = $composer.startRestartGroup(2076018843);
        ComposerKt.sourceInformation($composer2, "C(DrivingPad)P(1,5,4)33@1192L35,35@1345L3111:DrivingPad.kt#597736");
        int $dirty2 = $changed;
        if ((i & 1) != 0) {
            $dirty2 |= 6;
        } else if (($changed & 14) == 0) {
            $dirty2 |= $composer2.changed(label) ? 4 : 2;
        }
        if ((i & 2) != 0) {
            $dirty2 |= 48;
        } else if (($changed & 112) == 0) {
            $dirty2 |= $composer2.changed(vertical) ? 32 : 16;
        }
        if ((i & 4) != 0) {
            $dirty2 |= 384;
        } else if (($changed & 896) == 0) {
            $dirty2 |= $composer2.changed(value) ? 256 : 128;
        }
        if ((i & 8) != 0) {
            $dirty2 |= 3072;
        } else if (($changed & 7168) == 0) {
            $dirty2 |= $composer2.changed(enabled) ? 2048 : 1024;
        }
        int i3 = i & 16;
        if (i3 != 0) {
            $dirty2 |= 24576;
            modifier2 = modifier;
        } else if ((57344 & $changed) == 0) {
            modifier2 = modifier;
            $dirty2 |= $composer2.changed(modifier2) ? 16384 : 8192;
        } else {
            modifier2 = modifier;
        }
        if ((i & 32) == 0) {
            if ((458752 & $changed) == 0) {
                i2 = $composer2.changed(function1) ? 131072 : 65536;
            }
            $dirty = $dirty2;
            if ((374491 & $dirty) == 74898 || !$composer2.getSkipping()) {
                if (i3 != 0) {
                    modifier3 = Modifier.INSTANCE;
                } else {
                    modifier3 = modifier2;
                }
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventStart(2076018843, $dirty, -1, "vea.raceremote.control.DrivingPad (DrivingPad.kt:25)");
                }
                change$delegate = SnapshotStateKt.rememberUpdatedState(function1, $composer2, ($dirty >> 15) & 14);
                if (enabled) {
                    $composer2.startReplaceableGroup(-244214841);
                    ComposerKt.sourceInformation($composer2, "34@1272L6");
                    jM1659copywmQWz5c = MaterialTheme.INSTANCE.getColors($composer2, MaterialTheme.$stable).m981getPrimary0d7_KjU();
                } else {
                    $composer2.startReplaceableGroup(-244214797);
                    ComposerKt.sourceInformation($composer2, "34@1306L6");
                    long jM980getOnSurface0d7_KjU = MaterialTheme.INSTANCE.getColors($composer2, MaterialTheme.$stable).m980getOnSurface0d7_KjU();
                    jM1659copywmQWz5c = Color.m1659copywmQWz5c(jM980getOnSurface0d7_KjU, (14 & 1) != 0 ? Color.m1663getAlphaimpl(jM980getOnSurface0d7_KjU) : LiveLiterals$DrivingPadKt.INSTANCE.m6495Float$arg0$callcopy$else$if$valaccent$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(jM980getOnSurface0d7_KjU) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(jM980getOnSurface0d7_KjU) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(jM980getOnSurface0d7_KjU) : 0.0f);
                }
                $composer2.endReplaceableGroup();
                accent = jM1659copywmQWz5c;
                Alignment.Horizontal horizontalAlignment$iv = Alignment.INSTANCE.getCenterHorizontally();
                $changed$iv = (($dirty >> 12) & 14) | 384;
                $composer2.startReplaceableGroup(-483455358);
                ComposerKt.sourceInformation($composer2, "C(Column)P(2,3,1)77@3880L61,78@3946L133:Column.kt#2w3rfo");
                Arrangement.Vertical verticalArrangement$iv = Arrangement.INSTANCE.getTop();
                MeasurePolicy measurePolicy$iv = ColumnKt.columnMeasurePolicy(verticalArrangement$iv, horizontalAlignment$iv, $composer2, (($changed$iv >> 3) & 14) | (($changed$iv >> 3) & 112));
                int $changed$iv$iv = ($changed$iv << 3) & 112;
                $composer2.startReplaceableGroup(-1323940314);
                ComposerKt.sourceInformation($composer2, "C(Layout)P(!1,2)74@2915L7,75@2970L7,76@3029L7,77@3041L460:Layout.kt#80mrfh");
                ProvidableCompositionLocal<Density> localDensity = CompositionLocalsKt.getLocalDensity();
                ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
                Object objConsume = $composer2.consume(localDensity);
                ComposerKt.sourceInformationMarkerEnd($composer2);
                Density density$iv$iv = (Density) objConsume;
                ProvidableCompositionLocal<LayoutDirection> localLayoutDirection = CompositionLocalsKt.getLocalLayoutDirection();
                ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
                Object objConsume2 = $composer2.consume(localLayoutDirection);
                ComposerKt.sourceInformationMarkerEnd($composer2);
                LayoutDirection layoutDirection$iv$iv = (LayoutDirection) objConsume2;
                ProvidableCompositionLocal<ViewConfiguration> localViewConfiguration = CompositionLocalsKt.getLocalViewConfiguration();
                ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
                Object objConsume3 = $composer2.consume(localViewConfiguration);
                ComposerKt.sourceInformationMarkerEnd($composer2);
                ViewConfiguration viewConfiguration$iv$iv = (ViewConfiguration) objConsume3;
                constructor = ComposeUiNode.INSTANCE.getConstructor();
                Function3<SkippableUpdater<ComposeUiNode>, Composer, Integer, Unit> function3MaterializerOf = LayoutKt.materializerOf(modifier3);
                $changed$iv$iv$iv = (($changed$iv$iv << 9) & 7168) | 6;
                if (!($composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                $composer2.startReusableNode();
                if ($composer2.getInserting()) {
                    $composer2.createNode(constructor);
                } else {
                    $composer2.useNode();
                }
                $composer2.disableReusing();
                Composer $this$Layout_u24lambda_u2d0$iv$iv = Updater.m1304constructorimpl($composer2);
                Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, measurePolicy$iv, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, density$iv$iv, ComposeUiNode.INSTANCE.getSetDensity());
                Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, layoutDirection$iv$iv, ComposeUiNode.INSTANCE.getSetLayoutDirection());
                Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, viewConfiguration$iv$iv, ComposeUiNode.INSTANCE.getSetViewConfiguration());
                $composer2.enableReusing();
                function3MaterializerOf.invoke(SkippableUpdater.m1294boximpl(SkippableUpdater.m1295constructorimpl($composer2)), $composer2, Integer.valueOf(($changed$iv$iv$iv >> 3) & 112));
                $composer2.startReplaceableGroup(2058660585);
                $composer2.startReplaceableGroup(-1163856341);
                ComposerKt.sourceInformation($composer2, "C79@3994L9:Column.kt#2w3rfo");
                if ((($changed$iv$iv$iv >> 9) & 14 & 11) == 2 || !$composer2.getSkipping()) {
                    int i4 = (($changed$iv >> 6) & 112) | 6;
                    ColumnScope $this$DrivingPad_u24lambda_u244 = ColumnScopeInstance.INSTANCE;
                    ComposerKt.sourceInformationMarkerStart($composer2, 216050297, "C36@1424L11,38@1524L6,40@1686L213,45@1945L1914,76@3861L472,37@1444L2889,84@4431L10,84@4342L108:DrivingPad.kt#597736");
                    TextKt.m1249TextfLXpl1I(label, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, null, $composer2, $dirty & 14, 0, 65534);
                    Modifier modifierWeight$default = ColumnScope.weight$default($this$DrivingPad_u24lambda_u244, SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), LiveLiterals$DrivingPadKt.INSTANCE.m6499Float$arg0$callweight$$$this$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), false, 2, null);
                    long jM980getOnSurface0d7_KjU2 = MaterialTheme.INSTANCE.getColors($composer2, MaterialTheme.$stable).m980getOnSurface0d7_KjU();
                    long jM1659copywmQWz5c2 = Color.m1659copywmQWz5c(jM980getOnSurface0d7_KjU2, (14 & 1) != 0 ? Color.m1663getAlphaimpl(jM980getOnSurface0d7_KjU2) : LiveLiterals$DrivingPadKt.INSTANCE.m6492Float$arg0$callcopy$arg0$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(jM980getOnSurface0d7_KjU2) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(jM980getOnSurface0d7_KjU2) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(jM980getOnSurface0d7_KjU2) : 0.0f);
                    int $this$dp$iv = LiveLiterals$DrivingPadKt.INSTANCE.m6508Int$$$this$call$getdp$$arg0$callRoundedCornerShape$arg1$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                    Modifier modifierM179backgroundbw27NRU = BackgroundKt.m179backgroundbw27NRU(modifierWeight$default, jM1659copywmQWz5c2, RoundedCornerShapeKt.m677RoundedCornerShape0680j_4(Dp.m4046constructorimpl($this$dp$iv)));
                    liveLiterals$DrivingPadKt = LiveLiterals$DrivingPadKt.INSTANCE;
                    if (vertical) {
                        strM6517String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt.m6515String$branch$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                    } else {
                        strM6517String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt.m6517String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                    }
                    Modifier modifierTestTag = TestTagKt.testTag(modifierM179backgroundbw27NRU, strM6517String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad);
                    Object key2$iv2 = Float.valueOf(value);
                    Object key3$iv = Boolean.valueOf(enabled);
                    int i5 = ($dirty & 14) | (($dirty >> 3) & 112) | (($dirty >> 3) & 896);
                    $composer2.startReplaceableGroup(1618982084);
                    ComposerKt.sourceInformation($composer2, "C(remember)P(1,2,3):Composables.kt#9igjgp");
                    invalid$iv$iv = $composer2.changed(label) | $composer2.changed(key2$iv2) | $composer2.changed(key3$iv);
                    Object it$iv$iv = $composer2.rememberedValue();
                    if (!invalid$iv$iv || it$iv$iv == Composer.INSTANCE.getEmpty()) {
                        f = value;
                        z = enabled;
                        value$iv$iv = new Function1<SemanticsPropertyReceiver, Unit>() { // from class: vea.raceremote.control.DrivingPadKt$DrivingPad$1$1$1
                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            {
                                super(1);
                            }

                            @Override // kotlin.jvm.functions.Function1
                            public /* bridge */ /* synthetic */ Unit invoke(SemanticsPropertyReceiver semanticsPropertyReceiver) {
                                invoke2(semanticsPropertyReceiver);
                                return Unit.INSTANCE;
                            }

                            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                            public final void invoke2(SemanticsPropertyReceiver $this$semantics) {
                                Intrinsics.checkNotNullParameter($this$semantics, "$this$semantics");
                                SemanticsPropertiesKt.setContentDescription($this$semantics, label + LiveLiterals$DrivingPadKt.INSTANCE.m6512String$1$str$arg0$call$setcontentDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                                SemanticsPropertiesKt.setStateDescription($this$semantics, ((int) (f * LiveLiterals$DrivingPadKt.INSTANCE.m6511Int$arg0$calltimes$$this$calltoInt$0$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad())) + LiveLiterals$DrivingPadKt.INSTANCE.m6513String$1$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                                if (!z) {
                                    SemanticsPropertiesKt.disabled($this$semantics);
                                }
                            }
                        };
                        $composer2.updateRememberedValue(value$iv$iv);
                    } else {
                        value$iv$iv = it$iv$iv;
                        f = value;
                        z = enabled;
                    }
                    $composer2.endReplaceableGroup();
                    Modifier modifierSemantics$default = SemanticsModifierKt.semantics$default(modifierTestTag, false, (Function1) value$iv$iv, 1, null);
                    Boolean boolValueOf = Boolean.valueOf(enabled);
                    Boolean boolValueOf2 = Boolean.valueOf(vertical);
                    Object key1$iv2 = Boolean.valueOf(enabled);
                    Object key2$iv3 = Boolean.valueOf(vertical);
                    int i6 = (($dirty >> 9) & 14) | ($dirty & 112);
                    $composer2.startReplaceableGroup(1618982084);
                    ComposerKt.sourceInformation($composer2, "C(remember)P(1,2,3):Composables.kt#9igjgp");
                    invalid$iv$iv2 = $composer2.changed(key1$iv2) | $composer2.changed(key2$iv3) | $composer2.changed(change$delegate);
                    value$iv$iv2 = $composer2.rememberedValue();
                    if (!invalid$iv$iv2) {
                        key2$iv = Composer.INSTANCE.getEmpty();
                        if (value$iv$iv2 == key2$iv) {
                        }
                        $composer2.endReplaceableGroup();
                        Modifier modifierPointerInput = SuspendingPointerInputFilterKt.pointerInput(modifierSemantics$default, boolValueOf, boolValueOf2, (Function2) value$iv$iv2);
                        Object key1$iv3 = Boolean.valueOf(vertical);
                        Object key2$iv4 = Color.m1651boximpl(accent);
                        Object key3$iv2 = Float.valueOf(value);
                        int i7 = (($dirty >> 3) & 14) | ($dirty & 896);
                        $composer2.startReplaceableGroup(1618982084);
                        ComposerKt.sourceInformation($composer2, "C(remember)P(1,2,3):Composables.kt#9igjgp");
                        invalid$iv$iv3 = $composer2.changed(key1$iv3) | $composer2.changed(key2$iv4) | $composer2.changed(key3$iv2);
                        value$iv$iv3 = $composer2.rememberedValue();
                        if (!invalid$iv$iv3) {
                            key1$iv = Composer.INSTANCE.getEmpty();
                            if (value$iv$iv3 == key1$iv) {
                            }
                            $composer2.endReplaceableGroup();
                            CanvasKt.Canvas(modifierPointerInput, (Function1) value$iv$iv3, $composer2, 0);
                            liveLiterals$DrivingPadKt2 = LiveLiterals$DrivingPadKt.INSTANCE;
                            if (vertical) {
                                strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6514String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                            } else {
                                strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                            }
                            TextKt.m1249TextfLXpl1I(strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, MaterialTheme.INSTANCE.getTypography($composer2, MaterialTheme.$stable).getCaption(), $composer2, 0, 0, 32766);
                            ComposerKt.sourceInformationMarkerEnd($composer2);
                        }
                        value$iv$iv3 = (Function1) new Function1<DrawScope, Unit>() { // from class: vea.raceremote.control.DrivingPadKt$DrivingPad$1$3$1
                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            {
                                super(1);
                            }

                            @Override // kotlin.jvm.functions.Function1
                            public /* bridge */ /* synthetic */ Unit invoke(DrawScope drawScope) {
                                invoke2(drawScope);
                                return Unit.INSTANCE;
                            }

                            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                            public final void invoke2(DrawScope $this$Canvas) {
                                Intrinsics.checkNotNullParameter($this$Canvas, "$this$Canvas");
                                int $this$dp$iv2 = LiveLiterals$DrivingPadKt.INSTANCE.m6507Int$$$this$call$getdp$$$$this$calltoPx$valradius$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                                float radius = $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv2));
                                float fM1491getHeightimpl = ((vertical ? Size.m1491getHeightimpl($this$Canvas.mo2155getSizeNHjbRc()) : Size.m1494getWidthimpl($this$Canvas.mo2155getSizeNHjbRc())) / LiveLiterals$DrivingPadKt.INSTANCE.m6509Int$arg0$calldiv$$this$callminus$$this$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad()) - radius;
                                int $this$dp$iv3 = LiveLiterals$DrivingPadKt.INSTANCE.m6504Int$$$this$call$getdp$$$$this$calltoPx$arg0$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                                float travel = RangesKt.coerceAtLeast(fM1491getHeightimpl - $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv3)), LiveLiterals$DrivingPadKt.INSTANCE.m6490Float$arg0$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                                long delta = vertical ? OffsetKt.Offset(LiveLiterals$DrivingPadKt.INSTANCE.m6488Float$arg0$callOffset$branch$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), -travel) : OffsetKt.Offset(travel, LiveLiterals$DrivingPadKt.INSTANCE.m6500Float$arg1$callOffset$else$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                                long j = accent;
                                long jM1659copywmQWz5c3 = Color.m1659copywmQWz5c(j, (14 & 1) != 0 ? Color.m1663getAlphaimpl(j) : LiveLiterals$DrivingPadKt.INSTANCE.m6494Float$arg0$callcopy$arg0$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(j) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(j) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(j) : 0.0f);
                                long jM1429minusMKHz9U = Offset.m1429minusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), delta);
                                long jM1430plusMKHz9U = Offset.m1430plusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), delta);
                                int $this$dp$iv4 = LiveLiterals$DrivingPadKt.INSTANCE.m6506Int$$$this$call$getdp$$$$this$calltoPx$arg3$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                                DrawScope.m2142drawLineNGM6Ib0$default($this$Canvas, jM1659copywmQWz5c3, jM1429minusMKHz9U, jM1430plusMKHz9U, $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv4)), 0, null, 0.0f, null, 0, 496, null);
                                long j2 = accent;
                                long jM1659copywmQWz5c4 = Color.m1659copywmQWz5c(j2, (14 & 1) != 0 ? Color.m1663getAlphaimpl(j2) : LiveLiterals$DrivingPadKt.INSTANCE.m6493Float$arg0$callcopy$arg0$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(j2) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(j2) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(j2) : 0.0f);
                                int $this$dp$iv5 = LiveLiterals$DrivingPadKt.INSTANCE.m6505Int$$$this$call$getdp$$$$this$calltoPx$arg1$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                                DrawScope.m2137drawCircleVaOC9Bg$default($this$Canvas, jM1659copywmQWz5c4, $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv5)), $this$Canvas.mo2154getCenterF1C5BW0(), 0.0f, null, null, 0, 120, null);
                                DrawScope.m2137drawCircleVaOC9Bg$default($this$Canvas, accent, radius, Offset.m1430plusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), Offset.m1432timestuRUvjQ(delta, f)), 0.0f, null, null, 0, 120, null);
                            }
                        };
                        $composer2.updateRememberedValue(value$iv$iv3);
                        $composer2.endReplaceableGroup();
                        CanvasKt.Canvas(modifierPointerInput, (Function1) value$iv$iv3, $composer2, 0);
                        liveLiterals$DrivingPadKt2 = LiveLiterals$DrivingPadKt.INSTANCE;
                        if (vertical) {
                            strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6514String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        } else {
                            strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        }
                        TextKt.m1249TextfLXpl1I(strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, MaterialTheme.INSTANCE.getTypography($composer2, MaterialTheme.$stable).getCaption(), $composer2, 0, 0, 32766);
                        ComposerKt.sourceInformationMarkerEnd($composer2);
                    }
                    value$iv$iv2 = new DrivingPadKt$DrivingPad$1$2$1(z, vertical, change$delegate, null);
                    $composer2.updateRememberedValue(value$iv$iv2);
                    $composer2.endReplaceableGroup();
                    Modifier modifierPointerInput2 = SuspendingPointerInputFilterKt.pointerInput(modifierSemantics$default, boolValueOf, boolValueOf2, (Function2) value$iv$iv2);
                    Object key1$iv4 = Boolean.valueOf(vertical);
                    Object key2$iv5 = Color.m1651boximpl(accent);
                    Object key3$iv3 = Float.valueOf(value);
                    int i8 = (($dirty >> 3) & 14) | ($dirty & 896);
                    $composer2.startReplaceableGroup(1618982084);
                    ComposerKt.sourceInformation($composer2, "C(remember)P(1,2,3):Composables.kt#9igjgp");
                    invalid$iv$iv3 = $composer2.changed(key1$iv4) | $composer2.changed(key2$iv5) | $composer2.changed(key3$iv3);
                    value$iv$iv3 = $composer2.rememberedValue();
                    if (!invalid$iv$iv3) {
                        key1$iv = Composer.INSTANCE.getEmpty();
                        if (value$iv$iv3 == key1$iv) {
                        }
                        $composer2.endReplaceableGroup();
                        CanvasKt.Canvas(modifierPointerInput2, (Function1) value$iv$iv3, $composer2, 0);
                        liveLiterals$DrivingPadKt2 = LiveLiterals$DrivingPadKt.INSTANCE;
                        if (vertical) {
                            strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6514String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        } else {
                            strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        }
                        TextKt.m1249TextfLXpl1I(strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, MaterialTheme.INSTANCE.getTypography($composer2, MaterialTheme.$stable).getCaption(), $composer2, 0, 0, 32766);
                        ComposerKt.sourceInformationMarkerEnd($composer2);
                    }
                    value$iv$iv3 = (Function1) new Function1<DrawScope, Unit>() { // from class: vea.raceremote.control.DrivingPadKt$DrivingPad$1$3$1
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(1);
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public /* bridge */ /* synthetic */ Unit invoke(DrawScope drawScope) {
                            invoke2(drawScope);
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2(DrawScope $this$Canvas) {
                            Intrinsics.checkNotNullParameter($this$Canvas, "$this$Canvas");
                            int $this$dp$iv2 = LiveLiterals$DrivingPadKt.INSTANCE.m6507Int$$$this$call$getdp$$$$this$calltoPx$valradius$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                            float radius = $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv2));
                            float fM1491getHeightimpl = ((vertical ? Size.m1491getHeightimpl($this$Canvas.mo2155getSizeNHjbRc()) : Size.m1494getWidthimpl($this$Canvas.mo2155getSizeNHjbRc())) / LiveLiterals$DrivingPadKt.INSTANCE.m6509Int$arg0$calldiv$$this$callminus$$this$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad()) - radius;
                            int $this$dp$iv3 = LiveLiterals$DrivingPadKt.INSTANCE.m6504Int$$$this$call$getdp$$$$this$calltoPx$arg0$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                            float travel = RangesKt.coerceAtLeast(fM1491getHeightimpl - $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv3)), LiveLiterals$DrivingPadKt.INSTANCE.m6490Float$arg0$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            long delta = vertical ? OffsetKt.Offset(LiveLiterals$DrivingPadKt.INSTANCE.m6488Float$arg0$callOffset$branch$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), -travel) : OffsetKt.Offset(travel, LiveLiterals$DrivingPadKt.INSTANCE.m6500Float$arg1$callOffset$else$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            long j = accent;
                            long jM1659copywmQWz5c3 = Color.m1659copywmQWz5c(j, (14 & 1) != 0 ? Color.m1663getAlphaimpl(j) : LiveLiterals$DrivingPadKt.INSTANCE.m6494Float$arg0$callcopy$arg0$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(j) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(j) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(j) : 0.0f);
                            long jM1429minusMKHz9U = Offset.m1429minusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), delta);
                            long jM1430plusMKHz9U = Offset.m1430plusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), delta);
                            int $this$dp$iv4 = LiveLiterals$DrivingPadKt.INSTANCE.m6506Int$$$this$call$getdp$$$$this$calltoPx$arg3$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                            DrawScope.m2142drawLineNGM6Ib0$default($this$Canvas, jM1659copywmQWz5c3, jM1429minusMKHz9U, jM1430plusMKHz9U, $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv4)), 0, null, 0.0f, null, 0, 496, null);
                            long j2 = accent;
                            long jM1659copywmQWz5c4 = Color.m1659copywmQWz5c(j2, (14 & 1) != 0 ? Color.m1663getAlphaimpl(j2) : LiveLiterals$DrivingPadKt.INSTANCE.m6493Float$arg0$callcopy$arg0$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(j2) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(j2) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(j2) : 0.0f);
                            int $this$dp$iv5 = LiveLiterals$DrivingPadKt.INSTANCE.m6505Int$$$this$call$getdp$$$$this$calltoPx$arg1$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                            DrawScope.m2137drawCircleVaOC9Bg$default($this$Canvas, jM1659copywmQWz5c4, $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv5)), $this$Canvas.mo2154getCenterF1C5BW0(), 0.0f, null, null, 0, 120, null);
                            DrawScope.m2137drawCircleVaOC9Bg$default($this$Canvas, accent, radius, Offset.m1430plusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), Offset.m1432timestuRUvjQ(delta, f)), 0.0f, null, null, 0, 120, null);
                        }
                    };
                    $composer2.updateRememberedValue(value$iv$iv3);
                    $composer2.endReplaceableGroup();
                    CanvasKt.Canvas(modifierPointerInput2, (Function1) value$iv$iv3, $composer2, 0);
                    liveLiterals$DrivingPadKt2 = LiveLiterals$DrivingPadKt.INSTANCE;
                    if (vertical) {
                        strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6514String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                    } else {
                        strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                    }
                    TextKt.m1249TextfLXpl1I(strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, MaterialTheme.INSTANCE.getTypography($composer2, MaterialTheme.$stable).getCaption(), $composer2, 0, 0, 32766);
                    ComposerKt.sourceInformationMarkerEnd($composer2);
                } else {
                    $composer2.skipToGroupEnd();
                }
                $composer2.endReplaceableGroup();
                $composer2.endReplaceableGroup();
                $composer2.endNode();
                $composer2.endReplaceableGroup();
                $composer2.endReplaceableGroup();
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            } else {
                $composer2.skipToGroupEnd();
                modifier3 = modifier2;
                $composer2 = $composer2;
            }
            scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
            if (scopeUpdateScopeEndRestartGroup == null) {
                return;
            }
            final Modifier modifier4 = modifier3;
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.control.DrivingPadKt.DrivingPad.2
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                /* JADX WARN: Multi-variable type inference failed */
                {
                    super(2);
                }

                @Override // kotlin.jvm.functions.Function2
                public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                    invoke(composer, num.intValue());
                    return Unit.INSTANCE;
                }

                public final void invoke(Composer composer, int i9) {
                    DrivingPadKt.DrivingPad(label, vertical, value, enabled, modifier4, function1, composer, $changed | 1, i);
                }
            });
        }
        i2 = 196608;
        $dirty2 |= i2;
        $dirty = $dirty2;
        if ((374491 & $dirty) == 74898) {
            if (i3 != 0) {
                modifier3 = Modifier.INSTANCE;
            } else {
                modifier3 = modifier2;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(2076018843, $dirty, -1, "vea.raceremote.control.DrivingPad (DrivingPad.kt:25)");
            }
            change$delegate = SnapshotStateKt.rememberUpdatedState(function1, $composer2, ($dirty >> 15) & 14);
            if (enabled) {
                $composer2.startReplaceableGroup(-244214841);
                ComposerKt.sourceInformation($composer2, "34@1272L6");
                jM1659copywmQWz5c = MaterialTheme.INSTANCE.getColors($composer2, MaterialTheme.$stable).m981getPrimary0d7_KjU();
            } else {
                $composer2.startReplaceableGroup(-244214797);
                ComposerKt.sourceInformation($composer2, "34@1306L6");
                long jM980getOnSurface0d7_KjU3 = MaterialTheme.INSTANCE.getColors($composer2, MaterialTheme.$stable).m980getOnSurface0d7_KjU();
                jM1659copywmQWz5c = Color.m1659copywmQWz5c(jM980getOnSurface0d7_KjU3, (14 & 1) != 0 ? Color.m1663getAlphaimpl(jM980getOnSurface0d7_KjU3) : LiveLiterals$DrivingPadKt.INSTANCE.m6495Float$arg0$callcopy$else$if$valaccent$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(jM980getOnSurface0d7_KjU3) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(jM980getOnSurface0d7_KjU3) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(jM980getOnSurface0d7_KjU3) : 0.0f);
            }
            $composer2.endReplaceableGroup();
            accent = jM1659copywmQWz5c;
            Alignment.Horizontal horizontalAlignment$iv2 = Alignment.INSTANCE.getCenterHorizontally();
            $changed$iv = (($dirty >> 12) & 14) | 384;
            $composer2.startReplaceableGroup(-483455358);
            ComposerKt.sourceInformation($composer2, "C(Column)P(2,3,1)77@3880L61,78@3946L133:Column.kt#2w3rfo");
            Arrangement.Vertical verticalArrangement$iv2 = Arrangement.INSTANCE.getTop();
            MeasurePolicy measurePolicy$iv2 = ColumnKt.columnMeasurePolicy(verticalArrangement$iv2, horizontalAlignment$iv2, $composer2, (($changed$iv >> 3) & 14) | (($changed$iv >> 3) & 112));
            int $changed$iv$iv2 = ($changed$iv << 3) & 112;
            $composer2.startReplaceableGroup(-1323940314);
            ComposerKt.sourceInformation($composer2, "C(Layout)P(!1,2)74@2915L7,75@2970L7,76@3029L7,77@3041L460:Layout.kt#80mrfh");
            ProvidableCompositionLocal<Density> localDensity2 = CompositionLocalsKt.getLocalDensity();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume4 = $composer2.consume(localDensity2);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            Density density$iv$iv2 = (Density) objConsume4;
            ProvidableCompositionLocal<LayoutDirection> localLayoutDirection2 = CompositionLocalsKt.getLocalLayoutDirection();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume5 = $composer2.consume(localLayoutDirection2);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            LayoutDirection layoutDirection$iv$iv2 = (LayoutDirection) objConsume5;
            ProvidableCompositionLocal<ViewConfiguration> localViewConfiguration2 = CompositionLocalsKt.getLocalViewConfiguration();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume6 = $composer2.consume(localViewConfiguration2);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ViewConfiguration viewConfiguration$iv$iv2 = (ViewConfiguration) objConsume6;
            constructor = ComposeUiNode.INSTANCE.getConstructor();
            Function3<SkippableUpdater<ComposeUiNode>, Composer, Integer, Unit> function3MaterializerOf2 = LayoutKt.materializerOf(modifier3);
            $changed$iv$iv$iv = (($changed$iv$iv2 << 9) & 7168) | 6;
            if (!($composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer2.startReusableNode();
            if ($composer2.getInserting()) {
                $composer2.createNode(constructor);
            } else {
                $composer2.useNode();
            }
            $composer2.disableReusing();
            Composer $this$Layout_u24lambda_u2d0$iv$iv2 = Updater.m1304constructorimpl($composer2);
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv2, measurePolicy$iv2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv2, density$iv$iv2, ComposeUiNode.INSTANCE.getSetDensity());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv2, layoutDirection$iv$iv2, ComposeUiNode.INSTANCE.getSetLayoutDirection());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv2, viewConfiguration$iv$iv2, ComposeUiNode.INSTANCE.getSetViewConfiguration());
            $composer2.enableReusing();
            function3MaterializerOf2.invoke(SkippableUpdater.m1294boximpl(SkippableUpdater.m1295constructorimpl($composer2)), $composer2, Integer.valueOf(($changed$iv$iv$iv >> 3) & 112));
            $composer2.startReplaceableGroup(2058660585);
            $composer2.startReplaceableGroup(-1163856341);
            ComposerKt.sourceInformation($composer2, "C79@3994L9:Column.kt#2w3rfo");
            if ((($changed$iv$iv$iv >> 9) & 14 & 11) == 2) {
                int i9 = (($changed$iv >> 6) & 112) | 6;
                ColumnScope $this$DrivingPad_u24lambda_u245 = ColumnScopeInstance.INSTANCE;
                ComposerKt.sourceInformationMarkerStart($composer2, 216050297, "C36@1424L11,38@1524L6,40@1686L213,45@1945L1914,76@3861L472,37@1444L2889,84@4431L10,84@4342L108:DrivingPad.kt#597736");
                TextKt.m1249TextfLXpl1I(label, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, null, $composer2, $dirty & 14, 0, 65534);
                Modifier modifierWeight$default2 = ColumnScope.weight$default($this$DrivingPad_u24lambda_u245, SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), LiveLiterals$DrivingPadKt.INSTANCE.m6499Float$arg0$callweight$$$this$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), false, 2, null);
                long jM980getOnSurface0d7_KjU4 = MaterialTheme.INSTANCE.getColors($composer2, MaterialTheme.$stable).m980getOnSurface0d7_KjU();
                long jM1659copywmQWz5c3 = Color.m1659copywmQWz5c(jM980getOnSurface0d7_KjU4, (14 & 1) != 0 ? Color.m1663getAlphaimpl(jM980getOnSurface0d7_KjU4) : LiveLiterals$DrivingPadKt.INSTANCE.m6492Float$arg0$callcopy$arg0$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(jM980getOnSurface0d7_KjU4) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(jM980getOnSurface0d7_KjU4) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(jM980getOnSurface0d7_KjU4) : 0.0f);
                int $this$dp$iv2 = LiveLiterals$DrivingPadKt.INSTANCE.m6508Int$$$this$call$getdp$$arg0$callRoundedCornerShape$arg1$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                Modifier modifierM179backgroundbw27NRU2 = BackgroundKt.m179backgroundbw27NRU(modifierWeight$default2, jM1659copywmQWz5c3, RoundedCornerShapeKt.m677RoundedCornerShape0680j_4(Dp.m4046constructorimpl($this$dp$iv2)));
                liveLiterals$DrivingPadKt = LiveLiterals$DrivingPadKt.INSTANCE;
                if (vertical) {
                    strM6517String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt.m6515String$branch$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                } else {
                    strM6517String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt.m6517String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                }
                Modifier modifierTestTag2 = TestTagKt.testTag(modifierM179backgroundbw27NRU2, strM6517String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad);
                Object key2$iv6 = Float.valueOf(value);
                Object key3$iv4 = Boolean.valueOf(enabled);
                int i10 = ($dirty & 14) | (($dirty >> 3) & 112) | (($dirty >> 3) & 896);
                $composer2.startReplaceableGroup(1618982084);
                ComposerKt.sourceInformation($composer2, "C(remember)P(1,2,3):Composables.kt#9igjgp");
                invalid$iv$iv = $composer2.changed(label) | $composer2.changed(key2$iv6) | $composer2.changed(key3$iv4);
                Object it$iv$iv2 = $composer2.rememberedValue();
                if (invalid$iv$iv) {
                    f = value;
                    z = enabled;
                    value$iv$iv = new Function1<SemanticsPropertyReceiver, Unit>() { // from class: vea.raceremote.control.DrivingPadKt$DrivingPad$1$1$1
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(1);
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public /* bridge */ /* synthetic */ Unit invoke(SemanticsPropertyReceiver semanticsPropertyReceiver) {
                            invoke2(semanticsPropertyReceiver);
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2(SemanticsPropertyReceiver $this$semantics) {
                            Intrinsics.checkNotNullParameter($this$semantics, "$this$semantics");
                            SemanticsPropertiesKt.setContentDescription($this$semantics, label + LiveLiterals$DrivingPadKt.INSTANCE.m6512String$1$str$arg0$call$setcontentDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            SemanticsPropertiesKt.setStateDescription($this$semantics, ((int) (f * LiveLiterals$DrivingPadKt.INSTANCE.m6511Int$arg0$calltimes$$this$calltoInt$0$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad())) + LiveLiterals$DrivingPadKt.INSTANCE.m6513String$1$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            if (!z) {
                                SemanticsPropertiesKt.disabled($this$semantics);
                            }
                        }
                    };
                    $composer2.updateRememberedValue(value$iv$iv);
                } else {
                    f = value;
                    z = enabled;
                    value$iv$iv = new Function1<SemanticsPropertyReceiver, Unit>() { // from class: vea.raceremote.control.DrivingPadKt$DrivingPad$1$1$1
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(1);
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public /* bridge */ /* synthetic */ Unit invoke(SemanticsPropertyReceiver semanticsPropertyReceiver) {
                            invoke2(semanticsPropertyReceiver);
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2(SemanticsPropertyReceiver $this$semantics) {
                            Intrinsics.checkNotNullParameter($this$semantics, "$this$semantics");
                            SemanticsPropertiesKt.setContentDescription($this$semantics, label + LiveLiterals$DrivingPadKt.INSTANCE.m6512String$1$str$arg0$call$setcontentDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            SemanticsPropertiesKt.setStateDescription($this$semantics, ((int) (f * LiveLiterals$DrivingPadKt.INSTANCE.m6511Int$arg0$calltimes$$this$calltoInt$0$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad())) + LiveLiterals$DrivingPadKt.INSTANCE.m6513String$1$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            if (!z) {
                                SemanticsPropertiesKt.disabled($this$semantics);
                            }
                        }
                    };
                    $composer2.updateRememberedValue(value$iv$iv);
                }
                $composer2.endReplaceableGroup();
                Modifier modifierSemantics$default2 = SemanticsModifierKt.semantics$default(modifierTestTag2, false, (Function1) value$iv$iv, 1, null);
                Boolean boolValueOf3 = Boolean.valueOf(enabled);
                Boolean boolValueOf4 = Boolean.valueOf(vertical);
                Object key1$iv5 = Boolean.valueOf(enabled);
                Object key2$iv7 = Boolean.valueOf(vertical);
                int i11 = (($dirty >> 9) & 14) | ($dirty & 112);
                $composer2.startReplaceableGroup(1618982084);
                ComposerKt.sourceInformation($composer2, "C(remember)P(1,2,3):Composables.kt#9igjgp");
                invalid$iv$iv2 = $composer2.changed(key1$iv5) | $composer2.changed(key2$iv7) | $composer2.changed(change$delegate);
                value$iv$iv2 = $composer2.rememberedValue();
                if (!invalid$iv$iv2) {
                    key2$iv = Composer.INSTANCE.getEmpty();
                    if (value$iv$iv2 == key2$iv) {
                    }
                    $composer2.endReplaceableGroup();
                    Modifier modifierPointerInput3 = SuspendingPointerInputFilterKt.pointerInput(modifierSemantics$default2, boolValueOf3, boolValueOf4, (Function2) value$iv$iv2);
                    Object key1$iv6 = Boolean.valueOf(vertical);
                    Object key2$iv8 = Color.m1651boximpl(accent);
                    Object key3$iv5 = Float.valueOf(value);
                    int i12 = (($dirty >> 3) & 14) | ($dirty & 896);
                    $composer2.startReplaceableGroup(1618982084);
                    ComposerKt.sourceInformation($composer2, "C(remember)P(1,2,3):Composables.kt#9igjgp");
                    invalid$iv$iv3 = $composer2.changed(key1$iv6) | $composer2.changed(key2$iv8) | $composer2.changed(key3$iv5);
                    value$iv$iv3 = $composer2.rememberedValue();
                    if (!invalid$iv$iv3) {
                        key1$iv = Composer.INSTANCE.getEmpty();
                        if (value$iv$iv3 == key1$iv) {
                        }
                        $composer2.endReplaceableGroup();
                        CanvasKt.Canvas(modifierPointerInput3, (Function1) value$iv$iv3, $composer2, 0);
                        liveLiterals$DrivingPadKt2 = LiveLiterals$DrivingPadKt.INSTANCE;
                        if (vertical) {
                            strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6514String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        } else {
                            strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        }
                        TextKt.m1249TextfLXpl1I(strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, MaterialTheme.INSTANCE.getTypography($composer2, MaterialTheme.$stable).getCaption(), $composer2, 0, 0, 32766);
                        ComposerKt.sourceInformationMarkerEnd($composer2);
                    }
                    value$iv$iv3 = (Function1) new Function1<DrawScope, Unit>() { // from class: vea.raceremote.control.DrivingPadKt$DrivingPad$1$3$1
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(1);
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public /* bridge */ /* synthetic */ Unit invoke(DrawScope drawScope) {
                            invoke2(drawScope);
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2(DrawScope $this$Canvas) {
                            Intrinsics.checkNotNullParameter($this$Canvas, "$this$Canvas");
                            int $this$dp$iv3 = LiveLiterals$DrivingPadKt.INSTANCE.m6507Int$$$this$call$getdp$$$$this$calltoPx$valradius$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                            float radius = $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv3));
                            float fM1491getHeightimpl = ((vertical ? Size.m1491getHeightimpl($this$Canvas.mo2155getSizeNHjbRc()) : Size.m1494getWidthimpl($this$Canvas.mo2155getSizeNHjbRc())) / LiveLiterals$DrivingPadKt.INSTANCE.m6509Int$arg0$calldiv$$this$callminus$$this$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad()) - radius;
                            int $this$dp$iv4 = LiveLiterals$DrivingPadKt.INSTANCE.m6504Int$$$this$call$getdp$$$$this$calltoPx$arg0$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                            float travel = RangesKt.coerceAtLeast(fM1491getHeightimpl - $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv4)), LiveLiterals$DrivingPadKt.INSTANCE.m6490Float$arg0$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            long delta = vertical ? OffsetKt.Offset(LiveLiterals$DrivingPadKt.INSTANCE.m6488Float$arg0$callOffset$branch$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), -travel) : OffsetKt.Offset(travel, LiveLiterals$DrivingPadKt.INSTANCE.m6500Float$arg1$callOffset$else$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            long j = accent;
                            long jM1659copywmQWz5c4 = Color.m1659copywmQWz5c(j, (14 & 1) != 0 ? Color.m1663getAlphaimpl(j) : LiveLiterals$DrivingPadKt.INSTANCE.m6494Float$arg0$callcopy$arg0$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(j) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(j) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(j) : 0.0f);
                            long jM1429minusMKHz9U = Offset.m1429minusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), delta);
                            long jM1430plusMKHz9U = Offset.m1430plusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), delta);
                            int $this$dp$iv5 = LiveLiterals$DrivingPadKt.INSTANCE.m6506Int$$$this$call$getdp$$$$this$calltoPx$arg3$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                            DrawScope.m2142drawLineNGM6Ib0$default($this$Canvas, jM1659copywmQWz5c4, jM1429minusMKHz9U, jM1430plusMKHz9U, $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv5)), 0, null, 0.0f, null, 0, 496, null);
                            long j2 = accent;
                            long jM1659copywmQWz5c5 = Color.m1659copywmQWz5c(j2, (14 & 1) != 0 ? Color.m1663getAlphaimpl(j2) : LiveLiterals$DrivingPadKt.INSTANCE.m6493Float$arg0$callcopy$arg0$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(j2) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(j2) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(j2) : 0.0f);
                            int $this$dp$iv6 = LiveLiterals$DrivingPadKt.INSTANCE.m6505Int$$$this$call$getdp$$$$this$calltoPx$arg1$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                            DrawScope.m2137drawCircleVaOC9Bg$default($this$Canvas, jM1659copywmQWz5c5, $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv6)), $this$Canvas.mo2154getCenterF1C5BW0(), 0.0f, null, null, 0, 120, null);
                            DrawScope.m2137drawCircleVaOC9Bg$default($this$Canvas, accent, radius, Offset.m1430plusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), Offset.m1432timestuRUvjQ(delta, f)), 0.0f, null, null, 0, 120, null);
                        }
                    };
                    $composer2.updateRememberedValue(value$iv$iv3);
                    $composer2.endReplaceableGroup();
                    CanvasKt.Canvas(modifierPointerInput3, (Function1) value$iv$iv3, $composer2, 0);
                    liveLiterals$DrivingPadKt2 = LiveLiterals$DrivingPadKt.INSTANCE;
                    if (vertical) {
                        strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6514String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                    } else {
                        strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                    }
                    TextKt.m1249TextfLXpl1I(strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, MaterialTheme.INSTANCE.getTypography($composer2, MaterialTheme.$stable).getCaption(), $composer2, 0, 0, 32766);
                    ComposerKt.sourceInformationMarkerEnd($composer2);
                }
                value$iv$iv2 = new DrivingPadKt$DrivingPad$1$2$1(z, vertical, change$delegate, null);
                $composer2.updateRememberedValue(value$iv$iv2);
                $composer2.endReplaceableGroup();
                Modifier modifierPointerInput4 = SuspendingPointerInputFilterKt.pointerInput(modifierSemantics$default2, boolValueOf3, boolValueOf4, (Function2) value$iv$iv2);
                Object key1$iv7 = Boolean.valueOf(vertical);
                Object key2$iv9 = Color.m1651boximpl(accent);
                Object key3$iv6 = Float.valueOf(value);
                int i13 = (($dirty >> 3) & 14) | ($dirty & 896);
                $composer2.startReplaceableGroup(1618982084);
                ComposerKt.sourceInformation($composer2, "C(remember)P(1,2,3):Composables.kt#9igjgp");
                invalid$iv$iv3 = $composer2.changed(key1$iv7) | $composer2.changed(key2$iv9) | $composer2.changed(key3$iv6);
                value$iv$iv3 = $composer2.rememberedValue();
                if (!invalid$iv$iv3) {
                    key1$iv = Composer.INSTANCE.getEmpty();
                    if (value$iv$iv3 == key1$iv) {
                    }
                    $composer2.endReplaceableGroup();
                    CanvasKt.Canvas(modifierPointerInput4, (Function1) value$iv$iv3, $composer2, 0);
                    liveLiterals$DrivingPadKt2 = LiveLiterals$DrivingPadKt.INSTANCE;
                    if (vertical) {
                        strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6514String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                    } else {
                        strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                    }
                    TextKt.m1249TextfLXpl1I(strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, MaterialTheme.INSTANCE.getTypography($composer2, MaterialTheme.$stable).getCaption(), $composer2, 0, 0, 32766);
                    ComposerKt.sourceInformationMarkerEnd($composer2);
                }
                value$iv$iv3 = (Function1) new Function1<DrawScope, Unit>() { // from class: vea.raceremote.control.DrivingPadKt$DrivingPad$1$3$1
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(1);
                    }

                    @Override // kotlin.jvm.functions.Function1
                    public /* bridge */ /* synthetic */ Unit invoke(DrawScope drawScope) {
                        invoke2(drawScope);
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2(DrawScope $this$Canvas) {
                        Intrinsics.checkNotNullParameter($this$Canvas, "$this$Canvas");
                        int $this$dp$iv3 = LiveLiterals$DrivingPadKt.INSTANCE.m6507Int$$$this$call$getdp$$$$this$calltoPx$valradius$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        float radius = $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv3));
                        float fM1491getHeightimpl = ((vertical ? Size.m1491getHeightimpl($this$Canvas.mo2155getSizeNHjbRc()) : Size.m1494getWidthimpl($this$Canvas.mo2155getSizeNHjbRc())) / LiveLiterals$DrivingPadKt.INSTANCE.m6509Int$arg0$calldiv$$this$callminus$$this$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad()) - radius;
                        int $this$dp$iv4 = LiveLiterals$DrivingPadKt.INSTANCE.m6504Int$$$this$call$getdp$$$$this$calltoPx$arg0$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        float travel = RangesKt.coerceAtLeast(fM1491getHeightimpl - $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv4)), LiveLiterals$DrivingPadKt.INSTANCE.m6490Float$arg0$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                        long delta = vertical ? OffsetKt.Offset(LiveLiterals$DrivingPadKt.INSTANCE.m6488Float$arg0$callOffset$branch$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), -travel) : OffsetKt.Offset(travel, LiveLiterals$DrivingPadKt.INSTANCE.m6500Float$arg1$callOffset$else$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                        long j = accent;
                        long jM1659copywmQWz5c4 = Color.m1659copywmQWz5c(j, (14 & 1) != 0 ? Color.m1663getAlphaimpl(j) : LiveLiterals$DrivingPadKt.INSTANCE.m6494Float$arg0$callcopy$arg0$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(j) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(j) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(j) : 0.0f);
                        long jM1429minusMKHz9U = Offset.m1429minusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), delta);
                        long jM1430plusMKHz9U = Offset.m1430plusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), delta);
                        int $this$dp$iv5 = LiveLiterals$DrivingPadKt.INSTANCE.m6506Int$$$this$call$getdp$$$$this$calltoPx$arg3$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        DrawScope.m2142drawLineNGM6Ib0$default($this$Canvas, jM1659copywmQWz5c4, jM1429minusMKHz9U, jM1430plusMKHz9U, $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv5)), 0, null, 0.0f, null, 0, 496, null);
                        long j2 = accent;
                        long jM1659copywmQWz5c5 = Color.m1659copywmQWz5c(j2, (14 & 1) != 0 ? Color.m1663getAlphaimpl(j2) : LiveLiterals$DrivingPadKt.INSTANCE.m6493Float$arg0$callcopy$arg0$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(j2) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(j2) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(j2) : 0.0f);
                        int $this$dp$iv6 = LiveLiterals$DrivingPadKt.INSTANCE.m6505Int$$$this$call$getdp$$$$this$calltoPx$arg1$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        DrawScope.m2137drawCircleVaOC9Bg$default($this$Canvas, jM1659copywmQWz5c5, $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv6)), $this$Canvas.mo2154getCenterF1C5BW0(), 0.0f, null, null, 0, 120, null);
                        DrawScope.m2137drawCircleVaOC9Bg$default($this$Canvas, accent, radius, Offset.m1430plusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), Offset.m1432timestuRUvjQ(delta, f)), 0.0f, null, null, 0, 120, null);
                    }
                };
                $composer2.updateRememberedValue(value$iv$iv3);
                $composer2.endReplaceableGroup();
                CanvasKt.Canvas(modifierPointerInput4, (Function1) value$iv$iv3, $composer2, 0);
                liveLiterals$DrivingPadKt2 = LiveLiterals$DrivingPadKt.INSTANCE;
                if (vertical) {
                    strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6514String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                } else {
                    strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                }
                TextKt.m1249TextfLXpl1I(strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, MaterialTheme.INSTANCE.getTypography($composer2, MaterialTheme.$stable).getCaption(), $composer2, 0, 0, 32766);
                ComposerKt.sourceInformationMarkerEnd($composer2);
            } else {
                int i14 = (($changed$iv >> 6) & 112) | 6;
                ColumnScope $this$DrivingPad_u24lambda_u246 = ColumnScopeInstance.INSTANCE;
                ComposerKt.sourceInformationMarkerStart($composer2, 216050297, "C36@1424L11,38@1524L6,40@1686L213,45@1945L1914,76@3861L472,37@1444L2889,84@4431L10,84@4342L108:DrivingPad.kt#597736");
                TextKt.m1249TextfLXpl1I(label, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, null, $composer2, $dirty & 14, 0, 65534);
                Modifier modifierWeight$default3 = ColumnScope.weight$default($this$DrivingPad_u24lambda_u246, SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), LiveLiterals$DrivingPadKt.INSTANCE.m6499Float$arg0$callweight$$$this$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), false, 2, null);
                long jM980getOnSurface0d7_KjU5 = MaterialTheme.INSTANCE.getColors($composer2, MaterialTheme.$stable).m980getOnSurface0d7_KjU();
                long jM1659copywmQWz5c4 = Color.m1659copywmQWz5c(jM980getOnSurface0d7_KjU5, (14 & 1) != 0 ? Color.m1663getAlphaimpl(jM980getOnSurface0d7_KjU5) : LiveLiterals$DrivingPadKt.INSTANCE.m6492Float$arg0$callcopy$arg0$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(jM980getOnSurface0d7_KjU5) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(jM980getOnSurface0d7_KjU5) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(jM980getOnSurface0d7_KjU5) : 0.0f);
                int $this$dp$iv3 = LiveLiterals$DrivingPadKt.INSTANCE.m6508Int$$$this$call$getdp$$arg0$callRoundedCornerShape$arg1$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                Modifier modifierM179backgroundbw27NRU3 = BackgroundKt.m179backgroundbw27NRU(modifierWeight$default3, jM1659copywmQWz5c4, RoundedCornerShapeKt.m677RoundedCornerShape0680j_4(Dp.m4046constructorimpl($this$dp$iv3)));
                liveLiterals$DrivingPadKt = LiveLiterals$DrivingPadKt.INSTANCE;
                if (vertical) {
                    strM6517String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt.m6515String$branch$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                } else {
                    strM6517String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt.m6517String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                }
                Modifier modifierTestTag3 = TestTagKt.testTag(modifierM179backgroundbw27NRU3, strM6517String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad);
                Object key2$iv10 = Float.valueOf(value);
                Object key3$iv7 = Boolean.valueOf(enabled);
                int i15 = ($dirty & 14) | (($dirty >> 3) & 112) | (($dirty >> 3) & 896);
                $composer2.startReplaceableGroup(1618982084);
                ComposerKt.sourceInformation($composer2, "C(remember)P(1,2,3):Composables.kt#9igjgp");
                invalid$iv$iv = $composer2.changed(label) | $composer2.changed(key2$iv10) | $composer2.changed(key3$iv7);
                Object it$iv$iv3 = $composer2.rememberedValue();
                if (invalid$iv$iv) {
                    f = value;
                    z = enabled;
                    value$iv$iv = new Function1<SemanticsPropertyReceiver, Unit>() { // from class: vea.raceremote.control.DrivingPadKt$DrivingPad$1$1$1
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(1);
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public /* bridge */ /* synthetic */ Unit invoke(SemanticsPropertyReceiver semanticsPropertyReceiver) {
                            invoke2(semanticsPropertyReceiver);
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2(SemanticsPropertyReceiver $this$semantics) {
                            Intrinsics.checkNotNullParameter($this$semantics, "$this$semantics");
                            SemanticsPropertiesKt.setContentDescription($this$semantics, label + LiveLiterals$DrivingPadKt.INSTANCE.m6512String$1$str$arg0$call$setcontentDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            SemanticsPropertiesKt.setStateDescription($this$semantics, ((int) (f * LiveLiterals$DrivingPadKt.INSTANCE.m6511Int$arg0$calltimes$$this$calltoInt$0$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad())) + LiveLiterals$DrivingPadKt.INSTANCE.m6513String$1$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            if (!z) {
                                SemanticsPropertiesKt.disabled($this$semantics);
                            }
                        }
                    };
                    $composer2.updateRememberedValue(value$iv$iv);
                } else {
                    f = value;
                    z = enabled;
                    value$iv$iv = new Function1<SemanticsPropertyReceiver, Unit>() { // from class: vea.raceremote.control.DrivingPadKt$DrivingPad$1$1$1
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(1);
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public /* bridge */ /* synthetic */ Unit invoke(SemanticsPropertyReceiver semanticsPropertyReceiver) {
                            invoke2(semanticsPropertyReceiver);
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2(SemanticsPropertyReceiver $this$semantics) {
                            Intrinsics.checkNotNullParameter($this$semantics, "$this$semantics");
                            SemanticsPropertiesKt.setContentDescription($this$semantics, label + LiveLiterals$DrivingPadKt.INSTANCE.m6512String$1$str$arg0$call$setcontentDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            SemanticsPropertiesKt.setStateDescription($this$semantics, ((int) (f * LiveLiterals$DrivingPadKt.INSTANCE.m6511Int$arg0$calltimes$$this$calltoInt$0$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad())) + LiveLiterals$DrivingPadKt.INSTANCE.m6513String$1$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            if (!z) {
                                SemanticsPropertiesKt.disabled($this$semantics);
                            }
                        }
                    };
                    $composer2.updateRememberedValue(value$iv$iv);
                }
                $composer2.endReplaceableGroup();
                Modifier modifierSemantics$default3 = SemanticsModifierKt.semantics$default(modifierTestTag3, false, (Function1) value$iv$iv, 1, null);
                Boolean boolValueOf5 = Boolean.valueOf(enabled);
                Boolean boolValueOf6 = Boolean.valueOf(vertical);
                Object key1$iv8 = Boolean.valueOf(enabled);
                Object key2$iv11 = Boolean.valueOf(vertical);
                int i16 = (($dirty >> 9) & 14) | ($dirty & 112);
                $composer2.startReplaceableGroup(1618982084);
                ComposerKt.sourceInformation($composer2, "C(remember)P(1,2,3):Composables.kt#9igjgp");
                invalid$iv$iv2 = $composer2.changed(key1$iv8) | $composer2.changed(key2$iv11) | $composer2.changed(change$delegate);
                value$iv$iv2 = $composer2.rememberedValue();
                if (!invalid$iv$iv2) {
                    key2$iv = Composer.INSTANCE.getEmpty();
                    if (value$iv$iv2 == key2$iv) {
                    }
                    $composer2.endReplaceableGroup();
                    Modifier modifierPointerInput5 = SuspendingPointerInputFilterKt.pointerInput(modifierSemantics$default3, boolValueOf5, boolValueOf6, (Function2) value$iv$iv2);
                    Object key1$iv9 = Boolean.valueOf(vertical);
                    Object key2$iv12 = Color.m1651boximpl(accent);
                    Object key3$iv8 = Float.valueOf(value);
                    int i17 = (($dirty >> 3) & 14) | ($dirty & 896);
                    $composer2.startReplaceableGroup(1618982084);
                    ComposerKt.sourceInformation($composer2, "C(remember)P(1,2,3):Composables.kt#9igjgp");
                    invalid$iv$iv3 = $composer2.changed(key1$iv9) | $composer2.changed(key2$iv12) | $composer2.changed(key3$iv8);
                    value$iv$iv3 = $composer2.rememberedValue();
                    if (!invalid$iv$iv3) {
                        key1$iv = Composer.INSTANCE.getEmpty();
                        if (value$iv$iv3 == key1$iv) {
                        }
                        $composer2.endReplaceableGroup();
                        CanvasKt.Canvas(modifierPointerInput5, (Function1) value$iv$iv3, $composer2, 0);
                        liveLiterals$DrivingPadKt2 = LiveLiterals$DrivingPadKt.INSTANCE;
                        if (vertical) {
                            strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6514String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        } else {
                            strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        }
                        TextKt.m1249TextfLXpl1I(strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, MaterialTheme.INSTANCE.getTypography($composer2, MaterialTheme.$stable).getCaption(), $composer2, 0, 0, 32766);
                        ComposerKt.sourceInformationMarkerEnd($composer2);
                    }
                    value$iv$iv3 = (Function1) new Function1<DrawScope, Unit>() { // from class: vea.raceremote.control.DrivingPadKt$DrivingPad$1$3$1
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(1);
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public /* bridge */ /* synthetic */ Unit invoke(DrawScope drawScope) {
                            invoke2(drawScope);
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2(DrawScope $this$Canvas) {
                            Intrinsics.checkNotNullParameter($this$Canvas, "$this$Canvas");
                            int $this$dp$iv4 = LiveLiterals$DrivingPadKt.INSTANCE.m6507Int$$$this$call$getdp$$$$this$calltoPx$valradius$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                            float radius = $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv4));
                            float fM1491getHeightimpl = ((vertical ? Size.m1491getHeightimpl($this$Canvas.mo2155getSizeNHjbRc()) : Size.m1494getWidthimpl($this$Canvas.mo2155getSizeNHjbRc())) / LiveLiterals$DrivingPadKt.INSTANCE.m6509Int$arg0$calldiv$$this$callminus$$this$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad()) - radius;
                            int $this$dp$iv5 = LiveLiterals$DrivingPadKt.INSTANCE.m6504Int$$$this$call$getdp$$$$this$calltoPx$arg0$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                            float travel = RangesKt.coerceAtLeast(fM1491getHeightimpl - $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv5)), LiveLiterals$DrivingPadKt.INSTANCE.m6490Float$arg0$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            long delta = vertical ? OffsetKt.Offset(LiveLiterals$DrivingPadKt.INSTANCE.m6488Float$arg0$callOffset$branch$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), -travel) : OffsetKt.Offset(travel, LiveLiterals$DrivingPadKt.INSTANCE.m6500Float$arg1$callOffset$else$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            long j = accent;
                            long jM1659copywmQWz5c5 = Color.m1659copywmQWz5c(j, (14 & 1) != 0 ? Color.m1663getAlphaimpl(j) : LiveLiterals$DrivingPadKt.INSTANCE.m6494Float$arg0$callcopy$arg0$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(j) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(j) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(j) : 0.0f);
                            long jM1429minusMKHz9U = Offset.m1429minusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), delta);
                            long jM1430plusMKHz9U = Offset.m1430plusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), delta);
                            int $this$dp$iv6 = LiveLiterals$DrivingPadKt.INSTANCE.m6506Int$$$this$call$getdp$$$$this$calltoPx$arg3$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                            DrawScope.m2142drawLineNGM6Ib0$default($this$Canvas, jM1659copywmQWz5c5, jM1429minusMKHz9U, jM1430plusMKHz9U, $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv6)), 0, null, 0.0f, null, 0, 496, null);
                            long j2 = accent;
                            long jM1659copywmQWz5c6 = Color.m1659copywmQWz5c(j2, (14 & 1) != 0 ? Color.m1663getAlphaimpl(j2) : LiveLiterals$DrivingPadKt.INSTANCE.m6493Float$arg0$callcopy$arg0$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(j2) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(j2) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(j2) : 0.0f);
                            int $this$dp$iv7 = LiveLiterals$DrivingPadKt.INSTANCE.m6505Int$$$this$call$getdp$$$$this$calltoPx$arg1$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                            DrawScope.m2137drawCircleVaOC9Bg$default($this$Canvas, jM1659copywmQWz5c6, $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv7)), $this$Canvas.mo2154getCenterF1C5BW0(), 0.0f, null, null, 0, 120, null);
                            DrawScope.m2137drawCircleVaOC9Bg$default($this$Canvas, accent, radius, Offset.m1430plusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), Offset.m1432timestuRUvjQ(delta, f)), 0.0f, null, null, 0, 120, null);
                        }
                    };
                    $composer2.updateRememberedValue(value$iv$iv3);
                    $composer2.endReplaceableGroup();
                    CanvasKt.Canvas(modifierPointerInput5, (Function1) value$iv$iv3, $composer2, 0);
                    liveLiterals$DrivingPadKt2 = LiveLiterals$DrivingPadKt.INSTANCE;
                    if (vertical) {
                        strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6514String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                    } else {
                        strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                    }
                    TextKt.m1249TextfLXpl1I(strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, MaterialTheme.INSTANCE.getTypography($composer2, MaterialTheme.$stable).getCaption(), $composer2, 0, 0, 32766);
                    ComposerKt.sourceInformationMarkerEnd($composer2);
                }
                value$iv$iv2 = new DrivingPadKt$DrivingPad$1$2$1(z, vertical, change$delegate, null);
                $composer2.updateRememberedValue(value$iv$iv2);
                $composer2.endReplaceableGroup();
                Modifier modifierPointerInput6 = SuspendingPointerInputFilterKt.pointerInput(modifierSemantics$default3, boolValueOf5, boolValueOf6, (Function2) value$iv$iv2);
                Object key1$iv10 = Boolean.valueOf(vertical);
                Object key2$iv13 = Color.m1651boximpl(accent);
                Object key3$iv9 = Float.valueOf(value);
                int i18 = (($dirty >> 3) & 14) | ($dirty & 896);
                $composer2.startReplaceableGroup(1618982084);
                ComposerKt.sourceInformation($composer2, "C(remember)P(1,2,3):Composables.kt#9igjgp");
                invalid$iv$iv3 = $composer2.changed(key1$iv10) | $composer2.changed(key2$iv13) | $composer2.changed(key3$iv9);
                value$iv$iv3 = $composer2.rememberedValue();
                if (!invalid$iv$iv3) {
                    key1$iv = Composer.INSTANCE.getEmpty();
                    if (value$iv$iv3 == key1$iv) {
                    }
                    $composer2.endReplaceableGroup();
                    CanvasKt.Canvas(modifierPointerInput6, (Function1) value$iv$iv3, $composer2, 0);
                    liveLiterals$DrivingPadKt2 = LiveLiterals$DrivingPadKt.INSTANCE;
                    if (vertical) {
                        strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6514String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                    } else {
                        strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                    }
                    TextKt.m1249TextfLXpl1I(strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, MaterialTheme.INSTANCE.getTypography($composer2, MaterialTheme.$stable).getCaption(), $composer2, 0, 0, 32766);
                    ComposerKt.sourceInformationMarkerEnd($composer2);
                }
                value$iv$iv3 = (Function1) new Function1<DrawScope, Unit>() { // from class: vea.raceremote.control.DrivingPadKt$DrivingPad$1$3$1
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(1);
                    }

                    @Override // kotlin.jvm.functions.Function1
                    public /* bridge */ /* synthetic */ Unit invoke(DrawScope drawScope) {
                        invoke2(drawScope);
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2(DrawScope $this$Canvas) {
                        Intrinsics.checkNotNullParameter($this$Canvas, "$this$Canvas");
                        int $this$dp$iv4 = LiveLiterals$DrivingPadKt.INSTANCE.m6507Int$$$this$call$getdp$$$$this$calltoPx$valradius$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        float radius = $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv4));
                        float fM1491getHeightimpl = ((vertical ? Size.m1491getHeightimpl($this$Canvas.mo2155getSizeNHjbRc()) : Size.m1494getWidthimpl($this$Canvas.mo2155getSizeNHjbRc())) / LiveLiterals$DrivingPadKt.INSTANCE.m6509Int$arg0$calldiv$$this$callminus$$this$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad()) - radius;
                        int $this$dp$iv5 = LiveLiterals$DrivingPadKt.INSTANCE.m6504Int$$$this$call$getdp$$$$this$calltoPx$arg0$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        float travel = RangesKt.coerceAtLeast(fM1491getHeightimpl - $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv5)), LiveLiterals$DrivingPadKt.INSTANCE.m6490Float$arg0$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                        long delta = vertical ? OffsetKt.Offset(LiveLiterals$DrivingPadKt.INSTANCE.m6488Float$arg0$callOffset$branch$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), -travel) : OffsetKt.Offset(travel, LiveLiterals$DrivingPadKt.INSTANCE.m6500Float$arg1$callOffset$else$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                        long j = accent;
                        long jM1659copywmQWz5c5 = Color.m1659copywmQWz5c(j, (14 & 1) != 0 ? Color.m1663getAlphaimpl(j) : LiveLiterals$DrivingPadKt.INSTANCE.m6494Float$arg0$callcopy$arg0$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(j) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(j) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(j) : 0.0f);
                        long jM1429minusMKHz9U = Offset.m1429minusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), delta);
                        long jM1430plusMKHz9U = Offset.m1430plusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), delta);
                        int $this$dp$iv6 = LiveLiterals$DrivingPadKt.INSTANCE.m6506Int$$$this$call$getdp$$$$this$calltoPx$arg3$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        DrawScope.m2142drawLineNGM6Ib0$default($this$Canvas, jM1659copywmQWz5c5, jM1429minusMKHz9U, jM1430plusMKHz9U, $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv6)), 0, null, 0.0f, null, 0, 496, null);
                        long j2 = accent;
                        long jM1659copywmQWz5c6 = Color.m1659copywmQWz5c(j2, (14 & 1) != 0 ? Color.m1663getAlphaimpl(j2) : LiveLiterals$DrivingPadKt.INSTANCE.m6493Float$arg0$callcopy$arg0$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(j2) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(j2) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(j2) : 0.0f);
                        int $this$dp$iv7 = LiveLiterals$DrivingPadKt.INSTANCE.m6505Int$$$this$call$getdp$$$$this$calltoPx$arg1$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        DrawScope.m2137drawCircleVaOC9Bg$default($this$Canvas, jM1659copywmQWz5c6, $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv7)), $this$Canvas.mo2154getCenterF1C5BW0(), 0.0f, null, null, 0, 120, null);
                        DrawScope.m2137drawCircleVaOC9Bg$default($this$Canvas, accent, radius, Offset.m1430plusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), Offset.m1432timestuRUvjQ(delta, f)), 0.0f, null, null, 0, 120, null);
                    }
                };
                $composer2.updateRememberedValue(value$iv$iv3);
                $composer2.endReplaceableGroup();
                CanvasKt.Canvas(modifierPointerInput6, (Function1) value$iv$iv3, $composer2, 0);
                liveLiterals$DrivingPadKt2 = LiveLiterals$DrivingPadKt.INSTANCE;
                if (vertical) {
                    strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6514String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                } else {
                    strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                }
                TextKt.m1249TextfLXpl1I(strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, MaterialTheme.INSTANCE.getTypography($composer2, MaterialTheme.$stable).getCaption(), $composer2, 0, 0, 32766);
                ComposerKt.sourceInformationMarkerEnd($composer2);
            }
            $composer2.endReplaceableGroup();
            $composer2.endReplaceableGroup();
            $composer2.endNode();
            $composer2.endReplaceableGroup();
            $composer2.endReplaceableGroup();
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            if (i3 != 0) {
                modifier3 = Modifier.INSTANCE;
            } else {
                modifier3 = modifier2;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(2076018843, $dirty, -1, "vea.raceremote.control.DrivingPad (DrivingPad.kt:25)");
            }
            change$delegate = SnapshotStateKt.rememberUpdatedState(function1, $composer2, ($dirty >> 15) & 14);
            if (enabled) {
                $composer2.startReplaceableGroup(-244214841);
                ComposerKt.sourceInformation($composer2, "34@1272L6");
                jM1659copywmQWz5c = MaterialTheme.INSTANCE.getColors($composer2, MaterialTheme.$stable).m981getPrimary0d7_KjU();
            } else {
                $composer2.startReplaceableGroup(-244214797);
                ComposerKt.sourceInformation($composer2, "34@1306L6");
                long jM980getOnSurface0d7_KjU6 = MaterialTheme.INSTANCE.getColors($composer2, MaterialTheme.$stable).m980getOnSurface0d7_KjU();
                jM1659copywmQWz5c = Color.m1659copywmQWz5c(jM980getOnSurface0d7_KjU6, (14 & 1) != 0 ? Color.m1663getAlphaimpl(jM980getOnSurface0d7_KjU6) : LiveLiterals$DrivingPadKt.INSTANCE.m6495Float$arg0$callcopy$else$if$valaccent$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(jM980getOnSurface0d7_KjU6) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(jM980getOnSurface0d7_KjU6) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(jM980getOnSurface0d7_KjU6) : 0.0f);
            }
            $composer2.endReplaceableGroup();
            accent = jM1659copywmQWz5c;
            Alignment.Horizontal horizontalAlignment$iv3 = Alignment.INSTANCE.getCenterHorizontally();
            $changed$iv = (($dirty >> 12) & 14) | 384;
            $composer2.startReplaceableGroup(-483455358);
            ComposerKt.sourceInformation($composer2, "C(Column)P(2,3,1)77@3880L61,78@3946L133:Column.kt#2w3rfo");
            Arrangement.Vertical verticalArrangement$iv3 = Arrangement.INSTANCE.getTop();
            MeasurePolicy measurePolicy$iv3 = ColumnKt.columnMeasurePolicy(verticalArrangement$iv3, horizontalAlignment$iv3, $composer2, (($changed$iv >> 3) & 14) | (($changed$iv >> 3) & 112));
            int $changed$iv$iv3 = ($changed$iv << 3) & 112;
            $composer2.startReplaceableGroup(-1323940314);
            ComposerKt.sourceInformation($composer2, "C(Layout)P(!1,2)74@2915L7,75@2970L7,76@3029L7,77@3041L460:Layout.kt#80mrfh");
            ProvidableCompositionLocal<Density> localDensity3 = CompositionLocalsKt.getLocalDensity();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume7 = $composer2.consume(localDensity3);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            Density density$iv$iv3 = (Density) objConsume7;
            ProvidableCompositionLocal<LayoutDirection> localLayoutDirection3 = CompositionLocalsKt.getLocalLayoutDirection();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume8 = $composer2.consume(localLayoutDirection3);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            LayoutDirection layoutDirection$iv$iv3 = (LayoutDirection) objConsume8;
            ProvidableCompositionLocal<ViewConfiguration> localViewConfiguration3 = CompositionLocalsKt.getLocalViewConfiguration();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume9 = $composer2.consume(localViewConfiguration3);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ViewConfiguration viewConfiguration$iv$iv3 = (ViewConfiguration) objConsume9;
            constructor = ComposeUiNode.INSTANCE.getConstructor();
            Function3<SkippableUpdater<ComposeUiNode>, Composer, Integer, Unit> function3MaterializerOf3 = LayoutKt.materializerOf(modifier3);
            $changed$iv$iv$iv = (($changed$iv$iv3 << 9) & 7168) | 6;
            if (!($composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer2.startReusableNode();
            if ($composer2.getInserting()) {
                $composer2.createNode(constructor);
            } else {
                $composer2.useNode();
            }
            $composer2.disableReusing();
            Composer $this$Layout_u24lambda_u2d0$iv$iv3 = Updater.m1304constructorimpl($composer2);
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv3, measurePolicy$iv3, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv3, density$iv$iv3, ComposeUiNode.INSTANCE.getSetDensity());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv3, layoutDirection$iv$iv3, ComposeUiNode.INSTANCE.getSetLayoutDirection());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv3, viewConfiguration$iv$iv3, ComposeUiNode.INSTANCE.getSetViewConfiguration());
            $composer2.enableReusing();
            function3MaterializerOf3.invoke(SkippableUpdater.m1294boximpl(SkippableUpdater.m1295constructorimpl($composer2)), $composer2, Integer.valueOf(($changed$iv$iv$iv >> 3) & 112));
            $composer2.startReplaceableGroup(2058660585);
            $composer2.startReplaceableGroup(-1163856341);
            ComposerKt.sourceInformation($composer2, "C79@3994L9:Column.kt#2w3rfo");
            if ((($changed$iv$iv$iv >> 9) & 14 & 11) == 2) {
                int i19 = (($changed$iv >> 6) & 112) | 6;
                ColumnScope $this$DrivingPad_u24lambda_u247 = ColumnScopeInstance.INSTANCE;
                ComposerKt.sourceInformationMarkerStart($composer2, 216050297, "C36@1424L11,38@1524L6,40@1686L213,45@1945L1914,76@3861L472,37@1444L2889,84@4431L10,84@4342L108:DrivingPad.kt#597736");
                TextKt.m1249TextfLXpl1I(label, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, null, $composer2, $dirty & 14, 0, 65534);
                Modifier modifierWeight$default4 = ColumnScope.weight$default($this$DrivingPad_u24lambda_u247, SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), LiveLiterals$DrivingPadKt.INSTANCE.m6499Float$arg0$callweight$$$this$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), false, 2, null);
                long jM980getOnSurface0d7_KjU7 = MaterialTheme.INSTANCE.getColors($composer2, MaterialTheme.$stable).m980getOnSurface0d7_KjU();
                long jM1659copywmQWz5c5 = Color.m1659copywmQWz5c(jM980getOnSurface0d7_KjU7, (14 & 1) != 0 ? Color.m1663getAlphaimpl(jM980getOnSurface0d7_KjU7) : LiveLiterals$DrivingPadKt.INSTANCE.m6492Float$arg0$callcopy$arg0$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(jM980getOnSurface0d7_KjU7) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(jM980getOnSurface0d7_KjU7) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(jM980getOnSurface0d7_KjU7) : 0.0f);
                int $this$dp$iv4 = LiveLiterals$DrivingPadKt.INSTANCE.m6508Int$$$this$call$getdp$$arg0$callRoundedCornerShape$arg1$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                Modifier modifierM179backgroundbw27NRU4 = BackgroundKt.m179backgroundbw27NRU(modifierWeight$default4, jM1659copywmQWz5c5, RoundedCornerShapeKt.m677RoundedCornerShape0680j_4(Dp.m4046constructorimpl($this$dp$iv4)));
                liveLiterals$DrivingPadKt = LiveLiterals$DrivingPadKt.INSTANCE;
                if (vertical) {
                    strM6517String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt.m6515String$branch$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                } else {
                    strM6517String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt.m6517String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                }
                Modifier modifierTestTag4 = TestTagKt.testTag(modifierM179backgroundbw27NRU4, strM6517String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad);
                Object key2$iv14 = Float.valueOf(value);
                Object key3$iv10 = Boolean.valueOf(enabled);
                int i110 = ($dirty & 14) | (($dirty >> 3) & 112) | (($dirty >> 3) & 896);
                $composer2.startReplaceableGroup(1618982084);
                ComposerKt.sourceInformation($composer2, "C(remember)P(1,2,3):Composables.kt#9igjgp");
                invalid$iv$iv = $composer2.changed(label) | $composer2.changed(key2$iv14) | $composer2.changed(key3$iv10);
                Object it$iv$iv4 = $composer2.rememberedValue();
                if (invalid$iv$iv) {
                    f = value;
                    z = enabled;
                    value$iv$iv = new Function1<SemanticsPropertyReceiver, Unit>() { // from class: vea.raceremote.control.DrivingPadKt$DrivingPad$1$1$1
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(1);
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public /* bridge */ /* synthetic */ Unit invoke(SemanticsPropertyReceiver semanticsPropertyReceiver) {
                            invoke2(semanticsPropertyReceiver);
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2(SemanticsPropertyReceiver $this$semantics) {
                            Intrinsics.checkNotNullParameter($this$semantics, "$this$semantics");
                            SemanticsPropertiesKt.setContentDescription($this$semantics, label + LiveLiterals$DrivingPadKt.INSTANCE.m6512String$1$str$arg0$call$setcontentDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            SemanticsPropertiesKt.setStateDescription($this$semantics, ((int) (f * LiveLiterals$DrivingPadKt.INSTANCE.m6511Int$arg0$calltimes$$this$calltoInt$0$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad())) + LiveLiterals$DrivingPadKt.INSTANCE.m6513String$1$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            if (!z) {
                                SemanticsPropertiesKt.disabled($this$semantics);
                            }
                        }
                    };
                    $composer2.updateRememberedValue(value$iv$iv);
                } else {
                    f = value;
                    z = enabled;
                    value$iv$iv = new Function1<SemanticsPropertyReceiver, Unit>() { // from class: vea.raceremote.control.DrivingPadKt$DrivingPad$1$1$1
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(1);
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public /* bridge */ /* synthetic */ Unit invoke(SemanticsPropertyReceiver semanticsPropertyReceiver) {
                            invoke2(semanticsPropertyReceiver);
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2(SemanticsPropertyReceiver $this$semantics) {
                            Intrinsics.checkNotNullParameter($this$semantics, "$this$semantics");
                            SemanticsPropertiesKt.setContentDescription($this$semantics, label + LiveLiterals$DrivingPadKt.INSTANCE.m6512String$1$str$arg0$call$setcontentDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            SemanticsPropertiesKt.setStateDescription($this$semantics, ((int) (f * LiveLiterals$DrivingPadKt.INSTANCE.m6511Int$arg0$calltimes$$this$calltoInt$0$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad())) + LiveLiterals$DrivingPadKt.INSTANCE.m6513String$1$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            if (!z) {
                                SemanticsPropertiesKt.disabled($this$semantics);
                            }
                        }
                    };
                    $composer2.updateRememberedValue(value$iv$iv);
                }
                $composer2.endReplaceableGroup();
                Modifier modifierSemantics$default4 = SemanticsModifierKt.semantics$default(modifierTestTag4, false, (Function1) value$iv$iv, 1, null);
                Boolean boolValueOf7 = Boolean.valueOf(enabled);
                Boolean boolValueOf8 = Boolean.valueOf(vertical);
                Object key1$iv11 = Boolean.valueOf(enabled);
                Object key2$iv15 = Boolean.valueOf(vertical);
                int i111 = (($dirty >> 9) & 14) | ($dirty & 112);
                $composer2.startReplaceableGroup(1618982084);
                ComposerKt.sourceInformation($composer2, "C(remember)P(1,2,3):Composables.kt#9igjgp");
                invalid$iv$iv2 = $composer2.changed(key1$iv11) | $composer2.changed(key2$iv15) | $composer2.changed(change$delegate);
                value$iv$iv2 = $composer2.rememberedValue();
                if (!invalid$iv$iv2) {
                    key2$iv = Composer.INSTANCE.getEmpty();
                    if (value$iv$iv2 == key2$iv) {
                    }
                    $composer2.endReplaceableGroup();
                    Modifier modifierPointerInput7 = SuspendingPointerInputFilterKt.pointerInput(modifierSemantics$default4, boolValueOf7, boolValueOf8, (Function2) value$iv$iv2);
                    Object key1$iv12 = Boolean.valueOf(vertical);
                    Object key2$iv16 = Color.m1651boximpl(accent);
                    Object key3$iv11 = Float.valueOf(value);
                    int i112 = (($dirty >> 3) & 14) | ($dirty & 896);
                    $composer2.startReplaceableGroup(1618982084);
                    ComposerKt.sourceInformation($composer2, "C(remember)P(1,2,3):Composables.kt#9igjgp");
                    invalid$iv$iv3 = $composer2.changed(key1$iv12) | $composer2.changed(key2$iv16) | $composer2.changed(key3$iv11);
                    value$iv$iv3 = $composer2.rememberedValue();
                    if (!invalid$iv$iv3) {
                        key1$iv = Composer.INSTANCE.getEmpty();
                        if (value$iv$iv3 == key1$iv) {
                        }
                        $composer2.endReplaceableGroup();
                        CanvasKt.Canvas(modifierPointerInput7, (Function1) value$iv$iv3, $composer2, 0);
                        liveLiterals$DrivingPadKt2 = LiveLiterals$DrivingPadKt.INSTANCE;
                        if (vertical) {
                            strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6514String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        } else {
                            strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        }
                        TextKt.m1249TextfLXpl1I(strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, MaterialTheme.INSTANCE.getTypography($composer2, MaterialTheme.$stable).getCaption(), $composer2, 0, 0, 32766);
                        ComposerKt.sourceInformationMarkerEnd($composer2);
                    }
                    value$iv$iv3 = (Function1) new Function1<DrawScope, Unit>() { // from class: vea.raceremote.control.DrivingPadKt$DrivingPad$1$3$1
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(1);
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public /* bridge */ /* synthetic */ Unit invoke(DrawScope drawScope) {
                            invoke2(drawScope);
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2(DrawScope $this$Canvas) {
                            Intrinsics.checkNotNullParameter($this$Canvas, "$this$Canvas");
                            int $this$dp$iv5 = LiveLiterals$DrivingPadKt.INSTANCE.m6507Int$$$this$call$getdp$$$$this$calltoPx$valradius$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                            float radius = $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv5));
                            float fM1491getHeightimpl = ((vertical ? Size.m1491getHeightimpl($this$Canvas.mo2155getSizeNHjbRc()) : Size.m1494getWidthimpl($this$Canvas.mo2155getSizeNHjbRc())) / LiveLiterals$DrivingPadKt.INSTANCE.m6509Int$arg0$calldiv$$this$callminus$$this$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad()) - radius;
                            int $this$dp$iv6 = LiveLiterals$DrivingPadKt.INSTANCE.m6504Int$$$this$call$getdp$$$$this$calltoPx$arg0$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                            float travel = RangesKt.coerceAtLeast(fM1491getHeightimpl - $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv6)), LiveLiterals$DrivingPadKt.INSTANCE.m6490Float$arg0$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            long delta = vertical ? OffsetKt.Offset(LiveLiterals$DrivingPadKt.INSTANCE.m6488Float$arg0$callOffset$branch$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), -travel) : OffsetKt.Offset(travel, LiveLiterals$DrivingPadKt.INSTANCE.m6500Float$arg1$callOffset$else$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            long j = accent;
                            long jM1659copywmQWz5c6 = Color.m1659copywmQWz5c(j, (14 & 1) != 0 ? Color.m1663getAlphaimpl(j) : LiveLiterals$DrivingPadKt.INSTANCE.m6494Float$arg0$callcopy$arg0$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(j) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(j) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(j) : 0.0f);
                            long jM1429minusMKHz9U = Offset.m1429minusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), delta);
                            long jM1430plusMKHz9U = Offset.m1430plusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), delta);
                            int $this$dp$iv7 = LiveLiterals$DrivingPadKt.INSTANCE.m6506Int$$$this$call$getdp$$$$this$calltoPx$arg3$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                            DrawScope.m2142drawLineNGM6Ib0$default($this$Canvas, jM1659copywmQWz5c6, jM1429minusMKHz9U, jM1430plusMKHz9U, $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv7)), 0, null, 0.0f, null, 0, 496, null);
                            long j2 = accent;
                            long jM1659copywmQWz5c7 = Color.m1659copywmQWz5c(j2, (14 & 1) != 0 ? Color.m1663getAlphaimpl(j2) : LiveLiterals$DrivingPadKt.INSTANCE.m6493Float$arg0$callcopy$arg0$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(j2) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(j2) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(j2) : 0.0f);
                            int $this$dp$iv8 = LiveLiterals$DrivingPadKt.INSTANCE.m6505Int$$$this$call$getdp$$$$this$calltoPx$arg1$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                            DrawScope.m2137drawCircleVaOC9Bg$default($this$Canvas, jM1659copywmQWz5c7, $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv8)), $this$Canvas.mo2154getCenterF1C5BW0(), 0.0f, null, null, 0, 120, null);
                            DrawScope.m2137drawCircleVaOC9Bg$default($this$Canvas, accent, radius, Offset.m1430plusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), Offset.m1432timestuRUvjQ(delta, f)), 0.0f, null, null, 0, 120, null);
                        }
                    };
                    $composer2.updateRememberedValue(value$iv$iv3);
                    $composer2.endReplaceableGroup();
                    CanvasKt.Canvas(modifierPointerInput7, (Function1) value$iv$iv3, $composer2, 0);
                    liveLiterals$DrivingPadKt2 = LiveLiterals$DrivingPadKt.INSTANCE;
                    if (vertical) {
                        strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6514String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                    } else {
                        strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                    }
                    TextKt.m1249TextfLXpl1I(strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, MaterialTheme.INSTANCE.getTypography($composer2, MaterialTheme.$stable).getCaption(), $composer2, 0, 0, 32766);
                    ComposerKt.sourceInformationMarkerEnd($composer2);
                }
                value$iv$iv2 = new DrivingPadKt$DrivingPad$1$2$1(z, vertical, change$delegate, null);
                $composer2.updateRememberedValue(value$iv$iv2);
                $composer2.endReplaceableGroup();
                Modifier modifierPointerInput8 = SuspendingPointerInputFilterKt.pointerInput(modifierSemantics$default4, boolValueOf7, boolValueOf8, (Function2) value$iv$iv2);
                Object key1$iv13 = Boolean.valueOf(vertical);
                Object key2$iv17 = Color.m1651boximpl(accent);
                Object key3$iv12 = Float.valueOf(value);
                int i113 = (($dirty >> 3) & 14) | ($dirty & 896);
                $composer2.startReplaceableGroup(1618982084);
                ComposerKt.sourceInformation($composer2, "C(remember)P(1,2,3):Composables.kt#9igjgp");
                invalid$iv$iv3 = $composer2.changed(key1$iv13) | $composer2.changed(key2$iv17) | $composer2.changed(key3$iv12);
                value$iv$iv3 = $composer2.rememberedValue();
                if (!invalid$iv$iv3) {
                    key1$iv = Composer.INSTANCE.getEmpty();
                    if (value$iv$iv3 == key1$iv) {
                    }
                    $composer2.endReplaceableGroup();
                    CanvasKt.Canvas(modifierPointerInput8, (Function1) value$iv$iv3, $composer2, 0);
                    liveLiterals$DrivingPadKt2 = LiveLiterals$DrivingPadKt.INSTANCE;
                    if (vertical) {
                        strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6514String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                    } else {
                        strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                    }
                    TextKt.m1249TextfLXpl1I(strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, MaterialTheme.INSTANCE.getTypography($composer2, MaterialTheme.$stable).getCaption(), $composer2, 0, 0, 32766);
                    ComposerKt.sourceInformationMarkerEnd($composer2);
                }
                value$iv$iv3 = (Function1) new Function1<DrawScope, Unit>() { // from class: vea.raceremote.control.DrivingPadKt$DrivingPad$1$3$1
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(1);
                    }

                    @Override // kotlin.jvm.functions.Function1
                    public /* bridge */ /* synthetic */ Unit invoke(DrawScope drawScope) {
                        invoke2(drawScope);
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2(DrawScope $this$Canvas) {
                        Intrinsics.checkNotNullParameter($this$Canvas, "$this$Canvas");
                        int $this$dp$iv5 = LiveLiterals$DrivingPadKt.INSTANCE.m6507Int$$$this$call$getdp$$$$this$calltoPx$valradius$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        float radius = $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv5));
                        float fM1491getHeightimpl = ((vertical ? Size.m1491getHeightimpl($this$Canvas.mo2155getSizeNHjbRc()) : Size.m1494getWidthimpl($this$Canvas.mo2155getSizeNHjbRc())) / LiveLiterals$DrivingPadKt.INSTANCE.m6509Int$arg0$calldiv$$this$callminus$$this$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad()) - radius;
                        int $this$dp$iv6 = LiveLiterals$DrivingPadKt.INSTANCE.m6504Int$$$this$call$getdp$$$$this$calltoPx$arg0$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        float travel = RangesKt.coerceAtLeast(fM1491getHeightimpl - $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv6)), LiveLiterals$DrivingPadKt.INSTANCE.m6490Float$arg0$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                        long delta = vertical ? OffsetKt.Offset(LiveLiterals$DrivingPadKt.INSTANCE.m6488Float$arg0$callOffset$branch$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), -travel) : OffsetKt.Offset(travel, LiveLiterals$DrivingPadKt.INSTANCE.m6500Float$arg1$callOffset$else$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                        long j = accent;
                        long jM1659copywmQWz5c6 = Color.m1659copywmQWz5c(j, (14 & 1) != 0 ? Color.m1663getAlphaimpl(j) : LiveLiterals$DrivingPadKt.INSTANCE.m6494Float$arg0$callcopy$arg0$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(j) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(j) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(j) : 0.0f);
                        long jM1429minusMKHz9U = Offset.m1429minusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), delta);
                        long jM1430plusMKHz9U = Offset.m1430plusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), delta);
                        int $this$dp$iv7 = LiveLiterals$DrivingPadKt.INSTANCE.m6506Int$$$this$call$getdp$$$$this$calltoPx$arg3$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        DrawScope.m2142drawLineNGM6Ib0$default($this$Canvas, jM1659copywmQWz5c6, jM1429minusMKHz9U, jM1430plusMKHz9U, $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv7)), 0, null, 0.0f, null, 0, 496, null);
                        long j2 = accent;
                        long jM1659copywmQWz5c7 = Color.m1659copywmQWz5c(j2, (14 & 1) != 0 ? Color.m1663getAlphaimpl(j2) : LiveLiterals$DrivingPadKt.INSTANCE.m6493Float$arg0$callcopy$arg0$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(j2) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(j2) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(j2) : 0.0f);
                        int $this$dp$iv8 = LiveLiterals$DrivingPadKt.INSTANCE.m6505Int$$$this$call$getdp$$$$this$calltoPx$arg1$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        DrawScope.m2137drawCircleVaOC9Bg$default($this$Canvas, jM1659copywmQWz5c7, $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv8)), $this$Canvas.mo2154getCenterF1C5BW0(), 0.0f, null, null, 0, 120, null);
                        DrawScope.m2137drawCircleVaOC9Bg$default($this$Canvas, accent, radius, Offset.m1430plusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), Offset.m1432timestuRUvjQ(delta, f)), 0.0f, null, null, 0, 120, null);
                    }
                };
                $composer2.updateRememberedValue(value$iv$iv3);
                $composer2.endReplaceableGroup();
                CanvasKt.Canvas(modifierPointerInput8, (Function1) value$iv$iv3, $composer2, 0);
                liveLiterals$DrivingPadKt2 = LiveLiterals$DrivingPadKt.INSTANCE;
                if (vertical) {
                    strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6514String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                } else {
                    strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                }
                TextKt.m1249TextfLXpl1I(strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, MaterialTheme.INSTANCE.getTypography($composer2, MaterialTheme.$stable).getCaption(), $composer2, 0, 0, 32766);
                ComposerKt.sourceInformationMarkerEnd($composer2);
            } else {
                int i114 = (($changed$iv >> 6) & 112) | 6;
                ColumnScope $this$DrivingPad_u24lambda_u248 = ColumnScopeInstance.INSTANCE;
                ComposerKt.sourceInformationMarkerStart($composer2, 216050297, "C36@1424L11,38@1524L6,40@1686L213,45@1945L1914,76@3861L472,37@1444L2889,84@4431L10,84@4342L108:DrivingPad.kt#597736");
                TextKt.m1249TextfLXpl1I(label, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, null, $composer2, $dirty & 14, 0, 65534);
                Modifier modifierWeight$default5 = ColumnScope.weight$default($this$DrivingPad_u24lambda_u248, SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), LiveLiterals$DrivingPadKt.INSTANCE.m6499Float$arg0$callweight$$$this$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), false, 2, null);
                long jM980getOnSurface0d7_KjU8 = MaterialTheme.INSTANCE.getColors($composer2, MaterialTheme.$stable).m980getOnSurface0d7_KjU();
                long jM1659copywmQWz5c6 = Color.m1659copywmQWz5c(jM980getOnSurface0d7_KjU8, (14 & 1) != 0 ? Color.m1663getAlphaimpl(jM980getOnSurface0d7_KjU8) : LiveLiterals$DrivingPadKt.INSTANCE.m6492Float$arg0$callcopy$arg0$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(jM980getOnSurface0d7_KjU8) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(jM980getOnSurface0d7_KjU8) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(jM980getOnSurface0d7_KjU8) : 0.0f);
                int $this$dp$iv5 = LiveLiterals$DrivingPadKt.INSTANCE.m6508Int$$$this$call$getdp$$arg0$callRoundedCornerShape$arg1$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                Modifier modifierM179backgroundbw27NRU5 = BackgroundKt.m179backgroundbw27NRU(modifierWeight$default5, jM1659copywmQWz5c6, RoundedCornerShapeKt.m677RoundedCornerShape0680j_4(Dp.m4046constructorimpl($this$dp$iv5)));
                liveLiterals$DrivingPadKt = LiveLiterals$DrivingPadKt.INSTANCE;
                if (vertical) {
                    strM6517String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt.m6515String$branch$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                } else {
                    strM6517String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt.m6517String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                }
                Modifier modifierTestTag5 = TestTagKt.testTag(modifierM179backgroundbw27NRU5, strM6517String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad);
                Object key2$iv18 = Float.valueOf(value);
                Object key3$iv13 = Boolean.valueOf(enabled);
                int i115 = ($dirty & 14) | (($dirty >> 3) & 112) | (($dirty >> 3) & 896);
                $composer2.startReplaceableGroup(1618982084);
                ComposerKt.sourceInformation($composer2, "C(remember)P(1,2,3):Composables.kt#9igjgp");
                invalid$iv$iv = $composer2.changed(label) | $composer2.changed(key2$iv18) | $composer2.changed(key3$iv13);
                Object it$iv$iv5 = $composer2.rememberedValue();
                if (invalid$iv$iv) {
                    f = value;
                    z = enabled;
                    value$iv$iv = new Function1<SemanticsPropertyReceiver, Unit>() { // from class: vea.raceremote.control.DrivingPadKt$DrivingPad$1$1$1
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(1);
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public /* bridge */ /* synthetic */ Unit invoke(SemanticsPropertyReceiver semanticsPropertyReceiver) {
                            invoke2(semanticsPropertyReceiver);
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2(SemanticsPropertyReceiver $this$semantics) {
                            Intrinsics.checkNotNullParameter($this$semantics, "$this$semantics");
                            SemanticsPropertiesKt.setContentDescription($this$semantics, label + LiveLiterals$DrivingPadKt.INSTANCE.m6512String$1$str$arg0$call$setcontentDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            SemanticsPropertiesKt.setStateDescription($this$semantics, ((int) (f * LiveLiterals$DrivingPadKt.INSTANCE.m6511Int$arg0$calltimes$$this$calltoInt$0$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad())) + LiveLiterals$DrivingPadKt.INSTANCE.m6513String$1$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            if (!z) {
                                SemanticsPropertiesKt.disabled($this$semantics);
                            }
                        }
                    };
                    $composer2.updateRememberedValue(value$iv$iv);
                } else {
                    f = value;
                    z = enabled;
                    value$iv$iv = new Function1<SemanticsPropertyReceiver, Unit>() { // from class: vea.raceremote.control.DrivingPadKt$DrivingPad$1$1$1
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(1);
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public /* bridge */ /* synthetic */ Unit invoke(SemanticsPropertyReceiver semanticsPropertyReceiver) {
                            invoke2(semanticsPropertyReceiver);
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2(SemanticsPropertyReceiver $this$semantics) {
                            Intrinsics.checkNotNullParameter($this$semantics, "$this$semantics");
                            SemanticsPropertiesKt.setContentDescription($this$semantics, label + LiveLiterals$DrivingPadKt.INSTANCE.m6512String$1$str$arg0$call$setcontentDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            SemanticsPropertiesKt.setStateDescription($this$semantics, ((int) (f * LiveLiterals$DrivingPadKt.INSTANCE.m6511Int$arg0$calltimes$$this$calltoInt$0$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad())) + LiveLiterals$DrivingPadKt.INSTANCE.m6513String$1$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            if (!z) {
                                SemanticsPropertiesKt.disabled($this$semantics);
                            }
                        }
                    };
                    $composer2.updateRememberedValue(value$iv$iv);
                }
                $composer2.endReplaceableGroup();
                Modifier modifierSemantics$default5 = SemanticsModifierKt.semantics$default(modifierTestTag5, false, (Function1) value$iv$iv, 1, null);
                Boolean boolValueOf9 = Boolean.valueOf(enabled);
                Boolean boolValueOf10 = Boolean.valueOf(vertical);
                Object key1$iv14 = Boolean.valueOf(enabled);
                Object key2$iv19 = Boolean.valueOf(vertical);
                int i116 = (($dirty >> 9) & 14) | ($dirty & 112);
                $composer2.startReplaceableGroup(1618982084);
                ComposerKt.sourceInformation($composer2, "C(remember)P(1,2,3):Composables.kt#9igjgp");
                invalid$iv$iv2 = $composer2.changed(key1$iv14) | $composer2.changed(key2$iv19) | $composer2.changed(change$delegate);
                value$iv$iv2 = $composer2.rememberedValue();
                if (!invalid$iv$iv2) {
                    key2$iv = Composer.INSTANCE.getEmpty();
                    if (value$iv$iv2 == key2$iv) {
                    }
                    $composer2.endReplaceableGroup();
                    Modifier modifierPointerInput9 = SuspendingPointerInputFilterKt.pointerInput(modifierSemantics$default5, boolValueOf9, boolValueOf10, (Function2) value$iv$iv2);
                    Object key1$iv15 = Boolean.valueOf(vertical);
                    Object key2$iv110 = Color.m1651boximpl(accent);
                    Object key3$iv14 = Float.valueOf(value);
                    int i117 = (($dirty >> 3) & 14) | ($dirty & 896);
                    $composer2.startReplaceableGroup(1618982084);
                    ComposerKt.sourceInformation($composer2, "C(remember)P(1,2,3):Composables.kt#9igjgp");
                    invalid$iv$iv3 = $composer2.changed(key1$iv15) | $composer2.changed(key2$iv110) | $composer2.changed(key3$iv14);
                    value$iv$iv3 = $composer2.rememberedValue();
                    if (!invalid$iv$iv3) {
                        key1$iv = Composer.INSTANCE.getEmpty();
                        if (value$iv$iv3 == key1$iv) {
                        }
                        $composer2.endReplaceableGroup();
                        CanvasKt.Canvas(modifierPointerInput9, (Function1) value$iv$iv3, $composer2, 0);
                        liveLiterals$DrivingPadKt2 = LiveLiterals$DrivingPadKt.INSTANCE;
                        if (vertical) {
                            strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6514String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        } else {
                            strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        }
                        TextKt.m1249TextfLXpl1I(strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, MaterialTheme.INSTANCE.getTypography($composer2, MaterialTheme.$stable).getCaption(), $composer2, 0, 0, 32766);
                        ComposerKt.sourceInformationMarkerEnd($composer2);
                    }
                    value$iv$iv3 = (Function1) new Function1<DrawScope, Unit>() { // from class: vea.raceremote.control.DrivingPadKt$DrivingPad$1$3$1
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(1);
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public /* bridge */ /* synthetic */ Unit invoke(DrawScope drawScope) {
                            invoke2(drawScope);
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2(DrawScope $this$Canvas) {
                            Intrinsics.checkNotNullParameter($this$Canvas, "$this$Canvas");
                            int $this$dp$iv6 = LiveLiterals$DrivingPadKt.INSTANCE.m6507Int$$$this$call$getdp$$$$this$calltoPx$valradius$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                            float radius = $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv6));
                            float fM1491getHeightimpl = ((vertical ? Size.m1491getHeightimpl($this$Canvas.mo2155getSizeNHjbRc()) : Size.m1494getWidthimpl($this$Canvas.mo2155getSizeNHjbRc())) / LiveLiterals$DrivingPadKt.INSTANCE.m6509Int$arg0$calldiv$$this$callminus$$this$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad()) - radius;
                            int $this$dp$iv7 = LiveLiterals$DrivingPadKt.INSTANCE.m6504Int$$$this$call$getdp$$$$this$calltoPx$arg0$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                            float travel = RangesKt.coerceAtLeast(fM1491getHeightimpl - $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv7)), LiveLiterals$DrivingPadKt.INSTANCE.m6490Float$arg0$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            long delta = vertical ? OffsetKt.Offset(LiveLiterals$DrivingPadKt.INSTANCE.m6488Float$arg0$callOffset$branch$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), -travel) : OffsetKt.Offset(travel, LiveLiterals$DrivingPadKt.INSTANCE.m6500Float$arg1$callOffset$else$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                            long j = accent;
                            long jM1659copywmQWz5c7 = Color.m1659copywmQWz5c(j, (14 & 1) != 0 ? Color.m1663getAlphaimpl(j) : LiveLiterals$DrivingPadKt.INSTANCE.m6494Float$arg0$callcopy$arg0$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(j) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(j) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(j) : 0.0f);
                            long jM1429minusMKHz9U = Offset.m1429minusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), delta);
                            long jM1430plusMKHz9U = Offset.m1430plusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), delta);
                            int $this$dp$iv8 = LiveLiterals$DrivingPadKt.INSTANCE.m6506Int$$$this$call$getdp$$$$this$calltoPx$arg3$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                            DrawScope.m2142drawLineNGM6Ib0$default($this$Canvas, jM1659copywmQWz5c7, jM1429minusMKHz9U, jM1430plusMKHz9U, $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv8)), 0, null, 0.0f, null, 0, 496, null);
                            long j2 = accent;
                            long jM1659copywmQWz5c8 = Color.m1659copywmQWz5c(j2, (14 & 1) != 0 ? Color.m1663getAlphaimpl(j2) : LiveLiterals$DrivingPadKt.INSTANCE.m6493Float$arg0$callcopy$arg0$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(j2) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(j2) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(j2) : 0.0f);
                            int $this$dp$iv9 = LiveLiterals$DrivingPadKt.INSTANCE.m6505Int$$$this$call$getdp$$$$this$calltoPx$arg1$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                            DrawScope.m2137drawCircleVaOC9Bg$default($this$Canvas, jM1659copywmQWz5c8, $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv9)), $this$Canvas.mo2154getCenterF1C5BW0(), 0.0f, null, null, 0, 120, null);
                            DrawScope.m2137drawCircleVaOC9Bg$default($this$Canvas, accent, radius, Offset.m1430plusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), Offset.m1432timestuRUvjQ(delta, f)), 0.0f, null, null, 0, 120, null);
                        }
                    };
                    $composer2.updateRememberedValue(value$iv$iv3);
                    $composer2.endReplaceableGroup();
                    CanvasKt.Canvas(modifierPointerInput9, (Function1) value$iv$iv3, $composer2, 0);
                    liveLiterals$DrivingPadKt2 = LiveLiterals$DrivingPadKt.INSTANCE;
                    if (vertical) {
                        strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6514String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                    } else {
                        strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                    }
                    TextKt.m1249TextfLXpl1I(strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, MaterialTheme.INSTANCE.getTypography($composer2, MaterialTheme.$stable).getCaption(), $composer2, 0, 0, 32766);
                    ComposerKt.sourceInformationMarkerEnd($composer2);
                }
                value$iv$iv2 = new DrivingPadKt$DrivingPad$1$2$1(z, vertical, change$delegate, null);
                $composer2.updateRememberedValue(value$iv$iv2);
                $composer2.endReplaceableGroup();
                Modifier modifierPointerInput10 = SuspendingPointerInputFilterKt.pointerInput(modifierSemantics$default5, boolValueOf9, boolValueOf10, (Function2) value$iv$iv2);
                Object key1$iv16 = Boolean.valueOf(vertical);
                Object key2$iv111 = Color.m1651boximpl(accent);
                Object key3$iv15 = Float.valueOf(value);
                int i118 = (($dirty >> 3) & 14) | ($dirty & 896);
                $composer2.startReplaceableGroup(1618982084);
                ComposerKt.sourceInformation($composer2, "C(remember)P(1,2,3):Composables.kt#9igjgp");
                invalid$iv$iv3 = $composer2.changed(key1$iv16) | $composer2.changed(key2$iv111) | $composer2.changed(key3$iv15);
                value$iv$iv3 = $composer2.rememberedValue();
                if (!invalid$iv$iv3) {
                    key1$iv = Composer.INSTANCE.getEmpty();
                    if (value$iv$iv3 == key1$iv) {
                    }
                    $composer2.endReplaceableGroup();
                    CanvasKt.Canvas(modifierPointerInput10, (Function1) value$iv$iv3, $composer2, 0);
                    liveLiterals$DrivingPadKt2 = LiveLiterals$DrivingPadKt.INSTANCE;
                    if (vertical) {
                        strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6514String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                    } else {
                        strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                    }
                    TextKt.m1249TextfLXpl1I(strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, MaterialTheme.INSTANCE.getTypography($composer2, MaterialTheme.$stable).getCaption(), $composer2, 0, 0, 32766);
                    ComposerKt.sourceInformationMarkerEnd($composer2);
                }
                value$iv$iv3 = (Function1) new Function1<DrawScope, Unit>() { // from class: vea.raceremote.control.DrivingPadKt$DrivingPad$1$3$1
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(1);
                    }

                    @Override // kotlin.jvm.functions.Function1
                    public /* bridge */ /* synthetic */ Unit invoke(DrawScope drawScope) {
                        invoke2(drawScope);
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2(DrawScope $this$Canvas) {
                        Intrinsics.checkNotNullParameter($this$Canvas, "$this$Canvas");
                        int $this$dp$iv6 = LiveLiterals$DrivingPadKt.INSTANCE.m6507Int$$$this$call$getdp$$$$this$calltoPx$valradius$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        float radius = $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv6));
                        float fM1491getHeightimpl = ((vertical ? Size.m1491getHeightimpl($this$Canvas.mo2155getSizeNHjbRc()) : Size.m1494getWidthimpl($this$Canvas.mo2155getSizeNHjbRc())) / LiveLiterals$DrivingPadKt.INSTANCE.m6509Int$arg0$calldiv$$this$callminus$$this$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad()) - radius;
                        int $this$dp$iv7 = LiveLiterals$DrivingPadKt.INSTANCE.m6504Int$$$this$call$getdp$$$$this$calltoPx$arg0$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        float travel = RangesKt.coerceAtLeast(fM1491getHeightimpl - $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv7)), LiveLiterals$DrivingPadKt.INSTANCE.m6490Float$arg0$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                        long delta = vertical ? OffsetKt.Offset(LiveLiterals$DrivingPadKt.INSTANCE.m6488Float$arg0$callOffset$branch$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), -travel) : OffsetKt.Offset(travel, LiveLiterals$DrivingPadKt.INSTANCE.m6500Float$arg1$callOffset$else$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad());
                        long j = accent;
                        long jM1659copywmQWz5c7 = Color.m1659copywmQWz5c(j, (14 & 1) != 0 ? Color.m1663getAlphaimpl(j) : LiveLiterals$DrivingPadKt.INSTANCE.m6494Float$arg0$callcopy$arg0$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(j) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(j) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(j) : 0.0f);
                        long jM1429minusMKHz9U = Offset.m1429minusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), delta);
                        long jM1430plusMKHz9U = Offset.m1430plusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), delta);
                        int $this$dp$iv8 = LiveLiterals$DrivingPadKt.INSTANCE.m6506Int$$$this$call$getdp$$$$this$calltoPx$arg3$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        DrawScope.m2142drawLineNGM6Ib0$default($this$Canvas, jM1659copywmQWz5c7, jM1429minusMKHz9U, jM1430plusMKHz9U, $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv8)), 0, null, 0.0f, null, 0, 496, null);
                        long j2 = accent;
                        long jM1659copywmQWz5c8 = Color.m1659copywmQWz5c(j2, (14 & 1) != 0 ? Color.m1663getAlphaimpl(j2) : LiveLiterals$DrivingPadKt.INSTANCE.m6493Float$arg0$callcopy$arg0$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad(), (14 & 2) != 0 ? Color.m1667getRedimpl(j2) : 0.0f, (14 & 4) != 0 ? Color.m1666getGreenimpl(j2) : 0.0f, (14 & 8) != 0 ? Color.m1664getBlueimpl(j2) : 0.0f);
                        int $this$dp$iv9 = LiveLiterals$DrivingPadKt.INSTANCE.m6505Int$$$this$call$getdp$$$$this$calltoPx$arg1$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad();
                        DrawScope.m2137drawCircleVaOC9Bg$default($this$Canvas, jM1659copywmQWz5c8, $this$Canvas.mo322toPx0680j_4(Dp.m4046constructorimpl($this$dp$iv9)), $this$Canvas.mo2154getCenterF1C5BW0(), 0.0f, null, null, 0, 120, null);
                        DrawScope.m2137drawCircleVaOC9Bg$default($this$Canvas, accent, radius, Offset.m1430plusMKHz9U($this$Canvas.mo2154getCenterF1C5BW0(), Offset.m1432timestuRUvjQ(delta, f)), 0.0f, null, null, 0, 120, null);
                    }
                };
                $composer2.updateRememberedValue(value$iv$iv3);
                $composer2.endReplaceableGroup();
                CanvasKt.Canvas(modifierPointerInput10, (Function1) value$iv$iv3, $composer2, 0);
                liveLiterals$DrivingPadKt2 = LiveLiterals$DrivingPadKt.INSTANCE;
                if (vertical) {
                    strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6514String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                } else {
                    strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = liveLiterals$DrivingPadKt2.m6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad();
                }
                TextKt.m1249TextfLXpl1I(strM6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, MaterialTheme.INSTANCE.getTypography($composer2, MaterialTheme.$stable).getCaption(), $composer2, 0, 0, 32766);
                ComposerKt.sourceInformationMarkerEnd($composer2);
            }
            $composer2.endReplaceableGroup();
            $composer2.endReplaceableGroup();
            $composer2.endNode();
            $composer2.endReplaceableGroup();
            $composer2.endReplaceableGroup();
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        final Modifier modifier5 = modifier3;
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.control.DrivingPadKt.DrivingPad.2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i20) {
                DrivingPadKt.DrivingPad(label, vertical, value, enabled, modifier5, function1, composer, $changed | 1, i);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Function1<Float, Unit> DrivingPad$lambda$0(State<? extends Function1<? super Float, Unit>> state) {
        Object thisObj$iv = state.getValue();
        return (Function1) thisObj$iv;
    }
}
