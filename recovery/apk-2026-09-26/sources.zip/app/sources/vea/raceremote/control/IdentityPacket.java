package vea.raceremote.control;

import java.util.Iterator;
import kotlin.Metadata;
import kotlin.collections.IntIterator;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

/* JADX INFO: compiled from: IdentityPacket.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0012\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0005\u001a\u0004\u0018\u00010\u00062\u0006\u0010\u0007\u001a\u00020\bR\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\t"}, d2 = {"Lvea/raceremote/control/IdentityPacket;", "", "()V", "PATH", "", "decode", "Lvea/raceremote/control/CarIdentity;", "bytes", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class IdentityPacket {
    public static final String PATH = "/control/identity";
    public static final IdentityPacket INSTANCE = new IdentityPacket();
    public static final int $stable = LiveLiterals$IdentityPacketKt.INSTANCE.m6533Int$classIdentityPacket();

    private IdentityPacket() {
    }

    public final CarIdentity decode(byte[] bytes) {
        Intrinsics.checkNotNullParameter(bytes, "bytes");
        if (bytes.length != 16 || bytes[0] != 82 || bytes[1] != 67 || bytes[2] != 1 || bytes[3] != -126 || bytes[14] != 0 || bytes[LiveLiterals$IdentityPacketKt.INSTANCE.m6526Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$fundecode$classIdentityPacket()] != ((byte) LiveLiterals$IdentityPacketKt.INSTANCE.m6525Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$fundecode$classIdentityPacket())) {
            return null;
        }
        long token = decode$number(bytes, LiveLiterals$IdentityPacketKt.INSTANCE.m6528Int$arg0$callnumber$valtoken$fundecode$classIdentityPacket(), LiveLiterals$IdentityPacketKt.INSTANCE.m6531Int$arg1$callnumber$valtoken$fundecode$classIdentityPacket());
        long chipId = decode$number(bytes, LiveLiterals$IdentityPacketKt.INSTANCE.m6527Int$arg0$callnumber$valchipId$fundecode$classIdentityPacket(), LiveLiterals$IdentityPacketKt.INSTANCE.m6530Int$arg1$callnumber$valchipId$fundecode$classIdentityPacket());
        if (token == LiveLiterals$IdentityPacketKt.INSTANCE.m6537Long$arg1$callEQEQ$$this$callnot$cond$cond$if1$fundecode$classIdentityPacket() || chipId == LiveLiterals$IdentityPacketKt.INSTANCE.m6536Long$arg1$callEQEQ$$this$callnot$branch$cond$if1$fundecode$classIdentityPacket()) {
            return null;
        }
        return new CarIdentity(token, chipId);
    }

    private static final long decode$number(byte[] $bytes, int offset, int count) {
        Iterable $this$fold$iv = RangesKt.until(LiveLiterals$IdentityPacketKt.INSTANCE.m6523Int$$$this$calluntil$$$this$callfold$funnumber$fundecode$classIdentityPacket(), count);
        long initial$iv = LiveLiterals$IdentityPacketKt.INSTANCE.m6535Long$arg0$callfold$funnumber$fundecode$classIdentityPacket();
        long accumulator$iv = initial$iv;
        Iterator<Integer> it = $this$fold$iv.iterator();
        while (it.hasNext()) {
            int element$iv = ((IntIterator) it).nextInt();
            long value = accumulator$iv;
            accumulator$iv = value | ((((long) $bytes[offset + element$iv]) & LiveLiterals$IdentityPacketKt.INSTANCE.m6534Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$fundecode$classIdentityPacket()) << (LiveLiterals$IdentityPacketKt.INSTANCE.m6524Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$fundecode$classIdentityPacket() * element$iv));
        }
        return accumulator$iv;
    }
}
