package vea.raceremote.control;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: CarControlClient.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/control/CarControlClient.kt")
public final class LiveLiterals$CarControlClientKt {

    /* JADX INFO: renamed from: Boolean$arg-0$call-$set-opened$$fun-disconnect$class-CarControlClient, reason: not valid java name */
    private static boolean f53Boolean$arg0$call$setopened$$fundisconnect$classCarControlClient;

    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-CarConnectionState, reason: not valid java name */
    private static boolean f58Boolean$branch$when1$funequals$classCarConnectionState;

    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-CarConnectionState, reason: not valid java name */
    private static boolean f59Boolean$branch$when2$funequals$classCarConnectionState;

    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-CarConnectionState, reason: not valid java name */
    private static boolean f60Boolean$branch$when3$funequals$classCarConnectionState;

    /* JADX INFO: renamed from: Boolean$branch$when-4$fun-equals$class-CarConnectionState, reason: not valid java name */
    private static boolean f61Boolean$branch$when4$funequals$classCarConnectionState;

    /* JADX INFO: renamed from: Boolean$branch$when-5$fun-equals$class-CarConnectionState, reason: not valid java name */
    private static boolean f62Boolean$branch$when5$funequals$classCarConnectionState;

    /* JADX INFO: renamed from: Boolean$branch$when-6$fun-equals$class-CarConnectionState, reason: not valid java name */
    private static boolean f63Boolean$branch$when6$funequals$classCarConnectionState;

    /* JADX INFO: renamed from: Boolean$param-connected$class-CarConnectionState, reason: not valid java name */
    private static boolean f65Boolean$paramconnected$classCarConnectionState;

    /* JADX INFO: renamed from: Boolean$param-connecting$class-CarConnectionState, reason: not valid java name */
    private static boolean f66Boolean$paramconnecting$classCarConnectionState;

    /* JADX INFO: renamed from: Boolean$param-traceAllCommands$class-CarControlClient, reason: not valid java name */
    private static boolean f67Boolean$paramtraceAllCommands$classCarControlClient;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-all$branch$cond$val-local$fun-connect$class-CarControlClient, reason: not valid java name */
    private static int f76Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$vallocal$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: Int$arg-0$call-$set-steering$$fun-disconnect$class-CarControlClient, reason: not valid java name */
    private static int f84Int$arg0$call$setsteering$$fundisconnect$classCarControlClient;

    /* JADX INFO: renamed from: Int$arg-0$call-$set-throttle$$fun-disconnect$class-CarControlClient, reason: not valid java name */
    private static int f85Int$arg0$call$setthrottle$$fundisconnect$classCarControlClient;

    /* JADX INFO: renamed from: Int$arg-0$call-get$arg-0$call-EQEQ$cond$else$branch$val-local$fun-connect$class-CarControlClient, reason: not valid java name */
    private static int f88Int$arg0$callget$arg0$callEQEQ$cond$else$branch$vallocal$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: Int$arg-1$call-EQEQ$branch$cond$cond$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static int f99Int$arg1$callEQEQ$branch$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: Int$arg-1$call-EQEQ$branch$cond$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static int f100Int$arg1$callEQEQ$branch$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: Int$class-CarConnectionState, reason: not valid java name */
    private static int f103Int$classCarConnectionState;

    /* JADX INFO: renamed from: Int$param-steering$class-CarConnectionState, reason: not valid java name */
    private static int f106Int$paramsteering$classCarConnectionState;

    /* JADX INFO: renamed from: Int$param-throttle$class-CarConnectionState, reason: not valid java name */
    private static int f107Int$paramthrottle$classCarConnectionState;

    /* JADX INFO: renamed from: Long$arg-0$call-$set-sequence$$fun-disconnect$class-CarControlClient, reason: not valid java name */
    private static long f109Long$arg0$call$setsequence$$fundisconnect$classCarControlClient;

    /* JADX INFO: renamed from: Long$arg-0$call-$set-token$$fun-disconnect$class-CarControlClient, reason: not valid java name */
    private static long f110Long$arg0$call$settoken$$fundisconnect$classCarControlClient;

    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$$this$call-not$cond$if-1$fun-disconnect$class-CarControlClient, reason: not valid java name */
    private static long f113Long$arg1$callEQEQ$$this$callnot$cond$if1$fundisconnect$classCarControlClient;

    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$branch$cond$cond$cond$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static long f114Long$arg1$callEQEQ$branch$cond$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$cond$cond$cond$cond$cond$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static long f115Long$arg1$callEQEQ$cond$cond$cond$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$cond$else$cond$if-2$fun-tick$class-CarControlClient, reason: not valid java name */
    private static long f116Long$arg1$callEQEQ$cond$else$cond$if2$funtick$classCarControlClient;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-$set-opened$$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-onOpen$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Boolean> f119State$Boolean$arg0$call$setopened$$branch$if$fun$anonymous$$arg1$callsynchronized$funonOpen$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-$set-opened$$fun-disconnect$class-CarControlClient, reason: not valid java name */
    private static State<Boolean> f120State$Boolean$arg0$call$setopened$$fundisconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-$init$$arg-0$call-$set-value$$branch-1$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Boolean> f121State$Boolean$arg1$call$init$$arg0$call$setvalue$$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-EQEQ$$this$call-not$cond$if-2$fun-send$class-CarControlClient, reason: not valid java name */
    private static State<Boolean> f122State$Boolean$arg1$callEQEQ$$this$callnot$cond$if2$funsend$classCarControlClient;

    /* JADX INFO: renamed from: State$Boolean$arg-2$call-$init$$arg-0$call-$set-value$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Boolean> f123State$Boolean$arg2$call$init$$arg0$call$setvalue$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Boolean$branch$when$fun-equals$class-CarConnectionState, reason: not valid java name */
    private static State<Boolean> f124State$Boolean$branch$when$funequals$classCarConnectionState;

    /* JADX INFO: renamed from: State$Boolean$branch$when-1$fun-equals$class-CarConnectionState, reason: not valid java name */
    private static State<Boolean> f125State$Boolean$branch$when1$funequals$classCarConnectionState;

    /* JADX INFO: renamed from: State$Boolean$branch$when-2$fun-equals$class-CarConnectionState, reason: not valid java name */
    private static State<Boolean> f126State$Boolean$branch$when2$funequals$classCarConnectionState;

    /* JADX INFO: renamed from: State$Boolean$branch$when-3$fun-equals$class-CarConnectionState, reason: not valid java name */
    private static State<Boolean> f127State$Boolean$branch$when3$funequals$classCarConnectionState;

    /* JADX INFO: renamed from: State$Boolean$branch$when-4$fun-equals$class-CarConnectionState, reason: not valid java name */
    private static State<Boolean> f128State$Boolean$branch$when4$funequals$classCarConnectionState;

    /* JADX INFO: renamed from: State$Boolean$branch$when-5$fun-equals$class-CarConnectionState, reason: not valid java name */
    private static State<Boolean> f129State$Boolean$branch$when5$funequals$classCarConnectionState;

    /* JADX INFO: renamed from: State$Boolean$branch$when-6$fun-equals$class-CarConnectionState, reason: not valid java name */
    private static State<Boolean> f130State$Boolean$branch$when6$funequals$classCarConnectionState;

    /* JADX INFO: renamed from: State$Boolean$fun-equals$class-CarConnectionState, reason: not valid java name */
    private static State<Boolean> f131State$Boolean$funequals$classCarConnectionState;

    /* JADX INFO: renamed from: State$Boolean$param-connected$class-CarConnectionState, reason: not valid java name */
    private static State<Boolean> f132State$Boolean$paramconnected$classCarConnectionState;

    /* JADX INFO: renamed from: State$Boolean$param-connecting$class-CarConnectionState, reason: not valid java name */
    private static State<Boolean> f133State$Boolean$paramconnecting$classCarConnectionState;

    /* JADX INFO: renamed from: State$Boolean$param-traceAllCommands$class-CarControlClient, reason: not valid java name */
    private static State<Boolean> f134State$Boolean$paramtraceAllCommands$classCarControlClient;

    /* JADX INFO: renamed from: State$Char$0$vararg$arg-0$call-split$$$this$call-map$val-octets$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Character> f135State$Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Float$arg-0$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-$set-steering$$fun-setInput$class-CarControlClient, reason: not valid java name */
    private static State<Float> f136State$Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient;

    /* JADX INFO: renamed from: State$Float$arg-0$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-$set-throttle$$fun-setInput$class-CarControlClient, reason: not valid java name */
    private static State<Float> f137State$Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient;

    /* JADX INFO: renamed from: State$Float$arg-1$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-$set-steering$$fun-setInput$class-CarControlClient, reason: not valid java name */
    private static State<Float> f138State$Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient;

    /* JADX INFO: renamed from: State$Float$arg-1$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-$set-throttle$$fun-setInput$class-CarControlClient, reason: not valid java name */
    private static State<Float> f139State$Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$$this$call-not$branch$cond$if-1$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f140State$Int$$this$callrangeTo$$this$callcontains$$this$callnot$branch$cond$if1$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f141State$Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$branch$else$branch$val-local$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f142State$Int$$this$callrangeTo$$this$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-all$branch$cond$val-local$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f143State$Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$vallocal$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$$this$call-toLong$arg-1$call-greaterOrEqual$branch$else$cond$if-2$fun-tick$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f144State$Int$$this$calltoLong$arg1$callgreaterOrEqual$branch$else$cond$if2$funtick$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$branch$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f145State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$branch-1$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f146State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$fun-$anonymous$$arg-0$call-let$else$when$branch$if-1$fun-tick$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f147State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$when$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f148State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$$this$call-toLong$arg-1$call-lessOrEqual$else$cond$if-1$fun-send$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f149State$Int$$this$calltoLong$arg1$calllessOrEqual$else$cond$if1$funsend$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$$this$call-toLong$arg-1$call-lessOrEqual$else$cond$if-2$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f150State$Int$$this$calltoLong$arg1$calllessOrEqual$else$cond$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$arg-0$call-$set-steering$$fun-disconnect$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f151State$Int$arg0$call$setsteering$$fundisconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$arg-0$call-$set-throttle$$fun-disconnect$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f152State$Int$arg0$call$setthrottle$$fundisconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$arg-0$call-div$fun-$anonymous$$param-clockMs$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f153State$Int$arg0$calldiv$fun$anonymous$$paramclockMs$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$arg-0$call-get$arg-0$call-CHECK_NOT_NULL$arg-0$call-contains$branch$else$branch$val-local$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f154State$Int$arg0$callget$arg0$callCHECK_NOT_NULL$arg0$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$arg-0$call-get$arg-0$call-EQEQ$cond$else$branch$val-local$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f155State$Int$arg0$callget$arg0$callEQEQ$cond$else$branch$vallocal$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$arg-0$call-plus$$this$call-and$arg-0$call-$set-sequence$$branch$if-3$fun-tick$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f156State$Int$arg0$callplus$$this$calland$arg0$call$setsequence$$branch$if3$funtick$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f157State$Int$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rangeTo$$this$call-contains$branch$else$branch$val-local$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f158State$Int$arg0$callrangeTo$$this$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-all$branch$cond$val-local$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f159State$Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$vallocal$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-CarConnectionState, reason: not valid java name */
    private static State<Integer> f160State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCarConnectionState;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-CarConnectionState, reason: not valid java name */
    private static State<Integer> f161State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classCarConnectionState;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-2$fun-hashCode$class-CarConnectionState, reason: not valid java name */
    private static State<Integer> f162State$Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classCarConnectionState;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-3$fun-hashCode$class-CarConnectionState, reason: not valid java name */
    private static State<Integer> f163State$Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classCarConnectionState;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-toInt$arg-0$call-$set-steering$$fun-setInput$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f164State$Int$arg0$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-toInt$arg-0$call-$set-throttle$$fun-setInput$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f165State$Int$arg0$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$arg-1$call-EQEQ$branch$cond$cond$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f166State$Int$arg1$callEQEQ$branch$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$arg-1$call-EQEQ$branch$cond$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f167State$Int$arg1$callEQEQ$branch$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$arg-1$call-EQEQ$cond$cond$val-local$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f168State$Int$arg1$callEQEQ$cond$cond$vallocal$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$arg-1$call-EQEQ$cond$else$branch$val-local$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f169State$Int$arg1$callEQEQ$cond$else$branch$vallocal$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$class-CarConnectionState, reason: not valid java name */
    private static State<Integer> f170State$Int$classCarConnectionState;

    /* JADX INFO: renamed from: State$Int$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f171State$Int$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$param-port$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Integer> f172State$Int$paramport$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Int$param-steering$class-CarConnectionState, reason: not valid java name */
    private static State<Integer> f173State$Int$paramsteering$classCarConnectionState;

    /* JADX INFO: renamed from: State$Int$param-throttle$class-CarConnectionState, reason: not valid java name */
    private static State<Integer> f174State$Int$paramthrottle$classCarConnectionState;

    /* JADX INFO: renamed from: State$Long$arg-0$call-$set-sequence$$branch$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Long> f175State$Long$arg0$call$setsequence$$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Long$arg-0$call-$set-sequence$$fun-disconnect$class-CarControlClient, reason: not valid java name */
    private static State<Long> f176State$Long$arg0$call$setsequence$$fundisconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Long$arg-0$call-$set-token$$fun-disconnect$class-CarControlClient, reason: not valid java name */
    private static State<Long> f177State$Long$arg0$call$settoken$$fundisconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Long$arg-0$call-and$arg-0$call-$set-sequence$$branch$if-3$fun-tick$class-CarControlClient, reason: not valid java name */
    private static State<Long> f178State$Long$arg0$calland$arg0$call$setsequence$$branch$if3$funtick$classCarControlClient;

    /* JADX INFO: renamed from: State$Long$arg-0$call-rangeTo$$this$call-contains$$this$call-not$branch$cond$if-1$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Long> f179State$Long$arg0$callrangeTo$$this$callcontains$$this$callnot$branch$cond$if1$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Long$arg-1$call-EQEQ$$this$call-not$cond$if-1$fun-disconnect$class-CarControlClient, reason: not valid java name */
    private static State<Long> f180State$Long$arg1$callEQEQ$$this$callnot$cond$if1$fundisconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Long$arg-1$call-EQEQ$branch$cond$cond$cond$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Long> f181State$Long$arg1$callEQEQ$branch$cond$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Long$arg-1$call-EQEQ$cond$cond$cond$cond$cond$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<Long> f182State$Long$arg1$callEQEQ$cond$cond$cond$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$Long$arg-1$call-EQEQ$cond$else$cond$if-2$fun-tick$class-CarControlClient, reason: not valid java name */
    private static State<Long> f183State$Long$arg1$callEQEQ$cond$else$cond$if2$funtick$classCarControlClient;

    /* JADX INFO: renamed from: State$Long$arg-1$call-scheduleAtFixedRate$class-CarControlClient, reason: not valid java name */
    private static State<Long> f184State$Long$arg1$callscheduleAtFixedRate$classCarControlClient;

    /* JADX INFO: renamed from: State$Long$arg-2$call-scheduleAtFixedRate$class-CarControlClient, reason: not valid java name */
    private static State<Long> f185State$Long$arg2$callscheduleAtFixedRate$classCarControlClient;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-invoke$branch$if$fun-$anonymous$$arg-0$call-let$else$when$branch$if-1$fun-tick$class-CarControlClient, reason: not valid java name */
    private static State<String> f186State$String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-invoke$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-onClosing$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f187State$String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg1$callsynchronized$funonClosing$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-invoke$branch$if$fun-disconnect$class-CarControlClient, reason: not valid java name */
    private static State<String> f188State$String$0$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-invoke$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f189State$String$0$str$arg0$callinvoke$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-invoke$branch$if-1$fun-send$class-CarControlClient, reason: not valid java name */
    private static State<String> f190State$String$0$str$arg0$callinvoke$branch$if1$funsend$classCarControlClient;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-invoke$branch$if-2$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f191State$String$0$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-onFailure$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f192State$String$0$str$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-invoke$fun-disconnect$class-CarControlClient, reason: not valid java name */
    private static State<String> f193State$String$0$str$arg0$callinvoke$fundisconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-url$$this$call-build$arg-0$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f194State$String$0$str$arg0$callurl$$this$callbuild$arg0$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$0$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    private static State<String> f195State$String$0$str$funtoString$classCarConnectionState;

    /* JADX INFO: renamed from: State$String$1$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    private static State<String> f196State$String$1$str$funtoString$classCarConnectionState;

    /* JADX INFO: renamed from: State$String$10$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    private static State<String> f197State$String$10$str$funtoString$classCarConnectionState;

    /* JADX INFO: renamed from: State$String$12$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    private static State<String> f198State$String$12$str$funtoString$classCarConnectionState;

    /* JADX INFO: renamed from: State$String$13$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    private static State<String> f199State$String$13$str$funtoString$classCarConnectionState;

    /* JADX INFO: renamed from: State$String$15$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    private static State<String> f200State$String$15$str$funtoString$classCarConnectionState;

    /* JADX INFO: renamed from: State$String$2$str$arg-0$call-invoke$branch$if$fun-$anonymous$$arg-0$call-let$else$when$branch$if-1$fun-tick$class-CarControlClient, reason: not valid java name */
    private static State<String> f201State$String$2$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient;

    /* JADX INFO: renamed from: State$String$2$str$arg-0$call-invoke$branch$if$fun-disconnect$class-CarControlClient, reason: not valid java name */
    private static State<String> f202State$String$2$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$2$str$arg-0$call-invoke$branch$if-1$fun-send$class-CarControlClient, reason: not valid java name */
    private static State<String> f203State$String$2$str$arg0$callinvoke$branch$if1$funsend$classCarControlClient;

    /* JADX INFO: renamed from: State$String$2$str$arg-0$call-invoke$branch$if-2$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f204State$String$2$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$2$str$arg-0$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-onFailure$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f205State$String$2$str$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$2$str$arg-0$call-url$$this$call-build$arg-0$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f206State$String$2$str$arg0$callurl$$this$callbuild$arg0$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$3$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    private static State<String> f207State$String$3$str$funtoString$classCarConnectionState;

    /* JADX INFO: renamed from: State$String$4$str$arg-0$call-invoke$branch$if$fun-$anonymous$$arg-0$call-let$else$when$branch$if-1$fun-tick$class-CarControlClient, reason: not valid java name */
    private static State<String> f208State$String$4$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient;

    /* JADX INFO: renamed from: State$String$4$str$arg-0$call-invoke$branch$if$fun-disconnect$class-CarControlClient, reason: not valid java name */
    private static State<String> f209State$String$4$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$4$str$arg-0$call-invoke$branch$if-2$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f210State$String$4$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$4$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    private static State<String> f211State$String$4$str$funtoString$classCarConnectionState;

    /* JADX INFO: renamed from: State$String$6$str$arg-0$call-invoke$branch$if$fun-disconnect$class-CarControlClient, reason: not valid java name */
    private static State<String> f212State$String$6$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$6$str$arg-0$call-invoke$branch$if-2$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f213State$String$6$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$6$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    private static State<String> f214State$String$6$str$funtoString$classCarConnectionState;

    /* JADX INFO: renamed from: State$String$7$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    private static State<String> f215State$String$7$str$funtoString$classCarConnectionState;

    /* JADX INFO: renamed from: State$String$9$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    private static State<String> f216State$String$9$str$funtoString$classCarConnectionState;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$arg-0$call-$set-value$$branch$if$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f217State$String$arg0$call$init$$arg0$call$setvalue$$branch$if$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$arg-0$call-$set-value$$branch$if-1$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f218State$String$arg0$call$init$$arg0$call$setvalue$$branch$if1$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$arg-0$call-$set-value$$branch-1$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f219State$String$arg0$call$init$$arg0$call$setvalue$$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$arg-0$call-$set-value$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f220State$String$arg0$call$init$$arg0$call$setvalue$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$arg-0$call-disconnect$branch$if$branch$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f221State$String$arg0$calldisconnect$branch$if$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$arg-0$call-disconnect$branch$if$branch-1$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f222State$String$arg0$calldisconnect$branch$if$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$arg-0$call-disconnect$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-onClosed$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f223State$String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonClosed$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$arg-0$call-disconnect$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-onFailure$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f224State$String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$arg-0$call-disconnect$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage-1$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f225State$String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonMessage1$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$arg-0$call-disconnect$branch$if$fun-setInput$class-CarControlClient, reason: not valid java name */
    private static State<String> f226State$String$arg0$calldisconnect$branch$if$funsetInput$classCarControlClient;

    /* JADX INFO: renamed from: State$String$arg-0$call-disconnect$branch$if-1$branch$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f227State$String$arg0$calldisconnect$branch$if1$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$arg-0$call-disconnect$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onClosing$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f228State$String$arg0$calldisconnect$branch$if1$fun$anonymous$$arg1$callsynchronized$funonClosing$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$arg-0$call-disconnect$branch$if-2$fun-send$class-CarControlClient, reason: not valid java name */
    private static State<String> f229State$String$arg0$calldisconnect$branch$if2$funsend$classCarControlClient;

    /* JADX INFO: renamed from: State$String$arg-0$call-disconnect$branch$if-2$fun-tick$class-CarControlClient, reason: not valid java name */
    private static State<String> f230State$String$arg0$calldisconnect$branch$if2$funtick$classCarControlClient;

    /* JADX INFO: renamed from: State$String$arg-0$call-disconnect$branch$if-3$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f231State$String$arg0$calldisconnect$branch$if3$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$arg-0$call-disconnect$branch$when$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f232State$String$arg0$calldisconnect$branch$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$arg-0$call-disconnect$branch-1$when$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f233State$String$arg0$calldisconnect$branch1$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$arg-0$call-disconnect$branch-2$when$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f234State$String$arg0$calldisconnect$branch2$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$arg-0$call-disconnect$else$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f235State$String$arg0$calldisconnect$else$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$arg-0$call-invoke$branch$if$fun-send$class-CarControlClient, reason: not valid java name */
    private static State<String> f236State$String$arg0$callinvoke$branch$if$funsend$classCarControlClient;

    /* JADX INFO: renamed from: State$String$arg-0$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-onOpen$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f237State$String$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonOpen$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$branch$if$val-path$fun-connect$class-CarControlClient, reason: not valid java name */
    private static State<String> f238State$String$branch$if$valpath$funconnect$classCarControlClient;

    /* JADX INFO: renamed from: State$String$param-message$class-CarConnectionState, reason: not valid java name */
    private static State<String> f239State$String$parammessage$classCarConnectionState;

    /* JADX INFO: renamed from: State$String$param-message$fun-disconnect$class-CarControlClient, reason: not valid java name */
    private static State<String> f240State$String$parammessage$fundisconnect$classCarControlClient;
    public static final LiveLiterals$CarControlClientKt INSTANCE = new LiveLiterals$CarControlClientKt();

    /* JADX INFO: renamed from: String$param-message$class-CarConnectionState, reason: not valid java name */
    private static String f294String$parammessage$classCarConnectionState = "Не подключено";

    /* JADX INFO: renamed from: String$0$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    private static String f250String$0$str$funtoString$classCarConnectionState = "CarConnectionState(";

    /* JADX INFO: renamed from: String$1$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    private static String f251String$1$str$funtoString$classCarConnectionState = "message=";

    /* JADX INFO: renamed from: String$3$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    private static String f262String$3$str$funtoString$classCarConnectionState = ", ";

    /* JADX INFO: renamed from: String$4$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    private static String f266String$4$str$funtoString$classCarConnectionState = "connected=";

    /* JADX INFO: renamed from: String$6$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    private static String f269String$6$str$funtoString$classCarConnectionState = ", ";

    /* JADX INFO: renamed from: String$7$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    private static String f270String$7$str$funtoString$classCarConnectionState = "connecting=";

    /* JADX INFO: renamed from: String$9$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    private static String f271String$9$str$funtoString$classCarConnectionState = ", ";

    /* JADX INFO: renamed from: String$10$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    private static String f252String$10$str$funtoString$classCarConnectionState = "throttle=";

    /* JADX INFO: renamed from: String$12$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    private static String f253String$12$str$funtoString$classCarConnectionState = ", ";

    /* JADX INFO: renamed from: String$13$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    private static String f254String$13$str$funtoString$classCarConnectionState = "steering=";

    /* JADX INFO: renamed from: String$15$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    private static String f255String$15$str$funtoString$classCarConnectionState = ")";

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-CarConnectionState, reason: not valid java name */
    private static int f93Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCarConnectionState = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-CarConnectionState, reason: not valid java name */
    private static int f94Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classCarConnectionState = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-2$fun-hashCode$class-CarConnectionState, reason: not valid java name */
    private static int f95Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classCarConnectionState = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-3$fun-hashCode$class-CarConnectionState, reason: not valid java name */
    private static int f96Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classCarConnectionState = 31;

    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-CarConnectionState, reason: not valid java name */
    private static boolean f57Boolean$branch$when$funequals$classCarConnectionState = true;

    /* JADX INFO: renamed from: Boolean$fun-equals$class-CarConnectionState, reason: not valid java name */
    private static boolean f64Boolean$funequals$classCarConnectionState = true;

    /* JADX INFO: renamed from: Int$arg-0$call-div$fun-$anonymous$$param-clockMs$class-CarControlClient, reason: not valid java name */
    private static int f86Int$arg0$calldiv$fun$anonymous$$paramclockMs$classCarControlClient = 1000000;

    /* JADX INFO: renamed from: Long$arg-1$call-scheduleAtFixedRate$class-CarControlClient, reason: not valid java name */
    private static long f117Long$arg1$callscheduleAtFixedRate$classCarControlClient = 20;

    /* JADX INFO: renamed from: Long$arg-2$call-scheduleAtFixedRate$class-CarControlClient, reason: not valid java name */
    private static long f118Long$arg2$callscheduleAtFixedRate$classCarControlClient = 20;

    /* JADX INFO: renamed from: Int$param-port$fun-connect$class-CarControlClient, reason: not valid java name */
    private static int f105Int$paramport$funconnect$classCarControlClient = 1337;

    /* JADX INFO: renamed from: Char$0$vararg$arg-0$call-split$$$this$call-map$val-octets$fun-connect$class-CarControlClient, reason: not valid java name */
    private static char f68Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$funconnect$classCarControlClient = '.';

    /* JADX INFO: renamed from: Int$arg-1$call-EQEQ$cond$cond$val-local$fun-connect$class-CarControlClient, reason: not valid java name */
    private static int f101Int$arg1$callEQEQ$cond$cond$vallocal$funconnect$classCarControlClient = 4;

    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-all$branch$cond$val-local$fun-connect$class-CarControlClient, reason: not valid java name */
    private static int f92Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$vallocal$funconnect$classCarControlClient = 255;

    /* JADX INFO: renamed from: Int$arg-1$call-EQEQ$cond$else$branch$val-local$fun-connect$class-CarControlClient, reason: not valid java name */
    private static int f102Int$arg1$callEQEQ$cond$else$branch$vallocal$funconnect$classCarControlClient = 172;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$else$branch$val-local$fun-connect$class-CarControlClient, reason: not valid java name */
    private static int f75Int$$this$callrangeTo$$this$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient = 16;

    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$else$branch$val-local$fun-connect$class-CarControlClient, reason: not valid java name */
    private static int f91Int$arg0$callrangeTo$$this$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-get$arg-0$call-CHECK_NOT_NULL$arg-0$call-contains$branch$else$branch$val-local$fun-connect$class-CarControlClient, reason: not valid java name */
    private static int f87Int$arg0$callget$arg0$callCHECK_NOT_NULL$arg0$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient = 1;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if$fun-connect$class-CarControlClient, reason: not valid java name */
    private static int f74Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient = 1;

    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if$fun-connect$class-CarControlClient, reason: not valid java name */
    private static int f90Int$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient = 65535;

    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-0$call-$set-value$$branch$if$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f272String$arg0$call$init$$arg0$call$setvalue$$branch$if$funconnect$classCarControlClient = "Укажи локальный IPv4-адрес машинки";

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$$this$call-not$branch$cond$if-1$fun-connect$class-CarControlClient, reason: not valid java name */
    private static int f73Int$$this$callrangeTo$$this$callcontains$$this$callnot$branch$cond$if1$funconnect$classCarControlClient = 1;

    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$$this$call-not$branch$cond$if-1$fun-connect$class-CarControlClient, reason: not valid java name */
    private static long f112Long$arg0$callrangeTo$$this$callcontains$$this$callnot$branch$cond$if1$funconnect$classCarControlClient = 281474976710655L;

    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-0$call-$set-value$$branch$if-1$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f273String$arg0$call$init$$arg0$call$setvalue$$branch$if1$funconnect$classCarControlClient = "Некорректный ID машинки";

    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-0$call-$set-value$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f275String$arg0$call$init$$arg0$call$setvalue$$funconnect$classCarControlClient = "Подключение…";

    /* JADX INFO: renamed from: Boolean$arg-2$call-$init$$arg-0$call-$set-value$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static boolean f56Boolean$arg2$call$init$$arg0$call$setvalue$$funconnect$classCarControlClient = true;

    /* JADX INFO: renamed from: String$branch$if$val-path$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f293String$branch$if$valpath$funconnect$classCarControlClient = "/control";

    /* JADX INFO: renamed from: String$0$str$arg-0$call-url$$this$call-build$arg-0$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f249String$0$str$arg0$callurl$$this$callbuild$arg0$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = "ws://";

    /* JADX INFO: renamed from: String$2$str$arg-0$call-url$$this$call-build$arg-0$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f261String$2$str$arg0$callurl$$this$callbuild$arg0$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = ":";

    /* JADX INFO: renamed from: String$arg-0$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-onOpen$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f292String$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonOpen$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = "WebSocket opened";

    /* JADX INFO: renamed from: Boolean$arg-0$call-$set-opened$$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-onOpen$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static boolean f52Boolean$arg0$call$setopened$$branch$if$fun$anonymous$$arg1$callsynchronized$funonOpen$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = true;

    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f244String$0$str$arg0$callinvoke$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = "Received identity bytes=";

    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$when$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static int f81Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = 4000;

    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$when$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f287String$arg0$calldisconnect$branch$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = "Нет свежего ответа — остановлено";

    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch-1$when$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f288String$arg0$calldisconnect$branch1$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = "Машинка не подтвердила свой ID";

    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch-2$when$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f289String$arg0$calldisconnect$branch2$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = "По этому адресу другая машинка";

    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-lessOrEqual$else$cond$if-2$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static int f83Int$$this$calltoLong$arg1$calllessOrEqual$else$cond$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = 30;

    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$branch$if-2$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f246String$0$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = "Received bytes=";

    /* JADX INFO: renamed from: String$2$str$arg-0$call-invoke$branch$if-2$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f259String$2$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = " kind=";

    /* JADX INFO: renamed from: String$4$str$arg-0$call-invoke$branch$if-2$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f265String$4$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = " sequence=";

    /* JADX INFO: renamed from: String$6$str$arg-0$call-invoke$branch$if-2$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f268String$6$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = " rttMs=";

    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if-3$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f286String$arg0$calldisconnect$branch$if3$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = "Ошибка протокола";

    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$branch$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static int f78Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = 4000;

    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if$branch$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f276String$arg0$calldisconnect$branch$if$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = "Нет свежего ответа — остановлено";

    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if-1$branch$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f282String$arg0$calldisconnect$branch$if1$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = "ID и управление относятся к разным сессиям";

    /* JADX INFO: renamed from: Long$arg-0$call-$set-sequence$$branch$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static long f108Long$arg0$call$setsequence$$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = 1;

    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$branch-1$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static int f79Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = 200;

    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if$branch-1$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f277String$arg0$calldisconnect$branch$if$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = "Ответ задержался — остановлено";

    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-0$call-$set-value$$branch-1$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f274String$arg0$call$init$$arg0$call$setvalue$$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = "Управление подключено";

    /* JADX INFO: renamed from: Boolean$arg-1$call-$init$$arg-0$call-$set-value$$branch-1$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static boolean f54Boolean$arg1$call$init$$arg0$call$setvalue$$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = true;

    /* JADX INFO: renamed from: String$arg-0$call-disconnect$else$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f290String$arg0$calldisconnect$else$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = "Ответ не соответствует сессии";

    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage-1$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f280String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonMessage1$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = "Неподдерживаемый протокол";

    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-onFailure$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f247String$0$str$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = "WebSocket failure: ";

    /* JADX INFO: renamed from: String$2$str$arg-0$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-onFailure$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f260String$2$str$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = ": ";

    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-onFailure$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f279String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = "Нет связи — остановлено";

    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-onClosing$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f242String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg1$callsynchronized$funonClosing$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = "Peer closing code=";

    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onClosing$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f283String$arg0$calldisconnect$branch$if1$fun$anonymous$$arg1$callsynchronized$funonClosing$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = "Соединение закрыто — остановлено";

    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-onClosed$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    private static String f278String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonClosed$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = "Соединение закрыто — остановлено";

    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if$fun-setInput$class-CarControlClient, reason: not valid java name */
    private static String f281String$arg0$calldisconnect$branch$if$funsetInput$classCarControlClient = "Некорректное управление";

    /* JADX INFO: renamed from: Float$arg-0$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-$set-throttle$$fun-setInput$class-CarControlClient, reason: not valid java name */
    private static float f70Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient = -1.0f;

    /* JADX INFO: renamed from: Float$arg-1$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-$set-throttle$$fun-setInput$class-CarControlClient, reason: not valid java name */
    private static float f72Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient = 1.0f;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-toInt$arg-0$call-$set-throttle$$fun-setInput$class-CarControlClient, reason: not valid java name */
    private static int f98Int$arg0$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient = 1000;

    /* JADX INFO: renamed from: Float$arg-0$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-$set-steering$$fun-setInput$class-CarControlClient, reason: not valid java name */
    private static float f69Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient = -1.0f;

    /* JADX INFO: renamed from: Float$arg-1$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-$set-steering$$fun-setInput$class-CarControlClient, reason: not valid java name */
    private static float f71Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient = 1.0f;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-toInt$arg-0$call-$set-steering$$fun-setInput$class-CarControlClient, reason: not valid java name */
    private static int f97Int$arg0$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient = 1000;

    /* JADX INFO: renamed from: String$arg-0$call-invoke$branch$if$fun-send$class-CarControlClient, reason: not valid java name */
    private static String f291String$arg0$callinvoke$branch$if$funsend$classCarControlClient = "Sending neutral ARM";

    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-lessOrEqual$else$cond$if-1$fun-send$class-CarControlClient, reason: not valid java name */
    private static int f82Int$$this$calltoLong$arg1$calllessOrEqual$else$cond$if1$funsend$classCarControlClient = 30;

    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$branch$if-1$fun-send$class-CarControlClient, reason: not valid java name */
    private static String f245String$0$str$arg0$callinvoke$branch$if1$funsend$classCarControlClient = "Send kind=";

    /* JADX INFO: renamed from: String$2$str$arg-0$call-invoke$branch$if-1$fun-send$class-CarControlClient, reason: not valid java name */
    private static String f258String$2$str$arg0$callinvoke$branch$if1$funsend$classCarControlClient = " sequence=";

    /* JADX INFO: renamed from: Boolean$arg-1$call-EQEQ$$this$call-not$cond$if-2$fun-send$class-CarControlClient, reason: not valid java name */
    private static boolean f55Boolean$arg1$callEQEQ$$this$callnot$cond$if2$funsend$classCarControlClient = true;

    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if-2$fun-send$class-CarControlClient, reason: not valid java name */
    private static String f284String$arg0$calldisconnect$branch$if2$funsend$classCarControlClient = "Не удалось отправить команду";

    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$fun-$anonymous$$arg-0$call-let$else$when$branch$if-1$fun-tick$class-CarControlClient, reason: not valid java name */
    private static int f80Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient = 100;

    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$branch$if$fun-$anonymous$$arg-0$call-let$else$when$branch$if-1$fun-tick$class-CarControlClient, reason: not valid java name */
    private static String f241String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient = "Tick gapMs=";

    /* JADX INFO: renamed from: String$2$str$arg-0$call-invoke$branch$if$fun-$anonymous$$arg-0$call-let$else$when$branch$if-1$fun-tick$class-CarControlClient, reason: not valid java name */
    private static String f256String$2$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient = " pending=";

    /* JADX INFO: renamed from: String$4$str$arg-0$call-invoke$branch$if$fun-$anonymous$$arg-0$call-let$else$when$branch$if-1$fun-tick$class-CarControlClient, reason: not valid java name */
    private static String f263String$4$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient = " queueBytes=";

    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-greaterOrEqual$branch$else$cond$if-2$fun-tick$class-CarControlClient, reason: not valid java name */
    private static int f77Int$$this$calltoLong$arg1$callgreaterOrEqual$branch$else$cond$if2$funtick$classCarControlClient = 4000;

    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if-2$fun-tick$class-CarControlClient, reason: not valid java name */
    private static String f285String$arg0$calldisconnect$branch$if2$funtick$classCarControlClient = "Нет свежего ответа — остановлено";

    /* JADX INFO: renamed from: Int$arg-0$call-plus$$this$call-and$arg-0$call-$set-sequence$$branch$if-3$fun-tick$class-CarControlClient, reason: not valid java name */
    private static int f89Int$arg0$callplus$$this$calland$arg0$call$setsequence$$branch$if3$funtick$classCarControlClient = 1;

    /* JADX INFO: renamed from: Long$arg-0$call-and$arg-0$call-$set-sequence$$branch$if-3$fun-tick$class-CarControlClient, reason: not valid java name */
    private static long f111Long$arg0$calland$arg0$call$setsequence$$branch$if3$funtick$classCarControlClient = 4294967295L;

    /* JADX INFO: renamed from: String$param-message$fun-disconnect$class-CarControlClient, reason: not valid java name */
    private static String f295String$parammessage$fundisconnect$classCarControlClient = "Остановлено";

    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$branch$if$fun-disconnect$class-CarControlClient, reason: not valid java name */
    private static String f243String$0$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient = "Disconnect context sequence=";

    /* JADX INFO: renamed from: String$2$str$arg-0$call-invoke$branch$if$fun-disconnect$class-CarControlClient, reason: not valid java name */
    private static String f257String$2$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient = " pending=";

    /* JADX INFO: renamed from: String$4$str$arg-0$call-invoke$branch$if$fun-disconnect$class-CarControlClient, reason: not valid java name */
    private static String f264String$4$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient = " elapsedSinceSendMs=";

    /* JADX INFO: renamed from: String$6$str$arg-0$call-invoke$branch$if$fun-disconnect$class-CarControlClient, reason: not valid java name */
    private static String f267String$6$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient = " queueBytes=";

    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$fun-disconnect$class-CarControlClient, reason: not valid java name */
    private static String f248String$0$str$arg0$callinvoke$fundisconnect$classCarControlClient = "Disconnect: ";

    /* JADX INFO: renamed from: Int$class-CarControlClient, reason: not valid java name */
    private static int f104Int$classCarControlClient = 8;

    @LiveLiteralInfo(key = "Boolean$arg-0$call-$set-opened$$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-onOpen$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 3035)
    /* JADX INFO: renamed from: Boolean$arg-0$call-$set-opened$$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-onOpen$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final boolean m5988Boolean$arg0$call$setopened$$branch$if$fun$anonymous$$arg1$callsynchronized$funonOpen$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f52Boolean$arg0$call$setopened$$branch$if$fun$anonymous$$arg1$callsynchronized$funonOpen$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<Boolean> stateLiveLiteral = f119State$Boolean$arg0$call$setopened$$branch$if$fun$anonymous$$arg1$callsynchronized$funonOpen$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-$set-opened$$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-onOpen$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", Boolean.valueOf(f52Boolean$arg0$call$setopened$$branch$if$fun$anonymous$$arg1$callsynchronized$funonOpen$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient));
            f119State$Boolean$arg0$call$setopened$$branch$if$fun$anonymous$$arg1$callsynchronized$funonOpen$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-$set-opened$$fun-disconnect$class-CarControlClient", offset = 8821)
    /* JADX INFO: renamed from: Boolean$arg-0$call-$set-opened$$fun-disconnect$class-CarControlClient, reason: not valid java name */
    public final boolean m5989Boolean$arg0$call$setopened$$fundisconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f53Boolean$arg0$call$setopened$$fundisconnect$classCarControlClient;
        }
        State<Boolean> stateLiveLiteral = f120State$Boolean$arg0$call$setopened$$fundisconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-$set-opened$$fun-disconnect$class-CarControlClient", Boolean.valueOf(f53Boolean$arg0$call$setopened$$fundisconnect$classCarControlClient));
            f120State$Boolean$arg0$call$setopened$$fundisconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-$init$$arg-0$call-$set-value$$branch-1$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 5445)
    /* JADX INFO: renamed from: Boolean$arg-1$call-$init$$arg-0$call-$set-value$$branch-1$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final boolean m5990Boolean$arg1$call$init$$arg0$call$setvalue$$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f54Boolean$arg1$call$init$$arg0$call$setvalue$$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<Boolean> stateLiveLiteral = f121State$Boolean$arg1$call$init$$arg0$call$setvalue$$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-$init$$arg-0$call-$set-value$$branch-1$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", Boolean.valueOf(f54Boolean$arg1$call$init$$arg0$call$setvalue$$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient));
            f121State$Boolean$arg1$call$init$$arg0$call$setvalue$$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-EQEQ$$this$call-not$cond$if-2$fun-send$class-CarControlClient", offset = 7380)
    /* JADX INFO: renamed from: Boolean$arg-1$call-EQEQ$$this$call-not$cond$if-2$fun-send$class-CarControlClient, reason: not valid java name */
    public final boolean m5991Boolean$arg1$callEQEQ$$this$callnot$cond$if2$funsend$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f55Boolean$arg1$callEQEQ$$this$callnot$cond$if2$funsend$classCarControlClient;
        }
        State<Boolean> stateLiveLiteral = f122State$Boolean$arg1$callEQEQ$$this$callnot$cond$if2$funsend$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-EQEQ$$this$call-not$cond$if-2$fun-send$class-CarControlClient", Boolean.valueOf(f55Boolean$arg1$callEQEQ$$this$callnot$cond$if2$funsend$classCarControlClient));
            f122State$Boolean$arg1$callEQEQ$$this$callnot$cond$if2$funsend$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-2$call-$init$$arg-0$call-$set-value$$fun-connect$class-CarControlClient", offset = 2485)
    /* JADX INFO: renamed from: Boolean$arg-2$call-$init$$arg-0$call-$set-value$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final boolean m5992Boolean$arg2$call$init$$arg0$call$setvalue$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f56Boolean$arg2$call$init$$arg0$call$setvalue$$funconnect$classCarControlClient;
        }
        State<Boolean> stateLiveLiteral = f123State$Boolean$arg2$call$init$$arg0$call$setvalue$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-2$call-$init$$arg-0$call-$set-value$$fun-connect$class-CarControlClient", Boolean.valueOf(f56Boolean$arg2$call$init$$arg0$call$setvalue$$funconnect$classCarControlClient));
            f123State$Boolean$arg2$call$init$$arg0$call$setvalue$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when$fun-equals$class-CarConnectionState", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-CarConnectionState, reason: not valid java name */
    public final boolean m5993Boolean$branch$when$funequals$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f57Boolean$branch$when$funequals$classCarConnectionState;
        }
        State<Boolean> stateLiveLiteral = f124State$Boolean$branch$when$funequals$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when$fun-equals$class-CarConnectionState", Boolean.valueOf(f57Boolean$branch$when$funequals$classCarConnectionState));
            f124State$Boolean$branch$when$funequals$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-1$fun-equals$class-CarConnectionState", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-CarConnectionState, reason: not valid java name */
    public final boolean m5994Boolean$branch$when1$funequals$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f58Boolean$branch$when1$funequals$classCarConnectionState;
        }
        State<Boolean> stateLiveLiteral = f125State$Boolean$branch$when1$funequals$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-1$fun-equals$class-CarConnectionState", Boolean.valueOf(f58Boolean$branch$when1$funequals$classCarConnectionState));
            f125State$Boolean$branch$when1$funequals$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-2$fun-equals$class-CarConnectionState", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-CarConnectionState, reason: not valid java name */
    public final boolean m5995Boolean$branch$when2$funequals$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f59Boolean$branch$when2$funequals$classCarConnectionState;
        }
        State<Boolean> stateLiveLiteral = f126State$Boolean$branch$when2$funequals$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-2$fun-equals$class-CarConnectionState", Boolean.valueOf(f59Boolean$branch$when2$funequals$classCarConnectionState));
            f126State$Boolean$branch$when2$funequals$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-3$fun-equals$class-CarConnectionState", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-CarConnectionState, reason: not valid java name */
    public final boolean m5996Boolean$branch$when3$funequals$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f60Boolean$branch$when3$funequals$classCarConnectionState;
        }
        State<Boolean> stateLiveLiteral = f127State$Boolean$branch$when3$funequals$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-3$fun-equals$class-CarConnectionState", Boolean.valueOf(f60Boolean$branch$when3$funequals$classCarConnectionState));
            f127State$Boolean$branch$when3$funequals$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-4$fun-equals$class-CarConnectionState", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-4$fun-equals$class-CarConnectionState, reason: not valid java name */
    public final boolean m5997Boolean$branch$when4$funequals$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f61Boolean$branch$when4$funequals$classCarConnectionState;
        }
        State<Boolean> stateLiveLiteral = f128State$Boolean$branch$when4$funequals$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-4$fun-equals$class-CarConnectionState", Boolean.valueOf(f61Boolean$branch$when4$funequals$classCarConnectionState));
            f128State$Boolean$branch$when4$funequals$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-5$fun-equals$class-CarConnectionState", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-5$fun-equals$class-CarConnectionState, reason: not valid java name */
    public final boolean m5998Boolean$branch$when5$funequals$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f62Boolean$branch$when5$funequals$classCarConnectionState;
        }
        State<Boolean> stateLiveLiteral = f129State$Boolean$branch$when5$funequals$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-5$fun-equals$class-CarConnectionState", Boolean.valueOf(f62Boolean$branch$when5$funequals$classCarConnectionState));
            f129State$Boolean$branch$when5$funequals$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-6$fun-equals$class-CarConnectionState", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-6$fun-equals$class-CarConnectionState, reason: not valid java name */
    public final boolean m5999Boolean$branch$when6$funequals$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f63Boolean$branch$when6$funequals$classCarConnectionState;
        }
        State<Boolean> stateLiveLiteral = f130State$Boolean$branch$when6$funequals$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-6$fun-equals$class-CarConnectionState", Boolean.valueOf(f63Boolean$branch$when6$funequals$classCarConnectionState));
            f130State$Boolean$branch$when6$funequals$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$fun-equals$class-CarConnectionState", offset = -2)
    /* JADX INFO: renamed from: Boolean$fun-equals$class-CarConnectionState, reason: not valid java name */
    public final boolean m6000Boolean$funequals$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f64Boolean$funequals$classCarConnectionState;
        }
        State<Boolean> stateLiveLiteral = f131State$Boolean$funequals$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$fun-equals$class-CarConnectionState", Boolean.valueOf(f64Boolean$funequals$classCarConnectionState));
            f131State$Boolean$funequals$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$param-connected$class-CarConnectionState", offset = 458)
    /* JADX INFO: renamed from: Boolean$param-connected$class-CarConnectionState, reason: not valid java name */
    public final boolean m6001Boolean$paramconnected$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f65Boolean$paramconnected$classCarConnectionState;
        }
        State<Boolean> stateLiveLiteral = f132State$Boolean$paramconnected$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$param-connected$class-CarConnectionState", Boolean.valueOf(f65Boolean$paramconnected$classCarConnectionState));
            f132State$Boolean$paramconnected$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$param-connecting$class-CarConnectionState", offset = 495)
    /* JADX INFO: renamed from: Boolean$param-connecting$class-CarConnectionState, reason: not valid java name */
    public final boolean m6002Boolean$paramconnecting$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f66Boolean$paramconnecting$classCarConnectionState;
        }
        State<Boolean> stateLiveLiteral = f133State$Boolean$paramconnecting$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$param-connecting$class-CarConnectionState", Boolean.valueOf(f66Boolean$paramconnecting$classCarConnectionState));
            f133State$Boolean$paramconnecting$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$param-traceAllCommands$class-CarControlClient", offset = 761)
    /* JADX INFO: renamed from: Boolean$param-traceAllCommands$class-CarControlClient, reason: not valid java name */
    public final boolean m6003Boolean$paramtraceAllCommands$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f67Boolean$paramtraceAllCommands$classCarControlClient;
        }
        State<Boolean> stateLiveLiteral = f134State$Boolean$paramtraceAllCommands$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$param-traceAllCommands$class-CarControlClient", Boolean.valueOf(f67Boolean$paramtraceAllCommands$classCarControlClient));
            f134State$Boolean$paramtraceAllCommands$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Char$0$vararg$arg-0$call-split$$$this$call-map$val-octets$fun-connect$class-CarControlClient", offset = 1715)
    /* JADX INFO: renamed from: Char$0$vararg$arg-0$call-split$$$this$call-map$val-octets$fun-connect$class-CarControlClient, reason: not valid java name */
    public final char m6004Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f68Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$funconnect$classCarControlClient;
        }
        State<Character> stateLiveLiteral = f135State$Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Char$0$vararg$arg-0$call-split$$$this$call-map$val-octets$fun-connect$class-CarControlClient", Character.valueOf(f68Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$funconnect$classCarControlClient));
            f135State$Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().charValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-$set-steering$$fun-setInput$class-CarControlClient", offset = 7018)
    /* JADX INFO: renamed from: Float$arg-0$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-$set-steering$$fun-setInput$class-CarControlClient, reason: not valid java name */
    public final float m6005Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f69Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient;
        }
        State<Float> stateLiveLiteral = f136State$Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-$set-steering$$fun-setInput$class-CarControlClient", Float.valueOf(f69Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient));
            f136State$Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-$set-throttle$$fun-setInput$class-CarControlClient", offset = 6950)
    /* JADX INFO: renamed from: Float$arg-0$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-$set-throttle$$fun-setInput$class-CarControlClient, reason: not valid java name */
    public final float m6006Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f70Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient;
        }
        State<Float> stateLiveLiteral = f137State$Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-$set-throttle$$fun-setInput$class-CarControlClient", Float.valueOf(f70Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient));
            f137State$Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-1$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-$set-steering$$fun-setInput$class-CarControlClient", offset = 7023)
    /* JADX INFO: renamed from: Float$arg-1$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-$set-steering$$fun-setInput$class-CarControlClient, reason: not valid java name */
    public final float m6007Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f71Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient;
        }
        State<Float> stateLiveLiteral = f138State$Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-1$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-$set-steering$$fun-setInput$class-CarControlClient", Float.valueOf(f71Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient));
            f138State$Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-1$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-$set-throttle$$fun-setInput$class-CarControlClient", offset = 6955)
    /* JADX INFO: renamed from: Float$arg-1$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-$set-throttle$$fun-setInput$class-CarControlClient, reason: not valid java name */
    public final float m6008Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f72Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient;
        }
        State<Float> stateLiveLiteral = f139State$Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-1$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-$set-throttle$$fun-setInput$class-CarControlClient", Float.valueOf(f72Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient));
            f139State$Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$$this$call-not$branch$cond$if-1$fun-connect$class-CarControlClient", offset = 2189)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$$this$call-not$branch$cond$if-1$fun-connect$class-CarControlClient, reason: not valid java name */
    public final int m6009Int$$this$callrangeTo$$this$callcontains$$this$callnot$branch$cond$if1$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f73Int$$this$callrangeTo$$this$callcontains$$this$callnot$branch$cond$if1$funconnect$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f140State$Int$$this$callrangeTo$$this$callcontains$$this$callnot$branch$cond$if1$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$$this$call-not$branch$cond$if-1$fun-connect$class-CarControlClient", Integer.valueOf(f73Int$$this$callrangeTo$$this$callcontains$$this$callnot$branch$cond$if1$funconnect$classCarControlClient));
            f140State$Int$$this$callrangeTo$$this$callcontains$$this$callnot$branch$cond$if1$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if$fun-connect$class-CarControlClient", offset = 2032)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if$fun-connect$class-CarControlClient, reason: not valid java name */
    public final int m6010Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f74Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f141State$Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if$fun-connect$class-CarControlClient", Integer.valueOf(f74Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient));
            f141State$Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$branch$else$branch$val-local$fun-connect$class-CarControlClient", offset = 1992)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$else$branch$val-local$fun-connect$class-CarControlClient, reason: not valid java name */
    public final int m6011Int$$this$callrangeTo$$this$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f75Int$$this$callrangeTo$$this$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f142State$Int$$this$callrangeTo$$this$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$branch$else$branch$val-local$fun-connect$class-CarControlClient", Integer.valueOf(f75Int$$this$callrangeTo$$this$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient));
            f142State$Int$$this$callrangeTo$$this$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-all$branch$cond$val-local$fun-connect$class-CarControlClient", offset = 1818)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-all$branch$cond$val-local$fun-connect$class-CarControlClient, reason: not valid java name */
    public final int m6012Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$vallocal$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f76Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$vallocal$funconnect$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f143State$Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$vallocal$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-all$branch$cond$val-local$fun-connect$class-CarControlClient", Integer.valueOf(f76Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$vallocal$funconnect$classCarControlClient));
            f143State$Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$vallocal$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-toLong$arg-1$call-greaterOrEqual$branch$else$cond$if-2$fun-tick$class-CarControlClient", offset = 7842)
    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-greaterOrEqual$branch$else$cond$if-2$fun-tick$class-CarControlClient, reason: not valid java name */
    public final int m6013Int$$this$calltoLong$arg1$callgreaterOrEqual$branch$else$cond$if2$funtick$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f77Int$$this$calltoLong$arg1$callgreaterOrEqual$branch$else$cond$if2$funtick$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f144State$Int$$this$calltoLong$arg1$callgreaterOrEqual$branch$else$cond$if2$funtick$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-toLong$arg-1$call-greaterOrEqual$branch$else$cond$if-2$fun-tick$class-CarControlClient", Integer.valueOf(f77Int$$this$calltoLong$arg1$callgreaterOrEqual$branch$else$cond$if2$funtick$classCarControlClient));
            f144State$Int$$this$calltoLong$arg1$callgreaterOrEqual$branch$else$cond$if2$funtick$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$branch$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 4683)
    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$branch$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final int m6014Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f78Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f145State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$branch$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", Integer.valueOf(f78Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient));
            f145State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$branch-1$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 5238)
    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$branch-1$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final int m6015Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f79Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f146State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$branch-1$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", Integer.valueOf(f79Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient));
            f146State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$fun-$anonymous$$arg-0$call-let$else$when$branch$if-1$fun-tick$class-CarControlClient", offset = 7600)
    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$fun-$anonymous$$arg-0$call-let$else$when$branch$if-1$fun-tick$class-CarControlClient, reason: not valid java name */
    public final int m6016Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f80Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f147State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$fun-$anonymous$$arg-0$call-let$else$when$branch$if-1$fun-tick$class-CarControlClient", Integer.valueOf(f80Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient));
            f147State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$when$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 3554)
    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$when$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final int m6017Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f81Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f148State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$when$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", Integer.valueOf(f81Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient));
            f148State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-toLong$arg-1$call-lessOrEqual$else$cond$if-1$fun-send$class-CarControlClient", offset = 7213)
    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-lessOrEqual$else$cond$if-1$fun-send$class-CarControlClient, reason: not valid java name */
    public final int m6018Int$$this$calltoLong$arg1$calllessOrEqual$else$cond$if1$funsend$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f82Int$$this$calltoLong$arg1$calllessOrEqual$else$cond$if1$funsend$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f149State$Int$$this$calltoLong$arg1$calllessOrEqual$else$cond$if1$funsend$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-toLong$arg-1$call-lessOrEqual$else$cond$if-1$fun-send$class-CarControlClient", Integer.valueOf(f82Int$$this$calltoLong$arg1$calllessOrEqual$else$cond$if1$funsend$classCarControlClient));
            f149State$Int$$this$calltoLong$arg1$calllessOrEqual$else$cond$if1$funsend$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-toLong$arg-1$call-lessOrEqual$else$cond$if-2$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 4138)
    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-lessOrEqual$else$cond$if-2$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final int m6019Int$$this$calltoLong$arg1$calllessOrEqual$else$cond$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f83Int$$this$calltoLong$arg1$calllessOrEqual$else$cond$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f150State$Int$$this$calltoLong$arg1$calllessOrEqual$else$cond$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-toLong$arg-1$call-lessOrEqual$else$cond$if-2$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", Integer.valueOf(f83Int$$this$calltoLong$arg1$calllessOrEqual$else$cond$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient));
            f150State$Int$$this$calltoLong$arg1$calllessOrEqual$else$cond$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-$set-steering$$fun-disconnect$class-CarControlClient", offset = 8809)
    /* JADX INFO: renamed from: Int$arg-0$call-$set-steering$$fun-disconnect$class-CarControlClient, reason: not valid java name */
    public final int m6020Int$arg0$call$setsteering$$fundisconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f84Int$arg0$call$setsteering$$fundisconnect$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f151State$Int$arg0$call$setsteering$$fundisconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-$set-steering$$fun-disconnect$class-CarControlClient", Integer.valueOf(f84Int$arg0$call$setsteering$$fundisconnect$classCarControlClient));
            f151State$Int$arg0$call$setsteering$$fundisconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-$set-throttle$$fun-disconnect$class-CarControlClient", offset = 8795)
    /* JADX INFO: renamed from: Int$arg-0$call-$set-throttle$$fun-disconnect$class-CarControlClient, reason: not valid java name */
    public final int m6021Int$arg0$call$setthrottle$$fundisconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f85Int$arg0$call$setthrottle$$fundisconnect$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f152State$Int$arg0$call$setthrottle$$fundisconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-$set-throttle$$fun-disconnect$class-CarControlClient", Integer.valueOf(f85Int$arg0$call$setthrottle$$fundisconnect$classCarControlClient));
            f152State$Int$arg0$call$setthrottle$$fundisconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-div$fun-$anonymous$$param-clockMs$class-CarControlClient", offset = 828)
    /* JADX INFO: renamed from: Int$arg-0$call-div$fun-$anonymous$$param-clockMs$class-CarControlClient, reason: not valid java name */
    public final int m6022Int$arg0$calldiv$fun$anonymous$$paramclockMs$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f86Int$arg0$calldiv$fun$anonymous$$paramclockMs$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f153State$Int$arg0$calldiv$fun$anonymous$$paramclockMs$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-div$fun-$anonymous$$param-clockMs$class-CarControlClient", Integer.valueOf(f86Int$arg0$calldiv$fun$anonymous$$paramclockMs$classCarControlClient));
            f153State$Int$arg0$calldiv$fun$anonymous$$paramclockMs$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-get$arg-0$call-CHECK_NOT_NULL$arg-0$call-contains$branch$else$branch$val-local$fun-connect$class-CarControlClient", offset = 1984)
    /* JADX INFO: renamed from: Int$arg-0$call-get$arg-0$call-CHECK_NOT_NULL$arg-0$call-contains$branch$else$branch$val-local$fun-connect$class-CarControlClient, reason: not valid java name */
    public final int m6023Int$arg0$callget$arg0$callCHECK_NOT_NULL$arg0$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f87Int$arg0$callget$arg0$callCHECK_NOT_NULL$arg0$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f154State$Int$arg0$callget$arg0$callCHECK_NOT_NULL$arg0$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-get$arg-0$call-CHECK_NOT_NULL$arg-0$call-contains$branch$else$branch$val-local$fun-connect$class-CarControlClient", Integer.valueOf(f87Int$arg0$callget$arg0$callCHECK_NOT_NULL$arg0$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient));
            f154State$Int$arg0$callget$arg0$callCHECK_NOT_NULL$arg0$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-get$arg-0$call-EQEQ$cond$else$branch$val-local$fun-connect$class-CarControlClient", offset = 1964)
    /* JADX INFO: renamed from: Int$arg-0$call-get$arg-0$call-EQEQ$cond$else$branch$val-local$fun-connect$class-CarControlClient, reason: not valid java name */
    public final int m6024Int$arg0$callget$arg0$callEQEQ$cond$else$branch$vallocal$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f88Int$arg0$callget$arg0$callEQEQ$cond$else$branch$vallocal$funconnect$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f155State$Int$arg0$callget$arg0$callEQEQ$cond$else$branch$vallocal$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-get$arg-0$call-EQEQ$cond$else$branch$val-local$fun-connect$class-CarControlClient", Integer.valueOf(f88Int$arg0$callget$arg0$callEQEQ$cond$else$branch$vallocal$funconnect$classCarControlClient));
            f155State$Int$arg0$callget$arg0$callEQEQ$cond$else$branch$vallocal$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-plus$$this$call-and$arg-0$call-$set-sequence$$branch$if-3$fun-tick$class-CarControlClient", offset = 8036)
    /* JADX INFO: renamed from: Int$arg-0$call-plus$$this$call-and$arg-0$call-$set-sequence$$branch$if-3$fun-tick$class-CarControlClient, reason: not valid java name */
    public final int m6025Int$arg0$callplus$$this$calland$arg0$call$setsequence$$branch$if3$funtick$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f89Int$arg0$callplus$$this$calland$arg0$call$setsequence$$branch$if3$funtick$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f156State$Int$arg0$callplus$$this$calland$arg0$call$setsequence$$branch$if3$funtick$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-plus$$this$call-and$arg-0$call-$set-sequence$$branch$if-3$fun-tick$class-CarControlClient", Integer.valueOf(f89Int$arg0$callplus$$this$calland$arg0$call$setsequence$$branch$if3$funtick$classCarControlClient));
            f156State$Int$arg0$callplus$$this$calland$arg0$call$setsequence$$branch$if3$funtick$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if$fun-connect$class-CarControlClient", offset = 2035)
    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if$fun-connect$class-CarControlClient, reason: not valid java name */
    public final int m6026Int$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f90Int$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f157State$Int$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if$fun-connect$class-CarControlClient", Integer.valueOf(f90Int$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient));
            f157State$Int$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rangeTo$$this$call-contains$branch$else$branch$val-local$fun-connect$class-CarControlClient", offset = 1996)
    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$else$branch$val-local$fun-connect$class-CarControlClient, reason: not valid java name */
    public final int m6027Int$arg0$callrangeTo$$this$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f91Int$arg0$callrangeTo$$this$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f158State$Int$arg0$callrangeTo$$this$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rangeTo$$this$call-contains$branch$else$branch$val-local$fun-connect$class-CarControlClient", Integer.valueOf(f91Int$arg0$callrangeTo$$this$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient));
            f158State$Int$arg0$callrangeTo$$this$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-all$branch$cond$val-local$fun-connect$class-CarControlClient", offset = 1821)
    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-all$branch$cond$val-local$fun-connect$class-CarControlClient, reason: not valid java name */
    public final int m6028Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$vallocal$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f92Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$vallocal$funconnect$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f159State$Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$vallocal$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-all$branch$cond$val-local$fun-connect$class-CarControlClient", Integer.valueOf(f92Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$vallocal$funconnect$classCarControlClient));
            f159State$Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$vallocal$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-CarConnectionState", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-CarConnectionState, reason: not valid java name */
    public final int m6029Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f93Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCarConnectionState;
        }
        State<Integer> stateLiveLiteral = f160State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-CarConnectionState", Integer.valueOf(f93Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCarConnectionState));
            f160State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-CarConnectionState", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-CarConnectionState, reason: not valid java name */
    public final int m6030Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f94Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classCarConnectionState;
        }
        State<Integer> stateLiveLiteral = f161State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-CarConnectionState", Integer.valueOf(f94Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classCarConnectionState));
            f161State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-2$fun-hashCode$class-CarConnectionState", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-2$fun-hashCode$class-CarConnectionState, reason: not valid java name */
    public final int m6031Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f95Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classCarConnectionState;
        }
        State<Integer> stateLiveLiteral = f162State$Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-2$fun-hashCode$class-CarConnectionState", Integer.valueOf(f95Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classCarConnectionState));
            f162State$Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-3$fun-hashCode$class-CarConnectionState", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-3$fun-hashCode$class-CarConnectionState, reason: not valid java name */
    public final int m6032Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f96Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classCarConnectionState;
        }
        State<Integer> stateLiveLiteral = f163State$Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-3$fun-hashCode$class-CarConnectionState", Integer.valueOf(f96Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classCarConnectionState));
            f163State$Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-toInt$arg-0$call-$set-steering$$fun-setInput$class-CarControlClient", offset = 7029)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-toInt$arg-0$call-$set-steering$$fun-setInput$class-CarControlClient, reason: not valid java name */
    public final int m6033Int$arg0$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f97Int$arg0$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f164State$Int$arg0$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-toInt$arg-0$call-$set-steering$$fun-setInput$class-CarControlClient", Integer.valueOf(f97Int$arg0$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient));
            f164State$Int$arg0$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-toInt$arg-0$call-$set-throttle$$fun-setInput$class-CarControlClient", offset = 6961)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-toInt$arg-0$call-$set-throttle$$fun-setInput$class-CarControlClient, reason: not valid java name */
    public final int m6034Int$arg0$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f98Int$arg0$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f165State$Int$arg0$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-toInt$arg-0$call-$set-throttle$$fun-setInput$class-CarControlClient", Integer.valueOf(f98Int$arg0$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient));
            f165State$Int$arg0$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-EQEQ$branch$cond$cond$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 4445)
    /* JADX INFO: renamed from: Int$arg-1$call-EQEQ$branch$cond$cond$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final int m6035Int$arg1$callEQEQ$branch$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f99Int$arg1$callEQEQ$branch$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f166State$Int$arg1$callEQEQ$branch$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-EQEQ$branch$cond$cond$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", Integer.valueOf(f99Int$arg1$callEQEQ$branch$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient));
            f166State$Int$arg1$callEQEQ$branch$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-EQEQ$branch$cond$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 4464)
    /* JADX INFO: renamed from: Int$arg-1$call-EQEQ$branch$cond$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final int m6036Int$arg1$callEQEQ$branch$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f100Int$arg1$callEQEQ$branch$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f167State$Int$arg1$callEQEQ$branch$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-EQEQ$branch$cond$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", Integer.valueOf(f100Int$arg1$callEQEQ$branch$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient));
            f167State$Int$arg1$callEQEQ$branch$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-EQEQ$cond$cond$val-local$fun-connect$class-CarControlClient", offset = 1780)
    /* JADX INFO: renamed from: Int$arg-1$call-EQEQ$cond$cond$val-local$fun-connect$class-CarControlClient, reason: not valid java name */
    public final int m6037Int$arg1$callEQEQ$cond$cond$vallocal$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f101Int$arg1$callEQEQ$cond$cond$vallocal$funconnect$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f168State$Int$arg1$callEQEQ$cond$cond$vallocal$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-EQEQ$cond$cond$val-local$fun-connect$class-CarControlClient", Integer.valueOf(f101Int$arg1$callEQEQ$cond$cond$vallocal$funconnect$classCarControlClient));
            f168State$Int$arg1$callEQEQ$cond$cond$vallocal$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-EQEQ$cond$else$branch$val-local$fun-connect$class-CarControlClient", offset = 1970)
    /* JADX INFO: renamed from: Int$arg-1$call-EQEQ$cond$else$branch$val-local$fun-connect$class-CarControlClient, reason: not valid java name */
    public final int m6038Int$arg1$callEQEQ$cond$else$branch$vallocal$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f102Int$arg1$callEQEQ$cond$else$branch$vallocal$funconnect$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f169State$Int$arg1$callEQEQ$cond$else$branch$vallocal$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-EQEQ$cond$else$branch$val-local$fun-connect$class-CarControlClient", Integer.valueOf(f102Int$arg1$callEQEQ$cond$else$branch$vallocal$funconnect$classCarControlClient));
            f169State$Int$arg1$callEQEQ$cond$else$branch$vallocal$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-CarConnectionState", offset = -1)
    /* JADX INFO: renamed from: Int$class-CarConnectionState, reason: not valid java name */
    public final int m6039Int$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f103Int$classCarConnectionState;
        }
        State<Integer> stateLiveLiteral = f170State$Int$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-CarConnectionState", Integer.valueOf(f103Int$classCarConnectionState));
            f170State$Int$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-CarControlClient", offset = -1)
    /* JADX INFO: renamed from: Int$class-CarControlClient, reason: not valid java name */
    public final int m6040Int$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f104Int$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f171State$Int$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-CarControlClient", Integer.valueOf(f104Int$classCarControlClient));
            f171State$Int$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$param-port$fun-connect$class-CarControlClient", offset = 1547)
    /* JADX INFO: renamed from: Int$param-port$fun-connect$class-CarControlClient, reason: not valid java name */
    public final int m6041Int$paramport$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f105Int$paramport$funconnect$classCarControlClient;
        }
        State<Integer> stateLiveLiteral = f172State$Int$paramport$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$param-port$fun-connect$class-CarControlClient", Integer.valueOf(f105Int$paramport$funconnect$classCarControlClient));
            f172State$Int$paramport$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$param-steering$class-CarConnectionState", offset = 553)
    /* JADX INFO: renamed from: Int$param-steering$class-CarConnectionState, reason: not valid java name */
    public final int m6042Int$paramsteering$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f106Int$paramsteering$classCarConnectionState;
        }
        State<Integer> stateLiveLiteral = f173State$Int$paramsteering$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$param-steering$class-CarConnectionState", Integer.valueOf(f106Int$paramsteering$classCarConnectionState));
            f173State$Int$paramsteering$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$param-throttle$class-CarConnectionState", offset = 526)
    /* JADX INFO: renamed from: Int$param-throttle$class-CarConnectionState, reason: not valid java name */
    public final int m6043Int$paramthrottle$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f107Int$paramthrottle$classCarConnectionState;
        }
        State<Integer> stateLiveLiteral = f174State$Int$paramthrottle$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$param-throttle$class-CarConnectionState", Integer.valueOf(f107Int$paramthrottle$classCarConnectionState));
            f174State$Int$paramthrottle$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-$set-sequence$$branch$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 5011)
    /* JADX INFO: renamed from: Long$arg-0$call-$set-sequence$$branch$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final long m6044Long$arg0$call$setsequence$$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f108Long$arg0$call$setsequence$$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<Long> stateLiveLiteral = f175State$Long$arg0$call$setsequence$$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-$set-sequence$$branch$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", Long.valueOf(f108Long$arg0$call$setsequence$$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient));
            f175State$Long$arg0$call$setsequence$$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-$set-sequence$$fun-disconnect$class-CarControlClient", offset = 8765)
    /* JADX INFO: renamed from: Long$arg-0$call-$set-sequence$$fun-disconnect$class-CarControlClient, reason: not valid java name */
    public final long m6045Long$arg0$call$setsequence$$fundisconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f109Long$arg0$call$setsequence$$fundisconnect$classCarControlClient;
        }
        State<Long> stateLiveLiteral = f176State$Long$arg0$call$setsequence$$fundisconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-$set-sequence$$fun-disconnect$class-CarControlClient", Long.valueOf(f109Long$arg0$call$setsequence$$fundisconnect$classCarControlClient));
            f176State$Long$arg0$call$setsequence$$fundisconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-$set-token$$fun-disconnect$class-CarControlClient", offset = 8751)
    /* JADX INFO: renamed from: Long$arg-0$call-$set-token$$fun-disconnect$class-CarControlClient, reason: not valid java name */
    public final long m6046Long$arg0$call$settoken$$fundisconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f110Long$arg0$call$settoken$$fundisconnect$classCarControlClient;
        }
        State<Long> stateLiveLiteral = f177State$Long$arg0$call$settoken$$fundisconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-$set-token$$fun-disconnect$class-CarControlClient", Long.valueOf(f110Long$arg0$call$settoken$$fundisconnect$classCarControlClient));
            f177State$Long$arg0$call$settoken$$fundisconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-and$arg-0$call-$set-sequence$$branch$if-3$fun-tick$class-CarControlClient", offset = 8043)
    /* JADX INFO: renamed from: Long$arg-0$call-and$arg-0$call-$set-sequence$$branch$if-3$fun-tick$class-CarControlClient, reason: not valid java name */
    public final long m6047Long$arg0$calland$arg0$call$setsequence$$branch$if3$funtick$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f111Long$arg0$calland$arg0$call$setsequence$$branch$if3$funtick$classCarControlClient;
        }
        State<Long> stateLiveLiteral = f178State$Long$arg0$calland$arg0$call$setsequence$$branch$if3$funtick$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-and$arg-0$call-$set-sequence$$branch$if-3$fun-tick$class-CarControlClient", Long.valueOf(f111Long$arg0$calland$arg0$call$setsequence$$branch$if3$funtick$classCarControlClient));
            f178State$Long$arg0$calland$arg0$call$setsequence$$branch$if3$funtick$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-rangeTo$$this$call-contains$$this$call-not$branch$cond$if-1$fun-connect$class-CarControlClient", offset = 2192)
    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$$this$call-not$branch$cond$if-1$fun-connect$class-CarControlClient, reason: not valid java name */
    public final long m6048Long$arg0$callrangeTo$$this$callcontains$$this$callnot$branch$cond$if1$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f112Long$arg0$callrangeTo$$this$callcontains$$this$callnot$branch$cond$if1$funconnect$classCarControlClient;
        }
        State<Long> stateLiveLiteral = f179State$Long$arg0$callrangeTo$$this$callcontains$$this$callnot$branch$cond$if1$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-rangeTo$$this$call-contains$$this$call-not$branch$cond$if-1$fun-connect$class-CarControlClient", Long.valueOf(f112Long$arg0$callrangeTo$$this$callcontains$$this$callnot$branch$cond$if1$funconnect$classCarControlClient));
            f179State$Long$arg0$callrangeTo$$this$callcontains$$this$callnot$branch$cond$if1$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-1$call-EQEQ$$this$call-not$cond$if-1$fun-disconnect$class-CarControlClient", offset = 8553)
    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$$this$call-not$cond$if-1$fun-disconnect$class-CarControlClient, reason: not valid java name */
    public final long m6049Long$arg1$callEQEQ$$this$callnot$cond$if1$fundisconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f113Long$arg1$callEQEQ$$this$callnot$cond$if1$fundisconnect$classCarControlClient;
        }
        State<Long> stateLiveLiteral = f180State$Long$arg1$callEQEQ$$this$callnot$cond$if1$fundisconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-1$call-EQEQ$$this$call-not$cond$if-1$fun-disconnect$class-CarControlClient", Long.valueOf(f113Long$arg1$callEQEQ$$this$callnot$cond$if1$fundisconnect$classCarControlClient));
            f180State$Long$arg1$callEQEQ$$this$callnot$cond$if1$fundisconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-1$call-EQEQ$branch$cond$cond$cond$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 4425)
    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$branch$cond$cond$cond$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final long m6050Long$arg1$callEQEQ$branch$cond$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f114Long$arg1$callEQEQ$branch$cond$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<Long> stateLiveLiteral = f181State$Long$arg1$callEQEQ$branch$cond$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-1$call-EQEQ$branch$cond$cond$cond$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", Long.valueOf(f114Long$arg1$callEQEQ$branch$cond$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient));
            f181State$Long$arg1$callEQEQ$branch$cond$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-1$call-EQEQ$cond$cond$cond$cond$cond$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 4372)
    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$cond$cond$cond$cond$cond$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final long m6051Long$arg1$callEQEQ$cond$cond$cond$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f115Long$arg1$callEQEQ$cond$cond$cond$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<Long> stateLiveLiteral = f182State$Long$arg1$callEQEQ$cond$cond$cond$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-1$call-EQEQ$cond$cond$cond$cond$cond$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", Long.valueOf(f115Long$arg1$callEQEQ$cond$cond$cond$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient));
            f182State$Long$arg1$callEQEQ$cond$cond$cond$cond$cond$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-1$call-EQEQ$cond$else$cond$if-2$fun-tick$class-CarControlClient", offset = 7825)
    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$cond$else$cond$if-2$fun-tick$class-CarControlClient, reason: not valid java name */
    public final long m6052Long$arg1$callEQEQ$cond$else$cond$if2$funtick$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f116Long$arg1$callEQEQ$cond$else$cond$if2$funtick$classCarControlClient;
        }
        State<Long> stateLiveLiteral = f183State$Long$arg1$callEQEQ$cond$else$cond$if2$funtick$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-1$call-EQEQ$cond$else$cond$if-2$fun-tick$class-CarControlClient", Long.valueOf(f116Long$arg1$callEQEQ$cond$else$cond$if2$funtick$classCarControlClient));
            f183State$Long$arg1$callEQEQ$cond$else$cond$if2$funtick$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-1$call-scheduleAtFixedRate$class-CarControlClient", offset = 1427)
    /* JADX INFO: renamed from: Long$arg-1$call-scheduleAtFixedRate$class-CarControlClient, reason: not valid java name */
    public final long m6053Long$arg1$callscheduleAtFixedRate$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f117Long$arg1$callscheduleAtFixedRate$classCarControlClient;
        }
        State<Long> stateLiveLiteral = f184State$Long$arg1$callscheduleAtFixedRate$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-1$call-scheduleAtFixedRate$class-CarControlClient", Long.valueOf(f117Long$arg1$callscheduleAtFixedRate$classCarControlClient));
            f184State$Long$arg1$callscheduleAtFixedRate$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-2$call-scheduleAtFixedRate$class-CarControlClient", offset = 1431)
    /* JADX INFO: renamed from: Long$arg-2$call-scheduleAtFixedRate$class-CarControlClient, reason: not valid java name */
    public final long m6054Long$arg2$callscheduleAtFixedRate$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f118Long$arg2$callscheduleAtFixedRate$classCarControlClient;
        }
        State<Long> stateLiveLiteral = f185State$Long$arg2$callscheduleAtFixedRate$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-2$call-scheduleAtFixedRate$class-CarControlClient", Long.valueOf(f118Long$arg2$callscheduleAtFixedRate$classCarControlClient));
            f185State$Long$arg2$callscheduleAtFixedRate$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-invoke$branch$if$fun-$anonymous$$arg-0$call-let$else$when$branch$if-1$fun-tick$class-CarControlClient", offset = 7618)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$branch$if$fun-$anonymous$$arg-0$call-let$else$when$branch$if-1$fun-tick$class-CarControlClient, reason: not valid java name */
    public final String m6055String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f241String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient;
        }
        State<String> stateLiveLiteral = f186State$String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-invoke$branch$if$fun-$anonymous$$arg-0$call-let$else$when$branch$if-1$fun-tick$class-CarControlClient", f241String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient);
            f186State$String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-invoke$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-onClosing$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 6303)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-onClosing$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6056String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg1$callsynchronized$funonClosing$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f242String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg1$callsynchronized$funonClosing$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f187State$String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg1$callsynchronized$funonClosing$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-invoke$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-onClosing$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", f242String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg1$callsynchronized$funonClosing$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient);
            f187State$String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg1$callsynchronized$funonClosing$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-invoke$branch$if$fun-disconnect$class-CarControlClient", offset = 8295)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$branch$if$fun-disconnect$class-CarControlClient, reason: not valid java name */
    public final String m6057String$0$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f243String$0$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f188State$String$0$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-invoke$branch$if$fun-disconnect$class-CarControlClient", f243String$0$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient);
            f188State$String$0$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-invoke$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 3361)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6058String$0$str$arg0$callinvoke$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f244String$0$str$arg0$callinvoke$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f189State$String$0$str$arg0$callinvoke$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-invoke$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", f244String$0$str$arg0$callinvoke$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient);
            f189State$String$0$str$arg0$callinvoke$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-invoke$branch$if-1$fun-send$class-CarControlClient", offset = 7230)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$branch$if-1$fun-send$class-CarControlClient, reason: not valid java name */
    public final String m6059String$0$str$arg0$callinvoke$branch$if1$funsend$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f245String$0$str$arg0$callinvoke$branch$if1$funsend$classCarControlClient;
        }
        State<String> stateLiveLiteral = f190State$String$0$str$arg0$callinvoke$branch$if1$funsend$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-invoke$branch$if-1$fun-send$class-CarControlClient", f245String$0$str$arg0$callinvoke$branch$if1$funsend$classCarControlClient);
            f190State$String$0$str$arg0$callinvoke$branch$if1$funsend$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-invoke$branch$if-2$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 4155)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$branch$if-2$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6060String$0$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f246String$0$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f191State$String$0$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-invoke$branch$if-2$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", f246String$0$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient);
            f191State$String$0$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-onFailure$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 5947)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-onFailure$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6061String$0$str$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f247String$0$str$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f192State$String$0$str$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-onFailure$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", f247String$0$str$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient);
            f192State$String$0$str$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-invoke$fun-disconnect$class-CarControlClient", offset = 8448)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$fun-disconnect$class-CarControlClient, reason: not valid java name */
    public final String m6062String$0$str$arg0$callinvoke$fundisconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f248String$0$str$arg0$callinvoke$fundisconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f193State$String$0$str$arg0$callinvoke$fundisconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-invoke$fun-disconnect$class-CarControlClient", f248String$0$str$arg0$callinvoke$fundisconnect$classCarControlClient);
            f193State$String$0$str$arg0$callinvoke$fundisconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-url$$this$call-build$arg-0$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 2757)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-url$$this$call-build$arg-0$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6063String$0$str$arg0$callurl$$this$callbuild$arg0$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f249String$0$str$arg0$callurl$$this$callbuild$arg0$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f194State$String$0$str$arg0$callurl$$this$callbuild$arg0$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-url$$this$call-build$arg-0$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", f249String$0$str$arg0$callurl$$this$callbuild$arg0$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient);
            f194State$String$0$str$arg0$callurl$$this$callbuild$arg0$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$fun-toString$class-CarConnectionState", offset = -2)
    /* JADX INFO: renamed from: String$0$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    public final String m6064String$0$str$funtoString$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f250String$0$str$funtoString$classCarConnectionState;
        }
        State<String> stateLiveLiteral = f195State$String$0$str$funtoString$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$fun-toString$class-CarConnectionState", f250String$0$str$funtoString$classCarConnectionState);
            f195State$String$0$str$funtoString$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$1$str$fun-toString$class-CarConnectionState", offset = -2)
    /* JADX INFO: renamed from: String$1$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    public final String m6065String$1$str$funtoString$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f251String$1$str$funtoString$classCarConnectionState;
        }
        State<String> stateLiveLiteral = f196State$String$1$str$funtoString$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$1$str$fun-toString$class-CarConnectionState", f251String$1$str$funtoString$classCarConnectionState);
            f196State$String$1$str$funtoString$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$10$str$fun-toString$class-CarConnectionState", offset = -2)
    /* JADX INFO: renamed from: String$10$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    public final String m6066String$10$str$funtoString$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f252String$10$str$funtoString$classCarConnectionState;
        }
        State<String> stateLiveLiteral = f197State$String$10$str$funtoString$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$10$str$fun-toString$class-CarConnectionState", f252String$10$str$funtoString$classCarConnectionState);
            f197State$String$10$str$funtoString$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$12$str$fun-toString$class-CarConnectionState", offset = -2)
    /* JADX INFO: renamed from: String$12$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    public final String m6067String$12$str$funtoString$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f253String$12$str$funtoString$classCarConnectionState;
        }
        State<String> stateLiveLiteral = f198State$String$12$str$funtoString$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$12$str$fun-toString$class-CarConnectionState", f253String$12$str$funtoString$classCarConnectionState);
            f198State$String$12$str$funtoString$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$13$str$fun-toString$class-CarConnectionState", offset = -2)
    /* JADX INFO: renamed from: String$13$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    public final String m6068String$13$str$funtoString$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f254String$13$str$funtoString$classCarConnectionState;
        }
        State<String> stateLiveLiteral = f199State$String$13$str$funtoString$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$13$str$fun-toString$class-CarConnectionState", f254String$13$str$funtoString$classCarConnectionState);
            f199State$String$13$str$funtoString$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$15$str$fun-toString$class-CarConnectionState", offset = -2)
    /* JADX INFO: renamed from: String$15$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    public final String m6069String$15$str$funtoString$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f255String$15$str$funtoString$classCarConnectionState;
        }
        State<String> stateLiveLiteral = f200State$String$15$str$funtoString$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$15$str$fun-toString$class-CarConnectionState", f255String$15$str$funtoString$classCarConnectionState);
            f200State$String$15$str$funtoString$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$arg-0$call-invoke$branch$if$fun-$anonymous$$arg-0$call-let$else$when$branch$if-1$fun-tick$class-CarControlClient", offset = 7640)
    /* JADX INFO: renamed from: String$2$str$arg-0$call-invoke$branch$if$fun-$anonymous$$arg-0$call-let$else$when$branch$if-1$fun-tick$class-CarControlClient, reason: not valid java name */
    public final String m6070String$2$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f256String$2$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient;
        }
        State<String> stateLiveLiteral = f201State$String$2$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$arg-0$call-invoke$branch$if$fun-$anonymous$$arg-0$call-let$else$when$branch$if-1$fun-tick$class-CarControlClient", f256String$2$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient);
            f201State$String$2$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$arg-0$call-invoke$branch$if$fun-disconnect$class-CarControlClient", offset = 8332)
    /* JADX INFO: renamed from: String$2$str$arg-0$call-invoke$branch$if$fun-disconnect$class-CarControlClient, reason: not valid java name */
    public final String m6071String$2$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f257String$2$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f202State$String$2$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$arg-0$call-invoke$branch$if$fun-disconnect$class-CarControlClient", f257String$2$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient);
            f202State$String$2$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$arg-0$call-invoke$branch$if-1$fun-send$class-CarControlClient", offset = 7249)
    /* JADX INFO: renamed from: String$2$str$arg-0$call-invoke$branch$if-1$fun-send$class-CarControlClient, reason: not valid java name */
    public final String m6072String$2$str$arg0$callinvoke$branch$if1$funsend$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f258String$2$str$arg0$callinvoke$branch$if1$funsend$classCarControlClient;
        }
        State<String> stateLiveLiteral = f203State$String$2$str$arg0$callinvoke$branch$if1$funsend$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$arg-0$call-invoke$branch$if-1$fun-send$class-CarControlClient", f258String$2$str$arg0$callinvoke$branch$if1$funsend$classCarControlClient);
            f203State$String$2$str$arg0$callinvoke$branch$if1$funsend$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$arg-0$call-invoke$branch$if-2$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 4185)
    /* JADX INFO: renamed from: String$2$str$arg-0$call-invoke$branch$if-2$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6073String$2$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f259String$2$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f204State$String$2$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$arg-0$call-invoke$branch$if-2$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", f259String$2$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient);
            f204State$String$2$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$arg-0$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-onFailure$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 5991)
    /* JADX INFO: renamed from: String$2$str$arg-0$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-onFailure$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6074String$2$str$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f260String$2$str$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f205State$String$2$str$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$arg-0$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-onFailure$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", f260String$2$str$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient);
            f205State$String$2$str$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$arg-0$call-url$$this$call-build$arg-0$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 2767)
    /* JADX INFO: renamed from: String$2$str$arg-0$call-url$$this$call-build$arg-0$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6075String$2$str$arg0$callurl$$this$callbuild$arg0$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f261String$2$str$arg0$callurl$$this$callbuild$arg0$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f206State$String$2$str$arg0$callurl$$this$callbuild$arg0$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$arg-0$call-url$$this$call-build$arg-0$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", f261String$2$str$arg0$callurl$$this$callbuild$arg0$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient);
            f206State$String$2$str$arg0$callurl$$this$callbuild$arg0$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$3$str$fun-toString$class-CarConnectionState", offset = -2)
    /* JADX INFO: renamed from: String$3$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    public final String m6076String$3$str$funtoString$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f262String$3$str$funtoString$classCarConnectionState;
        }
        State<String> stateLiveLiteral = f207State$String$3$str$funtoString$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$3$str$fun-toString$class-CarConnectionState", f262String$3$str$funtoString$classCarConnectionState);
            f207State$String$3$str$funtoString$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$4$str$arg-0$call-invoke$branch$if$fun-$anonymous$$arg-0$call-let$else$when$branch$if-1$fun-tick$class-CarControlClient", offset = 7657)
    /* JADX INFO: renamed from: String$4$str$arg-0$call-invoke$branch$if$fun-$anonymous$$arg-0$call-let$else$when$branch$if-1$fun-tick$class-CarControlClient, reason: not valid java name */
    public final String m6077String$4$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f263String$4$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient;
        }
        State<String> stateLiveLiteral = f208State$String$4$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$4$str$arg-0$call-invoke$branch$if$fun-$anonymous$$arg-0$call-let$else$when$branch$if-1$fun-tick$class-CarControlClient", f263String$4$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient);
            f208State$String$4$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$4$str$arg-0$call-invoke$branch$if$fun-disconnect$class-CarControlClient", offset = 8349)
    /* JADX INFO: renamed from: String$4$str$arg-0$call-invoke$branch$if$fun-disconnect$class-CarControlClient, reason: not valid java name */
    public final String m6078String$4$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f264String$4$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f209State$String$4$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$4$str$arg-0$call-invoke$branch$if$fun-disconnect$class-CarControlClient", f264String$4$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient);
            f209State$String$4$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$4$str$arg-0$call-invoke$branch$if-2$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 4201)
    /* JADX INFO: renamed from: String$4$str$arg-0$call-invoke$branch$if-2$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6079String$4$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f265String$4$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f210State$String$4$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$4$str$arg-0$call-invoke$branch$if-2$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", f265String$4$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient);
            f210State$String$4$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$4$str$fun-toString$class-CarConnectionState", offset = -2)
    /* JADX INFO: renamed from: String$4$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    public final String m6080String$4$str$funtoString$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f266String$4$str$funtoString$classCarConnectionState;
        }
        State<String> stateLiveLiteral = f211State$String$4$str$funtoString$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$4$str$fun-toString$class-CarConnectionState", f266String$4$str$funtoString$classCarConnectionState);
            f211State$String$4$str$funtoString$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$6$str$arg-0$call-invoke$branch$if$fun-disconnect$class-CarControlClient", offset = 8390)
    /* JADX INFO: renamed from: String$6$str$arg-0$call-invoke$branch$if$fun-disconnect$class-CarControlClient, reason: not valid java name */
    public final String m6081String$6$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f267String$6$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f212State$String$6$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$6$str$arg-0$call-invoke$branch$if$fun-disconnect$class-CarControlClient", f267String$6$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient);
            f212State$String$6$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$6$str$arg-0$call-invoke$branch$if-2$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 4225)
    /* JADX INFO: renamed from: String$6$str$arg-0$call-invoke$branch$if-2$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6082String$6$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f268String$6$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f213State$String$6$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$6$str$arg-0$call-invoke$branch$if-2$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", f268String$6$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient);
            f213State$String$6$str$arg0$callinvoke$branch$if2$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$6$str$fun-toString$class-CarConnectionState", offset = -2)
    /* JADX INFO: renamed from: String$6$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    public final String m6083String$6$str$funtoString$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f269String$6$str$funtoString$classCarConnectionState;
        }
        State<String> stateLiveLiteral = f214State$String$6$str$funtoString$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$6$str$fun-toString$class-CarConnectionState", f269String$6$str$funtoString$classCarConnectionState);
            f214State$String$6$str$funtoString$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$7$str$fun-toString$class-CarConnectionState", offset = -2)
    /* JADX INFO: renamed from: String$7$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    public final String m6084String$7$str$funtoString$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f270String$7$str$funtoString$classCarConnectionState;
        }
        State<String> stateLiveLiteral = f215State$String$7$str$funtoString$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$7$str$fun-toString$class-CarConnectionState", f270String$7$str$funtoString$classCarConnectionState);
            f215State$String$7$str$funtoString$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$9$str$fun-toString$class-CarConnectionState", offset = -2)
    /* JADX INFO: renamed from: String$9$str$fun-toString$class-CarConnectionState, reason: not valid java name */
    public final String m6085String$9$str$funtoString$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f271String$9$str$funtoString$classCarConnectionState;
        }
        State<String> stateLiveLiteral = f216State$String$9$str$funtoString$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$9$str$fun-toString$class-CarConnectionState", f271String$9$str$funtoString$classCarConnectionState);
            f216State$String$9$str$funtoString$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$arg-0$call-$set-value$$branch$if$fun-connect$class-CarControlClient", offset = 2085)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-0$call-$set-value$$branch$if$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6086String$arg0$call$init$$arg0$call$setvalue$$branch$if$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f272String$arg0$call$init$$arg0$call$setvalue$$branch$if$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f217State$String$arg0$call$init$$arg0$call$setvalue$$branch$if$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$arg-0$call-$set-value$$branch$if$fun-connect$class-CarControlClient", f272String$arg0$call$init$$arg0$call$setvalue$$branch$if$funconnect$classCarControlClient);
            f217State$String$arg0$call$init$$arg0$call$setvalue$$branch$if$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$arg-0$call-$set-value$$branch$if-1$fun-connect$class-CarControlClient", offset = 2264)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-0$call-$set-value$$branch$if-1$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6087String$arg0$call$init$$arg0$call$setvalue$$branch$if1$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f273String$arg0$call$init$$arg0$call$setvalue$$branch$if1$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f218State$String$arg0$call$init$$arg0$call$setvalue$$branch$if1$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$arg-0$call-$set-value$$branch$if-1$fun-connect$class-CarControlClient", f273String$arg0$call$init$$arg0$call$setvalue$$branch$if1$funconnect$classCarControlClient);
            f218State$String$arg0$call$init$$arg0$call$setvalue$$branch$if1$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$arg-0$call-$set-value$$branch-1$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 5409)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-0$call-$set-value$$branch-1$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6088String$arg0$call$init$$arg0$call$setvalue$$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f274String$arg0$call$init$$arg0$call$setvalue$$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f219State$String$arg0$call$init$$arg0$call$setvalue$$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$arg-0$call-$set-value$$branch-1$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", f274String$arg0$call$init$$arg0$call$setvalue$$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient);
            f219State$String$arg0$call$init$$arg0$call$setvalue$$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$arg-0$call-$set-value$$fun-connect$class-CarControlClient", offset = 2457)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-0$call-$set-value$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6089String$arg0$call$init$$arg0$call$setvalue$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f275String$arg0$call$init$$arg0$call$setvalue$$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f220State$String$arg0$call$init$$arg0$call$setvalue$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$arg-0$call-$set-value$$fun-connect$class-CarControlClient", f275String$arg0$call$init$$arg0$call$setvalue$$funconnect$classCarControlClient);
            f220State$String$arg0$call$init$$arg0$call$setvalue$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-disconnect$branch$if$branch$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 4703)
    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if$branch$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6090String$arg0$calldisconnect$branch$if$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f276String$arg0$calldisconnect$branch$if$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f221State$String$arg0$calldisconnect$branch$if$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-disconnect$branch$if$branch$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", f276String$arg0$calldisconnect$branch$if$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient);
            f221State$String$arg0$calldisconnect$branch$if$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-disconnect$branch$if$branch-1$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 5257)
    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if$branch-1$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6091String$arg0$calldisconnect$branch$if$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f277String$arg0$calldisconnect$branch$if$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f222State$String$arg0$calldisconnect$branch$if$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-disconnect$branch$if$branch-1$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", f277String$arg0$calldisconnect$branch$if$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient);
            f222State$String$arg0$calldisconnect$branch$if$branch1$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-disconnect$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-onClosed$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 6611)
    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-onClosed$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6092String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonClosed$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f278String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonClosed$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f223State$String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonClosed$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-disconnect$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-onClosed$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", f278String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonClosed$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient);
            f223State$String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonClosed$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-disconnect$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-onFailure$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 6063)
    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-onFailure$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6093String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f279String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f224State$String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-disconnect$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-onFailure$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", f279String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient);
            f224State$String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonFailure$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-disconnect$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage-1$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 5744)
    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage-1$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6094String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonMessage1$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f280String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonMessage1$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f225State$String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonMessage1$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-disconnect$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage-1$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", f280String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonMessage1$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient);
            f225State$String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$funonMessage1$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-disconnect$branch$if$fun-setInput$class-CarControlClient", offset = 6821)
    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if$fun-setInput$class-CarControlClient, reason: not valid java name */
    public final String m6095String$arg0$calldisconnect$branch$if$funsetInput$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f281String$arg0$calldisconnect$branch$if$funsetInput$classCarControlClient;
        }
        State<String> stateLiveLiteral = f226State$String$arg0$calldisconnect$branch$if$funsetInput$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-disconnect$branch$if$fun-setInput$class-CarControlClient", f281String$arg0$calldisconnect$branch$if$funsetInput$classCarControlClient);
            f226State$String$arg0$calldisconnect$branch$if$funsetInput$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-disconnect$branch$if-1$branch$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 4875)
    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if-1$branch$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6096String$arg0$calldisconnect$branch$if1$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f282String$arg0$calldisconnect$branch$if1$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f227State$String$arg0$calldisconnect$branch$if1$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-disconnect$branch$if-1$branch$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", f282String$arg0$calldisconnect$branch$if1$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient);
            f227State$String$arg0$calldisconnect$branch$if1$branch$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-disconnect$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onClosing$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 6384)
    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onClosing$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6097String$arg0$calldisconnect$branch$if1$fun$anonymous$$arg1$callsynchronized$funonClosing$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f283String$arg0$calldisconnect$branch$if1$fun$anonymous$$arg1$callsynchronized$funonClosing$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f228State$String$arg0$calldisconnect$branch$if1$fun$anonymous$$arg1$callsynchronized$funonClosing$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-disconnect$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onClosing$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", f283String$arg0$calldisconnect$branch$if1$fun$anonymous$$arg1$callsynchronized$funonClosing$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient);
            f228State$String$arg0$calldisconnect$branch$if1$fun$anonymous$$arg1$callsynchronized$funonClosing$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-disconnect$branch$if-2$fun-send$class-CarControlClient", offset = 7398)
    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if-2$fun-send$class-CarControlClient, reason: not valid java name */
    public final String m6098String$arg0$calldisconnect$branch$if2$funsend$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f284String$arg0$calldisconnect$branch$if2$funsend$classCarControlClient;
        }
        State<String> stateLiveLiteral = f229State$String$arg0$calldisconnect$branch$if2$funsend$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-disconnect$branch$if-2$fun-send$class-CarControlClient", f284String$arg0$calldisconnect$branch$if2$funsend$classCarControlClient);
            f229State$String$arg0$calldisconnect$branch$if2$funsend$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-disconnect$branch$if-2$fun-tick$class-CarControlClient", offset = 7875)
    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if-2$fun-tick$class-CarControlClient, reason: not valid java name */
    public final String m6099String$arg0$calldisconnect$branch$if2$funtick$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f285String$arg0$calldisconnect$branch$if2$funtick$classCarControlClient;
        }
        State<String> stateLiveLiteral = f230State$String$arg0$calldisconnect$branch$if2$funtick$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-disconnect$branch$if-2$fun-tick$class-CarControlClient", f285String$arg0$calldisconnect$branch$if2$funtick$classCarControlClient);
            f230State$String$arg0$calldisconnect$branch$if2$funtick$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-disconnect$branch$if-3$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 4301)
    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if-3$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6100String$arg0$calldisconnect$branch$if3$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f286String$arg0$calldisconnect$branch$if3$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f231State$String$arg0$calldisconnect$branch$if3$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-disconnect$branch$if-3$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", f286String$arg0$calldisconnect$branch$if3$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient);
            f231State$String$arg0$calldisconnect$branch$if3$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-disconnect$branch$when$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 3574)
    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$when$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6101String$arg0$calldisconnect$branch$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f287String$arg0$calldisconnect$branch$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f232State$String$arg0$calldisconnect$branch$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-disconnect$branch$when$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", f287String$arg0$calldisconnect$branch$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient);
            f232State$String$arg0$calldisconnect$branch$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-disconnect$branch-1$when$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 3665)
    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch-1$when$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6102String$arg0$calldisconnect$branch1$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f288String$arg0$calldisconnect$branch1$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f233State$String$arg0$calldisconnect$branch1$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-disconnect$branch-1$when$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", f288String$arg0$calldisconnect$branch1$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient);
            f233State$String$arg0$calldisconnect$branch1$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-disconnect$branch-2$when$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 3771)
    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch-2$when$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6103String$arg0$calldisconnect$branch2$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f289String$arg0$calldisconnect$branch2$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f234State$String$arg0$calldisconnect$branch2$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-disconnect$branch-2$when$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", f289String$arg0$calldisconnect$branch2$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient);
            f234State$String$arg0$calldisconnect$branch2$when$branch$if1$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-disconnect$else$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 5532)
    /* JADX INFO: renamed from: String$arg-0$call-disconnect$else$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6104String$arg0$calldisconnect$else$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f290String$arg0$calldisconnect$else$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f235State$String$arg0$calldisconnect$else$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-disconnect$else$if-4$fun-$anonymous$$arg-1$call-synchronized$fun-onMessage$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", f290String$arg0$calldisconnect$else$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient);
            f235State$String$arg0$calldisconnect$else$if4$fun$anonymous$$arg1$callsynchronized$funonMessage$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-invoke$branch$if$fun-send$class-CarControlClient", offset = 7145)
    /* JADX INFO: renamed from: String$arg-0$call-invoke$branch$if$fun-send$class-CarControlClient, reason: not valid java name */
    public final String m6105String$arg0$callinvoke$branch$if$funsend$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f291String$arg0$callinvoke$branch$if$funsend$classCarControlClient;
        }
        State<String> stateLiveLiteral = f236State$String$arg0$callinvoke$branch$if$funsend$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-invoke$branch$if$fun-send$class-CarControlClient", f291String$arg0$callinvoke$branch$if$funsend$classCarControlClient);
            f236State$String$arg0$callinvoke$branch$if$funsend$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-onOpen$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", offset = 2964)
    /* JADX INFO: renamed from: String$arg-0$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-onOpen$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6106String$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonOpen$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f292String$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonOpen$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f237State$String$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonOpen$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-onOpen$class-$no-name-provided$$arg-1$call-newWebSocket$arg-0$call-$set-socket$$fun-connect$class-CarControlClient", f292String$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonOpen$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient);
            f237State$String$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funonOpen$class$nonameprovided$$arg1$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$branch$if$val-path$fun-connect$class-CarControlClient", offset = 2659)
    /* JADX INFO: renamed from: String$branch$if$val-path$fun-connect$class-CarControlClient, reason: not valid java name */
    public final String m6107String$branch$if$valpath$funconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f293String$branch$if$valpath$funconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f238State$String$branch$if$valpath$funconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$branch$if$val-path$fun-connect$class-CarControlClient", f293String$branch$if$valpath$funconnect$classCarControlClient);
            f238State$String$branch$if$valpath$funconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$param-message$class-CarConnectionState", offset = 413)
    /* JADX INFO: renamed from: String$param-message$class-CarConnectionState, reason: not valid java name */
    public final String m6108String$parammessage$classCarConnectionState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f294String$parammessage$classCarConnectionState;
        }
        State<String> stateLiveLiteral = f239State$String$parammessage$classCarConnectionState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$param-message$class-CarConnectionState", f294String$parammessage$classCarConnectionState);
            f239State$String$parammessage$classCarConnectionState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$param-message$fun-disconnect$class-CarControlClient", offset = 8218)
    /* JADX INFO: renamed from: String$param-message$fun-disconnect$class-CarControlClient, reason: not valid java name */
    public final String m6109String$parammessage$fundisconnect$classCarControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f295String$parammessage$fundisconnect$classCarControlClient;
        }
        State<String> stateLiveLiteral = f240State$String$parammessage$fundisconnect$classCarControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$param-message$fun-disconnect$class-CarControlClient", f295String$parammessage$fundisconnect$classCarControlClient);
            f240State$String$parammessage$fundisconnect$classCarControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
