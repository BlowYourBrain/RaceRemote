package vea.raceremote.control;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: CarControlConnection.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/control/CarControlConnection.kt")
public final class LiveLiterals$CarControlConnectionKt {

    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-ControlEndpoint, reason: not valid java name */
    private static boolean f302Boolean$branch$when1$funequals$classControlEndpoint;

    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-ControlEndpoint, reason: not valid java name */
    private static boolean f303Boolean$branch$when2$funequals$classControlEndpoint;

    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-ControlEndpoint, reason: not valid java name */
    private static boolean f304Boolean$branch$when3$funequals$classControlEndpoint;

    /* JADX INFO: renamed from: Boolean$branch$when-4$fun-equals$class-ControlEndpoint, reason: not valid java name */
    private static boolean f305Boolean$branch$when4$funequals$classControlEndpoint;

    /* JADX INFO: renamed from: Int$class-ControlEndpoint, reason: not valid java name */
    private static int f322Int$classControlEndpoint;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-$set-closed$$fun-close$class-CarControlConnection, reason: not valid java name */
    private static State<Boolean> f326State$Boolean$arg0$call$setclosed$$funclose$classCarControlConnection;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-$init$$branch-1$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<Boolean> f327State$Boolean$arg1$call$init$$branch1$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$Boolean$arg-2$call-$init$$arg-0$call-$set-value$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<Boolean> f328State$Boolean$arg2$call$init$$arg0$call$setvalue$$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$Boolean$arg-2$call-$init$$branch$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<Boolean> f329State$Boolean$arg2$call$init$$branch$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$Boolean$branch$when$cond$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<Boolean> f330State$Boolean$branch$when$cond$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$Boolean$branch$when$fun-equals$class-ControlEndpoint, reason: not valid java name */
    private static State<Boolean> f331State$Boolean$branch$when$funequals$classControlEndpoint;

    /* JADX INFO: renamed from: State$Boolean$branch$when-1$fun-equals$class-ControlEndpoint, reason: not valid java name */
    private static State<Boolean> f332State$Boolean$branch$when1$funequals$classControlEndpoint;

    /* JADX INFO: renamed from: State$Boolean$branch$when-2$fun-equals$class-ControlEndpoint, reason: not valid java name */
    private static State<Boolean> f333State$Boolean$branch$when2$funequals$classControlEndpoint;

    /* JADX INFO: renamed from: State$Boolean$branch$when-3$fun-equals$class-ControlEndpoint, reason: not valid java name */
    private static State<Boolean> f334State$Boolean$branch$when3$funequals$classControlEndpoint;

    /* JADX INFO: renamed from: State$Boolean$branch$when-4$fun-equals$class-ControlEndpoint, reason: not valid java name */
    private static State<Boolean> f335State$Boolean$branch$when4$funequals$classControlEndpoint;

    /* JADX INFO: renamed from: State$Boolean$fun-equals$class-ControlEndpoint, reason: not valid java name */
    private static State<Boolean> f336State$Boolean$funequals$classControlEndpoint;

    /* JADX INFO: renamed from: State$Char$0$vararg$arg-0$call-split$$$this$call-map$val-octets$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<Character> f337State$Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$Float$arg-0$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-input$else$when$fun-setInput$class-CarControlConnection, reason: not valid java name */
    private static State<Float> f338State$Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$callinput$else$when$funsetInput$classCarControlConnection;

    /* JADX INFO: renamed from: State$Float$arg-0$call-coerceIn$$this$call-times$$this$call-toInt$arg-1$call-input$else$when$fun-setInput$class-CarControlConnection, reason: not valid java name */
    private static State<Float> f339State$Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg1$callinput$else$when$funsetInput$classCarControlConnection;

    /* JADX INFO: renamed from: State$Float$arg-1$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-input$else$when$fun-setInput$class-CarControlConnection, reason: not valid java name */
    private static State<Float> f340State$Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$callinput$else$when$funsetInput$classCarControlConnection;

    /* JADX INFO: renamed from: State$Float$arg-1$call-coerceIn$$this$call-times$$this$call-toInt$arg-1$call-input$else$when$fun-setInput$class-CarControlConnection, reason: not valid java name */
    private static State<Float> f341State$Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg1$callinput$else$when$funsetInput$classCarControlConnection;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if-1$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<Integer> f342State$Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if1$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$arg-0$call-require$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<Integer> f343State$Int$$this$callrangeTo$$this$callcontains$arg0$callrequire$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$arg-0$call-require-1$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<Integer> f344State$Int$$this$callrangeTo$$this$callcontains$arg0$callrequire1$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if-1$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<Integer> f345State$Int$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if1$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rangeTo$$this$call-contains$arg-0$call-require-1$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<Integer> f346State$Int$arg0$callrangeTo$$this$callcontains$arg0$callrequire1$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-ControlEndpoint, reason: not valid java name */
    private static State<Integer> f347State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classControlEndpoint;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-ControlEndpoint, reason: not valid java name */
    private static State<Integer> f348State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classControlEndpoint;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-toInt$arg-0$call-input$else$when$fun-setInput$class-CarControlConnection, reason: not valid java name */
    private static State<Integer> f349State$Int$arg0$calltimes$$this$calltoInt$arg0$callinput$else$when$funsetInput$classCarControlConnection;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-toInt$arg-1$call-input$else$when$fun-setInput$class-CarControlConnection, reason: not valid java name */
    private static State<Integer> f350State$Int$arg0$calltimes$$this$calltoInt$arg1$callinput$else$when$funsetInput$classCarControlConnection;

    /* JADX INFO: renamed from: State$Int$class-CarControlConnection, reason: not valid java name */
    private static State<Integer> f351State$Int$classCarControlConnection;

    /* JADX INFO: renamed from: State$Int$class-ControlEndpoint, reason: not valid java name */
    private static State<Integer> f352State$Int$classControlEndpoint;

    /* JADX INFO: renamed from: State$Int$param-statusPort$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<Integer> f353State$Int$paramstatusPort$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$Long$arg-0$call-delay$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<Long> f354State$Long$arg0$calldelay$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$Long$arg-0$call-rangeTo$$this$call-contains$arg-0$call-require$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<Long> f355State$Long$arg0$callrangeTo$$this$callcontains$arg0$callrequire$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-invoke$branch$if$fun-$anonymous$$arg-1$call-synchronized$catch-1$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<String> f356State$String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg1$callsynchronized$catch1$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$String$0$str$fun-toString$class-ControlEndpoint, reason: not valid java name */
    private static State<String> f357State$String$0$str$funtoString$classControlEndpoint;

    /* JADX INFO: renamed from: State$String$1$str$fun-toString$class-ControlEndpoint, reason: not valid java name */
    private static State<String> f358State$String$1$str$funtoString$classControlEndpoint;

    /* JADX INFO: renamed from: State$String$3$str$fun-toString$class-ControlEndpoint, reason: not valid java name */
    private static State<String> f359State$String$3$str$funtoString$classControlEndpoint;

    /* JADX INFO: renamed from: State$String$4$str$fun-toString$class-ControlEndpoint, reason: not valid java name */
    private static State<String> f360State$String$4$str$funtoString$classControlEndpoint;

    /* JADX INFO: renamed from: State$String$6$str$fun-toString$class-ControlEndpoint, reason: not valid java name */
    private static State<String> f361State$String$6$str$funtoString$classControlEndpoint;

    /* JADX INFO: renamed from: State$String$7$str$fun-toString$class-ControlEndpoint, reason: not valid java name */
    private static State<String> f362State$String$7$str$funtoString$classControlEndpoint;

    /* JADX INFO: renamed from: State$String$9$str$fun-toString$class-ControlEndpoint, reason: not valid java name */
    private static State<String> f363State$String$9$str$funtoString$classControlEndpoint;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$arg-0$call-$set-value$$branch$if-1$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<String> f364State$String$arg0$call$init$$arg0$call$setvalue$$branch$if1$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$arg-0$call-$set-value$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<String> f365State$String$arg0$call$init$$arg0$call$setvalue$$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$branch$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<String> f366State$String$arg0$call$init$$branch$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$branch-1$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<String> f367State$String$arg0$call$init$$branch1$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$branch-2$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<String> f368State$String$arg0$call$init$$branch2$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$String$arg-0$call-disconnect$branch$if$fun-$anonymous$$arg-1$call-synchronized$catch-1$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<String> f369State$String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$catch1$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$String$arg-0$call-disconnect$branch$if$fun-setInput$class-CarControlConnection, reason: not valid java name */
    private static State<String> f370State$String$arg0$calldisconnect$branch$if$funsetInput$classCarControlConnection;

    /* JADX INFO: renamed from: State$String$arg-0$call-disconnect$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<String> f371State$String$arg0$calldisconnect$branch$if1$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$String$arg-0$call-disconnect$branch$if-2$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<String> f372State$String$arg0$calldisconnect$branch$if2$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$String$arg-0$call-disconnect$branch$if-3$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<String> f373State$String$arg0$calldisconnect$branch$if3$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$String$arg-0$call-disconnect$else$when$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<String> f374State$String$arg0$calldisconnect$else$when$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$String$arg-1$call-EQEQ$cond$when$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<String> f375State$String$arg1$callEQEQ$cond$when$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$String$arg-1$call-EQEQ$cond-1$when$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static State<String> f376State$String$arg1$callEQEQ$cond1$when$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;

    /* JADX INFO: renamed from: State$String$param-message$fun-disconnect$class-CarControlConnection, reason: not valid java name */
    private static State<String> f377State$String$parammessage$fundisconnect$classCarControlConnection;
    public static final LiveLiterals$CarControlConnectionKt INSTANCE = new LiveLiterals$CarControlConnectionKt();

    /* JADX INFO: renamed from: String$0$str$fun-toString$class-ControlEndpoint, reason: not valid java name */
    private static String f379String$0$str$funtoString$classControlEndpoint = "ControlEndpoint(";

    /* JADX INFO: renamed from: String$1$str$fun-toString$class-ControlEndpoint, reason: not valid java name */
    private static String f380String$1$str$funtoString$classControlEndpoint = "transport=";

    /* JADX INFO: renamed from: String$3$str$fun-toString$class-ControlEndpoint, reason: not valid java name */
    private static String f381String$3$str$funtoString$classControlEndpoint = ", ";

    /* JADX INFO: renamed from: String$4$str$fun-toString$class-ControlEndpoint, reason: not valid java name */
    private static String f382String$4$str$funtoString$classControlEndpoint = "port=";

    /* JADX INFO: renamed from: String$6$str$fun-toString$class-ControlEndpoint, reason: not valid java name */
    private static String f383String$6$str$funtoString$classControlEndpoint = ", ";

    /* JADX INFO: renamed from: String$7$str$fun-toString$class-ControlEndpoint, reason: not valid java name */
    private static String f384String$7$str$funtoString$classControlEndpoint = "chipId=";

    /* JADX INFO: renamed from: String$9$str$fun-toString$class-ControlEndpoint, reason: not valid java name */
    private static String f385String$9$str$funtoString$classControlEndpoint = ")";

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-ControlEndpoint, reason: not valid java name */
    private static int f317Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classControlEndpoint = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-ControlEndpoint, reason: not valid java name */
    private static int f318Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classControlEndpoint = 31;

    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-ControlEndpoint, reason: not valid java name */
    private static boolean f301Boolean$branch$when$funequals$classControlEndpoint = true;

    /* JADX INFO: renamed from: Boolean$fun-equals$class-ControlEndpoint, reason: not valid java name */
    private static boolean f306Boolean$funequals$classControlEndpoint = true;

    /* JADX INFO: renamed from: Int$param-statusPort$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static int f323Int$paramstatusPort$funconnect$classCarControlConnection = 80;

    /* JADX INFO: renamed from: Char$0$vararg$arg-0$call-split$$$this$call-map$val-octets$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static char f307Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$funconnect$classCarControlConnection = '.';

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if-1$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static int f312Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if1$funconnect$classCarControlConnection = 1;

    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if-1$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static int f315Int$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if1$funconnect$classCarControlConnection = 65535;

    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-0$call-$set-value$$branch$if-1$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static String f386String$arg0$call$init$$arg0$call$setvalue$$branch$if1$funconnect$classCarControlConnection = "Укажи локальный IPv4-адрес машинки";

    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-0$call-$set-value$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static String f387String$arg0$call$init$$arg0$call$setvalue$$funconnect$classCarControlConnection = "Проверка машинки…";

    /* JADX INFO: renamed from: Boolean$arg-2$call-$init$$arg-0$call-$set-value$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static boolean f298Boolean$arg2$call$init$$arg0$call$setvalue$$funconnect$classCarControlConnection = true;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$arg-0$call-require$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static int f313Int$$this$callrangeTo$$this$callcontains$arg0$callrequire$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = 1;

    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$arg-0$call-require$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static long f325Long$arg0$callrangeTo$$this$callcontains$arg0$callrequire$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = 281474976710655L;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$arg-0$call-require-1$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static int f314Int$$this$callrangeTo$$this$callcontains$arg0$callrequire1$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = 1;

    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$arg-0$call-require-1$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static int f316Int$arg0$callrangeTo$$this$callcontains$arg0$callrequire1$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = 65535;

    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static String f393String$arg0$calldisconnect$branch$if1$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = "По этому адресу другая машинка";

    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if-2$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static String f394String$arg0$calldisconnect$branch$if2$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = "Настройки машинки изменились — выбери её заново";

    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if-3$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static String f395String$arg0$calldisconnect$branch$if3$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = "Способ управления изменился — выбери машинку заново";

    /* JADX INFO: renamed from: String$arg-1$call-EQEQ$cond$when$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static String f397String$arg1$callEQEQ$cond$when$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = "udp-v1";

    /* JADX INFO: renamed from: String$arg-1$call-EQEQ$cond-1$when$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static String f398String$arg1$callEQEQ$cond1$when$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = "websocket-v1";

    /* JADX INFO: renamed from: String$arg-0$call-disconnect$else$when$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static String f396String$arg0$calldisconnect$else$when$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = "Версия управления не поддерживается";

    /* JADX INFO: renamed from: Boolean$branch$when$cond$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static boolean f300Boolean$branch$when$cond$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = true;

    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static String f388String$arg0$call$init$$branch$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = "Подключение…";

    /* JADX INFO: renamed from: Boolean$arg-2$call-$init$$branch$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static boolean f299Boolean$arg2$call$init$$branch$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = true;

    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch-1$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static String f389String$arg0$call$init$$branch1$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = "Управление подключено";

    /* JADX INFO: renamed from: Boolean$arg-1$call-$init$$branch-1$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static boolean f297Boolean$arg1$call$init$$branch1$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = true;

    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch-2$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static String f390String$arg0$call$init$$branch2$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = "Нет свежего ответа — остановлено";

    /* JADX INFO: renamed from: Long$arg-0$call-delay$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static long f324Long$arg0$calldelay$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = 20;

    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$branch$if$fun-$anonymous$$arg-1$call-synchronized$catch-1$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static String f378String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg1$callsynchronized$catch1$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = "Connection failed: ";

    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if$fun-$anonymous$$arg-1$call-synchronized$catch-1$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    private static String f391String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$catch1$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = "Не удалось проверить машинку — остановлено";

    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if$fun-setInput$class-CarControlConnection, reason: not valid java name */
    private static String f392String$arg0$calldisconnect$branch$if$funsetInput$classCarControlConnection = "Некорректное управление";

    /* JADX INFO: renamed from: Float$arg-0$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-input$else$when$fun-setInput$class-CarControlConnection, reason: not valid java name */
    private static float f308Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$callinput$else$when$funsetInput$classCarControlConnection = -1.0f;

    /* JADX INFO: renamed from: Float$arg-1$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-input$else$when$fun-setInput$class-CarControlConnection, reason: not valid java name */
    private static float f310Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$callinput$else$when$funsetInput$classCarControlConnection = 1.0f;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-toInt$arg-0$call-input$else$when$fun-setInput$class-CarControlConnection, reason: not valid java name */
    private static int f319Int$arg0$calltimes$$this$calltoInt$arg0$callinput$else$when$funsetInput$classCarControlConnection = 1000;

    /* JADX INFO: renamed from: Float$arg-0$call-coerceIn$$this$call-times$$this$call-toInt$arg-1$call-input$else$when$fun-setInput$class-CarControlConnection, reason: not valid java name */
    private static float f309Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg1$callinput$else$when$funsetInput$classCarControlConnection = -1.0f;

    /* JADX INFO: renamed from: Float$arg-1$call-coerceIn$$this$call-times$$this$call-toInt$arg-1$call-input$else$when$fun-setInput$class-CarControlConnection, reason: not valid java name */
    private static float f311Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg1$callinput$else$when$funsetInput$classCarControlConnection = 1.0f;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-toInt$arg-1$call-input$else$when$fun-setInput$class-CarControlConnection, reason: not valid java name */
    private static int f320Int$arg0$calltimes$$this$calltoInt$arg1$callinput$else$when$funsetInput$classCarControlConnection = 1000;

    /* JADX INFO: renamed from: String$param-message$fun-disconnect$class-CarControlConnection, reason: not valid java name */
    private static String f399String$parammessage$fundisconnect$classCarControlConnection = "Остановлено";

    /* JADX INFO: renamed from: Boolean$arg-0$call-$set-closed$$fun-close$class-CarControlConnection, reason: not valid java name */
    private static boolean f296Boolean$arg0$call$setclosed$$funclose$classCarControlConnection = true;

    /* JADX INFO: renamed from: Int$class-CarControlConnection, reason: not valid java name */
    private static int f321Int$classCarControlConnection = 8;

    @LiveLiteralInfo(key = "Boolean$arg-0$call-$set-closed$$fun-close$class-CarControlConnection", offset = 6054)
    /* JADX INFO: renamed from: Boolean$arg-0$call-$set-closed$$fun-close$class-CarControlConnection, reason: not valid java name */
    public final boolean m6110Boolean$arg0$call$setclosed$$funclose$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f296Boolean$arg0$call$setclosed$$funclose$classCarControlConnection;
        }
        State<Boolean> stateLiveLiteral = f326State$Boolean$arg0$call$setclosed$$funclose$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-$set-closed$$fun-close$class-CarControlConnection", Boolean.valueOf(f296Boolean$arg0$call$setclosed$$funclose$classCarControlConnection));
            f326State$Boolean$arg0$call$setclosed$$funclose$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-$init$$branch-1$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", offset = 4242)
    /* JADX INFO: renamed from: Boolean$arg-1$call-$init$$branch-1$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final boolean m6111Boolean$arg1$call$init$$branch1$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f297Boolean$arg1$call$init$$branch1$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        }
        State<Boolean> stateLiveLiteral = f327State$Boolean$arg1$call$init$$branch1$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-$init$$branch-1$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", Boolean.valueOf(f297Boolean$arg1$call$init$$branch1$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection));
            f327State$Boolean$arg1$call$init$$branch1$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-2$call-$init$$arg-0$call-$set-value$$fun-connect$class-CarControlConnection", offset = 1802)
    /* JADX INFO: renamed from: Boolean$arg-2$call-$init$$arg-0$call-$set-value$$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final boolean m6112Boolean$arg2$call$init$$arg0$call$setvalue$$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f298Boolean$arg2$call$init$$arg0$call$setvalue$$funconnect$classCarControlConnection;
        }
        State<Boolean> stateLiveLiteral = f328State$Boolean$arg2$call$init$$arg0$call$setvalue$$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-2$call-$init$$arg-0$call-$set-value$$fun-connect$class-CarControlConnection", Boolean.valueOf(f298Boolean$arg2$call$init$$arg0$call$setvalue$$funconnect$classCarControlConnection));
            f328State$Boolean$arg2$call$init$$arg0$call$setvalue$$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-2$call-$init$$branch$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", offset = 4078)
    /* JADX INFO: renamed from: Boolean$arg-2$call-$init$$branch$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final boolean m6113Boolean$arg2$call$init$$branch$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f299Boolean$arg2$call$init$$branch$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        }
        State<Boolean> stateLiveLiteral = f329State$Boolean$arg2$call$init$$branch$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-2$call-$init$$branch$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", Boolean.valueOf(f299Boolean$arg2$call$init$$branch$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection));
            f329State$Boolean$arg2$call$init$$branch$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when$cond$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", offset = 3927)
    /* JADX INFO: renamed from: Boolean$branch$when$cond$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final boolean m6114Boolean$branch$when$cond$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f300Boolean$branch$when$cond$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        }
        State<Boolean> stateLiveLiteral = f330State$Boolean$branch$when$cond$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when$cond$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", Boolean.valueOf(f300Boolean$branch$when$cond$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection));
            f330State$Boolean$branch$when$cond$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when$fun-equals$class-ControlEndpoint", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-ControlEndpoint, reason: not valid java name */
    public final boolean m6115Boolean$branch$when$funequals$classControlEndpoint() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f301Boolean$branch$when$funequals$classControlEndpoint;
        }
        State<Boolean> stateLiveLiteral = f331State$Boolean$branch$when$funequals$classControlEndpoint;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when$fun-equals$class-ControlEndpoint", Boolean.valueOf(f301Boolean$branch$when$funequals$classControlEndpoint));
            f331State$Boolean$branch$when$funequals$classControlEndpoint = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-1$fun-equals$class-ControlEndpoint", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-ControlEndpoint, reason: not valid java name */
    public final boolean m6116Boolean$branch$when1$funequals$classControlEndpoint() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f302Boolean$branch$when1$funequals$classControlEndpoint;
        }
        State<Boolean> stateLiveLiteral = f332State$Boolean$branch$when1$funequals$classControlEndpoint;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-1$fun-equals$class-ControlEndpoint", Boolean.valueOf(f302Boolean$branch$when1$funequals$classControlEndpoint));
            f332State$Boolean$branch$when1$funequals$classControlEndpoint = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-2$fun-equals$class-ControlEndpoint", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-ControlEndpoint, reason: not valid java name */
    public final boolean m6117Boolean$branch$when2$funequals$classControlEndpoint() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f303Boolean$branch$when2$funequals$classControlEndpoint;
        }
        State<Boolean> stateLiveLiteral = f333State$Boolean$branch$when2$funequals$classControlEndpoint;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-2$fun-equals$class-ControlEndpoint", Boolean.valueOf(f303Boolean$branch$when2$funequals$classControlEndpoint));
            f333State$Boolean$branch$when2$funequals$classControlEndpoint = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-3$fun-equals$class-ControlEndpoint", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-ControlEndpoint, reason: not valid java name */
    public final boolean m6118Boolean$branch$when3$funequals$classControlEndpoint() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f304Boolean$branch$when3$funequals$classControlEndpoint;
        }
        State<Boolean> stateLiveLiteral = f334State$Boolean$branch$when3$funequals$classControlEndpoint;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-3$fun-equals$class-ControlEndpoint", Boolean.valueOf(f304Boolean$branch$when3$funequals$classControlEndpoint));
            f334State$Boolean$branch$when3$funequals$classControlEndpoint = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-4$fun-equals$class-ControlEndpoint", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-4$fun-equals$class-ControlEndpoint, reason: not valid java name */
    public final boolean m6119Boolean$branch$when4$funequals$classControlEndpoint() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f305Boolean$branch$when4$funequals$classControlEndpoint;
        }
        State<Boolean> stateLiveLiteral = f335State$Boolean$branch$when4$funequals$classControlEndpoint;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-4$fun-equals$class-ControlEndpoint", Boolean.valueOf(f305Boolean$branch$when4$funequals$classControlEndpoint));
            f335State$Boolean$branch$when4$funequals$classControlEndpoint = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$fun-equals$class-ControlEndpoint", offset = -2)
    /* JADX INFO: renamed from: Boolean$fun-equals$class-ControlEndpoint, reason: not valid java name */
    public final boolean m6120Boolean$funequals$classControlEndpoint() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f306Boolean$funequals$classControlEndpoint;
        }
        State<Boolean> stateLiveLiteral = f336State$Boolean$funequals$classControlEndpoint;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$fun-equals$class-ControlEndpoint", Boolean.valueOf(f306Boolean$funequals$classControlEndpoint));
            f336State$Boolean$funequals$classControlEndpoint = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Char$0$vararg$arg-0$call-split$$$this$call-map$val-octets$fun-connect$class-CarControlConnection", offset = 1274)
    /* JADX INFO: renamed from: Char$0$vararg$arg-0$call-split$$$this$call-map$val-octets$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final char m6121Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f307Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$funconnect$classCarControlConnection;
        }
        State<Character> stateLiveLiteral = f337State$Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Char$0$vararg$arg-0$call-split$$$this$call-map$val-octets$fun-connect$class-CarControlConnection", Character.valueOf(f307Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$funconnect$classCarControlConnection));
            f337State$Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().charValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-input$else$when$fun-setInput$class-CarControlConnection", offset = 5614)
    /* JADX INFO: renamed from: Float$arg-0$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-input$else$when$fun-setInput$class-CarControlConnection, reason: not valid java name */
    public final float m6122Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$callinput$else$when$funsetInput$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f308Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$callinput$else$when$funsetInput$classCarControlConnection;
        }
        State<Float> stateLiveLiteral = f338State$Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$callinput$else$when$funsetInput$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-input$else$when$fun-setInput$class-CarControlConnection", Float.valueOf(f308Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$callinput$else$when$funsetInput$classCarControlConnection));
            f338State$Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$callinput$else$when$funsetInput$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-coerceIn$$this$call-times$$this$call-toInt$arg-1$call-input$else$when$fun-setInput$class-CarControlConnection", offset = 5659)
    /* JADX INFO: renamed from: Float$arg-0$call-coerceIn$$this$call-times$$this$call-toInt$arg-1$call-input$else$when$fun-setInput$class-CarControlConnection, reason: not valid java name */
    public final float m6123Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg1$callinput$else$when$funsetInput$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f309Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg1$callinput$else$when$funsetInput$classCarControlConnection;
        }
        State<Float> stateLiveLiteral = f339State$Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg1$callinput$else$when$funsetInput$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-coerceIn$$this$call-times$$this$call-toInt$arg-1$call-input$else$when$fun-setInput$class-CarControlConnection", Float.valueOf(f309Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg1$callinput$else$when$funsetInput$classCarControlConnection));
            f339State$Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg1$callinput$else$when$funsetInput$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-1$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-input$else$when$fun-setInput$class-CarControlConnection", offset = 5619)
    /* JADX INFO: renamed from: Float$arg-1$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-input$else$when$fun-setInput$class-CarControlConnection, reason: not valid java name */
    public final float m6124Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$callinput$else$when$funsetInput$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f310Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$callinput$else$when$funsetInput$classCarControlConnection;
        }
        State<Float> stateLiveLiteral = f340State$Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$callinput$else$when$funsetInput$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-1$call-coerceIn$$this$call-times$$this$call-toInt$arg-0$call-input$else$when$fun-setInput$class-CarControlConnection", Float.valueOf(f310Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$callinput$else$when$funsetInput$classCarControlConnection));
            f340State$Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$callinput$else$when$funsetInput$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-1$call-coerceIn$$this$call-times$$this$call-toInt$arg-1$call-input$else$when$fun-setInput$class-CarControlConnection", offset = 5664)
    /* JADX INFO: renamed from: Float$arg-1$call-coerceIn$$this$call-times$$this$call-toInt$arg-1$call-input$else$when$fun-setInput$class-CarControlConnection, reason: not valid java name */
    public final float m6125Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg1$callinput$else$when$funsetInput$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f311Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg1$callinput$else$when$funsetInput$classCarControlConnection;
        }
        State<Float> stateLiveLiteral = f341State$Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg1$callinput$else$when$funsetInput$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-1$call-coerceIn$$this$call-times$$this$call-toInt$arg-1$call-input$else$when$fun-setInput$class-CarControlConnection", Float.valueOf(f311Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg1$callinput$else$when$funsetInput$classCarControlConnection));
            f341State$Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg1$callinput$else$when$funsetInput$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if-1$fun-connect$class-CarControlConnection", offset = 1556)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if-1$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final int m6126Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if1$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f312Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if1$funconnect$classCarControlConnection;
        }
        State<Integer> stateLiveLiteral = f342State$Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if1$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if-1$fun-connect$class-CarControlConnection", Integer.valueOf(f312Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if1$funconnect$classCarControlConnection));
            f342State$Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if1$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$arg-0$call-require$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", offset = 2189)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$arg-0$call-require$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final int m6127Int$$this$callrangeTo$$this$callcontains$arg0$callrequire$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f313Int$$this$callrangeTo$$this$callcontains$arg0$callrequire$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        }
        State<Integer> stateLiveLiteral = f343State$Int$$this$callrangeTo$$this$callcontains$arg0$callrequire$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$arg-0$call-require$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", Integer.valueOf(f313Int$$this$callrangeTo$$this$callcontains$arg0$callrequire$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection));
            f343State$Int$$this$callrangeTo$$this$callcontains$arg0$callrequire$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$arg-0$call-require-1$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", offset = 2254)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$arg-0$call-require-1$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final int m6128Int$$this$callrangeTo$$this$callcontains$arg0$callrequire1$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f314Int$$this$callrangeTo$$this$callcontains$arg0$callrequire1$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        }
        State<Integer> stateLiveLiteral = f344State$Int$$this$callrangeTo$$this$callcontains$arg0$callrequire1$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$arg-0$call-require-1$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", Integer.valueOf(f314Int$$this$callrangeTo$$this$callcontains$arg0$callrequire1$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection));
            f344State$Int$$this$callrangeTo$$this$callcontains$arg0$callrequire1$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if-1$fun-connect$class-CarControlConnection", offset = 1559)
    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if-1$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final int m6129Int$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if1$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f315Int$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if1$funconnect$classCarControlConnection;
        }
        State<Integer> stateLiveLiteral = f345State$Int$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if1$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if-1$fun-connect$class-CarControlConnection", Integer.valueOf(f315Int$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if1$funconnect$classCarControlConnection));
            f345State$Int$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if1$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rangeTo$$this$call-contains$arg-0$call-require-1$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", offset = 2257)
    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$arg-0$call-require-1$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final int m6130Int$arg0$callrangeTo$$this$callcontains$arg0$callrequire1$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f316Int$arg0$callrangeTo$$this$callcontains$arg0$callrequire1$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        }
        State<Integer> stateLiveLiteral = f346State$Int$arg0$callrangeTo$$this$callcontains$arg0$callrequire1$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rangeTo$$this$call-contains$arg-0$call-require-1$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", Integer.valueOf(f316Int$arg0$callrangeTo$$this$callcontains$arg0$callrequire1$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection));
            f346State$Int$arg0$callrangeTo$$this$callcontains$arg0$callrequire1$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-ControlEndpoint", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-ControlEndpoint, reason: not valid java name */
    public final int m6131Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classControlEndpoint() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f317Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classControlEndpoint;
        }
        State<Integer> stateLiveLiteral = f347State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classControlEndpoint;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-ControlEndpoint", Integer.valueOf(f317Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classControlEndpoint));
            f347State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classControlEndpoint = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-ControlEndpoint", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-ControlEndpoint, reason: not valid java name */
    public final int m6132Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classControlEndpoint() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f318Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classControlEndpoint;
        }
        State<Integer> stateLiveLiteral = f348State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classControlEndpoint;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-ControlEndpoint", Integer.valueOf(f318Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classControlEndpoint));
            f348State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classControlEndpoint = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-toInt$arg-0$call-input$else$when$fun-setInput$class-CarControlConnection", offset = 5625)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-toInt$arg-0$call-input$else$when$fun-setInput$class-CarControlConnection, reason: not valid java name */
    public final int m6133Int$arg0$calltimes$$this$calltoInt$arg0$callinput$else$when$funsetInput$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f319Int$arg0$calltimes$$this$calltoInt$arg0$callinput$else$when$funsetInput$classCarControlConnection;
        }
        State<Integer> stateLiveLiteral = f349State$Int$arg0$calltimes$$this$calltoInt$arg0$callinput$else$when$funsetInput$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-toInt$arg-0$call-input$else$when$fun-setInput$class-CarControlConnection", Integer.valueOf(f319Int$arg0$calltimes$$this$calltoInt$arg0$callinput$else$when$funsetInput$classCarControlConnection));
            f349State$Int$arg0$calltimes$$this$calltoInt$arg0$callinput$else$when$funsetInput$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-toInt$arg-1$call-input$else$when$fun-setInput$class-CarControlConnection", offset = 5670)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-toInt$arg-1$call-input$else$when$fun-setInput$class-CarControlConnection, reason: not valid java name */
    public final int m6134Int$arg0$calltimes$$this$calltoInt$arg1$callinput$else$when$funsetInput$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f320Int$arg0$calltimes$$this$calltoInt$arg1$callinput$else$when$funsetInput$classCarControlConnection;
        }
        State<Integer> stateLiveLiteral = f350State$Int$arg0$calltimes$$this$calltoInt$arg1$callinput$else$when$funsetInput$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-toInt$arg-1$call-input$else$when$fun-setInput$class-CarControlConnection", Integer.valueOf(f320Int$arg0$calltimes$$this$calltoInt$arg1$callinput$else$when$funsetInput$classCarControlConnection));
            f350State$Int$arg0$calltimes$$this$calltoInt$arg1$callinput$else$when$funsetInput$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-CarControlConnection", offset = -1)
    /* JADX INFO: renamed from: Int$class-CarControlConnection, reason: not valid java name */
    public final int m6135Int$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f321Int$classCarControlConnection;
        }
        State<Integer> stateLiveLiteral = f351State$Int$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-CarControlConnection", Integer.valueOf(f321Int$classCarControlConnection));
            f351State$Int$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-ControlEndpoint", offset = -1)
    /* JADX INFO: renamed from: Int$class-ControlEndpoint, reason: not valid java name */
    public final int m6136Int$classControlEndpoint() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f322Int$classControlEndpoint;
        }
        State<Integer> stateLiveLiteral = f352State$Int$classControlEndpoint;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-ControlEndpoint", Integer.valueOf(f322Int$classControlEndpoint));
            f352State$Int$classControlEndpoint = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$param-statusPort$fun-connect$class-CarControlConnection", offset = 1137)
    /* JADX INFO: renamed from: Int$param-statusPort$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final int m6137Int$paramstatusPort$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f323Int$paramstatusPort$funconnect$classCarControlConnection;
        }
        State<Integer> stateLiveLiteral = f353State$Int$paramstatusPort$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$param-statusPort$fun-connect$class-CarControlConnection", Integer.valueOf(f323Int$paramstatusPort$funconnect$classCarControlConnection));
            f353State$Int$paramstatusPort$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-delay$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", offset = 4825)
    /* JADX INFO: renamed from: Long$arg-0$call-delay$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final long m6138Long$arg0$calldelay$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f324Long$arg0$calldelay$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        }
        State<Long> stateLiveLiteral = f354State$Long$arg0$calldelay$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-delay$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", Long.valueOf(f324Long$arg0$calldelay$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection));
            f354State$Long$arg0$calldelay$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-rangeTo$$this$call-contains$arg-0$call-require$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", offset = 2192)
    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$arg-0$call-require$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final long m6139Long$arg0$callrangeTo$$this$callcontains$arg0$callrequire$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f325Long$arg0$callrangeTo$$this$callcontains$arg0$callrequire$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        }
        State<Long> stateLiveLiteral = f355State$Long$arg0$callrangeTo$$this$callcontains$arg0$callrequire$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-rangeTo$$this$call-contains$arg-0$call-require$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", Long.valueOf(f325Long$arg0$callrangeTo$$this$callcontains$arg0$callrequire$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection));
            f355State$Long$arg0$callrangeTo$$this$callcontains$arg0$callrequire$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-invoke$branch$if$fun-$anonymous$$arg-1$call-synchronized$catch-1$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", offset = 5124)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$branch$if$fun-$anonymous$$arg-1$call-synchronized$catch-1$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final String m6140String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg1$callsynchronized$catch1$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f378String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg1$callsynchronized$catch1$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        }
        State<String> stateLiveLiteral = f356State$String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg1$callsynchronized$catch1$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-invoke$branch$if$fun-$anonymous$$arg-1$call-synchronized$catch-1$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", f378String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg1$callsynchronized$catch1$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection);
            f356State$String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg1$callsynchronized$catch1$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$fun-toString$class-ControlEndpoint", offset = -2)
    /* JADX INFO: renamed from: String$0$str$fun-toString$class-ControlEndpoint, reason: not valid java name */
    public final String m6141String$0$str$funtoString$classControlEndpoint() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f379String$0$str$funtoString$classControlEndpoint;
        }
        State<String> stateLiveLiteral = f357State$String$0$str$funtoString$classControlEndpoint;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$fun-toString$class-ControlEndpoint", f379String$0$str$funtoString$classControlEndpoint);
            f357State$String$0$str$funtoString$classControlEndpoint = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$1$str$fun-toString$class-ControlEndpoint", offset = -2)
    /* JADX INFO: renamed from: String$1$str$fun-toString$class-ControlEndpoint, reason: not valid java name */
    public final String m6142String$1$str$funtoString$classControlEndpoint() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f380String$1$str$funtoString$classControlEndpoint;
        }
        State<String> stateLiveLiteral = f358State$String$1$str$funtoString$classControlEndpoint;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$1$str$fun-toString$class-ControlEndpoint", f380String$1$str$funtoString$classControlEndpoint);
            f358State$String$1$str$funtoString$classControlEndpoint = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$3$str$fun-toString$class-ControlEndpoint", offset = -2)
    /* JADX INFO: renamed from: String$3$str$fun-toString$class-ControlEndpoint, reason: not valid java name */
    public final String m6143String$3$str$funtoString$classControlEndpoint() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f381String$3$str$funtoString$classControlEndpoint;
        }
        State<String> stateLiveLiteral = f359State$String$3$str$funtoString$classControlEndpoint;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$3$str$fun-toString$class-ControlEndpoint", f381String$3$str$funtoString$classControlEndpoint);
            f359State$String$3$str$funtoString$classControlEndpoint = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$4$str$fun-toString$class-ControlEndpoint", offset = -2)
    /* JADX INFO: renamed from: String$4$str$fun-toString$class-ControlEndpoint, reason: not valid java name */
    public final String m6144String$4$str$funtoString$classControlEndpoint() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f382String$4$str$funtoString$classControlEndpoint;
        }
        State<String> stateLiveLiteral = f360State$String$4$str$funtoString$classControlEndpoint;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$4$str$fun-toString$class-ControlEndpoint", f382String$4$str$funtoString$classControlEndpoint);
            f360State$String$4$str$funtoString$classControlEndpoint = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$6$str$fun-toString$class-ControlEndpoint", offset = -2)
    /* JADX INFO: renamed from: String$6$str$fun-toString$class-ControlEndpoint, reason: not valid java name */
    public final String m6145String$6$str$funtoString$classControlEndpoint() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f383String$6$str$funtoString$classControlEndpoint;
        }
        State<String> stateLiveLiteral = f361State$String$6$str$funtoString$classControlEndpoint;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$6$str$fun-toString$class-ControlEndpoint", f383String$6$str$funtoString$classControlEndpoint);
            f361State$String$6$str$funtoString$classControlEndpoint = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$7$str$fun-toString$class-ControlEndpoint", offset = -2)
    /* JADX INFO: renamed from: String$7$str$fun-toString$class-ControlEndpoint, reason: not valid java name */
    public final String m6146String$7$str$funtoString$classControlEndpoint() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f384String$7$str$funtoString$classControlEndpoint;
        }
        State<String> stateLiveLiteral = f362State$String$7$str$funtoString$classControlEndpoint;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$7$str$fun-toString$class-ControlEndpoint", f384String$7$str$funtoString$classControlEndpoint);
            f362State$String$7$str$funtoString$classControlEndpoint = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$9$str$fun-toString$class-ControlEndpoint", offset = -2)
    /* JADX INFO: renamed from: String$9$str$fun-toString$class-ControlEndpoint, reason: not valid java name */
    public final String m6147String$9$str$funtoString$classControlEndpoint() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f385String$9$str$funtoString$classControlEndpoint;
        }
        State<String> stateLiveLiteral = f363State$String$9$str$funtoString$classControlEndpoint;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$9$str$fun-toString$class-ControlEndpoint", f385String$9$str$funtoString$classControlEndpoint);
            f363State$String$9$str$funtoString$classControlEndpoint = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$arg-0$call-$set-value$$branch$if-1$fun-connect$class-CarControlConnection", offset = 1621)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-0$call-$set-value$$branch$if-1$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final String m6148String$arg0$call$init$$arg0$call$setvalue$$branch$if1$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f386String$arg0$call$init$$arg0$call$setvalue$$branch$if1$funconnect$classCarControlConnection;
        }
        State<String> stateLiveLiteral = f364State$String$arg0$call$init$$arg0$call$setvalue$$branch$if1$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$arg-0$call-$set-value$$branch$if-1$fun-connect$class-CarControlConnection", f386String$arg0$call$init$$arg0$call$setvalue$$branch$if1$funconnect$classCarControlConnection);
            f364State$String$arg0$call$init$$arg0$call$setvalue$$branch$if1$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$arg-0$call-$set-value$$fun-connect$class-CarControlConnection", offset = 1769)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-0$call-$set-value$$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final String m6149String$arg0$call$init$$arg0$call$setvalue$$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f387String$arg0$call$init$$arg0$call$setvalue$$funconnect$classCarControlConnection;
        }
        State<String> stateLiveLiteral = f365State$String$arg0$call$init$$arg0$call$setvalue$$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$arg-0$call-$set-value$$fun-connect$class-CarControlConnection", f387String$arg0$call$init$$arg0$call$setvalue$$funconnect$classCarControlConnection);
            f365State$String$arg0$call$init$$arg0$call$setvalue$$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$branch$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", offset = 4050)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final String m6150String$arg0$call$init$$branch$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f388String$arg0$call$init$$branch$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        }
        State<String> stateLiveLiteral = f366State$String$arg0$call$init$$branch$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$branch$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", f388String$arg0$call$init$$branch$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection);
            f366State$String$arg0$call$init$$branch$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$branch-1$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", offset = 4170)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch-1$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final String m6151String$arg0$call$init$$branch1$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f389String$arg0$call$init$$branch1$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        }
        State<String> stateLiveLiteral = f367State$String$arg0$call$init$$branch1$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$branch-1$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", f389String$arg0$call$init$$branch1$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection);
            f367State$String$arg0$call$init$$branch1$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$branch-2$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", offset = 4454)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch-2$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final String m6152String$arg0$call$init$$branch2$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f390String$arg0$call$init$$branch2$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        }
        State<String> stateLiveLiteral = f368State$String$arg0$call$init$$branch2$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$branch-2$when$fun-$anonymous$$arg-0$call-let$else$when$branch$when$val-tmp5_elvis_lhs$val-value$fun-$anonymous$$arg-1$call-synchronized$body$loop$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", f390String$arg0$call$init$$branch2$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection);
            f368State$String$arg0$call$init$$branch2$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-disconnect$branch$if$fun-$anonymous$$arg-1$call-synchronized$catch-1$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", offset = 5211)
    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if$fun-$anonymous$$arg-1$call-synchronized$catch-1$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final String m6153String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$catch1$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f391String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$catch1$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        }
        State<String> stateLiveLiteral = f369State$String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$catch1$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-disconnect$branch$if$fun-$anonymous$$arg-1$call-synchronized$catch-1$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", f391String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$catch1$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection);
            f369State$String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$catch1$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-disconnect$branch$if$fun-setInput$class-CarControlConnection", offset = 5482)
    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if$fun-setInput$class-CarControlConnection, reason: not valid java name */
    public final String m6154String$arg0$calldisconnect$branch$if$funsetInput$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f392String$arg0$calldisconnect$branch$if$funsetInput$classCarControlConnection;
        }
        State<String> stateLiveLiteral = f370State$String$arg0$calldisconnect$branch$if$funsetInput$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-disconnect$branch$if$fun-setInput$class-CarControlConnection", f392String$arg0$calldisconnect$branch$if$funsetInput$classCarControlConnection);
            f370State$String$arg0$calldisconnect$branch$if$funsetInput$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-disconnect$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", offset = 2387)
    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final String m6155String$arg0$calldisconnect$branch$if1$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f393String$arg0$calldisconnect$branch$if1$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        }
        State<String> stateLiveLiteral = f371State$String$arg0$calldisconnect$branch$if1$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-disconnect$branch$if-1$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", f393String$arg0$calldisconnect$branch$if1$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection);
            f371State$String$arg0$calldisconnect$branch$if1$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-disconnect$branch$if-2$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", offset = 2574)
    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if-2$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final String m6156String$arg0$calldisconnect$branch$if2$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f394String$arg0$calldisconnect$branch$if2$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        }
        State<String> stateLiveLiteral = f372State$String$arg0$calldisconnect$branch$if2$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-disconnect$branch$if-2$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", f394String$arg0$calldisconnect$branch$if2$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection);
            f372State$String$arg0$calldisconnect$branch$if2$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-disconnect$branch$if-3$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", offset = 2793)
    /* JADX INFO: renamed from: String$arg-0$call-disconnect$branch$if-3$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final String m6157String$arg0$calldisconnect$branch$if3$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f395String$arg0$calldisconnect$branch$if3$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        }
        State<String> stateLiveLiteral = f373State$String$arg0$calldisconnect$branch$if3$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-disconnect$branch$if-3$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", f395String$arg0$calldisconnect$branch$if3$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection);
            f373State$String$arg0$calldisconnect$branch$if3$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-disconnect$else$when$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", offset = 3478)
    /* JADX INFO: renamed from: String$arg-0$call-disconnect$else$when$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final String m6158String$arg0$calldisconnect$else$when$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f396String$arg0$calldisconnect$else$when$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        }
        State<String> stateLiveLiteral = f374State$String$arg0$calldisconnect$else$when$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-disconnect$else$when$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", f396String$arg0$calldisconnect$else$when$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection);
            f374State$String$arg0$calldisconnect$else$when$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-1$call-EQEQ$cond$when$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", offset = 2957)
    /* JADX INFO: renamed from: String$arg-1$call-EQEQ$cond$when$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final String m6159String$arg1$callEQEQ$cond$when$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f397String$arg1$callEQEQ$cond$when$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        }
        State<String> stateLiveLiteral = f375State$String$arg1$callEQEQ$cond$when$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-1$call-EQEQ$cond$when$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", f397String$arg1$callEQEQ$cond$when$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection);
            f375State$String$arg1$callEQEQ$cond$when$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-1$call-EQEQ$cond-1$when$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", offset = 3193)
    /* JADX INFO: renamed from: String$arg-1$call-EQEQ$cond-1$when$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection, reason: not valid java name */
    public final String m6160String$arg1$callEQEQ$cond1$when$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f398String$arg1$callEQEQ$cond1$when$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        }
        State<String> stateLiveLiteral = f376State$String$arg1$callEQEQ$cond1$when$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-1$call-EQEQ$cond-1$when$fun-$anonymous$$arg-1$call-synchronized$try$fun-$anonymous$$arg-2$call-launch$arg-0$call-$set-job$$fun-connect$class-CarControlConnection", f398String$arg1$callEQEQ$cond1$when$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection);
            f376State$String$arg1$callEQEQ$cond1$when$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$param-message$fun-disconnect$class-CarControlConnection", offset = 5796)
    /* JADX INFO: renamed from: String$param-message$fun-disconnect$class-CarControlConnection, reason: not valid java name */
    public final String m6161String$parammessage$fundisconnect$classCarControlConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f399String$parammessage$fundisconnect$classCarControlConnection;
        }
        State<String> stateLiveLiteral = f377State$String$parammessage$fundisconnect$classCarControlConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$param-message$fun-disconnect$class-CarControlConnection", f399String$parammessage$fundisconnect$classCarControlConnection);
            f377State$String$parammessage$fundisconnect$classCarControlConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
