package vea.raceremote.control;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: CarDiscovery.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/control/CarDiscovery.kt")
public final class LiveLiterals$CarDiscoveryKt {

    /* JADX INFO: renamed from: Boolean$arg-0$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized$catch$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static boolean f572Boolean$arg0$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized$catch$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: Boolean$arg-0$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static boolean f574Boolean$arg0$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-DiscoveryState, reason: not valid java name */
    private static boolean f578Boolean$branch$when1$funequals$classDiscoveryState;

    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-DiscoveryState, reason: not valid java name */
    private static boolean f579Boolean$branch$when2$funequals$classDiscoveryState;

    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-DiscoveryState, reason: not valid java name */
    private static boolean f580Boolean$branch$when3$funequals$classDiscoveryState;

    /* JADX INFO: renamed from: Boolean$branch$when-4$fun-equals$class-DiscoveryState, reason: not valid java name */
    private static boolean f581Boolean$branch$when4$funequals$classDiscoveryState;

    /* JADX INFO: renamed from: Boolean$param-searching$class-DiscoveryState, reason: not valid java name */
    private static boolean f583Boolean$paramsearching$classDiscoveryState;

    /* JADX INFO: renamed from: Int$branch$when$arg-0$call-greater$cond$if-2$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static int f593Int$branch$when$arg0$callgreater$cond$if2$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$cond$loop$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static long f597Long$arg1$callEQEQ$cond$loop$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized$catch$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static State<Boolean> f599State$Boolean$arg0$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized$catch$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized-1$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static State<Boolean> f600State$Boolean$arg0$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static State<Boolean> f601State$Boolean$arg0$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-$init$$arg-0$call-$set-value$$fun-search$class-CarDiscovery, reason: not valid java name */
    private static State<Boolean> f602State$Boolean$arg0$call$init$$arg0$call$setvalue$$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-setBroadcast$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static State<Boolean> f603State$Boolean$arg0$callsetBroadcast$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: State$Boolean$branch$when$fun-equals$class-DiscoveryState, reason: not valid java name */
    private static State<Boolean> f604State$Boolean$branch$when$funequals$classDiscoveryState;

    /* JADX INFO: renamed from: State$Boolean$branch$when-1$fun-equals$class-DiscoveryState, reason: not valid java name */
    private static State<Boolean> f605State$Boolean$branch$when1$funequals$classDiscoveryState;

    /* JADX INFO: renamed from: State$Boolean$branch$when-2$fun-equals$class-DiscoveryState, reason: not valid java name */
    private static State<Boolean> f606State$Boolean$branch$when2$funequals$classDiscoveryState;

    /* JADX INFO: renamed from: State$Boolean$branch$when-3$fun-equals$class-DiscoveryState, reason: not valid java name */
    private static State<Boolean> f607State$Boolean$branch$when3$funequals$classDiscoveryState;

    /* JADX INFO: renamed from: State$Boolean$branch$when-4$fun-equals$class-DiscoveryState, reason: not valid java name */
    private static State<Boolean> f608State$Boolean$branch$when4$funequals$classDiscoveryState;

    /* JADX INFO: renamed from: State$Boolean$fun-equals$class-DiscoveryState, reason: not valid java name */
    private static State<Boolean> f609State$Boolean$funequals$classDiscoveryState;

    /* JADX INFO: renamed from: State$Boolean$param-searching$class-DiscoveryState, reason: not valid java name */
    private static State<Boolean> f610State$Boolean$paramsearching$classDiscoveryState;

    /* JADX INFO: renamed from: State$Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static State<Integer> f611State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: State$Int$arg-0$call-$init$$arg-0$call-$init$$val-packet$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static State<Integer> f612State$Int$arg0$call$init$$arg0$call$init$$valpacket$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: State$Int$arg-0$call-div$val-elapsed$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static State<Integer> f613State$Int$arg0$calldiv$valelapsed$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: State$Int$arg-0$call-setSoTimeout$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static State<Integer> f614State$Int$arg0$callsetSoTimeout$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-DiscoveryState, reason: not valid java name */
    private static State<Integer> f615State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classDiscoveryState;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-DiscoveryState, reason: not valid java name */
    private static State<Integer> f616State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classDiscoveryState;

    /* JADX INFO: renamed from: State$Int$arg-1$call-$init$$val-packet$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static State<Integer> f617State$Int$arg1$call$init$$valpacket$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: State$Int$arg-1$call-greater$cond$if-3$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static State<Integer> f618State$Int$arg1$callgreater$cond$if3$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: State$Int$arg-1$call-query$1$vararg$arg-0$call-listOf$val-queries$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static State<Integer> f619State$Int$arg1$callquery$1$vararg$arg0$calllistOf$valqueries$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: State$Int$branch$when$arg-0$call-greater$cond$if-2$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static State<Integer> f620State$Int$branch$when$arg0$callgreater$cond$if2$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: State$Int$class-CarDiscovery, reason: not valid java name */
    private static State<Integer> f621State$Int$classCarDiscovery;

    /* JADX INFO: renamed from: State$Int$class-DiscoveryState, reason: not valid java name */
    private static State<Integer> f622State$Int$classDiscoveryState;

    /* JADX INFO: renamed from: State$Long$arg-0$call-and$set-nonce$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static State<Long> f623State$Long$arg0$calland$setnonce$body$loop$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: State$Long$arg-1$call-EQEQ$cond$loop$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static State<Long> f624State$Long$arg1$callEQEQ$cond$loop$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: State$Long$val-lastSend$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static State<Long> f625State$Long$vallastSend$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: State$String$0$str$fun-toString$class-DiscoveryState, reason: not valid java name */
    private static State<String> f626State$String$0$str$funtoString$classDiscoveryState;

    /* JADX INFO: renamed from: State$String$1$str$fun-toString$class-DiscoveryState, reason: not valid java name */
    private static State<String> f627State$String$1$str$funtoString$classDiscoveryState;

    /* JADX INFO: renamed from: State$String$1$str$val-key$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static State<String> f628State$String$1$str$valkey$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: State$String$3$str$fun-toString$class-DiscoveryState, reason: not valid java name */
    private static State<String> f629State$String$3$str$funtoString$classDiscoveryState;

    /* JADX INFO: renamed from: State$String$4$str$fun-toString$class-DiscoveryState, reason: not valid java name */
    private static State<String> f630State$String$4$str$funtoString$classDiscoveryState;

    /* JADX INFO: renamed from: State$String$6$str$fun-toString$class-DiscoveryState, reason: not valid java name */
    private static State<String> f631State$String$6$str$funtoString$classDiscoveryState;

    /* JADX INFO: renamed from: State$String$7$str$fun-toString$class-DiscoveryState, reason: not valid java name */
    private static State<String> f632State$String$7$str$funtoString$classDiscoveryState;

    /* JADX INFO: renamed from: State$String$9$str$fun-toString$class-DiscoveryState, reason: not valid java name */
    private static State<String> f633State$String$9$str$funtoString$classDiscoveryState;

    /* JADX INFO: renamed from: State$String$arg-2$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized$catch$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static State<String> f634State$String$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized$catch$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: State$String$arg-2$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized-1$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static State<String> f635State$String$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: State$String$arg-2$call-$init$$arg-0$call-$set-value$$branch$if$fun-search$class-CarDiscovery, reason: not valid java name */
    private static State<String> f636State$String$arg2$call$init$$arg0$call$setvalue$$branch$if$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: State$String$arg-2$call-$init$$arg-0$call-$set-value$$fun-search$class-CarDiscovery, reason: not valid java name */
    private static State<String> f637State$String$arg2$call$init$$arg0$call$setvalue$$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: State$String$branch$if$arg-2$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static State<String> f638State$String$branch$if$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: State$String$else$if$arg-2$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static State<String> f639State$String$else$if$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;

    /* JADX INFO: renamed from: State$String$param-message$class-DiscoveryState, reason: not valid java name */
    private static State<String> f640State$String$parammessage$classDiscoveryState;
    public static final LiveLiterals$CarDiscoveryKt INSTANCE = new LiveLiterals$CarDiscoveryKt();

    /* JADX INFO: renamed from: String$param-message$class-DiscoveryState, reason: not valid java name */
    private static String f655String$parammessage$classDiscoveryState = "";

    /* JADX INFO: renamed from: String$0$str$fun-toString$class-DiscoveryState, reason: not valid java name */
    private static String f641String$0$str$funtoString$classDiscoveryState = "DiscoveryState(";

    /* JADX INFO: renamed from: String$1$str$fun-toString$class-DiscoveryState, reason: not valid java name */
    private static String f642String$1$str$funtoString$classDiscoveryState = "searching=";

    /* JADX INFO: renamed from: String$3$str$fun-toString$class-DiscoveryState, reason: not valid java name */
    private static String f644String$3$str$funtoString$classDiscoveryState = ", ";

    /* JADX INFO: renamed from: String$4$str$fun-toString$class-DiscoveryState, reason: not valid java name */
    private static String f645String$4$str$funtoString$classDiscoveryState = "cars=";

    /* JADX INFO: renamed from: String$6$str$fun-toString$class-DiscoveryState, reason: not valid java name */
    private static String f646String$6$str$funtoString$classDiscoveryState = ", ";

    /* JADX INFO: renamed from: String$7$str$fun-toString$class-DiscoveryState, reason: not valid java name */
    private static String f647String$7$str$funtoString$classDiscoveryState = "message=";

    /* JADX INFO: renamed from: String$9$str$fun-toString$class-DiscoveryState, reason: not valid java name */
    private static String f648String$9$str$funtoString$classDiscoveryState = ")";

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-DiscoveryState, reason: not valid java name */
    private static int f588Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classDiscoveryState = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-DiscoveryState, reason: not valid java name */
    private static int f589Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classDiscoveryState = 31;

    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-DiscoveryState, reason: not valid java name */
    private static boolean f577Boolean$branch$when$funequals$classDiscoveryState = true;

    /* JADX INFO: renamed from: Boolean$fun-equals$class-DiscoveryState, reason: not valid java name */
    private static boolean f582Boolean$funequals$classDiscoveryState = true;

    /* JADX INFO: renamed from: Int$class-DiscoveryState, reason: not valid java name */
    private static int f595Int$classDiscoveryState = 8;

    /* JADX INFO: renamed from: String$arg-2$call-$init$$arg-0$call-$set-value$$branch$if$fun-search$class-CarDiscovery, reason: not valid java name */
    private static String f651String$arg2$call$init$$arg0$call$setvalue$$branch$if$funsearch$classCarDiscovery = "Нет доступной локальной сети";

    /* JADX INFO: renamed from: Boolean$arg-0$call-$init$$arg-0$call-$set-value$$fun-search$class-CarDiscovery, reason: not valid java name */
    private static boolean f575Boolean$arg0$call$init$$arg0$call$setvalue$$funsearch$classCarDiscovery = true;

    /* JADX INFO: renamed from: String$arg-2$call-$init$$arg-0$call-$set-value$$fun-search$class-CarDiscovery, reason: not valid java name */
    private static String f652String$arg2$call$init$$arg0$call$setvalue$$funsearch$classCarDiscovery = "Ищу машинки…";

    /* JADX INFO: renamed from: Boolean$arg-0$call-setBroadcast$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static boolean f576Boolean$arg0$callsetBroadcast$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = true;

    /* JADX INFO: renamed from: Int$arg-0$call-setSoTimeout$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static int f587Int$arg0$callsetSoTimeout$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = 100;

    /* JADX INFO: renamed from: Long$arg-0$call-and$set-nonce$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static long f596Long$arg0$calland$setnonce$body$loop$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = 4294967295L;

    /* JADX INFO: renamed from: Int$arg-1$call-query$1$vararg$arg-0$call-listOf$val-queries$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static int f592Int$arg1$callquery$1$vararg$arg0$calllistOf$valqueries$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = 2;

    /* JADX INFO: renamed from: Long$val-lastSend$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static long f598Long$vallastSend$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = -500;

    /* JADX INFO: renamed from: Int$arg-0$call-div$val-elapsed$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static int f586Int$arg0$calldiv$valelapsed$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = 1000000;

    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static int f584Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = 500;

    /* JADX INFO: renamed from: Int$arg-0$call-$init$$arg-0$call-$init$$val-packet$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static int f585Int$arg0$call$init$$arg0$call$init$$valpacket$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = 25;

    /* JADX INFO: renamed from: Int$arg-1$call-$init$$val-packet$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static int f590Int$arg1$call$init$$valpacket$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = 25;

    /* JADX INFO: renamed from: String$1$str$val-key$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static String f643String$1$str$valkey$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = "/";

    /* JADX INFO: renamed from: Int$arg-1$call-greater$cond$if-3$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static int f591Int$arg1$callgreater$cond$if3$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = 32;

    /* JADX INFO: renamed from: Boolean$arg-0$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized-1$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static boolean f573Boolean$arg0$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = true;

    /* JADX INFO: renamed from: String$arg-2$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized-1$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static String f650String$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = "Ищу машинки…";

    /* JADX INFO: renamed from: String$branch$if$arg-2$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static String f653String$branch$if$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = "Машинки не найдены. Можно ввести адрес вручную.";

    /* JADX INFO: renamed from: String$else$if$arg-2$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static String f654String$else$if$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = "Выбери машинку";

    /* JADX INFO: renamed from: String$arg-2$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized$catch$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    private static String f649String$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized$catch$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = "Не удалось выполнить поиск";

    /* JADX INFO: renamed from: Int$class-CarDiscovery, reason: not valid java name */
    private static int f594Int$classCarDiscovery = 8;

    @LiveLiteralInfo(key = "Boolean$arg-0$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized$catch$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", offset = 4116)
    /* JADX INFO: renamed from: Boolean$arg-0$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized$catch$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    public final boolean m6248Boolean$arg0$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized$catch$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f572Boolean$arg0$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized$catch$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        }
        State<Boolean> stateLiveLiteral = f599State$Boolean$arg0$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized$catch$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized$catch$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", Boolean.valueOf(f572Boolean$arg0$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized$catch$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery));
            f599State$Boolean$arg0$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized$catch$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized-1$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", offset = 3546)
    /* JADX INFO: renamed from: Boolean$arg-0$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized-1$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    public final boolean m6249Boolean$arg0$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f573Boolean$arg0$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        }
        State<Boolean> stateLiveLiteral = f600State$Boolean$arg0$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized-1$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", Boolean.valueOf(f573Boolean$arg0$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery));
            f600State$Boolean$arg0$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", offset = 3767)
    /* JADX INFO: renamed from: Boolean$arg-0$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    public final boolean m6250Boolean$arg0$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f574Boolean$arg0$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        }
        State<Boolean> stateLiveLiteral = f601State$Boolean$arg0$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", Boolean.valueOf(f574Boolean$arg0$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery));
            f601State$Boolean$arg0$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-$init$$arg-0$call-$set-value$$fun-search$class-CarDiscovery", offset = 1256)
    /* JADX INFO: renamed from: Boolean$arg-0$call-$init$$arg-0$call-$set-value$$fun-search$class-CarDiscovery, reason: not valid java name */
    public final boolean m6251Boolean$arg0$call$init$$arg0$call$setvalue$$funsearch$classCarDiscovery() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f575Boolean$arg0$call$init$$arg0$call$setvalue$$funsearch$classCarDiscovery;
        }
        State<Boolean> stateLiveLiteral = f602State$Boolean$arg0$call$init$$arg0$call$setvalue$$funsearch$classCarDiscovery;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-$init$$arg-0$call-$set-value$$fun-search$class-CarDiscovery", Boolean.valueOf(f575Boolean$arg0$call$init$$arg0$call$setvalue$$funsearch$classCarDiscovery));
            f602State$Boolean$arg0$call$init$$arg0$call$setvalue$$funsearch$classCarDiscovery = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-setBroadcast$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", offset = 1675)
    /* JADX INFO: renamed from: Boolean$arg-0$call-setBroadcast$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    public final boolean m6252Boolean$arg0$callsetBroadcast$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f576Boolean$arg0$callsetBroadcast$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        }
        State<Boolean> stateLiveLiteral = f603State$Boolean$arg0$callsetBroadcast$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-setBroadcast$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", Boolean.valueOf(f576Boolean$arg0$callsetBroadcast$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery));
            f603State$Boolean$arg0$callsetBroadcast$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when$fun-equals$class-DiscoveryState", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-DiscoveryState, reason: not valid java name */
    public final boolean m6253Boolean$branch$when$funequals$classDiscoveryState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f577Boolean$branch$when$funequals$classDiscoveryState;
        }
        State<Boolean> stateLiveLiteral = f604State$Boolean$branch$when$funequals$classDiscoveryState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when$fun-equals$class-DiscoveryState", Boolean.valueOf(f577Boolean$branch$when$funequals$classDiscoveryState));
            f604State$Boolean$branch$when$funequals$classDiscoveryState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-1$fun-equals$class-DiscoveryState", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-DiscoveryState, reason: not valid java name */
    public final boolean m6254Boolean$branch$when1$funequals$classDiscoveryState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f578Boolean$branch$when1$funequals$classDiscoveryState;
        }
        State<Boolean> stateLiveLiteral = f605State$Boolean$branch$when1$funequals$classDiscoveryState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-1$fun-equals$class-DiscoveryState", Boolean.valueOf(f578Boolean$branch$when1$funequals$classDiscoveryState));
            f605State$Boolean$branch$when1$funequals$classDiscoveryState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-2$fun-equals$class-DiscoveryState", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-DiscoveryState, reason: not valid java name */
    public final boolean m6255Boolean$branch$when2$funequals$classDiscoveryState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f579Boolean$branch$when2$funequals$classDiscoveryState;
        }
        State<Boolean> stateLiveLiteral = f606State$Boolean$branch$when2$funequals$classDiscoveryState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-2$fun-equals$class-DiscoveryState", Boolean.valueOf(f579Boolean$branch$when2$funequals$classDiscoveryState));
            f606State$Boolean$branch$when2$funequals$classDiscoveryState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-3$fun-equals$class-DiscoveryState", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-DiscoveryState, reason: not valid java name */
    public final boolean m6256Boolean$branch$when3$funequals$classDiscoveryState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f580Boolean$branch$when3$funequals$classDiscoveryState;
        }
        State<Boolean> stateLiveLiteral = f607State$Boolean$branch$when3$funequals$classDiscoveryState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-3$fun-equals$class-DiscoveryState", Boolean.valueOf(f580Boolean$branch$when3$funequals$classDiscoveryState));
            f607State$Boolean$branch$when3$funequals$classDiscoveryState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-4$fun-equals$class-DiscoveryState", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-4$fun-equals$class-DiscoveryState, reason: not valid java name */
    public final boolean m6257Boolean$branch$when4$funequals$classDiscoveryState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f581Boolean$branch$when4$funequals$classDiscoveryState;
        }
        State<Boolean> stateLiveLiteral = f608State$Boolean$branch$when4$funequals$classDiscoveryState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-4$fun-equals$class-DiscoveryState", Boolean.valueOf(f581Boolean$branch$when4$funequals$classDiscoveryState));
            f608State$Boolean$branch$when4$funequals$classDiscoveryState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$fun-equals$class-DiscoveryState", offset = -2)
    /* JADX INFO: renamed from: Boolean$fun-equals$class-DiscoveryState, reason: not valid java name */
    public final boolean m6258Boolean$funequals$classDiscoveryState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f582Boolean$funequals$classDiscoveryState;
        }
        State<Boolean> stateLiveLiteral = f609State$Boolean$funequals$classDiscoveryState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$fun-equals$class-DiscoveryState", Boolean.valueOf(f582Boolean$funequals$classDiscoveryState));
            f609State$Boolean$funequals$classDiscoveryState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$param-searching$class-DiscoveryState", offset = 467)
    /* JADX INFO: renamed from: Boolean$param-searching$class-DiscoveryState, reason: not valid java name */
    public final boolean m6259Boolean$paramsearching$classDiscoveryState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f583Boolean$paramsearching$classDiscoveryState;
        }
        State<Boolean> stateLiveLiteral = f610State$Boolean$paramsearching$classDiscoveryState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$param-searching$class-DiscoveryState", Boolean.valueOf(f583Boolean$paramsearching$classDiscoveryState));
            f610State$Boolean$paramsearching$classDiscoveryState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", offset = 2333)
    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    public final int m6260Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f584Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        }
        State<Integer> stateLiveLiteral = f611State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", Integer.valueOf(f584Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery));
            f611State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-$init$$arg-0$call-$init$$val-packet$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", offset = 2672)
    /* JADX INFO: renamed from: Int$arg-0$call-$init$$arg-0$call-$init$$val-packet$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    public final int m6261Int$arg0$call$init$$arg0$call$init$$valpacket$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f585Int$arg0$call$init$$arg0$call$init$$valpacket$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        }
        State<Integer> stateLiveLiteral = f612State$Int$arg0$call$init$$arg0$call$init$$valpacket$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-$init$$arg-0$call-$init$$val-packet$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", Integer.valueOf(f585Int$arg0$call$init$$arg0$call$init$$valpacket$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery));
            f612State$Int$arg0$call$init$$arg0$call$init$$valpacket$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-div$val-elapsed$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", offset = 2273)
    /* JADX INFO: renamed from: Int$arg-0$call-div$val-elapsed$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    public final int m6262Int$arg0$calldiv$valelapsed$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f586Int$arg0$calldiv$valelapsed$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        }
        State<Integer> stateLiveLiteral = f613State$Int$arg0$calldiv$valelapsed$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-div$val-elapsed$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", Integer.valueOf(f586Int$arg0$calldiv$valelapsed$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery));
            f613State$Int$arg0$calldiv$valelapsed$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-setSoTimeout$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", offset = 1697)
    /* JADX INFO: renamed from: Int$arg-0$call-setSoTimeout$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    public final int m6263Int$arg0$callsetSoTimeout$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f587Int$arg0$callsetSoTimeout$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        }
        State<Integer> stateLiveLiteral = f614State$Int$arg0$callsetSoTimeout$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-setSoTimeout$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", Integer.valueOf(f587Int$arg0$callsetSoTimeout$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery));
            f614State$Int$arg0$callsetSoTimeout$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-DiscoveryState", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-DiscoveryState, reason: not valid java name */
    public final int m6264Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classDiscoveryState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f588Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classDiscoveryState;
        }
        State<Integer> stateLiveLiteral = f615State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classDiscoveryState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-DiscoveryState", Integer.valueOf(f588Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classDiscoveryState));
            f615State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classDiscoveryState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-DiscoveryState", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-DiscoveryState, reason: not valid java name */
    public final int m6265Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classDiscoveryState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f589Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classDiscoveryState;
        }
        State<Integer> stateLiveLiteral = f616State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classDiscoveryState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-DiscoveryState", Integer.valueOf(f589Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classDiscoveryState));
            f616State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classDiscoveryState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-$init$$val-packet$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", offset = 2677)
    /* JADX INFO: renamed from: Int$arg-1$call-$init$$val-packet$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    public final int m6266Int$arg1$call$init$$valpacket$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f590Int$arg1$call$init$$valpacket$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        }
        State<Integer> stateLiveLiteral = f617State$Int$arg1$call$init$$valpacket$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-$init$$val-packet$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", Integer.valueOf(f590Int$arg1$call$init$$valpacket$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery));
            f617State$Int$arg1$call$init$$valpacket$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-greater$cond$if-3$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", offset = 3373)
    /* JADX INFO: renamed from: Int$arg-1$call-greater$cond$if-3$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    public final int m6267Int$arg1$callgreater$cond$if3$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f591Int$arg1$callgreater$cond$if3$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        }
        State<Integer> stateLiveLiteral = f618State$Int$arg1$callgreater$cond$if3$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-greater$cond$if-3$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", Integer.valueOf(f591Int$arg1$callgreater$cond$if3$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery));
            f618State$Int$arg1$callgreater$cond$if3$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-query$1$vararg$arg-0$call-listOf$val-queries$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", offset = 1942)
    /* JADX INFO: renamed from: Int$arg-1$call-query$1$vararg$arg-0$call-listOf$val-queries$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    public final int m6268Int$arg1$callquery$1$vararg$arg0$calllistOf$valqueries$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f592Int$arg1$callquery$1$vararg$arg0$calllistOf$valqueries$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        }
        State<Integer> stateLiveLiteral = f619State$Int$arg1$callquery$1$vararg$arg0$calllistOf$valqueries$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-query$1$vararg$arg-0$call-listOf$val-queries$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", Integer.valueOf(f592Int$arg1$callquery$1$vararg$arg0$calllistOf$valqueries$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery));
            f619State$Int$arg1$callquery$1$vararg$arg0$calllistOf$valqueries$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$branch$when$arg-0$call-greater$cond$if-2$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", offset = 3255)
    /* JADX INFO: renamed from: Int$branch$when$arg-0$call-greater$cond$if-2$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    public final int m6269Int$branch$when$arg0$callgreater$cond$if2$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f593Int$branch$when$arg0$callgreater$cond$if2$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        }
        State<Integer> stateLiveLiteral = f620State$Int$branch$when$arg0$callgreater$cond$if2$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$branch$when$arg-0$call-greater$cond$if-2$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", Integer.valueOf(f593Int$branch$when$arg0$callgreater$cond$if2$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery));
            f620State$Int$branch$when$arg0$callgreater$cond$if2$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-CarDiscovery", offset = -1)
    /* JADX INFO: renamed from: Int$class-CarDiscovery, reason: not valid java name */
    public final int m6270Int$classCarDiscovery() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f594Int$classCarDiscovery;
        }
        State<Integer> stateLiveLiteral = f621State$Int$classCarDiscovery;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-CarDiscovery", Integer.valueOf(f594Int$classCarDiscovery));
            f621State$Int$classCarDiscovery = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-DiscoveryState", offset = -1)
    /* JADX INFO: renamed from: Int$class-DiscoveryState, reason: not valid java name */
    public final int m6271Int$classDiscoveryState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f595Int$classDiscoveryState;
        }
        State<Integer> stateLiveLiteral = f622State$Int$classDiscoveryState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-DiscoveryState", Integer.valueOf(f595Int$classDiscoveryState));
            f622State$Int$classDiscoveryState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-and$set-nonce$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", offset = 1808)
    /* JADX INFO: renamed from: Long$arg-0$call-and$set-nonce$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    public final long m6272Long$arg0$calland$setnonce$body$loop$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f596Long$arg0$calland$setnonce$body$loop$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        }
        State<Long> stateLiveLiteral = f623State$Long$arg0$calland$setnonce$body$loop$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-and$set-nonce$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", Long.valueOf(f596Long$arg0$calland$setnonce$body$loop$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery));
            f623State$Long$arg0$calland$setnonce$body$loop$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-1$call-EQEQ$cond$loop$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", offset = 1838)
    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$cond$loop$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    public final long m6273Long$arg1$callEQEQ$cond$loop$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f597Long$arg1$callEQEQ$cond$loop$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        }
        State<Long> stateLiveLiteral = f624State$Long$arg1$callEQEQ$cond$loop$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-1$call-EQEQ$cond$loop$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", Long.valueOf(f597Long$arg1$callEQEQ$cond$loop$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery));
            f624State$Long$arg1$callEQEQ$cond$loop$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$val-lastSend$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", offset = 2033)
    /* JADX INFO: renamed from: Long$val-lastSend$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    public final long m6274Long$vallastSend$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f598Long$vallastSend$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        }
        State<Long> stateLiveLiteral = f625State$Long$vallastSend$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$val-lastSend$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", Long.valueOf(f598Long$vallastSend$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery));
            f625State$Long$vallastSend$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "String$0$str$fun-toString$class-DiscoveryState", offset = -2)
    /* JADX INFO: renamed from: String$0$str$fun-toString$class-DiscoveryState, reason: not valid java name */
    public final String m6275String$0$str$funtoString$classDiscoveryState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f641String$0$str$funtoString$classDiscoveryState;
        }
        State<String> stateLiveLiteral = f626State$String$0$str$funtoString$classDiscoveryState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$fun-toString$class-DiscoveryState", f641String$0$str$funtoString$classDiscoveryState);
            f626State$String$0$str$funtoString$classDiscoveryState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$1$str$fun-toString$class-DiscoveryState", offset = -2)
    /* JADX INFO: renamed from: String$1$str$fun-toString$class-DiscoveryState, reason: not valid java name */
    public final String m6276String$1$str$funtoString$classDiscoveryState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f642String$1$str$funtoString$classDiscoveryState;
        }
        State<String> stateLiveLiteral = f627State$String$1$str$funtoString$classDiscoveryState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$1$str$fun-toString$class-DiscoveryState", f642String$1$str$funtoString$classDiscoveryState);
            f627State$String$1$str$funtoString$classDiscoveryState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$1$str$val-key$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", offset = 3180)
    /* JADX INFO: renamed from: String$1$str$val-key$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    public final String m6277String$1$str$valkey$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f643String$1$str$valkey$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        }
        State<String> stateLiveLiteral = f628State$String$1$str$valkey$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$1$str$val-key$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", f643String$1$str$valkey$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery);
            f628State$String$1$str$valkey$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$3$str$fun-toString$class-DiscoveryState", offset = -2)
    /* JADX INFO: renamed from: String$3$str$fun-toString$class-DiscoveryState, reason: not valid java name */
    public final String m6278String$3$str$funtoString$classDiscoveryState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f644String$3$str$funtoString$classDiscoveryState;
        }
        State<String> stateLiveLiteral = f629State$String$3$str$funtoString$classDiscoveryState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$3$str$fun-toString$class-DiscoveryState", f644String$3$str$funtoString$classDiscoveryState);
            f629State$String$3$str$funtoString$classDiscoveryState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$4$str$fun-toString$class-DiscoveryState", offset = -2)
    /* JADX INFO: renamed from: String$4$str$fun-toString$class-DiscoveryState, reason: not valid java name */
    public final String m6279String$4$str$funtoString$classDiscoveryState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f645String$4$str$funtoString$classDiscoveryState;
        }
        State<String> stateLiveLiteral = f630State$String$4$str$funtoString$classDiscoveryState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$4$str$fun-toString$class-DiscoveryState", f645String$4$str$funtoString$classDiscoveryState);
            f630State$String$4$str$funtoString$classDiscoveryState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$6$str$fun-toString$class-DiscoveryState", offset = -2)
    /* JADX INFO: renamed from: String$6$str$fun-toString$class-DiscoveryState, reason: not valid java name */
    public final String m6280String$6$str$funtoString$classDiscoveryState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f646String$6$str$funtoString$classDiscoveryState;
        }
        State<String> stateLiveLiteral = f631State$String$6$str$funtoString$classDiscoveryState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$6$str$fun-toString$class-DiscoveryState", f646String$6$str$funtoString$classDiscoveryState);
            f631State$String$6$str$funtoString$classDiscoveryState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$7$str$fun-toString$class-DiscoveryState", offset = -2)
    /* JADX INFO: renamed from: String$7$str$fun-toString$class-DiscoveryState, reason: not valid java name */
    public final String m6281String$7$str$funtoString$classDiscoveryState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f647String$7$str$funtoString$classDiscoveryState;
        }
        State<String> stateLiveLiteral = f632State$String$7$str$funtoString$classDiscoveryState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$7$str$fun-toString$class-DiscoveryState", f647String$7$str$funtoString$classDiscoveryState);
            f632State$String$7$str$funtoString$classDiscoveryState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$9$str$fun-toString$class-DiscoveryState", offset = -2)
    /* JADX INFO: renamed from: String$9$str$fun-toString$class-DiscoveryState, reason: not valid java name */
    public final String m6282String$9$str$funtoString$classDiscoveryState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f648String$9$str$funtoString$classDiscoveryState;
        }
        State<String> stateLiveLiteral = f633State$String$9$str$funtoString$classDiscoveryState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$9$str$fun-toString$class-DiscoveryState", f648String$9$str$funtoString$classDiscoveryState);
            f633State$String$9$str$funtoString$classDiscoveryState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-2$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized$catch$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", offset = 4147)
    /* JADX INFO: renamed from: String$arg-2$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized$catch$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    public final String m6283String$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized$catch$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f649String$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized$catch$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        }
        State<String> stateLiveLiteral = f634State$String$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized$catch$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-2$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized$catch$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", f649String$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized$catch$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery);
            f634State$String$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized$catch$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-2$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized-1$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", offset = 3576)
    /* JADX INFO: renamed from: String$arg-2$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized-1$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    public final String m6284String$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f650String$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        }
        State<String> stateLiveLiteral = f635State$String$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-2$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized-1$body$loop-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", f650String$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery);
            f635State$String$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-2$call-$init$$arg-0$call-$set-value$$branch$if$fun-search$class-CarDiscovery", offset = 1126)
    /* JADX INFO: renamed from: String$arg-2$call-$init$$arg-0$call-$set-value$$branch$if$fun-search$class-CarDiscovery, reason: not valid java name */
    public final String m6285String$arg2$call$init$$arg0$call$setvalue$$branch$if$funsearch$classCarDiscovery() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f651String$arg2$call$init$$arg0$call$setvalue$$branch$if$funsearch$classCarDiscovery;
        }
        State<String> stateLiveLiteral = f636State$String$arg2$call$init$$arg0$call$setvalue$$branch$if$funsearch$classCarDiscovery;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-2$call-$init$$arg-0$call-$set-value$$branch$if$fun-search$class-CarDiscovery", f651String$arg2$call$init$$arg0$call$setvalue$$branch$if$funsearch$classCarDiscovery);
            f636State$String$arg2$call$init$$arg0$call$setvalue$$branch$if$funsearch$classCarDiscovery = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-2$call-$init$$arg-0$call-$set-value$$fun-search$class-CarDiscovery", offset = 1273)
    /* JADX INFO: renamed from: String$arg-2$call-$init$$arg-0$call-$set-value$$fun-search$class-CarDiscovery, reason: not valid java name */
    public final String m6286String$arg2$call$init$$arg0$call$setvalue$$funsearch$classCarDiscovery() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f652String$arg2$call$init$$arg0$call$setvalue$$funsearch$classCarDiscovery;
        }
        State<String> stateLiveLiteral = f637State$String$arg2$call$init$$arg0$call$setvalue$$funsearch$classCarDiscovery;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-2$call-$init$$arg-0$call-$set-value$$fun-search$class-CarDiscovery", f652String$arg2$call$init$$arg0$call$setvalue$$funsearch$classCarDiscovery);
            f637State$String$arg2$call$init$$arg0$call$setvalue$$funsearch$classCarDiscovery = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$branch$if$arg-2$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", offset = 3847)
    /* JADX INFO: renamed from: String$branch$if$arg-2$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    public final String m6287String$branch$if$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f653String$branch$if$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        }
        State<String> stateLiveLiteral = f638State$String$branch$if$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$branch$if$arg-2$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", f653String$branch$if$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery);
            f638State$String$branch$if$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$else$if$arg-2$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", offset = 3902)
    /* JADX INFO: renamed from: String$else$if$arg-2$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery, reason: not valid java name */
    public final String m6288String$else$if$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f654String$else$if$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        }
        State<String> stateLiveLiteral = f639State$String$else$if$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$else$if$arg-2$call-$init$$arg-0$call-$set-value$$branch$if$fun-$anonymous$$arg-1$call-synchronized-1$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-search$class-CarDiscovery", f654String$else$if$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery);
            f639State$String$else$if$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$param-message$class-DiscoveryState", offset = 541)
    /* JADX INFO: renamed from: String$param-message$class-DiscoveryState, reason: not valid java name */
    public final String m6289String$parammessage$classDiscoveryState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f655String$parammessage$classDiscoveryState;
        }
        State<String> stateLiveLiteral = f640State$String$parammessage$classDiscoveryState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$param-message$class-DiscoveryState", f655String$parammessage$classDiscoveryState);
            f640State$String$parammessage$classDiscoveryState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
