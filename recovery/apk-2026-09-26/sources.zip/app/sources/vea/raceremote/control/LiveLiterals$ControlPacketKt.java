package vea.raceremote.control;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: ControlPacket.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/control/ControlPacket.kt")
public final class LiveLiterals$ControlPacketKt {

    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-ControlPacket, reason: not valid java name */
    private static boolean f735Boolean$branch$when1$funequals$classControlPacket;

    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-ControlPacket, reason: not valid java name */
    private static boolean f736Boolean$branch$when2$funequals$classControlPacket;

    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-ControlPacket, reason: not valid java name */
    private static boolean f737Boolean$branch$when3$funequals$classControlPacket;

    /* JADX INFO: renamed from: Boolean$branch$when-4$fun-equals$class-ControlPacket, reason: not valid java name */
    private static boolean f738Boolean$branch$when4$funequals$classControlPacket;

    /* JADX INFO: renamed from: Boolean$branch$when-5$fun-equals$class-ControlPacket, reason: not valid java name */
    private static boolean f739Boolean$branch$when5$funequals$classControlPacket;

    /* JADX INFO: renamed from: Boolean$branch$when-6$fun-equals$class-ControlPacket, reason: not valid java name */
    private static boolean f740Boolean$branch$when6$funequals$classControlPacket;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$$this$call-fold$fun-u32$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static int f747Int$$this$callrangeTo$$$this$callfold$funu32$fundecode$classCompanion$classControlPacket;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require-1$fun-encode$class-ControlPacket, reason: not valid java name */
    private static int f748Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classControlPacket;

    /* JADX INFO: renamed from: Int$arg-0$call-set$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static int f771Int$arg0$callset$fun$anonymous$$arg0$callalso$funencode$classControlPacket;

    /* JADX INFO: renamed from: Int$class-ControlPacket, reason: not valid java name */
    private static int f788Int$classControlPacket;

    /* JADX INFO: renamed from: Int$param-steering$class-ControlPacket, reason: not valid java name */
    private static int f789Int$paramsteering$classControlPacket;

    /* JADX INFO: renamed from: Int$param-throttle$class-ControlPacket, reason: not valid java name */
    private static int f790Int$paramthrottle$classControlPacket;

    /* JADX INFO: renamed from: Long$arg-0$call-fold$fun-u32$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static long f792Long$arg0$callfold$funu32$fundecode$classCompanion$classControlPacket;

    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$$this$call-not$branch$cond$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static long f795Long$arg1$callEQEQ$$this$callnot$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket;

    /* JADX INFO: renamed from: State$Boolean$branch$when$fun-equals$class-ControlPacket, reason: not valid java name */
    private static State<Boolean> f796State$Boolean$branch$when$funequals$classControlPacket;

    /* JADX INFO: renamed from: State$Boolean$branch$when-1$fun-equals$class-ControlPacket, reason: not valid java name */
    private static State<Boolean> f797State$Boolean$branch$when1$funequals$classControlPacket;

    /* JADX INFO: renamed from: State$Boolean$branch$when-2$fun-equals$class-ControlPacket, reason: not valid java name */
    private static State<Boolean> f798State$Boolean$branch$when2$funequals$classControlPacket;

    /* JADX INFO: renamed from: State$Boolean$branch$when-3$fun-equals$class-ControlPacket, reason: not valid java name */
    private static State<Boolean> f799State$Boolean$branch$when3$funequals$classControlPacket;

    /* JADX INFO: renamed from: State$Boolean$branch$when-4$fun-equals$class-ControlPacket, reason: not valid java name */
    private static State<Boolean> f800State$Boolean$branch$when4$funequals$classControlPacket;

    /* JADX INFO: renamed from: State$Boolean$branch$when-5$fun-equals$class-ControlPacket, reason: not valid java name */
    private static State<Boolean> f801State$Boolean$branch$when5$funequals$classControlPacket;

    /* JADX INFO: renamed from: State$Boolean$branch$when-6$fun-equals$class-ControlPacket, reason: not valid java name */
    private static State<Boolean> f802State$Boolean$branch$when6$funequals$classControlPacket;

    /* JADX INFO: renamed from: State$Boolean$fun-equals$class-ControlPacket, reason: not valid java name */
    private static State<Boolean> f803State$Boolean$funequals$classControlPacket;

    /* JADX INFO: renamed from: State$Byte$arg-1$call-set$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Byte> f804State$Byte$arg1$callset$fun$anonymous$$arg0$callalso$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Byte$arg-1$call-set-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Byte> f805State$Byte$arg1$callset1$fun$anonymous$$arg0$callalso$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Byte$arg-1$call-set-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Byte> f806State$Byte$arg1$callset2$fun$anonymous$$arg0$callalso$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-plus$arg-0$call-set$body$loop$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f807State$Int$$this$callplus$arg0$callset$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-plus$arg-0$call-set-1$body$loop$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f808State$Int$$this$callplus$arg0$callset1$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$$this$call-fold$fun-u32$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f809State$Int$$this$callrangeTo$$$this$callfold$funu32$fundecode$classCompanion$classControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require-1$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f810State$Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require-2$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f811State$Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire2$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$branch$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f812State$Int$$this$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f813State$Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$cond$arg-0$call-require-1$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f814State$Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire1$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$cond$arg-0$call-require-2$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f815State$Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire2$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-times$arg-0$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-u32$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f816State$Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funu32$fundecode$classCompanion$classControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-times$arg-0$call-shr$$this$call-toByte$arg-1$call-set$body$loop$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f817State$Int$$this$calltimes$arg0$callshr$$this$calltoByte$arg1$callset$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-times$arg-0$call-shr$$this$call-toByte$arg-1$call-set-1$body$loop$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f818State$Int$$this$calltimes$arg0$callshr$$this$calltoByte$arg1$callset1$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f819State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-$init$$$$this$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f820State$Int$arg0$call$init$$$$this$callalso$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-and$$this$call-or$$this$call-toShort$$this$call-toInt$fun-i16$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f821State$Int$arg0$calland$$this$callor$$this$calltoShort$$this$calltoInt$funi16$fundecode$classCompanion$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-and$arg-0$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f822State$Int$arg0$calland$arg0$call$init$$valp$fundecode$classCompanion$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-get$$this$call-toInt$$this$call-and$arg-0$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f823State$Int$arg0$callget$$this$calltoInt$$this$calland$arg0$call$init$$valp$fundecode$classCompanion$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f824State$Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-i16$arg-3$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f825State$Int$arg0$calli16$arg3$call$init$$valp$fundecode$classCompanion$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-i16$arg-4$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f826State$Int$arg0$calli16$arg4$call$init$$valp$fundecode$classCompanion$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-plus$arg-0$call-get$$this$call-toInt$$this$call-shl$arg-0$call-or$$this$call-toShort$$this$call-toInt$fun-i16$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f827State$Int$arg0$callplus$arg0$callget$$this$calltoInt$$this$callshl$arg0$callor$$this$calltoShort$$this$calltoInt$funi16$fundecode$classCompanion$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rangeTo$$$this$call-fold$fun-u32$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f828State$Int$arg0$callrangeTo$$$this$callfold$funu32$fundecode$classCompanion$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require-2$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f829State$Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire2$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rangeTo$$this$call-contains$branch$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f830State$Int$arg0$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f831State$Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rangeTo$$this$call-contains$cond$arg-0$call-require-2$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f832State$Int$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire2$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-set$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f833State$Int$arg0$callset$fun$anonymous$$arg0$callalso$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-set-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f834State$Int$arg0$callset1$fun$anonymous$$arg0$callalso$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-set-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f835State$Int$arg0$callset2$fun$anonymous$$arg0$callalso$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-set-3$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f836State$Int$arg0$callset3$fun$anonymous$$arg0$callalso$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-set-4$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f837State$Int$arg0$callset4$fun$anonymous$$arg0$callalso$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-set-5$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f838State$Int$arg0$callset5$fun$anonymous$$arg0$callalso$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-set-6$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f839State$Int$arg0$callset6$fun$anonymous$$arg0$callalso$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-set-7$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f840State$Int$arg0$callset7$fun$anonymous$$arg0$callalso$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-shl$arg-0$call-or$$this$call-toShort$$this$call-toInt$fun-i16$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f841State$Int$arg0$callshl$arg0$callor$$this$calltoShort$$this$calltoInt$funi16$fundecode$classCompanion$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-shr$$this$call-toByte$arg-1$call-set-5$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f842State$Int$arg0$callshr$$this$calltoByte$arg1$callset5$fun$anonymous$$arg0$callalso$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-shr$$this$call-toByte$arg-1$call-set-7$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f843State$Int$arg0$callshr$$this$calltoByte$arg1$callset7$fun$anonymous$$arg0$callalso$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f844State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f845State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-2$fun-hashCode$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f846State$Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-3$fun-hashCode$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f847State$Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-u32$arg-1$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f848State$Int$arg0$callu32$arg1$call$init$$valp$fundecode$classCompanion$classControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-u32$arg-2$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f849State$Int$arg0$callu32$arg2$call$init$$valp$fundecode$classCompanion$classControlPacket;

    /* JADX INFO: renamed from: State$Int$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f850State$Int$classControlPacket;

    /* JADX INFO: renamed from: State$Int$param-steering$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f851State$Int$paramsteering$classControlPacket;

    /* JADX INFO: renamed from: State$Int$param-throttle$class-ControlPacket, reason: not valid java name */
    private static State<Integer> f852State$Int$paramthrottle$classControlPacket;

    /* JADX INFO: renamed from: State$Long$arg-0$call-and$$this$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-u32$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static State<Long> f853State$Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funu32$fundecode$classCompanion$classControlPacket;

    /* JADX INFO: renamed from: State$Long$arg-0$call-fold$fun-u32$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static State<Long> f854State$Long$arg0$callfold$funu32$fundecode$classCompanion$classControlPacket;

    /* JADX INFO: renamed from: State$Long$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require-1$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Long> f855State$Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Long$arg-0$call-rangeTo$$this$call-contains$cond$arg-0$call-require-1$fun-encode$class-ControlPacket, reason: not valid java name */
    private static State<Long> f856State$Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire1$funencode$classControlPacket;

    /* JADX INFO: renamed from: State$Long$arg-1$call-EQEQ$$this$call-not$branch$cond$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static State<Long> f857State$Long$arg1$callEQEQ$$this$callnot$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket;

    /* JADX INFO: renamed from: State$String$0$str$fun-toString$class-ControlPacket, reason: not valid java name */
    private static State<String> f858State$String$0$str$funtoString$classControlPacket;

    /* JADX INFO: renamed from: State$String$1$str$fun-toString$class-ControlPacket, reason: not valid java name */
    private static State<String> f859State$String$1$str$funtoString$classControlPacket;

    /* JADX INFO: renamed from: State$String$10$str$fun-toString$class-ControlPacket, reason: not valid java name */
    private static State<String> f860State$String$10$str$funtoString$classControlPacket;

    /* JADX INFO: renamed from: State$String$12$str$fun-toString$class-ControlPacket, reason: not valid java name */
    private static State<String> f861State$String$12$str$funtoString$classControlPacket;

    /* JADX INFO: renamed from: State$String$13$str$fun-toString$class-ControlPacket, reason: not valid java name */
    private static State<String> f862State$String$13$str$funtoString$classControlPacket;

    /* JADX INFO: renamed from: State$String$15$str$fun-toString$class-ControlPacket, reason: not valid java name */
    private static State<String> f863State$String$15$str$funtoString$classControlPacket;

    /* JADX INFO: renamed from: State$String$3$str$fun-toString$class-ControlPacket, reason: not valid java name */
    private static State<String> f864State$String$3$str$funtoString$classControlPacket;

    /* JADX INFO: renamed from: State$String$4$str$fun-toString$class-ControlPacket, reason: not valid java name */
    private static State<String> f865State$String$4$str$funtoString$classControlPacket;

    /* JADX INFO: renamed from: State$String$6$str$fun-toString$class-ControlPacket, reason: not valid java name */
    private static State<String> f866State$String$6$str$funtoString$classControlPacket;

    /* JADX INFO: renamed from: State$String$7$str$fun-toString$class-ControlPacket, reason: not valid java name */
    private static State<String> f867State$String$7$str$funtoString$classControlPacket;

    /* JADX INFO: renamed from: State$String$9$str$fun-toString$class-ControlPacket, reason: not valid java name */
    private static State<String> f868State$String$9$str$funtoString$classControlPacket;
    public static final LiveLiterals$ControlPacketKt INSTANCE = new LiveLiterals$ControlPacketKt();

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$cond$arg-0$call-require-1$fun-encode$class-ControlPacket, reason: not valid java name */
    private static int f752Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire1$funencode$classControlPacket = 1;

    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$cond$arg-0$call-require-1$fun-encode$class-ControlPacket, reason: not valid java name */
    private static long f794Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire1$funencode$classControlPacket = 4294967295L;

    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require-1$fun-encode$class-ControlPacket, reason: not valid java name */
    private static long f793Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classControlPacket = 4294967295L;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$cond$arg-0$call-require-2$fun-encode$class-ControlPacket, reason: not valid java name */
    private static int f753Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire2$funencode$classControlPacket = -1000;

    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$cond$arg-0$call-require-2$fun-encode$class-ControlPacket, reason: not valid java name */
    private static int f770Int$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire2$funencode$classControlPacket = 1000;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require-2$fun-encode$class-ControlPacket, reason: not valid java name */
    private static int f749Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire2$funencode$classControlPacket = -1000;

    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require-2$fun-encode$class-ControlPacket, reason: not valid java name */
    private static int f767Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire2$funencode$classControlPacket = 1000;

    /* JADX INFO: renamed from: Int$arg-0$call-$init$$$$this$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static int f758Int$arg0$call$init$$$$this$callalso$funencode$classControlPacket = 16;

    /* JADX INFO: renamed from: Byte$arg-1$call-set$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static byte f742Byte$arg1$callset$fun$anonymous$$arg0$callalso$funencode$classControlPacket = 82;

    /* JADX INFO: renamed from: Int$arg-0$call-set-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static int f772Int$arg0$callset1$fun$anonymous$$arg0$callalso$funencode$classControlPacket = 1;

    /* JADX INFO: renamed from: Byte$arg-1$call-set-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static byte f743Byte$arg1$callset1$fun$anonymous$$arg0$callalso$funencode$classControlPacket = 67;

    /* JADX INFO: renamed from: Int$arg-0$call-set-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static int f773Int$arg0$callset2$fun$anonymous$$arg0$callalso$funencode$classControlPacket = 2;

    /* JADX INFO: renamed from: Byte$arg-1$call-set-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static byte f744Byte$arg1$callset2$fun$anonymous$$arg0$callalso$funencode$classControlPacket = 1;

    /* JADX INFO: renamed from: Int$arg-0$call-set-3$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static int f774Int$arg0$callset3$fun$anonymous$$arg0$callalso$funencode$classControlPacket = 3;

    /* JADX INFO: renamed from: Int$$this$call-plus$arg-0$call-set$body$loop$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static int f745Int$$this$callplus$arg0$callset$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket = 4;

    /* JADX INFO: renamed from: Int$$this$call-times$arg-0$call-shr$$this$call-toByte$arg-1$call-set$body$loop$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static int f755Int$$this$calltimes$arg0$callshr$$this$calltoByte$arg1$callset$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket = 8;

    /* JADX INFO: renamed from: Int$$this$call-plus$arg-0$call-set-1$body$loop$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static int f746Int$$this$callplus$arg0$callset1$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket = 8;

    /* JADX INFO: renamed from: Int$$this$call-times$arg-0$call-shr$$this$call-toByte$arg-1$call-set-1$body$loop$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static int f756Int$$this$calltimes$arg0$callshr$$this$calltoByte$arg1$callset1$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket = 8;

    /* JADX INFO: renamed from: Int$arg-0$call-set-4$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static int f775Int$arg0$callset4$fun$anonymous$$arg0$callalso$funencode$classControlPacket = 12;

    /* JADX INFO: renamed from: Int$arg-0$call-set-5$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static int f776Int$arg0$callset5$fun$anonymous$$arg0$callalso$funencode$classControlPacket = 13;

    /* JADX INFO: renamed from: Int$arg-0$call-shr$$this$call-toByte$arg-1$call-set-5$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static int f780Int$arg0$callshr$$this$calltoByte$arg1$callset5$fun$anonymous$$arg0$callalso$funencode$classControlPacket = 8;

    /* JADX INFO: renamed from: Int$arg-0$call-set-6$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static int f777Int$arg0$callset6$fun$anonymous$$arg0$callalso$funencode$classControlPacket = 14;

    /* JADX INFO: renamed from: Int$arg-0$call-set-7$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static int f778Int$arg0$callset7$fun$anonymous$$arg0$callalso$funencode$classControlPacket = 15;

    /* JADX INFO: renamed from: Int$arg-0$call-shr$$this$call-toByte$arg-1$call-set-7$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    private static int f781Int$arg0$callshr$$this$calltoByte$arg1$callset7$fun$anonymous$$arg0$callalso$funencode$classControlPacket = 8;

    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static int f762Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classControlPacket = 2;

    /* JADX INFO: renamed from: Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static int f757Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classControlPacket = 1;

    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$$this$call-fold$fun-u32$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static int f766Int$arg0$callrangeTo$$$this$callfold$funu32$fundecode$classCompanion$classControlPacket = 3;

    /* JADX INFO: renamed from: Long$arg-0$call-and$$this$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-u32$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static long f791Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funu32$fundecode$classCompanion$classControlPacket = 255;

    /* JADX INFO: renamed from: Int$$this$call-times$arg-0$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-u32$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static int f754Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funu32$fundecode$classCompanion$classControlPacket = 8;

    /* JADX INFO: renamed from: Int$arg-0$call-and$$this$call-or$$this$call-toShort$$this$call-toInt$fun-i16$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static int f759Int$arg0$calland$$this$callor$$this$calltoShort$$this$calltoInt$funi16$fundecode$classCompanion$classControlPacket = 255;

    /* JADX INFO: renamed from: Int$arg-0$call-plus$arg-0$call-get$$this$call-toInt$$this$call-shl$arg-0$call-or$$this$call-toShort$$this$call-toInt$fun-i16$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static int f765Int$arg0$callplus$arg0$callget$$this$calltoInt$$this$callshl$arg0$callor$$this$calltoShort$$this$calltoInt$funi16$fundecode$classCompanion$classControlPacket = 1;

    /* JADX INFO: renamed from: Int$arg-0$call-shl$arg-0$call-or$$this$call-toShort$$this$call-toInt$fun-i16$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static int f779Int$arg0$callshl$arg0$callor$$this$calltoShort$$this$calltoInt$funi16$fundecode$classCompanion$classControlPacket = 8;

    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toInt$$this$call-and$arg-0$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static int f761Int$arg0$callget$$this$calltoInt$$this$calland$arg0$call$init$$valp$fundecode$classCompanion$classControlPacket = 3;

    /* JADX INFO: renamed from: Int$arg-0$call-and$arg-0$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static int f760Int$arg0$calland$arg0$call$init$$valp$fundecode$classCompanion$classControlPacket = 255;

    /* JADX INFO: renamed from: Int$arg-0$call-u32$arg-1$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static int f786Int$arg0$callu32$arg1$call$init$$valp$fundecode$classCompanion$classControlPacket = 4;

    /* JADX INFO: renamed from: Int$arg-0$call-u32$arg-2$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static int f787Int$arg0$callu32$arg2$call$init$$valp$fundecode$classCompanion$classControlPacket = 8;

    /* JADX INFO: renamed from: Int$arg-0$call-i16$arg-3$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static int f763Int$arg0$calli16$arg3$call$init$$valp$fundecode$classCompanion$classControlPacket = 12;

    /* JADX INFO: renamed from: Int$arg-0$call-i16$arg-4$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static int f764Int$arg0$calli16$arg4$call$init$$valp$fundecode$classCompanion$classControlPacket = 14;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static int f750Int$$this$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket = -1000;

    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static int f768Int$arg0$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket = 1000;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static int f751Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket = -1000;

    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    private static int f769Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket = 1000;

    /* JADX INFO: renamed from: String$0$str$fun-toString$class-ControlPacket, reason: not valid java name */
    private static String f869String$0$str$funtoString$classControlPacket = "ControlPacket(";

    /* JADX INFO: renamed from: String$1$str$fun-toString$class-ControlPacket, reason: not valid java name */
    private static String f870String$1$str$funtoString$classControlPacket = "kind=";

    /* JADX INFO: renamed from: String$3$str$fun-toString$class-ControlPacket, reason: not valid java name */
    private static String f875String$3$str$funtoString$classControlPacket = ", ";

    /* JADX INFO: renamed from: String$4$str$fun-toString$class-ControlPacket, reason: not valid java name */
    private static String f876String$4$str$funtoString$classControlPacket = "token=";

    /* JADX INFO: renamed from: String$6$str$fun-toString$class-ControlPacket, reason: not valid java name */
    private static String f877String$6$str$funtoString$classControlPacket = ", ";

    /* JADX INFO: renamed from: String$7$str$fun-toString$class-ControlPacket, reason: not valid java name */
    private static String f878String$7$str$funtoString$classControlPacket = "sequence=";

    /* JADX INFO: renamed from: String$9$str$fun-toString$class-ControlPacket, reason: not valid java name */
    private static String f879String$9$str$funtoString$classControlPacket = ", ";

    /* JADX INFO: renamed from: String$10$str$fun-toString$class-ControlPacket, reason: not valid java name */
    private static String f871String$10$str$funtoString$classControlPacket = "throttle=";

    /* JADX INFO: renamed from: String$12$str$fun-toString$class-ControlPacket, reason: not valid java name */
    private static String f872String$12$str$funtoString$classControlPacket = ", ";

    /* JADX INFO: renamed from: String$13$str$fun-toString$class-ControlPacket, reason: not valid java name */
    private static String f873String$13$str$funtoString$classControlPacket = "steering=";

    /* JADX INFO: renamed from: String$15$str$fun-toString$class-ControlPacket, reason: not valid java name */
    private static String f874String$15$str$funtoString$classControlPacket = ")";

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-ControlPacket, reason: not valid java name */
    private static int f782Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classControlPacket = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-ControlPacket, reason: not valid java name */
    private static int f783Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classControlPacket = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-2$fun-hashCode$class-ControlPacket, reason: not valid java name */
    private static int f784Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classControlPacket = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-3$fun-hashCode$class-ControlPacket, reason: not valid java name */
    private static int f785Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classControlPacket = 31;

    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-ControlPacket, reason: not valid java name */
    private static boolean f734Boolean$branch$when$funequals$classControlPacket = true;

    /* JADX INFO: renamed from: Boolean$fun-equals$class-ControlPacket, reason: not valid java name */
    private static boolean f741Boolean$funequals$classControlPacket = true;

    @LiveLiteralInfo(key = "Boolean$branch$when$fun-equals$class-ControlPacket", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-ControlPacket, reason: not valid java name */
    public final boolean m6329Boolean$branch$when$funequals$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f734Boolean$branch$when$funequals$classControlPacket;
        }
        State<Boolean> stateLiveLiteral = f796State$Boolean$branch$when$funequals$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when$fun-equals$class-ControlPacket", Boolean.valueOf(f734Boolean$branch$when$funequals$classControlPacket));
            f796State$Boolean$branch$when$funequals$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-1$fun-equals$class-ControlPacket", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-ControlPacket, reason: not valid java name */
    public final boolean m6330Boolean$branch$when1$funequals$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f735Boolean$branch$when1$funequals$classControlPacket;
        }
        State<Boolean> stateLiveLiteral = f797State$Boolean$branch$when1$funequals$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-1$fun-equals$class-ControlPacket", Boolean.valueOf(f735Boolean$branch$when1$funequals$classControlPacket));
            f797State$Boolean$branch$when1$funequals$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-2$fun-equals$class-ControlPacket", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-ControlPacket, reason: not valid java name */
    public final boolean m6331Boolean$branch$when2$funequals$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f736Boolean$branch$when2$funequals$classControlPacket;
        }
        State<Boolean> stateLiveLiteral = f798State$Boolean$branch$when2$funequals$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-2$fun-equals$class-ControlPacket", Boolean.valueOf(f736Boolean$branch$when2$funequals$classControlPacket));
            f798State$Boolean$branch$when2$funequals$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-3$fun-equals$class-ControlPacket", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-ControlPacket, reason: not valid java name */
    public final boolean m6332Boolean$branch$when3$funequals$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f737Boolean$branch$when3$funequals$classControlPacket;
        }
        State<Boolean> stateLiveLiteral = f799State$Boolean$branch$when3$funequals$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-3$fun-equals$class-ControlPacket", Boolean.valueOf(f737Boolean$branch$when3$funequals$classControlPacket));
            f799State$Boolean$branch$when3$funequals$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-4$fun-equals$class-ControlPacket", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-4$fun-equals$class-ControlPacket, reason: not valid java name */
    public final boolean m6333Boolean$branch$when4$funequals$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f738Boolean$branch$when4$funequals$classControlPacket;
        }
        State<Boolean> stateLiveLiteral = f800State$Boolean$branch$when4$funequals$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-4$fun-equals$class-ControlPacket", Boolean.valueOf(f738Boolean$branch$when4$funequals$classControlPacket));
            f800State$Boolean$branch$when4$funequals$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-5$fun-equals$class-ControlPacket", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-5$fun-equals$class-ControlPacket, reason: not valid java name */
    public final boolean m6334Boolean$branch$when5$funequals$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f739Boolean$branch$when5$funequals$classControlPacket;
        }
        State<Boolean> stateLiveLiteral = f801State$Boolean$branch$when5$funequals$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-5$fun-equals$class-ControlPacket", Boolean.valueOf(f739Boolean$branch$when5$funequals$classControlPacket));
            f801State$Boolean$branch$when5$funequals$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-6$fun-equals$class-ControlPacket", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-6$fun-equals$class-ControlPacket, reason: not valid java name */
    public final boolean m6335Boolean$branch$when6$funequals$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f740Boolean$branch$when6$funequals$classControlPacket;
        }
        State<Boolean> stateLiveLiteral = f802State$Boolean$branch$when6$funequals$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-6$fun-equals$class-ControlPacket", Boolean.valueOf(f740Boolean$branch$when6$funequals$classControlPacket));
            f802State$Boolean$branch$when6$funequals$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$fun-equals$class-ControlPacket", offset = -2)
    /* JADX INFO: renamed from: Boolean$fun-equals$class-ControlPacket, reason: not valid java name */
    public final boolean m6336Boolean$funequals$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f741Boolean$funequals$classControlPacket;
        }
        State<Boolean> stateLiveLiteral = f803State$Boolean$funequals$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$fun-equals$class-ControlPacket", Boolean.valueOf(f741Boolean$funequals$classControlPacket));
            f803State$Boolean$funequals$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Byte$arg-1$call-set$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", offset = 549)
    /* JADX INFO: renamed from: Byte$arg-1$call-set$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    public final byte m6337Byte$arg1$callset$fun$anonymous$$arg0$callalso$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f742Byte$arg1$callset$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        }
        State<Byte> stateLiveLiteral = f804State$Byte$arg1$callset$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Byte$arg-1$call-set$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", Byte.valueOf(f742Byte$arg1$callset$fun$anonymous$$arg0$callalso$funencode$classControlPacket));
            f804State$Byte$arg1$callset$fun$anonymous$$arg0$callalso$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().byteValue();
    }

    @LiveLiteralInfo(key = "Byte$arg-1$call-set-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", offset = 560)
    /* JADX INFO: renamed from: Byte$arg-1$call-set-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    public final byte m6338Byte$arg1$callset1$fun$anonymous$$arg0$callalso$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f743Byte$arg1$callset1$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        }
        State<Byte> stateLiveLiteral = f805State$Byte$arg1$callset1$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Byte$arg-1$call-set-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", Byte.valueOf(f743Byte$arg1$callset1$fun$anonymous$$arg0$callalso$funencode$classControlPacket));
            f805State$Byte$arg1$callset1$fun$anonymous$$arg0$callalso$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().byteValue();
    }

    @LiveLiteralInfo(key = "Byte$arg-1$call-set-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", offset = 571)
    /* JADX INFO: renamed from: Byte$arg-1$call-set-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    public final byte m6339Byte$arg1$callset2$fun$anonymous$$arg0$callalso$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f744Byte$arg1$callset2$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        }
        State<Byte> stateLiveLiteral = f806State$Byte$arg1$callset2$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Byte$arg-1$call-set-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", Byte.valueOf(f744Byte$arg1$callset2$fun$anonymous$$arg0$callalso$funencode$classControlPacket));
            f806State$Byte$arg1$callset2$fun$anonymous$$arg0$callalso$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().byteValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-plus$arg-0$call-set$body$loop$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", offset = 643)
    /* JADX INFO: renamed from: Int$$this$call-plus$arg-0$call-set$body$loop$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    public final int m6340Int$$this$callplus$arg0$callset$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f745Int$$this$callplus$arg0$callset$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f807State$Int$$this$callplus$arg0$callset$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-plus$arg-0$call-set$body$loop$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", Integer.valueOf(f745Int$$this$callplus$arg0$callset$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket));
            f807State$Int$$this$callplus$arg0$callset$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-plus$arg-0$call-set-1$body$loop$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", offset = 699)
    /* JADX INFO: renamed from: Int$$this$call-plus$arg-0$call-set-1$body$loop$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    public final int m6341Int$$this$callplus$arg0$callset1$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f746Int$$this$callplus$arg0$callset1$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f808State$Int$$this$callplus$arg0$callset1$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-plus$arg-0$call-set-1$body$loop$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", Integer.valueOf(f746Int$$this$callplus$arg0$callset1$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket));
            f808State$Int$$this$callplus$arg0$callset1$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$$this$call-fold$fun-u32$fun-decode$class-Companion$class-ControlPacket", offset = 1276)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$$this$call-fold$fun-u32$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    public final int m6342Int$$this$callrangeTo$$$this$callfold$funu32$fundecode$classCompanion$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f747Int$$this$callrangeTo$$$this$callfold$funu32$fundecode$classCompanion$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f809State$Int$$this$callrangeTo$$$this$callfold$funu32$fundecode$classCompanion$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$$this$call-fold$fun-u32$fun-decode$class-Companion$class-ControlPacket", Integer.valueOf(f747Int$$this$callrangeTo$$$this$callfold$funu32$fundecode$classCompanion$classControlPacket));
            f809State$Int$$this$callrangeTo$$$this$callfold$funu32$fundecode$classCompanion$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require-1$fun-encode$class-ControlPacket", offset = 405)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require-1$fun-encode$class-ControlPacket, reason: not valid java name */
    public final int m6343Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f748Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f810State$Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require-1$fun-encode$class-ControlPacket", Integer.valueOf(f748Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classControlPacket));
            f810State$Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require-2$fun-encode$class-ControlPacket", offset = 476)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require-2$fun-encode$class-ControlPacket, reason: not valid java name */
    public final int m6344Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire2$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f749Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire2$funencode$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f811State$Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire2$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require-2$fun-encode$class-ControlPacket", Integer.valueOf(f749Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire2$funencode$classControlPacket));
            f811State$Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire2$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$branch$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-ControlPacket", offset = 1690)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    public final int m6345Int$$this$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f750Int$$this$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f812State$Int$$this$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$branch$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-ControlPacket", Integer.valueOf(f750Int$$this$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket));
            f812State$Int$$this$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-ControlPacket", offset = 1720)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    public final int m6346Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f751Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f813State$Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-ControlPacket", Integer.valueOf(f751Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket));
            f813State$Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$cond$arg-0$call-require-1$fun-encode$class-ControlPacket", offset = 375)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$cond$arg-0$call-require-1$fun-encode$class-ControlPacket, reason: not valid java name */
    public final int m6347Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire1$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f752Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire1$funencode$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f814State$Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire1$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$cond$arg-0$call-require-1$fun-encode$class-ControlPacket", Integer.valueOf(f752Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire1$funencode$classControlPacket));
            f814State$Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire1$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$cond$arg-0$call-require-2$fun-encode$class-ControlPacket", offset = 449)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$cond$arg-0$call-require-2$fun-encode$class-ControlPacket, reason: not valid java name */
    public final int m6348Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire2$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f753Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire2$funencode$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f815State$Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire2$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$cond$arg-0$call-require-2$fun-encode$class-ControlPacket", Integer.valueOf(f753Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire2$funencode$classControlPacket));
            f815State$Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire2$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-times$arg-0$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-u32$fun-decode$class-Companion$class-ControlPacket", offset = 1345)
    /* JADX INFO: renamed from: Int$$this$call-times$arg-0$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-u32$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    public final int m6349Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funu32$fundecode$classCompanion$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f754Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funu32$fundecode$classCompanion$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f816State$Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funu32$fundecode$classCompanion$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-times$arg-0$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-u32$fun-decode$class-Companion$class-ControlPacket", Integer.valueOf(f754Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funu32$fundecode$classCompanion$classControlPacket));
            f816State$Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funu32$fundecode$classCompanion$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-times$arg-0$call-shr$$this$call-toByte$arg-1$call-set$body$loop$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", offset = 664)
    /* JADX INFO: renamed from: Int$$this$call-times$arg-0$call-shr$$this$call-toByte$arg-1$call-set$body$loop$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    public final int m6350Int$$this$calltimes$arg0$callshr$$this$calltoByte$arg1$callset$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f755Int$$this$calltimes$arg0$callshr$$this$calltoByte$arg1$callset$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f817State$Int$$this$calltimes$arg0$callshr$$this$calltoByte$arg1$callset$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-times$arg-0$call-shr$$this$call-toByte$arg-1$call-set$body$loop$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", Integer.valueOf(f755Int$$this$calltimes$arg0$callshr$$this$calltoByte$arg1$callset$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket));
            f817State$Int$$this$calltimes$arg0$callshr$$this$calltoByte$arg1$callset$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-times$arg-0$call-shr$$this$call-toByte$arg-1$call-set-1$body$loop$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", offset = 723)
    /* JADX INFO: renamed from: Int$$this$call-times$arg-0$call-shr$$this$call-toByte$arg-1$call-set-1$body$loop$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    public final int m6351Int$$this$calltimes$arg0$callshr$$this$calltoByte$arg1$callset1$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f756Int$$this$calltimes$arg0$callshr$$this$calltoByte$arg1$callset1$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f818State$Int$$this$calltimes$arg0$callshr$$this$calltoByte$arg1$callset1$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-times$arg-0$call-shr$$this$call-toByte$arg-1$call-set-1$body$loop$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", Integer.valueOf(f756Int$$this$calltimes$arg0$callshr$$this$calltoByte$arg1$callset1$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket));
            f818State$Int$$this$calltimes$arg0$callshr$$this$calltoByte$arg1$callset1$body$loop$fun$anonymous$$arg0$callalso$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-Companion$class-ControlPacket", offset = 1216)
    /* JADX INFO: renamed from: Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    public final int m6352Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f757Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f819State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-Companion$class-ControlPacket", Integer.valueOf(f757Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classControlPacket));
            f819State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-$init$$$$this$call-also$fun-encode$class-ControlPacket", offset = 514)
    /* JADX INFO: renamed from: Int$arg-0$call-$init$$$$this$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    public final int m6353Int$arg0$call$init$$$$this$callalso$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f758Int$arg0$call$init$$$$this$callalso$funencode$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f820State$Int$arg0$call$init$$$$this$callalso$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-$init$$$$this$call-also$fun-encode$class-ControlPacket", Integer.valueOf(f758Int$arg0$call$init$$$$this$callalso$funencode$classControlPacket));
            f820State$Int$arg0$call$init$$$$this$callalso$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-and$$this$call-or$$this$call-toShort$$this$call-toInt$fun-i16$fun-decode$class-Companion$class-ControlPacket", offset = 1414)
    /* JADX INFO: renamed from: Int$arg-0$call-and$$this$call-or$$this$call-toShort$$this$call-toInt$fun-i16$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    public final int m6354Int$arg0$calland$$this$callor$$this$calltoShort$$this$calltoInt$funi16$fundecode$classCompanion$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f759Int$arg0$calland$$this$callor$$this$calltoShort$$this$calltoInt$funi16$fundecode$classCompanion$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f821State$Int$arg0$calland$$this$callor$$this$calltoShort$$this$calltoInt$funi16$fundecode$classCompanion$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-and$$this$call-or$$this$call-toShort$$this$call-toInt$fun-i16$fun-decode$class-Companion$class-ControlPacket", Integer.valueOf(f759Int$arg0$calland$$this$callor$$this$calltoShort$$this$calltoInt$funi16$fundecode$classCompanion$classControlPacket));
            f821State$Int$arg0$calland$$this$callor$$this$calltoShort$$this$calltoInt$funi16$fundecode$classCompanion$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-and$arg-0$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket", offset = 1522)
    /* JADX INFO: renamed from: Int$arg-0$call-and$arg-0$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    public final int m6355Int$arg0$calland$arg0$call$init$$valp$fundecode$classCompanion$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f760Int$arg0$calland$arg0$call$init$$valp$fundecode$classCompanion$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f822State$Int$arg0$calland$arg0$call$init$$valp$fundecode$classCompanion$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-and$arg-0$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket", Integer.valueOf(f760Int$arg0$calland$arg0$call$init$$valp$fundecode$classCompanion$classControlPacket));
            f822State$Int$arg0$calland$arg0$call$init$$valp$fundecode$classCompanion$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-get$$this$call-toInt$$this$call-and$arg-0$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket", offset = 1507)
    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toInt$$this$call-and$arg-0$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    public final int m6356Int$arg0$callget$$this$calltoInt$$this$calland$arg0$call$init$$valp$fundecode$classCompanion$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f761Int$arg0$callget$$this$calltoInt$$this$calland$arg0$call$init$$valp$fundecode$classCompanion$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f823State$Int$arg0$callget$$this$calltoInt$$this$calland$arg0$call$init$$valp$fundecode$classCompanion$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-get$$this$call-toInt$$this$call-and$arg-0$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket", Integer.valueOf(f761Int$arg0$callget$$this$calltoInt$$this$calland$arg0$call$init$$valp$fundecode$classCompanion$classControlPacket));
            f823State$Int$arg0$callget$$this$calltoInt$$this$calland$arg0$call$init$$valp$fundecode$classCompanion$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-Companion$class-ControlPacket", offset = 1210)
    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    public final int m6357Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f762Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f824State$Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-Companion$class-ControlPacket", Integer.valueOf(f762Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classControlPacket));
            f824State$Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-i16$arg-3$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket", offset = 1547)
    /* JADX INFO: renamed from: Int$arg-0$call-i16$arg-3$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    public final int m6358Int$arg0$calli16$arg3$call$init$$valp$fundecode$classCompanion$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f763Int$arg0$calli16$arg3$call$init$$valp$fundecode$classCompanion$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f825State$Int$arg0$calli16$arg3$call$init$$valp$fundecode$classCompanion$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-i16$arg-3$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket", Integer.valueOf(f763Int$arg0$calli16$arg3$call$init$$valp$fundecode$classCompanion$classControlPacket));
            f825State$Int$arg0$calli16$arg3$call$init$$valp$fundecode$classCompanion$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-i16$arg-4$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket", offset = 1556)
    /* JADX INFO: renamed from: Int$arg-0$call-i16$arg-4$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    public final int m6359Int$arg0$calli16$arg4$call$init$$valp$fundecode$classCompanion$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f764Int$arg0$calli16$arg4$call$init$$valp$fundecode$classCompanion$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f826State$Int$arg0$calli16$arg4$call$init$$valp$fundecode$classCompanion$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-i16$arg-4$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket", Integer.valueOf(f764Int$arg0$calli16$arg4$call$init$$valp$fundecode$classCompanion$classControlPacket));
            f826State$Int$arg0$calli16$arg4$call$init$$valp$fundecode$classCompanion$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-plus$arg-0$call-get$$this$call-toInt$$this$call-shl$arg-0$call-or$$this$call-toShort$$this$call-toInt$fun-i16$fun-decode$class-Companion$class-ControlPacket", offset = 1434)
    /* JADX INFO: renamed from: Int$arg-0$call-plus$arg-0$call-get$$this$call-toInt$$this$call-shl$arg-0$call-or$$this$call-toShort$$this$call-toInt$fun-i16$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    public final int m6360Int$arg0$callplus$arg0$callget$$this$calltoInt$$this$callshl$arg0$callor$$this$calltoShort$$this$calltoInt$funi16$fundecode$classCompanion$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f765Int$arg0$callplus$arg0$callget$$this$calltoInt$$this$callshl$arg0$callor$$this$calltoShort$$this$calltoInt$funi16$fundecode$classCompanion$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f827State$Int$arg0$callplus$arg0$callget$$this$calltoInt$$this$callshl$arg0$callor$$this$calltoShort$$this$calltoInt$funi16$fundecode$classCompanion$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-plus$arg-0$call-get$$this$call-toInt$$this$call-shl$arg-0$call-or$$this$call-toShort$$this$call-toInt$fun-i16$fun-decode$class-Companion$class-ControlPacket", Integer.valueOf(f765Int$arg0$callplus$arg0$callget$$this$calltoInt$$this$callshl$arg0$callor$$this$calltoShort$$this$calltoInt$funi16$fundecode$classCompanion$classControlPacket));
            f827State$Int$arg0$callplus$arg0$callget$$this$calltoInt$$this$callshl$arg0$callor$$this$calltoShort$$this$calltoInt$funi16$fundecode$classCompanion$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rangeTo$$$this$call-fold$fun-u32$fun-decode$class-Companion$class-ControlPacket", offset = 1279)
    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$$this$call-fold$fun-u32$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    public final int m6361Int$arg0$callrangeTo$$$this$callfold$funu32$fundecode$classCompanion$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f766Int$arg0$callrangeTo$$$this$callfold$funu32$fundecode$classCompanion$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f828State$Int$arg0$callrangeTo$$$this$callfold$funu32$fundecode$classCompanion$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rangeTo$$$this$call-fold$fun-u32$fun-decode$class-Companion$class-ControlPacket", Integer.valueOf(f766Int$arg0$callrangeTo$$$this$callfold$funu32$fundecode$classCompanion$classControlPacket));
            f828State$Int$arg0$callrangeTo$$$this$callfold$funu32$fundecode$classCompanion$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require-2$fun-encode$class-ControlPacket", offset = 483)
    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require-2$fun-encode$class-ControlPacket, reason: not valid java name */
    public final int m6362Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire2$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f767Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire2$funencode$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f829State$Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire2$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require-2$fun-encode$class-ControlPacket", Integer.valueOf(f767Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire2$funencode$classControlPacket));
            f829State$Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire2$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rangeTo$$this$call-contains$branch$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-ControlPacket", offset = 1697)
    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    public final int m6363Int$arg0$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f768Int$arg0$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f830State$Int$arg0$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rangeTo$$this$call-contains$branch$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-ControlPacket", Integer.valueOf(f768Int$arg0$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket));
            f830State$Int$arg0$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-ControlPacket", offset = 1727)
    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    public final int m6364Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f769Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f831State$Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-ControlPacket", Integer.valueOf(f769Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket));
            f831State$Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rangeTo$$this$call-contains$cond$arg-0$call-require-2$fun-encode$class-ControlPacket", offset = 456)
    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$cond$arg-0$call-require-2$fun-encode$class-ControlPacket, reason: not valid java name */
    public final int m6365Int$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire2$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f770Int$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire2$funencode$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f832State$Int$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire2$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rangeTo$$this$call-contains$cond$arg-0$call-require-2$fun-encode$class-ControlPacket", Integer.valueOf(f770Int$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire2$funencode$classControlPacket));
            f832State$Int$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire2$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-set$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", offset = 544)
    /* JADX INFO: renamed from: Int$arg-0$call-set$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    public final int m6366Int$arg0$callset$fun$anonymous$$arg0$callalso$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f771Int$arg0$callset$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f833State$Int$arg0$callset$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-set$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", Integer.valueOf(f771Int$arg0$callset$fun$anonymous$$arg0$callalso$funencode$classControlPacket));
            f833State$Int$arg0$callset$fun$anonymous$$arg0$callalso$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-set-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", offset = 555)
    /* JADX INFO: renamed from: Int$arg-0$call-set-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    public final int m6367Int$arg0$callset1$fun$anonymous$$arg0$callalso$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f772Int$arg0$callset1$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f834State$Int$arg0$callset1$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-set-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", Integer.valueOf(f772Int$arg0$callset1$fun$anonymous$$arg0$callalso$funencode$classControlPacket));
            f834State$Int$arg0$callset1$fun$anonymous$$arg0$callalso$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-set-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", offset = 566)
    /* JADX INFO: renamed from: Int$arg-0$call-set-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    public final int m6368Int$arg0$callset2$fun$anonymous$$arg0$callalso$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f773Int$arg0$callset2$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f835State$Int$arg0$callset2$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-set-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", Integer.valueOf(f773Int$arg0$callset2$fun$anonymous$$arg0$callalso$funencode$classControlPacket));
            f835State$Int$arg0$callset2$fun$anonymous$$arg0$callalso$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-set-3$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", offset = 576)
    /* JADX INFO: renamed from: Int$arg-0$call-set-3$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    public final int m6369Int$arg0$callset3$fun$anonymous$$arg0$callalso$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f774Int$arg0$callset3$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f836State$Int$arg0$callset3$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-set-3$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", Integer.valueOf(f774Int$arg0$callset3$fun$anonymous$$arg0$callalso$funencode$classControlPacket));
            f836State$Int$arg0$callset3$fun$anonymous$$arg0$callalso$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-set-4$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", offset = 768)
    /* JADX INFO: renamed from: Int$arg-0$call-set-4$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    public final int m6370Int$arg0$callset4$fun$anonymous$$arg0$callalso$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f775Int$arg0$callset4$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f837State$Int$arg0$callset4$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-set-4$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", Integer.valueOf(f775Int$arg0$callset4$fun$anonymous$$arg0$callalso$funencode$classControlPacket));
            f837State$Int$arg0$callset4$fun$anonymous$$arg0$callalso$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-set-5$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", offset = 795)
    /* JADX INFO: renamed from: Int$arg-0$call-set-5$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    public final int m6371Int$arg0$callset5$fun$anonymous$$arg0$callalso$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f776Int$arg0$callset5$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f838State$Int$arg0$callset5$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-set-5$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", Integer.valueOf(f776Int$arg0$callset5$fun$anonymous$$arg0$callalso$funencode$classControlPacket));
            f838State$Int$arg0$callset5$fun$anonymous$$arg0$callalso$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-set-6$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", offset = 841)
    /* JADX INFO: renamed from: Int$arg-0$call-set-6$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    public final int m6372Int$arg0$callset6$fun$anonymous$$arg0$callalso$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f777Int$arg0$callset6$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f839State$Int$arg0$callset6$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-set-6$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", Integer.valueOf(f777Int$arg0$callset6$fun$anonymous$$arg0$callalso$funencode$classControlPacket));
            f839State$Int$arg0$callset6$fun$anonymous$$arg0$callalso$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-set-7$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", offset = 868)
    /* JADX INFO: renamed from: Int$arg-0$call-set-7$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    public final int m6373Int$arg0$callset7$fun$anonymous$$arg0$callalso$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f778Int$arg0$callset7$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f840State$Int$arg0$callset7$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-set-7$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", Integer.valueOf(f778Int$arg0$callset7$fun$anonymous$$arg0$callalso$funencode$classControlPacket));
            f840State$Int$arg0$callset7$fun$anonymous$$arg0$callalso$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-shl$arg-0$call-or$$this$call-toShort$$this$call-toInt$fun-i16$fun-decode$class-Companion$class-ControlPacket", offset = 1449)
    /* JADX INFO: renamed from: Int$arg-0$call-shl$arg-0$call-or$$this$call-toShort$$this$call-toInt$fun-i16$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    public final int m6374Int$arg0$callshl$arg0$callor$$this$calltoShort$$this$calltoInt$funi16$fundecode$classCompanion$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f779Int$arg0$callshl$arg0$callor$$this$calltoShort$$this$calltoInt$funi16$fundecode$classCompanion$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f841State$Int$arg0$callshl$arg0$callor$$this$calltoShort$$this$calltoInt$funi16$fundecode$classCompanion$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-shl$arg-0$call-or$$this$call-toShort$$this$call-toInt$fun-i16$fun-decode$class-Companion$class-ControlPacket", Integer.valueOf(f779Int$arg0$callshl$arg0$callor$$this$calltoShort$$this$calltoInt$funi16$fundecode$classCompanion$classControlPacket));
            f841State$Int$arg0$callshl$arg0$callor$$this$calltoShort$$this$calltoInt$funi16$fundecode$classCompanion$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-shr$$this$call-toByte$arg-1$call-set-5$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", offset = 815)
    /* JADX INFO: renamed from: Int$arg-0$call-shr$$this$call-toByte$arg-1$call-set-5$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    public final int m6375Int$arg0$callshr$$this$calltoByte$arg1$callset5$fun$anonymous$$arg0$callalso$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f780Int$arg0$callshr$$this$calltoByte$arg1$callset5$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f842State$Int$arg0$callshr$$this$calltoByte$arg1$callset5$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-shr$$this$call-toByte$arg-1$call-set-5$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", Integer.valueOf(f780Int$arg0$callshr$$this$calltoByte$arg1$callset5$fun$anonymous$$arg0$callalso$funencode$classControlPacket));
            f842State$Int$arg0$callshr$$this$calltoByte$arg1$callset5$fun$anonymous$$arg0$callalso$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-shr$$this$call-toByte$arg-1$call-set-7$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", offset = 888)
    /* JADX INFO: renamed from: Int$arg-0$call-shr$$this$call-toByte$arg-1$call-set-7$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket, reason: not valid java name */
    public final int m6376Int$arg0$callshr$$this$calltoByte$arg1$callset7$fun$anonymous$$arg0$callalso$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f781Int$arg0$callshr$$this$calltoByte$arg1$callset7$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f843State$Int$arg0$callshr$$this$calltoByte$arg1$callset7$fun$anonymous$$arg0$callalso$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-shr$$this$call-toByte$arg-1$call-set-7$fun-$anonymous$$arg-0$call-also$fun-encode$class-ControlPacket", Integer.valueOf(f781Int$arg0$callshr$$this$calltoByte$arg1$callset7$fun$anonymous$$arg0$callalso$funencode$classControlPacket));
            f843State$Int$arg0$callshr$$this$calltoByte$arg1$callset7$fun$anonymous$$arg0$callalso$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-ControlPacket", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-ControlPacket, reason: not valid java name */
    public final int m6377Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f782Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f844State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-ControlPacket", Integer.valueOf(f782Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classControlPacket));
            f844State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-ControlPacket", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-ControlPacket, reason: not valid java name */
    public final int m6378Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f783Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f845State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-ControlPacket", Integer.valueOf(f783Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classControlPacket));
            f845State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-2$fun-hashCode$class-ControlPacket", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-2$fun-hashCode$class-ControlPacket, reason: not valid java name */
    public final int m6379Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f784Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f846State$Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-2$fun-hashCode$class-ControlPacket", Integer.valueOf(f784Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classControlPacket));
            f846State$Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-3$fun-hashCode$class-ControlPacket", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-3$fun-hashCode$class-ControlPacket, reason: not valid java name */
    public final int m6380Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f785Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f847State$Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-3$fun-hashCode$class-ControlPacket", Integer.valueOf(f785Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classControlPacket));
            f847State$Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-u32$arg-1$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket", offset = 1531)
    /* JADX INFO: renamed from: Int$arg-0$call-u32$arg-1$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    public final int m6381Int$arg0$callu32$arg1$call$init$$valp$fundecode$classCompanion$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f786Int$arg0$callu32$arg1$call$init$$valp$fundecode$classCompanion$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f848State$Int$arg0$callu32$arg1$call$init$$valp$fundecode$classCompanion$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-u32$arg-1$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket", Integer.valueOf(f786Int$arg0$callu32$arg1$call$init$$valp$fundecode$classCompanion$classControlPacket));
            f848State$Int$arg0$callu32$arg1$call$init$$valp$fundecode$classCompanion$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-u32$arg-2$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket", offset = 1539)
    /* JADX INFO: renamed from: Int$arg-0$call-u32$arg-2$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    public final int m6382Int$arg0$callu32$arg2$call$init$$valp$fundecode$classCompanion$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f787Int$arg0$callu32$arg2$call$init$$valp$fundecode$classCompanion$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f849State$Int$arg0$callu32$arg2$call$init$$valp$fundecode$classCompanion$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-u32$arg-2$call-$init$$val-p$fun-decode$class-Companion$class-ControlPacket", Integer.valueOf(f787Int$arg0$callu32$arg2$call$init$$valp$fundecode$classCompanion$classControlPacket));
            f849State$Int$arg0$callu32$arg2$call$init$$valp$fundecode$classCompanion$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-ControlPacket", offset = -1)
    /* JADX INFO: renamed from: Int$class-ControlPacket, reason: not valid java name */
    public final int m6383Int$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f788Int$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f850State$Int$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-ControlPacket", Integer.valueOf(f788Int$classControlPacket));
            f850State$Int$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$param-steering$class-ControlPacket", offset = 252)
    /* JADX INFO: renamed from: Int$param-steering$class-ControlPacket, reason: not valid java name */
    public final int m6384Int$paramsteering$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f789Int$paramsteering$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f851State$Int$paramsteering$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$param-steering$class-ControlPacket", Integer.valueOf(f789Int$paramsteering$classControlPacket));
            f851State$Int$paramsteering$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$param-throttle$class-ControlPacket", offset = 225)
    /* JADX INFO: renamed from: Int$param-throttle$class-ControlPacket, reason: not valid java name */
    public final int m6385Int$paramthrottle$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f790Int$paramthrottle$classControlPacket;
        }
        State<Integer> stateLiveLiteral = f852State$Int$paramthrottle$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$param-throttle$class-ControlPacket", Integer.valueOf(f790Int$paramthrottle$classControlPacket));
            f852State$Int$paramthrottle$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-and$$this$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-u32$fun-decode$class-Companion$class-ControlPacket", offset = 1335)
    /* JADX INFO: renamed from: Long$arg-0$call-and$$this$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-u32$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    public final long m6386Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funu32$fundecode$classCompanion$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f791Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funu32$fundecode$classCompanion$classControlPacket;
        }
        State<Long> stateLiveLiteral = f853State$Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funu32$fundecode$classCompanion$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-and$$this$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-u32$fun-decode$class-Companion$class-ControlPacket", Long.valueOf(f791Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funu32$fundecode$classCompanion$classControlPacket));
            f853State$Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funu32$fundecode$classCompanion$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-fold$fun-u32$fun-decode$class-Companion$class-ControlPacket", offset = 1287)
    /* JADX INFO: renamed from: Long$arg-0$call-fold$fun-u32$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    public final long m6387Long$arg0$callfold$funu32$fundecode$classCompanion$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f792Long$arg0$callfold$funu32$fundecode$classCompanion$classControlPacket;
        }
        State<Long> stateLiveLiteral = f854State$Long$arg0$callfold$funu32$fundecode$classCompanion$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-fold$fun-u32$fun-decode$class-Companion$class-ControlPacket", Long.valueOf(f792Long$arg0$callfold$funu32$fundecode$classCompanion$classControlPacket));
            f854State$Long$arg0$callfold$funu32$fundecode$classCompanion$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require-1$fun-encode$class-ControlPacket", offset = 408)
    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require-1$fun-encode$class-ControlPacket, reason: not valid java name */
    public final long m6388Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f793Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classControlPacket;
        }
        State<Long> stateLiveLiteral = f855State$Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require-1$fun-encode$class-ControlPacket", Long.valueOf(f793Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classControlPacket));
            f855State$Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-rangeTo$$this$call-contains$cond$arg-0$call-require-1$fun-encode$class-ControlPacket", offset = 378)
    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$cond$arg-0$call-require-1$fun-encode$class-ControlPacket, reason: not valid java name */
    public final long m6389Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire1$funencode$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f794Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire1$funencode$classControlPacket;
        }
        State<Long> stateLiveLiteral = f856State$Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire1$funencode$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-rangeTo$$this$call-contains$cond$arg-0$call-require-1$fun-encode$class-ControlPacket", Long.valueOf(f794Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire1$funencode$classControlPacket));
            f856State$Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire1$funencode$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-1$call-EQEQ$$this$call-not$branch$cond$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-ControlPacket", offset = 1653)
    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$$this$call-not$branch$cond$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-ControlPacket, reason: not valid java name */
    public final long m6390Long$arg1$callEQEQ$$this$callnot$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f795Long$arg1$callEQEQ$$this$callnot$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket;
        }
        State<Long> stateLiveLiteral = f857State$Long$arg1$callEQEQ$$this$callnot$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-1$call-EQEQ$$this$call-not$branch$cond$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-ControlPacket", Long.valueOf(f795Long$arg1$callEQEQ$$this$callnot$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket));
            f857State$Long$arg1$callEQEQ$$this$callnot$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "String$0$str$fun-toString$class-ControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$0$str$fun-toString$class-ControlPacket, reason: not valid java name */
    public final String m6391String$0$str$funtoString$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f869String$0$str$funtoString$classControlPacket;
        }
        State<String> stateLiveLiteral = f858State$String$0$str$funtoString$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$fun-toString$class-ControlPacket", f869String$0$str$funtoString$classControlPacket);
            f858State$String$0$str$funtoString$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$1$str$fun-toString$class-ControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$1$str$fun-toString$class-ControlPacket, reason: not valid java name */
    public final String m6392String$1$str$funtoString$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f870String$1$str$funtoString$classControlPacket;
        }
        State<String> stateLiveLiteral = f859State$String$1$str$funtoString$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$1$str$fun-toString$class-ControlPacket", f870String$1$str$funtoString$classControlPacket);
            f859State$String$1$str$funtoString$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$10$str$fun-toString$class-ControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$10$str$fun-toString$class-ControlPacket, reason: not valid java name */
    public final String m6393String$10$str$funtoString$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f871String$10$str$funtoString$classControlPacket;
        }
        State<String> stateLiveLiteral = f860State$String$10$str$funtoString$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$10$str$fun-toString$class-ControlPacket", f871String$10$str$funtoString$classControlPacket);
            f860State$String$10$str$funtoString$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$12$str$fun-toString$class-ControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$12$str$fun-toString$class-ControlPacket, reason: not valid java name */
    public final String m6394String$12$str$funtoString$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f872String$12$str$funtoString$classControlPacket;
        }
        State<String> stateLiveLiteral = f861State$String$12$str$funtoString$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$12$str$fun-toString$class-ControlPacket", f872String$12$str$funtoString$classControlPacket);
            f861State$String$12$str$funtoString$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$13$str$fun-toString$class-ControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$13$str$fun-toString$class-ControlPacket, reason: not valid java name */
    public final String m6395String$13$str$funtoString$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f873String$13$str$funtoString$classControlPacket;
        }
        State<String> stateLiveLiteral = f862State$String$13$str$funtoString$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$13$str$fun-toString$class-ControlPacket", f873String$13$str$funtoString$classControlPacket);
            f862State$String$13$str$funtoString$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$15$str$fun-toString$class-ControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$15$str$fun-toString$class-ControlPacket, reason: not valid java name */
    public final String m6396String$15$str$funtoString$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f874String$15$str$funtoString$classControlPacket;
        }
        State<String> stateLiveLiteral = f863State$String$15$str$funtoString$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$15$str$fun-toString$class-ControlPacket", f874String$15$str$funtoString$classControlPacket);
            f863State$String$15$str$funtoString$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$3$str$fun-toString$class-ControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$3$str$fun-toString$class-ControlPacket, reason: not valid java name */
    public final String m6397String$3$str$funtoString$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f875String$3$str$funtoString$classControlPacket;
        }
        State<String> stateLiveLiteral = f864State$String$3$str$funtoString$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$3$str$fun-toString$class-ControlPacket", f875String$3$str$funtoString$classControlPacket);
            f864State$String$3$str$funtoString$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$4$str$fun-toString$class-ControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$4$str$fun-toString$class-ControlPacket, reason: not valid java name */
    public final String m6398String$4$str$funtoString$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f876String$4$str$funtoString$classControlPacket;
        }
        State<String> stateLiveLiteral = f865State$String$4$str$funtoString$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$4$str$fun-toString$class-ControlPacket", f876String$4$str$funtoString$classControlPacket);
            f865State$String$4$str$funtoString$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$6$str$fun-toString$class-ControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$6$str$fun-toString$class-ControlPacket, reason: not valid java name */
    public final String m6399String$6$str$funtoString$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f877String$6$str$funtoString$classControlPacket;
        }
        State<String> stateLiveLiteral = f866State$String$6$str$funtoString$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$6$str$fun-toString$class-ControlPacket", f877String$6$str$funtoString$classControlPacket);
            f866State$String$6$str$funtoString$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$7$str$fun-toString$class-ControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$7$str$fun-toString$class-ControlPacket, reason: not valid java name */
    public final String m6400String$7$str$funtoString$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f878String$7$str$funtoString$classControlPacket;
        }
        State<String> stateLiveLiteral = f867State$String$7$str$funtoString$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$7$str$fun-toString$class-ControlPacket", f878String$7$str$funtoString$classControlPacket);
            f867State$String$7$str$funtoString$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$9$str$fun-toString$class-ControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$9$str$fun-toString$class-ControlPacket, reason: not valid java name */
    public final String m6401String$9$str$funtoString$classControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f879String$9$str$funtoString$classControlPacket;
        }
        State<String> stateLiveLiteral = f868State$String$9$str$funtoString$classControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$9$str$fun-toString$class-ControlPacket", f879String$9$str$funtoString$classControlPacket);
            f868State$String$9$str$funtoString$classControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
