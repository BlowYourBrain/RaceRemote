package vea.raceremote.control;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: ControlSocketFactory.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/control/ControlSocketFactory.kt")
public final class LiveLiterals$ControlSocketFactoryKt {

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-setTcpNoDelay$fun-$anonymous$$arg-0$call-apply$fun-immediate$class-ControlSocketFactory, reason: not valid java name */
    private static State<Boolean> f882State$Boolean$arg0$callsetTcpNoDelay$fun$anonymous$$arg0$callapply$funimmediate$classControlSocketFactory;

    /* JADX INFO: renamed from: State$Int$class-ControlSocketFactory, reason: not valid java name */
    private static State<Integer> f883State$Int$classControlSocketFactory;
    public static final LiveLiterals$ControlSocketFactoryKt INSTANCE = new LiveLiterals$ControlSocketFactoryKt();

    /* JADX INFO: renamed from: Boolean$arg-0$call-setTcpNoDelay$fun-$anonymous$$arg-0$call-apply$fun-immediate$class-ControlSocketFactory, reason: not valid java name */
    private static boolean f880Boolean$arg0$callsetTcpNoDelay$fun$anonymous$$arg0$callapply$funimmediate$classControlSocketFactory = true;

    /* JADX INFO: renamed from: Int$class-ControlSocketFactory, reason: not valid java name */
    private static int f881Int$classControlSocketFactory = 8;

    @LiveLiteralInfo(key = "Boolean$arg-0$call-setTcpNoDelay$fun-$anonymous$$arg-0$call-apply$fun-immediate$class-ControlSocketFactory", offset = 340)
    /* JADX INFO: renamed from: Boolean$arg-0$call-setTcpNoDelay$fun-$anonymous$$arg-0$call-apply$fun-immediate$class-ControlSocketFactory, reason: not valid java name */
    public final boolean m6402Boolean$arg0$callsetTcpNoDelay$fun$anonymous$$arg0$callapply$funimmediate$classControlSocketFactory() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f880Boolean$arg0$callsetTcpNoDelay$fun$anonymous$$arg0$callapply$funimmediate$classControlSocketFactory;
        }
        State<Boolean> stateLiveLiteral = f882State$Boolean$arg0$callsetTcpNoDelay$fun$anonymous$$arg0$callapply$funimmediate$classControlSocketFactory;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-setTcpNoDelay$fun-$anonymous$$arg-0$call-apply$fun-immediate$class-ControlSocketFactory", Boolean.valueOf(f880Boolean$arg0$callsetTcpNoDelay$fun$anonymous$$arg0$callapply$funimmediate$classControlSocketFactory));
            f882State$Boolean$arg0$callsetTcpNoDelay$fun$anonymous$$arg0$callapply$funimmediate$classControlSocketFactory = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Int$class-ControlSocketFactory", offset = -1)
    /* JADX INFO: renamed from: Int$class-ControlSocketFactory, reason: not valid java name */
    public final int m6403Int$classControlSocketFactory() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f881Int$classControlSocketFactory;
        }
        State<Integer> stateLiveLiteral = f883State$Int$classControlSocketFactory;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-ControlSocketFactory", Integer.valueOf(f881Int$classControlSocketFactory));
            f883State$Int$classControlSocketFactory = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }
}
