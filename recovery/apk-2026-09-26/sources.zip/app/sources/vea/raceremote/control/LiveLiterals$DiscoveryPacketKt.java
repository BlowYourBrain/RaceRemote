package vea.raceremote.control;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: DiscoveryPacket.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/control/DiscoveryPacket.kt")
public final class LiveLiterals$DiscoveryPacketKt {

    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-DiscoveredCar, reason: not valid java name */
    private static boolean f885Boolean$branch$when1$funequals$classDiscoveredCar;

    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-DiscoveredCar, reason: not valid java name */
    private static boolean f886Boolean$branch$when2$funequals$classDiscoveredCar;

    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-DiscoveredCar, reason: not valid java name */
    private static boolean f887Boolean$branch$when3$funequals$classDiscoveredCar;

    /* JADX INFO: renamed from: Boolean$branch$when-4$fun-equals$class-DiscoveredCar, reason: not valid java name */
    private static boolean f888Boolean$branch$when4$funequals$classDiscoveredCar;

    /* JADX INFO: renamed from: Boolean$branch$when-5$fun-equals$class-DiscoveredCar, reason: not valid java name */
    private static boolean f889Boolean$branch$when5$funequals$classDiscoveredCar;

    /* JADX INFO: renamed from: Boolean$branch$when-6$fun-equals$class-DiscoveredCar, reason: not valid java name */
    private static boolean f890Boolean$branch$when6$funequals$classDiscoveredCar;

    /* JADX INFO: renamed from: Boolean$branch$when-7$fun-equals$class-DiscoveredCar, reason: not valid java name */
    private static boolean f891Boolean$branch$when7$funequals$classDiscoveredCar;

    /* JADX INFO: renamed from: Byte$10$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static byte f895Byte$10$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: Byte$11$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static byte f896Byte$11$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: Byte$5$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static byte f899Byte$5$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: Byte$6$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static byte f900Byte$6$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: Byte$7$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static byte f901Byte$7$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: Byte$8$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static byte f902Byte$8$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: Byte$9$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static byte f903Byte$9$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: Int$$$this$call-until$$$this$call-fold$fun-number$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static int f904Int$$$this$calluntil$$$this$callfold$funnumber$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$$this$call-not$else$cond$if$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static int f911Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$branch$cond$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static int f913Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond$when$valtransport$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: Int$class-DiscoveredCar, reason: not valid java name */
    private static int f940Int$classDiscoveredCar;

    /* JADX INFO: renamed from: Int$class-DiscoveryPacket, reason: not valid java name */
    private static int f941Int$classDiscoveryPacket;

    /* JADX INFO: renamed from: Long$arg-0$call-fold$fun-number$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static long f945Long$arg0$callfold$funnumber$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Boolean$branch$when$fun-equals$class-DiscoveredCar, reason: not valid java name */
    private static State<Boolean> f948State$Boolean$branch$when$funequals$classDiscoveredCar;

    /* JADX INFO: renamed from: State$Boolean$branch$when-1$fun-equals$class-DiscoveredCar, reason: not valid java name */
    private static State<Boolean> f949State$Boolean$branch$when1$funequals$classDiscoveredCar;

    /* JADX INFO: renamed from: State$Boolean$branch$when-2$fun-equals$class-DiscoveredCar, reason: not valid java name */
    private static State<Boolean> f950State$Boolean$branch$when2$funequals$classDiscoveredCar;

    /* JADX INFO: renamed from: State$Boolean$branch$when-3$fun-equals$class-DiscoveredCar, reason: not valid java name */
    private static State<Boolean> f951State$Boolean$branch$when3$funequals$classDiscoveredCar;

    /* JADX INFO: renamed from: State$Boolean$branch$when-4$fun-equals$class-DiscoveredCar, reason: not valid java name */
    private static State<Boolean> f952State$Boolean$branch$when4$funequals$classDiscoveredCar;

    /* JADX INFO: renamed from: State$Boolean$branch$when-5$fun-equals$class-DiscoveredCar, reason: not valid java name */
    private static State<Boolean> f953State$Boolean$branch$when5$funequals$classDiscoveredCar;

    /* JADX INFO: renamed from: State$Boolean$branch$when-6$fun-equals$class-DiscoveredCar, reason: not valid java name */
    private static State<Boolean> f954State$Boolean$branch$when6$funequals$classDiscoveredCar;

    /* JADX INFO: renamed from: State$Boolean$branch$when-7$fun-equals$class-DiscoveredCar, reason: not valid java name */
    private static State<Boolean> f955State$Boolean$branch$when7$funequals$classDiscoveredCar;

    /* JADX INFO: renamed from: State$Boolean$fun-equals$class-DiscoveredCar, reason: not valid java name */
    private static State<Boolean> f956State$Boolean$funequals$classDiscoveredCar;

    /* JADX INFO: renamed from: State$Byte$0$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static State<Byte> f957State$Byte$0$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Byte$1$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static State<Byte> f958State$Byte$1$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Byte$10$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static State<Byte> f959State$Byte$10$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Byte$11$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static State<Byte> f960State$Byte$11$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Byte$2$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static State<Byte> f961State$Byte$2$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Byte$4$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static State<Byte> f962State$Byte$4$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Byte$5$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static State<Byte> f963State$Byte$5$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Byte$6$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static State<Byte> f964State$Byte$6$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Byte$7$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static State<Byte> f965State$Byte$7$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Byte$8$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static State<Byte> f966State$Byte$8$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Byte$9$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static State<Byte> f967State$Byte$9$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$$$this$call-until$$$this$call-fold$fun-number$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f968State$Int$$$this$calluntil$$$this$callfold$funnumber$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-plus$arg-0$call-set$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-0$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f969State$Int$$this$callplus$arg0$callset$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if-2$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f970State$Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if2$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f971State$Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$cond$arg-0$call-require$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f972State$Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-times$arg-0$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-number$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f973State$Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-times$arg-0$call-ushr$$this$call-toByte$arg-1$call-set$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-0$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f974State$Int$$this$calltimes$arg0$callushr$$this$calltoByte$arg1$callset$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$$this$call-not$else$cond$if$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f975State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$arg-3$call-$init$$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f976State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$arg3$call$init$$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$branch$cond$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f977State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond$when$valtransport$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$branch$cond-1$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f978State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond1$when$valtransport$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$branch$cond-2$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f979State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond2$when$valtransport$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$$this$call-not$else$cond$if$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f980State$Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$arg-3$call-$init$$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f981State$Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$arg3$call$init$$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$branch$cond$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f982State$Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond$when$valtransport$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$branch$cond-1$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f983State$Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond1$when$valtransport$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$branch$cond-2$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f984State$Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond2$when$valtransport$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-get$$this$call-toInt$val-version$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f985State$Int$arg0$callget$$this$calltoInt$valversion$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-number$$this$call-toInt$val-port$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f986State$Int$arg0$callnumber$$this$calltoInt$valport$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-number$arg-0$call-EQEQ$$this$call-not$else$cond$if-1$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f987State$Int$arg0$callnumber$arg0$callEQEQ$$this$callnot$else$cond$if1$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-number$val-chipId$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f988State$Int$arg0$callnumber$valchipId$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f989State$Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-repeat$fun-$anonymous$$arg-0$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f990State$Int$arg0$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-DiscoveredCar, reason: not valid java name */
    private static State<Integer> f991State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classDiscoveredCar;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-DiscoveredCar, reason: not valid java name */
    private static State<Integer> f992State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classDiscoveredCar;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-2$fun-hashCode$class-DiscoveredCar, reason: not valid java name */
    private static State<Integer> f993State$Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classDiscoveredCar;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-3$fun-hashCode$class-DiscoveredCar, reason: not valid java name */
    private static State<Integer> f994State$Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classDiscoveredCar;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-4$fun-hashCode$class-DiscoveredCar, reason: not valid java name */
    private static State<Integer> f995State$Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classDiscoveredCar;

    /* JADX INFO: renamed from: State$Int$arg-0$call-toString$1$str$fun-$get-name$$get$val-name$class-DiscoveredCar, reason: not valid java name */
    private static State<Integer> f996State$Int$arg0$calltoString$1$str$fun$getname$$get$valname$classDiscoveredCar;

    /* JADX INFO: renamed from: State$Int$arg-0$call-ushr$$$this$call-toString$1$str$fun-$get-name$$get$val-name$class-DiscoveredCar, reason: not valid java name */
    private static State<Integer> f997State$Int$arg0$callushr$$$this$calltoString$1$str$fun$getname$$get$valname$classDiscoveredCar;

    /* JADX INFO: renamed from: State$Int$arg-1$call-EQEQ$cond$cond$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f998State$Int$arg1$callEQEQ$cond$cond$when$valtransport$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$arg-1$call-EQEQ$cond$cond-1$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f999State$Int$arg1$callEQEQ$cond$cond1$when$valtransport$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$arg-1$call-EQEQ$cond$cond-2$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f1000State$Int$arg1$callEQEQ$cond$cond2$when$valtransport$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$arg-1$call-number$$this$call-toInt$val-port$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f1001State$Int$arg1$callnumber$$this$calltoInt$valport$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$arg-1$call-number$arg-0$call-EQEQ$$this$call-not$else$cond$if-1$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f1002State$Int$arg1$callnumber$arg0$callEQEQ$$this$callnot$else$cond$if1$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$arg-1$call-number$val-chipId$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f1003State$Int$arg1$callnumber$valchipId$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$class-DiscoveredCar, reason: not valid java name */
    private static State<Integer> f1004State$Int$classDiscoveredCar;

    /* JADX INFO: renamed from: State$Int$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f1005State$Int$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Int$param-discoveryVersion$class-DiscoveredCar, reason: not valid java name */
    private static State<Integer> f1006State$Int$paramdiscoveryVersion$classDiscoveredCar;

    /* JADX INFO: renamed from: State$Int$param-version$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static State<Integer> f1007State$Int$paramversion$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Long$arg-0$call-and$$this$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-number$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Long> f1008State$Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Long$arg-0$call-fold$fun-number$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Long> f1009State$Long$arg0$callfold$funnumber$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Long$arg-0$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if-2$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<Long> f1010State$Long$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if2$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$Long$arg-0$call-rangeTo$$this$call-contains$cond$arg-0$call-require$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static State<Long> f1011State$Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$funquery$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$String$0$str$fun-$get-name$$get$val-name$class-DiscoveredCar, reason: not valid java name */
    private static State<String> f1012State$String$0$str$fun$getname$$get$valname$classDiscoveredCar;

    /* JADX INFO: renamed from: State$String$0$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static State<String> f1013State$String$0$str$funtoString$classDiscoveredCar;

    /* JADX INFO: renamed from: State$String$1$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static State<String> f1014State$String$1$str$funtoString$classDiscoveredCar;

    /* JADX INFO: renamed from: State$String$10$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static State<String> f1015State$String$10$str$funtoString$classDiscoveredCar;

    /* JADX INFO: renamed from: State$String$12$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static State<String> f1016State$String$12$str$funtoString$classDiscoveredCar;

    /* JADX INFO: renamed from: State$String$13$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static State<String> f1017State$String$13$str$funtoString$classDiscoveredCar;

    /* JADX INFO: renamed from: State$String$15$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static State<String> f1018State$String$15$str$funtoString$classDiscoveredCar;

    /* JADX INFO: renamed from: State$String$16$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static State<String> f1019State$String$16$str$funtoString$classDiscoveredCar;

    /* JADX INFO: renamed from: State$String$18$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static State<String> f1020State$String$18$str$funtoString$classDiscoveredCar;

    /* JADX INFO: renamed from: State$String$3$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static State<String> f1021State$String$3$str$funtoString$classDiscoveredCar;

    /* JADX INFO: renamed from: State$String$4$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static State<String> f1022State$String$4$str$funtoString$classDiscoveredCar;

    /* JADX INFO: renamed from: State$String$6$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static State<String> f1023State$String$6$str$funtoString$classDiscoveredCar;

    /* JADX INFO: renamed from: State$String$7$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static State<String> f1024State$String$7$str$funtoString$classDiscoveredCar;

    /* JADX INFO: renamed from: State$String$9$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static State<String> f1025State$String$9$str$funtoString$classDiscoveredCar;

    /* JADX INFO: renamed from: State$String$arg-1$call-EQEQ$cond$cond$if-3$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<String> f1026State$String$arg1$callEQEQ$cond$cond$if3$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$String$branch$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<String> f1027State$String$branch$when$valtransport$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$String$branch-1$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<String> f1028State$String$branch1$when$valtransport$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$String$branch-2$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static State<String> f1029State$String$branch2$when$valtransport$funreply$classDiscoveryPacket;

    /* JADX INFO: renamed from: State$String$param-transport$class-DiscoveredCar, reason: not valid java name */
    private static State<String> f1030State$String$paramtransport$classDiscoveredCar;
    public static final LiveLiterals$DiscoveryPacketKt INSTANCE = new LiveLiterals$DiscoveryPacketKt();

    /* JADX INFO: renamed from: String$param-transport$class-DiscoveredCar, reason: not valid java name */
    private static String f1049String$paramtransport$classDiscoveredCar = "websocket-v1";

    /* JADX INFO: renamed from: Int$param-discoveryVersion$class-DiscoveredCar, reason: not valid java name */
    private static int f942Int$paramdiscoveryVersion$classDiscoveredCar = 1;

    /* JADX INFO: renamed from: String$0$str$fun-$get-name$$get$val-name$class-DiscoveredCar, reason: not valid java name */
    private static String f1031String$0$str$fun$getname$$get$valname$classDiscoveredCar = "RaceRemote-";

    /* JADX INFO: renamed from: Int$arg-0$call-ushr$$$this$call-toString$1$str$fun-$get-name$$get$val-name$class-DiscoveredCar, reason: not valid java name */
    private static int f933Int$arg0$callushr$$$this$calltoString$1$str$fun$getname$$get$valname$classDiscoveredCar = 24;

    /* JADX INFO: renamed from: Int$arg-0$call-toString$1$str$fun-$get-name$$get$val-name$class-DiscoveredCar, reason: not valid java name */
    private static int f932Int$arg0$calltoString$1$str$fun$getname$$get$valname$classDiscoveredCar = 16;

    /* JADX INFO: renamed from: String$0$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static String f1032String$0$str$funtoString$classDiscoveredCar = "DiscoveredCar(";

    /* JADX INFO: renamed from: String$1$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static String f1033String$1$str$funtoString$classDiscoveredCar = "host=";

    /* JADX INFO: renamed from: String$3$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static String f1040String$3$str$funtoString$classDiscoveredCar = ", ";

    /* JADX INFO: renamed from: String$4$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static String f1041String$4$str$funtoString$classDiscoveredCar = "port=";

    /* JADX INFO: renamed from: String$6$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static String f1042String$6$str$funtoString$classDiscoveredCar = ", ";

    /* JADX INFO: renamed from: String$7$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static String f1043String$7$str$funtoString$classDiscoveredCar = "chipId=";

    /* JADX INFO: renamed from: String$9$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static String f1044String$9$str$funtoString$classDiscoveredCar = ", ";

    /* JADX INFO: renamed from: String$10$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static String f1034String$10$str$funtoString$classDiscoveredCar = "busy=";

    /* JADX INFO: renamed from: String$12$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static String f1035String$12$str$funtoString$classDiscoveredCar = ", ";

    /* JADX INFO: renamed from: String$13$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static String f1036String$13$str$funtoString$classDiscoveredCar = "transport=";

    /* JADX INFO: renamed from: String$15$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static String f1037String$15$str$funtoString$classDiscoveredCar = ", ";

    /* JADX INFO: renamed from: String$16$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static String f1038String$16$str$funtoString$classDiscoveredCar = "discoveryVersion=";

    /* JADX INFO: renamed from: String$18$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    private static String f1039String$18$str$funtoString$classDiscoveredCar = ")";

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-DiscoveredCar, reason: not valid java name */
    private static int f927Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classDiscoveredCar = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-DiscoveredCar, reason: not valid java name */
    private static int f928Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classDiscoveredCar = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-2$fun-hashCode$class-DiscoveredCar, reason: not valid java name */
    private static int f929Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classDiscoveredCar = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-3$fun-hashCode$class-DiscoveredCar, reason: not valid java name */
    private static int f930Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classDiscoveredCar = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-4$fun-hashCode$class-DiscoveredCar, reason: not valid java name */
    private static int f931Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classDiscoveredCar = 31;

    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-DiscoveredCar, reason: not valid java name */
    private static boolean f884Boolean$branch$when$funequals$classDiscoveredCar = true;

    /* JADX INFO: renamed from: Boolean$fun-equals$class-DiscoveredCar, reason: not valid java name */
    private static boolean f892Boolean$funequals$classDiscoveredCar = true;

    /* JADX INFO: renamed from: Int$param-version$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static int f943Int$paramversion$funquery$classDiscoveryPacket = 1;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$cond$arg-0$call-require$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static int f908Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$funquery$classDiscoveryPacket = 1;

    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$cond$arg-0$call-require$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static long f947Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$funquery$classDiscoveryPacket = 4294967295L;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static int f907Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funquery$classDiscoveryPacket = 1;

    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static int f925Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funquery$classDiscoveryPacket = 2;

    /* JADX INFO: renamed from: Byte$0$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static byte f893Byte$0$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket = 82;

    /* JADX INFO: renamed from: Byte$1$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static byte f894Byte$1$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket = 82;

    /* JADX INFO: renamed from: Byte$2$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static byte f897Byte$2$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket = 68;

    /* JADX INFO: renamed from: Byte$4$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static byte f898Byte$4$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket = 1;

    /* JADX INFO: renamed from: Int$arg-0$call-repeat$fun-$anonymous$$arg-0$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static int f926Int$arg0$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket = 4;

    /* JADX INFO: renamed from: Int$$this$call-plus$arg-0$call-set$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-0$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static int f905Int$$this$callplus$arg0$callset$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket = 8;

    /* JADX INFO: renamed from: Int$$this$call-times$arg-0$call-ushr$$this$call-toByte$arg-1$call-set$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-0$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    private static int f910Int$$this$calltimes$arg0$callushr$$this$calltoByte$arg1$callset$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket = 8;

    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$$this$call-not$else$cond$if$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static int f916Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$funreply$classDiscoveryPacket = 23;

    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toInt$val-version$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static int f921Int$arg0$callget$$this$calltoInt$valversion$funreply$classDiscoveryPacket = 3;

    /* JADX INFO: renamed from: Int$arg-1$call-EQEQ$cond$cond$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static int f934Int$arg1$callEQEQ$cond$cond$when$valtransport$funreply$classDiscoveryPacket = 1;

    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$branch$cond$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static int f918Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond$when$valtransport$funreply$classDiscoveryPacket = 22;

    /* JADX INFO: renamed from: String$branch$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static String f1046String$branch$when$valtransport$funreply$classDiscoveryPacket = "websocket-v1";

    /* JADX INFO: renamed from: Int$arg-1$call-EQEQ$cond$cond-1$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static int f935Int$arg1$callEQEQ$cond$cond1$when$valtransport$funreply$classDiscoveryPacket = 2;

    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$branch$cond-1$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static int f919Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond1$when$valtransport$funreply$classDiscoveryPacket = 22;

    /* JADX INFO: renamed from: Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$branch$cond-1$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static int f914Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond1$when$valtransport$funreply$classDiscoveryPacket = 1;

    /* JADX INFO: renamed from: String$branch-1$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static String f1047String$branch1$when$valtransport$funreply$classDiscoveryPacket = "websocket-v1";

    /* JADX INFO: renamed from: Int$arg-1$call-EQEQ$cond$cond-2$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static int f936Int$arg1$callEQEQ$cond$cond2$when$valtransport$funreply$classDiscoveryPacket = 2;

    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$branch$cond-2$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static int f920Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond2$when$valtransport$funreply$classDiscoveryPacket = 22;

    /* JADX INFO: renamed from: Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$branch$cond-2$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static int f915Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond2$when$valtransport$funreply$classDiscoveryPacket = 2;

    /* JADX INFO: renamed from: String$branch-2$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static String f1048String$branch2$when$valtransport$funreply$classDiscoveryPacket = "udp-v1";

    /* JADX INFO: renamed from: Long$arg-0$call-and$$this$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-number$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static long f944Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$funreply$classDiscoveryPacket = 255;

    /* JADX INFO: renamed from: Int$$this$call-times$arg-0$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-number$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static int f909Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$funreply$classDiscoveryPacket = 8;

    /* JADX INFO: renamed from: Int$arg-0$call-number$arg-0$call-EQEQ$$this$call-not$else$cond$if-1$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static int f923Int$arg0$callnumber$arg0$callEQEQ$$this$callnot$else$cond$if1$funreply$classDiscoveryPacket = 8;

    /* JADX INFO: renamed from: Int$arg-1$call-number$arg-0$call-EQEQ$$this$call-not$else$cond$if-1$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static int f938Int$arg1$callnumber$arg0$callEQEQ$$this$callnot$else$cond$if1$funreply$classDiscoveryPacket = 4;

    /* JADX INFO: renamed from: Int$arg-0$call-number$$this$call-toInt$val-port$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static int f922Int$arg0$callnumber$$this$calltoInt$valport$funreply$classDiscoveryPacket = 6;

    /* JADX INFO: renamed from: Int$arg-1$call-number$$this$call-toInt$val-port$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static int f937Int$arg1$callnumber$$this$calltoInt$valport$funreply$classDiscoveryPacket = 2;

    /* JADX INFO: renamed from: Int$arg-0$call-number$val-chipId$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static int f924Int$arg0$callnumber$valchipId$funreply$classDiscoveryPacket = 12;

    /* JADX INFO: renamed from: Int$arg-1$call-number$val-chipId$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static int f939Int$arg1$callnumber$valchipId$funreply$classDiscoveryPacket = 8;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if-2$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static int f906Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if2$funreply$classDiscoveryPacket = 1;

    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if-2$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static long f946Long$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if2$funreply$classDiscoveryPacket = 281474976710655L;

    /* JADX INFO: renamed from: String$arg-1$call-EQEQ$cond$cond$if-3$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static String f1045String$arg1$callEQEQ$cond$cond$if3$funreply$classDiscoveryPacket = "udp-v1";

    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$arg-3$call-$init$$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static int f917Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$arg3$call$init$$funreply$classDiscoveryPacket = 21;

    /* JADX INFO: renamed from: Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$arg-3$call-$init$$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    private static int f912Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$arg3$call$init$$funreply$classDiscoveryPacket = 1;

    @LiveLiteralInfo(key = "Boolean$branch$when$fun-equals$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-DiscoveredCar, reason: not valid java name */
    public final boolean m6404Boolean$branch$when$funequals$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f884Boolean$branch$when$funequals$classDiscoveredCar;
        }
        State<Boolean> stateLiveLiteral = f948State$Boolean$branch$when$funequals$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when$fun-equals$class-DiscoveredCar", Boolean.valueOf(f884Boolean$branch$when$funequals$classDiscoveredCar));
            f948State$Boolean$branch$when$funequals$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-1$fun-equals$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-DiscoveredCar, reason: not valid java name */
    public final boolean m6405Boolean$branch$when1$funequals$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f885Boolean$branch$when1$funequals$classDiscoveredCar;
        }
        State<Boolean> stateLiveLiteral = f949State$Boolean$branch$when1$funequals$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-1$fun-equals$class-DiscoveredCar", Boolean.valueOf(f885Boolean$branch$when1$funequals$classDiscoveredCar));
            f949State$Boolean$branch$when1$funequals$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-2$fun-equals$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-DiscoveredCar, reason: not valid java name */
    public final boolean m6406Boolean$branch$when2$funequals$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f886Boolean$branch$when2$funequals$classDiscoveredCar;
        }
        State<Boolean> stateLiveLiteral = f950State$Boolean$branch$when2$funequals$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-2$fun-equals$class-DiscoveredCar", Boolean.valueOf(f886Boolean$branch$when2$funequals$classDiscoveredCar));
            f950State$Boolean$branch$when2$funequals$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-3$fun-equals$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-DiscoveredCar, reason: not valid java name */
    public final boolean m6407Boolean$branch$when3$funequals$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f887Boolean$branch$when3$funequals$classDiscoveredCar;
        }
        State<Boolean> stateLiveLiteral = f951State$Boolean$branch$when3$funequals$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-3$fun-equals$class-DiscoveredCar", Boolean.valueOf(f887Boolean$branch$when3$funequals$classDiscoveredCar));
            f951State$Boolean$branch$when3$funequals$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-4$fun-equals$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-4$fun-equals$class-DiscoveredCar, reason: not valid java name */
    public final boolean m6408Boolean$branch$when4$funequals$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f888Boolean$branch$when4$funequals$classDiscoveredCar;
        }
        State<Boolean> stateLiveLiteral = f952State$Boolean$branch$when4$funequals$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-4$fun-equals$class-DiscoveredCar", Boolean.valueOf(f888Boolean$branch$when4$funequals$classDiscoveredCar));
            f952State$Boolean$branch$when4$funequals$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-5$fun-equals$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-5$fun-equals$class-DiscoveredCar, reason: not valid java name */
    public final boolean m6409Boolean$branch$when5$funequals$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f889Boolean$branch$when5$funequals$classDiscoveredCar;
        }
        State<Boolean> stateLiveLiteral = f953State$Boolean$branch$when5$funequals$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-5$fun-equals$class-DiscoveredCar", Boolean.valueOf(f889Boolean$branch$when5$funequals$classDiscoveredCar));
            f953State$Boolean$branch$when5$funequals$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-6$fun-equals$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-6$fun-equals$class-DiscoveredCar, reason: not valid java name */
    public final boolean m6410Boolean$branch$when6$funequals$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f890Boolean$branch$when6$funequals$classDiscoveredCar;
        }
        State<Boolean> stateLiveLiteral = f954State$Boolean$branch$when6$funequals$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-6$fun-equals$class-DiscoveredCar", Boolean.valueOf(f890Boolean$branch$when6$funequals$classDiscoveredCar));
            f954State$Boolean$branch$when6$funequals$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-7$fun-equals$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-7$fun-equals$class-DiscoveredCar, reason: not valid java name */
    public final boolean m6411Boolean$branch$when7$funequals$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f891Boolean$branch$when7$funequals$classDiscoveredCar;
        }
        State<Boolean> stateLiveLiteral = f955State$Boolean$branch$when7$funequals$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-7$fun-equals$class-DiscoveredCar", Boolean.valueOf(f891Boolean$branch$when7$funequals$classDiscoveredCar));
            f955State$Boolean$branch$when7$funequals$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$fun-equals$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: Boolean$fun-equals$class-DiscoveredCar, reason: not valid java name */
    public final boolean m6412Boolean$funequals$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f892Boolean$funequals$classDiscoveredCar;
        }
        State<Boolean> stateLiveLiteral = f956State$Boolean$funequals$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$fun-equals$class-DiscoveredCar", Boolean.valueOf(f892Boolean$funequals$classDiscoveredCar));
            f956State$Boolean$funequals$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Byte$0$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket", offset = 499)
    /* JADX INFO: renamed from: Byte$0$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    public final byte m6413Byte$0$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f893Byte$0$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;
        }
        State<Byte> stateLiveLiteral = f957State$Byte$0$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Byte$0$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket", Byte.valueOf(f893Byte$0$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket));
            f957State$Byte$0$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().byteValue();
    }

    @LiveLiteralInfo(key = "Byte$1$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket", offset = 503)
    /* JADX INFO: renamed from: Byte$1$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    public final byte m6414Byte$1$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f894Byte$1$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;
        }
        State<Byte> stateLiveLiteral = f958State$Byte$1$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Byte$1$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket", Byte.valueOf(f894Byte$1$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket));
            f958State$Byte$1$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().byteValue();
    }

    @LiveLiteralInfo(key = "Byte$10$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket", offset = 547)
    /* JADX INFO: renamed from: Byte$10$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    public final byte m6415Byte$10$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f895Byte$10$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;
        }
        State<Byte> stateLiveLiteral = f959State$Byte$10$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Byte$10$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket", Byte.valueOf(f895Byte$10$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket));
            f959State$Byte$10$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().byteValue();
    }

    @LiveLiteralInfo(key = "Byte$11$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket", offset = 550)
    /* JADX INFO: renamed from: Byte$11$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    public final byte m6416Byte$11$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f896Byte$11$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;
        }
        State<Byte> stateLiveLiteral = f960State$Byte$11$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Byte$11$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket", Byte.valueOf(f896Byte$11$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket));
            f960State$Byte$11$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().byteValue();
    }

    @LiveLiteralInfo(key = "Byte$2$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket", offset = 507)
    /* JADX INFO: renamed from: Byte$2$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    public final byte m6417Byte$2$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f897Byte$2$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;
        }
        State<Byte> stateLiveLiteral = f961State$Byte$2$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Byte$2$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket", Byte.valueOf(f897Byte$2$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket));
            f961State$Byte$2$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().byteValue();
    }

    @LiveLiteralInfo(key = "Byte$4$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket", offset = 529)
    /* JADX INFO: renamed from: Byte$4$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    public final byte m6418Byte$4$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f898Byte$4$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;
        }
        State<Byte> stateLiveLiteral = f962State$Byte$4$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Byte$4$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket", Byte.valueOf(f898Byte$4$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket));
            f962State$Byte$4$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().byteValue();
    }

    @LiveLiteralInfo(key = "Byte$5$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket", offset = 532)
    /* JADX INFO: renamed from: Byte$5$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    public final byte m6419Byte$5$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f899Byte$5$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;
        }
        State<Byte> stateLiveLiteral = f963State$Byte$5$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Byte$5$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket", Byte.valueOf(f899Byte$5$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket));
            f963State$Byte$5$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().byteValue();
    }

    @LiveLiteralInfo(key = "Byte$6$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket", offset = 535)
    /* JADX INFO: renamed from: Byte$6$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    public final byte m6420Byte$6$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f900Byte$6$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;
        }
        State<Byte> stateLiveLiteral = f964State$Byte$6$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Byte$6$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket", Byte.valueOf(f900Byte$6$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket));
            f964State$Byte$6$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().byteValue();
    }

    @LiveLiteralInfo(key = "Byte$7$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket", offset = 538)
    /* JADX INFO: renamed from: Byte$7$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    public final byte m6421Byte$7$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f901Byte$7$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;
        }
        State<Byte> stateLiveLiteral = f965State$Byte$7$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Byte$7$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket", Byte.valueOf(f901Byte$7$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket));
            f965State$Byte$7$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().byteValue();
    }

    @LiveLiteralInfo(key = "Byte$8$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket", offset = 541)
    /* JADX INFO: renamed from: Byte$8$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    public final byte m6422Byte$8$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f902Byte$8$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;
        }
        State<Byte> stateLiveLiteral = f966State$Byte$8$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Byte$8$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket", Byte.valueOf(f902Byte$8$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket));
            f966State$Byte$8$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().byteValue();
    }

    @LiveLiteralInfo(key = "Byte$9$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket", offset = 544)
    /* JADX INFO: renamed from: Byte$9$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    public final byte m6423Byte$9$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f903Byte$9$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;
        }
        State<Byte> stateLiveLiteral = f967State$Byte$9$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Byte$9$vararg$arg-0$call-byteArrayOf$$$this$call-also$fun-query$class-DiscoveryPacket", Byte.valueOf(f903Byte$9$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket));
            f967State$Byte$9$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().byteValue();
    }

    @LiveLiteralInfo(key = "Int$$$this$call-until$$$this$call-fold$fun-number$fun-reply$class-DiscoveryPacket", offset = 1437)
    /* JADX INFO: renamed from: Int$$$this$call-until$$$this$call-fold$fun-number$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final int m6424Int$$$this$calluntil$$$this$callfold$funnumber$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f904Int$$$this$calluntil$$$this$callfold$funnumber$funreply$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f968State$Int$$$this$calluntil$$$this$callfold$funnumber$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$$this$call-until$$$this$call-fold$fun-number$fun-reply$class-DiscoveryPacket", Integer.valueOf(f904Int$$$this$calluntil$$$this$callfold$funnumber$funreply$classDiscoveryPacket));
            f968State$Int$$$this$calluntil$$$this$callfold$funnumber$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-plus$arg-0$call-set$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-0$call-also$fun-query$class-DiscoveryPacket", offset = 599)
    /* JADX INFO: renamed from: Int$$this$call-plus$arg-0$call-set$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-0$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    public final int m6425Int$$this$callplus$arg0$callset$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f905Int$$this$callplus$arg0$callset$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f969State$Int$$this$callplus$arg0$callset$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-plus$arg-0$call-set$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-0$call-also$fun-query$class-DiscoveryPacket", Integer.valueOf(f905Int$$this$callplus$arg0$callset$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket));
            f969State$Int$$this$callplus$arg0$callset$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if-2$fun-reply$class-DiscoveryPacket", offset = 1746)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if-2$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final int m6426Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if2$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f906Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if2$funreply$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f970State$Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if2$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if-2$fun-reply$class-DiscoveryPacket", Integer.valueOf(f906Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if2$funreply$classDiscoveryPacket));
            f970State$Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if2$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-query$class-DiscoveryPacket", offset = 466)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-query$class-DiscoveryPacket, reason: not valid java name */
    public final int m6427Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funquery$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f907Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funquery$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f971State$Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funquery$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-query$class-DiscoveryPacket", Integer.valueOf(f907Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funquery$classDiscoveryPacket));
            f971State$Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funquery$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$cond$arg-0$call-require$fun-query$class-DiscoveryPacket", offset = 437)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$cond$arg-0$call-require$fun-query$class-DiscoveryPacket, reason: not valid java name */
    public final int m6428Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$funquery$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f908Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$funquery$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f972State$Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$funquery$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$cond$arg-0$call-require$fun-query$class-DiscoveryPacket", Integer.valueOf(f908Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$funquery$classDiscoveryPacket));
            f972State$Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$funquery$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-times$arg-0$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-number$fun-reply$class-DiscoveryPacket", offset = 1539)
    /* JADX INFO: renamed from: Int$$this$call-times$arg-0$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-number$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final int m6429Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f909Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$funreply$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f973State$Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-times$arg-0$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-number$fun-reply$class-DiscoveryPacket", Integer.valueOf(f909Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$funreply$classDiscoveryPacket));
            f973State$Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-times$arg-0$call-ushr$$this$call-toByte$arg-1$call-set$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-0$call-also$fun-query$class-DiscoveryPacket", offset = 622)
    /* JADX INFO: renamed from: Int$$this$call-times$arg-0$call-ushr$$this$call-toByte$arg-1$call-set$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-0$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    public final int m6430Int$$this$calltimes$arg0$callushr$$this$calltoByte$arg1$callset$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f910Int$$this$calltimes$arg0$callushr$$this$calltoByte$arg1$callset$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f974State$Int$$this$calltimes$arg0$callushr$$this$calltoByte$arg1$callset$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-times$arg-0$call-ushr$$this$call-toByte$arg-1$call-set$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-0$call-also$fun-query$class-DiscoveryPacket", Integer.valueOf(f910Int$$this$calltimes$arg0$callushr$$this$calltoByte$arg1$callset$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket));
            f974State$Int$$this$calltimes$arg0$callushr$$this$calltoByte$arg1$callset$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$$this$call-not$else$cond$if$fun-reply$class-DiscoveryPacket", offset = 1044)
    /* JADX INFO: renamed from: Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$$this$call-not$else$cond$if$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final int m6431Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f911Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$funreply$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f975State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$$this$call-not$else$cond$if$fun-reply$class-DiscoveryPacket", Integer.valueOf(f911Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$funreply$classDiscoveryPacket));
            f975State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$arg-3$call-$init$$fun-reply$class-DiscoveryPacket", offset = 1920)
    /* JADX INFO: renamed from: Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$arg-3$call-$init$$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final int m6432Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$arg3$call$init$$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f912Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$arg3$call$init$$funreply$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f976State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$arg3$call$init$$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$arg-3$call-$init$$fun-reply$class-DiscoveryPacket", Integer.valueOf(f912Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$arg3$call$init$$funreply$classDiscoveryPacket));
            f976State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$arg3$call$init$$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$branch$cond$when$val-transport$fun-reply$class-DiscoveryPacket", offset = 1179)
    /* JADX INFO: renamed from: Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$branch$cond$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final int m6433Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond$when$valtransport$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f913Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond$when$valtransport$funreply$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f977State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond$when$valtransport$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$branch$cond$when$val-transport$fun-reply$class-DiscoveryPacket", Integer.valueOf(f913Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond$when$valtransport$funreply$classDiscoveryPacket));
            f977State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond$when$valtransport$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$branch$cond-1$when$val-transport$fun-reply$class-DiscoveryPacket", offset = 1249)
    /* JADX INFO: renamed from: Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$branch$cond-1$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final int m6434Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond1$when$valtransport$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f914Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond1$when$valtransport$funreply$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f978State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond1$when$valtransport$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$branch$cond-1$when$val-transport$fun-reply$class-DiscoveryPacket", Integer.valueOf(f914Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond1$when$valtransport$funreply$classDiscoveryPacket));
            f978State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond1$when$valtransport$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$branch$cond-2$when$val-transport$fun-reply$class-DiscoveryPacket", offset = 1319)
    /* JADX INFO: renamed from: Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$branch$cond-2$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final int m6435Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond2$when$valtransport$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f915Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond2$when$valtransport$funreply$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f979State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond2$when$valtransport$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$branch$cond-2$when$val-transport$fun-reply$class-DiscoveryPacket", Integer.valueOf(f915Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond2$when$valtransport$funreply$classDiscoveryPacket));
            f979State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond2$when$valtransport$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$$this$call-not$else$cond$if$fun-reply$class-DiscoveryPacket", offset = 1037)
    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$$this$call-not$else$cond$if$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final int m6436Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f916Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$funreply$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f980State$Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$$this$call-not$else$cond$if$fun-reply$class-DiscoveryPacket", Integer.valueOf(f916Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$funreply$classDiscoveryPacket));
            f980State$Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$arg-3$call-$init$$fun-reply$class-DiscoveryPacket", offset = 1913)
    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$arg-3$call-$init$$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final int m6437Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$arg3$call$init$$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f917Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$arg3$call$init$$funreply$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f981State$Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$arg3$call$init$$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$arg-3$call-$init$$fun-reply$class-DiscoveryPacket", Integer.valueOf(f917Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$arg3$call$init$$funreply$classDiscoveryPacket));
            f981State$Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$arg3$call$init$$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$branch$cond$when$val-transport$fun-reply$class-DiscoveryPacket", offset = 1172)
    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$branch$cond$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final int m6438Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond$when$valtransport$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f918Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond$when$valtransport$funreply$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f982State$Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond$when$valtransport$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$branch$cond$when$val-transport$fun-reply$class-DiscoveryPacket", Integer.valueOf(f918Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond$when$valtransport$funreply$classDiscoveryPacket));
            f982State$Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond$when$valtransport$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$branch$cond-1$when$val-transport$fun-reply$class-DiscoveryPacket", offset = 1242)
    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$branch$cond-1$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final int m6439Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond1$when$valtransport$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f919Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond1$when$valtransport$funreply$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f983State$Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond1$when$valtransport$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$branch$cond-1$when$val-transport$fun-reply$class-DiscoveryPacket", Integer.valueOf(f919Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond1$when$valtransport$funreply$classDiscoveryPacket));
            f983State$Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond1$when$valtransport$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$branch$cond-2$when$val-transport$fun-reply$class-DiscoveryPacket", offset = 1312)
    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$branch$cond-2$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final int m6440Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond2$when$valtransport$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f920Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond2$when$valtransport$funreply$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f984State$Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond2$when$valtransport$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$branch$cond-2$when$val-transport$fun-reply$class-DiscoveryPacket", Integer.valueOf(f920Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond2$when$valtransport$funreply$classDiscoveryPacket));
            f984State$Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond2$when$valtransport$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-get$$this$call-toInt$val-version$fun-reply$class-DiscoveryPacket", offset = 1096)
    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toInt$val-version$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final int m6441Int$arg0$callget$$this$calltoInt$valversion$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f921Int$arg0$callget$$this$calltoInt$valversion$funreply$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f985State$Int$arg0$callget$$this$calltoInt$valversion$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-get$$this$call-toInt$val-version$fun-reply$class-DiscoveryPacket", Integer.valueOf(f921Int$arg0$callget$$this$calltoInt$valversion$funreply$classDiscoveryPacket));
            f985State$Int$arg0$callget$$this$calltoInt$valversion$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-number$$this$call-toInt$val-port$fun-reply$class-DiscoveryPacket", offset = 1661)
    /* JADX INFO: renamed from: Int$arg-0$call-number$$this$call-toInt$val-port$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final int m6442Int$arg0$callnumber$$this$calltoInt$valport$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f922Int$arg0$callnumber$$this$calltoInt$valport$funreply$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f986State$Int$arg0$callnumber$$this$calltoInt$valport$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-number$$this$call-toInt$val-port$fun-reply$class-DiscoveryPacket", Integer.valueOf(f922Int$arg0$callnumber$$this$calltoInt$valport$funreply$classDiscoveryPacket));
            f986State$Int$arg0$callnumber$$this$calltoInt$valport$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-number$arg-0$call-EQEQ$$this$call-not$else$cond$if-1$fun-reply$class-DiscoveryPacket", offset = 1599)
    /* JADX INFO: renamed from: Int$arg-0$call-number$arg-0$call-EQEQ$$this$call-not$else$cond$if-1$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final int m6443Int$arg0$callnumber$arg0$callEQEQ$$this$callnot$else$cond$if1$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f923Int$arg0$callnumber$arg0$callEQEQ$$this$callnot$else$cond$if1$funreply$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f987State$Int$arg0$callnumber$arg0$callEQEQ$$this$callnot$else$cond$if1$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-number$arg-0$call-EQEQ$$this$call-not$else$cond$if-1$fun-reply$class-DiscoveryPacket", Integer.valueOf(f923Int$arg0$callnumber$arg0$callEQEQ$$this$callnot$else$cond$if1$funreply$classDiscoveryPacket));
            f987State$Int$arg0$callnumber$arg0$callEQEQ$$this$callnot$else$cond$if1$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-number$val-chipId$fun-reply$class-DiscoveryPacket", offset = 1703)
    /* JADX INFO: renamed from: Int$arg-0$call-number$val-chipId$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final int m6444Int$arg0$callnumber$valchipId$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f924Int$arg0$callnumber$valchipId$funreply$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f988State$Int$arg0$callnumber$valchipId$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-number$val-chipId$fun-reply$class-DiscoveryPacket", Integer.valueOf(f924Int$arg0$callnumber$valchipId$funreply$classDiscoveryPacket));
            f988State$Int$arg0$callnumber$valchipId$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-query$class-DiscoveryPacket", offset = 469)
    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-query$class-DiscoveryPacket, reason: not valid java name */
    public final int m6445Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funquery$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f925Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funquery$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f989State$Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funquery$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-query$class-DiscoveryPacket", Integer.valueOf(f925Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funquery$classDiscoveryPacket));
            f989State$Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funquery$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-repeat$fun-$anonymous$$arg-0$call-also$fun-query$class-DiscoveryPacket", offset = 588)
    /* JADX INFO: renamed from: Int$arg-0$call-repeat$fun-$anonymous$$arg-0$call-also$fun-query$class-DiscoveryPacket, reason: not valid java name */
    public final int m6446Int$arg0$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f926Int$arg0$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f990State$Int$arg0$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-repeat$fun-$anonymous$$arg-0$call-also$fun-query$class-DiscoveryPacket", Integer.valueOf(f926Int$arg0$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket));
            f990State$Int$arg0$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-DiscoveredCar, reason: not valid java name */
    public final int m6447Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f927Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classDiscoveredCar;
        }
        State<Integer> stateLiveLiteral = f991State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-DiscoveredCar", Integer.valueOf(f927Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classDiscoveredCar));
            f991State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-DiscoveredCar, reason: not valid java name */
    public final int m6448Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f928Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classDiscoveredCar;
        }
        State<Integer> stateLiveLiteral = f992State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-DiscoveredCar", Integer.valueOf(f928Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classDiscoveredCar));
            f992State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-2$fun-hashCode$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-2$fun-hashCode$class-DiscoveredCar, reason: not valid java name */
    public final int m6449Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f929Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classDiscoveredCar;
        }
        State<Integer> stateLiveLiteral = f993State$Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-2$fun-hashCode$class-DiscoveredCar", Integer.valueOf(f929Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classDiscoveredCar));
            f993State$Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-3$fun-hashCode$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-3$fun-hashCode$class-DiscoveredCar, reason: not valid java name */
    public final int m6450Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f930Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classDiscoveredCar;
        }
        State<Integer> stateLiveLiteral = f994State$Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-3$fun-hashCode$class-DiscoveredCar", Integer.valueOf(f930Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classDiscoveredCar));
            f994State$Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-4$fun-hashCode$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-4$fun-hashCode$class-DiscoveredCar, reason: not valid java name */
    public final int m6451Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f931Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classDiscoveredCar;
        }
        State<Integer> stateLiveLiteral = f995State$Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-4$fun-hashCode$class-DiscoveredCar", Integer.valueOf(f931Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classDiscoveredCar));
            f995State$Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-toString$1$str$fun-$get-name$$get$val-name$class-DiscoveredCar", offset = 294)
    /* JADX INFO: renamed from: Int$arg-0$call-toString$1$str$fun-$get-name$$get$val-name$class-DiscoveredCar, reason: not valid java name */
    public final int m6452Int$arg0$calltoString$1$str$fun$getname$$get$valname$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f932Int$arg0$calltoString$1$str$fun$getname$$get$valname$classDiscoveredCar;
        }
        State<Integer> stateLiveLiteral = f996State$Int$arg0$calltoString$1$str$fun$getname$$get$valname$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-toString$1$str$fun-$get-name$$get$val-name$class-DiscoveredCar", Integer.valueOf(f932Int$arg0$calltoString$1$str$fun$getname$$get$valname$classDiscoveredCar));
            f996State$Int$arg0$calltoString$1$str$fun$getname$$get$valname$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-ushr$$$this$call-toString$1$str$fun-$get-name$$get$val-name$class-DiscoveredCar", offset = 281)
    /* JADX INFO: renamed from: Int$arg-0$call-ushr$$$this$call-toString$1$str$fun-$get-name$$get$val-name$class-DiscoveredCar, reason: not valid java name */
    public final int m6453Int$arg0$callushr$$$this$calltoString$1$str$fun$getname$$get$valname$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f933Int$arg0$callushr$$$this$calltoString$1$str$fun$getname$$get$valname$classDiscoveredCar;
        }
        State<Integer> stateLiveLiteral = f997State$Int$arg0$callushr$$$this$calltoString$1$str$fun$getname$$get$valname$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-ushr$$$this$call-toString$1$str$fun-$get-name$$get$val-name$class-DiscoveredCar", Integer.valueOf(f933Int$arg0$callushr$$$this$calltoString$1$str$fun$getname$$get$valname$classDiscoveredCar));
            f997State$Int$arg0$callushr$$$this$calltoString$1$str$fun$getname$$get$valname$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-EQEQ$cond$cond$when$val-transport$fun-reply$class-DiscoveryPacket", offset = 1161)
    /* JADX INFO: renamed from: Int$arg-1$call-EQEQ$cond$cond$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final int m6454Int$arg1$callEQEQ$cond$cond$when$valtransport$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f934Int$arg1$callEQEQ$cond$cond$when$valtransport$funreply$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f998State$Int$arg1$callEQEQ$cond$cond$when$valtransport$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-EQEQ$cond$cond$when$val-transport$fun-reply$class-DiscoveryPacket", Integer.valueOf(f934Int$arg1$callEQEQ$cond$cond$when$valtransport$funreply$classDiscoveryPacket));
            f998State$Int$arg1$callEQEQ$cond$cond$when$valtransport$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-EQEQ$cond$cond-1$when$val-transport$fun-reply$class-DiscoveryPacket", offset = 1231)
    /* JADX INFO: renamed from: Int$arg-1$call-EQEQ$cond$cond-1$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final int m6455Int$arg1$callEQEQ$cond$cond1$when$valtransport$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f935Int$arg1$callEQEQ$cond$cond1$when$valtransport$funreply$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f999State$Int$arg1$callEQEQ$cond$cond1$when$valtransport$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-EQEQ$cond$cond-1$when$val-transport$fun-reply$class-DiscoveryPacket", Integer.valueOf(f935Int$arg1$callEQEQ$cond$cond1$when$valtransport$funreply$classDiscoveryPacket));
            f999State$Int$arg1$callEQEQ$cond$cond1$when$valtransport$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-EQEQ$cond$cond-2$when$val-transport$fun-reply$class-DiscoveryPacket", offset = 1301)
    /* JADX INFO: renamed from: Int$arg-1$call-EQEQ$cond$cond-2$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final int m6456Int$arg1$callEQEQ$cond$cond2$when$valtransport$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f936Int$arg1$callEQEQ$cond$cond2$when$valtransport$funreply$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f1000State$Int$arg1$callEQEQ$cond$cond2$when$valtransport$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-EQEQ$cond$cond-2$when$val-transport$fun-reply$class-DiscoveryPacket", Integer.valueOf(f936Int$arg1$callEQEQ$cond$cond2$when$valtransport$funreply$classDiscoveryPacket));
            f1000State$Int$arg1$callEQEQ$cond$cond2$when$valtransport$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-number$$this$call-toInt$val-port$fun-reply$class-DiscoveryPacket", offset = 1664)
    /* JADX INFO: renamed from: Int$arg-1$call-number$$this$call-toInt$val-port$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final int m6457Int$arg1$callnumber$$this$calltoInt$valport$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f937Int$arg1$callnumber$$this$calltoInt$valport$funreply$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f1001State$Int$arg1$callnumber$$this$calltoInt$valport$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-number$$this$call-toInt$val-port$fun-reply$class-DiscoveryPacket", Integer.valueOf(f937Int$arg1$callnumber$$this$calltoInt$valport$funreply$classDiscoveryPacket));
            f1001State$Int$arg1$callnumber$$this$calltoInt$valport$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-number$arg-0$call-EQEQ$$this$call-not$else$cond$if-1$fun-reply$class-DiscoveryPacket", offset = 1602)
    /* JADX INFO: renamed from: Int$arg-1$call-number$arg-0$call-EQEQ$$this$call-not$else$cond$if-1$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final int m6458Int$arg1$callnumber$arg0$callEQEQ$$this$callnot$else$cond$if1$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f938Int$arg1$callnumber$arg0$callEQEQ$$this$callnot$else$cond$if1$funreply$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f1002State$Int$arg1$callnumber$arg0$callEQEQ$$this$callnot$else$cond$if1$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-number$arg-0$call-EQEQ$$this$call-not$else$cond$if-1$fun-reply$class-DiscoveryPacket", Integer.valueOf(f938Int$arg1$callnumber$arg0$callEQEQ$$this$callnot$else$cond$if1$funreply$classDiscoveryPacket));
            f1002State$Int$arg1$callnumber$arg0$callEQEQ$$this$callnot$else$cond$if1$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-number$val-chipId$fun-reply$class-DiscoveryPacket", offset = 1707)
    /* JADX INFO: renamed from: Int$arg-1$call-number$val-chipId$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final int m6459Int$arg1$callnumber$valchipId$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f939Int$arg1$callnumber$valchipId$funreply$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f1003State$Int$arg1$callnumber$valchipId$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-number$val-chipId$fun-reply$class-DiscoveryPacket", Integer.valueOf(f939Int$arg1$callnumber$valchipId$funreply$classDiscoveryPacket));
            f1003State$Int$arg1$callnumber$valchipId$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-DiscoveredCar", offset = -1)
    /* JADX INFO: renamed from: Int$class-DiscoveredCar, reason: not valid java name */
    public final int m6460Int$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f940Int$classDiscoveredCar;
        }
        State<Integer> stateLiveLiteral = f1004State$Int$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-DiscoveredCar", Integer.valueOf(f940Int$classDiscoveredCar));
            f1004State$Int$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-DiscoveryPacket", offset = -1)
    /* JADX INFO: renamed from: Int$class-DiscoveryPacket, reason: not valid java name */
    public final int m6461Int$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f941Int$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f1005State$Int$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-DiscoveryPacket", Integer.valueOf(f941Int$classDiscoveryPacket));
            f1005State$Int$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$param-discoveryVersion$class-DiscoveredCar", offset = 220)
    /* JADX INFO: renamed from: Int$param-discoveryVersion$class-DiscoveredCar, reason: not valid java name */
    public final int m6462Int$paramdiscoveryVersion$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f942Int$paramdiscoveryVersion$classDiscoveredCar;
        }
        State<Integer> stateLiveLiteral = f1006State$Int$paramdiscoveryVersion$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$param-discoveryVersion$class-DiscoveredCar", Integer.valueOf(f942Int$paramdiscoveryVersion$classDiscoveredCar));
            f1006State$Int$paramdiscoveryVersion$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$param-version$fun-query$class-DiscoveryPacket", offset = 396)
    /* JADX INFO: renamed from: Int$param-version$fun-query$class-DiscoveryPacket, reason: not valid java name */
    public final int m6463Int$paramversion$funquery$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f943Int$paramversion$funquery$classDiscoveryPacket;
        }
        State<Integer> stateLiveLiteral = f1007State$Int$paramversion$funquery$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$param-version$fun-query$class-DiscoveryPacket", Integer.valueOf(f943Int$paramversion$funquery$classDiscoveryPacket));
            f1007State$Int$paramversion$funquery$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-and$$this$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-number$fun-reply$class-DiscoveryPacket", offset = 1529)
    /* JADX INFO: renamed from: Long$arg-0$call-and$$this$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-number$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final long m6464Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f944Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$funreply$classDiscoveryPacket;
        }
        State<Long> stateLiveLiteral = f1008State$Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-and$$this$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-number$fun-reply$class-DiscoveryPacket", Long.valueOf(f944Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$funreply$classDiscoveryPacket));
            f1008State$Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-fold$fun-number$fun-reply$class-DiscoveryPacket", offset = 1457)
    /* JADX INFO: renamed from: Long$arg-0$call-fold$fun-number$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final long m6465Long$arg0$callfold$funnumber$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f945Long$arg0$callfold$funnumber$funreply$classDiscoveryPacket;
        }
        State<Long> stateLiveLiteral = f1009State$Long$arg0$callfold$funnumber$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-fold$fun-number$fun-reply$class-DiscoveryPacket", Long.valueOf(f945Long$arg0$callfold$funnumber$funreply$classDiscoveryPacket));
            f1009State$Long$arg0$callfold$funnumber$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if-2$fun-reply$class-DiscoveryPacket", offset = 1749)
    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if-2$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final long m6466Long$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if2$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f946Long$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if2$funreply$classDiscoveryPacket;
        }
        State<Long> stateLiveLiteral = f1010State$Long$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if2$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if-2$fun-reply$class-DiscoveryPacket", Long.valueOf(f946Long$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if2$funreply$classDiscoveryPacket));
            f1010State$Long$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if2$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-rangeTo$$this$call-contains$cond$arg-0$call-require$fun-query$class-DiscoveryPacket", offset = 440)
    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$cond$arg-0$call-require$fun-query$class-DiscoveryPacket, reason: not valid java name */
    public final long m6467Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$funquery$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f947Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$funquery$classDiscoveryPacket;
        }
        State<Long> stateLiveLiteral = f1011State$Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$funquery$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-rangeTo$$this$call-contains$cond$arg-0$call-require$fun-query$class-DiscoveryPacket", Long.valueOf(f947Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$funquery$classDiscoveryPacket));
            f1011State$Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$funquery$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "String$0$str$fun-$get-name$$get$val-name$class-DiscoveredCar", offset = 255)
    /* JADX INFO: renamed from: String$0$str$fun-$get-name$$get$val-name$class-DiscoveredCar, reason: not valid java name */
    public final String m6468String$0$str$fun$getname$$get$valname$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1031String$0$str$fun$getname$$get$valname$classDiscoveredCar;
        }
        State<String> stateLiveLiteral = f1012State$String$0$str$fun$getname$$get$valname$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$fun-$get-name$$get$val-name$class-DiscoveredCar", f1031String$0$str$fun$getname$$get$valname$classDiscoveredCar);
            f1012State$String$0$str$fun$getname$$get$valname$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$fun-toString$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: String$0$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    public final String m6469String$0$str$funtoString$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1032String$0$str$funtoString$classDiscoveredCar;
        }
        State<String> stateLiveLiteral = f1013State$String$0$str$funtoString$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$fun-toString$class-DiscoveredCar", f1032String$0$str$funtoString$classDiscoveredCar);
            f1013State$String$0$str$funtoString$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$1$str$fun-toString$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: String$1$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    public final String m6470String$1$str$funtoString$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1033String$1$str$funtoString$classDiscoveredCar;
        }
        State<String> stateLiveLiteral = f1014State$String$1$str$funtoString$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$1$str$fun-toString$class-DiscoveredCar", f1033String$1$str$funtoString$classDiscoveredCar);
            f1014State$String$1$str$funtoString$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$10$str$fun-toString$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: String$10$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    public final String m6471String$10$str$funtoString$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1034String$10$str$funtoString$classDiscoveredCar;
        }
        State<String> stateLiveLiteral = f1015State$String$10$str$funtoString$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$10$str$fun-toString$class-DiscoveredCar", f1034String$10$str$funtoString$classDiscoveredCar);
            f1015State$String$10$str$funtoString$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$12$str$fun-toString$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: String$12$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    public final String m6472String$12$str$funtoString$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1035String$12$str$funtoString$classDiscoveredCar;
        }
        State<String> stateLiveLiteral = f1016State$String$12$str$funtoString$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$12$str$fun-toString$class-DiscoveredCar", f1035String$12$str$funtoString$classDiscoveredCar);
            f1016State$String$12$str$funtoString$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$13$str$fun-toString$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: String$13$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    public final String m6473String$13$str$funtoString$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1036String$13$str$funtoString$classDiscoveredCar;
        }
        State<String> stateLiveLiteral = f1017State$String$13$str$funtoString$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$13$str$fun-toString$class-DiscoveredCar", f1036String$13$str$funtoString$classDiscoveredCar);
            f1017State$String$13$str$funtoString$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$15$str$fun-toString$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: String$15$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    public final String m6474String$15$str$funtoString$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1037String$15$str$funtoString$classDiscoveredCar;
        }
        State<String> stateLiveLiteral = f1018State$String$15$str$funtoString$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$15$str$fun-toString$class-DiscoveredCar", f1037String$15$str$funtoString$classDiscoveredCar);
            f1018State$String$15$str$funtoString$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$16$str$fun-toString$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: String$16$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    public final String m6475String$16$str$funtoString$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1038String$16$str$funtoString$classDiscoveredCar;
        }
        State<String> stateLiveLiteral = f1019State$String$16$str$funtoString$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$16$str$fun-toString$class-DiscoveredCar", f1038String$16$str$funtoString$classDiscoveredCar);
            f1019State$String$16$str$funtoString$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$18$str$fun-toString$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: String$18$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    public final String m6476String$18$str$funtoString$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1039String$18$str$funtoString$classDiscoveredCar;
        }
        State<String> stateLiveLiteral = f1020State$String$18$str$funtoString$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$18$str$fun-toString$class-DiscoveredCar", f1039String$18$str$funtoString$classDiscoveredCar);
            f1020State$String$18$str$funtoString$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$3$str$fun-toString$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: String$3$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    public final String m6477String$3$str$funtoString$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1040String$3$str$funtoString$classDiscoveredCar;
        }
        State<String> stateLiveLiteral = f1021State$String$3$str$funtoString$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$3$str$fun-toString$class-DiscoveredCar", f1040String$3$str$funtoString$classDiscoveredCar);
            f1021State$String$3$str$funtoString$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$4$str$fun-toString$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: String$4$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    public final String m6478String$4$str$funtoString$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1041String$4$str$funtoString$classDiscoveredCar;
        }
        State<String> stateLiveLiteral = f1022State$String$4$str$funtoString$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$4$str$fun-toString$class-DiscoveredCar", f1041String$4$str$funtoString$classDiscoveredCar);
            f1022State$String$4$str$funtoString$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$6$str$fun-toString$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: String$6$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    public final String m6479String$6$str$funtoString$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1042String$6$str$funtoString$classDiscoveredCar;
        }
        State<String> stateLiveLiteral = f1023State$String$6$str$funtoString$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$6$str$fun-toString$class-DiscoveredCar", f1042String$6$str$funtoString$classDiscoveredCar);
            f1023State$String$6$str$funtoString$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$7$str$fun-toString$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: String$7$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    public final String m6480String$7$str$funtoString$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1043String$7$str$funtoString$classDiscoveredCar;
        }
        State<String> stateLiveLiteral = f1024State$String$7$str$funtoString$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$7$str$fun-toString$class-DiscoveredCar", f1043String$7$str$funtoString$classDiscoveredCar);
            f1024State$String$7$str$funtoString$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$9$str$fun-toString$class-DiscoveredCar", offset = -2)
    /* JADX INFO: renamed from: String$9$str$fun-toString$class-DiscoveredCar, reason: not valid java name */
    public final String m6481String$9$str$funtoString$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1044String$9$str$funtoString$classDiscoveredCar;
        }
        State<String> stateLiveLiteral = f1025State$String$9$str$funtoString$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$9$str$fun-toString$class-DiscoveredCar", f1044String$9$str$funtoString$classDiscoveredCar);
            f1025State$String$9$str$funtoString$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-1$call-EQEQ$cond$cond$if-3$fun-reply$class-DiscoveryPacket", offset = 1804)
    /* JADX INFO: renamed from: String$arg-1$call-EQEQ$cond$cond$if-3$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final String m6482String$arg1$callEQEQ$cond$cond$if3$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1045String$arg1$callEQEQ$cond$cond$if3$funreply$classDiscoveryPacket;
        }
        State<String> stateLiveLiteral = f1026State$String$arg1$callEQEQ$cond$cond$if3$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-1$call-EQEQ$cond$cond$if-3$fun-reply$class-DiscoveryPacket", f1045String$arg1$callEQEQ$cond$cond$if3$funreply$classDiscoveryPacket);
            f1026State$String$arg1$callEQEQ$cond$cond$if3$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$branch$when$val-transport$fun-reply$class-DiscoveryPacket", offset = 1194)
    /* JADX INFO: renamed from: String$branch$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final String m6483String$branch$when$valtransport$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1046String$branch$when$valtransport$funreply$classDiscoveryPacket;
        }
        State<String> stateLiveLiteral = f1027State$String$branch$when$valtransport$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$branch$when$val-transport$fun-reply$class-DiscoveryPacket", f1046String$branch$when$valtransport$funreply$classDiscoveryPacket);
            f1027State$String$branch$when$valtransport$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$branch-1$when$val-transport$fun-reply$class-DiscoveryPacket", offset = 1264)
    /* JADX INFO: renamed from: String$branch-1$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final String m6484String$branch1$when$valtransport$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1047String$branch1$when$valtransport$funreply$classDiscoveryPacket;
        }
        State<String> stateLiveLiteral = f1028State$String$branch1$when$valtransport$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$branch-1$when$val-transport$fun-reply$class-DiscoveryPacket", f1047String$branch1$when$valtransport$funreply$classDiscoveryPacket);
            f1028State$String$branch1$when$valtransport$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$branch-2$when$val-transport$fun-reply$class-DiscoveryPacket", offset = 1334)
    /* JADX INFO: renamed from: String$branch-2$when$val-transport$fun-reply$class-DiscoveryPacket, reason: not valid java name */
    public final String m6485String$branch2$when$valtransport$funreply$classDiscoveryPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1048String$branch2$when$valtransport$funreply$classDiscoveryPacket;
        }
        State<String> stateLiveLiteral = f1029State$String$branch2$when$valtransport$funreply$classDiscoveryPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$branch-2$when$val-transport$fun-reply$class-DiscoveryPacket", f1048String$branch2$when$valtransport$funreply$classDiscoveryPacket);
            f1029State$String$branch2$when$valtransport$funreply$classDiscoveryPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$param-transport$class-DiscoveredCar", offset = 177)
    /* JADX INFO: renamed from: String$param-transport$class-DiscoveredCar, reason: not valid java name */
    public final String m6486String$paramtransport$classDiscoveredCar() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1049String$paramtransport$classDiscoveredCar;
        }
        State<String> stateLiveLiteral = f1030State$String$paramtransport$classDiscoveredCar;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$param-transport$class-DiscoveredCar", f1049String$paramtransport$classDiscoveredCar);
            f1030State$String$paramtransport$classDiscoveredCar = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
