package vea.raceremote.control;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: DrivingPad.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/control/DrivingPad.kt")
public final class LiveLiterals$DrivingPadKt {

    /* JADX INFO: renamed from: Float$$$this$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if$body$loop$try$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static float f1050Float$$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: Float$arg-0$call-Offset$branch$if$val-delta$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static float f1051Float$arg0$callOffset$branch$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: Float$arg-0$call-coerceAtLeast$val-travel$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static float f1053Float$arg0$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: Float$arg-0$call-coerceIn$arg-0$call-times$else$if$val-amount$body$loop$try$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static float f1054Float$arg0$callcoerceIn$arg0$calltimes$else$if$valamount$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: Float$arg-0$call-invoke$finally$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static float f1060Float$arg0$callinvoke$finally$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: Float$arg-0$call-invoke$try$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static float f1061Float$arg0$callinvoke$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: Float$arg-1$call-Offset$else$if$val-delta$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static float f1063Float$arg1$callOffset$else$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: Float$branch$if$val-amount$body$loop$try$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static float f1065Float$branch$if$valamount$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$Float$$$this$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if$body$loop$try$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<Float> f1075State$Float$$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$Float$arg-0$call-Offset$branch$if$val-delta$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<Float> f1076State$Float$arg0$callOffset$branch$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$Float$arg-0$call-coerceAtLeast$val-travel$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<Float> f1077State$Float$arg0$callcoerceAtLeast$valtravel$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$Float$arg-0$call-coerceAtLeast$val-travel$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<Float> f1078State$Float$arg0$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$Float$arg-0$call-coerceIn$arg-0$call-times$else$if$val-amount$body$loop$try$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<Float> f1079State$Float$arg0$callcoerceIn$arg0$calltimes$else$if$valamount$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$Float$arg-0$call-copy$arg-0$call-background$$$this$call-testTag$$$this$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<Float> f1080State$Float$arg0$callcopy$arg0$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$Float$arg-0$call-copy$arg-0$call-drawCircle$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<Float> f1081State$Float$arg0$callcopy$arg0$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$Float$arg-0$call-copy$arg-0$call-drawLine$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<Float> f1082State$Float$arg0$callcopy$arg0$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$Float$arg-0$call-copy$else$if$val-accent$fun-DrivingPad, reason: not valid java name */
    private static State<Float> f1083State$Float$arg0$callcopy$else$if$valaccent$funDrivingPad;

    /* JADX INFO: renamed from: State$Float$arg-0$call-div$$this$call-minus$$$this$call-coerceAtLeast$val-travel$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<Float> f1084State$Float$arg0$calldiv$$this$callminus$$$this$callcoerceAtLeast$valtravel$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$Float$arg-0$call-invoke$finally$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<Float> f1085State$Float$arg0$callinvoke$finally$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$Float$arg-0$call-invoke$try$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<Float> f1086State$Float$arg0$callinvoke$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$Float$arg-0$call-weight$$$this$call-background$$$this$call-testTag$$$this$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<Float> f1087State$Float$arg0$callweight$$$this$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$Float$arg-1$call-Offset$else$if$val-delta$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<Float> f1088State$Float$arg1$callOffset$else$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$Float$arg-1$call-coerceIn$arg-0$call-times$else$if$val-amount$body$loop$try$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<Float> f1089State$Float$arg1$callcoerceIn$arg0$calltimes$else$if$valamount$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$Float$branch$if$val-amount$body$loop$try$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<Float> f1090State$Float$branch$if$valamount$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$Int$$$this$call-$get-dp$$$$this$call-toPx$arg-0$call-minus$$$this$call-coerceAtLeast$val-travel$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<Integer> f1091State$Int$$$this$call$getdp$$$$this$calltoPx$arg0$callminus$$$this$callcoerceAtLeast$valtravel$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$Int$$$this$call-$get-dp$$$$this$call-toPx$arg-0$call-minus$$$this$call-coerceAtLeast$val-travel$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<Integer> f1092State$Int$$$this$call$getdp$$$$this$calltoPx$arg0$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$Int$$$this$call-$get-dp$$$$this$call-toPx$arg-1$call-drawCircle$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<Integer> f1093State$Int$$$this$call$getdp$$$$this$calltoPx$arg1$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$Int$$$this$call-$get-dp$$$$this$call-toPx$arg-3$call-drawLine$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<Integer> f1094State$Int$$$this$call$getdp$$$$this$calltoPx$arg3$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$Int$$$this$call-$get-dp$$$$this$call-toPx$val-radius$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<Integer> f1095State$Int$$$this$call$getdp$$$$this$calltoPx$valradius$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$Int$$$this$call-$get-dp$$arg-0$call-RoundedCornerShape$arg-1$call-background$$$this$call-testTag$$$this$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<Integer> f1096State$Int$$$this$call$getdp$$arg0$callRoundedCornerShape$arg1$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$Int$arg-0$call-div$$this$call-minus$$this$call-minus$$$this$call-coerceAtLeast$val-travel$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<Integer> f1097State$Int$arg0$calldiv$$this$callminus$$this$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$Int$arg-0$call-div$arg-0$call-coerceAtMost$val-deadZone$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<Integer> f1098State$Int$arg0$calldiv$arg0$callcoerceAtMost$valdeadZone$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-toInt$0$str$arg-0$call-$set-stateDescription$$fun-$anonymous$$arg-1$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<Integer> f1099State$Int$arg0$calltimes$$this$calltoInt$0$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$String$1$str$arg-0$call-$set-contentDescription$$fun-$anonymous$$arg-1$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<String> f1100State$String$1$str$arg0$call$setcontentDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$String$1$str$arg-0$call-$set-stateDescription$$fun-$anonymous$$arg-1$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<String> f1101State$String$1$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$String$branch$if$arg-0$call-Text-1$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<String> f1102State$String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$String$branch$if$arg-0$call-testTag$$$this$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<String> f1103State$String$branch$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$String$else$if$arg-0$call-Text-1$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<String> f1104State$String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad;

    /* JADX INFO: renamed from: State$String$else$if$arg-0$call-testTag$$$this$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static State<String> f1105State$String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
    public static final LiveLiterals$DrivingPadKt INSTANCE = new LiveLiterals$DrivingPadKt();

    /* JADX INFO: renamed from: Float$arg-0$call-copy$else$if$val-accent$fun-DrivingPad, reason: not valid java name */
    private static float f1058Float$arg0$callcopy$else$if$valaccent$funDrivingPad = 0.3f;

    /* JADX INFO: renamed from: Float$arg-0$call-weight$$$this$call-background$$$this$call-testTag$$$this$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static float f1062Float$arg0$callweight$$$this$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = 1.0f;

    /* JADX INFO: renamed from: Float$arg-0$call-copy$arg-0$call-background$$$this$call-testTag$$$this$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static float f1055Float$arg0$callcopy$arg0$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = 0.06f;

    /* JADX INFO: renamed from: Int$$$this$call-$get-dp$$arg-0$call-RoundedCornerShape$arg-1$call-background$$$this$call-testTag$$$this$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static int f1071Int$$$this$call$getdp$$arg0$callRoundedCornerShape$arg1$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = 16;

    /* JADX INFO: renamed from: String$branch$if$arg-0$call-testTag$$$this$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static String f1109String$branch$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = "drive_throttle";

    /* JADX INFO: renamed from: String$else$if$arg-0$call-testTag$$$this$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static String f1111String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = "drive_steering";

    /* JADX INFO: renamed from: String$1$str$arg-0$call-$set-contentDescription$$fun-$anonymous$$arg-1$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static String f1106String$1$str$arg0$call$setcontentDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = ": удерживай и двигай палец; отпусти для нейтрали";

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-toInt$0$str$arg-0$call-$set-stateDescription$$fun-$anonymous$$arg-1$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static int f1074Int$arg0$calltimes$$this$calltoInt$0$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = 100;

    /* JADX INFO: renamed from: String$1$str$arg-0$call-$set-stateDescription$$fun-$anonymous$$arg-1$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static String f1107String$1$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = "%";

    /* JADX INFO: renamed from: Float$arg-0$call-div$$this$call-minus$$$this$call-coerceAtLeast$val-travel$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static float f1059Float$arg0$calldiv$$this$callminus$$$this$callcoerceAtLeast$valtravel$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = 2.0f;

    /* JADX INFO: renamed from: Int$$$this$call-$get-dp$$$$this$call-toPx$arg-0$call-minus$$$this$call-coerceAtLeast$val-travel$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static int f1066Int$$$this$call$getdp$$$$this$calltoPx$arg0$callminus$$$this$callcoerceAtLeast$valtravel$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = 24;

    /* JADX INFO: renamed from: Float$arg-0$call-coerceAtLeast$val-travel$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static float f1052Float$arg0$callcoerceAtLeast$valtravel$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = 1.0f;

    /* JADX INFO: renamed from: Int$arg-0$call-div$arg-0$call-coerceAtMost$val-deadZone$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static int f1073Int$arg0$calldiv$arg0$callcoerceAtMost$valdeadZone$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = 3;

    /* JADX INFO: renamed from: Float$arg-1$call-coerceIn$arg-0$call-times$else$if$val-amount$body$loop$try$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static float f1064Float$arg1$callcoerceIn$arg0$calltimes$else$if$valamount$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = 1.0f;

    /* JADX INFO: renamed from: Int$$$this$call-$get-dp$$$$this$call-toPx$val-radius$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static int f1070Int$$$this$call$getdp$$$$this$calltoPx$valradius$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = 20;

    /* JADX INFO: renamed from: Int$arg-0$call-div$$this$call-minus$$this$call-minus$$$this$call-coerceAtLeast$val-travel$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static int f1072Int$arg0$calldiv$$this$callminus$$this$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = 2;

    /* JADX INFO: renamed from: Int$$$this$call-$get-dp$$$$this$call-toPx$arg-0$call-minus$$$this$call-coerceAtLeast$val-travel$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static int f1067Int$$$this$call$getdp$$$$this$calltoPx$arg0$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = 4;

    /* JADX INFO: renamed from: Float$arg-0$call-copy$arg-0$call-drawLine$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static float f1057Float$arg0$callcopy$arg0$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = 0.3f;

    /* JADX INFO: renamed from: Int$$$this$call-$get-dp$$$$this$call-toPx$arg-3$call-drawLine$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static int f1069Int$$$this$call$getdp$$$$this$calltoPx$arg3$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = 4;

    /* JADX INFO: renamed from: Float$arg-0$call-copy$arg-0$call-drawCircle$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static float f1056Float$arg0$callcopy$arg0$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = 0.3f;

    /* JADX INFO: renamed from: Int$$$this$call-$get-dp$$$$this$call-toPx$arg-1$call-drawCircle$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static int f1068Int$$$this$call$getdp$$$$this$calltoPx$arg1$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = 5;

    /* JADX INFO: renamed from: String$branch$if$arg-0$call-Text-1$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static String f1108String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = "↑ вперёд · ↓ назад";

    /* JADX INFO: renamed from: String$else$if$arg-0$call-Text-1$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    private static String f1110String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = "← влево · вправо →";

    @LiveLiteralInfo(key = "Float$$$this$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if$body$loop$try$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 2925)
    /* JADX INFO: renamed from: Float$$$this$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if$body$loop$try$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final float m6487Float$$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1050Float$$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<Float> stateLiveLiteral = f1075State$Float$$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$$$this$call-rangeTo$$this$call-contains$$this$call-not$else$cond$if$body$loop$try$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", Float.valueOf(f1050Float$$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad));
            f1075State$Float$$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-Offset$branch$if$val-delta$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 4062)
    /* JADX INFO: renamed from: Float$arg-0$call-Offset$branch$if$val-delta$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final float m6488Float$arg0$callOffset$branch$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1051Float$arg0$callOffset$branch$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<Float> stateLiveLiteral = f1076State$Float$arg0$callOffset$branch$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-Offset$branch$if$val-delta$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", Float.valueOf(f1051Float$arg0$callOffset$branch$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad));
            f1076State$Float$arg0$callOffset$branch$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-coerceAtLeast$val-travel$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 2332)
    /* JADX INFO: renamed from: Float$arg-0$call-coerceAtLeast$val-travel$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final float m6489Float$arg0$callcoerceAtLeast$valtravel$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1052Float$arg0$callcoerceAtLeast$valtravel$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<Float> stateLiveLiteral = f1077State$Float$arg0$callcoerceAtLeast$valtravel$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-coerceAtLeast$val-travel$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", Float.valueOf(f1052Float$arg0$callcoerceAtLeast$valtravel$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad));
            f1077State$Float$arg0$callcoerceAtLeast$valtravel$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-coerceAtLeast$val-travel$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 4013)
    /* JADX INFO: renamed from: Float$arg-0$call-coerceAtLeast$val-travel$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final float m6490Float$arg0$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1053Float$arg0$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<Float> stateLiveLiteral = f1078State$Float$arg0$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-coerceAtLeast$val-travel$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", Float.valueOf(f1053Float$arg0$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad));
            f1078State$Float$arg0$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-coerceIn$arg-0$call-times$else$if$val-amount$body$loop$try$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 3279)
    /* JADX INFO: renamed from: Float$arg-0$call-coerceIn$arg-0$call-times$else$if$val-amount$body$loop$try$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final float m6491Float$arg0$callcoerceIn$arg0$calltimes$else$if$valamount$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1054Float$arg0$callcoerceIn$arg0$calltimes$else$if$valamount$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<Float> stateLiveLiteral = f1079State$Float$arg0$callcoerceIn$arg0$calltimes$else$if$valamount$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-coerceIn$arg-0$call-times$else$if$val-amount$body$loop$try$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", Float.valueOf(f1054Float$arg0$callcoerceIn$arg0$calltimes$else$if$valamount$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad));
            f1079State$Float$arg0$callcoerceIn$arg0$calltimes$else$if$valamount$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-copy$arg-0$call-background$$$this$call-testTag$$$this$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 1554)
    /* JADX INFO: renamed from: Float$arg-0$call-copy$arg-0$call-background$$$this$call-testTag$$$this$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final float m6492Float$arg0$callcopy$arg0$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1055Float$arg0$callcopy$arg0$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<Float> stateLiveLiteral = f1080State$Float$arg0$callcopy$arg0$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-copy$arg-0$call-background$$$this$call-testTag$$$this$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", Float.valueOf(f1055Float$arg0$callcopy$arg0$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad));
            f1080State$Float$arg0$callcopy$arg0$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-copy$arg-0$call-drawCircle$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 4234)
    /* JADX INFO: renamed from: Float$arg-0$call-copy$arg-0$call-drawCircle$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final float m6493Float$arg0$callcopy$arg0$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1056Float$arg0$callcopy$arg0$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<Float> stateLiveLiteral = f1081State$Float$arg0$callcopy$arg0$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-copy$arg-0$call-drawCircle$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", Float.valueOf(f1056Float$arg0$callcopy$arg0$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad));
            f1081State$Float$arg0$callcopy$arg0$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-copy$arg-0$call-drawLine$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 4140)
    /* JADX INFO: renamed from: Float$arg-0$call-copy$arg-0$call-drawLine$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final float m6494Float$arg0$callcopy$arg0$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1057Float$arg0$callcopy$arg0$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<Float> stateLiveLiteral = f1082State$Float$arg0$callcopy$arg0$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-copy$arg-0$call-drawLine$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", Float.valueOf(f1057Float$arg0$callcopy$arg0$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad));
            f1082State$Float$arg0$callcopy$arg0$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-copy$else$if$val-accent$fun-DrivingPad", offset = 1336)
    /* JADX INFO: renamed from: Float$arg-0$call-copy$else$if$val-accent$fun-DrivingPad, reason: not valid java name */
    public final float m6495Float$arg0$callcopy$else$if$valaccent$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1058Float$arg0$callcopy$else$if$valaccent$funDrivingPad;
        }
        State<Float> stateLiveLiteral = f1083State$Float$arg0$callcopy$else$if$valaccent$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-copy$else$if$val-accent$fun-DrivingPad", Float.valueOf(f1058Float$arg0$callcopy$else$if$valaccent$funDrivingPad));
            f1083State$Float$arg0$callcopy$else$if$valaccent$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-div$$this$call-minus$$$this$call-coerceAtLeast$val-travel$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 2299)
    /* JADX INFO: renamed from: Float$arg-0$call-div$$this$call-minus$$$this$call-coerceAtLeast$val-travel$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final float m6496Float$arg0$calldiv$$this$callminus$$$this$callcoerceAtLeast$valtravel$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1059Float$arg0$calldiv$$this$callminus$$$this$callcoerceAtLeast$valtravel$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<Float> stateLiveLiteral = f1084State$Float$arg0$calldiv$$this$callminus$$$this$callcoerceAtLeast$valtravel$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-div$$this$call-minus$$$this$call-coerceAtLeast$val-travel$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", Float.valueOf(f1059Float$arg0$calldiv$$this$callminus$$$this$callcoerceAtLeast$valtravel$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad));
            f1084State$Float$arg0$calldiv$$this$callminus$$$this$callcoerceAtLeast$valtravel$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-invoke$finally$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 3588)
    /* JADX INFO: renamed from: Float$arg-0$call-invoke$finally$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final float m6497Float$arg0$callinvoke$finally$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1060Float$arg0$callinvoke$finally$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<Float> stateLiveLiteral = f1085State$Float$arg0$callinvoke$finally$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-invoke$finally$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", Float.valueOf(f1060Float$arg0$callinvoke$finally$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad));
            f1085State$Float$arg0$callinvoke$finally$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-invoke$try$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 2493)
    /* JADX INFO: renamed from: Float$arg-0$call-invoke$try$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final float m6498Float$arg0$callinvoke$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1061Float$arg0$callinvoke$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<Float> stateLiveLiteral = f1086State$Float$arg0$callinvoke$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-invoke$try$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", Float.valueOf(f1061Float$arg0$callinvoke$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad));
            f1086State$Float$arg0$callinvoke$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-weight$$$this$call-background$$$this$call-testTag$$$this$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 1482)
    /* JADX INFO: renamed from: Float$arg-0$call-weight$$$this$call-background$$$this$call-testTag$$$this$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final float m6499Float$arg0$callweight$$$this$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1062Float$arg0$callweight$$$this$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<Float> stateLiveLiteral = f1087State$Float$arg0$callweight$$$this$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-weight$$$this$call-background$$$this$call-testTag$$$this$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", Float.valueOf(f1062Float$arg0$callweight$$$this$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad));
            f1087State$Float$arg0$callweight$$$this$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-1$call-Offset$else$if$val-delta$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 4095)
    /* JADX INFO: renamed from: Float$arg-1$call-Offset$else$if$val-delta$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final float m6500Float$arg1$callOffset$else$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1063Float$arg1$callOffset$else$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<Float> stateLiveLiteral = f1088State$Float$arg1$callOffset$else$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-1$call-Offset$else$if$val-delta$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", Float.valueOf(f1063Float$arg1$callOffset$else$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad));
            f1088State$Float$arg1$callOffset$else$if$valdelta$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-1$call-coerceIn$arg-0$call-times$else$if$val-amount$body$loop$try$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 3283)
    /* JADX INFO: renamed from: Float$arg-1$call-coerceIn$arg-0$call-times$else$if$val-amount$body$loop$try$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final float m6501Float$arg1$callcoerceIn$arg0$calltimes$else$if$valamount$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1064Float$arg1$callcoerceIn$arg0$calltimes$else$if$valamount$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<Float> stateLiveLiteral = f1089State$Float$arg1$callcoerceIn$arg0$calltimes$else$if$valamount$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-1$call-coerceIn$arg-0$call-times$else$if$val-amount$body$loop$try$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", Float.valueOf(f1064Float$arg1$callcoerceIn$arg0$calltimes$else$if$valamount$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad));
            f1089State$Float$arg1$callcoerceIn$arg0$calltimes$else$if$valamount$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$branch$if$val-amount$body$loop$try$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 3158)
    /* JADX INFO: renamed from: Float$branch$if$val-amount$body$loop$try$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final float m6502Float$branch$if$valamount$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1065Float$branch$if$valamount$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<Float> stateLiveLiteral = f1090State$Float$branch$if$valamount$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$branch$if$val-amount$body$loop$try$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", Float.valueOf(f1065Float$branch$if$valamount$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad));
            f1090State$Float$branch$if$valamount$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Int$$$this$call-$get-dp$$$$this$call-toPx$arg-0$call-minus$$$this$call-coerceAtLeast$val-travel$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 2304)
    /* JADX INFO: renamed from: Int$$$this$call-$get-dp$$$$this$call-toPx$arg-0$call-minus$$$this$call-coerceAtLeast$val-travel$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final int m6503Int$$$this$call$getdp$$$$this$calltoPx$arg0$callminus$$$this$callcoerceAtLeast$valtravel$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1066Int$$$this$call$getdp$$$$this$calltoPx$arg0$callminus$$$this$callcoerceAtLeast$valtravel$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<Integer> stateLiveLiteral = f1091State$Int$$$this$call$getdp$$$$this$calltoPx$arg0$callminus$$$this$callcoerceAtLeast$valtravel$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$$this$call-$get-dp$$$$this$call-toPx$arg-0$call-minus$$$this$call-coerceAtLeast$val-travel$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", Integer.valueOf(f1066Int$$$this$call$getdp$$$$this$calltoPx$arg0$callminus$$$this$callcoerceAtLeast$valtravel$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad));
            f1091State$Int$$$this$call$getdp$$$$this$calltoPx$arg0$callminus$$$this$callcoerceAtLeast$valtravel$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$$this$call-$get-dp$$$$this$call-toPx$arg-0$call-minus$$$this$call-coerceAtLeast$val-travel$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 3986)
    /* JADX INFO: renamed from: Int$$$this$call-$get-dp$$$$this$call-toPx$arg-0$call-minus$$$this$call-coerceAtLeast$val-travel$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final int m6504Int$$$this$call$getdp$$$$this$calltoPx$arg0$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1067Int$$$this$call$getdp$$$$this$calltoPx$arg0$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<Integer> stateLiveLiteral = f1092State$Int$$$this$call$getdp$$$$this$calltoPx$arg0$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$$this$call-$get-dp$$$$this$call-toPx$arg-0$call-minus$$$this$call-coerceAtLeast$val-travel$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", Integer.valueOf(f1067Int$$$this$call$getdp$$$$this$calltoPx$arg0$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad));
            f1092State$Int$$$this$call$getdp$$$$this$calltoPx$arg0$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$$this$call-$get-dp$$$$this$call-toPx$arg-1$call-drawCircle$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 4240)
    /* JADX INFO: renamed from: Int$$$this$call-$get-dp$$$$this$call-toPx$arg-1$call-drawCircle$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final int m6505Int$$$this$call$getdp$$$$this$calltoPx$arg1$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1068Int$$$this$call$getdp$$$$this$calltoPx$arg1$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<Integer> stateLiveLiteral = f1093State$Int$$$this$call$getdp$$$$this$calltoPx$arg1$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$$this$call-$get-dp$$$$this$call-toPx$arg-1$call-drawCircle$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", Integer.valueOf(f1068Int$$$this$call$getdp$$$$this$calltoPx$arg1$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad));
            f1093State$Int$$$this$call$getdp$$$$this$calltoPx$arg1$calldrawCircle$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$$this$call-$get-dp$$$$this$call-toPx$arg-3$call-drawLine$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 4178)
    /* JADX INFO: renamed from: Int$$$this$call-$get-dp$$$$this$call-toPx$arg-3$call-drawLine$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final int m6506Int$$$this$call$getdp$$$$this$calltoPx$arg3$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1069Int$$$this$call$getdp$$$$this$calltoPx$arg3$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<Integer> stateLiveLiteral = f1094State$Int$$$this$call$getdp$$$$this$calltoPx$arg3$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$$this$call-$get-dp$$$$this$call-toPx$arg-3$call-drawLine$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", Integer.valueOf(f1069Int$$$this$call$getdp$$$$this$calltoPx$arg3$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad));
            f1094State$Int$$$this$call$getdp$$$$this$calltoPx$arg3$calldrawLine$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$$this$call-$get-dp$$$$this$call-toPx$val-radius$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 3888)
    /* JADX INFO: renamed from: Int$$$this$call-$get-dp$$$$this$call-toPx$val-radius$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final int m6507Int$$$this$call$getdp$$$$this$calltoPx$valradius$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1070Int$$$this$call$getdp$$$$this$calltoPx$valradius$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<Integer> stateLiveLiteral = f1095State$Int$$$this$call$getdp$$$$this$calltoPx$valradius$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$$this$call-$get-dp$$$$this$call-toPx$val-radius$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", Integer.valueOf(f1070Int$$$this$call$getdp$$$$this$calltoPx$valradius$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad));
            f1095State$Int$$$this$call$getdp$$$$this$calltoPx$valradius$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$$this$call-$get-dp$$arg-0$call-RoundedCornerShape$arg-1$call-background$$$this$call-testTag$$$this$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 1580)
    /* JADX INFO: renamed from: Int$$$this$call-$get-dp$$arg-0$call-RoundedCornerShape$arg-1$call-background$$$this$call-testTag$$$this$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final int m6508Int$$$this$call$getdp$$arg0$callRoundedCornerShape$arg1$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1071Int$$$this$call$getdp$$arg0$callRoundedCornerShape$arg1$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<Integer> stateLiveLiteral = f1096State$Int$$$this$call$getdp$$arg0$callRoundedCornerShape$arg1$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$$this$call-$get-dp$$arg-0$call-RoundedCornerShape$arg-1$call-background$$$this$call-testTag$$$this$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", Integer.valueOf(f1071Int$$$this$call$getdp$$arg0$callRoundedCornerShape$arg1$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad));
            f1096State$Int$$$this$call$getdp$$arg0$callRoundedCornerShape$arg1$callbackground$$$this$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-div$$this$call-minus$$this$call-minus$$$this$call-coerceAtLeast$val-travel$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 3973)
    /* JADX INFO: renamed from: Int$arg-0$call-div$$this$call-minus$$this$call-minus$$$this$call-coerceAtLeast$val-travel$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final int m6509Int$arg0$calldiv$$this$callminus$$this$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1072Int$arg0$calldiv$$this$callminus$$this$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<Integer> stateLiveLiteral = f1097State$Int$arg0$calldiv$$this$callminus$$this$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-div$$this$call-minus$$this$call-minus$$$this$call-coerceAtLeast$val-travel$fun-$anonymous$$arg-1$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", Integer.valueOf(f1072Int$arg0$calldiv$$this$callminus$$this$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad));
            f1097State$Int$arg0$calldiv$$this$callminus$$this$callminus$$$this$callcoerceAtLeast$valtravel$fun$anonymous$$arg1$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-div$arg-0$call-coerceAtMost$val-deadZone$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 2425)
    /* JADX INFO: renamed from: Int$arg-0$call-div$arg-0$call-coerceAtMost$val-deadZone$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final int m6510Int$arg0$calldiv$arg0$callcoerceAtMost$valdeadZone$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1073Int$arg0$calldiv$arg0$callcoerceAtMost$valdeadZone$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<Integer> stateLiveLiteral = f1098State$Int$arg0$calldiv$arg0$callcoerceAtMost$valdeadZone$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-div$arg-0$call-coerceAtMost$val-deadZone$body$loop$fun-$anonymous$$arg-0$call-awaitPointerEventScope$fun-$anonymous$$arg-2$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", Integer.valueOf(f1073Int$arg0$calldiv$arg0$callcoerceAtMost$valdeadZone$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad));
            f1098State$Int$arg0$calldiv$arg0$callcoerceAtMost$valdeadZone$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-toInt$0$str$arg-0$call-$set-stateDescription$$fun-$anonymous$$arg-1$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 1829)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-toInt$0$str$arg-0$call-$set-stateDescription$$fun-$anonymous$$arg-1$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final int m6511Int$arg0$calltimes$$this$calltoInt$0$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1074Int$arg0$calltimes$$this$calltoInt$0$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<Integer> stateLiveLiteral = f1099State$Int$arg0$calltimes$$this$calltoInt$0$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-toInt$0$str$arg-0$call-$set-stateDescription$$fun-$anonymous$$arg-1$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", Integer.valueOf(f1074Int$arg0$calltimes$$this$calltoInt$0$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad));
            f1099State$Int$arg0$calltimes$$this$calltoInt$0$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "String$1$str$arg-0$call-$set-contentDescription$$fun-$anonymous$$arg-1$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 1732)
    /* JADX INFO: renamed from: String$1$str$arg-0$call-$set-contentDescription$$fun-$anonymous$$arg-1$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final String m6512String$1$str$arg0$call$setcontentDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1106String$1$str$arg0$call$setcontentDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<String> stateLiveLiteral = f1100State$String$1$str$arg0$call$setcontentDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$1$str$arg-0$call-$set-contentDescription$$fun-$anonymous$$arg-1$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", f1106String$1$str$arg0$call$setcontentDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad);
            f1100State$String$1$str$arg0$call$setcontentDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$1$str$arg-0$call-$set-stateDescription$$fun-$anonymous$$arg-1$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 1842)
    /* JADX INFO: renamed from: String$1$str$arg-0$call-$set-stateDescription$$fun-$anonymous$$arg-1$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final String m6513String$1$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1107String$1$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<String> stateLiveLiteral = f1101State$String$1$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$1$str$arg-0$call-$set-stateDescription$$fun-$anonymous$$arg-1$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", f1107String$1$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad);
            f1101State$String$1$str$arg0$call$setstateDescription$$fun$anonymous$$arg1$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$branch$if$arg-0$call-Text-1$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 4362)
    /* JADX INFO: renamed from: String$branch$if$arg-0$call-Text-1$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final String m6514String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1108String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<String> stateLiveLiteral = f1102State$String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$branch$if$arg-0$call-Text-1$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", f1108String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad);
            f1102State$String$branch$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$branch$if$arg-0$call-testTag$$$this$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 1624)
    /* JADX INFO: renamed from: String$branch$if$arg-0$call-testTag$$$this$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final String m6515String$branch$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1109String$branch$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<String> stateLiveLiteral = f1103State$String$branch$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$branch$if$arg-0$call-testTag$$$this$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", f1109String$branch$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad);
            f1103State$String$branch$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$else$if$arg-0$call-Text-1$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 4388)
    /* JADX INFO: renamed from: String$else$if$arg-0$call-Text-1$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final String m6516String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1110String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<String> stateLiveLiteral = f1104State$String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$else$if$arg-0$call-Text-1$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", f1110String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad);
            f1104State$String$else$if$arg0$callText1$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$else$if$arg-0$call-testTag$$$this$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", offset = 1646)
    /* JADX INFO: renamed from: String$else$if$arg-0$call-testTag$$$this$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad, reason: not valid java name */
    public final String m6517String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1111String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        }
        State<String> stateLiveLiteral = f1105State$String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$else$if$arg-0$call-testTag$$$this$call-semantics$$$this$call-pointerInput$arg-0$call-Canvas$fun-$anonymous$$arg-3$call-Column$fun-DrivingPad", f1111String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad);
            f1105State$String$else$if$arg0$calltestTag$$$this$callsemantics$$$this$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
