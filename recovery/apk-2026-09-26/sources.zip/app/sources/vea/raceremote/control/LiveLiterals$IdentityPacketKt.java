package vea.raceremote.control;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: IdentityPacket.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/control/IdentityPacket.kt")
public final class LiveLiterals$IdentityPacketKt {

    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-CarIdentity, reason: not valid java name */
    private static boolean f1113Boolean$branch$when1$funequals$classCarIdentity;

    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-CarIdentity, reason: not valid java name */
    private static boolean f1114Boolean$branch$when2$funequals$classCarIdentity;

    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-CarIdentity, reason: not valid java name */
    private static boolean f1115Boolean$branch$when3$funequals$classCarIdentity;

    /* JADX INFO: renamed from: Int$$$this$call-until$$$this$call-fold$fun-number$fun-decode$class-IdentityPacket, reason: not valid java name */
    private static int f1117Int$$$this$calluntil$$$this$callfold$funnumber$fundecode$classIdentityPacket;

    /* JADX INFO: renamed from: Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-IdentityPacket, reason: not valid java name */
    private static int f1119Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$fundecode$classIdentityPacket;

    /* JADX INFO: renamed from: Int$class-CarIdentity, reason: not valid java name */
    private static int f1126Int$classCarIdentity;

    /* JADX INFO: renamed from: Int$class-IdentityPacket, reason: not valid java name */
    private static int f1127Int$classIdentityPacket;

    /* JADX INFO: renamed from: Long$arg-0$call-fold$fun-number$fun-decode$class-IdentityPacket, reason: not valid java name */
    private static long f1129Long$arg0$callfold$funnumber$fundecode$classIdentityPacket;

    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$$this$call-not$branch$cond$if-1$fun-decode$class-IdentityPacket, reason: not valid java name */
    private static long f1130Long$arg1$callEQEQ$$this$callnot$branch$cond$if1$fundecode$classIdentityPacket;

    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$$this$call-not$cond$cond$if-1$fun-decode$class-IdentityPacket, reason: not valid java name */
    private static long f1131Long$arg1$callEQEQ$$this$callnot$cond$cond$if1$fundecode$classIdentityPacket;

    /* JADX INFO: renamed from: State$Boolean$branch$when$fun-equals$class-CarIdentity, reason: not valid java name */
    private static State<Boolean> f1132State$Boolean$branch$when$funequals$classCarIdentity;

    /* JADX INFO: renamed from: State$Boolean$branch$when-1$fun-equals$class-CarIdentity, reason: not valid java name */
    private static State<Boolean> f1133State$Boolean$branch$when1$funequals$classCarIdentity;

    /* JADX INFO: renamed from: State$Boolean$branch$when-2$fun-equals$class-CarIdentity, reason: not valid java name */
    private static State<Boolean> f1134State$Boolean$branch$when2$funequals$classCarIdentity;

    /* JADX INFO: renamed from: State$Boolean$branch$when-3$fun-equals$class-CarIdentity, reason: not valid java name */
    private static State<Boolean> f1135State$Boolean$branch$when3$funequals$classCarIdentity;

    /* JADX INFO: renamed from: State$Boolean$fun-equals$class-CarIdentity, reason: not valid java name */
    private static State<Boolean> f1136State$Boolean$funequals$classCarIdentity;

    /* JADX INFO: renamed from: State$Int$$$this$call-until$$$this$call-fold$fun-number$fun-decode$class-IdentityPacket, reason: not valid java name */
    private static State<Integer> f1137State$Int$$$this$calluntil$$$this$callfold$funnumber$fundecode$classIdentityPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-times$arg-0$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-number$fun-decode$class-IdentityPacket, reason: not valid java name */
    private static State<Integer> f1138State$Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$fundecode$classIdentityPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-IdentityPacket, reason: not valid java name */
    private static State<Integer> f1139State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$fundecode$classIdentityPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-IdentityPacket, reason: not valid java name */
    private static State<Integer> f1140State$Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$fundecode$classIdentityPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-number$val-chipId$fun-decode$class-IdentityPacket, reason: not valid java name */
    private static State<Integer> f1141State$Int$arg0$callnumber$valchipId$fundecode$classIdentityPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-number$val-token$fun-decode$class-IdentityPacket, reason: not valid java name */
    private static State<Integer> f1142State$Int$arg0$callnumber$valtoken$fundecode$classIdentityPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-CarIdentity, reason: not valid java name */
    private static State<Integer> f1143State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCarIdentity;

    /* JADX INFO: renamed from: State$Int$arg-1$call-number$val-chipId$fun-decode$class-IdentityPacket, reason: not valid java name */
    private static State<Integer> f1144State$Int$arg1$callnumber$valchipId$fundecode$classIdentityPacket;

    /* JADX INFO: renamed from: State$Int$arg-1$call-number$val-token$fun-decode$class-IdentityPacket, reason: not valid java name */
    private static State<Integer> f1145State$Int$arg1$callnumber$valtoken$fundecode$classIdentityPacket;

    /* JADX INFO: renamed from: State$Int$class-CarIdentity, reason: not valid java name */
    private static State<Integer> f1146State$Int$classCarIdentity;

    /* JADX INFO: renamed from: State$Int$class-IdentityPacket, reason: not valid java name */
    private static State<Integer> f1147State$Int$classIdentityPacket;

    /* JADX INFO: renamed from: State$Long$arg-0$call-and$$this$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-number$fun-decode$class-IdentityPacket, reason: not valid java name */
    private static State<Long> f1148State$Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$fundecode$classIdentityPacket;

    /* JADX INFO: renamed from: State$Long$arg-0$call-fold$fun-number$fun-decode$class-IdentityPacket, reason: not valid java name */
    private static State<Long> f1149State$Long$arg0$callfold$funnumber$fundecode$classIdentityPacket;

    /* JADX INFO: renamed from: State$Long$arg-1$call-EQEQ$$this$call-not$branch$cond$if-1$fun-decode$class-IdentityPacket, reason: not valid java name */
    private static State<Long> f1150State$Long$arg1$callEQEQ$$this$callnot$branch$cond$if1$fundecode$classIdentityPacket;

    /* JADX INFO: renamed from: State$Long$arg-1$call-EQEQ$$this$call-not$cond$cond$if-1$fun-decode$class-IdentityPacket, reason: not valid java name */
    private static State<Long> f1151State$Long$arg1$callEQEQ$$this$callnot$cond$cond$if1$fundecode$classIdentityPacket;

    /* JADX INFO: renamed from: State$String$0$str$fun-toString$class-CarIdentity, reason: not valid java name */
    private static State<String> f1152State$String$0$str$funtoString$classCarIdentity;

    /* JADX INFO: renamed from: State$String$1$str$fun-toString$class-CarIdentity, reason: not valid java name */
    private static State<String> f1153State$String$1$str$funtoString$classCarIdentity;

    /* JADX INFO: renamed from: State$String$3$str$fun-toString$class-CarIdentity, reason: not valid java name */
    private static State<String> f1154State$String$3$str$funtoString$classCarIdentity;

    /* JADX INFO: renamed from: State$String$4$str$fun-toString$class-CarIdentity, reason: not valid java name */
    private static State<String> f1155State$String$4$str$funtoString$classCarIdentity;

    /* JADX INFO: renamed from: State$String$6$str$fun-toString$class-CarIdentity, reason: not valid java name */
    private static State<String> f1156State$String$6$str$funtoString$classCarIdentity;
    public static final LiveLiterals$IdentityPacketKt INSTANCE = new LiveLiterals$IdentityPacketKt();

    /* JADX INFO: renamed from: String$0$str$fun-toString$class-CarIdentity, reason: not valid java name */
    private static String f1157String$0$str$funtoString$classCarIdentity = "CarIdentity(";

    /* JADX INFO: renamed from: String$1$str$fun-toString$class-CarIdentity, reason: not valid java name */
    private static String f1158String$1$str$funtoString$classCarIdentity = "token=";

    /* JADX INFO: renamed from: String$3$str$fun-toString$class-CarIdentity, reason: not valid java name */
    private static String f1159String$3$str$funtoString$classCarIdentity = ", ";

    /* JADX INFO: renamed from: String$4$str$fun-toString$class-CarIdentity, reason: not valid java name */
    private static String f1160String$4$str$funtoString$classCarIdentity = "chipId=";

    /* JADX INFO: renamed from: String$6$str$fun-toString$class-CarIdentity, reason: not valid java name */
    private static String f1161String$6$str$funtoString$classCarIdentity = ")";

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-CarIdentity, reason: not valid java name */
    private static int f1123Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCarIdentity = 31;

    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-CarIdentity, reason: not valid java name */
    private static boolean f1112Boolean$branch$when$funequals$classCarIdentity = true;

    /* JADX INFO: renamed from: Boolean$fun-equals$class-CarIdentity, reason: not valid java name */
    private static boolean f1116Boolean$funequals$classCarIdentity = true;

    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-IdentityPacket, reason: not valid java name */
    private static int f1120Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$fundecode$classIdentityPacket = 15;

    /* JADX INFO: renamed from: Long$arg-0$call-and$$this$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-number$fun-decode$class-IdentityPacket, reason: not valid java name */
    private static long f1128Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$fundecode$classIdentityPacket = 255;

    /* JADX INFO: renamed from: Int$$this$call-times$arg-0$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-number$fun-decode$class-IdentityPacket, reason: not valid java name */
    private static int f1118Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$fundecode$classIdentityPacket = 8;

    /* JADX INFO: renamed from: Int$arg-0$call-number$val-token$fun-decode$class-IdentityPacket, reason: not valid java name */
    private static int f1122Int$arg0$callnumber$valtoken$fundecode$classIdentityPacket = 4;

    /* JADX INFO: renamed from: Int$arg-1$call-number$val-token$fun-decode$class-IdentityPacket, reason: not valid java name */
    private static int f1125Int$arg1$callnumber$valtoken$fundecode$classIdentityPacket = 4;

    /* JADX INFO: renamed from: Int$arg-0$call-number$val-chipId$fun-decode$class-IdentityPacket, reason: not valid java name */
    private static int f1121Int$arg0$callnumber$valchipId$fundecode$classIdentityPacket = 8;

    /* JADX INFO: renamed from: Int$arg-1$call-number$val-chipId$fun-decode$class-IdentityPacket, reason: not valid java name */
    private static int f1124Int$arg1$callnumber$valchipId$fundecode$classIdentityPacket = 6;

    @LiveLiteralInfo(key = "Boolean$branch$when$fun-equals$class-CarIdentity", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-CarIdentity, reason: not valid java name */
    public final boolean m6518Boolean$branch$when$funequals$classCarIdentity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1112Boolean$branch$when$funequals$classCarIdentity;
        }
        State<Boolean> stateLiveLiteral = f1132State$Boolean$branch$when$funequals$classCarIdentity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when$fun-equals$class-CarIdentity", Boolean.valueOf(f1112Boolean$branch$when$funequals$classCarIdentity));
            f1132State$Boolean$branch$when$funequals$classCarIdentity = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-1$fun-equals$class-CarIdentity", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-CarIdentity, reason: not valid java name */
    public final boolean m6519Boolean$branch$when1$funequals$classCarIdentity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1113Boolean$branch$when1$funequals$classCarIdentity;
        }
        State<Boolean> stateLiveLiteral = f1133State$Boolean$branch$when1$funequals$classCarIdentity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-1$fun-equals$class-CarIdentity", Boolean.valueOf(f1113Boolean$branch$when1$funequals$classCarIdentity));
            f1133State$Boolean$branch$when1$funequals$classCarIdentity = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-2$fun-equals$class-CarIdentity", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-CarIdentity, reason: not valid java name */
    public final boolean m6520Boolean$branch$when2$funequals$classCarIdentity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1114Boolean$branch$when2$funequals$classCarIdentity;
        }
        State<Boolean> stateLiveLiteral = f1134State$Boolean$branch$when2$funequals$classCarIdentity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-2$fun-equals$class-CarIdentity", Boolean.valueOf(f1114Boolean$branch$when2$funequals$classCarIdentity));
            f1134State$Boolean$branch$when2$funequals$classCarIdentity = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-3$fun-equals$class-CarIdentity", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-CarIdentity, reason: not valid java name */
    public final boolean m6521Boolean$branch$when3$funequals$classCarIdentity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1115Boolean$branch$when3$funequals$classCarIdentity;
        }
        State<Boolean> stateLiveLiteral = f1135State$Boolean$branch$when3$funequals$classCarIdentity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-3$fun-equals$class-CarIdentity", Boolean.valueOf(f1115Boolean$branch$when3$funequals$classCarIdentity));
            f1135State$Boolean$branch$when3$funequals$classCarIdentity = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$fun-equals$class-CarIdentity", offset = -2)
    /* JADX INFO: renamed from: Boolean$fun-equals$class-CarIdentity, reason: not valid java name */
    public final boolean m6522Boolean$funequals$classCarIdentity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1116Boolean$funequals$classCarIdentity;
        }
        State<Boolean> stateLiveLiteral = f1136State$Boolean$funequals$classCarIdentity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$fun-equals$class-CarIdentity", Boolean.valueOf(f1116Boolean$funequals$classCarIdentity));
            f1136State$Boolean$funequals$classCarIdentity = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Int$$$this$call-until$$$this$call-fold$fun-number$fun-decode$class-IdentityPacket", offset = 552)
    /* JADX INFO: renamed from: Int$$$this$call-until$$$this$call-fold$fun-number$fun-decode$class-IdentityPacket, reason: not valid java name */
    public final int m6523Int$$$this$calluntil$$$this$callfold$funnumber$fundecode$classIdentityPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1117Int$$$this$calluntil$$$this$callfold$funnumber$fundecode$classIdentityPacket;
        }
        State<Integer> stateLiveLiteral = f1137State$Int$$$this$calluntil$$$this$callfold$funnumber$fundecode$classIdentityPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$$this$call-until$$$this$call-fold$fun-number$fun-decode$class-IdentityPacket", Integer.valueOf(f1117Int$$$this$calluntil$$$this$callfold$funnumber$fundecode$classIdentityPacket));
            f1137State$Int$$$this$calluntil$$$this$callfold$funnumber$fundecode$classIdentityPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-times$arg-0$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-number$fun-decode$class-IdentityPacket", offset = 654)
    /* JADX INFO: renamed from: Int$$this$call-times$arg-0$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-number$fun-decode$class-IdentityPacket, reason: not valid java name */
    public final int m6524Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$fundecode$classIdentityPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1118Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$fundecode$classIdentityPacket;
        }
        State<Integer> stateLiveLiteral = f1138State$Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$fundecode$classIdentityPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-times$arg-0$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-number$fun-decode$class-IdentityPacket", Integer.valueOf(f1118Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$fundecode$classIdentityPacket));
            f1138State$Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$fundecode$classIdentityPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-IdentityPacket", offset = 475)
    /* JADX INFO: renamed from: Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-IdentityPacket, reason: not valid java name */
    public final int m6525Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$fundecode$classIdentityPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1119Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$fundecode$classIdentityPacket;
        }
        State<Integer> stateLiveLiteral = f1139State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$fundecode$classIdentityPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-IdentityPacket", Integer.valueOf(f1119Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$fundecode$classIdentityPacket));
            f1139State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$fundecode$classIdentityPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-IdentityPacket", offset = 468)
    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-IdentityPacket, reason: not valid java name */
    public final int m6526Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$fundecode$classIdentityPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1120Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$fundecode$classIdentityPacket;
        }
        State<Integer> stateLiveLiteral = f1140State$Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$fundecode$classIdentityPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-IdentityPacket", Integer.valueOf(f1120Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$fundecode$classIdentityPacket));
            f1140State$Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$fundecode$classIdentityPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-number$val-chipId$fun-decode$class-IdentityPacket", offset = 733)
    /* JADX INFO: renamed from: Int$arg-0$call-number$val-chipId$fun-decode$class-IdentityPacket, reason: not valid java name */
    public final int m6527Int$arg0$callnumber$valchipId$fundecode$classIdentityPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1121Int$arg0$callnumber$valchipId$fundecode$classIdentityPacket;
        }
        State<Integer> stateLiveLiteral = f1141State$Int$arg0$callnumber$valchipId$fundecode$classIdentityPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-number$val-chipId$fun-decode$class-IdentityPacket", Integer.valueOf(f1121Int$arg0$callnumber$valchipId$fundecode$classIdentityPacket));
            f1141State$Int$arg0$callnumber$valchipId$fundecode$classIdentityPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-number$val-token$fun-decode$class-IdentityPacket", offset = 699)
    /* JADX INFO: renamed from: Int$arg-0$call-number$val-token$fun-decode$class-IdentityPacket, reason: not valid java name */
    public final int m6528Int$arg0$callnumber$valtoken$fundecode$classIdentityPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1122Int$arg0$callnumber$valtoken$fundecode$classIdentityPacket;
        }
        State<Integer> stateLiveLiteral = f1142State$Int$arg0$callnumber$valtoken$fundecode$classIdentityPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-number$val-token$fun-decode$class-IdentityPacket", Integer.valueOf(f1122Int$arg0$callnumber$valtoken$fundecode$classIdentityPacket));
            f1142State$Int$arg0$callnumber$valtoken$fundecode$classIdentityPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-CarIdentity", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-CarIdentity, reason: not valid java name */
    public final int m6529Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCarIdentity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1123Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCarIdentity;
        }
        State<Integer> stateLiveLiteral = f1143State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCarIdentity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-CarIdentity", Integer.valueOf(f1123Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCarIdentity));
            f1143State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCarIdentity = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-number$val-chipId$fun-decode$class-IdentityPacket", offset = 736)
    /* JADX INFO: renamed from: Int$arg-1$call-number$val-chipId$fun-decode$class-IdentityPacket, reason: not valid java name */
    public final int m6530Int$arg1$callnumber$valchipId$fundecode$classIdentityPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1124Int$arg1$callnumber$valchipId$fundecode$classIdentityPacket;
        }
        State<Integer> stateLiveLiteral = f1144State$Int$arg1$callnumber$valchipId$fundecode$classIdentityPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-number$val-chipId$fun-decode$class-IdentityPacket", Integer.valueOf(f1124Int$arg1$callnumber$valchipId$fundecode$classIdentityPacket));
            f1144State$Int$arg1$callnumber$valchipId$fundecode$classIdentityPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-number$val-token$fun-decode$class-IdentityPacket", offset = 702)
    /* JADX INFO: renamed from: Int$arg-1$call-number$val-token$fun-decode$class-IdentityPacket, reason: not valid java name */
    public final int m6531Int$arg1$callnumber$valtoken$fundecode$classIdentityPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1125Int$arg1$callnumber$valtoken$fundecode$classIdentityPacket;
        }
        State<Integer> stateLiveLiteral = f1145State$Int$arg1$callnumber$valtoken$fundecode$classIdentityPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-number$val-token$fun-decode$class-IdentityPacket", Integer.valueOf(f1125Int$arg1$callnumber$valtoken$fundecode$classIdentityPacket));
            f1145State$Int$arg1$callnumber$valtoken$fundecode$classIdentityPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-CarIdentity", offset = -1)
    /* JADX INFO: renamed from: Int$class-CarIdentity, reason: not valid java name */
    public final int m6532Int$classCarIdentity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1126Int$classCarIdentity;
        }
        State<Integer> stateLiveLiteral = f1146State$Int$classCarIdentity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-CarIdentity", Integer.valueOf(f1126Int$classCarIdentity));
            f1146State$Int$classCarIdentity = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-IdentityPacket", offset = -1)
    /* JADX INFO: renamed from: Int$class-IdentityPacket, reason: not valid java name */
    public final int m6533Int$classIdentityPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1127Int$classIdentityPacket;
        }
        State<Integer> stateLiveLiteral = f1147State$Int$classIdentityPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-IdentityPacket", Integer.valueOf(f1127Int$classIdentityPacket));
            f1147State$Int$classIdentityPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-and$$this$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-number$fun-decode$class-IdentityPacket", offset = 644)
    /* JADX INFO: renamed from: Long$arg-0$call-and$$this$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-number$fun-decode$class-IdentityPacket, reason: not valid java name */
    public final long m6534Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$fundecode$classIdentityPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1128Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$fundecode$classIdentityPacket;
        }
        State<Long> stateLiveLiteral = f1148State$Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$fundecode$classIdentityPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-and$$this$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-number$fun-decode$class-IdentityPacket", Long.valueOf(f1128Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$fundecode$classIdentityPacket));
            f1148State$Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$fundecode$classIdentityPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-fold$fun-number$fun-decode$class-IdentityPacket", offset = 572)
    /* JADX INFO: renamed from: Long$arg-0$call-fold$fun-number$fun-decode$class-IdentityPacket, reason: not valid java name */
    public final long m6535Long$arg0$callfold$funnumber$fundecode$classIdentityPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1129Long$arg0$callfold$funnumber$fundecode$classIdentityPacket;
        }
        State<Long> stateLiveLiteral = f1149State$Long$arg0$callfold$funnumber$fundecode$classIdentityPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-fold$fun-number$fun-decode$class-IdentityPacket", Long.valueOf(f1129Long$arg0$callfold$funnumber$fundecode$classIdentityPacket));
            f1149State$Long$arg0$callfold$funnumber$fundecode$classIdentityPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-1$call-EQEQ$$this$call-not$branch$cond$if-1$fun-decode$class-IdentityPacket", offset = 783)
    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$$this$call-not$branch$cond$if-1$fun-decode$class-IdentityPacket, reason: not valid java name */
    public final long m6536Long$arg1$callEQEQ$$this$callnot$branch$cond$if1$fundecode$classIdentityPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1130Long$arg1$callEQEQ$$this$callnot$branch$cond$if1$fundecode$classIdentityPacket;
        }
        State<Long> stateLiveLiteral = f1150State$Long$arg1$callEQEQ$$this$callnot$branch$cond$if1$fundecode$classIdentityPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-1$call-EQEQ$$this$call-not$branch$cond$if-1$fun-decode$class-IdentityPacket", Long.valueOf(f1130Long$arg1$callEQEQ$$this$callnot$branch$cond$if1$fundecode$classIdentityPacket));
            f1150State$Long$arg1$callEQEQ$$this$callnot$branch$cond$if1$fundecode$classIdentityPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-1$call-EQEQ$$this$call-not$cond$cond$if-1$fun-decode$class-IdentityPacket", offset = 767)
    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$$this$call-not$cond$cond$if-1$fun-decode$class-IdentityPacket, reason: not valid java name */
    public final long m6537Long$arg1$callEQEQ$$this$callnot$cond$cond$if1$fundecode$classIdentityPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1131Long$arg1$callEQEQ$$this$callnot$cond$cond$if1$fundecode$classIdentityPacket;
        }
        State<Long> stateLiveLiteral = f1151State$Long$arg1$callEQEQ$$this$callnot$cond$cond$if1$fundecode$classIdentityPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-1$call-EQEQ$$this$call-not$cond$cond$if-1$fun-decode$class-IdentityPacket", Long.valueOf(f1131Long$arg1$callEQEQ$$this$callnot$cond$cond$if1$fundecode$classIdentityPacket));
            f1151State$Long$arg1$callEQEQ$$this$callnot$cond$cond$if1$fundecode$classIdentityPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "String$0$str$fun-toString$class-CarIdentity", offset = -2)
    /* JADX INFO: renamed from: String$0$str$fun-toString$class-CarIdentity, reason: not valid java name */
    public final String m6538String$0$str$funtoString$classCarIdentity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1157String$0$str$funtoString$classCarIdentity;
        }
        State<String> stateLiveLiteral = f1152State$String$0$str$funtoString$classCarIdentity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$fun-toString$class-CarIdentity", f1157String$0$str$funtoString$classCarIdentity);
            f1152State$String$0$str$funtoString$classCarIdentity = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$1$str$fun-toString$class-CarIdentity", offset = -2)
    /* JADX INFO: renamed from: String$1$str$fun-toString$class-CarIdentity, reason: not valid java name */
    public final String m6539String$1$str$funtoString$classCarIdentity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1158String$1$str$funtoString$classCarIdentity;
        }
        State<String> stateLiveLiteral = f1153State$String$1$str$funtoString$classCarIdentity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$1$str$fun-toString$class-CarIdentity", f1158String$1$str$funtoString$classCarIdentity);
            f1153State$String$1$str$funtoString$classCarIdentity = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$3$str$fun-toString$class-CarIdentity", offset = -2)
    /* JADX INFO: renamed from: String$3$str$fun-toString$class-CarIdentity, reason: not valid java name */
    public final String m6540String$3$str$funtoString$classCarIdentity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1159String$3$str$funtoString$classCarIdentity;
        }
        State<String> stateLiveLiteral = f1154State$String$3$str$funtoString$classCarIdentity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$3$str$fun-toString$class-CarIdentity", f1159String$3$str$funtoString$classCarIdentity);
            f1154State$String$3$str$funtoString$classCarIdentity = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$4$str$fun-toString$class-CarIdentity", offset = -2)
    /* JADX INFO: renamed from: String$4$str$fun-toString$class-CarIdentity, reason: not valid java name */
    public final String m6541String$4$str$funtoString$classCarIdentity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1160String$4$str$funtoString$classCarIdentity;
        }
        State<String> stateLiveLiteral = f1155State$String$4$str$funtoString$classCarIdentity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$4$str$fun-toString$class-CarIdentity", f1160String$4$str$funtoString$classCarIdentity);
            f1155State$String$4$str$funtoString$classCarIdentity = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$6$str$fun-toString$class-CarIdentity", offset = -2)
    /* JADX INFO: renamed from: String$6$str$fun-toString$class-CarIdentity, reason: not valid java name */
    public final String m6542String$6$str$funtoString$classCarIdentity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1161String$6$str$funtoString$classCarIdentity;
        }
        State<String> stateLiveLiteral = f1156State$String$6$str$funtoString$classCarIdentity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$6$str$fun-toString$class-CarIdentity", f1161String$6$str$funtoString$classCarIdentity);
            f1156State$String$6$str$funtoString$classCarIdentity = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
