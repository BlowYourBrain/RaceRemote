package vea.raceremote.control;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: UdpControlClient.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/control/UdpControlClient.kt")
public final class LiveLiterals$UdpControlClientKt {

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-all$branch$cond$arg-0$call-require$class-UdpControlClient, reason: not valid java name */
    private static int f1166Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$arg0$callrequire$classUdpControlClient;

    /* JADX INFO: renamed from: Int$arg-0$call-get$arg-0$call-EQEQ$cond$else$branch$arg-0$call-require$class-UdpControlClient, reason: not valid java name */
    private static int f1170Int$arg0$callget$arg0$callEQEQ$cond$else$branch$arg0$callrequire$classUdpControlClient;

    /* JADX INFO: renamed from: Int$arg-0$call-input$fun-$anonymous$$arg-1$call-synchronized$fun-close$class-UdpControlClient, reason: not valid java name */
    private static int f1171Int$arg0$callinput$fun$anonymous$$arg1$callsynchronized$funclose$classUdpControlClient;

    /* JADX INFO: renamed from: Int$arg-1$call-input$fun-$anonymous$$arg-1$call-synchronized$fun-close$class-UdpControlClient, reason: not valid java name */
    private static int f1177Int$arg1$callinput$fun$anonymous$$arg1$callsynchronized$funclose$classUdpControlClient;

    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$cond$loop$class-UdpControlClient, reason: not valid java name */
    private static long f1182Long$arg1$callEQEQ$cond$loop$classUdpControlClient;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-set$fun-close$class-UdpControlClient, reason: not valid java name */
    private static State<Boolean> f1183State$Boolean$arg0$callset$funclose$classUdpControlClient;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-setDaemon$fun-$anonymous$$arg-0$call-apply$set-worker$class-UdpControlClient, reason: not valid java name */
    private static State<Boolean> f1184State$Boolean$arg0$callsetDaemon$fun$anonymous$$arg0$callapply$setworker$classUdpControlClient;

    /* JADX INFO: renamed from: State$Char$0$vararg$arg-0$call-split$$$this$call-map$val-octets$class-UdpControlClient, reason: not valid java name */
    private static State<Character> f1185State$Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$classUdpControlClient;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$branch$else$branch$arg-0$call-require$class-UdpControlClient, reason: not valid java name */
    private static State<Integer> f1186State$Int$$this$callrangeTo$$this$callcontains$branch$else$branch$arg0$callrequire$classUdpControlClient;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-all$branch$cond$arg-0$call-require$class-UdpControlClient, reason: not valid java name */
    private static State<Integer> f1187State$Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$arg0$callrequire$classUdpControlClient;

    /* JADX INFO: renamed from: State$Int$arg-0$call-$init$$val-buffer$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient, reason: not valid java name */
    private static State<Integer> f1188State$Int$arg0$call$init$$valbuffer$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient;

    /* JADX INFO: renamed from: State$Int$arg-0$call-div$fun-$anonymous$$param-clockMs$class-UdpControlClient, reason: not valid java name */
    private static State<Integer> f1189State$Int$arg0$calldiv$fun$anonymous$$paramclockMs$classUdpControlClient;

    /* JADX INFO: renamed from: State$Int$arg-0$call-get$arg-0$call-CHECK_NOT_NULL$arg-0$call-contains$branch$else$branch$arg-0$call-require$class-UdpControlClient, reason: not valid java name */
    private static State<Integer> f1190State$Int$arg0$callget$arg0$callCHECK_NOT_NULL$arg0$callcontains$branch$else$branch$arg0$callrequire$classUdpControlClient;

    /* JADX INFO: renamed from: State$Int$arg-0$call-get$arg-0$call-EQEQ$cond$else$branch$arg-0$call-require$class-UdpControlClient, reason: not valid java name */
    private static State<Integer> f1191State$Int$arg0$callget$arg0$callEQEQ$cond$else$branch$arg0$callrequire$classUdpControlClient;

    /* JADX INFO: renamed from: State$Int$arg-0$call-input$fun-$anonymous$$arg-1$call-synchronized$fun-close$class-UdpControlClient, reason: not valid java name */
    private static State<Integer> f1192State$Int$arg0$callinput$fun$anonymous$$arg1$callsynchronized$funclose$classUdpControlClient;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rangeTo$$this$call-contains$branch$else$branch$arg-0$call-require$class-UdpControlClient, reason: not valid java name */
    private static State<Integer> f1193State$Int$arg0$callrangeTo$$this$callcontains$branch$else$branch$arg0$callrequire$classUdpControlClient;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-all$branch$cond$arg-0$call-require$class-UdpControlClient, reason: not valid java name */
    private static State<Integer> f1194State$Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$arg0$callrequire$classUdpControlClient;

    /* JADX INFO: renamed from: State$Int$arg-0$call-setSoTimeout$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient, reason: not valid java name */
    private static State<Integer> f1195State$Int$arg0$callsetSoTimeout$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient;

    /* JADX INFO: renamed from: State$Int$arg-1$call-EQEQ$cond$cond$arg-0$call-require$class-UdpControlClient, reason: not valid java name */
    private static State<Integer> f1196State$Int$arg1$callEQEQ$cond$cond$arg0$callrequire$classUdpControlClient;

    /* JADX INFO: renamed from: State$Int$arg-1$call-EQEQ$cond$else$branch$arg-0$call-require$class-UdpControlClient, reason: not valid java name */
    private static State<Integer> f1197State$Int$arg1$callEQEQ$cond$else$branch$arg0$callrequire$classUdpControlClient;

    /* JADX INFO: renamed from: State$Int$arg-1$call-input$fun-$anonymous$$arg-1$call-synchronized$fun-close$class-UdpControlClient, reason: not valid java name */
    private static State<Integer> f1198State$Int$arg1$callinput$fun$anonymous$$arg1$callsynchronized$funclose$classUdpControlClient;

    /* JADX INFO: renamed from: State$Int$class-UdpControlClient, reason: not valid java name */
    private static State<Integer> f1199State$Int$classUdpControlClient;

    /* JADX INFO: renamed from: State$Long$arg-0$call-and$set-attempt$body$loop$class-UdpControlClient, reason: not valid java name */
    private static State<Long> f1200State$Long$arg0$calland$setattempt$body$loop$classUdpControlClient;

    /* JADX INFO: renamed from: State$Long$arg-0$call-join$branch$if$fun-close$class-UdpControlClient, reason: not valid java name */
    private static State<Long> f1201State$Long$arg0$calljoin$branch$if$funclose$classUdpControlClient;

    /* JADX INFO: renamed from: State$Long$arg-0$call-join-1$branch$if$fun-close$class-UdpControlClient, reason: not valid java name */
    private static State<Long> f1202State$Long$arg0$calljoin1$branch$if$funclose$classUdpControlClient;

    /* JADX INFO: renamed from: State$Long$arg-1$call-EQEQ$cond$loop$class-UdpControlClient, reason: not valid java name */
    private static State<Long> f1203State$Long$arg1$callEQEQ$cond$loop$classUdpControlClient;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-invoke$branch$if$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient, reason: not valid java name */
    private static State<String> f1204State$String$0$str$arg0$callinvoke$branch$if$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-invoke$catch$fun-run$class-UdpControlClient, reason: not valid java name */
    private static State<String> f1205State$String$0$str$arg0$callinvoke$catch$funrun$classUdpControlClient;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-invoke$finally$fun-run$class-UdpControlClient, reason: not valid java name */
    private static State<String> f1206State$String$0$str$arg0$callinvoke$finally$funrun$classUdpControlClient;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-invoke$try$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient, reason: not valid java name */
    private static State<String> f1207State$String$0$str$arg0$callinvoke$try$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-stop$fun-$anonymous$$arg-1$call-synchronized$catch$fun-run$class-UdpControlClient, reason: not valid java name */
    private static State<String> f1208State$String$0$str$arg0$callstop$fun$anonymous$$arg1$callsynchronized$catch$funrun$classUdpControlClient;

    /* JADX INFO: renamed from: State$String$2$str$arg-0$call-invoke$branch$if$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient, reason: not valid java name */
    private static State<String> f1209State$String$2$str$arg0$callinvoke$branch$if$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient;

    /* JADX INFO: renamed from: State$String$2$str$arg-0$call-invoke$try$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient, reason: not valid java name */
    private static State<String> f1210State$String$2$str$arg0$callinvoke$try$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient;

    /* JADX INFO: renamed from: State$String$4$str$arg-0$call-invoke$branch$if$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient, reason: not valid java name */
    private static State<String> f1211State$String$4$str$arg0$callinvoke$branch$if$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient;

    /* JADX INFO: renamed from: State$String$arg-1$call-$init$$$$this$call-apply$set-worker$class-UdpControlClient, reason: not valid java name */
    private static State<String> f1212State$String$arg1$call$init$$$$this$callapply$setworker$classUdpControlClient;

    /* JADX INFO: renamed from: State$String$fun-$anonymous$$arg-1$call-require$class-UdpControlClient, reason: not valid java name */
    private static State<String> f1213State$String$fun$anonymous$$arg1$callrequire$classUdpControlClient;
    public static final LiveLiterals$UdpControlClientKt INSTANCE = new LiveLiterals$UdpControlClientKt();

    /* JADX INFO: renamed from: Int$arg-0$call-div$fun-$anonymous$$param-clockMs$class-UdpControlClient, reason: not valid java name */
    private static int f1168Int$arg0$calldiv$fun$anonymous$$paramclockMs$classUdpControlClient = 1000000;

    /* JADX INFO: renamed from: Char$0$vararg$arg-0$call-split$$$this$call-map$val-octets$class-UdpControlClient, reason: not valid java name */
    private static char f1164Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$classUdpControlClient = '.';

    /* JADX INFO: renamed from: Int$arg-1$call-EQEQ$cond$cond$arg-0$call-require$class-UdpControlClient, reason: not valid java name */
    private static int f1175Int$arg1$callEQEQ$cond$cond$arg0$callrequire$classUdpControlClient = 4;

    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-all$branch$cond$arg-0$call-require$class-UdpControlClient, reason: not valid java name */
    private static int f1173Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$arg0$callrequire$classUdpControlClient = 255;

    /* JADX INFO: renamed from: Int$arg-1$call-EQEQ$cond$else$branch$arg-0$call-require$class-UdpControlClient, reason: not valid java name */
    private static int f1176Int$arg1$callEQEQ$cond$else$branch$arg0$callrequire$classUdpControlClient = 172;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$else$branch$arg-0$call-require$class-UdpControlClient, reason: not valid java name */
    private static int f1165Int$$this$callrangeTo$$this$callcontains$branch$else$branch$arg0$callrequire$classUdpControlClient = 16;

    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$else$branch$arg-0$call-require$class-UdpControlClient, reason: not valid java name */
    private static int f1172Int$arg0$callrangeTo$$this$callcontains$branch$else$branch$arg0$callrequire$classUdpControlClient = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-get$arg-0$call-CHECK_NOT_NULL$arg-0$call-contains$branch$else$branch$arg-0$call-require$class-UdpControlClient, reason: not valid java name */
    private static int f1169Int$arg0$callget$arg0$callCHECK_NOT_NULL$arg0$callcontains$branch$else$branch$arg0$callrequire$classUdpControlClient = 1;

    /* JADX INFO: renamed from: String$fun-$anonymous$$arg-1$call-require$class-UdpControlClient, reason: not valid java name */
    private static String f1223String$fun$anonymous$$arg1$callrequire$classUdpControlClient = "Local IPv4 required";

    /* JADX INFO: renamed from: Long$arg-0$call-and$set-attempt$body$loop$class-UdpControlClient, reason: not valid java name */
    private static long f1179Long$arg0$calland$setattempt$body$loop$classUdpControlClient = 4294967295L;

    /* JADX INFO: renamed from: String$arg-1$call-$init$$$$this$call-apply$set-worker$class-UdpControlClient, reason: not valid java name */
    private static String f1222String$arg1$call$init$$$$this$callapply$setworker$classUdpControlClient = "rc-udp-control";

    /* JADX INFO: renamed from: Boolean$arg-0$call-setDaemon$fun-$anonymous$$arg-0$call-apply$set-worker$class-UdpControlClient, reason: not valid java name */
    private static boolean f1163Boolean$arg0$callsetDaemon$fun$anonymous$$arg0$callapply$setworker$classUdpControlClient = true;

    /* JADX INFO: renamed from: Int$arg-0$call-setSoTimeout$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient, reason: not valid java name */
    private static int f1174Int$arg0$callsetSoTimeout$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient = 5;

    /* JADX INFO: renamed from: Int$arg-0$call-$init$$val-buffer$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient, reason: not valid java name */
    private static int f1167Int$arg0$call$init$$valbuffer$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient = 256;

    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$branch$if$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient, reason: not valid java name */
    private static String f1214String$0$str$arg0$callinvoke$branch$if$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient = "sent kind=";

    /* JADX INFO: renamed from: String$2$str$arg-0$call-invoke$branch$if$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient, reason: not valid java name */
    private static String f1219String$2$str$arg0$callinvoke$branch$if$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient = " seq=";

    /* JADX INFO: renamed from: String$4$str$arg-0$call-invoke$branch$if$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient, reason: not valid java name */
    private static String f1221String$4$str$arg0$callinvoke$branch$if$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient = " basis=";

    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$try$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient, reason: not valid java name */
    private static String f1217String$0$str$arg0$callinvoke$try$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient = "received seq=";

    /* JADX INFO: renamed from: String$2$str$arg-0$call-invoke$try$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient, reason: not valid java name */
    private static String f1220String$2$str$arg0$callinvoke$try$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient = " accepted=";

    /* JADX INFO: renamed from: String$0$str$arg-0$call-stop$fun-$anonymous$$arg-1$call-synchronized$catch$fun-run$class-UdpControlClient, reason: not valid java name */
    private static String f1218String$0$str$arg0$callstop$fun$anonymous$$arg1$callsynchronized$catch$funrun$classUdpControlClient = "Transport failure: ";

    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$catch$fun-run$class-UdpControlClient, reason: not valid java name */
    private static String f1215String$0$str$arg0$callinvoke$catch$funrun$classUdpControlClient = "transport failure ";

    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$finally$fun-run$class-UdpControlClient, reason: not valid java name */
    private static String f1216String$0$str$arg0$callinvoke$finally$funrun$classUdpControlClient = "closed ";

    /* JADX INFO: renamed from: Boolean$arg-0$call-set$fun-close$class-UdpControlClient, reason: not valid java name */
    private static boolean f1162Boolean$arg0$callset$funclose$classUdpControlClient = true;

    /* JADX INFO: renamed from: Long$arg-0$call-join$branch$if$fun-close$class-UdpControlClient, reason: not valid java name */
    private static long f1180Long$arg0$calljoin$branch$if$funclose$classUdpControlClient = 300;

    /* JADX INFO: renamed from: Long$arg-0$call-join-1$branch$if$fun-close$class-UdpControlClient, reason: not valid java name */
    private static long f1181Long$arg0$calljoin1$branch$if$funclose$classUdpControlClient = 100;

    /* JADX INFO: renamed from: Int$class-UdpControlClient, reason: not valid java name */
    private static int f1178Int$classUdpControlClient = 8;

    @LiveLiteralInfo(key = "Boolean$arg-0$call-set$fun-close$class-UdpControlClient", offset = 3657)
    /* JADX INFO: renamed from: Boolean$arg-0$call-set$fun-close$class-UdpControlClient, reason: not valid java name */
    public final boolean m6543Boolean$arg0$callset$funclose$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1162Boolean$arg0$callset$funclose$classUdpControlClient;
        }
        State<Boolean> stateLiveLiteral = f1183State$Boolean$arg0$callset$funclose$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-set$fun-close$class-UdpControlClient", Boolean.valueOf(f1162Boolean$arg0$callset$funclose$classUdpControlClient));
            f1183State$Boolean$arg0$callset$funclose$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-setDaemon$fun-$anonymous$$arg-0$call-apply$set-worker$class-UdpControlClient", offset = 1534)
    /* JADX INFO: renamed from: Boolean$arg-0$call-setDaemon$fun-$anonymous$$arg-0$call-apply$set-worker$class-UdpControlClient, reason: not valid java name */
    public final boolean m6544Boolean$arg0$callsetDaemon$fun$anonymous$$arg0$callapply$setworker$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1163Boolean$arg0$callsetDaemon$fun$anonymous$$arg0$callapply$setworker$classUdpControlClient;
        }
        State<Boolean> stateLiveLiteral = f1184State$Boolean$arg0$callsetDaemon$fun$anonymous$$arg0$callapply$setworker$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-setDaemon$fun-$anonymous$$arg-0$call-apply$set-worker$class-UdpControlClient", Boolean.valueOf(f1163Boolean$arg0$callsetDaemon$fun$anonymous$$arg0$callapply$setworker$classUdpControlClient));
            f1184State$Boolean$arg0$callsetDaemon$fun$anonymous$$arg0$callapply$setworker$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Char$0$vararg$arg-0$call-split$$$this$call-map$val-octets$class-UdpControlClient", offset = 908)
    /* JADX INFO: renamed from: Char$0$vararg$arg-0$call-split$$$this$call-map$val-octets$class-UdpControlClient, reason: not valid java name */
    public final char m6545Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1164Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$classUdpControlClient;
        }
        State<Character> stateLiveLiteral = f1185State$Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Char$0$vararg$arg-0$call-split$$$this$call-map$val-octets$class-UdpControlClient", Character.valueOf(f1164Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$classUdpControlClient));
            f1185State$Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().charValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$branch$else$branch$arg-0$call-require$class-UdpControlClient", offset = 1165)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$else$branch$arg-0$call-require$class-UdpControlClient, reason: not valid java name */
    public final int m6546Int$$this$callrangeTo$$this$callcontains$branch$else$branch$arg0$callrequire$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1165Int$$this$callrangeTo$$this$callcontains$branch$else$branch$arg0$callrequire$classUdpControlClient;
        }
        State<Integer> stateLiveLiteral = f1186State$Int$$this$callrangeTo$$this$callcontains$branch$else$branch$arg0$callrequire$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$branch$else$branch$arg-0$call-require$class-UdpControlClient", Integer.valueOf(f1165Int$$this$callrangeTo$$this$callcontains$branch$else$branch$arg0$callrequire$classUdpControlClient));
            f1186State$Int$$this$callrangeTo$$this$callcontains$branch$else$branch$arg0$callrequire$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-all$branch$cond$arg-0$call-require$class-UdpControlClient", offset = 1007)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-all$branch$cond$arg-0$call-require$class-UdpControlClient, reason: not valid java name */
    public final int m6547Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$arg0$callrequire$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1166Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$arg0$callrequire$classUdpControlClient;
        }
        State<Integer> stateLiveLiteral = f1187State$Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$arg0$callrequire$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-all$branch$cond$arg-0$call-require$class-UdpControlClient", Integer.valueOf(f1166Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$arg0$callrequire$classUdpControlClient));
            f1187State$Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$arg0$callrequire$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-$init$$val-buffer$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient", offset = 2058)
    /* JADX INFO: renamed from: Int$arg-0$call-$init$$val-buffer$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient, reason: not valid java name */
    public final int m6548Int$arg0$call$init$$valbuffer$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1167Int$arg0$call$init$$valbuffer$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient;
        }
        State<Integer> stateLiveLiteral = f1188State$Int$arg0$call$init$$valbuffer$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-$init$$val-buffer$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient", Integer.valueOf(f1167Int$arg0$call$init$$valbuffer$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient));
            f1188State$Int$arg0$call$init$$valbuffer$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-div$fun-$anonymous$$param-clockMs$class-UdpControlClient", offset = 591)
    /* JADX INFO: renamed from: Int$arg-0$call-div$fun-$anonymous$$param-clockMs$class-UdpControlClient, reason: not valid java name */
    public final int m6549Int$arg0$calldiv$fun$anonymous$$paramclockMs$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1168Int$arg0$calldiv$fun$anonymous$$paramclockMs$classUdpControlClient;
        }
        State<Integer> stateLiveLiteral = f1189State$Int$arg0$calldiv$fun$anonymous$$paramclockMs$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-div$fun-$anonymous$$param-clockMs$class-UdpControlClient", Integer.valueOf(f1168Int$arg0$calldiv$fun$anonymous$$paramclockMs$classUdpControlClient));
            f1189State$Int$arg0$calldiv$fun$anonymous$$paramclockMs$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-get$arg-0$call-CHECK_NOT_NULL$arg-0$call-contains$branch$else$branch$arg-0$call-require$class-UdpControlClient", offset = 1157)
    /* JADX INFO: renamed from: Int$arg-0$call-get$arg-0$call-CHECK_NOT_NULL$arg-0$call-contains$branch$else$branch$arg-0$call-require$class-UdpControlClient, reason: not valid java name */
    public final int m6550Int$arg0$callget$arg0$callCHECK_NOT_NULL$arg0$callcontains$branch$else$branch$arg0$callrequire$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1169Int$arg0$callget$arg0$callCHECK_NOT_NULL$arg0$callcontains$branch$else$branch$arg0$callrequire$classUdpControlClient;
        }
        State<Integer> stateLiveLiteral = f1190State$Int$arg0$callget$arg0$callCHECK_NOT_NULL$arg0$callcontains$branch$else$branch$arg0$callrequire$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-get$arg-0$call-CHECK_NOT_NULL$arg-0$call-contains$branch$else$branch$arg-0$call-require$class-UdpControlClient", Integer.valueOf(f1169Int$arg0$callget$arg0$callCHECK_NOT_NULL$arg0$callcontains$branch$else$branch$arg0$callrequire$classUdpControlClient));
            f1190State$Int$arg0$callget$arg0$callCHECK_NOT_NULL$arg0$callcontains$branch$else$branch$arg0$callrequire$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-get$arg-0$call-EQEQ$cond$else$branch$arg-0$call-require$class-UdpControlClient", offset = 1137)
    /* JADX INFO: renamed from: Int$arg-0$call-get$arg-0$call-EQEQ$cond$else$branch$arg-0$call-require$class-UdpControlClient, reason: not valid java name */
    public final int m6551Int$arg0$callget$arg0$callEQEQ$cond$else$branch$arg0$callrequire$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1170Int$arg0$callget$arg0$callEQEQ$cond$else$branch$arg0$callrequire$classUdpControlClient;
        }
        State<Integer> stateLiveLiteral = f1191State$Int$arg0$callget$arg0$callEQEQ$cond$else$branch$arg0$callrequire$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-get$arg-0$call-EQEQ$cond$else$branch$arg-0$call-require$class-UdpControlClient", Integer.valueOf(f1170Int$arg0$callget$arg0$callEQEQ$cond$else$branch$arg0$callrequire$classUdpControlClient));
            f1191State$Int$arg0$callget$arg0$callEQEQ$cond$else$branch$arg0$callrequire$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-input$fun-$anonymous$$arg-1$call-synchronized$fun-close$class-UdpControlClient", offset = 3706)
    /* JADX INFO: renamed from: Int$arg-0$call-input$fun-$anonymous$$arg-1$call-synchronized$fun-close$class-UdpControlClient, reason: not valid java name */
    public final int m6552Int$arg0$callinput$fun$anonymous$$arg1$callsynchronized$funclose$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1171Int$arg0$callinput$fun$anonymous$$arg1$callsynchronized$funclose$classUdpControlClient;
        }
        State<Integer> stateLiveLiteral = f1192State$Int$arg0$callinput$fun$anonymous$$arg1$callsynchronized$funclose$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-input$fun-$anonymous$$arg-1$call-synchronized$fun-close$class-UdpControlClient", Integer.valueOf(f1171Int$arg0$callinput$fun$anonymous$$arg1$callsynchronized$funclose$classUdpControlClient));
            f1192State$Int$arg0$callinput$fun$anonymous$$arg1$callsynchronized$funclose$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rangeTo$$this$call-contains$branch$else$branch$arg-0$call-require$class-UdpControlClient", offset = 1169)
    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$else$branch$arg-0$call-require$class-UdpControlClient, reason: not valid java name */
    public final int m6553Int$arg0$callrangeTo$$this$callcontains$branch$else$branch$arg0$callrequire$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1172Int$arg0$callrangeTo$$this$callcontains$branch$else$branch$arg0$callrequire$classUdpControlClient;
        }
        State<Integer> stateLiveLiteral = f1193State$Int$arg0$callrangeTo$$this$callcontains$branch$else$branch$arg0$callrequire$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rangeTo$$this$call-contains$branch$else$branch$arg-0$call-require$class-UdpControlClient", Integer.valueOf(f1172Int$arg0$callrangeTo$$this$callcontains$branch$else$branch$arg0$callrequire$classUdpControlClient));
            f1193State$Int$arg0$callrangeTo$$this$callcontains$branch$else$branch$arg0$callrequire$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-all$branch$cond$arg-0$call-require$class-UdpControlClient", offset = 1010)
    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-all$branch$cond$arg-0$call-require$class-UdpControlClient, reason: not valid java name */
    public final int m6554Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$arg0$callrequire$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1173Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$arg0$callrequire$classUdpControlClient;
        }
        State<Integer> stateLiveLiteral = f1194State$Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$arg0$callrequire$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-all$branch$cond$arg-0$call-require$class-UdpControlClient", Integer.valueOf(f1173Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$arg0$callrequire$classUdpControlClient));
            f1194State$Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$arg0$callrequire$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-setSoTimeout$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient", offset = 2017)
    /* JADX INFO: renamed from: Int$arg-0$call-setSoTimeout$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient, reason: not valid java name */
    public final int m6555Int$arg0$callsetSoTimeout$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1174Int$arg0$callsetSoTimeout$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient;
        }
        State<Integer> stateLiveLiteral = f1195State$Int$arg0$callsetSoTimeout$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-setSoTimeout$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient", Integer.valueOf(f1174Int$arg0$callsetSoTimeout$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient));
            f1195State$Int$arg0$callsetSoTimeout$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-EQEQ$cond$cond$arg-0$call-require$class-UdpControlClient", offset = 969)
    /* JADX INFO: renamed from: Int$arg-1$call-EQEQ$cond$cond$arg-0$call-require$class-UdpControlClient, reason: not valid java name */
    public final int m6556Int$arg1$callEQEQ$cond$cond$arg0$callrequire$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1175Int$arg1$callEQEQ$cond$cond$arg0$callrequire$classUdpControlClient;
        }
        State<Integer> stateLiveLiteral = f1196State$Int$arg1$callEQEQ$cond$cond$arg0$callrequire$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-EQEQ$cond$cond$arg-0$call-require$class-UdpControlClient", Integer.valueOf(f1175Int$arg1$callEQEQ$cond$cond$arg0$callrequire$classUdpControlClient));
            f1196State$Int$arg1$callEQEQ$cond$cond$arg0$callrequire$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-EQEQ$cond$else$branch$arg-0$call-require$class-UdpControlClient", offset = 1143)
    /* JADX INFO: renamed from: Int$arg-1$call-EQEQ$cond$else$branch$arg-0$call-require$class-UdpControlClient, reason: not valid java name */
    public final int m6557Int$arg1$callEQEQ$cond$else$branch$arg0$callrequire$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1176Int$arg1$callEQEQ$cond$else$branch$arg0$callrequire$classUdpControlClient;
        }
        State<Integer> stateLiveLiteral = f1197State$Int$arg1$callEQEQ$cond$else$branch$arg0$callrequire$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-EQEQ$cond$else$branch$arg-0$call-require$class-UdpControlClient", Integer.valueOf(f1176Int$arg1$callEQEQ$cond$else$branch$arg0$callrequire$classUdpControlClient));
            f1197State$Int$arg1$callEQEQ$cond$else$branch$arg0$callrequire$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-input$fun-$anonymous$$arg-1$call-synchronized$fun-close$class-UdpControlClient", offset = 3709)
    /* JADX INFO: renamed from: Int$arg-1$call-input$fun-$anonymous$$arg-1$call-synchronized$fun-close$class-UdpControlClient, reason: not valid java name */
    public final int m6558Int$arg1$callinput$fun$anonymous$$arg1$callsynchronized$funclose$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1177Int$arg1$callinput$fun$anonymous$$arg1$callsynchronized$funclose$classUdpControlClient;
        }
        State<Integer> stateLiveLiteral = f1198State$Int$arg1$callinput$fun$anonymous$$arg1$callsynchronized$funclose$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-input$fun-$anonymous$$arg-1$call-synchronized$fun-close$class-UdpControlClient", Integer.valueOf(f1177Int$arg1$callinput$fun$anonymous$$arg1$callsynchronized$funclose$classUdpControlClient));
            f1198State$Int$arg1$callinput$fun$anonymous$$arg1$callsynchronized$funclose$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-UdpControlClient", offset = -1)
    /* JADX INFO: renamed from: Int$class-UdpControlClient, reason: not valid java name */
    public final int m6559Int$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1178Int$classUdpControlClient;
        }
        State<Integer> stateLiveLiteral = f1199State$Int$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-UdpControlClient", Integer.valueOf(f1178Int$classUdpControlClient));
            f1199State$Int$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-and$set-attempt$body$loop$class-UdpControlClient", offset = 1362)
    /* JADX INFO: renamed from: Long$arg-0$call-and$set-attempt$body$loop$class-UdpControlClient, reason: not valid java name */
    public final long m6560Long$arg0$calland$setattempt$body$loop$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1179Long$arg0$calland$setattempt$body$loop$classUdpControlClient;
        }
        State<Long> stateLiveLiteral = f1200State$Long$arg0$calland$setattempt$body$loop$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-and$set-attempt$body$loop$class-UdpControlClient", Long.valueOf(f1179Long$arg0$calland$setattempt$body$loop$classUdpControlClient));
            f1200State$Long$arg0$calland$setattempt$body$loop$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-join$branch$if$fun-close$class-UdpControlClient", offset = 3786)
    /* JADX INFO: renamed from: Long$arg-0$call-join$branch$if$fun-close$class-UdpControlClient, reason: not valid java name */
    public final long m6561Long$arg0$calljoin$branch$if$funclose$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1180Long$arg0$calljoin$branch$if$funclose$classUdpControlClient;
        }
        State<Long> stateLiveLiteral = f1201State$Long$arg0$calljoin$branch$if$funclose$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-join$branch$if$fun-close$class-UdpControlClient", Long.valueOf(f1180Long$arg0$calljoin$branch$if$funclose$classUdpControlClient));
            f1201State$Long$arg0$calljoin$branch$if$funclose$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-join-1$branch$if$fun-close$class-UdpControlClient", offset = 3942)
    /* JADX INFO: renamed from: Long$arg-0$call-join-1$branch$if$fun-close$class-UdpControlClient, reason: not valid java name */
    public final long m6562Long$arg0$calljoin1$branch$if$funclose$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1181Long$arg0$calljoin1$branch$if$funclose$classUdpControlClient;
        }
        State<Long> stateLiveLiteral = f1202State$Long$arg0$calljoin1$branch$if$funclose$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-join-1$branch$if$fun-close$class-UdpControlClient", Long.valueOf(f1181Long$arg0$calljoin1$branch$if$funclose$classUdpControlClient));
            f1202State$Long$arg0$calljoin1$branch$if$funclose$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-1$call-EQEQ$cond$loop$class-UdpControlClient", offset = 1394)
    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$cond$loop$class-UdpControlClient, reason: not valid java name */
    public final long m6563Long$arg1$callEQEQ$cond$loop$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1182Long$arg1$callEQEQ$cond$loop$classUdpControlClient;
        }
        State<Long> stateLiveLiteral = f1203State$Long$arg1$callEQEQ$cond$loop$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-1$call-EQEQ$cond$loop$class-UdpControlClient", Long.valueOf(f1182Long$arg1$callEQEQ$cond$loop$classUdpControlClient));
            f1203State$Long$arg1$callEQEQ$cond$loop$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-invoke$branch$if$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient", offset = 2481)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$branch$if$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient, reason: not valid java name */
    public final String m6564String$0$str$arg0$callinvoke$branch$if$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1214String$0$str$arg0$callinvoke$branch$if$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient;
        }
        State<String> stateLiveLiteral = f1204State$String$0$str$arg0$callinvoke$branch$if$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-invoke$branch$if$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient", f1214String$0$str$arg0$callinvoke$branch$if$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient);
            f1204State$String$0$str$arg0$callinvoke$branch$if$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-invoke$catch$fun-run$class-UdpControlClient", offset = 3396)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$catch$fun-run$class-UdpControlClient, reason: not valid java name */
    public final String m6565String$0$str$arg0$callinvoke$catch$funrun$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1215String$0$str$arg0$callinvoke$catch$funrun$classUdpControlClient;
        }
        State<String> stateLiveLiteral = f1205State$String$0$str$arg0$callinvoke$catch$funrun$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-invoke$catch$fun-run$class-UdpControlClient", f1215String$0$str$arg0$callinvoke$catch$funrun$classUdpControlClient);
            f1205State$String$0$str$arg0$callinvoke$catch$funrun$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-invoke$finally$fun-run$class-UdpControlClient", offset = 3563)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$finally$fun-run$class-UdpControlClient, reason: not valid java name */
    public final String m6566String$0$str$arg0$callinvoke$finally$funrun$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1216String$0$str$arg0$callinvoke$finally$funrun$classUdpControlClient;
        }
        State<String> stateLiveLiteral = f1206State$String$0$str$arg0$callinvoke$finally$funrun$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-invoke$finally$fun-run$class-UdpControlClient", f1216String$0$str$arg0$callinvoke$finally$funrun$classUdpControlClient);
            f1206State$String$0$str$arg0$callinvoke$finally$funrun$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-invoke$try$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient", offset = 3047)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$try$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient, reason: not valid java name */
    public final String m6567String$0$str$arg0$callinvoke$try$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1217String$0$str$arg0$callinvoke$try$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient;
        }
        State<String> stateLiveLiteral = f1207State$String$0$str$arg0$callinvoke$try$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-invoke$try$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient", f1217String$0$str$arg0$callinvoke$try$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient);
            f1207State$String$0$str$arg0$callinvoke$try$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-stop$fun-$anonymous$$arg-1$call-synchronized$catch$fun-run$class-UdpControlClient", offset = 3322)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-stop$fun-$anonymous$$arg-1$call-synchronized$catch$fun-run$class-UdpControlClient, reason: not valid java name */
    public final String m6568String$0$str$arg0$callstop$fun$anonymous$$arg1$callsynchronized$catch$funrun$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1218String$0$str$arg0$callstop$fun$anonymous$$arg1$callsynchronized$catch$funrun$classUdpControlClient;
        }
        State<String> stateLiveLiteral = f1208State$String$0$str$arg0$callstop$fun$anonymous$$arg1$callsynchronized$catch$funrun$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-stop$fun-$anonymous$$arg-1$call-synchronized$catch$fun-run$class-UdpControlClient", f1218String$0$str$arg0$callstop$fun$anonymous$$arg1$callsynchronized$catch$funrun$classUdpControlClient);
            f1208State$String$0$str$arg0$callstop$fun$anonymous$$arg1$callsynchronized$catch$funrun$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$arg-0$call-invoke$branch$if$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient", offset = 2507)
    /* JADX INFO: renamed from: String$2$str$arg-0$call-invoke$branch$if$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient, reason: not valid java name */
    public final String m6569String$2$str$arg0$callinvoke$branch$if$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1219String$2$str$arg0$callinvoke$branch$if$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient;
        }
        State<String> stateLiveLiteral = f1209State$String$2$str$arg0$callinvoke$branch$if$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$arg-0$call-invoke$branch$if$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient", f1219String$2$str$arg0$callinvoke$branch$if$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient);
            f1209State$String$2$str$arg0$callinvoke$branch$if$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$arg-0$call-invoke$try$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient", offset = 3074)
    /* JADX INFO: renamed from: String$2$str$arg-0$call-invoke$try$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient, reason: not valid java name */
    public final String m6570String$2$str$arg0$callinvoke$try$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1220String$2$str$arg0$callinvoke$try$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient;
        }
        State<String> stateLiveLiteral = f1210State$String$2$str$arg0$callinvoke$try$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$arg-0$call-invoke$try$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient", f1220String$2$str$arg0$callinvoke$try$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient);
            f1210State$String$2$str$arg0$callinvoke$try$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$4$str$arg-0$call-invoke$branch$if$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient", offset = 2532)
    /* JADX INFO: renamed from: String$4$str$arg-0$call-invoke$branch$if$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient, reason: not valid java name */
    public final String m6571String$4$str$arg0$callinvoke$branch$if$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1221String$4$str$arg0$callinvoke$branch$if$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient;
        }
        State<String> stateLiveLiteral = f1211State$String$4$str$arg0$callinvoke$branch$if$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$4$str$arg-0$call-invoke$branch$if$body$loop$fun-$anonymous$$arg-0$call-use$try$fun-run$class-UdpControlClient", f1221String$4$str$arg0$callinvoke$branch$if$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient);
            f1211State$String$4$str$arg0$callinvoke$branch$if$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-1$call-$init$$$$this$call-apply$set-worker$class-UdpControlClient", offset = 1498)
    /* JADX INFO: renamed from: String$arg-1$call-$init$$$$this$call-apply$set-worker$class-UdpControlClient, reason: not valid java name */
    public final String m6572String$arg1$call$init$$$$this$callapply$setworker$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1222String$arg1$call$init$$$$this$callapply$setworker$classUdpControlClient;
        }
        State<String> stateLiveLiteral = f1212State$String$arg1$call$init$$$$this$callapply$setworker$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-1$call-$init$$$$this$call-apply$set-worker$class-UdpControlClient", f1222String$arg1$call$init$$$$this$callapply$setworker$classUdpControlClient);
            f1212State$String$arg1$call$init$$$$this$callapply$setworker$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$fun-$anonymous$$arg-1$call-require$class-UdpControlClient", offset = 1178)
    /* JADX INFO: renamed from: String$fun-$anonymous$$arg-1$call-require$class-UdpControlClient, reason: not valid java name */
    public final String m6573String$fun$anonymous$$arg1$callrequire$classUdpControlClient() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1223String$fun$anonymous$$arg1$callrequire$classUdpControlClient;
        }
        State<String> stateLiveLiteral = f1213State$String$fun$anonymous$$arg1$callrequire$classUdpControlClient;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$fun-$anonymous$$arg-1$call-require$class-UdpControlClient", f1223String$fun$anonymous$$arg1$callrequire$classUdpControlClient);
            f1213State$String$fun$anonymous$$arg1$callrequire$classUdpControlClient = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
