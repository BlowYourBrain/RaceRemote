package vea.raceremote.control;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: UdpControlPacket.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/control/UdpControlPacket.kt")
public final class LiveLiterals$UdpControlPacketKt {

    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-UdpControlPacket, reason: not valid java name */
    private static boolean f1225Boolean$branch$when1$funequals$classUdpControlPacket;

    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-UdpControlPacket, reason: not valid java name */
    private static boolean f1226Boolean$branch$when2$funequals$classUdpControlPacket;

    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-UdpControlPacket, reason: not valid java name */
    private static boolean f1227Boolean$branch$when3$funequals$classUdpControlPacket;

    /* JADX INFO: renamed from: Boolean$branch$when-4$fun-equals$class-UdpControlPacket, reason: not valid java name */
    private static boolean f1228Boolean$branch$when4$funequals$classUdpControlPacket;

    /* JADX INFO: renamed from: Boolean$branch$when-5$fun-equals$class-UdpControlPacket, reason: not valid java name */
    private static boolean f1229Boolean$branch$when5$funequals$classUdpControlPacket;

    /* JADX INFO: renamed from: Boolean$branch$when-6$fun-equals$class-UdpControlPacket, reason: not valid java name */
    private static boolean f1230Boolean$branch$when6$funequals$classUdpControlPacket;

    /* JADX INFO: renamed from: Boolean$branch$when-7$fun-equals$class-UdpControlPacket, reason: not valid java name */
    private static boolean f1231Boolean$branch$when7$funequals$classUdpControlPacket;

    /* JADX INFO: renamed from: Boolean$branch$when-8$fun-equals$class-UdpControlPacket, reason: not valid java name */
    private static boolean f1232Boolean$branch$when8$funequals$classUdpControlPacket;

    /* JADX INFO: renamed from: Boolean$branch$when-9$fun-equals$class-UdpControlPacket, reason: not valid java name */
    private static boolean f1233Boolean$branch$when9$funequals$classUdpControlPacket;

    /* JADX INFO: renamed from: Int$$$this$call-until$$$this$call-fold$fun-get$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static int f1238Int$$$this$calluntil$$$this$callfold$funget$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$arg-0$call-require-2$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1239Int$$this$callrangeTo$$this$callcontains$arg0$callrequire2$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1240Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$cond$arg-0$call-require$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1242Int$$this$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$cond$cond$cond$arg-0$call-require$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1249Int$$this$callrangeTo$$this$callcontains$cond$cond$cond$arg0$callrequire$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: Int$arg-0$call-set$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1275Int$arg0$callset$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: Int$class-UdpControlPacket, reason: not valid java name */
    private static int f1300Int$classUdpControlPacket;

    /* JADX INFO: renamed from: Long$arg-0$call-fold$fun-get$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static long f1302Long$arg0$callfold$funget$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$$this$call-not$cond$cond$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static long f1309Long$arg1$callEQEQ$$this$callnot$cond$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: Long$param-basis$class-UdpControlPacket, reason: not valid java name */
    private static long f1310Long$parambasis$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Boolean$branch$when$fun-equals$class-UdpControlPacket, reason: not valid java name */
    private static State<Boolean> f1311State$Boolean$branch$when$funequals$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Boolean$branch$when-1$fun-equals$class-UdpControlPacket, reason: not valid java name */
    private static State<Boolean> f1312State$Boolean$branch$when1$funequals$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Boolean$branch$when-2$fun-equals$class-UdpControlPacket, reason: not valid java name */
    private static State<Boolean> f1313State$Boolean$branch$when2$funequals$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Boolean$branch$when-3$fun-equals$class-UdpControlPacket, reason: not valid java name */
    private static State<Boolean> f1314State$Boolean$branch$when3$funequals$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Boolean$branch$when-4$fun-equals$class-UdpControlPacket, reason: not valid java name */
    private static State<Boolean> f1315State$Boolean$branch$when4$funequals$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Boolean$branch$when-5$fun-equals$class-UdpControlPacket, reason: not valid java name */
    private static State<Boolean> f1316State$Boolean$branch$when5$funequals$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Boolean$branch$when-6$fun-equals$class-UdpControlPacket, reason: not valid java name */
    private static State<Boolean> f1317State$Boolean$branch$when6$funequals$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Boolean$branch$when-7$fun-equals$class-UdpControlPacket, reason: not valid java name */
    private static State<Boolean> f1318State$Boolean$branch$when7$funequals$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Boolean$branch$when-8$fun-equals$class-UdpControlPacket, reason: not valid java name */
    private static State<Boolean> f1319State$Boolean$branch$when8$funequals$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Boolean$branch$when-9$fun-equals$class-UdpControlPacket, reason: not valid java name */
    private static State<Boolean> f1320State$Boolean$branch$when9$funequals$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Boolean$fun-equals$class-UdpControlPacket, reason: not valid java name */
    private static State<Boolean> f1321State$Boolean$funequals$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Byte$arg-1$call-set$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Byte> f1322State$Byte$arg1$callset$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Byte$arg-1$call-set-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Byte> f1323State$Byte$arg1$callset1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Byte$arg-1$call-set-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Byte> f1324State$Byte$arg1$callset2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$$$this$call-until$$$this$call-fold$fun-get$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1325State$Int$$$this$calluntil$$$this$callfold$funget$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$arg-0$call-require-2$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1326State$Int$$this$callrangeTo$$this$callcontains$arg0$callrequire2$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1327State$Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require-1$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1328State$Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$branch$cond$arg-0$call-require$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1329State$Int$$this$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$branch$cond$arg-0$call-require-1$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1330State$Int$$this$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire1$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$branch$cond$cond$arg-0$call-require$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1331State$Int$$this$callrangeTo$$this$callcontains$branch$cond$cond$arg0$callrequire$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$branch$cond$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1332State$Int$$this$callrangeTo$$this$callcontains$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$branch$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1333State$Int$$this$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1334State$Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$cond$cond$arg-0$call-require-1$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1335State$Int$$this$callrangeTo$$this$callcontains$cond$cond$arg0$callrequire1$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$cond$cond$cond$arg-0$call-require$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1336State$Int$$this$callrangeTo$$this$callcontains$cond$cond$cond$arg0$callrequire$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-times$arg-0$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-get$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1337State$Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funget$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-times$arg-0$call-ushr$$this$call-toByte$arg-1$call-set$fun-$anonymous$$arg-1$call-repeat$fun-put$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1338State$Int$$this$calltimes$arg0$callushr$$this$calltoByte$arg1$callset$fun$anonymous$$arg1$callrepeat$funput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1339State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-and$arg-0$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1340State$Int$arg0$calland$arg0$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-get$$this$call-toInt$$this$call-and$arg-0$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1341State$Int$arg0$callget$$this$calltoInt$$this$calland$arg0$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1342State$Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-get$$this$call-toShort$$this$call-toInt$arg-4$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1343State$Int$arg0$callget$$this$calltoShort$$this$calltoInt$arg4$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-get$$this$call-toShort$$this$call-toInt$arg-5$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1344State$Int$arg0$callget$$this$calltoShort$$this$calltoInt$arg5$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-get$arg-1$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1345State$Int$arg0$callget$arg1$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-get$arg-2$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1346State$Int$arg0$callget$arg2$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-get$arg-3$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1347State$Int$arg0$callget$arg3$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-get$arg-6$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1348State$Int$arg0$callget$arg6$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-get$arg-7$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1349State$Int$arg0$callget$arg7$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-put$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1350State$Int$arg0$callput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-put-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1351State$Int$arg0$callput1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-put-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1352State$Int$arg0$callput2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-put-3$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1353State$Int$arg0$callput3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-put-4$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1354State$Int$arg0$callput4$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-put-5$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1355State$Int$arg0$callput5$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-put-6$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1356State$Int$arg0$callput6$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rangeTo$$this$call-contains$branch$cond$arg-0$call-require-1$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1357State$Int$arg0$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire1$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rangeTo$$this$call-contains$branch$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1358State$Int$arg0$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1359State$Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rangeTo$$this$call-contains$cond$cond$arg-0$call-require-1$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1360State$Int$arg0$callrangeTo$$this$callcontains$cond$cond$arg0$callrequire1$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rangeTo$$this$call-contains$cond$cond$cond$arg-0$call-require$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1361State$Int$arg0$callrangeTo$$this$callcontains$cond$cond$cond$arg0$callrequire$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-set$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1362State$Int$arg0$callset$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-set-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1363State$Int$arg0$callset1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-set-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1364State$Int$arg0$callset2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-set-3$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1365State$Int$arg0$callset3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1366State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1367State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-2$fun-hashCode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1368State$Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-3$fun-hashCode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1369State$Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-4$fun-hashCode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1370State$Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-5$fun-hashCode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1371State$Int$arg0$calltimes$$this$callplus$setresult5$funhashCode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-6$fun-hashCode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1372State$Int$arg0$calltimes$$this$callplus$setresult6$funhashCode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-1$call-get$$this$call-toShort$$this$call-toInt$arg-4$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1373State$Int$arg1$callget$$this$calltoShort$$this$calltoInt$arg4$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-1$call-get$$this$call-toShort$$this$call-toInt$arg-5$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1374State$Int$arg1$callget$$this$calltoShort$$this$calltoInt$arg5$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-1$call-get$arg-1$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1375State$Int$arg1$callget$arg1$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-1$call-get$arg-2$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1376State$Int$arg1$callget$arg2$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-1$call-get$arg-3$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1377State$Int$arg1$callget$arg3$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-1$call-get$arg-6$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1378State$Int$arg1$callget$arg6$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-1$call-get$arg-7$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1379State$Int$arg1$callget$arg7$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-1$call-put$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1380State$Int$arg1$callput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-1$call-put-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1381State$Int$arg1$callput1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-1$call-put-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1382State$Int$arg1$callput2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-1$call-put-3$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1383State$Int$arg1$callput3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-1$call-put-4$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1384State$Int$arg1$callput4$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-1$call-put-5$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1385State$Int$arg1$callput5$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$arg-1$call-put-6$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1386State$Int$arg1$callput6$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Int$class-UdpControlPacket, reason: not valid java name */
    private static State<Integer> f1387State$Int$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Long$arg-0$call-and$$this$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-get$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Long> f1388State$Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funget$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Long$arg-0$call-fold$fun-get$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Long> f1389State$Long$arg0$callfold$funget$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Long$arg-0$call-rangeTo$$this$call-contains$arg-0$call-require-2$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Long> f1390State$Long$arg0$callrangeTo$$this$callcontains$arg0$callrequire2$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Long$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Long> f1391State$Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Long$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require-1$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Long> f1392State$Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Long$arg-0$call-rangeTo$$this$call-contains$branch$cond$arg-0$call-require$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Long> f1393State$Long$arg0$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Long$arg-0$call-rangeTo$$this$call-contains$branch$cond$cond$arg-0$call-require$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static State<Long> f1394State$Long$arg0$callrangeTo$$this$callcontains$branch$cond$cond$arg0$callrequire$funencode$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Long$arg-0$call-rangeTo$$this$call-contains$branch$cond$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Long> f1395State$Long$arg0$callrangeTo$$this$callcontains$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Long$arg-1$call-EQEQ$$this$call-not$cond$cond$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static State<Long> f1396State$Long$arg1$callEQEQ$$this$callnot$cond$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket;

    /* JADX INFO: renamed from: State$Long$param-basis$class-UdpControlPacket, reason: not valid java name */
    private static State<Long> f1397State$Long$parambasis$classUdpControlPacket;

    /* JADX INFO: renamed from: State$String$0$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static State<String> f1398State$String$0$str$funtoString$classUdpControlPacket;

    /* JADX INFO: renamed from: State$String$1$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static State<String> f1399State$String$1$str$funtoString$classUdpControlPacket;

    /* JADX INFO: renamed from: State$String$10$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static State<String> f1400State$String$10$str$funtoString$classUdpControlPacket;

    /* JADX INFO: renamed from: State$String$12$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static State<String> f1401State$String$12$str$funtoString$classUdpControlPacket;

    /* JADX INFO: renamed from: State$String$13$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static State<String> f1402State$String$13$str$funtoString$classUdpControlPacket;

    /* JADX INFO: renamed from: State$String$15$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static State<String> f1403State$String$15$str$funtoString$classUdpControlPacket;

    /* JADX INFO: renamed from: State$String$16$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static State<String> f1404State$String$16$str$funtoString$classUdpControlPacket;

    /* JADX INFO: renamed from: State$String$18$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static State<String> f1405State$String$18$str$funtoString$classUdpControlPacket;

    /* JADX INFO: renamed from: State$String$19$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static State<String> f1406State$String$19$str$funtoString$classUdpControlPacket;

    /* JADX INFO: renamed from: State$String$21$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static State<String> f1407State$String$21$str$funtoString$classUdpControlPacket;

    /* JADX INFO: renamed from: State$String$22$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static State<String> f1408State$String$22$str$funtoString$classUdpControlPacket;

    /* JADX INFO: renamed from: State$String$24$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static State<String> f1409State$String$24$str$funtoString$classUdpControlPacket;

    /* JADX INFO: renamed from: State$String$3$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static State<String> f1410State$String$3$str$funtoString$classUdpControlPacket;

    /* JADX INFO: renamed from: State$String$4$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static State<String> f1411State$String$4$str$funtoString$classUdpControlPacket;

    /* JADX INFO: renamed from: State$String$6$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static State<String> f1412State$String$6$str$funtoString$classUdpControlPacket;

    /* JADX INFO: renamed from: State$String$7$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static State<String> f1413State$String$7$str$funtoString$classUdpControlPacket;

    /* JADX INFO: renamed from: State$String$9$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static State<String> f1414State$String$9$str$funtoString$classUdpControlPacket;
    public static final LiveLiterals$UdpControlPacketKt INSTANCE = new LiveLiterals$UdpControlPacketKt();

    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$cond$cond$cond$arg-0$call-require$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1274Int$arg0$callrangeTo$$this$callcontains$cond$cond$cond$arg0$callrequire$funencode$classUdpControlPacket = 255;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$cond$cond$arg-0$call-require$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1244Int$$this$callrangeTo$$this$callcontains$branch$cond$cond$arg0$callrequire$funencode$classUdpControlPacket = 1;

    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$branch$cond$cond$arg-0$call-require$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static long f1307Long$arg0$callrangeTo$$this$callcontains$branch$cond$cond$arg0$callrequire$funencode$classUdpControlPacket = 4294967295L;

    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$branch$cond$arg-0$call-require$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static long f1306Long$arg0$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire$funencode$classUdpControlPacket = 4294967295L;

    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static long f1304Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funencode$classUdpControlPacket = 4294967295L;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$cond$cond$arg-0$call-require-1$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1248Int$$this$callrangeTo$$this$callcontains$cond$cond$arg0$callrequire1$funencode$classUdpControlPacket = -1000;

    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$cond$cond$arg-0$call-require-1$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1273Int$arg0$callrangeTo$$this$callcontains$cond$cond$arg0$callrequire1$funencode$classUdpControlPacket = 1000;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$cond$arg-0$call-require-1$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1243Int$$this$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire1$funencode$classUdpControlPacket = -1000;

    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$cond$arg-0$call-require-1$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1270Int$arg0$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire1$funencode$classUdpControlPacket = 1000;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require-1$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1241Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classUdpControlPacket = 1;

    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require-1$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static long f1305Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classUdpControlPacket = 281474976710655L;

    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$arg-0$call-require-2$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static long f1303Long$arg0$callrangeTo$$this$callcontains$arg0$callrequire2$funencode$classUdpControlPacket = 4294967295L;

    /* JADX INFO: renamed from: Byte$arg-1$call-set$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static byte f1235Byte$arg1$callset$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = 82;

    /* JADX INFO: renamed from: Int$arg-0$call-set-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1276Int$arg0$callset1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = 1;

    /* JADX INFO: renamed from: Byte$arg-1$call-set-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static byte f1236Byte$arg1$callset1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = 85;

    /* JADX INFO: renamed from: Int$arg-0$call-set-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1277Int$arg0$callset2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = 2;

    /* JADX INFO: renamed from: Byte$arg-1$call-set-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static byte f1237Byte$arg1$callset2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = 1;

    /* JADX INFO: renamed from: Int$arg-0$call-set-3$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1278Int$arg0$callset3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = 3;

    /* JADX INFO: renamed from: Int$$this$call-times$arg-0$call-ushr$$this$call-toByte$arg-1$call-set$fun-$anonymous$$arg-1$call-repeat$fun-put$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1251Int$$this$calltimes$arg0$callushr$$this$calltoByte$arg1$callset$fun$anonymous$$arg1$callrepeat$funput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = 8;

    /* JADX INFO: renamed from: Int$arg-0$call-put$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1263Int$arg0$callput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = 4;

    /* JADX INFO: renamed from: Int$arg-1$call-put$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1293Int$arg1$callput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = 4;

    /* JADX INFO: renamed from: Int$arg-0$call-put-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1264Int$arg0$callput1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = 8;

    /* JADX INFO: renamed from: Int$arg-1$call-put-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1294Int$arg1$callput1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = 4;

    /* JADX INFO: renamed from: Int$arg-0$call-put-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1265Int$arg0$callput2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = 12;

    /* JADX INFO: renamed from: Int$arg-1$call-put-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1295Int$arg1$callput2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = 4;

    /* JADX INFO: renamed from: Int$arg-0$call-put-3$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1266Int$arg0$callput3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = 16;

    /* JADX INFO: renamed from: Int$arg-1$call-put-3$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1296Int$arg1$callput3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = 2;

    /* JADX INFO: renamed from: Int$arg-0$call-put-4$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1267Int$arg0$callput4$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = 18;

    /* JADX INFO: renamed from: Int$arg-1$call-put-4$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1297Int$arg1$callput4$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = 2;

    /* JADX INFO: renamed from: Int$arg-0$call-put-5$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1268Int$arg0$callput5$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = 20;

    /* JADX INFO: renamed from: Int$arg-1$call-put-5$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1298Int$arg1$callput5$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = 4;

    /* JADX INFO: renamed from: Int$arg-0$call-put-6$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1269Int$arg0$callput6$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = 24;

    /* JADX INFO: renamed from: Int$arg-1$call-put-6$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    private static int f1299Int$arg1$callput6$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = 8;

    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static int f1255Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classUdpControlPacket = 2;

    /* JADX INFO: renamed from: Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static int f1252Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classUdpControlPacket = 1;

    /* JADX INFO: renamed from: Long$arg-0$call-and$$this$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-get$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static long f1301Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funget$fundecode$classCompanion$classUdpControlPacket = 255;

    /* JADX INFO: renamed from: Int$$this$call-times$arg-0$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-get$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static int f1250Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funget$fundecode$classCompanion$classUdpControlPacket = 8;

    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toInt$$this$call-and$arg-0$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static int f1254Int$arg0$callget$$this$calltoInt$$this$calland$arg0$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = 3;

    /* JADX INFO: renamed from: Int$arg-0$call-and$arg-0$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static int f1253Int$arg0$calland$arg0$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = 255;

    /* JADX INFO: renamed from: Int$arg-0$call-get$arg-1$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static int f1258Int$arg0$callget$arg1$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = 4;

    /* JADX INFO: renamed from: Int$arg-1$call-get$arg-1$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static int f1288Int$arg1$callget$arg1$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = 4;

    /* JADX INFO: renamed from: Int$arg-0$call-get$arg-2$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static int f1259Int$arg0$callget$arg2$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = 8;

    /* JADX INFO: renamed from: Int$arg-1$call-get$arg-2$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static int f1289Int$arg1$callget$arg2$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = 4;

    /* JADX INFO: renamed from: Int$arg-0$call-get$arg-3$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static int f1260Int$arg0$callget$arg3$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = 12;

    /* JADX INFO: renamed from: Int$arg-1$call-get$arg-3$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static int f1290Int$arg1$callget$arg3$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = 4;

    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toShort$$this$call-toInt$arg-4$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static int f1256Int$arg0$callget$$this$calltoShort$$this$calltoInt$arg4$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = 16;

    /* JADX INFO: renamed from: Int$arg-1$call-get$$this$call-toShort$$this$call-toInt$arg-4$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static int f1286Int$arg1$callget$$this$calltoShort$$this$calltoInt$arg4$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = 2;

    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toShort$$this$call-toInt$arg-5$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static int f1257Int$arg0$callget$$this$calltoShort$$this$calltoInt$arg5$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = 18;

    /* JADX INFO: renamed from: Int$arg-1$call-get$$this$call-toShort$$this$call-toInt$arg-5$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static int f1287Int$arg1$callget$$this$calltoShort$$this$calltoInt$arg5$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = 2;

    /* JADX INFO: renamed from: Int$arg-0$call-get$arg-6$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static int f1261Int$arg0$callget$arg6$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = 24;

    /* JADX INFO: renamed from: Int$arg-1$call-get$arg-6$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static int f1291Int$arg1$callget$arg6$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = 8;

    /* JADX INFO: renamed from: Int$arg-0$call-get$arg-7$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static int f1262Int$arg0$callget$arg7$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = 20;

    /* JADX INFO: renamed from: Int$arg-1$call-get$arg-7$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static int f1292Int$arg1$callget$arg7$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = 4;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$cond$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static int f1245Int$$this$callrangeTo$$this$callcontains$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket = 1;

    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$branch$cond$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static long f1308Long$arg0$callrangeTo$$this$callcontains$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket = 281474976710655L;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static int f1246Int$$this$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket = -1000;

    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static int f1271Int$arg0$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket = 1000;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static int f1247Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket = -1000;

    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    private static int f1272Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket = 1000;

    /* JADX INFO: renamed from: String$0$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static String f1415String$0$str$funtoString$classUdpControlPacket = "UdpControlPacket(";

    /* JADX INFO: renamed from: String$1$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static String f1416String$1$str$funtoString$classUdpControlPacket = "kind=";

    /* JADX INFO: renamed from: String$3$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static String f1427String$3$str$funtoString$classUdpControlPacket = ", ";

    /* JADX INFO: renamed from: String$4$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static String f1428String$4$str$funtoString$classUdpControlPacket = "attempt=";

    /* JADX INFO: renamed from: String$6$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static String f1429String$6$str$funtoString$classUdpControlPacket = ", ";

    /* JADX INFO: renamed from: String$7$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static String f1430String$7$str$funtoString$classUdpControlPacket = "token=";

    /* JADX INFO: renamed from: String$9$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static String f1431String$9$str$funtoString$classUdpControlPacket = ", ";

    /* JADX INFO: renamed from: String$10$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static String f1417String$10$str$funtoString$classUdpControlPacket = "sequence=";

    /* JADX INFO: renamed from: String$12$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static String f1418String$12$str$funtoString$classUdpControlPacket = ", ";

    /* JADX INFO: renamed from: String$13$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static String f1419String$13$str$funtoString$classUdpControlPacket = "throttle=";

    /* JADX INFO: renamed from: String$15$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static String f1420String$15$str$funtoString$classUdpControlPacket = ", ";

    /* JADX INFO: renamed from: String$16$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static String f1421String$16$str$funtoString$classUdpControlPacket = "steering=";

    /* JADX INFO: renamed from: String$18$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static String f1422String$18$str$funtoString$classUdpControlPacket = ", ";

    /* JADX INFO: renamed from: String$19$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static String f1423String$19$str$funtoString$classUdpControlPacket = "chipId=";

    /* JADX INFO: renamed from: String$21$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static String f1424String$21$str$funtoString$classUdpControlPacket = ", ";

    /* JADX INFO: renamed from: String$22$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static String f1425String$22$str$funtoString$classUdpControlPacket = "basis=";

    /* JADX INFO: renamed from: String$24$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    private static String f1426String$24$str$funtoString$classUdpControlPacket = ")";

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-UdpControlPacket, reason: not valid java name */
    private static int f1279Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classUdpControlPacket = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-UdpControlPacket, reason: not valid java name */
    private static int f1280Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classUdpControlPacket = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-2$fun-hashCode$class-UdpControlPacket, reason: not valid java name */
    private static int f1281Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classUdpControlPacket = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-3$fun-hashCode$class-UdpControlPacket, reason: not valid java name */
    private static int f1282Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classUdpControlPacket = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-4$fun-hashCode$class-UdpControlPacket, reason: not valid java name */
    private static int f1283Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classUdpControlPacket = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-5$fun-hashCode$class-UdpControlPacket, reason: not valid java name */
    private static int f1284Int$arg0$calltimes$$this$callplus$setresult5$funhashCode$classUdpControlPacket = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-6$fun-hashCode$class-UdpControlPacket, reason: not valid java name */
    private static int f1285Int$arg0$calltimes$$this$callplus$setresult6$funhashCode$classUdpControlPacket = 31;

    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-UdpControlPacket, reason: not valid java name */
    private static boolean f1224Boolean$branch$when$funequals$classUdpControlPacket = true;

    /* JADX INFO: renamed from: Boolean$fun-equals$class-UdpControlPacket, reason: not valid java name */
    private static boolean f1234Boolean$funequals$classUdpControlPacket = true;

    @LiveLiteralInfo(key = "Boolean$branch$when$fun-equals$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-UdpControlPacket, reason: not valid java name */
    public final boolean m6574Boolean$branch$when$funequals$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1224Boolean$branch$when$funequals$classUdpControlPacket;
        }
        State<Boolean> stateLiveLiteral = f1311State$Boolean$branch$when$funequals$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when$fun-equals$class-UdpControlPacket", Boolean.valueOf(f1224Boolean$branch$when$funequals$classUdpControlPacket));
            f1311State$Boolean$branch$when$funequals$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-1$fun-equals$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-UdpControlPacket, reason: not valid java name */
    public final boolean m6575Boolean$branch$when1$funequals$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1225Boolean$branch$when1$funequals$classUdpControlPacket;
        }
        State<Boolean> stateLiveLiteral = f1312State$Boolean$branch$when1$funequals$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-1$fun-equals$class-UdpControlPacket", Boolean.valueOf(f1225Boolean$branch$when1$funequals$classUdpControlPacket));
            f1312State$Boolean$branch$when1$funequals$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-2$fun-equals$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-UdpControlPacket, reason: not valid java name */
    public final boolean m6576Boolean$branch$when2$funequals$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1226Boolean$branch$when2$funequals$classUdpControlPacket;
        }
        State<Boolean> stateLiveLiteral = f1313State$Boolean$branch$when2$funequals$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-2$fun-equals$class-UdpControlPacket", Boolean.valueOf(f1226Boolean$branch$when2$funequals$classUdpControlPacket));
            f1313State$Boolean$branch$when2$funequals$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-3$fun-equals$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-UdpControlPacket, reason: not valid java name */
    public final boolean m6577Boolean$branch$when3$funequals$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1227Boolean$branch$when3$funequals$classUdpControlPacket;
        }
        State<Boolean> stateLiveLiteral = f1314State$Boolean$branch$when3$funequals$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-3$fun-equals$class-UdpControlPacket", Boolean.valueOf(f1227Boolean$branch$when3$funequals$classUdpControlPacket));
            f1314State$Boolean$branch$when3$funequals$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-4$fun-equals$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-4$fun-equals$class-UdpControlPacket, reason: not valid java name */
    public final boolean m6578Boolean$branch$when4$funequals$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1228Boolean$branch$when4$funequals$classUdpControlPacket;
        }
        State<Boolean> stateLiveLiteral = f1315State$Boolean$branch$when4$funequals$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-4$fun-equals$class-UdpControlPacket", Boolean.valueOf(f1228Boolean$branch$when4$funequals$classUdpControlPacket));
            f1315State$Boolean$branch$when4$funequals$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-5$fun-equals$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-5$fun-equals$class-UdpControlPacket, reason: not valid java name */
    public final boolean m6579Boolean$branch$when5$funequals$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1229Boolean$branch$when5$funequals$classUdpControlPacket;
        }
        State<Boolean> stateLiveLiteral = f1316State$Boolean$branch$when5$funequals$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-5$fun-equals$class-UdpControlPacket", Boolean.valueOf(f1229Boolean$branch$when5$funequals$classUdpControlPacket));
            f1316State$Boolean$branch$when5$funequals$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-6$fun-equals$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-6$fun-equals$class-UdpControlPacket, reason: not valid java name */
    public final boolean m6580Boolean$branch$when6$funequals$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1230Boolean$branch$when6$funequals$classUdpControlPacket;
        }
        State<Boolean> stateLiveLiteral = f1317State$Boolean$branch$when6$funequals$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-6$fun-equals$class-UdpControlPacket", Boolean.valueOf(f1230Boolean$branch$when6$funequals$classUdpControlPacket));
            f1317State$Boolean$branch$when6$funequals$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-7$fun-equals$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-7$fun-equals$class-UdpControlPacket, reason: not valid java name */
    public final boolean m6581Boolean$branch$when7$funequals$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1231Boolean$branch$when7$funequals$classUdpControlPacket;
        }
        State<Boolean> stateLiveLiteral = f1318State$Boolean$branch$when7$funequals$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-7$fun-equals$class-UdpControlPacket", Boolean.valueOf(f1231Boolean$branch$when7$funequals$classUdpControlPacket));
            f1318State$Boolean$branch$when7$funequals$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-8$fun-equals$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-8$fun-equals$class-UdpControlPacket, reason: not valid java name */
    public final boolean m6582Boolean$branch$when8$funequals$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1232Boolean$branch$when8$funequals$classUdpControlPacket;
        }
        State<Boolean> stateLiveLiteral = f1319State$Boolean$branch$when8$funequals$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-8$fun-equals$class-UdpControlPacket", Boolean.valueOf(f1232Boolean$branch$when8$funequals$classUdpControlPacket));
            f1319State$Boolean$branch$when8$funequals$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-9$fun-equals$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-9$fun-equals$class-UdpControlPacket, reason: not valid java name */
    public final boolean m6583Boolean$branch$when9$funequals$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1233Boolean$branch$when9$funequals$classUdpControlPacket;
        }
        State<Boolean> stateLiveLiteral = f1320State$Boolean$branch$when9$funequals$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-9$fun-equals$class-UdpControlPacket", Boolean.valueOf(f1233Boolean$branch$when9$funequals$classUdpControlPacket));
            f1320State$Boolean$branch$when9$funequals$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$fun-equals$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: Boolean$fun-equals$class-UdpControlPacket, reason: not valid java name */
    public final boolean m6584Boolean$funequals$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1234Boolean$funequals$classUdpControlPacket;
        }
        State<Boolean> stateLiveLiteral = f1321State$Boolean$funequals$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$fun-equals$class-UdpControlPacket", Boolean.valueOf(f1234Boolean$funequals$classUdpControlPacket));
            f1321State$Boolean$funequals$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Byte$arg-1$call-set$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", offset = 689)
    /* JADX INFO: renamed from: Byte$arg-1$call-set$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final byte m6585Byte$arg1$callset$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1235Byte$arg1$callset$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        }
        State<Byte> stateLiveLiteral = f1322State$Byte$arg1$callset$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Byte$arg-1$call-set$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", Byte.valueOf(f1235Byte$arg1$callset$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket));
            f1322State$Byte$arg1$callset$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().byteValue();
    }

    @LiveLiteralInfo(key = "Byte$arg-1$call-set-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", offset = 704)
    /* JADX INFO: renamed from: Byte$arg-1$call-set-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final byte m6586Byte$arg1$callset1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1236Byte$arg1$callset1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        }
        State<Byte> stateLiveLiteral = f1323State$Byte$arg1$callset1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Byte$arg-1$call-set-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", Byte.valueOf(f1236Byte$arg1$callset1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket));
            f1323State$Byte$arg1$callset1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().byteValue();
    }

    @LiveLiteralInfo(key = "Byte$arg-1$call-set-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", offset = 719)
    /* JADX INFO: renamed from: Byte$arg-1$call-set-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final byte m6587Byte$arg1$callset2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1237Byte$arg1$callset2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        }
        State<Byte> stateLiveLiteral = f1324State$Byte$arg1$callset2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Byte$arg-1$call-set-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", Byte.valueOf(f1237Byte$arg1$callset2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket));
            f1324State$Byte$arg1$callset2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().byteValue();
    }

    @LiveLiteralInfo(key = "Int$$$this$call-until$$$this$call-fold$fun-get$fun-decode$class-Companion$class-UdpControlPacket", offset = 1592)
    /* JADX INFO: renamed from: Int$$$this$call-until$$$this$call-fold$fun-get$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final int m6588Int$$$this$calluntil$$$this$callfold$funget$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1238Int$$$this$calluntil$$$this$callfold$funget$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1325State$Int$$$this$calluntil$$$this$callfold$funget$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$$this$call-until$$$this$call-fold$fun-get$fun-decode$class-Companion$class-UdpControlPacket", Integer.valueOf(f1238Int$$$this$calluntil$$$this$callfold$funget$fundecode$classCompanion$classUdpControlPacket));
            f1325State$Int$$$this$calluntil$$$this$callfold$funget$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$arg-0$call-require-2$fun-encode$class-UdpControlPacket", offset = 603)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$arg-0$call-require-2$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6589Int$$this$callrangeTo$$this$callcontains$arg0$callrequire2$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1239Int$$this$callrangeTo$$this$callcontains$arg0$callrequire2$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1326State$Int$$this$callrangeTo$$this$callcontains$arg0$callrequire2$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$arg-0$call-require-2$fun-encode$class-UdpControlPacket", Integer.valueOf(f1239Int$$this$callrangeTo$$this$callcontains$arg0$callrequire2$funencode$classUdpControlPacket));
            f1326State$Int$$this$callrangeTo$$this$callcontains$arg0$callrequire2$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-encode$class-UdpControlPacket", offset = 462)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6590Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1240Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1327State$Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-encode$class-UdpControlPacket", Integer.valueOf(f1240Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funencode$classUdpControlPacket));
            f1327State$Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require-1$fun-encode$class-UdpControlPacket", offset = 558)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require-1$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6591Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1241Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1328State$Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require-1$fun-encode$class-UdpControlPacket", Integer.valueOf(f1241Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classUdpControlPacket));
            f1328State$Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$branch$cond$arg-0$call-require$fun-encode$class-UdpControlPacket", offset = 432)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$cond$arg-0$call-require$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6592Int$$this$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1242Int$$this$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1329State$Int$$this$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$branch$cond$arg-0$call-require$fun-encode$class-UdpControlPacket", Integer.valueOf(f1242Int$$this$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire$funencode$classUdpControlPacket));
            f1329State$Int$$this$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$branch$cond$arg-0$call-require-1$fun-encode$class-UdpControlPacket", offset = 533)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$cond$arg-0$call-require-1$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6593Int$$this$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire1$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1243Int$$this$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire1$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1330State$Int$$this$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire1$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$branch$cond$arg-0$call-require-1$fun-encode$class-UdpControlPacket", Integer.valueOf(f1243Int$$this$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire1$funencode$classUdpControlPacket));
            f1330State$Int$$this$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire1$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$branch$cond$cond$arg-0$call-require$fun-encode$class-UdpControlPacket", offset = 405)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$cond$cond$arg-0$call-require$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6594Int$$this$callrangeTo$$this$callcontains$branch$cond$cond$arg0$callrequire$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1244Int$$this$callrangeTo$$this$callcontains$branch$cond$cond$arg0$callrequire$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1331State$Int$$this$callrangeTo$$this$callcontains$branch$cond$cond$arg0$callrequire$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$branch$cond$cond$arg-0$call-require$fun-encode$class-UdpControlPacket", Integer.valueOf(f1244Int$$this$callrangeTo$$this$callcontains$branch$cond$cond$arg0$callrequire$funencode$classUdpControlPacket));
            f1331State$Int$$this$callrangeTo$$this$callcontains$branch$cond$cond$arg0$callrequire$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$branch$cond$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket", offset = 1979)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$cond$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final int m6595Int$$this$callrangeTo$$this$callcontains$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1245Int$$this$callrangeTo$$this$callcontains$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1332State$Int$$this$callrangeTo$$this$callcontains$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$branch$cond$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket", Integer.valueOf(f1245Int$$this$callrangeTo$$this$callcontains$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket));
            f1332State$Int$$this$callrangeTo$$this$callcontains$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$branch$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket", offset = 2032)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final int m6596Int$$this$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1246Int$$this$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1333State$Int$$this$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$branch$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket", Integer.valueOf(f1246Int$$this$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket));
            f1333State$Int$$this$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket", offset = 2062)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final int m6597Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1247Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1334State$Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket", Integer.valueOf(f1247Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket));
            f1334State$Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$cond$cond$arg-0$call-require-1$fun-encode$class-UdpControlPacket", offset = 506)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$cond$cond$arg-0$call-require-1$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6598Int$$this$callrangeTo$$this$callcontains$cond$cond$arg0$callrequire1$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1248Int$$this$callrangeTo$$this$callcontains$cond$cond$arg0$callrequire1$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1335State$Int$$this$callrangeTo$$this$callcontains$cond$cond$arg0$callrequire1$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$cond$cond$arg-0$call-require-1$fun-encode$class-UdpControlPacket", Integer.valueOf(f1248Int$$this$callrangeTo$$this$callcontains$cond$cond$arg0$callrequire1$funencode$classUdpControlPacket));
            f1335State$Int$$this$callrangeTo$$this$callcontains$cond$cond$arg0$callrequire1$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$cond$cond$cond$arg-0$call-require$fun-encode$class-UdpControlPacket", offset = 384)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$cond$cond$cond$arg-0$call-require$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6599Int$$this$callrangeTo$$this$callcontains$cond$cond$cond$arg0$callrequire$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1249Int$$this$callrangeTo$$this$callcontains$cond$cond$cond$arg0$callrequire$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1336State$Int$$this$callrangeTo$$this$callcontains$cond$cond$cond$arg0$callrequire$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$cond$cond$cond$arg-0$call-require$fun-encode$class-UdpControlPacket", Integer.valueOf(f1249Int$$this$callrangeTo$$this$callcontains$cond$cond$cond$arg0$callrequire$funencode$classUdpControlPacket));
            f1336State$Int$$this$callrangeTo$$this$callcontains$cond$cond$cond$arg0$callrequire$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-times$arg-0$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-get$fun-decode$class-Companion$class-UdpControlPacket", offset = 1697)
    /* JADX INFO: renamed from: Int$$this$call-times$arg-0$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-get$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final int m6600Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funget$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1250Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funget$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1337State$Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funget$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-times$arg-0$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-get$fun-decode$class-Companion$class-UdpControlPacket", Integer.valueOf(f1250Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funget$fundecode$classCompanion$classUdpControlPacket));
            f1337State$Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funget$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-times$arg-0$call-ushr$$this$call-toByte$arg-1$call-set$fun-$anonymous$$arg-1$call-repeat$fun-put$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", offset = 871)
    /* JADX INFO: renamed from: Int$$this$call-times$arg-0$call-ushr$$this$call-toByte$arg-1$call-set$fun-$anonymous$$arg-1$call-repeat$fun-put$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6601Int$$this$calltimes$arg0$callushr$$this$calltoByte$arg1$callset$fun$anonymous$$arg1$callrepeat$funput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1251Int$$this$calltimes$arg0$callushr$$this$calltoByte$arg1$callset$fun$anonymous$$arg1$callrepeat$funput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1338State$Int$$this$calltimes$arg0$callushr$$this$calltoByte$arg1$callset$fun$anonymous$$arg1$callrepeat$funput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-times$arg-0$call-ushr$$this$call-toByte$arg-1$call-set$fun-$anonymous$$arg-1$call-repeat$fun-put$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", Integer.valueOf(f1251Int$$this$calltimes$arg0$callushr$$this$calltoByte$arg1$callset$fun$anonymous$$arg1$callrepeat$funput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket));
            f1338State$Int$$this$calltimes$arg0$callushr$$this$calltoByte$arg1$callset$fun$anonymous$$arg1$callrepeat$funput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-Companion$class-UdpControlPacket", offset = 1515)
    /* JADX INFO: renamed from: Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final int m6602Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1252Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1339State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-Companion$class-UdpControlPacket", Integer.valueOf(f1252Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classUdpControlPacket));
            f1339State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-and$arg-0$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", offset = 1777)
    /* JADX INFO: renamed from: Int$arg-0$call-and$arg-0$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final int m6603Int$arg0$calland$arg0$call$init$$valp$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1253Int$arg0$calland$arg0$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1340State$Int$arg0$calland$arg0$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-and$arg-0$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", Integer.valueOf(f1253Int$arg0$calland$arg0$call$init$$valp$fundecode$classCompanion$classUdpControlPacket));
            f1340State$Int$arg0$calland$arg0$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-get$$this$call-toInt$$this$call-and$arg-0$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", offset = 1762)
    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toInt$$this$call-and$arg-0$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final int m6604Int$arg0$callget$$this$calltoInt$$this$calland$arg0$call$init$$valp$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1254Int$arg0$callget$$this$calltoInt$$this$calland$arg0$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1341State$Int$arg0$callget$$this$calltoInt$$this$calland$arg0$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-get$$this$call-toInt$$this$call-and$arg-0$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", Integer.valueOf(f1254Int$arg0$callget$$this$calltoInt$$this$calland$arg0$call$init$$valp$fundecode$classCompanion$classUdpControlPacket));
            f1341State$Int$arg0$callget$$this$calltoInt$$this$calland$arg0$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-Companion$class-UdpControlPacket", offset = 1509)
    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final int m6605Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1255Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1342State$Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$$this$call-not$else$cond$if$fun-decode$class-Companion$class-UdpControlPacket", Integer.valueOf(f1255Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classUdpControlPacket));
            f1342State$Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-get$$this$call-toShort$$this$call-toInt$arg-4$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", offset = 1836)
    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toShort$$this$call-toInt$arg-4$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final int m6606Int$arg0$callget$$this$calltoShort$$this$calltoInt$arg4$call$init$$valp$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1256Int$arg0$callget$$this$calltoShort$$this$calltoInt$arg4$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1343State$Int$arg0$callget$$this$calltoShort$$this$calltoInt$arg4$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-get$$this$call-toShort$$this$call-toInt$arg-4$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", Integer.valueOf(f1256Int$arg0$callget$$this$calltoShort$$this$calltoInt$arg4$call$init$$valp$fundecode$classCompanion$classUdpControlPacket));
            f1343State$Int$arg0$callget$$this$calltoShort$$this$calltoInt$arg4$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-get$$this$call-toShort$$this$call-toInt$arg-5$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", offset = 1866)
    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toShort$$this$call-toInt$arg-5$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final int m6607Int$arg0$callget$$this$calltoShort$$this$calltoInt$arg5$call$init$$valp$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1257Int$arg0$callget$$this$calltoShort$$this$calltoInt$arg5$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1344State$Int$arg0$callget$$this$calltoShort$$this$calltoInt$arg5$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-get$$this$call-toShort$$this$call-toInt$arg-5$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", Integer.valueOf(f1257Int$arg0$callget$$this$calltoShort$$this$calltoInt$arg5$call$init$$valp$fundecode$classCompanion$classUdpControlPacket));
            f1344State$Int$arg0$callget$$this$calltoShort$$this$calltoInt$arg5$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-get$arg-1$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", offset = 1786)
    /* JADX INFO: renamed from: Int$arg-0$call-get$arg-1$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final int m6608Int$arg0$callget$arg1$call$init$$valp$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1258Int$arg0$callget$arg1$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1345State$Int$arg0$callget$arg1$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-get$arg-1$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", Integer.valueOf(f1258Int$arg0$callget$arg1$call$init$$valp$fundecode$classCompanion$classUdpControlPacket));
            f1345State$Int$arg0$callget$arg1$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-get$arg-2$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", offset = 1797)
    /* JADX INFO: renamed from: Int$arg-0$call-get$arg-2$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final int m6609Int$arg0$callget$arg2$call$init$$valp$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1259Int$arg0$callget$arg2$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1346State$Int$arg0$callget$arg2$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-get$arg-2$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", Integer.valueOf(f1259Int$arg0$callget$arg2$call$init$$valp$fundecode$classCompanion$classUdpControlPacket));
            f1346State$Int$arg0$callget$arg2$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-get$arg-3$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", offset = 1808)
    /* JADX INFO: renamed from: Int$arg-0$call-get$arg-3$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final int m6610Int$arg0$callget$arg3$call$init$$valp$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1260Int$arg0$callget$arg3$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1347State$Int$arg0$callget$arg3$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-get$arg-3$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", Integer.valueOf(f1260Int$arg0$callget$arg3$call$init$$valp$fundecode$classCompanion$classUdpControlPacket));
            f1347State$Int$arg0$callget$arg3$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-get$arg-6$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", offset = 1896)
    /* JADX INFO: renamed from: Int$arg-0$call-get$arg-6$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final int m6611Int$arg0$callget$arg6$call$init$$valp$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1261Int$arg0$callget$arg6$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1348State$Int$arg0$callget$arg6$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-get$arg-6$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", Integer.valueOf(f1261Int$arg0$callget$arg6$call$init$$valp$fundecode$classCompanion$classUdpControlPacket));
            f1348State$Int$arg0$callget$arg6$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-get$arg-7$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", offset = 1908)
    /* JADX INFO: renamed from: Int$arg-0$call-get$arg-7$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final int m6612Int$arg0$callget$arg7$call$init$$valp$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1262Int$arg0$callget$arg7$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1349State$Int$arg0$callget$arg7$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-get$arg-7$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", Integer.valueOf(f1262Int$arg0$callget$arg7$call$init$$valp$fundecode$classCompanion$classUdpControlPacket));
            f1349State$Int$arg0$callget$arg7$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-put$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", offset = 921)
    /* JADX INFO: renamed from: Int$arg-0$call-put$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6613Int$arg0$callput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1263Int$arg0$callput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1350State$Int$arg0$callput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-put$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", Integer.valueOf(f1263Int$arg0$callput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket));
            f1350State$Int$arg0$callput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-put-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", offset = 941)
    /* JADX INFO: renamed from: Int$arg-0$call-put-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6614Int$arg0$callput1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1264Int$arg0$callput1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1351State$Int$arg0$callput1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-put-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", Integer.valueOf(f1264Int$arg0$callput1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket));
            f1351State$Int$arg0$callput1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-put-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", offset = 959)
    /* JADX INFO: renamed from: Int$arg-0$call-put-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6615Int$arg0$callput2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1265Int$arg0$callput2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1352State$Int$arg0$callput2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-put-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", Integer.valueOf(f1265Int$arg0$callput2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket));
            f1352State$Int$arg0$callput2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-put-3$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", offset = 992)
    /* JADX INFO: renamed from: Int$arg-0$call-put-3$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6616Int$arg0$callput3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1266Int$arg0$callput3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1353State$Int$arg0$callput3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-put-3$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", Integer.valueOf(f1266Int$arg0$callput3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket));
            f1353State$Int$arg0$callput3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-put-4$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", offset = 1023)
    /* JADX INFO: renamed from: Int$arg-0$call-put-4$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6617Int$arg0$callput4$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1267Int$arg0$callput4$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1354State$Int$arg0$callput4$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-put-4$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", Integer.valueOf(f1267Int$arg0$callput4$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket));
            f1354State$Int$arg0$callput4$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-put-5$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", offset = 1054)
    /* JADX INFO: renamed from: Int$arg-0$call-put-5$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6618Int$arg0$callput5$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1268Int$arg0$callput5$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1355State$Int$arg0$callput5$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-put-5$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", Integer.valueOf(f1268Int$arg0$callput5$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket));
            f1355State$Int$arg0$callput5$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-put-6$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", offset = 1073)
    /* JADX INFO: renamed from: Int$arg-0$call-put-6$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6619Int$arg0$callput6$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1269Int$arg0$callput6$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1356State$Int$arg0$callput6$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-put-6$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", Integer.valueOf(f1269Int$arg0$callput6$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket));
            f1356State$Int$arg0$callput6$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rangeTo$$this$call-contains$branch$cond$arg-0$call-require-1$fun-encode$class-UdpControlPacket", offset = 540)
    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$cond$arg-0$call-require-1$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6620Int$arg0$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire1$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1270Int$arg0$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire1$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1357State$Int$arg0$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire1$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rangeTo$$this$call-contains$branch$cond$arg-0$call-require-1$fun-encode$class-UdpControlPacket", Integer.valueOf(f1270Int$arg0$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire1$funencode$classUdpControlPacket));
            f1357State$Int$arg0$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire1$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rangeTo$$this$call-contains$branch$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket", offset = 2039)
    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final int m6621Int$arg0$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1271Int$arg0$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1358State$Int$arg0$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rangeTo$$this$call-contains$branch$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket", Integer.valueOf(f1271Int$arg0$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket));
            f1358State$Int$arg0$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket", offset = 2069)
    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final int m6622Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1272Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1359State$Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rangeTo$$this$call-contains$branch$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket", Integer.valueOf(f1272Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket));
            f1359State$Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rangeTo$$this$call-contains$cond$cond$arg-0$call-require-1$fun-encode$class-UdpControlPacket", offset = 513)
    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$cond$cond$arg-0$call-require-1$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6623Int$arg0$callrangeTo$$this$callcontains$cond$cond$arg0$callrequire1$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1273Int$arg0$callrangeTo$$this$callcontains$cond$cond$arg0$callrequire1$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1360State$Int$arg0$callrangeTo$$this$callcontains$cond$cond$arg0$callrequire1$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rangeTo$$this$call-contains$cond$cond$arg-0$call-require-1$fun-encode$class-UdpControlPacket", Integer.valueOf(f1273Int$arg0$callrangeTo$$this$callcontains$cond$cond$arg0$callrequire1$funencode$classUdpControlPacket));
            f1360State$Int$arg0$callrangeTo$$this$callcontains$cond$cond$arg0$callrequire1$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rangeTo$$this$call-contains$cond$cond$cond$arg-0$call-require$fun-encode$class-UdpControlPacket", offset = 387)
    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$cond$cond$cond$arg-0$call-require$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6624Int$arg0$callrangeTo$$this$callcontains$cond$cond$cond$arg0$callrequire$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1274Int$arg0$callrangeTo$$this$callcontains$cond$cond$cond$arg0$callrequire$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1361State$Int$arg0$callrangeTo$$this$callcontains$cond$cond$cond$arg0$callrequire$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rangeTo$$this$call-contains$cond$cond$cond$arg-0$call-require$fun-encode$class-UdpControlPacket", Integer.valueOf(f1274Int$arg0$callrangeTo$$this$callcontains$cond$cond$cond$arg0$callrequire$funencode$classUdpControlPacket));
            f1361State$Int$arg0$callrangeTo$$this$callcontains$cond$cond$cond$arg0$callrequire$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-set$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", offset = 684)
    /* JADX INFO: renamed from: Int$arg-0$call-set$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6625Int$arg0$callset$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1275Int$arg0$callset$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1362State$Int$arg0$callset$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-set$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", Integer.valueOf(f1275Int$arg0$callset$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket));
            f1362State$Int$arg0$callset$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-set-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", offset = 699)
    /* JADX INFO: renamed from: Int$arg-0$call-set-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6626Int$arg0$callset1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1276Int$arg0$callset1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1363State$Int$arg0$callset1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-set-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", Integer.valueOf(f1276Int$arg0$callset1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket));
            f1363State$Int$arg0$callset1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-set-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", offset = 714)
    /* JADX INFO: renamed from: Int$arg-0$call-set-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6627Int$arg0$callset2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1277Int$arg0$callset2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1364State$Int$arg0$callset2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-set-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", Integer.valueOf(f1277Int$arg0$callset2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket));
            f1364State$Int$arg0$callset2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-set-3$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", offset = 728)
    /* JADX INFO: renamed from: Int$arg-0$call-set-3$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6628Int$arg0$callset3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1278Int$arg0$callset3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1365State$Int$arg0$callset3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-set-3$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", Integer.valueOf(f1278Int$arg0$callset3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket));
            f1365State$Int$arg0$callset3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-UdpControlPacket, reason: not valid java name */
    public final int m6629Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1279Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1366State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-UdpControlPacket", Integer.valueOf(f1279Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classUdpControlPacket));
            f1366State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-UdpControlPacket, reason: not valid java name */
    public final int m6630Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1280Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1367State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-UdpControlPacket", Integer.valueOf(f1280Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classUdpControlPacket));
            f1367State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-2$fun-hashCode$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-2$fun-hashCode$class-UdpControlPacket, reason: not valid java name */
    public final int m6631Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1281Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1368State$Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-2$fun-hashCode$class-UdpControlPacket", Integer.valueOf(f1281Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classUdpControlPacket));
            f1368State$Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-3$fun-hashCode$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-3$fun-hashCode$class-UdpControlPacket, reason: not valid java name */
    public final int m6632Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1282Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1369State$Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-3$fun-hashCode$class-UdpControlPacket", Integer.valueOf(f1282Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classUdpControlPacket));
            f1369State$Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-4$fun-hashCode$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-4$fun-hashCode$class-UdpControlPacket, reason: not valid java name */
    public final int m6633Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1283Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1370State$Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-4$fun-hashCode$class-UdpControlPacket", Integer.valueOf(f1283Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classUdpControlPacket));
            f1370State$Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-5$fun-hashCode$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-5$fun-hashCode$class-UdpControlPacket, reason: not valid java name */
    public final int m6634Int$arg0$calltimes$$this$callplus$setresult5$funhashCode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1284Int$arg0$calltimes$$this$callplus$setresult5$funhashCode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1371State$Int$arg0$calltimes$$this$callplus$setresult5$funhashCode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-5$fun-hashCode$class-UdpControlPacket", Integer.valueOf(f1284Int$arg0$calltimes$$this$callplus$setresult5$funhashCode$classUdpControlPacket));
            f1371State$Int$arg0$calltimes$$this$callplus$setresult5$funhashCode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-6$fun-hashCode$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-6$fun-hashCode$class-UdpControlPacket, reason: not valid java name */
    public final int m6635Int$arg0$calltimes$$this$callplus$setresult6$funhashCode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1285Int$arg0$calltimes$$this$callplus$setresult6$funhashCode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1372State$Int$arg0$calltimes$$this$callplus$setresult6$funhashCode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-6$fun-hashCode$class-UdpControlPacket", Integer.valueOf(f1285Int$arg0$calltimes$$this$callplus$setresult6$funhashCode$classUdpControlPacket));
            f1372State$Int$arg0$calltimes$$this$callplus$setresult6$funhashCode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-get$$this$call-toShort$$this$call-toInt$arg-4$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", offset = 1840)
    /* JADX INFO: renamed from: Int$arg-1$call-get$$this$call-toShort$$this$call-toInt$arg-4$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final int m6636Int$arg1$callget$$this$calltoShort$$this$calltoInt$arg4$call$init$$valp$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1286Int$arg1$callget$$this$calltoShort$$this$calltoInt$arg4$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1373State$Int$arg1$callget$$this$calltoShort$$this$calltoInt$arg4$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-get$$this$call-toShort$$this$call-toInt$arg-4$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", Integer.valueOf(f1286Int$arg1$callget$$this$calltoShort$$this$calltoInt$arg4$call$init$$valp$fundecode$classCompanion$classUdpControlPacket));
            f1373State$Int$arg1$callget$$this$calltoShort$$this$calltoInt$arg4$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-get$$this$call-toShort$$this$call-toInt$arg-5$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", offset = 1870)
    /* JADX INFO: renamed from: Int$arg-1$call-get$$this$call-toShort$$this$call-toInt$arg-5$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final int m6637Int$arg1$callget$$this$calltoShort$$this$calltoInt$arg5$call$init$$valp$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1287Int$arg1$callget$$this$calltoShort$$this$calltoInt$arg5$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1374State$Int$arg1$callget$$this$calltoShort$$this$calltoInt$arg5$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-get$$this$call-toShort$$this$call-toInt$arg-5$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", Integer.valueOf(f1287Int$arg1$callget$$this$calltoShort$$this$calltoInt$arg5$call$init$$valp$fundecode$classCompanion$classUdpControlPacket));
            f1374State$Int$arg1$callget$$this$calltoShort$$this$calltoInt$arg5$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-get$arg-1$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", offset = 1789)
    /* JADX INFO: renamed from: Int$arg-1$call-get$arg-1$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final int m6638Int$arg1$callget$arg1$call$init$$valp$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1288Int$arg1$callget$arg1$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1375State$Int$arg1$callget$arg1$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-get$arg-1$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", Integer.valueOf(f1288Int$arg1$callget$arg1$call$init$$valp$fundecode$classCompanion$classUdpControlPacket));
            f1375State$Int$arg1$callget$arg1$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-get$arg-2$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", offset = 1800)
    /* JADX INFO: renamed from: Int$arg-1$call-get$arg-2$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final int m6639Int$arg1$callget$arg2$call$init$$valp$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1289Int$arg1$callget$arg2$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1376State$Int$arg1$callget$arg2$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-get$arg-2$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", Integer.valueOf(f1289Int$arg1$callget$arg2$call$init$$valp$fundecode$classCompanion$classUdpControlPacket));
            f1376State$Int$arg1$callget$arg2$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-get$arg-3$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", offset = 1812)
    /* JADX INFO: renamed from: Int$arg-1$call-get$arg-3$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final int m6640Int$arg1$callget$arg3$call$init$$valp$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1290Int$arg1$callget$arg3$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1377State$Int$arg1$callget$arg3$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-get$arg-3$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", Integer.valueOf(f1290Int$arg1$callget$arg3$call$init$$valp$fundecode$classCompanion$classUdpControlPacket));
            f1377State$Int$arg1$callget$arg3$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-get$arg-6$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", offset = 1900)
    /* JADX INFO: renamed from: Int$arg-1$call-get$arg-6$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final int m6641Int$arg1$callget$arg6$call$init$$valp$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1291Int$arg1$callget$arg6$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1378State$Int$arg1$callget$arg6$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-get$arg-6$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", Integer.valueOf(f1291Int$arg1$callget$arg6$call$init$$valp$fundecode$classCompanion$classUdpControlPacket));
            f1378State$Int$arg1$callget$arg6$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-get$arg-7$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", offset = 1912)
    /* JADX INFO: renamed from: Int$arg-1$call-get$arg-7$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final int m6642Int$arg1$callget$arg7$call$init$$valp$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1292Int$arg1$callget$arg7$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1379State$Int$arg1$callget$arg7$call$init$$valp$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-get$arg-7$call-$init$$val-p$fun-decode$class-Companion$class-UdpControlPacket", Integer.valueOf(f1292Int$arg1$callget$arg7$call$init$$valp$fundecode$classCompanion$classUdpControlPacket));
            f1379State$Int$arg1$callget$arg7$call$init$$valp$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-put$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", offset = 924)
    /* JADX INFO: renamed from: Int$arg-1$call-put$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6643Int$arg1$callput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1293Int$arg1$callput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1380State$Int$arg1$callput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-put$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", Integer.valueOf(f1293Int$arg1$callput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket));
            f1380State$Int$arg1$callput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-put-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", offset = 944)
    /* JADX INFO: renamed from: Int$arg-1$call-put-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6644Int$arg1$callput1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1294Int$arg1$callput1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1381State$Int$arg1$callput1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-put-1$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", Integer.valueOf(f1294Int$arg1$callput1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket));
            f1381State$Int$arg1$callput1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-put-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", offset = 963)
    /* JADX INFO: renamed from: Int$arg-1$call-put-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6645Int$arg1$callput2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1295Int$arg1$callput2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1382State$Int$arg1$callput2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-put-2$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", Integer.valueOf(f1295Int$arg1$callput2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket));
            f1382State$Int$arg1$callput2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-put-3$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", offset = 996)
    /* JADX INFO: renamed from: Int$arg-1$call-put-3$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6646Int$arg1$callput3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1296Int$arg1$callput3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1383State$Int$arg1$callput3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-put-3$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", Integer.valueOf(f1296Int$arg1$callput3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket));
            f1383State$Int$arg1$callput3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-put-4$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", offset = 1027)
    /* JADX INFO: renamed from: Int$arg-1$call-put-4$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6647Int$arg1$callput4$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1297Int$arg1$callput4$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1384State$Int$arg1$callput4$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-put-4$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", Integer.valueOf(f1297Int$arg1$callput4$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket));
            f1384State$Int$arg1$callput4$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-put-5$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", offset = 1058)
    /* JADX INFO: renamed from: Int$arg-1$call-put-5$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6648Int$arg1$callput5$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1298Int$arg1$callput5$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1385State$Int$arg1$callput5$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-put-5$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", Integer.valueOf(f1298Int$arg1$callput5$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket));
            f1385State$Int$arg1$callput5$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-put-6$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", offset = 1077)
    /* JADX INFO: renamed from: Int$arg-1$call-put-6$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final int m6649Int$arg1$callput6$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1299Int$arg1$callput6$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1386State$Int$arg1$callput6$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-put-6$fun-$anonymous$$arg-0$call-also$fun-encode$class-UdpControlPacket", Integer.valueOf(f1299Int$arg1$callput6$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket));
            f1386State$Int$arg1$callput6$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-UdpControlPacket", offset = -1)
    /* JADX INFO: renamed from: Int$class-UdpControlPacket, reason: not valid java name */
    public final int m6650Int$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1300Int$classUdpControlPacket;
        }
        State<Integer> stateLiveLiteral = f1387State$Int$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-UdpControlPacket", Integer.valueOf(f1300Int$classUdpControlPacket));
            f1387State$Int$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-and$$this$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-get$fun-decode$class-Companion$class-UdpControlPacket", offset = 1687)
    /* JADX INFO: renamed from: Long$arg-0$call-and$$this$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-get$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final long m6651Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funget$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1301Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funget$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Long> stateLiveLiteral = f1388State$Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funget$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-and$$this$call-shl$arg-0$call-or$fun-$anonymous$$arg-1$call-fold$fun-get$fun-decode$class-Companion$class-UdpControlPacket", Long.valueOf(f1301Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funget$fundecode$classCompanion$classUdpControlPacket));
            f1388State$Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funget$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-fold$fun-get$fun-decode$class-Companion$class-UdpControlPacket", offset = 1611)
    /* JADX INFO: renamed from: Long$arg-0$call-fold$fun-get$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final long m6652Long$arg0$callfold$funget$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1302Long$arg0$callfold$funget$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Long> stateLiveLiteral = f1389State$Long$arg0$callfold$funget$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-fold$fun-get$fun-decode$class-Companion$class-UdpControlPacket", Long.valueOf(f1302Long$arg0$callfold$funget$fundecode$classCompanion$classUdpControlPacket));
            f1389State$Long$arg0$callfold$funget$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-rangeTo$$this$call-contains$arg-0$call-require-2$fun-encode$class-UdpControlPacket", offset = 606)
    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$arg-0$call-require-2$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final long m6653Long$arg0$callrangeTo$$this$callcontains$arg0$callrequire2$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1303Long$arg0$callrangeTo$$this$callcontains$arg0$callrequire2$funencode$classUdpControlPacket;
        }
        State<Long> stateLiveLiteral = f1390State$Long$arg0$callrangeTo$$this$callcontains$arg0$callrequire2$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-rangeTo$$this$call-contains$arg-0$call-require-2$fun-encode$class-UdpControlPacket", Long.valueOf(f1303Long$arg0$callrangeTo$$this$callcontains$arg0$callrequire2$funencode$classUdpControlPacket));
            f1390State$Long$arg0$callrangeTo$$this$callcontains$arg0$callrequire2$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-encode$class-UdpControlPacket", offset = 465)
    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final long m6654Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1304Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funencode$classUdpControlPacket;
        }
        State<Long> stateLiveLiteral = f1391State$Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-encode$class-UdpControlPacket", Long.valueOf(f1304Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funencode$classUdpControlPacket));
            f1391State$Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require-1$fun-encode$class-UdpControlPacket", offset = 561)
    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require-1$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final long m6655Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1305Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classUdpControlPacket;
        }
        State<Long> stateLiveLiteral = f1392State$Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require-1$fun-encode$class-UdpControlPacket", Long.valueOf(f1305Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classUdpControlPacket));
            f1392State$Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-rangeTo$$this$call-contains$branch$cond$arg-0$call-require$fun-encode$class-UdpControlPacket", offset = 435)
    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$branch$cond$arg-0$call-require$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final long m6656Long$arg0$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1306Long$arg0$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire$funencode$classUdpControlPacket;
        }
        State<Long> stateLiveLiteral = f1393State$Long$arg0$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-rangeTo$$this$call-contains$branch$cond$arg-0$call-require$fun-encode$class-UdpControlPacket", Long.valueOf(f1306Long$arg0$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire$funencode$classUdpControlPacket));
            f1393State$Long$arg0$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-rangeTo$$this$call-contains$branch$cond$cond$arg-0$call-require$fun-encode$class-UdpControlPacket", offset = 408)
    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$branch$cond$cond$arg-0$call-require$fun-encode$class-UdpControlPacket, reason: not valid java name */
    public final long m6657Long$arg0$callrangeTo$$this$callcontains$branch$cond$cond$arg0$callrequire$funencode$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1307Long$arg0$callrangeTo$$this$callcontains$branch$cond$cond$arg0$callrequire$funencode$classUdpControlPacket;
        }
        State<Long> stateLiveLiteral = f1394State$Long$arg0$callrangeTo$$this$callcontains$branch$cond$cond$arg0$callrequire$funencode$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-rangeTo$$this$call-contains$branch$cond$cond$arg-0$call-require$fun-encode$class-UdpControlPacket", Long.valueOf(f1307Long$arg0$callrangeTo$$this$callcontains$branch$cond$cond$arg0$callrequire$funencode$classUdpControlPacket));
            f1394State$Long$arg0$callrangeTo$$this$callcontains$branch$cond$cond$arg0$callrequire$funencode$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-rangeTo$$this$call-contains$branch$cond$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket", offset = 1982)
    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$branch$cond$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final long m6658Long$arg0$callrangeTo$$this$callcontains$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1308Long$arg0$callrangeTo$$this$callcontains$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Long> stateLiveLiteral = f1395State$Long$arg0$callrangeTo$$this$callcontains$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-rangeTo$$this$call-contains$branch$cond$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket", Long.valueOf(f1308Long$arg0$callrangeTo$$this$callcontains$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket));
            f1395State$Long$arg0$callrangeTo$$this$callcontains$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-1$call-EQEQ$$this$call-not$cond$cond$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket", offset = 1960)
    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$$this$call-not$cond$cond$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket, reason: not valid java name */
    public final long m6659Long$arg1$callEQEQ$$this$callnot$cond$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1309Long$arg1$callEQEQ$$this$callnot$cond$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket;
        }
        State<Long> stateLiveLiteral = f1396State$Long$arg1$callEQEQ$$this$callnot$cond$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-1$call-EQEQ$$this$call-not$cond$cond$cond$fun-$anonymous$$arg-0$call-takeIf$fun-decode$class-Companion$class-UdpControlPacket", Long.valueOf(f1309Long$arg1$callEQEQ$$this$callnot$cond$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket));
            f1396State$Long$arg1$callEQEQ$$this$callnot$cond$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$param-basis$class-UdpControlPacket", offset = 323)
    /* JADX INFO: renamed from: Long$param-basis$class-UdpControlPacket, reason: not valid java name */
    public final long m6660Long$parambasis$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1310Long$parambasis$classUdpControlPacket;
        }
        State<Long> stateLiveLiteral = f1397State$Long$parambasis$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$param-basis$class-UdpControlPacket", Long.valueOf(f1310Long$parambasis$classUdpControlPacket));
            f1397State$Long$parambasis$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "String$0$str$fun-toString$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$0$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    public final String m6661String$0$str$funtoString$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1415String$0$str$funtoString$classUdpControlPacket;
        }
        State<String> stateLiveLiteral = f1398State$String$0$str$funtoString$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$fun-toString$class-UdpControlPacket", f1415String$0$str$funtoString$classUdpControlPacket);
            f1398State$String$0$str$funtoString$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$1$str$fun-toString$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$1$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    public final String m6662String$1$str$funtoString$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1416String$1$str$funtoString$classUdpControlPacket;
        }
        State<String> stateLiveLiteral = f1399State$String$1$str$funtoString$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$1$str$fun-toString$class-UdpControlPacket", f1416String$1$str$funtoString$classUdpControlPacket);
            f1399State$String$1$str$funtoString$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$10$str$fun-toString$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$10$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    public final String m6663String$10$str$funtoString$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1417String$10$str$funtoString$classUdpControlPacket;
        }
        State<String> stateLiveLiteral = f1400State$String$10$str$funtoString$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$10$str$fun-toString$class-UdpControlPacket", f1417String$10$str$funtoString$classUdpControlPacket);
            f1400State$String$10$str$funtoString$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$12$str$fun-toString$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$12$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    public final String m6664String$12$str$funtoString$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1418String$12$str$funtoString$classUdpControlPacket;
        }
        State<String> stateLiveLiteral = f1401State$String$12$str$funtoString$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$12$str$fun-toString$class-UdpControlPacket", f1418String$12$str$funtoString$classUdpControlPacket);
            f1401State$String$12$str$funtoString$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$13$str$fun-toString$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$13$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    public final String m6665String$13$str$funtoString$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1419String$13$str$funtoString$classUdpControlPacket;
        }
        State<String> stateLiveLiteral = f1402State$String$13$str$funtoString$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$13$str$fun-toString$class-UdpControlPacket", f1419String$13$str$funtoString$classUdpControlPacket);
            f1402State$String$13$str$funtoString$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$15$str$fun-toString$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$15$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    public final String m6666String$15$str$funtoString$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1420String$15$str$funtoString$classUdpControlPacket;
        }
        State<String> stateLiveLiteral = f1403State$String$15$str$funtoString$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$15$str$fun-toString$class-UdpControlPacket", f1420String$15$str$funtoString$classUdpControlPacket);
            f1403State$String$15$str$funtoString$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$16$str$fun-toString$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$16$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    public final String m6667String$16$str$funtoString$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1421String$16$str$funtoString$classUdpControlPacket;
        }
        State<String> stateLiveLiteral = f1404State$String$16$str$funtoString$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$16$str$fun-toString$class-UdpControlPacket", f1421String$16$str$funtoString$classUdpControlPacket);
            f1404State$String$16$str$funtoString$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$18$str$fun-toString$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$18$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    public final String m6668String$18$str$funtoString$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1422String$18$str$funtoString$classUdpControlPacket;
        }
        State<String> stateLiveLiteral = f1405State$String$18$str$funtoString$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$18$str$fun-toString$class-UdpControlPacket", f1422String$18$str$funtoString$classUdpControlPacket);
            f1405State$String$18$str$funtoString$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$19$str$fun-toString$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$19$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    public final String m6669String$19$str$funtoString$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1423String$19$str$funtoString$classUdpControlPacket;
        }
        State<String> stateLiveLiteral = f1406State$String$19$str$funtoString$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$19$str$fun-toString$class-UdpControlPacket", f1423String$19$str$funtoString$classUdpControlPacket);
            f1406State$String$19$str$funtoString$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$21$str$fun-toString$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$21$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    public final String m6670String$21$str$funtoString$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1424String$21$str$funtoString$classUdpControlPacket;
        }
        State<String> stateLiveLiteral = f1407State$String$21$str$funtoString$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$21$str$fun-toString$class-UdpControlPacket", f1424String$21$str$funtoString$classUdpControlPacket);
            f1407State$String$21$str$funtoString$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$22$str$fun-toString$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$22$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    public final String m6671String$22$str$funtoString$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1425String$22$str$funtoString$classUdpControlPacket;
        }
        State<String> stateLiveLiteral = f1408State$String$22$str$funtoString$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$22$str$fun-toString$class-UdpControlPacket", f1425String$22$str$funtoString$classUdpControlPacket);
            f1408State$String$22$str$funtoString$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$24$str$fun-toString$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$24$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    public final String m6672String$24$str$funtoString$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1426String$24$str$funtoString$classUdpControlPacket;
        }
        State<String> stateLiveLiteral = f1409State$String$24$str$funtoString$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$24$str$fun-toString$class-UdpControlPacket", f1426String$24$str$funtoString$classUdpControlPacket);
            f1409State$String$24$str$funtoString$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$3$str$fun-toString$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$3$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    public final String m6673String$3$str$funtoString$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1427String$3$str$funtoString$classUdpControlPacket;
        }
        State<String> stateLiveLiteral = f1410State$String$3$str$funtoString$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$3$str$fun-toString$class-UdpControlPacket", f1427String$3$str$funtoString$classUdpControlPacket);
            f1410State$String$3$str$funtoString$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$4$str$fun-toString$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$4$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    public final String m6674String$4$str$funtoString$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1428String$4$str$funtoString$classUdpControlPacket;
        }
        State<String> stateLiveLiteral = f1411State$String$4$str$funtoString$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$4$str$fun-toString$class-UdpControlPacket", f1428String$4$str$funtoString$classUdpControlPacket);
            f1411State$String$4$str$funtoString$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$6$str$fun-toString$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$6$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    public final String m6675String$6$str$funtoString$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1429String$6$str$funtoString$classUdpControlPacket;
        }
        State<String> stateLiveLiteral = f1412State$String$6$str$funtoString$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$6$str$fun-toString$class-UdpControlPacket", f1429String$6$str$funtoString$classUdpControlPacket);
            f1412State$String$6$str$funtoString$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$7$str$fun-toString$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$7$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    public final String m6676String$7$str$funtoString$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1430String$7$str$funtoString$classUdpControlPacket;
        }
        State<String> stateLiveLiteral = f1413State$String$7$str$funtoString$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$7$str$fun-toString$class-UdpControlPacket", f1430String$7$str$funtoString$classUdpControlPacket);
            f1413State$String$7$str$funtoString$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$9$str$fun-toString$class-UdpControlPacket", offset = -2)
    /* JADX INFO: renamed from: String$9$str$fun-toString$class-UdpControlPacket, reason: not valid java name */
    public final String m6677String$9$str$funtoString$classUdpControlPacket() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1431String$9$str$funtoString$classUdpControlPacket;
        }
        State<String> stateLiveLiteral = f1414State$String$9$str$funtoString$classUdpControlPacket;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$9$str$fun-toString$class-UdpControlPacket", f1431String$9$str$funtoString$classUdpControlPacket);
            f1414State$String$9$str$funtoString$classUdpControlPacket = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
