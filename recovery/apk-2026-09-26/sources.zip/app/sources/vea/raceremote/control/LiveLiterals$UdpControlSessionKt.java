package vea.raceremote.control;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: UdpControlSession.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/control/UdpControlSession.kt")
public final class LiveLiterals$UdpControlSessionKt {

    /* JADX INFO: renamed from: Boolean$branch$if$branch$if-1$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static boolean f1433Boolean$branch$if$branch$if1$funreceive$classUdpControlSession;

    /* JADX INFO: renamed from: Boolean$branch$if$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static boolean f1434Boolean$branch$if$funreceive$classUdpControlSession;

    /* JADX INFO: renamed from: Boolean$branch$if-2$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static boolean f1436Boolean$branch$if2$funreceive$classUdpControlSession;

    /* JADX INFO: renamed from: Boolean$branch$if-3$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static boolean f1437Boolean$branch$if3$funreceive$classUdpControlSession;

    /* JADX INFO: renamed from: Boolean$branch$if-4$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static boolean f1438Boolean$branch$if4$funreceive$classUdpControlSession;

    /* JADX INFO: renamed from: Boolean$branch$when$val-sent$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static boolean f1441Boolean$branch$when$valsent$funreceive$classUdpControlSession;

    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-Sent$class-UdpControlSession, reason: not valid java name */
    private static boolean f1442Boolean$branch$when1$funequals$classSent$classUdpControlSession;

    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static boolean f1443Boolean$branch$when1$funequals$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: Boolean$branch$when-10$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static boolean f1444Boolean$branch$when10$funequals$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-Sent$class-UdpControlSession, reason: not valid java name */
    private static boolean f1445Boolean$branch$when2$funequals$classSent$classUdpControlSession;

    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static boolean f1446Boolean$branch$when2$funequals$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-Sent$class-UdpControlSession, reason: not valid java name */
    private static boolean f1447Boolean$branch$when3$funequals$classSent$classUdpControlSession;

    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static boolean f1448Boolean$branch$when3$funequals$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: Boolean$branch$when-4$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static boolean f1449Boolean$branch$when4$funequals$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: Boolean$branch$when-5$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static boolean f1450Boolean$branch$when5$funequals$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: Boolean$branch$when-6$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static boolean f1451Boolean$branch$when6$funequals$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: Boolean$branch$when-7$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static boolean f1452Boolean$branch$when7$funequals$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: Boolean$branch$when-8$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static boolean f1453Boolean$branch$when8$funequals$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: Boolean$branch$when-9$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static boolean f1454Boolean$branch$when9$funequals$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: Int$arg-0$call-$set-acknowledgedSteering$$fun-stop$class-UdpControlSession, reason: not valid java name */
    private static int f1465Int$arg0$call$setacknowledgedSteering$$funstop$classUdpControlSession;

    /* JADX INFO: renamed from: Int$arg-0$call-$set-acknowledgedThrottle$$fun-stop$class-UdpControlSession, reason: not valid java name */
    private static int f1466Int$arg0$call$setacknowledgedThrottle$$funstop$classUdpControlSession;

    /* JADX INFO: renamed from: Int$arg-0$call-$set-steering$$fun-stop$class-UdpControlSession, reason: not valid java name */
    private static int f1467Int$arg0$call$setsteering$$funstop$classUdpControlSession;

    /* JADX INFO: renamed from: Int$arg-0$call-$set-throttle$$fun-stop$class-UdpControlSession, reason: not valid java name */
    private static int f1468Int$arg0$call$setthrottle$$funstop$classUdpControlSession;

    /* JADX INFO: renamed from: Int$arg-1$call-EQEQ$$this$call-not$else$cond$if$branch$if-1$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static int f1485Int$arg1$callEQEQ$$this$callnot$else$cond$if$branch$if1$funreceive$classUdpControlSession;

    /* JADX INFO: renamed from: Int$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static int f1488Int$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: Int$param-s$fun-packet$class-UdpControlSession, reason: not valid java name */
    private static int f1491Int$params$funpacket$classUdpControlSession;

    /* JADX INFO: renamed from: Int$param-t$fun-packet$class-UdpControlSession, reason: not valid java name */
    private static int f1492Int$paramt$funpacket$classUdpControlSession;

    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$$this$call-not$cond$if-1$fun-stop$class-UdpControlSession, reason: not valid java name */
    private static long f1499Long$arg1$callEQEQ$$this$callnot$cond$if1$funstop$classUdpControlSession;

    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$$this$call-not$else$cond$if$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static long f1500Long$arg1$callEQEQ$$this$callnot$else$cond$if$funreceive$classUdpControlSession;

    /* JADX INFO: renamed from: Long$arg-1$call-packet$branch$when$val-p$fun-next$class-UdpControlSession, reason: not valid java name */
    private static long f1502Long$arg1$callpacket$branch$when$valp$funnext$classUdpControlSession;

    /* JADX INFO: renamed from: Long$param-basis$fun-packet$class-UdpControlSession, reason: not valid java name */
    private static long f1503Long$parambasis$funpacket$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-EQEQ$cond$if-1$fun-next$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1504State$Boolean$arg1$callEQEQ$cond$if1$funnext$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$branch$if$branch$if-1$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1505State$Boolean$branch$if$branch$if1$funreceive$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$branch$if$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1506State$Boolean$branch$if$funreceive$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$branch$if-1$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1507State$Boolean$branch$if1$funreceive$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$branch$if-2$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1508State$Boolean$branch$if2$funreceive$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$branch$if-3$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1509State$Boolean$branch$if3$funreceive$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$branch$if-4$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1510State$Boolean$branch$if4$funreceive$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$branch$when$fun-equals$class-Sent$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1511State$Boolean$branch$when$funequals$classSent$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$branch$when$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1512State$Boolean$branch$when$funequals$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$branch$when$val-sent$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1513State$Boolean$branch$when$valsent$funreceive$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$branch$when-1$fun-equals$class-Sent$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1514State$Boolean$branch$when1$funequals$classSent$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$branch$when-1$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1515State$Boolean$branch$when1$funequals$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$branch$when-10$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1516State$Boolean$branch$when10$funequals$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$branch$when-2$fun-equals$class-Sent$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1517State$Boolean$branch$when2$funequals$classSent$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$branch$when-2$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1518State$Boolean$branch$when2$funequals$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$branch$when-3$fun-equals$class-Sent$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1519State$Boolean$branch$when3$funequals$classSent$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$branch$when-3$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1520State$Boolean$branch$when3$funequals$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$branch$when-4$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1521State$Boolean$branch$when4$funequals$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$branch$when-5$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1522State$Boolean$branch$when5$funequals$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$branch$when-6$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1523State$Boolean$branch$when6$funequals$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$branch$when-7$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1524State$Boolean$branch$when7$funequals$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$branch$when-8$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1525State$Boolean$branch$when8$funequals$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$branch$when-9$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1526State$Boolean$branch$when9$funequals$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$fun-equals$class-Sent$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1527State$Boolean$funequals$classSent$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1528State$Boolean$funequals$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$Boolean$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static State<Boolean> f1529State$Boolean$funreceive$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1530State$Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-input$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1531State$Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funinput$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$cond$arg-0$call-require$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1532State$Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$cond$arg-0$call-require$fun-input$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1533State$Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$funinput$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$branch$when$fun-expire$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1534State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch$when$funexpire$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$branch-1$when$fun-expire$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1535State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch1$when$funexpire$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$branch-2$when$fun-expire$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1536State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch2$when$funexpire$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$arg-0$call-$set-acknowledgedSteering$$fun-stop$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1537State$Int$arg0$call$setacknowledgedSteering$$funstop$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$arg-0$call-$set-acknowledgedThrottle$$fun-stop$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1538State$Int$arg0$call$setacknowledgedThrottle$$funstop$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$arg-0$call-$set-steering$$fun-stop$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1539State$Int$arg0$call$setsteering$$funstop$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$arg-0$call-$set-throttle$$fun-stop$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1540State$Int$arg0$call$setthrottle$$funstop$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$arg-0$call-plus$$this$call-and$arg-0$call-$set-sequence$$branch-2$when$val-p$fun-next$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1541State$Int$arg0$callplus$$this$calland$arg0$call$setsequence$$branch2$when$valp$funnext$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-input$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1542State$Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funinput$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rangeTo$$this$call-contains$cond$arg-0$call-require$fun-input$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1543State$Int$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$funinput$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rem$$this$call-toInt$arg-0$call-get$val-tmp0_elvis_lhs$val-sent$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1544State$Int$arg0$callrem$$this$calltoInt$arg0$callget$valtmp0_elvis_lhs$valsent$funreceive$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rem$$this$call-toInt$arg-0$call-set$fun-$anonymous$$arg-0$call-also$branch-2$when$val-p$fun-next$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1545State$Int$arg0$callrem$$this$calltoInt$arg0$callset$fun$anonymous$$arg0$callalso$branch2$when$valp$funnext$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rem$$this$call-toInt$arg-0$call-set$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1546State$Int$arg0$callrem$$this$calltoInt$arg0$callset$funreceive$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$arg-0$call-set$branch$if$fun-$anonymous$$arg-0$call-also$branch-1$when$val-p$fun-next$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1547State$Int$arg0$callset$branch$if$fun$anonymous$$arg0$callalso$branch1$when$valp$funnext$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Sent$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1548State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classSent$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1549State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1550State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-2$fun-hashCode$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1551State$Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-3$fun-hashCode$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1552State$Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-4$fun-hashCode$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1553State$Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-5$fun-hashCode$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1554State$Int$arg0$calltimes$$this$callplus$setresult5$funhashCode$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-6$fun-hashCode$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1555State$Int$arg0$calltimes$$this$callplus$setresult6$funhashCode$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-7$fun-hashCode$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1556State$Int$arg0$calltimes$$this$callplus$setresult7$funhashCode$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$arg-1$call-EQEQ$$this$call-not$else$cond$if$branch$if-1$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1557State$Int$arg1$callEQEQ$$this$callnot$else$cond$if$branch$if1$funreceive$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$branch$when$val-interval$fun-next$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1558State$Int$branch$when$valinterval$funnext$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$branch-1$when$val-interval$fun-next$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1559State$Int$branch1$when$valinterval$funnext$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1560State$Int$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1561State$Int$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$else$when$val-interval$fun-next$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1562State$Int$else$when$valinterval$funnext$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$param-s$fun-packet$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1563State$Int$params$funpacket$classUdpControlSession;

    /* JADX INFO: renamed from: State$Int$param-t$fun-packet$class-UdpControlSession, reason: not valid java name */
    private static State<Integer> f1564State$Int$paramt$funpacket$classUdpControlSession;

    /* JADX INFO: renamed from: State$Long$arg-0$call-$set-sequence$$branch$if-5$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static State<Long> f1565State$Long$arg0$call$setsequence$$branch$if5$funreceive$classUdpControlSession;

    /* JADX INFO: renamed from: State$Long$arg-0$call-and$arg-0$call-$set-sequence$$branch-2$when$val-p$fun-next$class-UdpControlSession, reason: not valid java name */
    private static State<Long> f1566State$Long$arg0$calland$arg0$call$setsequence$$branch2$when$valp$funnext$classUdpControlSession;

    /* JADX INFO: renamed from: State$Long$arg-0$call-and$val-distance$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static State<Long> f1567State$Long$arg0$calland$valdistance$funreceive$classUdpControlSession;

    /* JADX INFO: renamed from: State$Long$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require$class-UdpControlSession, reason: not valid java name */
    private static State<Long> f1568State$Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$classUdpControlSession;

    /* JADX INFO: renamed from: State$Long$arg-0$call-rangeTo$$this$call-contains$cond$arg-0$call-require$class-UdpControlSession, reason: not valid java name */
    private static State<Long> f1569State$Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$classUdpControlSession;

    /* JADX INFO: renamed from: State$Long$arg-1$call-EQEQ$$this$call-not$branch$cond$if-4$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static State<Long> f1570State$Long$arg1$callEQEQ$$this$callnot$branch$cond$if4$funreceive$classUdpControlSession;

    /* JADX INFO: renamed from: State$Long$arg-1$call-EQEQ$$this$call-not$cond$if-1$fun-stop$class-UdpControlSession, reason: not valid java name */
    private static State<Long> f1571State$Long$arg1$callEQEQ$$this$callnot$cond$if1$funstop$classUdpControlSession;

    /* JADX INFO: renamed from: State$Long$arg-1$call-EQEQ$$this$call-not$else$cond$if$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static State<Long> f1572State$Long$arg1$callEQEQ$$this$callnot$else$cond$if$funreceive$classUdpControlSession;

    /* JADX INFO: renamed from: State$Long$arg-1$call-packet$$$this$call-also$branch-1$when$val-p$fun-next$class-UdpControlSession, reason: not valid java name */
    private static State<Long> f1573State$Long$arg1$callpacket$$$this$callalso$branch1$when$valp$funnext$classUdpControlSession;

    /* JADX INFO: renamed from: State$Long$arg-1$call-packet$branch$when$val-p$fun-next$class-UdpControlSession, reason: not valid java name */
    private static State<Long> f1574State$Long$arg1$callpacket$branch$when$valp$funnext$classUdpControlSession;

    /* JADX INFO: renamed from: State$Long$param-basis$fun-packet$class-UdpControlSession, reason: not valid java name */
    private static State<Long> f1575State$Long$parambasis$funpacket$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$0$str$fun-toString$class-Sent$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1576State$String$0$str$funtoString$classSent$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$0$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1577State$String$0$str$funtoString$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$1$str$fun-toString$class-Sent$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1578State$String$1$str$funtoString$classSent$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$1$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1579State$String$1$str$funtoString$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$10$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1580State$String$10$str$funtoString$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$12$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1581State$String$12$str$funtoString$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$13$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1582State$String$13$str$funtoString$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$15$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1583State$String$15$str$funtoString$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$16$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1584State$String$16$str$funtoString$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$18$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1585State$String$18$str$funtoString$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$19$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1586State$String$19$str$funtoString$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$21$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1587State$String$21$str$funtoString$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$22$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1588State$String$22$str$funtoString$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$24$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1589State$String$24$str$funtoString$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$25$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1590State$String$25$str$funtoString$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$27$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1591State$String$27$str$funtoString$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$3$str$fun-toString$class-Sent$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1592State$String$3$str$funtoString$classSent$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$3$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1593State$String$3$str$funtoString$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$4$str$fun-toString$class-Sent$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1594State$String$4$str$funtoString$classSent$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$4$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1595State$String$4$str$funtoString$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$6$str$fun-toString$class-Sent$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1596State$String$6$str$funtoString$classSent$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$6$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1597State$String$6$str$funtoString$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$7$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1598State$String$7$str$funtoString$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$9$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1599State$String$9$str$funtoString$classSnapshot$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$arg-0$call-$set-reason$$branch$if-5$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1600State$String$arg0$call$setreason$$branch$if5$funreceive$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$arg-0$call-stop$branch$if$branch$when$fun-expire$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1601State$String$arg0$callstop$branch$if$branch$when$funexpire$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$arg-0$call-stop$branch$if$branch-1$when$fun-expire$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1602State$String$arg0$callstop$branch$if$branch1$when$funexpire$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$arg-0$call-stop$branch$if$branch-2$when$fun-expire$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1603State$String$arg0$callstop$branch$if$branch2$when$funexpire$classUdpControlSession;

    /* JADX INFO: renamed from: State$String$param-reason$fun-stop$class-UdpControlSession, reason: not valid java name */
    private static State<String> f1604State$String$paramreason$funstop$classUdpControlSession;
    public static final LiveLiterals$UdpControlSessionKt INSTANCE = new LiveLiterals$UdpControlSessionKt();

    /* JADX INFO: renamed from: String$0$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static String f1606String$0$str$funtoString$classSnapshot$classUdpControlSession = "Snapshot(";

    /* JADX INFO: renamed from: String$1$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static String f1608String$1$str$funtoString$classSnapshot$classUdpControlSession = "phase=";

    /* JADX INFO: renamed from: String$3$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static String f1622String$3$str$funtoString$classSnapshot$classUdpControlSession = ", ";

    /* JADX INFO: renamed from: String$4$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static String f1624String$4$str$funtoString$classSnapshot$classUdpControlSession = "reason=";

    /* JADX INFO: renamed from: String$6$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static String f1626String$6$str$funtoString$classSnapshot$classUdpControlSession = ", ";

    /* JADX INFO: renamed from: String$7$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static String f1627String$7$str$funtoString$classSnapshot$classUdpControlSession = "acknowledgements=";

    /* JADX INFO: renamed from: String$9$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static String f1628String$9$str$funtoString$classSnapshot$classUdpControlSession = ", ";

    /* JADX INFO: renamed from: String$10$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static String f1609String$10$str$funtoString$classSnapshot$classUdpControlSession = "lastAck=";

    /* JADX INFO: renamed from: String$12$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static String f1610String$12$str$funtoString$classSnapshot$classUdpControlSession = ", ";

    /* JADX INFO: renamed from: String$13$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static String f1611String$13$str$funtoString$classSnapshot$classUdpControlSession = "throttle=";

    /* JADX INFO: renamed from: String$15$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static String f1612String$15$str$funtoString$classSnapshot$classUdpControlSession = ", ";

    /* JADX INFO: renamed from: String$16$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static String f1613String$16$str$funtoString$classSnapshot$classUdpControlSession = "steering=";

    /* JADX INFO: renamed from: String$18$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static String f1614String$18$str$funtoString$classSnapshot$classUdpControlSession = ", ";

    /* JADX INFO: renamed from: String$19$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static String f1615String$19$str$funtoString$classSnapshot$classUdpControlSession = "maxRttMs=";

    /* JADX INFO: renamed from: String$21$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static String f1616String$21$str$funtoString$classSnapshot$classUdpControlSession = ", ";

    /* JADX INFO: renamed from: String$22$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static String f1617String$22$str$funtoString$classSnapshot$classUdpControlSession = "acknowledgedThrottle=";

    /* JADX INFO: renamed from: String$24$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static String f1618String$24$str$funtoString$classSnapshot$classUdpControlSession = ", ";

    /* JADX INFO: renamed from: String$25$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static String f1619String$25$str$funtoString$classSnapshot$classUdpControlSession = "acknowledgedSteering=";

    /* JADX INFO: renamed from: String$27$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static String f1620String$27$str$funtoString$classSnapshot$classUdpControlSession = ")";

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static int f1477Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classSnapshot$classUdpControlSession = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static int f1478Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classSnapshot$classUdpControlSession = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-2$fun-hashCode$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static int f1479Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classSnapshot$classUdpControlSession = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-3$fun-hashCode$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static int f1480Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classSnapshot$classUdpControlSession = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-4$fun-hashCode$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static int f1481Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classSnapshot$classUdpControlSession = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-5$fun-hashCode$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static int f1482Int$arg0$calltimes$$this$callplus$setresult5$funhashCode$classSnapshot$classUdpControlSession = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-6$fun-hashCode$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static int f1483Int$arg0$calltimes$$this$callplus$setresult6$funhashCode$classSnapshot$classUdpControlSession = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-7$fun-hashCode$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static int f1484Int$arg0$calltimes$$this$callplus$setresult7$funhashCode$classSnapshot$classUdpControlSession = 31;

    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static boolean f1440Boolean$branch$when$funequals$classSnapshot$classUdpControlSession = true;

    /* JADX INFO: renamed from: Boolean$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    private static boolean f1456Boolean$funequals$classSnapshot$classUdpControlSession = true;

    /* JADX INFO: renamed from: String$0$str$fun-toString$class-Sent$class-UdpControlSession, reason: not valid java name */
    private static String f1605String$0$str$funtoString$classSent$classUdpControlSession = "Sent(";

    /* JADX INFO: renamed from: String$1$str$fun-toString$class-Sent$class-UdpControlSession, reason: not valid java name */
    private static String f1607String$1$str$funtoString$classSent$classUdpControlSession = "packet=";

    /* JADX INFO: renamed from: String$3$str$fun-toString$class-Sent$class-UdpControlSession, reason: not valid java name */
    private static String f1621String$3$str$funtoString$classSent$classUdpControlSession = ", ";

    /* JADX INFO: renamed from: String$4$str$fun-toString$class-Sent$class-UdpControlSession, reason: not valid java name */
    private static String f1623String$4$str$funtoString$classSent$classUdpControlSession = "at=";

    /* JADX INFO: renamed from: String$6$str$fun-toString$class-Sent$class-UdpControlSession, reason: not valid java name */
    private static String f1625String$6$str$funtoString$classSent$classUdpControlSession = ")";

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Sent$class-UdpControlSession, reason: not valid java name */
    private static int f1476Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classSent$classUdpControlSession = 31;

    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-Sent$class-UdpControlSession, reason: not valid java name */
    private static boolean f1439Boolean$branch$when$funequals$classSent$classUdpControlSession = true;

    /* JADX INFO: renamed from: Boolean$fun-equals$class-Sent$class-UdpControlSession, reason: not valid java name */
    private static boolean f1455Boolean$funequals$classSent$classUdpControlSession = true;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$cond$arg-0$call-require$class-UdpControlSession, reason: not valid java name */
    private static int f1460Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$classUdpControlSession = 1;

    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$cond$arg-0$call-require$class-UdpControlSession, reason: not valid java name */
    private static long f1497Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$classUdpControlSession = 281474976710655L;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require$class-UdpControlSession, reason: not valid java name */
    private static int f1458Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$classUdpControlSession = 1;

    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require$class-UdpControlSession, reason: not valid java name */
    private static long f1496Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$classUdpControlSession = 4294967295L;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$cond$arg-0$call-require$fun-input$class-UdpControlSession, reason: not valid java name */
    private static int f1461Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$funinput$classUdpControlSession = -1000;

    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$cond$arg-0$call-require$fun-input$class-UdpControlSession, reason: not valid java name */
    private static int f1471Int$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$funinput$classUdpControlSession = 1000;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-input$class-UdpControlSession, reason: not valid java name */
    private static int f1459Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funinput$classUdpControlSession = -1000;

    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-input$class-UdpControlSession, reason: not valid java name */
    private static int f1470Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funinput$classUdpControlSession = 1000;

    /* JADX INFO: renamed from: String$param-reason$fun-stop$class-UdpControlSession, reason: not valid java name */
    private static String f1633String$paramreason$funstop$classUdpControlSession = "Stopped";

    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$branch$when$fun-expire$class-UdpControlSession, reason: not valid java name */
    private static int f1462Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch$when$funexpire$classUdpControlSession = 4000;

    /* JADX INFO: renamed from: String$arg-0$call-stop$branch$if$branch$when$fun-expire$class-UdpControlSession, reason: not valid java name */
    private static String f1630String$arg0$callstop$branch$if$branch$when$funexpire$classUdpControlSession = "HELLO timeout";

    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$branch-1$when$fun-expire$class-UdpControlSession, reason: not valid java name */
    private static int f1463Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch1$when$funexpire$classUdpControlSession = 200;

    /* JADX INFO: renamed from: String$arg-0$call-stop$branch$if$branch-1$when$fun-expire$class-UdpControlSession, reason: not valid java name */
    private static String f1631String$arg0$callstop$branch$if$branch1$when$funexpire$classUdpControlSession = "ARM timeout";

    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$branch-2$when$fun-expire$class-UdpControlSession, reason: not valid java name */
    private static int f1464Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch2$when$funexpire$classUdpControlSession = 200;

    /* JADX INFO: renamed from: String$arg-0$call-stop$branch$if$branch-2$when$fun-expire$class-UdpControlSession, reason: not valid java name */
    private static String f1632String$arg0$callstop$branch$if$branch2$when$funexpire$classUdpControlSession = "ACK freshness timeout";

    /* JADX INFO: renamed from: Int$branch$when$val-interval$fun-next$class-UdpControlSession, reason: not valid java name */
    private static int f1486Int$branch$when$valinterval$funnext$classUdpControlSession = 100;

    /* JADX INFO: renamed from: Int$branch-1$when$val-interval$fun-next$class-UdpControlSession, reason: not valid java name */
    private static int f1487Int$branch1$when$valinterval$funnext$classUdpControlSession = 50;

    /* JADX INFO: renamed from: Int$else$when$val-interval$fun-next$class-UdpControlSession, reason: not valid java name */
    private static int f1490Int$else$when$valinterval$funnext$classUdpControlSession = 20;

    /* JADX INFO: renamed from: Boolean$arg-1$call-EQEQ$cond$if-1$fun-next$class-UdpControlSession, reason: not valid java name */
    private static boolean f1432Boolean$arg1$callEQEQ$cond$if1$funnext$classUdpControlSession = true;

    /* JADX INFO: renamed from: Long$arg-1$call-packet$$$this$call-also$branch-1$when$val-p$fun-next$class-UdpControlSession, reason: not valid java name */
    private static long f1501Long$arg1$callpacket$$$this$callalso$branch1$when$valp$funnext$classUdpControlSession = 1;

    /* JADX INFO: renamed from: Int$arg-0$call-set$branch$if$fun-$anonymous$$arg-0$call-also$branch-1$when$val-p$fun-next$class-UdpControlSession, reason: not valid java name */
    private static int f1475Int$arg0$callset$branch$if$fun$anonymous$$arg0$callalso$branch1$when$valp$funnext$classUdpControlSession = 1;

    /* JADX INFO: renamed from: Int$arg-0$call-plus$$this$call-and$arg-0$call-$set-sequence$$branch-2$when$val-p$fun-next$class-UdpControlSession, reason: not valid java name */
    private static int f1469Int$arg0$callplus$$this$calland$arg0$call$setsequence$$branch2$when$valp$funnext$classUdpControlSession = 1;

    /* JADX INFO: renamed from: Long$arg-0$call-and$arg-0$call-$set-sequence$$branch-2$when$val-p$fun-next$class-UdpControlSession, reason: not valid java name */
    private static long f1494Long$arg0$calland$arg0$call$setsequence$$branch2$when$valp$funnext$classUdpControlSession = 4294967295L;

    /* JADX INFO: renamed from: Int$arg-0$call-rem$$this$call-toInt$arg-0$call-set$fun-$anonymous$$arg-0$call-also$branch-2$when$val-p$fun-next$class-UdpControlSession, reason: not valid java name */
    private static int f1473Int$arg0$callrem$$this$calltoInt$arg0$callset$fun$anonymous$$arg0$callalso$branch2$when$valp$funnext$classUdpControlSession = 64;

    /* JADX INFO: renamed from: Boolean$branch$if-1$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static boolean f1435Boolean$branch$if1$funreceive$classUdpControlSession = true;

    /* JADX INFO: renamed from: Int$arg-0$call-rem$$this$call-toInt$arg-0$call-get$val-tmp0_elvis_lhs$val-sent$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static int f1472Int$arg0$callrem$$this$calltoInt$arg0$callget$valtmp0_elvis_lhs$valsent$funreceive$classUdpControlSession = 64;

    /* JADX INFO: renamed from: Long$arg-0$call-and$val-distance$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static long f1495Long$arg0$calland$valdistance$funreceive$classUdpControlSession = 4294967295L;

    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$$this$call-not$branch$cond$if-4$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static long f1498Long$arg1$callEQEQ$$this$callnot$branch$cond$if4$funreceive$classUdpControlSession = 1;

    /* JADX INFO: renamed from: Int$arg-0$call-rem$$this$call-toInt$arg-0$call-set$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static int f1474Int$arg0$callrem$$this$calltoInt$arg0$callset$funreceive$classUdpControlSession = 64;

    /* JADX INFO: renamed from: Long$arg-0$call-$set-sequence$$branch$if-5$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static long f1493Long$arg0$call$setsequence$$branch$if5$funreceive$classUdpControlSession = 1;

    /* JADX INFO: renamed from: String$arg-0$call-$set-reason$$branch$if-5$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static String f1629String$arg0$call$setreason$$branch$if5$funreceive$classUdpControlSession = "Connected";

    /* JADX INFO: renamed from: Boolean$fun-receive$class-UdpControlSession, reason: not valid java name */
    private static boolean f1457Boolean$funreceive$classUdpControlSession = true;

    /* JADX INFO: renamed from: Int$class-UdpControlSession, reason: not valid java name */
    private static int f1489Int$classUdpControlSession = 8;

    @LiveLiteralInfo(key = "Boolean$arg-1$call-EQEQ$cond$if-1$fun-next$class-UdpControlSession", offset = 2706)
    /* JADX INFO: renamed from: Boolean$arg-1$call-EQEQ$cond$if-1$fun-next$class-UdpControlSession, reason: not valid java name */
    public final boolean m6678Boolean$arg1$callEQEQ$cond$if1$funnext$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1432Boolean$arg1$callEQEQ$cond$if1$funnext$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1504State$Boolean$arg1$callEQEQ$cond$if1$funnext$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-EQEQ$cond$if-1$fun-next$class-UdpControlSession", Boolean.valueOf(f1432Boolean$arg1$callEQEQ$cond$if1$funnext$classUdpControlSession));
            f1504State$Boolean$arg1$callEQEQ$cond$if1$funnext$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$if$branch$if-1$fun-receive$class-UdpControlSession", offset = 3921)
    /* JADX INFO: renamed from: Boolean$branch$if$branch$if-1$fun-receive$class-UdpControlSession, reason: not valid java name */
    public final boolean m6679Boolean$branch$if$branch$if1$funreceive$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1433Boolean$branch$if$branch$if1$funreceive$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1505State$Boolean$branch$if$branch$if1$funreceive$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$if$branch$if-1$fun-receive$class-UdpControlSession", Boolean.valueOf(f1433Boolean$branch$if$branch$if1$funreceive$classUdpControlSession));
            f1505State$Boolean$branch$if$branch$if1$funreceive$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$if$fun-receive$class-UdpControlSession", offset = 3729)
    /* JADX INFO: renamed from: Boolean$branch$if$fun-receive$class-UdpControlSession, reason: not valid java name */
    public final boolean m6680Boolean$branch$if$funreceive$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1434Boolean$branch$if$funreceive$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1506State$Boolean$branch$if$funreceive$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$if$fun-receive$class-UdpControlSession", Boolean.valueOf(f1434Boolean$branch$if$funreceive$classUdpControlSession));
            f1506State$Boolean$branch$if$funreceive$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$if-1$fun-receive$class-UdpControlSession", offset = 4028)
    /* JADX INFO: renamed from: Boolean$branch$if-1$fun-receive$class-UdpControlSession, reason: not valid java name */
    public final boolean m6681Boolean$branch$if1$funreceive$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1435Boolean$branch$if1$funreceive$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1507State$Boolean$branch$if1$funreceive$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$if-1$fun-receive$class-UdpControlSession", Boolean.valueOf(f1435Boolean$branch$if1$funreceive$classUdpControlSession));
            f1507State$Boolean$branch$if1$funreceive$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$if-2$fun-receive$class-UdpControlSession", offset = 4114)
    /* JADX INFO: renamed from: Boolean$branch$if-2$fun-receive$class-UdpControlSession, reason: not valid java name */
    public final boolean m6682Boolean$branch$if2$funreceive$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1436Boolean$branch$if2$funreceive$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1508State$Boolean$branch$if2$funreceive$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$if-2$fun-receive$class-UdpControlSession", Boolean.valueOf(f1436Boolean$branch$if2$funreceive$classUdpControlSession));
            f1508State$Boolean$branch$if2$funreceive$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$if-3$fun-receive$class-UdpControlSession", offset = 4450)
    /* JADX INFO: renamed from: Boolean$branch$if-3$fun-receive$class-UdpControlSession, reason: not valid java name */
    public final boolean m6683Boolean$branch$if3$funreceive$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1437Boolean$branch$if3$funreceive$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1509State$Boolean$branch$if3$funreceive$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$if-3$fun-receive$class-UdpControlSession", Boolean.valueOf(f1437Boolean$branch$if3$funreceive$classUdpControlSession));
            f1509State$Boolean$branch$if3$funreceive$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$if-4$fun-receive$class-UdpControlSession", offset = 4518)
    /* JADX INFO: renamed from: Boolean$branch$if-4$fun-receive$class-UdpControlSession, reason: not valid java name */
    public final boolean m6684Boolean$branch$if4$funreceive$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1438Boolean$branch$if4$funreceive$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1510State$Boolean$branch$if4$funreceive$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$if-4$fun-receive$class-UdpControlSession", Boolean.valueOf(f1438Boolean$branch$if4$funreceive$classUdpControlSession));
            f1510State$Boolean$branch$if4$funreceive$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when$fun-equals$class-Sent$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-Sent$class-UdpControlSession, reason: not valid java name */
    public final boolean m6685Boolean$branch$when$funequals$classSent$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1439Boolean$branch$when$funequals$classSent$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1511State$Boolean$branch$when$funequals$classSent$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when$fun-equals$class-Sent$class-UdpControlSession", Boolean.valueOf(f1439Boolean$branch$when$funequals$classSent$classUdpControlSession));
            f1511State$Boolean$branch$when$funequals$classSent$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when$fun-equals$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final boolean m6686Boolean$branch$when$funequals$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1440Boolean$branch$when$funequals$classSnapshot$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1512State$Boolean$branch$when$funequals$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when$fun-equals$class-Snapshot$class-UdpControlSession", Boolean.valueOf(f1440Boolean$branch$when$funequals$classSnapshot$classUdpControlSession));
            f1512State$Boolean$branch$when$funequals$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when$val-sent$fun-receive$class-UdpControlSession", offset = 4184)
    /* JADX INFO: renamed from: Boolean$branch$when$val-sent$fun-receive$class-UdpControlSession, reason: not valid java name */
    public final boolean m6687Boolean$branch$when$valsent$funreceive$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1441Boolean$branch$when$valsent$funreceive$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1513State$Boolean$branch$when$valsent$funreceive$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when$val-sent$fun-receive$class-UdpControlSession", Boolean.valueOf(f1441Boolean$branch$when$valsent$funreceive$classUdpControlSession));
            f1513State$Boolean$branch$when$valsent$funreceive$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-1$fun-equals$class-Sent$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-Sent$class-UdpControlSession, reason: not valid java name */
    public final boolean m6688Boolean$branch$when1$funequals$classSent$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1442Boolean$branch$when1$funequals$classSent$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1514State$Boolean$branch$when1$funequals$classSent$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-1$fun-equals$class-Sent$class-UdpControlSession", Boolean.valueOf(f1442Boolean$branch$when1$funequals$classSent$classUdpControlSession));
            f1514State$Boolean$branch$when1$funequals$classSent$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-1$fun-equals$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final boolean m6689Boolean$branch$when1$funequals$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1443Boolean$branch$when1$funequals$classSnapshot$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1515State$Boolean$branch$when1$funequals$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-1$fun-equals$class-Snapshot$class-UdpControlSession", Boolean.valueOf(f1443Boolean$branch$when1$funequals$classSnapshot$classUdpControlSession));
            f1515State$Boolean$branch$when1$funequals$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-10$fun-equals$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-10$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final boolean m6690Boolean$branch$when10$funequals$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1444Boolean$branch$when10$funequals$classSnapshot$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1516State$Boolean$branch$when10$funequals$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-10$fun-equals$class-Snapshot$class-UdpControlSession", Boolean.valueOf(f1444Boolean$branch$when10$funequals$classSnapshot$classUdpControlSession));
            f1516State$Boolean$branch$when10$funequals$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-2$fun-equals$class-Sent$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-Sent$class-UdpControlSession, reason: not valid java name */
    public final boolean m6691Boolean$branch$when2$funequals$classSent$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1445Boolean$branch$when2$funequals$classSent$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1517State$Boolean$branch$when2$funequals$classSent$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-2$fun-equals$class-Sent$class-UdpControlSession", Boolean.valueOf(f1445Boolean$branch$when2$funequals$classSent$classUdpControlSession));
            f1517State$Boolean$branch$when2$funequals$classSent$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-2$fun-equals$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final boolean m6692Boolean$branch$when2$funequals$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1446Boolean$branch$when2$funequals$classSnapshot$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1518State$Boolean$branch$when2$funequals$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-2$fun-equals$class-Snapshot$class-UdpControlSession", Boolean.valueOf(f1446Boolean$branch$when2$funequals$classSnapshot$classUdpControlSession));
            f1518State$Boolean$branch$when2$funequals$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-3$fun-equals$class-Sent$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-Sent$class-UdpControlSession, reason: not valid java name */
    public final boolean m6693Boolean$branch$when3$funequals$classSent$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1447Boolean$branch$when3$funequals$classSent$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1519State$Boolean$branch$when3$funequals$classSent$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-3$fun-equals$class-Sent$class-UdpControlSession", Boolean.valueOf(f1447Boolean$branch$when3$funequals$classSent$classUdpControlSession));
            f1519State$Boolean$branch$when3$funequals$classSent$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-3$fun-equals$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final boolean m6694Boolean$branch$when3$funequals$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1448Boolean$branch$when3$funequals$classSnapshot$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1520State$Boolean$branch$when3$funequals$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-3$fun-equals$class-Snapshot$class-UdpControlSession", Boolean.valueOf(f1448Boolean$branch$when3$funequals$classSnapshot$classUdpControlSession));
            f1520State$Boolean$branch$when3$funequals$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-4$fun-equals$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-4$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final boolean m6695Boolean$branch$when4$funequals$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1449Boolean$branch$when4$funequals$classSnapshot$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1521State$Boolean$branch$when4$funequals$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-4$fun-equals$class-Snapshot$class-UdpControlSession", Boolean.valueOf(f1449Boolean$branch$when4$funequals$classSnapshot$classUdpControlSession));
            f1521State$Boolean$branch$when4$funequals$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-5$fun-equals$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-5$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final boolean m6696Boolean$branch$when5$funequals$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1450Boolean$branch$when5$funequals$classSnapshot$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1522State$Boolean$branch$when5$funequals$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-5$fun-equals$class-Snapshot$class-UdpControlSession", Boolean.valueOf(f1450Boolean$branch$when5$funequals$classSnapshot$classUdpControlSession));
            f1522State$Boolean$branch$when5$funequals$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-6$fun-equals$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-6$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final boolean m6697Boolean$branch$when6$funequals$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1451Boolean$branch$when6$funequals$classSnapshot$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1523State$Boolean$branch$when6$funequals$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-6$fun-equals$class-Snapshot$class-UdpControlSession", Boolean.valueOf(f1451Boolean$branch$when6$funequals$classSnapshot$classUdpControlSession));
            f1523State$Boolean$branch$when6$funequals$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-7$fun-equals$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-7$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final boolean m6698Boolean$branch$when7$funequals$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1452Boolean$branch$when7$funequals$classSnapshot$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1524State$Boolean$branch$when7$funequals$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-7$fun-equals$class-Snapshot$class-UdpControlSession", Boolean.valueOf(f1452Boolean$branch$when7$funequals$classSnapshot$classUdpControlSession));
            f1524State$Boolean$branch$when7$funequals$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-8$fun-equals$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-8$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final boolean m6699Boolean$branch$when8$funequals$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1453Boolean$branch$when8$funequals$classSnapshot$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1525State$Boolean$branch$when8$funequals$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-8$fun-equals$class-Snapshot$class-UdpControlSession", Boolean.valueOf(f1453Boolean$branch$when8$funequals$classSnapshot$classUdpControlSession));
            f1525State$Boolean$branch$when8$funequals$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-9$fun-equals$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-9$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final boolean m6700Boolean$branch$when9$funequals$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1454Boolean$branch$when9$funequals$classSnapshot$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1526State$Boolean$branch$when9$funequals$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-9$fun-equals$class-Snapshot$class-UdpControlSession", Boolean.valueOf(f1454Boolean$branch$when9$funequals$classSnapshot$classUdpControlSession));
            f1526State$Boolean$branch$when9$funequals$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$fun-equals$class-Sent$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Boolean$fun-equals$class-Sent$class-UdpControlSession, reason: not valid java name */
    public final boolean m6701Boolean$funequals$classSent$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1455Boolean$funequals$classSent$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1527State$Boolean$funequals$classSent$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$fun-equals$class-Sent$class-UdpControlSession", Boolean.valueOf(f1455Boolean$funequals$classSent$classUdpControlSession));
            f1527State$Boolean$funequals$classSent$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$fun-equals$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Boolean$fun-equals$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final boolean m6702Boolean$funequals$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1456Boolean$funequals$classSnapshot$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1528State$Boolean$funequals$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$fun-equals$class-Snapshot$class-UdpControlSession", Boolean.valueOf(f1456Boolean$funequals$classSnapshot$classUdpControlSession));
            f1528State$Boolean$funequals$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$fun-receive$class-UdpControlSession", offset = 4884)
    /* JADX INFO: renamed from: Boolean$fun-receive$class-UdpControlSession, reason: not valid java name */
    public final boolean m6703Boolean$funreceive$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1457Boolean$funreceive$classUdpControlSession;
        }
        State<Boolean> stateLiveLiteral = f1529State$Boolean$funreceive$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$fun-receive$class-UdpControlSession", Boolean.valueOf(f1457Boolean$funreceive$classUdpControlSession));
            f1529State$Boolean$funreceive$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require$class-UdpControlSession", offset = 1260)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require$class-UdpControlSession, reason: not valid java name */
    public final int m6704Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1458Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1530State$Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require$class-UdpControlSession", Integer.valueOf(f1458Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$classUdpControlSession));
            f1530State$Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-input$class-UdpControlSession", offset = 1535)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-input$class-UdpControlSession, reason: not valid java name */
    public final int m6705Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funinput$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1459Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funinput$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1531State$Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funinput$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-input$class-UdpControlSession", Integer.valueOf(f1459Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funinput$classUdpControlSession));
            f1531State$Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funinput$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$cond$arg-0$call-require$class-UdpControlSession", offset = 1227)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$cond$arg-0$call-require$class-UdpControlSession, reason: not valid java name */
    public final int m6706Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1460Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1532State$Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$cond$arg-0$call-require$class-UdpControlSession", Integer.valueOf(f1460Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$classUdpControlSession));
            f1532State$Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$cond$arg-0$call-require$fun-input$class-UdpControlSession", offset = 1508)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$cond$arg-0$call-require$fun-input$class-UdpControlSession, reason: not valid java name */
    public final int m6707Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$funinput$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1461Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$funinput$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1533State$Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$funinput$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$cond$arg-0$call-require$fun-input$class-UdpControlSession", Integer.valueOf(f1461Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$funinput$classUdpControlSession));
            f1533State$Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$funinput$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$branch$when$fun-expire$class-UdpControlSession", offset = 2163)
    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$branch$when$fun-expire$class-UdpControlSession, reason: not valid java name */
    public final int m6708Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch$when$funexpire$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1462Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch$when$funexpire$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1534State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch$when$funexpire$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$branch$when$fun-expire$class-UdpControlSession", Integer.valueOf(f1462Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch$when$funexpire$classUdpControlSession));
            f1534State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch$when$funexpire$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$branch-1$when$fun-expire$class-UdpControlSession", offset = 2256)
    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$branch-1$when$fun-expire$class-UdpControlSession, reason: not valid java name */
    public final int m6709Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch1$when$funexpire$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1463Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch1$when$funexpire$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1535State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch1$when$funexpire$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$branch-1$when$fun-expire$class-UdpControlSession", Integer.valueOf(f1463Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch1$when$funexpire$classUdpControlSession));
            f1535State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch1$when$funexpire$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$branch-2$when$fun-expire$class-UdpControlSession", offset = 2334)
    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$branch-2$when$fun-expire$class-UdpControlSession, reason: not valid java name */
    public final int m6710Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch2$when$funexpire$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1464Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch2$when$funexpire$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1536State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch2$when$funexpire$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if$branch-2$when$fun-expire$class-UdpControlSession", Integer.valueOf(f1464Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch2$when$funexpire$classUdpControlSession));
            f1536State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch2$when$funexpire$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-$set-acknowledgedSteering$$fun-stop$class-UdpControlSession", offset = 2017)
    /* JADX INFO: renamed from: Int$arg-0$call-$set-acknowledgedSteering$$fun-stop$class-UdpControlSession, reason: not valid java name */
    public final int m6711Int$arg0$call$setacknowledgedSteering$$funstop$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1465Int$arg0$call$setacknowledgedSteering$$funstop$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1537State$Int$arg0$call$setacknowledgedSteering$$funstop$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-$set-acknowledgedSteering$$fun-stop$class-UdpControlSession", Integer.valueOf(f1465Int$arg0$call$setacknowledgedSteering$$funstop$classUdpControlSession));
            f1537State$Int$arg0$call$setacknowledgedSteering$$funstop$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-$set-acknowledgedThrottle$$fun-stop$class-UdpControlSession", offset = 1991)
    /* JADX INFO: renamed from: Int$arg-0$call-$set-acknowledgedThrottle$$fun-stop$class-UdpControlSession, reason: not valid java name */
    public final int m6712Int$arg0$call$setacknowledgedThrottle$$funstop$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1466Int$arg0$call$setacknowledgedThrottle$$funstop$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1538State$Int$arg0$call$setacknowledgedThrottle$$funstop$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-$set-acknowledgedThrottle$$fun-stop$class-UdpControlSession", Integer.valueOf(f1466Int$arg0$call$setacknowledgedThrottle$$funstop$classUdpControlSession));
            f1538State$Int$arg0$call$setacknowledgedThrottle$$funstop$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-$set-steering$$fun-stop$class-UdpControlSession", offset = 1958)
    /* JADX INFO: renamed from: Int$arg-0$call-$set-steering$$fun-stop$class-UdpControlSession, reason: not valid java name */
    public final int m6713Int$arg0$call$setsteering$$funstop$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1467Int$arg0$call$setsteering$$funstop$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1539State$Int$arg0$call$setsteering$$funstop$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-$set-steering$$fun-stop$class-UdpControlSession", Integer.valueOf(f1467Int$arg0$call$setsteering$$funstop$classUdpControlSession));
            f1539State$Int$arg0$call$setsteering$$funstop$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-$set-throttle$$fun-stop$class-UdpControlSession", offset = 1944)
    /* JADX INFO: renamed from: Int$arg-0$call-$set-throttle$$fun-stop$class-UdpControlSession, reason: not valid java name */
    public final int m6714Int$arg0$call$setthrottle$$funstop$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1468Int$arg0$call$setthrottle$$funstop$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1540State$Int$arg0$call$setthrottle$$funstop$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-$set-throttle$$fun-stop$class-UdpControlSession", Integer.valueOf(f1468Int$arg0$call$setthrottle$$funstop$classUdpControlSession));
            f1540State$Int$arg0$call$setthrottle$$funstop$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-plus$$this$call-and$arg-0$call-$set-sequence$$branch-2$when$val-p$fun-next$class-UdpControlSession", offset = 3151)
    /* JADX INFO: renamed from: Int$arg-0$call-plus$$this$call-and$arg-0$call-$set-sequence$$branch-2$when$val-p$fun-next$class-UdpControlSession, reason: not valid java name */
    public final int m6715Int$arg0$callplus$$this$calland$arg0$call$setsequence$$branch2$when$valp$funnext$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1469Int$arg0$callplus$$this$calland$arg0$call$setsequence$$branch2$when$valp$funnext$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1541State$Int$arg0$callplus$$this$calland$arg0$call$setsequence$$branch2$when$valp$funnext$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-plus$$this$call-and$arg-0$call-$set-sequence$$branch-2$when$val-p$fun-next$class-UdpControlSession", Integer.valueOf(f1469Int$arg0$callplus$$this$calland$arg0$call$setsequence$$branch2$when$valp$funnext$classUdpControlSession));
            f1541State$Int$arg0$callplus$$this$calland$arg0$call$setsequence$$branch2$when$valp$funnext$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-input$class-UdpControlSession", offset = 1542)
    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-input$class-UdpControlSession, reason: not valid java name */
    public final int m6716Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funinput$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1470Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funinput$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1542State$Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funinput$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require$fun-input$class-UdpControlSession", Integer.valueOf(f1470Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funinput$classUdpControlSession));
            f1542State$Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funinput$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rangeTo$$this$call-contains$cond$arg-0$call-require$fun-input$class-UdpControlSession", offset = 1515)
    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$cond$arg-0$call-require$fun-input$class-UdpControlSession, reason: not valid java name */
    public final int m6717Int$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$funinput$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1471Int$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$funinput$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1543State$Int$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$funinput$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rangeTo$$this$call-contains$cond$arg-0$call-require$fun-input$class-UdpControlSession", Integer.valueOf(f1471Int$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$funinput$classUdpControlSession));
            f1543State$Int$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$funinput$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rem$$this$call-toInt$arg-0$call-get$val-tmp0_elvis_lhs$val-sent$fun-receive$class-UdpControlSession", offset = 4161)
    /* JADX INFO: renamed from: Int$arg-0$call-rem$$this$call-toInt$arg-0$call-get$val-tmp0_elvis_lhs$val-sent$fun-receive$class-UdpControlSession, reason: not valid java name */
    public final int m6718Int$arg0$callrem$$this$calltoInt$arg0$callget$valtmp0_elvis_lhs$valsent$funreceive$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1472Int$arg0$callrem$$this$calltoInt$arg0$callget$valtmp0_elvis_lhs$valsent$funreceive$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1544State$Int$arg0$callrem$$this$calltoInt$arg0$callget$valtmp0_elvis_lhs$valsent$funreceive$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rem$$this$call-toInt$arg-0$call-get$val-tmp0_elvis_lhs$val-sent$fun-receive$class-UdpControlSession", Integer.valueOf(f1472Int$arg0$callrem$$this$calltoInt$arg0$callget$valtmp0_elvis_lhs$valsent$funreceive$classUdpControlSession));
            f1544State$Int$arg0$callrem$$this$calltoInt$arg0$callget$valtmp0_elvis_lhs$valsent$funreceive$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rem$$this$call-toInt$arg-0$call-set$fun-$anonymous$$arg-0$call-also$branch-2$when$val-p$fun-next$class-UdpControlSession", offset = 3303)
    /* JADX INFO: renamed from: Int$arg-0$call-rem$$this$call-toInt$arg-0$call-set$fun-$anonymous$$arg-0$call-also$branch-2$when$val-p$fun-next$class-UdpControlSession, reason: not valid java name */
    public final int m6719Int$arg0$callrem$$this$calltoInt$arg0$callset$fun$anonymous$$arg0$callalso$branch2$when$valp$funnext$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1473Int$arg0$callrem$$this$calltoInt$arg0$callset$fun$anonymous$$arg0$callalso$branch2$when$valp$funnext$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1545State$Int$arg0$callrem$$this$calltoInt$arg0$callset$fun$anonymous$$arg0$callalso$branch2$when$valp$funnext$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rem$$this$call-toInt$arg-0$call-set$fun-$anonymous$$arg-0$call-also$branch-2$when$val-p$fun-next$class-UdpControlSession", Integer.valueOf(f1473Int$arg0$callrem$$this$calltoInt$arg0$callset$fun$anonymous$$arg0$callalso$branch2$when$valp$funnext$classUdpControlSession));
            f1545State$Int$arg0$callrem$$this$calltoInt$arg0$callset$fun$anonymous$$arg0$callalso$branch2$when$valp$funnext$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rem$$this$call-toInt$arg-0$call-set$fun-receive$class-UdpControlSession", offset = 4753)
    /* JADX INFO: renamed from: Int$arg-0$call-rem$$this$call-toInt$arg-0$call-set$fun-receive$class-UdpControlSession, reason: not valid java name */
    public final int m6720Int$arg0$callrem$$this$calltoInt$arg0$callset$funreceive$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1474Int$arg0$callrem$$this$calltoInt$arg0$callset$funreceive$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1546State$Int$arg0$callrem$$this$calltoInt$arg0$callset$funreceive$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rem$$this$call-toInt$arg-0$call-set$fun-receive$class-UdpControlSession", Integer.valueOf(f1474Int$arg0$callrem$$this$calltoInt$arg0$callset$funreceive$classUdpControlSession));
            f1546State$Int$arg0$callrem$$this$calltoInt$arg0$callset$funreceive$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-set$branch$if$fun-$anonymous$$arg-0$call-also$branch-1$when$val-p$fun-next$class-UdpControlSession", offset = 2991)
    /* JADX INFO: renamed from: Int$arg-0$call-set$branch$if$fun-$anonymous$$arg-0$call-also$branch-1$when$val-p$fun-next$class-UdpControlSession, reason: not valid java name */
    public final int m6721Int$arg0$callset$branch$if$fun$anonymous$$arg0$callalso$branch1$when$valp$funnext$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1475Int$arg0$callset$branch$if$fun$anonymous$$arg0$callalso$branch1$when$valp$funnext$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1547State$Int$arg0$callset$branch$if$fun$anonymous$$arg0$callalso$branch1$when$valp$funnext$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-set$branch$if$fun-$anonymous$$arg-0$call-also$branch-1$when$val-p$fun-next$class-UdpControlSession", Integer.valueOf(f1475Int$arg0$callset$branch$if$fun$anonymous$$arg0$callalso$branch1$when$valp$funnext$classUdpControlSession));
            f1547State$Int$arg0$callset$branch$if$fun$anonymous$$arg0$callalso$branch1$when$valp$funnext$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Sent$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Sent$class-UdpControlSession, reason: not valid java name */
    public final int m6722Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classSent$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1476Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classSent$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1548State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classSent$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Sent$class-UdpControlSession", Integer.valueOf(f1476Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classSent$classUdpControlSession));
            f1548State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classSent$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final int m6723Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1477Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classSnapshot$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1549State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Snapshot$class-UdpControlSession", Integer.valueOf(f1477Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classSnapshot$classUdpControlSession));
            f1549State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final int m6724Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1478Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classSnapshot$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1550State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-Snapshot$class-UdpControlSession", Integer.valueOf(f1478Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classSnapshot$classUdpControlSession));
            f1550State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-2$fun-hashCode$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-2$fun-hashCode$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final int m6725Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1479Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classSnapshot$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1551State$Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-2$fun-hashCode$class-Snapshot$class-UdpControlSession", Integer.valueOf(f1479Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classSnapshot$classUdpControlSession));
            f1551State$Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-3$fun-hashCode$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-3$fun-hashCode$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final int m6726Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1480Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classSnapshot$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1552State$Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-3$fun-hashCode$class-Snapshot$class-UdpControlSession", Integer.valueOf(f1480Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classSnapshot$classUdpControlSession));
            f1552State$Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-4$fun-hashCode$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-4$fun-hashCode$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final int m6727Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1481Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classSnapshot$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1553State$Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-4$fun-hashCode$class-Snapshot$class-UdpControlSession", Integer.valueOf(f1481Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classSnapshot$classUdpControlSession));
            f1553State$Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-5$fun-hashCode$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-5$fun-hashCode$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final int m6728Int$arg0$calltimes$$this$callplus$setresult5$funhashCode$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1482Int$arg0$calltimes$$this$callplus$setresult5$funhashCode$classSnapshot$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1554State$Int$arg0$calltimes$$this$callplus$setresult5$funhashCode$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-5$fun-hashCode$class-Snapshot$class-UdpControlSession", Integer.valueOf(f1482Int$arg0$calltimes$$this$callplus$setresult5$funhashCode$classSnapshot$classUdpControlSession));
            f1554State$Int$arg0$calltimes$$this$callplus$setresult5$funhashCode$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-6$fun-hashCode$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-6$fun-hashCode$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final int m6729Int$arg0$calltimes$$this$callplus$setresult6$funhashCode$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1483Int$arg0$calltimes$$this$callplus$setresult6$funhashCode$classSnapshot$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1555State$Int$arg0$calltimes$$this$callplus$setresult6$funhashCode$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-6$fun-hashCode$class-Snapshot$class-UdpControlSession", Integer.valueOf(f1483Int$arg0$calltimes$$this$callplus$setresult6$funhashCode$classSnapshot$classUdpControlSession));
            f1555State$Int$arg0$calltimes$$this$callplus$setresult6$funhashCode$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-7$fun-hashCode$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-7$fun-hashCode$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final int m6730Int$arg0$calltimes$$this$callplus$setresult7$funhashCode$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1484Int$arg0$calltimes$$this$callplus$setresult7$funhashCode$classSnapshot$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1556State$Int$arg0$calltimes$$this$callplus$setresult7$funhashCode$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-7$fun-hashCode$class-Snapshot$class-UdpControlSession", Integer.valueOf(f1484Int$arg0$calltimes$$this$callplus$setresult7$funhashCode$classSnapshot$classUdpControlSession));
            f1556State$Int$arg0$calltimes$$this$callplus$setresult7$funhashCode$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-EQEQ$$this$call-not$else$cond$if$branch$if-1$fun-receive$class-UdpControlSession", offset = 3911)
    /* JADX INFO: renamed from: Int$arg-1$call-EQEQ$$this$call-not$else$cond$if$branch$if-1$fun-receive$class-UdpControlSession, reason: not valid java name */
    public final int m6731Int$arg1$callEQEQ$$this$callnot$else$cond$if$branch$if1$funreceive$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1485Int$arg1$callEQEQ$$this$callnot$else$cond$if$branch$if1$funreceive$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1557State$Int$arg1$callEQEQ$$this$callnot$else$cond$if$branch$if1$funreceive$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-EQEQ$$this$call-not$else$cond$if$branch$if-1$fun-receive$class-UdpControlSession", Integer.valueOf(f1485Int$arg1$callEQEQ$$this$callnot$else$cond$if$branch$if1$funreceive$classUdpControlSession));
            f1557State$Int$arg1$callEQEQ$$this$callnot$else$cond$if$branch$if1$funreceive$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$branch$when$val-interval$fun-next$class-UdpControlSession", offset = 2615)
    /* JADX INFO: renamed from: Int$branch$when$val-interval$fun-next$class-UdpControlSession, reason: not valid java name */
    public final int m6732Int$branch$when$valinterval$funnext$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1486Int$branch$when$valinterval$funnext$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1558State$Int$branch$when$valinterval$funnext$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$branch$when$val-interval$fun-next$class-UdpControlSession", Integer.valueOf(f1486Int$branch$when$valinterval$funnext$classUdpControlSession));
            f1558State$Int$branch$when$valinterval$funnext$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$branch-1$when$val-interval$fun-next$class-UdpControlSession", offset = 2636)
    /* JADX INFO: renamed from: Int$branch-1$when$val-interval$fun-next$class-UdpControlSession, reason: not valid java name */
    public final int m6733Int$branch1$when$valinterval$funnext$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1487Int$branch1$when$valinterval$funnext$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1559State$Int$branch1$when$valinterval$funnext$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$branch-1$when$val-interval$fun-next$class-UdpControlSession", Integer.valueOf(f1487Int$branch1$when$valinterval$funnext$classUdpControlSession));
            f1559State$Int$branch1$when$valinterval$funnext$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-Snapshot$class-UdpControlSession", offset = -1)
    /* JADX INFO: renamed from: Int$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final int m6734Int$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1488Int$classSnapshot$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1560State$Int$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-Snapshot$class-UdpControlSession", Integer.valueOf(f1488Int$classSnapshot$classUdpControlSession));
            f1560State$Int$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-UdpControlSession", offset = -1)
    /* JADX INFO: renamed from: Int$class-UdpControlSession, reason: not valid java name */
    public final int m6735Int$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1489Int$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1561State$Int$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-UdpControlSession", Integer.valueOf(f1489Int$classUdpControlSession));
            f1561State$Int$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$else$when$val-interval$fun-next$class-UdpControlSession", offset = 2648)
    /* JADX INFO: renamed from: Int$else$when$val-interval$fun-next$class-UdpControlSession, reason: not valid java name */
    public final int m6736Int$else$when$valinterval$funnext$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1490Int$else$when$valinterval$funnext$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1562State$Int$else$when$valinterval$funnext$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$else$when$val-interval$fun-next$class-UdpControlSession", Integer.valueOf(f1490Int$else$when$valinterval$funnext$classUdpControlSession));
            f1562State$Int$else$when$valinterval$funnext$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$param-s$fun-packet$class-UdpControlSession", offset = 4962)
    /* JADX INFO: renamed from: Int$param-s$fun-packet$class-UdpControlSession, reason: not valid java name */
    public final int m6737Int$params$funpacket$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1491Int$params$funpacket$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1563State$Int$params$funpacket$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$param-s$fun-packet$class-UdpControlSession", Integer.valueOf(f1491Int$params$funpacket$classUdpControlSession));
            f1563State$Int$params$funpacket$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$param-t$fun-packet$class-UdpControlSession", offset = 4950)
    /* JADX INFO: renamed from: Int$param-t$fun-packet$class-UdpControlSession, reason: not valid java name */
    public final int m6738Int$paramt$funpacket$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1492Int$paramt$funpacket$classUdpControlSession;
        }
        State<Integer> stateLiveLiteral = f1564State$Int$paramt$funpacket$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$param-t$fun-packet$class-UdpControlSession", Integer.valueOf(f1492Int$paramt$funpacket$classUdpControlSession));
            f1564State$Int$paramt$funpacket$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-$set-sequence$$branch$if-5$fun-receive$class-UdpControlSession", offset = 4821)
    /* JADX INFO: renamed from: Long$arg-0$call-$set-sequence$$branch$if-5$fun-receive$class-UdpControlSession, reason: not valid java name */
    public final long m6739Long$arg0$call$setsequence$$branch$if5$funreceive$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1493Long$arg0$call$setsequence$$branch$if5$funreceive$classUdpControlSession;
        }
        State<Long> stateLiveLiteral = f1565State$Long$arg0$call$setsequence$$branch$if5$funreceive$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-$set-sequence$$branch$if-5$fun-receive$class-UdpControlSession", Long.valueOf(f1493Long$arg0$call$setsequence$$branch$if5$funreceive$classUdpControlSession));
            f1565State$Long$arg0$call$setsequence$$branch$if5$funreceive$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-and$arg-0$call-$set-sequence$$branch-2$when$val-p$fun-next$class-UdpControlSession", offset = 3158)
    /* JADX INFO: renamed from: Long$arg-0$call-and$arg-0$call-$set-sequence$$branch-2$when$val-p$fun-next$class-UdpControlSession, reason: not valid java name */
    public final long m6740Long$arg0$calland$arg0$call$setsequence$$branch2$when$valp$funnext$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1494Long$arg0$calland$arg0$call$setsequence$$branch2$when$valp$funnext$classUdpControlSession;
        }
        State<Long> stateLiveLiteral = f1566State$Long$arg0$calland$arg0$call$setsequence$$branch2$when$valp$funnext$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-and$arg-0$call-$set-sequence$$branch-2$when$val-p$fun-next$class-UdpControlSession", Long.valueOf(f1494Long$arg0$calland$arg0$call$setsequence$$branch2$when$valp$funnext$classUdpControlSession));
            f1566State$Long$arg0$calland$arg0$call$setsequence$$branch2$when$valp$funnext$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-and$val-distance$fun-receive$class-UdpControlSession", offset = 4240)
    /* JADX INFO: renamed from: Long$arg-0$call-and$val-distance$fun-receive$class-UdpControlSession, reason: not valid java name */
    public final long m6741Long$arg0$calland$valdistance$funreceive$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1495Long$arg0$calland$valdistance$funreceive$classUdpControlSession;
        }
        State<Long> stateLiveLiteral = f1567State$Long$arg0$calland$valdistance$funreceive$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-and$val-distance$fun-receive$class-UdpControlSession", Long.valueOf(f1495Long$arg0$calland$valdistance$funreceive$classUdpControlSession));
            f1567State$Long$arg0$calland$valdistance$funreceive$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require$class-UdpControlSession", offset = 1263)
    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require$class-UdpControlSession, reason: not valid java name */
    public final long m6742Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1496Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$classUdpControlSession;
        }
        State<Long> stateLiveLiteral = f1568State$Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-rangeTo$$this$call-contains$branch$arg-0$call-require$class-UdpControlSession", Long.valueOf(f1496Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$classUdpControlSession));
            f1568State$Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-rangeTo$$this$call-contains$cond$arg-0$call-require$class-UdpControlSession", offset = 1230)
    /* JADX INFO: renamed from: Long$arg-0$call-rangeTo$$this$call-contains$cond$arg-0$call-require$class-UdpControlSession, reason: not valid java name */
    public final long m6743Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1497Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$classUdpControlSession;
        }
        State<Long> stateLiveLiteral = f1569State$Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-rangeTo$$this$call-contains$cond$arg-0$call-require$class-UdpControlSession", Long.valueOf(f1497Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$classUdpControlSession));
            f1569State$Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-1$call-EQEQ$$this$call-not$branch$cond$if-4$fun-receive$class-UdpControlSession", offset = 4507)
    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$$this$call-not$branch$cond$if-4$fun-receive$class-UdpControlSession, reason: not valid java name */
    public final long m6744Long$arg1$callEQEQ$$this$callnot$branch$cond$if4$funreceive$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1498Long$arg1$callEQEQ$$this$callnot$branch$cond$if4$funreceive$classUdpControlSession;
        }
        State<Long> stateLiveLiteral = f1570State$Long$arg1$callEQEQ$$this$callnot$branch$cond$if4$funreceive$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-1$call-EQEQ$$this$call-not$branch$cond$if-4$fun-receive$class-UdpControlSession", Long.valueOf(f1498Long$arg1$callEQEQ$$this$callnot$branch$cond$if4$funreceive$classUdpControlSession));
            f1570State$Long$arg1$callEQEQ$$this$callnot$branch$cond$if4$funreceive$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-1$call-EQEQ$$this$call-not$cond$if-1$fun-stop$class-UdpControlSession", offset = 1826)
    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$$this$call-not$cond$if-1$fun-stop$class-UdpControlSession, reason: not valid java name */
    public final long m6745Long$arg1$callEQEQ$$this$callnot$cond$if1$funstop$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1499Long$arg1$callEQEQ$$this$callnot$cond$if1$funstop$classUdpControlSession;
        }
        State<Long> stateLiveLiteral = f1571State$Long$arg1$callEQEQ$$this$callnot$cond$if1$funstop$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-1$call-EQEQ$$this$call-not$cond$if-1$fun-stop$class-UdpControlSession", Long.valueOf(f1499Long$arg1$callEQEQ$$this$callnot$cond$if1$funstop$classUdpControlSession));
            f1571State$Long$arg1$callEQEQ$$this$callnot$cond$if1$funstop$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-1$call-EQEQ$$this$call-not$else$cond$if$fun-receive$class-UdpControlSession", offset = 3718)
    /* JADX INFO: renamed from: Long$arg-1$call-EQEQ$$this$call-not$else$cond$if$fun-receive$class-UdpControlSession, reason: not valid java name */
    public final long m6746Long$arg1$callEQEQ$$this$callnot$else$cond$if$funreceive$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1500Long$arg1$callEQEQ$$this$callnot$else$cond$if$funreceive$classUdpControlSession;
        }
        State<Long> stateLiveLiteral = f1572State$Long$arg1$callEQEQ$$this$callnot$else$cond$if$funreceive$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-1$call-EQEQ$$this$call-not$else$cond$if$fun-receive$class-UdpControlSession", Long.valueOf(f1500Long$arg1$callEQEQ$$this$callnot$else$cond$if$funreceive$classUdpControlSession));
            f1572State$Long$arg1$callEQEQ$$this$callnot$else$cond$if$funreceive$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-1$call-packet$$$this$call-also$branch-1$when$val-p$fun-next$class-UdpControlSession", offset = 2874)
    /* JADX INFO: renamed from: Long$arg-1$call-packet$$$this$call-also$branch-1$when$val-p$fun-next$class-UdpControlSession, reason: not valid java name */
    public final long m6747Long$arg1$callpacket$$$this$callalso$branch1$when$valp$funnext$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1501Long$arg1$callpacket$$$this$callalso$branch1$when$valp$funnext$classUdpControlSession;
        }
        State<Long> stateLiveLiteral = f1573State$Long$arg1$callpacket$$$this$callalso$branch1$when$valp$funnext$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-1$call-packet$$$this$call-also$branch-1$when$val-p$fun-next$class-UdpControlSession", Long.valueOf(f1501Long$arg1$callpacket$$$this$callalso$branch1$when$valp$funnext$classUdpControlSession));
            f1573State$Long$arg1$callpacket$$$this$callalso$branch1$when$valp$funnext$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-1$call-packet$branch$when$val-p$fun-next$class-UdpControlSession", offset = 2814)
    /* JADX INFO: renamed from: Long$arg-1$call-packet$branch$when$val-p$fun-next$class-UdpControlSession, reason: not valid java name */
    public final long m6748Long$arg1$callpacket$branch$when$valp$funnext$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1502Long$arg1$callpacket$branch$when$valp$funnext$classUdpControlSession;
        }
        State<Long> stateLiveLiteral = f1574State$Long$arg1$callpacket$branch$when$valp$funnext$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-1$call-packet$branch$when$val-p$fun-next$class-UdpControlSession", Long.valueOf(f1502Long$arg1$callpacket$branch$when$valp$funnext$classUdpControlSession));
            f1574State$Long$arg1$callpacket$branch$when$valp$funnext$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$param-basis$fun-packet$class-UdpControlSession", offset = 4979)
    /* JADX INFO: renamed from: Long$param-basis$fun-packet$class-UdpControlSession, reason: not valid java name */
    public final long m6749Long$parambasis$funpacket$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1503Long$parambasis$funpacket$classUdpControlSession;
        }
        State<Long> stateLiveLiteral = f1575State$Long$parambasis$funpacket$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$param-basis$fun-packet$class-UdpControlSession", Long.valueOf(f1503Long$parambasis$funpacket$classUdpControlSession));
            f1575State$Long$parambasis$funpacket$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "String$0$str$fun-toString$class-Sent$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: String$0$str$fun-toString$class-Sent$class-UdpControlSession, reason: not valid java name */
    public final String m6750String$0$str$funtoString$classSent$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1605String$0$str$funtoString$classSent$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1576State$String$0$str$funtoString$classSent$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$fun-toString$class-Sent$class-UdpControlSession", f1605String$0$str$funtoString$classSent$classUdpControlSession);
            f1576State$String$0$str$funtoString$classSent$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$fun-toString$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: String$0$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final String m6751String$0$str$funtoString$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1606String$0$str$funtoString$classSnapshot$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1577State$String$0$str$funtoString$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$fun-toString$class-Snapshot$class-UdpControlSession", f1606String$0$str$funtoString$classSnapshot$classUdpControlSession);
            f1577State$String$0$str$funtoString$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$1$str$fun-toString$class-Sent$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: String$1$str$fun-toString$class-Sent$class-UdpControlSession, reason: not valid java name */
    public final String m6752String$1$str$funtoString$classSent$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1607String$1$str$funtoString$classSent$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1578State$String$1$str$funtoString$classSent$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$1$str$fun-toString$class-Sent$class-UdpControlSession", f1607String$1$str$funtoString$classSent$classUdpControlSession);
            f1578State$String$1$str$funtoString$classSent$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$1$str$fun-toString$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: String$1$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final String m6753String$1$str$funtoString$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1608String$1$str$funtoString$classSnapshot$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1579State$String$1$str$funtoString$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$1$str$fun-toString$class-Snapshot$class-UdpControlSession", f1608String$1$str$funtoString$classSnapshot$classUdpControlSession);
            f1579State$String$1$str$funtoString$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$10$str$fun-toString$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: String$10$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final String m6754String$10$str$funtoString$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1609String$10$str$funtoString$classSnapshot$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1580State$String$10$str$funtoString$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$10$str$fun-toString$class-Snapshot$class-UdpControlSession", f1609String$10$str$funtoString$classSnapshot$classUdpControlSession);
            f1580State$String$10$str$funtoString$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$12$str$fun-toString$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: String$12$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final String m6755String$12$str$funtoString$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1610String$12$str$funtoString$classSnapshot$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1581State$String$12$str$funtoString$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$12$str$fun-toString$class-Snapshot$class-UdpControlSession", f1610String$12$str$funtoString$classSnapshot$classUdpControlSession);
            f1581State$String$12$str$funtoString$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$13$str$fun-toString$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: String$13$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final String m6756String$13$str$funtoString$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1611String$13$str$funtoString$classSnapshot$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1582State$String$13$str$funtoString$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$13$str$fun-toString$class-Snapshot$class-UdpControlSession", f1611String$13$str$funtoString$classSnapshot$classUdpControlSession);
            f1582State$String$13$str$funtoString$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$15$str$fun-toString$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: String$15$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final String m6757String$15$str$funtoString$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1612String$15$str$funtoString$classSnapshot$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1583State$String$15$str$funtoString$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$15$str$fun-toString$class-Snapshot$class-UdpControlSession", f1612String$15$str$funtoString$classSnapshot$classUdpControlSession);
            f1583State$String$15$str$funtoString$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$16$str$fun-toString$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: String$16$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final String m6758String$16$str$funtoString$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1613String$16$str$funtoString$classSnapshot$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1584State$String$16$str$funtoString$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$16$str$fun-toString$class-Snapshot$class-UdpControlSession", f1613String$16$str$funtoString$classSnapshot$classUdpControlSession);
            f1584State$String$16$str$funtoString$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$18$str$fun-toString$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: String$18$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final String m6759String$18$str$funtoString$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1614String$18$str$funtoString$classSnapshot$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1585State$String$18$str$funtoString$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$18$str$fun-toString$class-Snapshot$class-UdpControlSession", f1614String$18$str$funtoString$classSnapshot$classUdpControlSession);
            f1585State$String$18$str$funtoString$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$19$str$fun-toString$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: String$19$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final String m6760String$19$str$funtoString$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1615String$19$str$funtoString$classSnapshot$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1586State$String$19$str$funtoString$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$19$str$fun-toString$class-Snapshot$class-UdpControlSession", f1615String$19$str$funtoString$classSnapshot$classUdpControlSession);
            f1586State$String$19$str$funtoString$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$21$str$fun-toString$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: String$21$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final String m6761String$21$str$funtoString$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1616String$21$str$funtoString$classSnapshot$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1587State$String$21$str$funtoString$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$21$str$fun-toString$class-Snapshot$class-UdpControlSession", f1616String$21$str$funtoString$classSnapshot$classUdpControlSession);
            f1587State$String$21$str$funtoString$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$22$str$fun-toString$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: String$22$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final String m6762String$22$str$funtoString$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1617String$22$str$funtoString$classSnapshot$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1588State$String$22$str$funtoString$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$22$str$fun-toString$class-Snapshot$class-UdpControlSession", f1617String$22$str$funtoString$classSnapshot$classUdpControlSession);
            f1588State$String$22$str$funtoString$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$24$str$fun-toString$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: String$24$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final String m6763String$24$str$funtoString$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1618String$24$str$funtoString$classSnapshot$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1589State$String$24$str$funtoString$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$24$str$fun-toString$class-Snapshot$class-UdpControlSession", f1618String$24$str$funtoString$classSnapshot$classUdpControlSession);
            f1589State$String$24$str$funtoString$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$25$str$fun-toString$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: String$25$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final String m6764String$25$str$funtoString$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1619String$25$str$funtoString$classSnapshot$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1590State$String$25$str$funtoString$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$25$str$fun-toString$class-Snapshot$class-UdpControlSession", f1619String$25$str$funtoString$classSnapshot$classUdpControlSession);
            f1590State$String$25$str$funtoString$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$27$str$fun-toString$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: String$27$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final String m6765String$27$str$funtoString$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1620String$27$str$funtoString$classSnapshot$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1591State$String$27$str$funtoString$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$27$str$fun-toString$class-Snapshot$class-UdpControlSession", f1620String$27$str$funtoString$classSnapshot$classUdpControlSession);
            f1591State$String$27$str$funtoString$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$3$str$fun-toString$class-Sent$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: String$3$str$fun-toString$class-Sent$class-UdpControlSession, reason: not valid java name */
    public final String m6766String$3$str$funtoString$classSent$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1621String$3$str$funtoString$classSent$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1592State$String$3$str$funtoString$classSent$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$3$str$fun-toString$class-Sent$class-UdpControlSession", f1621String$3$str$funtoString$classSent$classUdpControlSession);
            f1592State$String$3$str$funtoString$classSent$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$3$str$fun-toString$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: String$3$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final String m6767String$3$str$funtoString$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1622String$3$str$funtoString$classSnapshot$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1593State$String$3$str$funtoString$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$3$str$fun-toString$class-Snapshot$class-UdpControlSession", f1622String$3$str$funtoString$classSnapshot$classUdpControlSession);
            f1593State$String$3$str$funtoString$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$4$str$fun-toString$class-Sent$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: String$4$str$fun-toString$class-Sent$class-UdpControlSession, reason: not valid java name */
    public final String m6768String$4$str$funtoString$classSent$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1623String$4$str$funtoString$classSent$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1594State$String$4$str$funtoString$classSent$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$4$str$fun-toString$class-Sent$class-UdpControlSession", f1623String$4$str$funtoString$classSent$classUdpControlSession);
            f1594State$String$4$str$funtoString$classSent$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$4$str$fun-toString$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: String$4$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final String m6769String$4$str$funtoString$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1624String$4$str$funtoString$classSnapshot$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1595State$String$4$str$funtoString$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$4$str$fun-toString$class-Snapshot$class-UdpControlSession", f1624String$4$str$funtoString$classSnapshot$classUdpControlSession);
            f1595State$String$4$str$funtoString$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$6$str$fun-toString$class-Sent$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: String$6$str$fun-toString$class-Sent$class-UdpControlSession, reason: not valid java name */
    public final String m6770String$6$str$funtoString$classSent$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1625String$6$str$funtoString$classSent$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1596State$String$6$str$funtoString$classSent$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$6$str$fun-toString$class-Sent$class-UdpControlSession", f1625String$6$str$funtoString$classSent$classUdpControlSession);
            f1596State$String$6$str$funtoString$classSent$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$6$str$fun-toString$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: String$6$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final String m6771String$6$str$funtoString$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1626String$6$str$funtoString$classSnapshot$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1597State$String$6$str$funtoString$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$6$str$fun-toString$class-Snapshot$class-UdpControlSession", f1626String$6$str$funtoString$classSnapshot$classUdpControlSession);
            f1597State$String$6$str$funtoString$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$7$str$fun-toString$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: String$7$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final String m6772String$7$str$funtoString$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1627String$7$str$funtoString$classSnapshot$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1598State$String$7$str$funtoString$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$7$str$fun-toString$class-Snapshot$class-UdpControlSession", f1627String$7$str$funtoString$classSnapshot$classUdpControlSession);
            f1598State$String$7$str$funtoString$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$9$str$fun-toString$class-Snapshot$class-UdpControlSession", offset = -2)
    /* JADX INFO: renamed from: String$9$str$fun-toString$class-Snapshot$class-UdpControlSession, reason: not valid java name */
    public final String m6773String$9$str$funtoString$classSnapshot$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1628String$9$str$funtoString$classSnapshot$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1599State$String$9$str$funtoString$classSnapshot$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$9$str$fun-toString$class-Snapshot$class-UdpControlSession", f1628String$9$str$funtoString$classSnapshot$classUdpControlSession);
            f1599State$String$9$str$funtoString$classSnapshot$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$set-reason$$branch$if-5$fun-receive$class-UdpControlSession", offset = 4856)
    /* JADX INFO: renamed from: String$arg-0$call-$set-reason$$branch$if-5$fun-receive$class-UdpControlSession, reason: not valid java name */
    public final String m6774String$arg0$call$setreason$$branch$if5$funreceive$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1629String$arg0$call$setreason$$branch$if5$funreceive$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1600State$String$arg0$call$setreason$$branch$if5$funreceive$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$set-reason$$branch$if-5$fun-receive$class-UdpControlSession", f1629String$arg0$call$setreason$$branch$if5$funreceive$classUdpControlSession);
            f1600State$String$arg0$call$setreason$$branch$if5$funreceive$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-stop$branch$if$branch$when$fun-expire$class-UdpControlSession", offset = 2175)
    /* JADX INFO: renamed from: String$arg-0$call-stop$branch$if$branch$when$fun-expire$class-UdpControlSession, reason: not valid java name */
    public final String m6775String$arg0$callstop$branch$if$branch$when$funexpire$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1630String$arg0$callstop$branch$if$branch$when$funexpire$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1601State$String$arg0$callstop$branch$if$branch$when$funexpire$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-stop$branch$if$branch$when$fun-expire$class-UdpControlSession", f1630String$arg0$callstop$branch$if$branch$when$funexpire$classUdpControlSession);
            f1601State$String$arg0$callstop$branch$if$branch$when$funexpire$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-stop$branch$if$branch-1$when$fun-expire$class-UdpControlSession", offset = 2267)
    /* JADX INFO: renamed from: String$arg-0$call-stop$branch$if$branch-1$when$fun-expire$class-UdpControlSession, reason: not valid java name */
    public final String m6776String$arg0$callstop$branch$if$branch1$when$funexpire$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1631String$arg0$callstop$branch$if$branch1$when$funexpire$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1602State$String$arg0$callstop$branch$if$branch1$when$funexpire$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-stop$branch$if$branch-1$when$fun-expire$class-UdpControlSession", f1631String$arg0$callstop$branch$if$branch1$when$funexpire$classUdpControlSession);
            f1602State$String$arg0$callstop$branch$if$branch1$when$funexpire$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-stop$branch$if$branch-2$when$fun-expire$class-UdpControlSession", offset = 2345)
    /* JADX INFO: renamed from: String$arg-0$call-stop$branch$if$branch-2$when$fun-expire$class-UdpControlSession, reason: not valid java name */
    public final String m6777String$arg0$callstop$branch$if$branch2$when$funexpire$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1632String$arg0$callstop$branch$if$branch2$when$funexpire$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1603State$String$arg0$callstop$branch$if$branch2$when$funexpire$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-stop$branch$if$branch-2$when$fun-expire$class-UdpControlSession", f1632String$arg0$callstop$branch$if$branch2$when$funexpire$classUdpControlSession);
            f1603State$String$arg0$callstop$branch$if$branch2$when$funexpire$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$param-reason$fun-stop$class-UdpControlSession", offset = 1751)
    /* JADX INFO: renamed from: String$param-reason$fun-stop$class-UdpControlSession, reason: not valid java name */
    public final String m6778String$paramreason$funstop$classUdpControlSession() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1633String$paramreason$funstop$classUdpControlSession;
        }
        State<String> stateLiveLiteral = f1604State$String$paramreason$funstop$classUdpControlSession;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$param-reason$fun-stop$class-UdpControlSession", f1633String$paramreason$funstop$classUdpControlSession);
            f1604State$String$paramreason$funstop$classUdpControlSession = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
