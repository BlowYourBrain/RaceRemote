package vea.raceremote.control;

import java.util.Iterator;
import kotlin.Metadata;
import kotlin.collections.IntIterator;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

/* JADX INFO: compiled from: UdpControlPacket.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0002\b\u001b\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\b\u0087\b\u0018\u0000 (2\u00020\u0001:\u0001(BG\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\u0003\u0012\u0006\u0010\t\u001a\u00020\u0003\u0012\u0006\u0010\n\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u000b\u001a\u00020\u0005¢\u0006\u0002\u0010\fJ\t\u0010\u0017\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0018\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0019\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001a\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001b\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001c\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001d\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001e\u001a\u00020\u0005HÆ\u0003JY\u0010\u001f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00052\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\u00032\b\b\u0002\u0010\n\u001a\u00020\u00052\b\b\u0002\u0010\u000b\u001a\u00020\u0005HÆ\u0001J\u0006\u0010 \u001a\u00020!J\u0013\u0010\"\u001a\u00020#2\b\u0010$\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010%\u001a\u00020\u0003HÖ\u0001J\t\u0010&\u001a\u00020'HÖ\u0001R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u000b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000eR\u0011\u0010\n\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000eR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u000eR\u0011\u0010\t\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0012R\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0012R\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u000e¨\u0006)"}, d2 = {"Lvea/raceremote/control/UdpControlPacket;", "", "kind", "", "attempt", "", "token", "sequence", "throttle", "steering", "chipId", "basis", "(IJJJIIJJ)V", "getAttempt", "()J", "getBasis", "getChipId", "getKind", "()I", "getSequence", "getSteering", "getThrottle", "getToken", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "copy", "encode", "", "equals", "", "other", "hashCode", "toString", "", "Companion", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final /* data */ class UdpControlPacket {
    public static final int ACK = 129;
    public static final int ARM = 1;
    public static final int DRIVE = 2;
    public static final int HELLO = 128;
    public static final int OPEN = 0;
    public static final int PORT = 3334;
    public static final int SIZE = 32;
    public static final int STOP = 3;
    private final long attempt;
    private final long basis;
    private final long chipId;
    private final int kind;
    private final long sequence;
    private final int steering;
    private final int throttle;
    private final long token;

    /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion();
    public static final int $stable = LiveLiterals$UdpControlPacketKt.INSTANCE.m6650Int$classUdpControlPacket();

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final int getKind() {
        return this.kind;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final long getAttempt() {
        return this.attempt;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final long getToken() {
        return this.token;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final long getSequence() {
        return this.sequence;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final int getThrottle() {
        return this.throttle;
    }

    /* JADX INFO: renamed from: component6, reason: from getter */
    public final int getSteering() {
        return this.steering;
    }

    /* JADX INFO: renamed from: component7, reason: from getter */
    public final long getChipId() {
        return this.chipId;
    }

    /* JADX INFO: renamed from: component8, reason: from getter */
    public final long getBasis() {
        return this.basis;
    }

    public final UdpControlPacket copy(int kind, long attempt, long token, long sequence, int throttle, int steering, long chipId, long basis) {
        return new UdpControlPacket(kind, attempt, token, sequence, throttle, steering, chipId, basis);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return LiveLiterals$UdpControlPacketKt.INSTANCE.m6574Boolean$branch$when$funequals$classUdpControlPacket();
        }
        if (!(other instanceof UdpControlPacket)) {
            return LiveLiterals$UdpControlPacketKt.INSTANCE.m6575Boolean$branch$when1$funequals$classUdpControlPacket();
        }
        UdpControlPacket udpControlPacket = (UdpControlPacket) other;
        if (this.kind != udpControlPacket.kind) {
            return LiveLiterals$UdpControlPacketKt.INSTANCE.m6576Boolean$branch$when2$funequals$classUdpControlPacket();
        }
        if (this.attempt != udpControlPacket.attempt) {
            return LiveLiterals$UdpControlPacketKt.INSTANCE.m6577Boolean$branch$when3$funequals$classUdpControlPacket();
        }
        if (this.token != udpControlPacket.token) {
            return LiveLiterals$UdpControlPacketKt.INSTANCE.m6578Boolean$branch$when4$funequals$classUdpControlPacket();
        }
        if (this.sequence != udpControlPacket.sequence) {
            return LiveLiterals$UdpControlPacketKt.INSTANCE.m6579Boolean$branch$when5$funequals$classUdpControlPacket();
        }
        if (this.throttle != udpControlPacket.throttle) {
            return LiveLiterals$UdpControlPacketKt.INSTANCE.m6580Boolean$branch$when6$funequals$classUdpControlPacket();
        }
        if (this.steering != udpControlPacket.steering) {
            return LiveLiterals$UdpControlPacketKt.INSTANCE.m6581Boolean$branch$when7$funequals$classUdpControlPacket();
        }
        if (this.chipId != udpControlPacket.chipId) {
            return LiveLiterals$UdpControlPacketKt.INSTANCE.m6582Boolean$branch$when8$funequals$classUdpControlPacket();
        }
        return this.basis != udpControlPacket.basis ? LiveLiterals$UdpControlPacketKt.INSTANCE.m6583Boolean$branch$when9$funequals$classUdpControlPacket() : LiveLiterals$UdpControlPacketKt.INSTANCE.m6584Boolean$funequals$classUdpControlPacket();
    }

    public int hashCode() {
        return (LiveLiterals$UdpControlPacketKt.INSTANCE.m6635Int$arg0$calltimes$$this$callplus$setresult6$funhashCode$classUdpControlPacket() * ((LiveLiterals$UdpControlPacketKt.INSTANCE.m6634Int$arg0$calltimes$$this$callplus$setresult5$funhashCode$classUdpControlPacket() * ((LiveLiterals$UdpControlPacketKt.INSTANCE.m6633Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classUdpControlPacket() * ((LiveLiterals$UdpControlPacketKt.INSTANCE.m6632Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classUdpControlPacket() * ((LiveLiterals$UdpControlPacketKt.INSTANCE.m6631Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classUdpControlPacket() * ((LiveLiterals$UdpControlPacketKt.INSTANCE.m6630Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classUdpControlPacket() * ((LiveLiterals$UdpControlPacketKt.INSTANCE.m6629Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classUdpControlPacket() * Integer.hashCode(this.kind)) + Long.hashCode(this.attempt))) + Long.hashCode(this.token))) + Long.hashCode(this.sequence))) + Integer.hashCode(this.throttle))) + Integer.hashCode(this.steering))) + Long.hashCode(this.chipId))) + Long.hashCode(this.basis);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(LiveLiterals$UdpControlPacketKt.INSTANCE.m6661String$0$str$funtoString$classUdpControlPacket()).append(LiveLiterals$UdpControlPacketKt.INSTANCE.m6662String$1$str$funtoString$classUdpControlPacket()).append(this.kind).append(LiveLiterals$UdpControlPacketKt.INSTANCE.m6673String$3$str$funtoString$classUdpControlPacket()).append(LiveLiterals$UdpControlPacketKt.INSTANCE.m6674String$4$str$funtoString$classUdpControlPacket()).append(this.attempt).append(LiveLiterals$UdpControlPacketKt.INSTANCE.m6675String$6$str$funtoString$classUdpControlPacket()).append(LiveLiterals$UdpControlPacketKt.INSTANCE.m6676String$7$str$funtoString$classUdpControlPacket()).append(this.token).append(LiveLiterals$UdpControlPacketKt.INSTANCE.m6677String$9$str$funtoString$classUdpControlPacket()).append(LiveLiterals$UdpControlPacketKt.INSTANCE.m6663String$10$str$funtoString$classUdpControlPacket()).append(this.sequence).append(LiveLiterals$UdpControlPacketKt.INSTANCE.m6664String$12$str$funtoString$classUdpControlPacket()).append(LiveLiterals$UdpControlPacketKt.INSTANCE.m6665String$13$str$funtoString$classUdpControlPacket()).append(this.throttle).append(LiveLiterals$UdpControlPacketKt.INSTANCE.m6666String$15$str$funtoString$classUdpControlPacket()).append(LiveLiterals$UdpControlPacketKt.INSTANCE.m6667String$16$str$funtoString$classUdpControlPacket()).append(this.steering).append(LiveLiterals$UdpControlPacketKt.INSTANCE.m6668String$18$str$funtoString$classUdpControlPacket()).append(LiveLiterals$UdpControlPacketKt.INSTANCE.m6669String$19$str$funtoString$classUdpControlPacket()).append(this.chipId).append(LiveLiterals$UdpControlPacketKt.INSTANCE.m6670String$21$str$funtoString$classUdpControlPacket()).append(LiveLiterals$UdpControlPacketKt.INSTANCE.m6671String$22$str$funtoString$classUdpControlPacket());
        sb.append(this.basis).append(LiveLiterals$UdpControlPacketKt.INSTANCE.m6672String$24$str$funtoString$classUdpControlPacket());
        return sb.toString();
    }

    public UdpControlPacket(int kind, long attempt, long token, long sequence, int throttle, int steering, long chipId, long basis) {
        this.kind = kind;
        this.attempt = attempt;
        this.token = token;
        this.sequence = sequence;
        this.throttle = throttle;
        this.steering = steering;
        this.chipId = chipId;
        this.basis = basis;
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public /* synthetic */ UdpControlPacket(int i, long j, long j2, long j3, int i2, int i3, long j4, long j5, int i4, DefaultConstructorMarker defaultConstructorMarker) {
        long jM6660Long$parambasis$classUdpControlPacket;
        if ((i4 & 128) == 0) {
            jM6660Long$parambasis$classUdpControlPacket = j5;
        } else {
            jM6660Long$parambasis$classUdpControlPacket = LiveLiterals$UdpControlPacketKt.INSTANCE.m6660Long$parambasis$classUdpControlPacket();
        }
        this(i, j, j2, j3, i2, i3, j4, jM6660Long$parambasis$classUdpControlPacket);
    }

    public final int getKind() {
        return this.kind;
    }

    public final long getAttempt() {
        return this.attempt;
    }

    public final long getToken() {
        return this.token;
    }

    public final long getSequence() {
        return this.sequence;
    }

    public final int getThrottle() {
        return this.throttle;
    }

    public final int getSteering() {
        return this.steering;
    }

    public final long getChipId() {
        return this.chipId;
    }

    public final long getBasis() {
        return this.basis;
    }

    /* JADX WARN: Code duplicated, block: B:30:0x006f  */
    /* JADX WARN: Code duplicated, block: B:53:0x00c0  */
    public final byte[] encode() {
        boolean z;
        boolean z2;
        int iM6599Int$$this$callrangeTo$$this$callcontains$cond$cond$cond$arg0$callrequire$funencode$classUdpControlPacket = LiveLiterals$UdpControlPacketKt.INSTANCE.m6599Int$$this$callrangeTo$$this$callcontains$cond$cond$cond$arg0$callrequire$funencode$classUdpControlPacket();
        int iM6624Int$arg0$callrangeTo$$this$callcontains$cond$cond$cond$arg0$callrequire$funencode$classUdpControlPacket = LiveLiterals$UdpControlPacketKt.INSTANCE.m6624Int$arg0$callrangeTo$$this$callcontains$cond$cond$cond$arg0$callrequire$funencode$classUdpControlPacket();
        int i = this.kind;
        if (iM6599Int$$this$callrangeTo$$this$callcontains$cond$cond$cond$arg0$callrequire$funencode$classUdpControlPacket <= i && i <= iM6624Int$arg0$callrangeTo$$this$callcontains$cond$cond$cond$arg0$callrequire$funencode$classUdpControlPacket) {
            int iM6594Int$$this$callrangeTo$$this$callcontains$branch$cond$cond$arg0$callrequire$funencode$classUdpControlPacket = LiveLiterals$UdpControlPacketKt.INSTANCE.m6594Int$$this$callrangeTo$$this$callcontains$branch$cond$cond$arg0$callrequire$funencode$classUdpControlPacket();
            long jM6657Long$arg0$callrangeTo$$this$callcontains$branch$cond$cond$arg0$callrequire$funencode$classUdpControlPacket = LiveLiterals$UdpControlPacketKt.INSTANCE.m6657Long$arg0$callrangeTo$$this$callcontains$branch$cond$cond$arg0$callrequire$funencode$classUdpControlPacket();
            long j = this.attempt;
            if (((long) iM6594Int$$this$callrangeTo$$this$callcontains$branch$cond$cond$arg0$callrequire$funencode$classUdpControlPacket) <= j && j <= jM6657Long$arg0$callrangeTo$$this$callcontains$branch$cond$cond$arg0$callrequire$funencode$classUdpControlPacket) {
                int iM6592Int$$this$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire$funencode$classUdpControlPacket = LiveLiterals$UdpControlPacketKt.INSTANCE.m6592Int$$this$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire$funencode$classUdpControlPacket();
                long jM6656Long$arg0$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire$funencode$classUdpControlPacket = LiveLiterals$UdpControlPacketKt.INSTANCE.m6656Long$arg0$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire$funencode$classUdpControlPacket();
                long j2 = this.token;
                if (((long) iM6592Int$$this$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire$funencode$classUdpControlPacket) <= j2 && j2 <= jM6656Long$arg0$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire$funencode$classUdpControlPacket) {
                    int iM6590Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funencode$classUdpControlPacket = LiveLiterals$UdpControlPacketKt.INSTANCE.m6590Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funencode$classUdpControlPacket();
                    long jM6654Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funencode$classUdpControlPacket = LiveLiterals$UdpControlPacketKt.INSTANCE.m6654Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funencode$classUdpControlPacket();
                    long j3 = this.sequence;
                    if (((long) iM6590Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funencode$classUdpControlPacket) <= j3 && j3 <= jM6654Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funencode$classUdpControlPacket) {
                        z = true;
                    } else {
                        z = false;
                    }
                } else {
                    z = false;
                }
            } else {
                z = false;
            }
        } else {
            z = false;
        }
        if (!z) {
            throw new IllegalArgumentException("Failed requirement.".toString());
        }
        int iM6598Int$$this$callrangeTo$$this$callcontains$cond$cond$arg0$callrequire1$funencode$classUdpControlPacket = LiveLiterals$UdpControlPacketKt.INSTANCE.m6598Int$$this$callrangeTo$$this$callcontains$cond$cond$arg0$callrequire1$funencode$classUdpControlPacket();
        int iM6623Int$arg0$callrangeTo$$this$callcontains$cond$cond$arg0$callrequire1$funencode$classUdpControlPacket = LiveLiterals$UdpControlPacketKt.INSTANCE.m6623Int$arg0$callrangeTo$$this$callcontains$cond$cond$arg0$callrequire1$funencode$classUdpControlPacket();
        int i2 = this.throttle;
        if (iM6598Int$$this$callrangeTo$$this$callcontains$cond$cond$arg0$callrequire1$funencode$classUdpControlPacket <= i2 && i2 <= iM6623Int$arg0$callrangeTo$$this$callcontains$cond$cond$arg0$callrequire1$funencode$classUdpControlPacket) {
            int iM6593Int$$this$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire1$funencode$classUdpControlPacket = LiveLiterals$UdpControlPacketKt.INSTANCE.m6593Int$$this$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire1$funencode$classUdpControlPacket();
            int iM6620Int$arg0$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire1$funencode$classUdpControlPacket = LiveLiterals$UdpControlPacketKt.INSTANCE.m6620Int$arg0$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire1$funencode$classUdpControlPacket();
            int i3 = this.steering;
            if (iM6593Int$$this$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire1$funencode$classUdpControlPacket <= i3 && i3 <= iM6620Int$arg0$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire1$funencode$classUdpControlPacket) {
                int iM6591Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classUdpControlPacket = LiveLiterals$UdpControlPacketKt.INSTANCE.m6591Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classUdpControlPacket();
                long jM6655Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classUdpControlPacket = LiveLiterals$UdpControlPacketKt.INSTANCE.m6655Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classUdpControlPacket();
                long j4 = this.chipId;
                if (((long) iM6591Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classUdpControlPacket) <= j4 && j4 <= jM6655Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classUdpControlPacket) {
                    z2 = true;
                } else {
                    z2 = false;
                }
            } else {
                z2 = false;
            }
        } else {
            z2 = false;
        }
        if (!z2) {
            throw new IllegalArgumentException("Failed requirement.".toString());
        }
        int iM6589Int$$this$callrangeTo$$this$callcontains$arg0$callrequire2$funencode$classUdpControlPacket = LiveLiterals$UdpControlPacketKt.INSTANCE.m6589Int$$this$callrangeTo$$this$callcontains$arg0$callrequire2$funencode$classUdpControlPacket();
        long jM6653Long$arg0$callrangeTo$$this$callcontains$arg0$callrequire2$funencode$classUdpControlPacket = LiveLiterals$UdpControlPacketKt.INSTANCE.m6653Long$arg0$callrangeTo$$this$callcontains$arg0$callrequire2$funencode$classUdpControlPacket();
        long j5 = this.basis;
        if (!(((long) iM6589Int$$this$callrangeTo$$this$callcontains$arg0$callrequire2$funencode$classUdpControlPacket) <= j5 && j5 <= jM6653Long$arg0$callrangeTo$$this$callcontains$arg0$callrequire2$funencode$classUdpControlPacket)) {
            throw new IllegalArgumentException("Failed requirement.".toString());
        }
        byte[] bytes = new byte[32];
        bytes[LiveLiterals$UdpControlPacketKt.INSTANCE.m6625Int$arg0$callset$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()] = LiveLiterals$UdpControlPacketKt.INSTANCE.m6585Byte$arg1$callset$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket();
        bytes[LiveLiterals$UdpControlPacketKt.INSTANCE.m6626Int$arg0$callset1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()] = LiveLiterals$UdpControlPacketKt.INSTANCE.m6586Byte$arg1$callset1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket();
        bytes[LiveLiterals$UdpControlPacketKt.INSTANCE.m6627Int$arg0$callset2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()] = LiveLiterals$UdpControlPacketKt.INSTANCE.m6587Byte$arg1$callset2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket();
        bytes[LiveLiterals$UdpControlPacketKt.INSTANCE.m6628Int$arg0$callset3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()] = (byte) this.kind;
        encode$lambda$1$put(bytes, LiveLiterals$UdpControlPacketKt.INSTANCE.m6613Int$arg0$callput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket(), LiveLiterals$UdpControlPacketKt.INSTANCE.m6643Int$arg1$callput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket(), this.attempt);
        encode$lambda$1$put(bytes, LiveLiterals$UdpControlPacketKt.INSTANCE.m6614Int$arg0$callput1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket(), LiveLiterals$UdpControlPacketKt.INSTANCE.m6644Int$arg1$callput1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket(), this.token);
        encode$lambda$1$put(bytes, LiveLiterals$UdpControlPacketKt.INSTANCE.m6615Int$arg0$callput2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket(), LiveLiterals$UdpControlPacketKt.INSTANCE.m6645Int$arg1$callput2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket(), this.sequence);
        encode$lambda$1$put(bytes, LiveLiterals$UdpControlPacketKt.INSTANCE.m6616Int$arg0$callput3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket(), LiveLiterals$UdpControlPacketKt.INSTANCE.m6646Int$arg1$callput3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket(), this.throttle);
        encode$lambda$1$put(bytes, LiveLiterals$UdpControlPacketKt.INSTANCE.m6617Int$arg0$callput4$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket(), LiveLiterals$UdpControlPacketKt.INSTANCE.m6647Int$arg1$callput4$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket(), this.steering);
        encode$lambda$1$put(bytes, LiveLiterals$UdpControlPacketKt.INSTANCE.m6618Int$arg0$callput5$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket(), LiveLiterals$UdpControlPacketKt.INSTANCE.m6648Int$arg1$callput5$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket(), this.basis);
        encode$lambda$1$put(bytes, LiveLiterals$UdpControlPacketKt.INSTANCE.m6619Int$arg0$callput6$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket(), LiveLiterals$UdpControlPacketKt.INSTANCE.m6649Int$arg1$callput6$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket(), this.chipId);
        return bytes;
    }

    private static final void encode$lambda$1$put(byte[] $bytes, int offset, int size, long value) {
        for (int i = 0; i < size; i++) {
            int it = i;
            $bytes[offset + it] = (byte) (value >>> (LiveLiterals$UdpControlPacketKt.INSTANCE.m6601Int$$this$calltimes$arg0$callushr$$this$calltoByte$arg1$callset$fun$anonymous$$arg1$callrepeat$funput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket() * it));
        }
    }

    /* JADX INFO: compiled from: UdpControlPacket.kt */
    @Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0012\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\f\u001a\u0004\u0018\u00010\r2\u0006\u0010\u000e\u001a\u00020\u000fR\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0010"}, d2 = {"Lvea/raceremote/control/UdpControlPacket$Companion;", "", "()V", "ACK", "", "ARM", "DRIVE", "HELLO", "OPEN", "PORT", "SIZE", "STOP", "decode", "Lvea/raceremote/control/UdpControlPacket;", "bytes", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
        }

        public final UdpControlPacket decode(byte[] bytes) {
            Intrinsics.checkNotNullParameter(bytes, "bytes");
            if (bytes.length == 32) {
                boolean z = false;
                if (bytes[0] == 82 && bytes[1] == 85 && bytes[LiveLiterals$UdpControlPacketKt.INSTANCE.m6605Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classUdpControlPacket()] == ((byte) LiveLiterals$UdpControlPacketKt.INSTANCE.m6602Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classUdpControlPacket())) {
                    UdpControlPacket p = new UdpControlPacket(bytes[LiveLiterals$UdpControlPacketKt.INSTANCE.m6604Int$arg0$callget$$this$calltoInt$$this$calland$arg0$call$init$$valp$fundecode$classCompanion$classUdpControlPacket()] & LiveLiterals$UdpControlPacketKt.INSTANCE.m6603Int$arg0$calland$arg0$call$init$$valp$fundecode$classCompanion$classUdpControlPacket(), decode$get(bytes, LiveLiterals$UdpControlPacketKt.INSTANCE.m6608Int$arg0$callget$arg1$call$init$$valp$fundecode$classCompanion$classUdpControlPacket(), LiveLiterals$UdpControlPacketKt.INSTANCE.m6638Int$arg1$callget$arg1$call$init$$valp$fundecode$classCompanion$classUdpControlPacket()), decode$get(bytes, LiveLiterals$UdpControlPacketKt.INSTANCE.m6609Int$arg0$callget$arg2$call$init$$valp$fundecode$classCompanion$classUdpControlPacket(), LiveLiterals$UdpControlPacketKt.INSTANCE.m6639Int$arg1$callget$arg2$call$init$$valp$fundecode$classCompanion$classUdpControlPacket()), decode$get(bytes, LiveLiterals$UdpControlPacketKt.INSTANCE.m6610Int$arg0$callget$arg3$call$init$$valp$fundecode$classCompanion$classUdpControlPacket(), LiveLiterals$UdpControlPacketKt.INSTANCE.m6640Int$arg1$callget$arg3$call$init$$valp$fundecode$classCompanion$classUdpControlPacket()), (short) decode$get(bytes, LiveLiterals$UdpControlPacketKt.INSTANCE.m6606Int$arg0$callget$$this$calltoShort$$this$calltoInt$arg4$call$init$$valp$fundecode$classCompanion$classUdpControlPacket(), LiveLiterals$UdpControlPacketKt.INSTANCE.m6636Int$arg1$callget$$this$calltoShort$$this$calltoInt$arg4$call$init$$valp$fundecode$classCompanion$classUdpControlPacket()), (short) decode$get(bytes, LiveLiterals$UdpControlPacketKt.INSTANCE.m6607Int$arg0$callget$$this$calltoShort$$this$calltoInt$arg5$call$init$$valp$fundecode$classCompanion$classUdpControlPacket(), LiveLiterals$UdpControlPacketKt.INSTANCE.m6637Int$arg1$callget$$this$calltoShort$$this$calltoInt$arg5$call$init$$valp$fundecode$classCompanion$classUdpControlPacket()), decode$get(bytes, LiveLiterals$UdpControlPacketKt.INSTANCE.m6611Int$arg0$callget$arg6$call$init$$valp$fundecode$classCompanion$classUdpControlPacket(), LiveLiterals$UdpControlPacketKt.INSTANCE.m6641Int$arg1$callget$arg6$call$init$$valp$fundecode$classCompanion$classUdpControlPacket()), decode$get(bytes, LiveLiterals$UdpControlPacketKt.INSTANCE.m6612Int$arg0$callget$arg7$call$init$$valp$fundecode$classCompanion$classUdpControlPacket(), LiveLiterals$UdpControlPacketKt.INSTANCE.m6642Int$arg1$callget$arg7$call$init$$valp$fundecode$classCompanion$classUdpControlPacket()));
                    if (p.getAttempt() != LiveLiterals$UdpControlPacketKt.INSTANCE.m6659Long$arg1$callEQEQ$$this$callnot$cond$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket()) {
                        int iM6595Int$$this$callrangeTo$$this$callcontains$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket = LiveLiterals$UdpControlPacketKt.INSTANCE.m6595Int$$this$callrangeTo$$this$callcontains$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket();
                        long jM6658Long$arg0$callrangeTo$$this$callcontains$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket = LiveLiterals$UdpControlPacketKt.INSTANCE.m6658Long$arg0$callrangeTo$$this$callcontains$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket();
                        long chipId = p.getChipId();
                        if (((long) iM6595Int$$this$callrangeTo$$this$callcontains$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket) <= chipId && chipId <= jM6658Long$arg0$callrangeTo$$this$callcontains$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket) {
                            int iM6596Int$$this$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket = LiveLiterals$UdpControlPacketKt.INSTANCE.m6596Int$$this$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket();
                            int iM6621Int$arg0$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket = LiveLiterals$UdpControlPacketKt.INSTANCE.m6621Int$arg0$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket();
                            int throttle = p.getThrottle();
                            if (iM6596Int$$this$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket <= throttle && throttle <= iM6621Int$arg0$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket) {
                                int iM6597Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket = LiveLiterals$UdpControlPacketKt.INSTANCE.m6597Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket();
                                int iM6622Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket = LiveLiterals$UdpControlPacketKt.INSTANCE.m6622Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket();
                                int steering = p.getSteering();
                                if (iM6597Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket <= steering && steering <= iM6622Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket) {
                                    z = true;
                                }
                            }
                        }
                    }
                    if (z) {
                        return p;
                    }
                    return null;
                }
            }
            return null;
        }

        private static final long decode$get(byte[] $bytes, int offset, int size) {
            Iterable $this$fold$iv = RangesKt.until(LiveLiterals$UdpControlPacketKt.INSTANCE.m6588Int$$$this$calluntil$$$this$callfold$funget$fundecode$classCompanion$classUdpControlPacket(), size);
            long initial$iv = LiveLiterals$UdpControlPacketKt.INSTANCE.m6652Long$arg0$callfold$funget$fundecode$classCompanion$classUdpControlPacket();
            long accumulator$iv = initial$iv;
            Iterator<Integer> it = $this$fold$iv.iterator();
            while (it.hasNext()) {
                int element$iv = ((IntIterator) it).nextInt();
                long value = accumulator$iv;
                accumulator$iv = value | ((((long) $bytes[offset + element$iv]) & LiveLiterals$UdpControlPacketKt.INSTANCE.m6651Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funget$fundecode$classCompanion$classUdpControlPacket()) << (LiveLiterals$UdpControlPacketKt.INSTANCE.m6600Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funget$fundecode$classCompanion$classUdpControlPacket() * element$iv));
            }
            return accumulator$iv;
        }
    }
}
