package vea.raceremote.control;

import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.collections.ArraysKt;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: UdpControlSession.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000T\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\r\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0007\u0018\u00002\u00020\u0001:\u0003456B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003¢\u0006\u0002\u0010\u0006J\u0010\u0010#\u001a\u00020$2\u0006\u0010%\u001a\u00020\u0003H\u0002J\u0016\u0010&\u001a\u00020$2\u0006\u0010!\u001a\u00020\b2\u0006\u0010\u001e\u001a\u00020\bJ\u0010\u0010'\u001a\u0004\u0018\u00010 2\u0006\u0010%\u001a\u00020\u0003J6\u0010(\u001a\u00020 2\u0006\u0010)\u001a\u00020\b2\u0006\u0010*\u001a\u00020\u00032\b\b\u0002\u0010+\u001a\u00020\b2\b\b\u0002\u0010,\u001a\u00020\b2\b\b\u0002\u0010-\u001a\u00020\u0003H\u0002J\u0016\u0010.\u001a\u00020/2\u0006\u00100\u001a\u00020 2\u0006\u0010%\u001a\u00020\u0003J\u0006\u00101\u001a\u000202J\u0010\u00103\u001a\u00020$2\b\b\u0002\u0010\u001b\u001a\u00020\u001cR\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0012\u0010\u000b\u001a\u0004\u0018\u00010\u0003X\u0082\u000e¢\u0006\u0004\n\u0002\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000eR\u000e\u0010\u0010\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000R\u0012\u0010\u0013\u001a\u0004\u0018\u00010\u0003X\u0082\u000e¢\u0006\u0004\n\u0002\u0010\fR\u000e\u0010\u0014\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0018\u0010\u0015\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00170\u0016X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0018R\u000e\u0010\u0019\u001a\u00020\u001aX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u001cX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u001f\u001a\u0004\u0018\u00010 X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000¨\u00067"}, d2 = {"Lvea/raceremote/control/UdpControlSession;", "", "chipId", "", "attempt", "openedAt", "(JJJ)V", "acknowledgedSteering", "", "acknowledgedThrottle", "acknowledgements", "armStarted", "Ljava/lang/Long;", "getAttempt", "()J", "getChipId", "confirmedAt", "helloAt", "lastAck", "lastSent", "maxRttMs", "pending", "", "Lvea/raceremote/control/UdpControlSession$Sent;", "[Lvea/raceremote/control/UdpControlSession$Sent;", "phase", "Lvea/raceremote/control/UdpControlSession$Phase;", "reason", "", "sequence", "steering", "stopping", "Lvea/raceremote/control/UdpControlPacket;", "throttle", "token", "expire", "", "now", "input", "next", "packet", "kind", "seq", "t", "s", "basis", "receive", "", "p", "snapshot", "Lvea/raceremote/control/UdpControlSession$Snapshot;", "stop", "Phase", "Sent", "Snapshot", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class UdpControlSession {
    public static final int $stable = LiveLiterals$UdpControlSessionKt.INSTANCE.m6735Int$classUdpControlSession();
    private int acknowledgedSteering;
    private int acknowledgedThrottle;
    private int acknowledgements;
    private Long armStarted;
    private final long attempt;
    private final long chipId;
    private long confirmedAt;
    private long helloAt;
    private long lastAck;
    private Long lastSent;
    private long maxRttMs;
    private final long openedAt;
    private final Sent[] pending = new Sent[64];
    private Phase phase = Phase.OPENING;
    private String reason = "Connecting";
    private long sequence;
    private int steering;
    private UdpControlPacket stopping;
    private int throttle;
    private long token;

    /* JADX INFO: compiled from: UdpControlSession.kt */
    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0006\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006¨\u0006\u0007"}, d2 = {"Lvea/raceremote/control/UdpControlSession$Phase;", "", "(Ljava/lang/String;I)V", "OPENING", "ARMING", "ACTIVE", "CLOSED", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public enum Phase {
        OPENING,
        ARMING,
        ACTIVE,
        CLOSED
    }

    /* JADX INFO: compiled from: UdpControlSession.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[Phase.values().length];
            try {
                iArr[Phase.OPENING.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                iArr[Phase.ARMING.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                iArr[Phase.ACTIVE.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                iArr[Phase.CLOSED.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    /* JADX WARN: Code duplicated, block: B:17:0x004e  */
    public UdpControlSession(long chipId, long attempt, long openedAt) {
        boolean z;
        this.chipId = chipId;
        this.attempt = attempt;
        this.openedAt = openedAt;
        if (((long) LiveLiterals$UdpControlSessionKt.INSTANCE.m6706Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$classUdpControlSession()) <= chipId && chipId <= LiveLiterals$UdpControlSessionKt.INSTANCE.m6743Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$classUdpControlSession()) {
            z = (((long) LiveLiterals$UdpControlSessionKt.INSTANCE.m6704Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$classUdpControlSession()) > attempt ? 1 : (((long) LiveLiterals$UdpControlSessionKt.INSTANCE.m6704Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$classUdpControlSession()) == attempt ? 0 : -1)) <= 0 && (attempt > LiveLiterals$UdpControlSessionKt.INSTANCE.m6742Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$classUdpControlSession() ? 1 : (attempt == LiveLiterals$UdpControlSessionKt.INSTANCE.m6742Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$classUdpControlSession() ? 0 : -1)) <= 0;
        }
        if (z) {
        } else {
            throw new IllegalArgumentException("Failed requirement.".toString());
        }
    }

    public final long getAttempt() {
        return this.attempt;
    }

    public final long getChipId() {
        return this.chipId;
    }

    /* JADX INFO: compiled from: UdpControlSession.kt */
    @Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0002\b\u001e\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0087\b\u0018\u00002\u00020\u0001BM\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\u0007\u0012\u0006\u0010\u000b\u001a\u00020\u0007\u0012\u0006\u0010\f\u001a\u00020\t\u0012\u0006\u0010\r\u001a\u00020\u0007\u0012\u0006\u0010\u000e\u001a\u00020\u0007¢\u0006\u0002\u0010\u000fJ\t\u0010\u001d\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001e\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001f\u001a\u00020\u0007HÆ\u0003J\t\u0010 \u001a\u00020\tHÆ\u0003J\t\u0010!\u001a\u00020\u0007HÆ\u0003J\t\u0010\"\u001a\u00020\u0007HÆ\u0003J\t\u0010#\u001a\u00020\tHÆ\u0003J\t\u0010$\u001a\u00020\u0007HÆ\u0003J\t\u0010%\u001a\u00020\u0007HÆ\u0003Jc\u0010&\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\n\u001a\u00020\u00072\b\b\u0002\u0010\u000b\u001a\u00020\u00072\b\b\u0002\u0010\f\u001a\u00020\t2\b\b\u0002\u0010\r\u001a\u00020\u00072\b\b\u0002\u0010\u000e\u001a\u00020\u0007HÆ\u0001J\u0013\u0010'\u001a\u00020(2\b\u0010)\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010*\u001a\u00020\u0007HÖ\u0001J\t\u0010+\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u000e\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\r\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0011R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0011R\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0011\u0010\f\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0015R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u001aR\u0011\u0010\u000b\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0011R\u0011\u0010\n\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0011¨\u0006,"}, d2 = {"Lvea/raceremote/control/UdpControlSession$Snapshot;", "", "phase", "Lvea/raceremote/control/UdpControlSession$Phase;", "reason", "", "acknowledgements", "", "lastAck", "", "throttle", "steering", "maxRttMs", "acknowledgedThrottle", "acknowledgedSteering", "(Lvea/raceremote/control/UdpControlSession$Phase;Ljava/lang/String;IJIIJII)V", "getAcknowledgedSteering", "()I", "getAcknowledgedThrottle", "getAcknowledgements", "getLastAck", "()J", "getMaxRttMs", "getPhase", "()Lvea/raceremote/control/UdpControlSession$Phase;", "getReason", "()Ljava/lang/String;", "getSteering", "getThrottle", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "equals", "", "other", "hashCode", "toString", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final /* data */ class Snapshot {
        public static final int $stable = LiveLiterals$UdpControlSessionKt.INSTANCE.m6734Int$classSnapshot$classUdpControlSession();
        private final int acknowledgedSteering;
        private final int acknowledgedThrottle;
        private final int acknowledgements;
        private final long lastAck;
        private final long maxRttMs;
        private final Phase phase;
        private final String reason;
        private final int steering;
        private final int throttle;

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final Phase getPhase() {
            return this.phase;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final String getReason() {
            return this.reason;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final int getAcknowledgements() {
            return this.acknowledgements;
        }

        /* JADX INFO: renamed from: component4, reason: from getter */
        public final long getLastAck() {
            return this.lastAck;
        }

        /* JADX INFO: renamed from: component5, reason: from getter */
        public final int getThrottle() {
            return this.throttle;
        }

        /* JADX INFO: renamed from: component6, reason: from getter */
        public final int getSteering() {
            return this.steering;
        }

        /* JADX INFO: renamed from: component7, reason: from getter */
        public final long getMaxRttMs() {
            return this.maxRttMs;
        }

        /* JADX INFO: renamed from: component8, reason: from getter */
        public final int getAcknowledgedThrottle() {
            return this.acknowledgedThrottle;
        }

        /* JADX INFO: renamed from: component9, reason: from getter */
        public final int getAcknowledgedSteering() {
            return this.acknowledgedSteering;
        }

        public final Snapshot copy(Phase phase, String reason, int acknowledgements, long lastAck, int throttle, int steering, long maxRttMs, int acknowledgedThrottle, int acknowledgedSteering) {
            Intrinsics.checkNotNullParameter(phase, "phase");
            Intrinsics.checkNotNullParameter(reason, "reason");
            return new Snapshot(phase, reason, acknowledgements, lastAck, throttle, steering, maxRttMs, acknowledgedThrottle, acknowledgedSteering);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return LiveLiterals$UdpControlSessionKt.INSTANCE.m6686Boolean$branch$when$funequals$classSnapshot$classUdpControlSession();
            }
            if (!(other instanceof Snapshot)) {
                return LiveLiterals$UdpControlSessionKt.INSTANCE.m6689Boolean$branch$when1$funequals$classSnapshot$classUdpControlSession();
            }
            Snapshot snapshot = (Snapshot) other;
            if (this.phase != snapshot.phase) {
                return LiveLiterals$UdpControlSessionKt.INSTANCE.m6692Boolean$branch$when2$funequals$classSnapshot$classUdpControlSession();
            }
            if (!Intrinsics.areEqual(this.reason, snapshot.reason)) {
                return LiveLiterals$UdpControlSessionKt.INSTANCE.m6694Boolean$branch$when3$funequals$classSnapshot$classUdpControlSession();
            }
            if (this.acknowledgements != snapshot.acknowledgements) {
                return LiveLiterals$UdpControlSessionKt.INSTANCE.m6695Boolean$branch$when4$funequals$classSnapshot$classUdpControlSession();
            }
            if (this.lastAck != snapshot.lastAck) {
                return LiveLiterals$UdpControlSessionKt.INSTANCE.m6696Boolean$branch$when5$funequals$classSnapshot$classUdpControlSession();
            }
            if (this.throttle != snapshot.throttle) {
                return LiveLiterals$UdpControlSessionKt.INSTANCE.m6697Boolean$branch$when6$funequals$classSnapshot$classUdpControlSession();
            }
            if (this.steering != snapshot.steering) {
                return LiveLiterals$UdpControlSessionKt.INSTANCE.m6698Boolean$branch$when7$funequals$classSnapshot$classUdpControlSession();
            }
            if (this.maxRttMs != snapshot.maxRttMs) {
                return LiveLiterals$UdpControlSessionKt.INSTANCE.m6699Boolean$branch$when8$funequals$classSnapshot$classUdpControlSession();
            }
            if (this.acknowledgedThrottle != snapshot.acknowledgedThrottle) {
                return LiveLiterals$UdpControlSessionKt.INSTANCE.m6700Boolean$branch$when9$funequals$classSnapshot$classUdpControlSession();
            }
            return this.acknowledgedSteering != snapshot.acknowledgedSteering ? LiveLiterals$UdpControlSessionKt.INSTANCE.m6690Boolean$branch$when10$funequals$classSnapshot$classUdpControlSession() : LiveLiterals$UdpControlSessionKt.INSTANCE.m6702Boolean$funequals$classSnapshot$classUdpControlSession();
        }

        public int hashCode() {
            return (LiveLiterals$UdpControlSessionKt.INSTANCE.m6730Int$arg0$calltimes$$this$callplus$setresult7$funhashCode$classSnapshot$classUdpControlSession() * ((LiveLiterals$UdpControlSessionKt.INSTANCE.m6729Int$arg0$calltimes$$this$callplus$setresult6$funhashCode$classSnapshot$classUdpControlSession() * ((LiveLiterals$UdpControlSessionKt.INSTANCE.m6728Int$arg0$calltimes$$this$callplus$setresult5$funhashCode$classSnapshot$classUdpControlSession() * ((LiveLiterals$UdpControlSessionKt.INSTANCE.m6727Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classSnapshot$classUdpControlSession() * ((LiveLiterals$UdpControlSessionKt.INSTANCE.m6726Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classSnapshot$classUdpControlSession() * ((LiveLiterals$UdpControlSessionKt.INSTANCE.m6725Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classSnapshot$classUdpControlSession() * ((LiveLiterals$UdpControlSessionKt.INSTANCE.m6724Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classSnapshot$classUdpControlSession() * ((LiveLiterals$UdpControlSessionKt.INSTANCE.m6723Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classSnapshot$classUdpControlSession() * this.phase.hashCode()) + this.reason.hashCode())) + Integer.hashCode(this.acknowledgements))) + Long.hashCode(this.lastAck))) + Integer.hashCode(this.throttle))) + Integer.hashCode(this.steering))) + Long.hashCode(this.maxRttMs))) + Integer.hashCode(this.acknowledgedThrottle))) + Integer.hashCode(this.acknowledgedSteering);
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append(LiveLiterals$UdpControlSessionKt.INSTANCE.m6751String$0$str$funtoString$classSnapshot$classUdpControlSession()).append(LiveLiterals$UdpControlSessionKt.INSTANCE.m6753String$1$str$funtoString$classSnapshot$classUdpControlSession()).append(this.phase).append(LiveLiterals$UdpControlSessionKt.INSTANCE.m6767String$3$str$funtoString$classSnapshot$classUdpControlSession()).append(LiveLiterals$UdpControlSessionKt.INSTANCE.m6769String$4$str$funtoString$classSnapshot$classUdpControlSession()).append(this.reason).append(LiveLiterals$UdpControlSessionKt.INSTANCE.m6771String$6$str$funtoString$classSnapshot$classUdpControlSession()).append(LiveLiterals$UdpControlSessionKt.INSTANCE.m6772String$7$str$funtoString$classSnapshot$classUdpControlSession()).append(this.acknowledgements).append(LiveLiterals$UdpControlSessionKt.INSTANCE.m6773String$9$str$funtoString$classSnapshot$classUdpControlSession()).append(LiveLiterals$UdpControlSessionKt.INSTANCE.m6754String$10$str$funtoString$classSnapshot$classUdpControlSession()).append(this.lastAck).append(LiveLiterals$UdpControlSessionKt.INSTANCE.m6755String$12$str$funtoString$classSnapshot$classUdpControlSession()).append(LiveLiterals$UdpControlSessionKt.INSTANCE.m6756String$13$str$funtoString$classSnapshot$classUdpControlSession()).append(this.throttle).append(LiveLiterals$UdpControlSessionKt.INSTANCE.m6757String$15$str$funtoString$classSnapshot$classUdpControlSession()).append(LiveLiterals$UdpControlSessionKt.INSTANCE.m6758String$16$str$funtoString$classSnapshot$classUdpControlSession()).append(this.steering).append(LiveLiterals$UdpControlSessionKt.INSTANCE.m6759String$18$str$funtoString$classSnapshot$classUdpControlSession()).append(LiveLiterals$UdpControlSessionKt.INSTANCE.m6760String$19$str$funtoString$classSnapshot$classUdpControlSession()).append(this.maxRttMs).append(LiveLiterals$UdpControlSessionKt.INSTANCE.m6761String$21$str$funtoString$classSnapshot$classUdpControlSession()).append(LiveLiterals$UdpControlSessionKt.INSTANCE.m6762String$22$str$funtoString$classSnapshot$classUdpControlSession());
            sb.append(this.acknowledgedThrottle).append(LiveLiterals$UdpControlSessionKt.INSTANCE.m6763String$24$str$funtoString$classSnapshot$classUdpControlSession()).append(LiveLiterals$UdpControlSessionKt.INSTANCE.m6764String$25$str$funtoString$classSnapshot$classUdpControlSession()).append(this.acknowledgedSteering).append(LiveLiterals$UdpControlSessionKt.INSTANCE.m6765String$27$str$funtoString$classSnapshot$classUdpControlSession());
            return sb.toString();
        }

        public Snapshot(Phase phase, String reason, int acknowledgements, long lastAck, int throttle, int steering, long maxRttMs, int acknowledgedThrottle, int acknowledgedSteering) {
            Intrinsics.checkNotNullParameter(phase, "phase");
            Intrinsics.checkNotNullParameter(reason, "reason");
            this.phase = phase;
            this.reason = reason;
            this.acknowledgements = acknowledgements;
            this.lastAck = lastAck;
            this.throttle = throttle;
            this.steering = steering;
            this.maxRttMs = maxRttMs;
            this.acknowledgedThrottle = acknowledgedThrottle;
            this.acknowledgedSteering = acknowledgedSteering;
        }

        public final int getAcknowledgements() {
            return this.acknowledgements;
        }

        public final long getLastAck() {
            return this.lastAck;
        }

        public final Phase getPhase() {
            return this.phase;
        }

        public final String getReason() {
            return this.reason;
        }

        public final long getMaxRttMs() {
            return this.maxRttMs;
        }

        public final int getSteering() {
            return this.steering;
        }

        public final int getThrottle() {
            return this.throttle;
        }

        public final int getAcknowledgedSteering() {
            return this.acknowledgedSteering;
        }

        public final int getAcknowledgedThrottle() {
            return this.acknowledgedThrottle;
        }
    }

    /* JADX INFO: compiled from: UdpControlSession.kt */
    @Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0082\b\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\t\u0010\u000b\u001a\u00020\u0003HÆ\u0003J\t\u0010\f\u001a\u00020\u0005HÆ\u0003J\u001d\u0010\r\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u000e\u001a\u00020\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0011\u001a\u00020\u0012HÖ\u0001J\t\u0010\u0013\u001a\u00020\u0014HÖ\u0001R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u0015"}, d2 = {"Lvea/raceremote/control/UdpControlSession$Sent;", "", "packet", "Lvea/raceremote/control/UdpControlPacket;", "at", "", "(Lvea/raceremote/control/UdpControlPacket;J)V", "getAt", "()J", "getPacket", "()Lvea/raceremote/control/UdpControlPacket;", "component1", "component2", "copy", "equals", "", "other", "hashCode", "", "toString", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
    private static final /* data */ class Sent {
        private final long at;
        private final UdpControlPacket packet;

        public static /* synthetic */ Sent copy$default(Sent sent, UdpControlPacket udpControlPacket, long j, int i, Object obj) {
            if ((i & 1) != 0) {
                udpControlPacket = sent.packet;
            }
            if ((i & 2) != 0) {
                j = sent.at;
            }
            return sent.copy(udpControlPacket, j);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final UdpControlPacket getPacket() {
            return this.packet;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final long getAt() {
            return this.at;
        }

        public final Sent copy(UdpControlPacket packet, long at) {
            Intrinsics.checkNotNullParameter(packet, "packet");
            return new Sent(packet, at);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return LiveLiterals$UdpControlSessionKt.INSTANCE.m6685Boolean$branch$when$funequals$classSent$classUdpControlSession();
            }
            if (!(other instanceof Sent)) {
                return LiveLiterals$UdpControlSessionKt.INSTANCE.m6688Boolean$branch$when1$funequals$classSent$classUdpControlSession();
            }
            Sent sent = (Sent) other;
            if (Intrinsics.areEqual(this.packet, sent.packet)) {
                return this.at != sent.at ? LiveLiterals$UdpControlSessionKt.INSTANCE.m6693Boolean$branch$when3$funequals$classSent$classUdpControlSession() : LiveLiterals$UdpControlSessionKt.INSTANCE.m6701Boolean$funequals$classSent$classUdpControlSession();
            }
            return LiveLiterals$UdpControlSessionKt.INSTANCE.m6691Boolean$branch$when2$funequals$classSent$classUdpControlSession();
        }

        public int hashCode() {
            return (LiveLiterals$UdpControlSessionKt.INSTANCE.m6722Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classSent$classUdpControlSession() * this.packet.hashCode()) + Long.hashCode(this.at);
        }

        public String toString() {
            return LiveLiterals$UdpControlSessionKt.INSTANCE.m6750String$0$str$funtoString$classSent$classUdpControlSession() + LiveLiterals$UdpControlSessionKt.INSTANCE.m6752String$1$str$funtoString$classSent$classUdpControlSession() + this.packet + LiveLiterals$UdpControlSessionKt.INSTANCE.m6766String$3$str$funtoString$classSent$classUdpControlSession() + LiveLiterals$UdpControlSessionKt.INSTANCE.m6768String$4$str$funtoString$classSent$classUdpControlSession() + this.at + LiveLiterals$UdpControlSessionKt.INSTANCE.m6770String$6$str$funtoString$classSent$classUdpControlSession();
        }

        public Sent(UdpControlPacket packet, long at) {
            Intrinsics.checkNotNullParameter(packet, "packet");
            this.packet = packet;
            this.at = at;
        }

        public final long getAt() {
            return this.at;
        }

        public final UdpControlPacket getPacket() {
            return this.packet;
        }
    }

    public final Snapshot snapshot() {
        return new Snapshot(this.phase, this.reason, this.acknowledgements, this.lastAck, this.throttle, this.steering, this.maxRttMs, this.acknowledgedThrottle, this.acknowledgedSteering);
    }

    /* JADX WARN: Code duplicated, block: B:15:0x002d  */
    public final void input(int throttle, int steering) {
        boolean z;
        if (throttle <= LiveLiterals$UdpControlSessionKt.INSTANCE.m6717Int$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$funinput$classUdpControlSession() && LiveLiterals$UdpControlSessionKt.INSTANCE.m6707Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$funinput$classUdpControlSession() <= throttle) {
            z = steering <= LiveLiterals$UdpControlSessionKt.INSTANCE.m6716Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funinput$classUdpControlSession() && LiveLiterals$UdpControlSessionKt.INSTANCE.m6705Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funinput$classUdpControlSession() <= steering;
        }
        if (!z) {
            throw new IllegalArgumentException("Failed requirement.".toString());
        }
        if (this.phase == Phase.ACTIVE) {
            this.throttle = throttle;
            this.steering = steering;
        }
    }

    public static /* synthetic */ void stop$default(UdpControlSession udpControlSession, String str, int i, Object obj) {
        if ((i & 1) != 0) {
            str = LiveLiterals$UdpControlSessionKt.INSTANCE.m6778String$paramreason$funstop$classUdpControlSession();
        }
        udpControlSession.stop(str);
    }

    public final void stop(String reason) {
        Intrinsics.checkNotNullParameter(reason, "reason");
        if (this.phase == Phase.CLOSED) {
            return;
        }
        if (this.token != LiveLiterals$UdpControlSessionKt.INSTANCE.m6745Long$arg1$callEQEQ$$this$callnot$cond$if1$funstop$classUdpControlSession()) {
            this.stopping = packet$default(this, 3, this.sequence, 0, 0, 0L, 28, null);
        }
        this.phase = Phase.CLOSED;
        this.reason = reason;
        this.throttle = LiveLiterals$UdpControlSessionKt.INSTANCE.m6714Int$arg0$call$setthrottle$$funstop$classUdpControlSession();
        this.steering = LiveLiterals$UdpControlSessionKt.INSTANCE.m6713Int$arg0$call$setsteering$$funstop$classUdpControlSession();
        this.acknowledgedThrottle = LiveLiterals$UdpControlSessionKt.INSTANCE.m6712Int$arg0$call$setacknowledgedThrottle$$funstop$classUdpControlSession();
        this.acknowledgedSteering = LiveLiterals$UdpControlSessionKt.INSTANCE.m6711Int$arg0$call$setacknowledgedSteering$$funstop$classUdpControlSession();
        ArraysKt.fill$default(this.pending, (Object) null, 0, 0, 6, (Object) null);
    }

    private final void expire(long now) {
        switch (WhenMappings.$EnumSwitchMapping$0[this.phase.ordinal()]) {
            case 1:
                if (now - this.openedAt >= LiveLiterals$UdpControlSessionKt.INSTANCE.m6708Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch$when$funexpire$classUdpControlSession()) {
                    stop(LiveLiterals$UdpControlSessionKt.INSTANCE.m6775String$arg0$callstop$branch$if$branch$when$funexpire$classUdpControlSession());
                }
                break;
            case 2:
                Long l = this.armStarted;
                if (now - (l != null ? l.longValue() : this.helloAt) >= LiveLiterals$UdpControlSessionKt.INSTANCE.m6709Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch1$when$funexpire$classUdpControlSession()) {
                    stop(LiveLiterals$UdpControlSessionKt.INSTANCE.m6776String$arg0$callstop$branch$if$branch1$when$funexpire$classUdpControlSession());
                }
                break;
            case 3:
                if (now - this.confirmedAt >= LiveLiterals$UdpControlSessionKt.INSTANCE.m6710Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch2$when$funexpire$classUdpControlSession()) {
                    stop(LiveLiterals$UdpControlSessionKt.INSTANCE.m6777String$arg0$callstop$branch$if$branch2$when$funexpire$classUdpControlSession());
                }
                break;
        }
    }

    public final UdpControlPacket next(long now) {
        int iM6732Int$branch$when$valinterval$funnext$classUdpControlSession;
        UdpControlPacket it;
        expire(now);
        if (this.phase == Phase.CLOSED) {
            UdpControlPacket udpControlPacket = this.stopping;
            this.stopping = null;
            return udpControlPacket;
        }
        switch (WhenMappings.$EnumSwitchMapping$0[this.phase.ordinal()]) {
            case 1:
                iM6732Int$branch$when$valinterval$funnext$classUdpControlSession = LiveLiterals$UdpControlSessionKt.INSTANCE.m6732Int$branch$when$valinterval$funnext$classUdpControlSession();
                break;
            case 2:
                iM6732Int$branch$when$valinterval$funnext$classUdpControlSession = LiveLiterals$UdpControlSessionKt.INSTANCE.m6733Int$branch1$when$valinterval$funnext$classUdpControlSession();
                break;
            default:
                iM6732Int$branch$when$valinterval$funnext$classUdpControlSession = LiveLiterals$UdpControlSessionKt.INSTANCE.m6736Int$else$when$valinterval$funnext$classUdpControlSession();
                break;
        }
        int interval = iM6732Int$branch$when$valinterval$funnext$classUdpControlSession;
        Long l = this.lastSent;
        boolean z = false;
        if (l != null) {
            long it2 = l.longValue();
            if ((now - it2 < ((long) interval)) == LiveLiterals$UdpControlSessionKt.INSTANCE.m6678Boolean$arg1$callEQEQ$cond$if1$funnext$classUdpControlSession()) {
                z = true;
            }
        }
        if (z) {
            return null;
        }
        switch (WhenMappings.$EnumSwitchMapping$0[this.phase.ordinal()]) {
            case 1:
                it = packet$default(this, 0, LiveLiterals$UdpControlSessionKt.INSTANCE.m6748Long$arg1$callpacket$branch$when$valp$funnext$classUdpControlSession(), 0, 0, 0L, 28, null);
                break;
            case 2:
                it = packet$default(this, 1, LiveLiterals$UdpControlSessionKt.INSTANCE.m6747Long$arg1$callpacket$$$this$callalso$branch1$when$valp$funnext$classUdpControlSession(), 0, 0, 0L, 28, null);
                if (this.armStarted == null) {
                    this.armStarted = Long.valueOf(now);
                    this.pending[LiveLiterals$UdpControlSessionKt.INSTANCE.m6721Int$arg0$callset$branch$if$fun$anonymous$$arg0$callalso$branch1$when$valp$funnext$classUdpControlSession()] = new Sent(it, now);
                }
                break;
            case 3:
                long jM6740Long$arg0$calland$arg0$call$setsequence$$branch2$when$valp$funnext$classUdpControlSession = LiveLiterals$UdpControlSessionKt.INSTANCE.m6740Long$arg0$calland$arg0$call$setsequence$$branch2$when$valp$funnext$classUdpControlSession() & (this.sequence + ((long) LiveLiterals$UdpControlSessionKt.INSTANCE.m6715Int$arg0$callplus$$this$calland$arg0$call$setsequence$$branch2$when$valp$funnext$classUdpControlSession()));
                this.sequence = jM6740Long$arg0$calland$arg0$call$setsequence$$branch2$when$valp$funnext$classUdpControlSession;
                it = packet(2, jM6740Long$arg0$calland$arg0$call$setsequence$$branch2$when$valp$funnext$classUdpControlSession, this.throttle, this.steering, this.lastAck);
                this.pending[(int) (this.sequence % ((long) LiveLiterals$UdpControlSessionKt.INSTANCE.m6719Int$arg0$callrem$$this$calltoInt$arg0$callset$fun$anonymous$$arg0$callalso$branch2$when$valp$funnext$classUdpControlSession()))] = new Sent(it, now);
                break;
            case 4:
                return null;
            default:
                throw new NoWhenBranchMatchedException();
        }
        this.lastSent = Long.valueOf(now);
        return it;
    }

    public final boolean receive(UdpControlPacket p, long now) {
        Intrinsics.checkNotNullParameter(p, "p");
        expire(now);
        if (this.phase == Phase.CLOSED || p.getChipId() != this.chipId || p.getAttempt() != this.attempt || p.getBasis() != LiveLiterals$UdpControlSessionKt.INSTANCE.m6746Long$arg1$callEQEQ$$this$callnot$else$cond$if$funreceive$classUdpControlSession()) {
            return LiveLiterals$UdpControlSessionKt.INSTANCE.m6680Boolean$branch$if$funreceive$classUdpControlSession();
        }
        if (this.phase == Phase.OPENING) {
            if (p.getKind() != 128 || p.getToken() == 0 || p.getSequence() != 0 || p.getThrottle() != 0 || p.getSteering() != LiveLiterals$UdpControlSessionKt.INSTANCE.m6731Int$arg1$callEQEQ$$this$callnot$else$cond$if$branch$if1$funreceive$classUdpControlSession()) {
                return LiveLiterals$UdpControlSessionKt.INSTANCE.m6679Boolean$branch$if$branch$if1$funreceive$classUdpControlSession();
            }
            this.token = p.getToken();
            this.helloAt = now;
            this.lastSent = null;
            this.phase = Phase.ARMING;
            return LiveLiterals$UdpControlSessionKt.INSTANCE.m6681Boolean$branch$if1$funreceive$classUdpControlSession();
        }
        if (p.getKind() != 129 || p.getToken() != this.token) {
            return LiveLiterals$UdpControlSessionKt.INSTANCE.m6682Boolean$branch$if2$funreceive$classUdpControlSession();
        }
        Sent sent = this.pending[(int) (p.getSequence() % ((long) LiveLiterals$UdpControlSessionKt.INSTANCE.m6718Int$arg0$callrem$$this$calltoInt$arg0$callget$valtmp0_elvis_lhs$valsent$funreceive$classUdpControlSession()))];
        if (sent == null) {
            return LiveLiterals$UdpControlSessionKt.INSTANCE.m6687Boolean$branch$when$valsent$funreceive$classUdpControlSession();
        }
        long distance = (p.getSequence() - this.lastAck) & LiveLiterals$UdpControlSessionKt.INSTANCE.m6741Long$arg0$calland$valdistance$funreceive$classUdpControlSession();
        if (sent.getPacket().getSequence() == p.getSequence()) {
            boolean z = false;
            if (1 <= distance && distance < 2147483648L) {
                z = true;
            }
            if (z && now - sent.getAt() < 200 && p.getThrottle() == sent.getPacket().getThrottle() && p.getSteering() == sent.getPacket().getSteering()) {
                if (this.phase == Phase.ARMING && p.getSequence() != LiveLiterals$UdpControlSessionKt.INSTANCE.m6744Long$arg1$callEQEQ$$this$callnot$branch$cond$if4$funreceive$classUdpControlSession()) {
                    return LiveLiterals$UdpControlSessionKt.INSTANCE.m6684Boolean$branch$if4$funreceive$classUdpControlSession();
                }
                this.lastAck = p.getSequence();
                this.confirmedAt = sent.getAt();
                this.acknowledgements++;
                this.acknowledgedThrottle = p.getThrottle();
                this.acknowledgedSteering = p.getSteering();
                this.maxRttMs = Math.max(this.maxRttMs, now - sent.getAt());
                this.pending[(int) (p.getSequence() % ((long) LiveLiterals$UdpControlSessionKt.INSTANCE.m6720Int$arg0$callrem$$this$calltoInt$arg0$callset$funreceive$classUdpControlSession()))] = null;
                if (this.phase == Phase.ARMING) {
                    this.sequence = LiveLiterals$UdpControlSessionKt.INSTANCE.m6739Long$arg0$call$setsequence$$branch$if5$funreceive$classUdpControlSession();
                    this.phase = Phase.ACTIVE;
                    this.reason = LiveLiterals$UdpControlSessionKt.INSTANCE.m6774String$arg0$call$setreason$$branch$if5$funreceive$classUdpControlSession();
                }
                return LiveLiterals$UdpControlSessionKt.INSTANCE.m6703Boolean$funreceive$classUdpControlSession();
            }
        }
        return LiveLiterals$UdpControlSessionKt.INSTANCE.m6683Boolean$branch$if3$funreceive$classUdpControlSession();
    }

    static /* synthetic */ UdpControlPacket packet$default(UdpControlSession udpControlSession, int i, long j, int i2, int i3, long j2, int i4, Object obj) {
        return udpControlSession.packet(i, j, (i4 & 4) != 0 ? LiveLiterals$UdpControlSessionKt.INSTANCE.m6738Int$paramt$funpacket$classUdpControlSession() : i2, (i4 & 8) != 0 ? LiveLiterals$UdpControlSessionKt.INSTANCE.m6737Int$params$funpacket$classUdpControlSession() : i3, (i4 & 16) != 0 ? LiveLiterals$UdpControlSessionKt.INSTANCE.m6749Long$parambasis$funpacket$classUdpControlSession() : j2);
    }

    private final UdpControlPacket packet(int kind, long seq, int t, int s, long basis) {
        return new UdpControlPacket(kind, this.attempt, this.token, seq, t, s, this.chipId, basis);
    }
}
