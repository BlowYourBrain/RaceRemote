package vea.raceremote.features;

import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.material.MaterialTheme;
import androidx.compose.material.TextKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.res.StringResources_androidKt;
import androidx.compose.ui.text.style.TextAlign;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import vea.raceremote.ui.theme.Padding;

/* JADX INFO: compiled from: BluetoothPermissionRationale.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
public final class ComposableSingletons$BluetoothPermissionRationaleKt {
    public static final ComposableSingletons$BluetoothPermissionRationaleKt INSTANCE = new ComposableSingletons$BluetoothPermissionRationaleKt();

    /* JADX INFO: renamed from: lambda-1, reason: not valid java name */
    public static Function2<Composer, Integer, Unit> f1634lambda1 = ComposableLambdaKt.composableLambdaInstance(1694374635, false, new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.features.ComposableSingletons$BluetoothPermissionRationaleKt$lambda-1$1
        @Override // kotlin.jvm.functions.Function2
        public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
            invoke(composer, num.intValue());
            return Unit.INSTANCE;
        }

        public final void invoke(Composer $composer, int $changed) {
            ComposerKt.sourceInformation($composer, "C47@1696L63,48@1803L10,45@1597L287:BluetoothPermissionRationale.kt#pfgioo");
            if (($changed & 11) != 2 || !$composer.getSkipping()) {
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventStart(1694374635, $changed, -1, "vea.raceremote.features.ComposableSingletons$BluetoothPermissionRationaleKt.lambda-1.<anonymous> (BluetoothPermissionRationale.kt:44)");
                }
                Modifier modifierM427padding3ABfNKs = PaddingKt.m427padding3ABfNKs(Modifier.Companion, Padding.INSTANCE.m6886getContentD9Ej5fM());
                TextKt.m1249TextfLXpl1I(StringResources_androidKt.stringResource(2131689505, $composer, 0), modifierM427padding3ABfNKs, 0L, 0L, null, null, null, 0L, null, TextAlign.m3925boximpl(TextAlign.INSTANCE.m3932getCentere0LSkKk()), 0L, 0, false, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getH5(), $composer, 48, 0, 32252);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                    return;
                }
                return;
            }
            $composer.skipToGroupEnd();
        }
    });

    /* JADX INFO: renamed from: getLambda-1$app_debug, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m6780getLambda1$app_debug() {
        return f1634lambda1;
    }
}
