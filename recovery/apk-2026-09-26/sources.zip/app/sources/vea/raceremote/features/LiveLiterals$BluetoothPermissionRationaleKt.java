package vea.raceremote.features;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: BluetoothPermissionRationale.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/features/BluetoothPermissionRationale.kt")
public final class LiveLiterals$BluetoothPermissionRationaleKt {

    /* JADX INFO: renamed from: State$Float$arg-0$call-fillMaxWidth$arg-0$call-Column$fun-$anonymous$$arg-3$call-Box$fun-BluetoothPermissionRationale, reason: not valid java name */
    private static State<Float> f1636State$Float$arg0$callfillMaxWidth$arg0$callColumn$fun$anonymous$$arg3$callBox$funBluetoothPermissionRationale;
    public static final LiveLiterals$BluetoothPermissionRationaleKt INSTANCE = new LiveLiterals$BluetoothPermissionRationaleKt();

    /* JADX INFO: renamed from: Float$arg-0$call-fillMaxWidth$arg-0$call-Column$fun-$anonymous$$arg-3$call-Box$fun-BluetoothPermissionRationale, reason: not valid java name */
    private static float f1635Float$arg0$callfillMaxWidth$arg0$callColumn$fun$anonymous$$arg3$callBox$funBluetoothPermissionRationale = 0.5f;

    @LiveLiteralInfo(key = "Float$arg-0$call-fillMaxWidth$arg-0$call-Column$fun-$anonymous$$arg-3$call-Box$fun-BluetoothPermissionRationale", offset = 1369)
    /* JADX INFO: renamed from: Float$arg-0$call-fillMaxWidth$arg-0$call-Column$fun-$anonymous$$arg-3$call-Box$fun-BluetoothPermissionRationale, reason: not valid java name */
    public final float m6781Float$arg0$callfillMaxWidth$arg0$callColumn$fun$anonymous$$arg3$callBox$funBluetoothPermissionRationale() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1635Float$arg0$callfillMaxWidth$arg0$callColumn$fun$anonymous$$arg3$callBox$funBluetoothPermissionRationale;
        }
        State<Float> stateLiveLiteral = f1636State$Float$arg0$callfillMaxWidth$arg0$callColumn$fun$anonymous$$arg3$callBox$funBluetoothPermissionRationale;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-fillMaxWidth$arg-0$call-Column$fun-$anonymous$$arg-3$call-Box$fun-BluetoothPermissionRationale", Float.valueOf(f1635Float$arg0$callfillMaxWidth$arg0$callColumn$fun$anonymous$$arg3$callBox$funBluetoothPermissionRationale));
            f1636State$Float$arg0$callfillMaxWidth$arg0$callColumn$fun$anonymous$$arg3$callBox$funBluetoothPermissionRationale = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }
}
