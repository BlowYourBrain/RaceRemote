package vea.raceremote.features.remote_control.data;

import kotlin.Metadata;
import kotlin.coroutines.Continuation;

/* JADX INFO: compiled from: RemoteDeviceRepository.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\bf\u0018\u00002\u00020\u0001:\u0001\u000bJ\u0011\u0010\u0002\u001a\u00020\u0003H¦@ø\u0001\u0000¢\u0006\u0002\u0010\u0004J\u0018\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH&\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\f"}, d2 = {"Lvea/raceremote/features/remote_control/data/IRemoteDeviceRepository;", "", "isRemoteDeviceAvailable", "", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendData", "", "destination", "Lvea/raceremote/features/remote_control/data/IRemoteDeviceRepository$Destination;", "command", "", "Destination", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public interface IRemoteDeviceRepository {

    /* JADX INFO: compiled from: RemoteDeviceRepository.kt */
    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0004\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004¨\u0006\u0005"}, d2 = {"Lvea/raceremote/features/remote_control/data/IRemoteDeviceRepository$Destination;", "", "(Ljava/lang/String;I)V", "Bluetooth", "WiFi", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public enum Destination {
        Bluetooth,
        WiFi
    }

    Object isRemoteDeviceAvailable(Continuation<? super Boolean> continuation);

    void sendData(Destination destination, int command);
}
