package vea.raceremote.features.remote_control.data;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: RemoteDeviceRepository.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/features/remote_control/data/RemoteDeviceRepository.kt")
public final class LiveLiterals$RemoteDeviceRepositoryKt {

    /* JADX INFO: renamed from: State$Int$class-RemoteDeviceRepository, reason: not valid java name */
    private static State<Integer> f1638State$Int$classRemoteDeviceRepository;

    /* JADX INFO: renamed from: State$String$arg-1$call-debug$fun-$anonymous$$arg-0$call-onFailure$val-result$fun-isRemoteDeviceAvailable$class-RemoteDeviceRepository, reason: not valid java name */
    private static State<String> f1639State$String$arg1$calldebug$fun$anonymous$$arg0$callonFailure$valresult$funisRemoteDeviceAvailable$classRemoteDeviceRepository;

    /* JADX INFO: renamed from: State$String$arg-1$call-debug-1$fun-$anonymous$$arg-0$call-onFailure$val-result$fun-isRemoteDeviceAvailable$class-RemoteDeviceRepository, reason: not valid java name */
    private static State<String> f1640State$String$arg1$calldebug1$fun$anonymous$$arg0$callonFailure$valresult$funisRemoteDeviceAvailable$classRemoteDeviceRepository;

    /* JADX INFO: renamed from: State$String$branch$when$arg-0$call-debug$fun-$anonymous$$arg-0$call-onFailure$val-result$fun-isRemoteDeviceAvailable$class-RemoteDeviceRepository, reason: not valid java name */
    private static State<String> f1641State$String$branch$when$arg0$calldebug$fun$anonymous$$arg0$callonFailure$valresult$funisRemoteDeviceAvailable$classRemoteDeviceRepository;
    public static final LiveLiterals$RemoteDeviceRepositoryKt INSTANCE = new LiveLiterals$RemoteDeviceRepositoryKt();

    /* JADX INFO: renamed from: String$branch$when$arg-0$call-debug$fun-$anonymous$$arg-0$call-onFailure$val-result$fun-isRemoteDeviceAvailable$class-RemoteDeviceRepository, reason: not valid java name */
    private static String f1644String$branch$when$arg0$calldebug$fun$anonymous$$arg0$callonFailure$valresult$funisRemoteDeviceAvailable$classRemoteDeviceRepository = "unknown failure";

    /* JADX INFO: renamed from: String$arg-1$call-debug$fun-$anonymous$$arg-0$call-onFailure$val-result$fun-isRemoteDeviceAvailable$class-RemoteDeviceRepository, reason: not valid java name */
    private static String f1642String$arg1$calldebug$fun$anonymous$$arg0$callonFailure$valresult$funisRemoteDeviceAvailable$classRemoteDeviceRepository = "WIFI_CONNECTION_TAG";

    /* JADX INFO: renamed from: String$arg-1$call-debug-1$fun-$anonymous$$arg-0$call-onFailure$val-result$fun-isRemoteDeviceAvailable$class-RemoteDeviceRepository, reason: not valid java name */
    private static String f1643String$arg1$calldebug1$fun$anonymous$$arg0$callonFailure$valresult$funisRemoteDeviceAvailable$classRemoteDeviceRepository = "WIFI_CONNECTION_TAG";

    /* JADX INFO: renamed from: Int$class-RemoteDeviceRepository, reason: not valid java name */
    private static int f1637Int$classRemoteDeviceRepository = 8;

    @LiveLiteralInfo(key = "Int$class-RemoteDeviceRepository", offset = -1)
    /* JADX INFO: renamed from: Int$class-RemoteDeviceRepository, reason: not valid java name */
    public final int m6782Int$classRemoteDeviceRepository() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1637Int$classRemoteDeviceRepository;
        }
        State<Integer> stateLiveLiteral = f1638State$Int$classRemoteDeviceRepository;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-RemoteDeviceRepository", Integer.valueOf(f1637Int$classRemoteDeviceRepository));
            f1638State$Int$classRemoteDeviceRepository = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "String$arg-1$call-debug$fun-$anonymous$$arg-0$call-onFailure$val-result$fun-isRemoteDeviceAvailable$class-RemoteDeviceRepository", offset = 964)
    /* JADX INFO: renamed from: String$arg-1$call-debug$fun-$anonymous$$arg-0$call-onFailure$val-result$fun-isRemoteDeviceAvailable$class-RemoteDeviceRepository, reason: not valid java name */
    public final String m6783String$arg1$calldebug$fun$anonymous$$arg0$callonFailure$valresult$funisRemoteDeviceAvailable$classRemoteDeviceRepository() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1642String$arg1$calldebug$fun$anonymous$$arg0$callonFailure$valresult$funisRemoteDeviceAvailable$classRemoteDeviceRepository;
        }
        State<String> stateLiveLiteral = f1639State$String$arg1$calldebug$fun$anonymous$$arg0$callonFailure$valresult$funisRemoteDeviceAvailable$classRemoteDeviceRepository;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-1$call-debug$fun-$anonymous$$arg-0$call-onFailure$val-result$fun-isRemoteDeviceAvailable$class-RemoteDeviceRepository", f1642String$arg1$calldebug$fun$anonymous$$arg0$callonFailure$valresult$funisRemoteDeviceAvailable$classRemoteDeviceRepository);
            f1639State$String$arg1$calldebug$fun$anonymous$$arg0$callonFailure$valresult$funisRemoteDeviceAvailable$classRemoteDeviceRepository = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-1$call-debug-1$fun-$anonymous$$arg-0$call-onFailure$val-result$fun-isRemoteDeviceAvailable$class-RemoteDeviceRepository", offset = 1034)
    /* JADX INFO: renamed from: String$arg-1$call-debug-1$fun-$anonymous$$arg-0$call-onFailure$val-result$fun-isRemoteDeviceAvailable$class-RemoteDeviceRepository, reason: not valid java name */
    public final String m6784String$arg1$calldebug1$fun$anonymous$$arg0$callonFailure$valresult$funisRemoteDeviceAvailable$classRemoteDeviceRepository() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1643String$arg1$calldebug1$fun$anonymous$$arg0$callonFailure$valresult$funisRemoteDeviceAvailable$classRemoteDeviceRepository;
        }
        State<String> stateLiveLiteral = f1640State$String$arg1$calldebug1$fun$anonymous$$arg0$callonFailure$valresult$funisRemoteDeviceAvailable$classRemoteDeviceRepository;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-1$call-debug-1$fun-$anonymous$$arg-0$call-onFailure$val-result$fun-isRemoteDeviceAvailable$class-RemoteDeviceRepository", f1643String$arg1$calldebug1$fun$anonymous$$arg0$callonFailure$valresult$funisRemoteDeviceAvailable$classRemoteDeviceRepository);
            f1640State$String$arg1$calldebug1$fun$anonymous$$arg0$callonFailure$valresult$funisRemoteDeviceAvailable$classRemoteDeviceRepository = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$branch$when$arg-0$call-debug$fun-$anonymous$$arg-0$call-onFailure$val-result$fun-isRemoteDeviceAvailable$class-RemoteDeviceRepository", offset = 945)
    /* JADX INFO: renamed from: String$branch$when$arg-0$call-debug$fun-$anonymous$$arg-0$call-onFailure$val-result$fun-isRemoteDeviceAvailable$class-RemoteDeviceRepository, reason: not valid java name */
    public final String m6785String$branch$when$arg0$calldebug$fun$anonymous$$arg0$callonFailure$valresult$funisRemoteDeviceAvailable$classRemoteDeviceRepository() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1644String$branch$when$arg0$calldebug$fun$anonymous$$arg0$callonFailure$valresult$funisRemoteDeviceAvailable$classRemoteDeviceRepository;
        }
        State<String> stateLiveLiteral = f1641State$String$branch$when$arg0$calldebug$fun$anonymous$$arg0$callonFailure$valresult$funisRemoteDeviceAvailable$classRemoteDeviceRepository;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$branch$when$arg-0$call-debug$fun-$anonymous$$arg-0$call-onFailure$val-result$fun-isRemoteDeviceAvailable$class-RemoteDeviceRepository", f1644String$branch$when$arg0$calldebug$fun$anonymous$$arg0$callonFailure$valresult$funisRemoteDeviceAvailable$classRemoteDeviceRepository);
            f1641State$String$branch$when$arg0$calldebug$fun$anonymous$$arg0$callonFailure$valresult$funisRemoteDeviceAvailable$classRemoteDeviceRepository = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
