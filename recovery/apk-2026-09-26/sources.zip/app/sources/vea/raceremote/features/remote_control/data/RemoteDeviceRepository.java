package vea.raceremote.features.remote_control.data;

import kotlin.ExceptionsKt;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.jvm.internal.Intrinsics;
import okio.ByteString;
import vea.raceremote.features.remote_control.utils.ICompoundCommandExtractor;
import vea.raceremote.network.RemoteDeviceApi;
import vea.raceremote.network.WebSocketApi;
import vea.raceremote.utils.LogKt;

/* JADX INFO: compiled from: RemoteDeviceRepository.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bJ\u0011\u0010\t\u001a\u00020\nH\u0096@ø\u0001\u0000¢\u0006\u0002\u0010\u000bJ\u0018\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0011H\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u0012"}, d2 = {"Lvea/raceremote/features/remote_control/data/RemoteDeviceRepository;", "Lvea/raceremote/features/remote_control/data/IRemoteDeviceRepository;", "extractor", "Lvea/raceremote/features/remote_control/utils/ICompoundCommandExtractor;", "remoteDeviceApi", "Lvea/raceremote/network/RemoteDeviceApi;", "webSocketApi", "Lvea/raceremote/network/WebSocketApi;", "(Lvea/raceremote/features/remote_control/utils/ICompoundCommandExtractor;Lvea/raceremote/network/RemoteDeviceApi;Lvea/raceremote/network/WebSocketApi;)V", "isRemoteDeviceAvailable", "", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendData", "", "destination", "Lvea/raceremote/features/remote_control/data/IRemoteDeviceRepository$Destination;", "command", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class RemoteDeviceRepository implements IRemoteDeviceRepository {
    public static final int $stable = LiveLiterals$RemoteDeviceRepositoryKt.INSTANCE.m6782Int$classRemoteDeviceRepository();
    private final ICompoundCommandExtractor extractor;
    private final RemoteDeviceApi remoteDeviceApi;
    private final WebSocketApi webSocketApi;

    /* JADX INFO: compiled from: RemoteDeviceRepository.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[IRemoteDeviceRepository.Destination.values().length];
            try {
                iArr[IRemoteDeviceRepository.Destination.WiFi.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                iArr[IRemoteDeviceRepository.Destination.Bluetooth.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    /* JADX INFO: renamed from: vea.raceremote.features.remote_control.data.RemoteDeviceRepository$isRemoteDeviceAvailable$1, reason: invalid class name */
    /* JADX INFO: compiled from: RemoteDeviceRepository.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "vea.raceremote.features.remote_control.data.RemoteDeviceRepository", f = "RemoteDeviceRepository.kt", i = {}, l = {28}, m = "isRemoteDeviceAvailable", n = {}, s = {})
    static final class AnonymousClass1 extends ContinuationImpl {
        int label;
        /* synthetic */ Object result;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return RemoteDeviceRepository.this.isRemoteDeviceAvailable(this);
        }
    }

    public RemoteDeviceRepository(ICompoundCommandExtractor extractor, RemoteDeviceApi remoteDeviceApi, WebSocketApi webSocketApi) {
        Intrinsics.checkNotNullParameter(extractor, "extractor");
        Intrinsics.checkNotNullParameter(remoteDeviceApi, "remoteDeviceApi");
        Intrinsics.checkNotNullParameter(webSocketApi, "webSocketApi");
        this.extractor = extractor;
        this.remoteDeviceApi = remoteDeviceApi;
        this.webSocketApi = webSocketApi;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0014  */
    @Override // vea.raceremote.features.remote_control.data.IRemoteDeviceRepository
    public Object isRemoteDeviceAvailable(Continuation<? super Boolean> continuation) {
        AnonymousClass1 anonymousClass1;
        Object result;
        if (continuation instanceof AnonymousClass1) {
            anonymousClass1 = (AnonymousClass1) continuation;
            if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                anonymousClass1.label -= Integer.MIN_VALUE;
            } else {
                anonymousClass1 = new AnonymousClass1(continuation);
            }
        } else {
            anonymousClass1 = new AnonymousClass1(continuation);
        }
        AnonymousClass1 anonymousClass2 = anonymousClass1;
        Object $result = anonymousClass2.result;
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        try {
            switch (anonymousClass2.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    Result.Companion companion = Result.INSTANCE;
                    RemoteDeviceApi remoteDeviceApi = this.remoteDeviceApi;
                    anonymousClass2.label = 1;
                    if (remoteDeviceApi.isRemoteDevice(anonymousClass2) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            result = Result.m4399constructorimpl(Unit.INSTANCE);
        } catch (Throwable th) {
            Result.Companion companion2 = Result.INSTANCE;
            result = Result.m4399constructorimpl(ResultKt.createFailure(th));
        }
        Throwable it = Result.m4402exceptionOrNullimpl(result);
        if (it != null) {
            String message = it.getMessage();
            if (message == null) {
                message = LiveLiterals$RemoteDeviceRepositoryKt.INSTANCE.m6785String$branch$when$arg0$calldebug$fun$anonymous$$arg0$callonFailure$valresult$funisRemoteDeviceAvailable$classRemoteDeviceRepository();
            }
            LogKt.debug(message, LiveLiterals$RemoteDeviceRepositoryKt.INSTANCE.m6783String$arg1$calldebug$fun$anonymous$$arg0$callonFailure$valresult$funisRemoteDeviceAvailable$classRemoteDeviceRepository());
            LogKt.debug(ExceptionsKt.stackTraceToString(it), LiveLiterals$RemoteDeviceRepositoryKt.INSTANCE.m6784String$arg1$calldebug1$fun$anonymous$$arg0$callonFailure$valresult$funisRemoteDeviceAvailable$classRemoteDeviceRepository());
        }
        return Boxing.boxBoolean(Result.m4406isSuccessimpl(result));
    }

    @Override // vea.raceremote.features.remote_control.data.IRemoteDeviceRepository
    public void sendData(IRemoteDeviceRepository.Destination destination, int command) {
        Intrinsics.checkNotNullParameter(destination, "destination");
        switch (WhenMappings.$EnumSwitchMapping$0[destination.ordinal()]) {
            case 1:
                WebSocketApi webSocketApi = this.webSocketApi;
                ByteString byteStringOf = ByteString.of(this.extractor.extractStartCommand(command), this.extractor.extractEndCommand(command));
                Intrinsics.checkNotNullExpressionValue(byteStringOf, "of(\n                    …nd)\n                    )");
                webSocketApi.sendMessage(byteStringOf);
                break;
        }
    }
}
