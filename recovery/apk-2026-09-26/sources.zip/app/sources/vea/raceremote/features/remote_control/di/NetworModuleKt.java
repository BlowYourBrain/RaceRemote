package vea.raceremote.features.remote_control.di;

import java.util.List;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import okhttp3.OkHttpClient;
import org.koin.core.definition.BeanDefinition;
import org.koin.core.definition.BeanDefinitionKt;
import org.koin.core.definition.Kind;
import org.koin.core.instance.SingleInstanceFactory;
import org.koin.core.module.Module;
import org.koin.core.parameter.ParametersHolder;
import org.koin.core.qualifier.Qualifier;
import org.koin.core.registry.ScopeRegistry;
import org.koin.core.scope.Scope;
import org.koin.dsl.ModuleKt;
import retrofit2.Retrofit;
import vea.raceremote.network.RemoteApiProvider;
import vea.raceremote.network.RemoteDeviceApi;
import vea.raceremote.network.WebSocketApi;

/* JADX INFO: compiled from: NetworModule.kt */
/* JADX INFO: loaded from: classes7.dex */
@Metadata(d1 = {"\u0000\u0010\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0004\u0010\u0005¨\u0006\u0006"}, d2 = {"BASE_URL", "", "networkModule", "Lorg/koin/core/module/Module;", "getNetworkModule", "()Lorg/koin/core/module/Module;", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class NetworModuleKt {
    private static final String BASE_URL = "http://192.168.1.100:80/";
    private static final Module networkModule = ModuleKt.module$default(false, new Function1<Module, Unit>() { // from class: vea.raceremote.features.remote_control.di.NetworModuleKt$networkModule$1
        @Override // kotlin.jvm.functions.Function1
        public /* bridge */ /* synthetic */ Unit invoke(Module module) {
            invoke2(module);
            return Unit.INSTANCE;
        }

        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
        public final void invoke2(Module $this$module) {
            Intrinsics.checkNotNullParameter($this$module, "$this$module");
            Function2 definition$iv = new Function2<Scope, ParametersHolder, Retrofit>() { // from class: vea.raceremote.features.remote_control.di.NetworModuleKt$networkModule$1.1
                @Override // kotlin.jvm.functions.Function2
                public final Retrofit invoke(Scope $this$single, ParametersHolder it) {
                    Intrinsics.checkNotNullParameter($this$single, "$this$single");
                    Intrinsics.checkNotNullParameter(it, "it");
                    Retrofit retrofitBuild = new Retrofit.Builder().client(new OkHttpClient.Builder().readTimeout(3L, TimeUnit.SECONDS).connectTimeout(3L, TimeUnit.SECONDS).build()).baseUrl("http://192.168.1.100:80/").build();
                    Intrinsics.checkNotNullExpressionValue(retrofitBuild, "Builder()\n            .c…URL)\n            .build()");
                    return retrofitBuild;
                }
            };
            Kind kind$iv$iv = Kind.Singleton;
            Qualifier scopeQualifier$iv$iv = ScopeRegistry.Companion.getRootScopeQualifier();
            List secondaryTypes$iv$iv = CollectionsKt.emptyList();
            BeanDefinition def$iv = new BeanDefinition(scopeQualifier$iv$iv, Reflection.getOrCreateKotlinClass(Retrofit.class), null, definition$iv, kind$iv$iv, secondaryTypes$iv$iv);
            String mapping$iv = BeanDefinitionKt.indexKey(def$iv.getPrimaryType(), null, ScopeRegistry.Companion.getRootScopeQualifier());
            SingleInstanceFactory<?> singleInstanceFactory = new SingleInstanceFactory<>(def$iv);
            Module.saveMapping$default($this$module, mapping$iv, singleInstanceFactory, false, 4, null);
            if ($this$module.getCreatedAtStart()) {
                $this$module.getEagerInstances().add(singleInstanceFactory);
            }
            new Pair($this$module, singleInstanceFactory);
            Function2 definition$iv2 = new Function2<Scope, ParametersHolder, RemoteDeviceApi>() { // from class: vea.raceremote.features.remote_control.di.NetworModuleKt$networkModule$1.2
                @Override // kotlin.jvm.functions.Function2
                public final RemoteDeviceApi invoke(Scope $this$single, ParametersHolder it) {
                    Intrinsics.checkNotNullParameter($this$single, "$this$single");
                    Intrinsics.checkNotNullParameter(it, "it");
                    return new RemoteApiProvider((Retrofit) $this$single.get(Reflection.getOrCreateKotlinClass(Retrofit.class), null, null)).provideRemoteDeviceApi();
                }
            };
            Kind kind$iv$iv2 = Kind.Singleton;
            Qualifier scopeQualifier$iv$iv2 = ScopeRegistry.Companion.getRootScopeQualifier();
            List secondaryTypes$iv$iv2 = CollectionsKt.emptyList();
            BeanDefinition def$iv2 = new BeanDefinition(scopeQualifier$iv$iv2, Reflection.getOrCreateKotlinClass(RemoteDeviceApi.class), null, definition$iv2, kind$iv$iv2, secondaryTypes$iv$iv2);
            String mapping$iv2 = BeanDefinitionKt.indexKey(def$iv2.getPrimaryType(), null, ScopeRegistry.Companion.getRootScopeQualifier());
            SingleInstanceFactory<?> singleInstanceFactory2 = new SingleInstanceFactory<>(def$iv2);
            Module.saveMapping$default($this$module, mapping$iv2, singleInstanceFactory2, false, 4, null);
            if ($this$module.getCreatedAtStart()) {
                $this$module.getEagerInstances().add(singleInstanceFactory2);
            }
            new Pair($this$module, singleInstanceFactory2);
            Function2 definition$iv3 = new Function2<Scope, ParametersHolder, WebSocketApi>() { // from class: vea.raceremote.features.remote_control.di.NetworModuleKt$networkModule$1.3
                @Override // kotlin.jvm.functions.Function2
                public final WebSocketApi invoke(Scope $this$single, ParametersHolder it) {
                    Intrinsics.checkNotNullParameter($this$single, "$this$single");
                    Intrinsics.checkNotNullParameter(it, "it");
                    return new WebSocketApi();
                }
            };
            Kind kind$iv$iv3 = Kind.Singleton;
            Qualifier scopeQualifier$iv$iv3 = ScopeRegistry.Companion.getRootScopeQualifier();
            List secondaryTypes$iv$iv3 = CollectionsKt.emptyList();
            BeanDefinition def$iv3 = new BeanDefinition(scopeQualifier$iv$iv3, Reflection.getOrCreateKotlinClass(WebSocketApi.class), null, definition$iv3, kind$iv$iv3, secondaryTypes$iv$iv3);
            String mapping$iv3 = BeanDefinitionKt.indexKey(def$iv3.getPrimaryType(), null, ScopeRegistry.Companion.getRootScopeQualifier());
            SingleInstanceFactory<?> singleInstanceFactory3 = new SingleInstanceFactory<>(def$iv3);
            Module.saveMapping$default($this$module, mapping$iv3, singleInstanceFactory3, false, 4, null);
            if ($this$module.getCreatedAtStart()) {
                $this$module.getEagerInstances().add(singleInstanceFactory3);
            }
            new Pair($this$module, singleInstanceFactory3);
        }
    }, 1, null);

    public static final Module getNetworkModule() {
        return networkModule;
    }
}
