package vea.raceremote.features.remote_control.di;

import android.content.Context;
import java.util.List;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KClass;
import org.koin.core.definition.BeanDefinition;
import org.koin.core.definition.BeanDefinitionKt;
import org.koin.core.definition.Kind;
import org.koin.core.instance.FactoryInstanceFactory;
import org.koin.core.instance.SingleInstanceFactory;
import org.koin.core.module.Module;
import org.koin.core.parameter.ParametersHolder;
import org.koin.core.qualifier.Qualifier;
import org.koin.core.registry.ScopeRegistry;
import org.koin.core.scope.Scope;
import org.koin.dsl.DefinitionBindingKt;
import org.koin.dsl.ModuleKt;
import vea.raceremote.features.remote_control.data.IRemoteDeviceRepository;
import vea.raceremote.features.remote_control.data.RemoteDeviceRepository;
import vea.raceremote.features.remote_control.presentation.ActionsViewModel;
import vea.raceremote.features.remote_control.presentation.IWifiNetworkFinder;
import vea.raceremote.features.remote_control.presentation.RemoteControlViewModel;
import vea.raceremote.features.remote_control.presentation.RemoteDeviceConnection;
import vea.raceremote.features.remote_control.presentation.mapper.EngineMapper;
import vea.raceremote.features.remote_control.presentation.mapper.IEngineMapper;
import vea.raceremote.features.remote_control.presentation.mapper.ISteeringWheelMapper;
import vea.raceremote.features.remote_control.presentation.mapper.SteeringWheelMapper;
import vea.raceremote.features.remote_control.utils.CompoundCommandCreator;
import vea.raceremote.features.remote_control.utils.CompoundCommandExtractor;
import vea.raceremote.features.remote_control.utils.ICompoundCommandCreator;
import vea.raceremote.features.remote_control.utils.ICompoundCommandExtractor;
import vea.raceremote.network.RemoteDeviceApi;
import vea.raceremote.network.WebSocketApi;
import vea.raceremote.utils.bluetooth.IBluetoothConnection;
import vea.raceremote.utils.sidepanel.ISidePanelActionProducer;
import vea.raceremote.utils.sidepanel.ISidePanelActionProvider;
import vea.raceremote.utils.sidepanel.SidePanelActionProvider;

/* JADX INFO: compiled from: RemoteControlModule.kt */
/* JADX INFO: loaded from: classes7.dex */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\"\u0011\u0010\u0000\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"remoteControlModule", "Lorg/koin/core/module/Module;", "getRemoteControlModule", "()Lorg/koin/core/module/Module;", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class RemoteControlModuleKt {
    private static final Module remoteControlModule = ModuleKt.module$default(false, new Function1<Module, Unit>() { // from class: vea.raceremote.features.remote_control.di.RemoteControlModuleKt$remoteControlModule$1
        @Override // kotlin.jvm.functions.Function1
        public /* bridge */ /* synthetic */ Unit invoke(Module module) {
            invoke2(module);
            return Unit.INSTANCE;
        }

        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
        public final void invoke2(Module $this$module) {
            Intrinsics.checkNotNullParameter($this$module, "$this$module");
            Function2 definition$iv = new Function2<Scope, ParametersHolder, RemoteDeviceConnection>() { // from class: vea.raceremote.features.remote_control.di.RemoteControlModuleKt$remoteControlModule$1.1
                @Override // kotlin.jvm.functions.Function2
                public final RemoteDeviceConnection invoke(Scope $this$factory, ParametersHolder it) {
                    Intrinsics.checkNotNullParameter($this$factory, "$this$factory");
                    Intrinsics.checkNotNullParameter(it, "it");
                    return new RemoteDeviceConnection();
                }
            };
            Qualifier scopeQualifier$iv$iv = ScopeRegistry.Companion.getRootScopeQualifier();
            Kind kind$iv$iv$iv = Kind.Factory;
            List secondaryTypes$iv$iv$iv = CollectionsKt.emptyList();
            BeanDefinition def$iv$iv = new BeanDefinition(scopeQualifier$iv$iv, Reflection.getOrCreateKotlinClass(RemoteDeviceConnection.class), null, definition$iv, kind$iv$iv$iv, secondaryTypes$iv$iv$iv);
            String mapping$iv$iv = BeanDefinitionKt.indexKey(def$iv$iv.getPrimaryType(), null, scopeQualifier$iv$iv);
            FactoryInstanceFactory instanceFactory$iv$iv = new FactoryInstanceFactory(def$iv$iv);
            Module.saveMapping$default($this$module, mapping$iv$iv, instanceFactory$iv$iv, false, 4, null);
            new Pair($this$module, instanceFactory$iv$iv);
            Function2 definition$iv2 = new Function2<Scope, ParametersHolder, IEngineMapper>() { // from class: vea.raceremote.features.remote_control.di.RemoteControlModuleKt$remoteControlModule$1.2
                @Override // kotlin.jvm.functions.Function2
                public final IEngineMapper invoke(Scope $this$factory, ParametersHolder it) {
                    Intrinsics.checkNotNullParameter($this$factory, "$this$factory");
                    Intrinsics.checkNotNullParameter(it, "it");
                    return new EngineMapper();
                }
            };
            Qualifier scopeQualifier$iv$iv2 = ScopeRegistry.Companion.getRootScopeQualifier();
            Kind kind$iv$iv$iv2 = Kind.Factory;
            List secondaryTypes$iv$iv$iv2 = CollectionsKt.emptyList();
            BeanDefinition def$iv$iv2 = new BeanDefinition(scopeQualifier$iv$iv2, Reflection.getOrCreateKotlinClass(IEngineMapper.class), null, definition$iv2, kind$iv$iv$iv2, secondaryTypes$iv$iv$iv2);
            String mapping$iv$iv2 = BeanDefinitionKt.indexKey(def$iv$iv2.getPrimaryType(), null, scopeQualifier$iv$iv2);
            FactoryInstanceFactory instanceFactory$iv$iv2 = new FactoryInstanceFactory(def$iv$iv2);
            Module.saveMapping$default($this$module, mapping$iv$iv2, instanceFactory$iv$iv2, false, 4, null);
            new Pair($this$module, instanceFactory$iv$iv2);
            Function2 definition$iv3 = new Function2<Scope, ParametersHolder, ISteeringWheelMapper>() { // from class: vea.raceremote.features.remote_control.di.RemoteControlModuleKt$remoteControlModule$1.3
                @Override // kotlin.jvm.functions.Function2
                public final ISteeringWheelMapper invoke(Scope $this$factory, ParametersHolder it) {
                    Intrinsics.checkNotNullParameter($this$factory, "$this$factory");
                    Intrinsics.checkNotNullParameter(it, "it");
                    return new SteeringWheelMapper();
                }
            };
            Qualifier scopeQualifier$iv$iv3 = ScopeRegistry.Companion.getRootScopeQualifier();
            Kind kind$iv$iv$iv3 = Kind.Factory;
            List secondaryTypes$iv$iv$iv3 = CollectionsKt.emptyList();
            BeanDefinition def$iv$iv3 = new BeanDefinition(scopeQualifier$iv$iv3, Reflection.getOrCreateKotlinClass(ISteeringWheelMapper.class), null, definition$iv3, kind$iv$iv$iv3, secondaryTypes$iv$iv$iv3);
            String mapping$iv$iv3 = BeanDefinitionKt.indexKey(def$iv$iv3.getPrimaryType(), null, scopeQualifier$iv$iv3);
            FactoryInstanceFactory instanceFactory$iv$iv3 = new FactoryInstanceFactory(def$iv$iv3);
            Module.saveMapping$default($this$module, mapping$iv$iv3, instanceFactory$iv$iv3, false, 4, null);
            new Pair($this$module, instanceFactory$iv$iv3);
            Function2 definition$iv4 = new Function2<Scope, ParametersHolder, ICompoundCommandCreator>() { // from class: vea.raceremote.features.remote_control.di.RemoteControlModuleKt$remoteControlModule$1.4
                @Override // kotlin.jvm.functions.Function2
                public final ICompoundCommandCreator invoke(Scope $this$factory, ParametersHolder it) {
                    Intrinsics.checkNotNullParameter($this$factory, "$this$factory");
                    Intrinsics.checkNotNullParameter(it, "it");
                    return new CompoundCommandCreator();
                }
            };
            Qualifier scopeQualifier$iv$iv4 = ScopeRegistry.Companion.getRootScopeQualifier();
            Kind kind$iv$iv$iv4 = Kind.Factory;
            List secondaryTypes$iv$iv$iv4 = CollectionsKt.emptyList();
            BeanDefinition def$iv$iv4 = new BeanDefinition(scopeQualifier$iv$iv4, Reflection.getOrCreateKotlinClass(ICompoundCommandCreator.class), null, definition$iv4, kind$iv$iv$iv4, secondaryTypes$iv$iv$iv4);
            String mapping$iv$iv4 = BeanDefinitionKt.indexKey(def$iv$iv4.getPrimaryType(), null, scopeQualifier$iv$iv4);
            FactoryInstanceFactory instanceFactory$iv$iv4 = new FactoryInstanceFactory(def$iv$iv4);
            Module.saveMapping$default($this$module, mapping$iv$iv4, instanceFactory$iv$iv4, false, 4, null);
            new Pair($this$module, instanceFactory$iv$iv4);
            Function2 definition$iv5 = new Function2<Scope, ParametersHolder, ICompoundCommandExtractor>() { // from class: vea.raceremote.features.remote_control.di.RemoteControlModuleKt$remoteControlModule$1.5
                @Override // kotlin.jvm.functions.Function2
                public final ICompoundCommandExtractor invoke(Scope $this$factory, ParametersHolder it) {
                    Intrinsics.checkNotNullParameter($this$factory, "$this$factory");
                    Intrinsics.checkNotNullParameter(it, "it");
                    return new CompoundCommandExtractor();
                }
            };
            Qualifier scopeQualifier$iv$iv5 = ScopeRegistry.Companion.getRootScopeQualifier();
            Kind kind$iv$iv$iv5 = Kind.Factory;
            List secondaryTypes$iv$iv$iv5 = CollectionsKt.emptyList();
            BeanDefinition def$iv$iv5 = new BeanDefinition(scopeQualifier$iv$iv5, Reflection.getOrCreateKotlinClass(ICompoundCommandExtractor.class), null, definition$iv5, kind$iv$iv$iv5, secondaryTypes$iv$iv$iv5);
            String mapping$iv$iv5 = BeanDefinitionKt.indexKey(def$iv$iv5.getPrimaryType(), null, scopeQualifier$iv$iv5);
            FactoryInstanceFactory instanceFactory$iv$iv5 = new FactoryInstanceFactory(def$iv$iv5);
            Module.saveMapping$default($this$module, mapping$iv$iv5, instanceFactory$iv$iv5, false, 4, null);
            new Pair($this$module, instanceFactory$iv$iv5);
            Function2 definition$iv6 = new Function2<Scope, ParametersHolder, IRemoteDeviceRepository>() { // from class: vea.raceremote.features.remote_control.di.RemoteControlModuleKt$remoteControlModule$1.6
                @Override // kotlin.jvm.functions.Function2
                public final IRemoteDeviceRepository invoke(Scope $this$factory, ParametersHolder it) {
                    Intrinsics.checkNotNullParameter($this$factory, "$this$factory");
                    Intrinsics.checkNotNullParameter(it, "it");
                    return new RemoteDeviceRepository((ICompoundCommandExtractor) $this$factory.get(Reflection.getOrCreateKotlinClass(ICompoundCommandExtractor.class), null, null), (RemoteDeviceApi) $this$factory.get(Reflection.getOrCreateKotlinClass(RemoteDeviceApi.class), null, null), (WebSocketApi) $this$factory.get(Reflection.getOrCreateKotlinClass(WebSocketApi.class), null, null));
                }
            };
            Qualifier scopeQualifier$iv$iv6 = ScopeRegistry.Companion.getRootScopeQualifier();
            Kind kind$iv$iv$iv6 = Kind.Factory;
            List secondaryTypes$iv$iv$iv6 = CollectionsKt.emptyList();
            BeanDefinition def$iv$iv6 = new BeanDefinition(scopeQualifier$iv$iv6, Reflection.getOrCreateKotlinClass(IRemoteDeviceRepository.class), null, definition$iv6, kind$iv$iv$iv6, secondaryTypes$iv$iv$iv6);
            String mapping$iv$iv6 = BeanDefinitionKt.indexKey(def$iv$iv6.getPrimaryType(), null, scopeQualifier$iv$iv6);
            FactoryInstanceFactory instanceFactory$iv$iv6 = new FactoryInstanceFactory(def$iv$iv6);
            Module.saveMapping$default($this$module, mapping$iv$iv6, instanceFactory$iv$iv6, false, 4, null);
            new Pair($this$module, instanceFactory$iv$iv6);
            Function2 definition$iv7 = new Function2<Scope, ParametersHolder, SidePanelActionProvider>() { // from class: vea.raceremote.features.remote_control.di.RemoteControlModuleKt$remoteControlModule$1.7
                @Override // kotlin.jvm.functions.Function2
                public final SidePanelActionProvider invoke(Scope $this$single, ParametersHolder it) {
                    Intrinsics.checkNotNullParameter($this$single, "$this$single");
                    Intrinsics.checkNotNullParameter(it, "it");
                    return new SidePanelActionProvider();
                }
            };
            Function2 definition$iv8 = definition$iv7;
            Kind kind$iv$iv = Kind.Singleton;
            Qualifier scopeQualifier$iv$iv7 = ScopeRegistry.Companion.getRootScopeQualifier();
            List secondaryTypes$iv$iv = CollectionsKt.emptyList();
            BeanDefinition def$iv = new BeanDefinition(scopeQualifier$iv$iv7, Reflection.getOrCreateKotlinClass(SidePanelActionProvider.class), null, definition$iv8, kind$iv$iv, secondaryTypes$iv$iv);
            String mapping$iv = BeanDefinitionKt.indexKey(def$iv.getPrimaryType(), null, ScopeRegistry.Companion.getRootScopeQualifier());
            SingleInstanceFactory<?> singleInstanceFactory = new SingleInstanceFactory<>(def$iv);
            Module.saveMapping$default($this$module, mapping$iv, singleInstanceFactory, false, 4, null);
            if ($this$module.getCreatedAtStart()) {
                $this$module.getEagerInstances().add(singleInstanceFactory);
            }
            DefinitionBindingKt.binds(new Pair($this$module, singleInstanceFactory), new KClass[]{Reflection.getOrCreateKotlinClass(ISidePanelActionProducer.class), Reflection.getOrCreateKotlinClass(ISidePanelActionProvider.class)});
            Function2 definition$iv9 = new Function2<Scope, ParametersHolder, ActionsViewModel>() { // from class: vea.raceremote.features.remote_control.di.RemoteControlModuleKt$remoteControlModule$1.8
                @Override // kotlin.jvm.functions.Function2
                public final ActionsViewModel invoke(Scope $this$single, ParametersHolder it) {
                    Intrinsics.checkNotNullParameter($this$single, "$this$single");
                    Intrinsics.checkNotNullParameter(it, "it");
                    return new ActionsViewModel((Context) $this$single.get(Reflection.getOrCreateKotlinClass(Context.class), null, null), (IWifiNetworkFinder) $this$single.get(Reflection.getOrCreateKotlinClass(IWifiNetworkFinder.class), null, null), (IBluetoothConnection) $this$single.get(Reflection.getOrCreateKotlinClass(IBluetoothConnection.class), null, null), (ISidePanelActionProvider) $this$single.get(Reflection.getOrCreateKotlinClass(ISidePanelActionProvider.class), null, null), (ISidePanelActionProducer) $this$single.get(Reflection.getOrCreateKotlinClass(ISidePanelActionProducer.class), null, null));
                }
            };
            Kind kind$iv$iv2 = Kind.Singleton;
            Qualifier scopeQualifier$iv$iv8 = ScopeRegistry.Companion.getRootScopeQualifier();
            List secondaryTypes$iv$iv2 = CollectionsKt.emptyList();
            BeanDefinition def$iv2 = new BeanDefinition(scopeQualifier$iv$iv8, Reflection.getOrCreateKotlinClass(ActionsViewModel.class), null, definition$iv9, kind$iv$iv2, secondaryTypes$iv$iv2);
            String mapping$iv2 = BeanDefinitionKt.indexKey(def$iv2.getPrimaryType(), null, ScopeRegistry.Companion.getRootScopeQualifier());
            SingleInstanceFactory<?> singleInstanceFactory2 = new SingleInstanceFactory<>(def$iv2);
            Module.saveMapping$default($this$module, mapping$iv2, singleInstanceFactory2, false, 4, null);
            if ($this$module.getCreatedAtStart()) {
                $this$module.getEagerInstances().add(singleInstanceFactory2);
            }
            new Pair($this$module, singleInstanceFactory2);
            Function2 definition$iv10 = new Function2<Scope, ParametersHolder, RemoteControlViewModel>() { // from class: vea.raceremote.features.remote_control.di.RemoteControlModuleKt$remoteControlModule$1.9
                @Override // kotlin.jvm.functions.Function2
                public final RemoteControlViewModel invoke(Scope $this$viewModel, ParametersHolder it) {
                    Intrinsics.checkNotNullParameter($this$viewModel, "$this$viewModel");
                    Intrinsics.checkNotNullParameter(it, "it");
                    return new RemoteControlViewModel((IEngineMapper) $this$viewModel.get(Reflection.getOrCreateKotlinClass(IEngineMapper.class), null, null), (ISteeringWheelMapper) $this$viewModel.get(Reflection.getOrCreateKotlinClass(ISteeringWheelMapper.class), null, null), (IBluetoothConnection) $this$viewModel.get(Reflection.getOrCreateKotlinClass(IBluetoothConnection.class), null, null), (ICompoundCommandCreator) $this$viewModel.get(Reflection.getOrCreateKotlinClass(ICompoundCommandCreator.class), null, null), (IRemoteDeviceRepository) $this$viewModel.get(Reflection.getOrCreateKotlinClass(IRemoteDeviceRepository.class), null, null));
                }
            };
            Qualifier scopeQualifier$iv$iv$iv = ScopeRegistry.Companion.getRootScopeQualifier();
            Kind kind$iv$iv$iv$iv = Kind.Factory;
            List secondaryTypes$iv$iv$iv$iv = CollectionsKt.emptyList();
            BeanDefinition def$iv$iv$iv = new BeanDefinition(scopeQualifier$iv$iv$iv, Reflection.getOrCreateKotlinClass(RemoteControlViewModel.class), null, definition$iv10, kind$iv$iv$iv$iv, secondaryTypes$iv$iv$iv$iv);
            String mapping$iv$iv$iv = BeanDefinitionKt.indexKey(def$iv$iv$iv.getPrimaryType(), null, scopeQualifier$iv$iv$iv);
            FactoryInstanceFactory instanceFactory$iv$iv$iv = new FactoryInstanceFactory(def$iv$iv$iv);
            Module.saveMapping$default($this$module, mapping$iv$iv$iv, instanceFactory$iv$iv$iv, false, 4, null);
            new Pair($this$module, instanceFactory$iv$iv$iv);
        }
    }, 1, null);

    public static final Module getRemoteControlModule() {
        return remoteControlModule;
    }
}
