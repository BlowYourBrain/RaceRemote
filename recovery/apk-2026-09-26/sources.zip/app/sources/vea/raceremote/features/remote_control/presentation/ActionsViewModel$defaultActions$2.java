package vea.raceremote.features.remote_control.presentation;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.FunctionReferenceImpl;

/* JADX INFO: compiled from: ActionsViewModel.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
/* synthetic */ class ActionsViewModel$defaultActions$2 extends FunctionReferenceImpl implements Function0<Unit> {
    ActionsViewModel$defaultActions$2(Object obj) {
        super(0, obj, ActionsViewModel.class, "onWifiClick", "onWifiClick()V", 0);
    }

    @Override // kotlin.jvm.functions.Function0
    public /* bridge */ /* synthetic */ Unit invoke() {
        invoke2();
        return Unit.INSTANCE;
    }

    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
    public final void invoke2() {
        ((ActionsViewModel) this.receiver).onWifiClick();
    }
}
