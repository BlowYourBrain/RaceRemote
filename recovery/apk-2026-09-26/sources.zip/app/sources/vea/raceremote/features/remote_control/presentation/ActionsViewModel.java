package vea.raceremote.features.remote_control.presentation;

import android.content.Context;
import androidx.compose.ui.unit.Dp;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelKt;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.channels.Channel;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlowKt;
import vea.raceremote.features.remote_control.presentation.model.Action;
import vea.raceremote.features.remote_control.presentation.model.RemoteDevice;
import vea.raceremote.ui.views.DotsState;
import vea.raceremote.utils.FlowKt;
import vea.raceremote.utils.LogKt;
import vea.raceremote.utils.bluetooth.BluetoothUtilsKt;
import vea.raceremote.utils.bluetooth.IBluetoothConnection;
import vea.raceremote.utils.sidepanel.ISidePanelActionProducer;
import vea.raceremote.utils.sidepanel.ISidePanelActionProvider;
import vea.raceremote.utils.sidepanel.ISidePanelActionProviderKt;
import vea.raceremote.utils.wifi.WiFiUtilsKt;

/* JADX INFO: compiled from: ActionsViewModel.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u0000~\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\f\b\u0007\u0018\u0000 =2\u00020\u0001:\u0001=B-\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\u000b¢\u0006\u0002\u0010\fJ\b\u0010,\u001a\u00020-H\u0002J\b\u0010.\u001a\u00020-H\u0002J\u000e\u0010/\u001a\u00020\u00152\u0006\u00100\u001a\u00020\u001bJ\u0010\u00101\u001a\u0002022\u0006\u00103\u001a\u00020\u001bH\u0002J\b\u00104\u001a\u00020-H\u0002J\u000e\u00105\u001a\u00020\u00152\u0006\u00106\u001a\u00020-J\b\u00107\u001a\u00020\u0015H\u0002J\b\u00108\u001a\u00020\u0015H\u0002J\b\u00109\u001a\u00020\u0015H\u0002J\u0018\u0010:\u001a\u00020\u00152\u0006\u0010;\u001a\u00020\u00132\u0006\u0010<\u001a\u000202H\u0002R\u001a\u0010\r\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00100\u000f0\u000eX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00130\u0012X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00150\u0012X\u0082\u0004¢\u0006\u0002\n\u0000R\u001d\u0010\u0016\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00100\u000f0\u0017¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u001b\u0010\u001a\u001a\u00020\u001b8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u001e\u0010\u001f\u001a\u0004\b\u001c\u0010\u001dR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010 \u001a\b\u0012\u0004\u0012\u00020\u00100\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\"X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020$X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010%\u001a\b\u0012\u0004\u0012\u00020\u00130\u0017¢\u0006\b\n\u0000\u001a\u0004\b&\u0010\u0019R\u0017\u0010'\u001a\b\u0012\u0004\u0012\u00020\u00150\u0017¢\u0006\b\n\u0000\u001a\u0004\b(\u0010\u0019R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010)\u001a\n +*\u0004\u0018\u00010*0*X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006>"}, d2 = {"Lvea/raceremote/features/remote_control/presentation/ActionsViewModel;", "Landroidx/lifecycle/ViewModel;", "context", "Landroid/content/Context;", "wifiNetwork", "Lvea/raceremote/features/remote_control/presentation/IWifiNetworkFinder;", "bluetoothConnection", "Lvea/raceremote/utils/bluetooth/IBluetoothConnection;", "sidePanelActionProvider", "Lvea/raceremote/utils/sidepanel/ISidePanelActionProvider;", "sidePanelActionProducer", "Lvea/raceremote/utils/sidepanel/ISidePanelActionProducer;", "(Landroid/content/Context;Lvea/raceremote/features/remote_control/presentation/IWifiNetworkFinder;Lvea/raceremote/utils/bluetooth/IBluetoothConnection;Lvea/raceremote/utils/sidepanel/ISidePanelActionProvider;Lvea/raceremote/utils/sidepanel/ISidePanelActionProducer;)V", "_actions", "Lkotlinx/coroutines/flow/MutableStateFlow;", "", "Lvea/raceremote/features/remote_control/presentation/model/Action;", "_remoteDevice", "Lkotlinx/coroutines/channels/Channel;", "Lvea/raceremote/features/remote_control/presentation/model/RemoteDevice;", "_requestBluetoothPermissions", "", "actions", "Lkotlinx/coroutines/flow/Flow;", "getActions", "()Lkotlinx/coroutines/flow/Flow;", "connected", "", "getConnected", "()Ljava/lang/String;", "connected$delegate", "Lkotlin/Lazy;", "defaultActions", "idleDotsState", "Lvea/raceremote/ui/views/DotsState$Idle;", "loadingDotsState", "Lvea/raceremote/ui/views/DotsState$Loading;", "remoteDevice", "getRemoteDevice", "requestBluetoothPermissions", "getRequestBluetoothPermissions", "uuid", "Ljava/util/UUID;", "kotlin.jvm.PlatformType", "checkBluetoothGranted", "", "checkWifiGranted", "connectBluetooth", "macAddress", "createDotsTextState", "Lvea/raceremote/ui/views/DotsState;", "text", "hasBluetoothConnection", "isOpened", "value", "onBluetoothClick", "onSettingsClick", "onWifiClick", "updateState", "device", "dotsState", "Companion", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class ActionsViewModel extends ViewModel {
    private static final int BLUETOOTH_POSITION = 0;
    private static final int DOTS_HEIGHT = 14;
    private static final int DOTS_TEXT_HEIGHT = 12;
    private static final String UUID_STR = "4ab19e4e-e6c1-43ba-b9cd-0b19777da670";
    private static final int WIFI_POSITION = 1;
    private final MutableStateFlow<List<Action>> _actions;
    private final Channel<RemoteDevice> _remoteDevice;
    private final Channel<Unit> _requestBluetoothPermissions;
    private final Flow<List<Action>> actions;
    private final IBluetoothConnection bluetoothConnection;

    /* JADX INFO: renamed from: connected$delegate, reason: from kotlin metadata */
    private final Lazy connected;
    private final Context context;
    private final List<Action> defaultActions;
    private final DotsState.Idle idleDotsState;
    private final DotsState.Loading loadingDotsState;
    private final Flow<RemoteDevice> remoteDevice;
    private final Flow<Unit> requestBluetoothPermissions;
    private final ISidePanelActionProducer sidePanelActionProducer;
    private final ISidePanelActionProvider sidePanelActionProvider;
    private final UUID uuid;
    private final IWifiNetworkFinder wifiNetwork;
    public static final int $stable = LiveLiterals$ActionsViewModelKt.INSTANCE.m6791Int$classActionsViewModel();

    /* JADX INFO: compiled from: ActionsViewModel.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[RemoteDevice.values().length];
            try {
                iArr[RemoteDevice.Bluetooth.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                iArr[RemoteDevice.WIFI.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    public ActionsViewModel(Context context, IWifiNetworkFinder wifiNetwork, IBluetoothConnection bluetoothConnection, ISidePanelActionProvider sidePanelActionProvider, ISidePanelActionProducer sidePanelActionProducer) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(wifiNetwork, "wifiNetwork");
        Intrinsics.checkNotNullParameter(bluetoothConnection, "bluetoothConnection");
        Intrinsics.checkNotNullParameter(sidePanelActionProvider, "sidePanelActionProvider");
        Intrinsics.checkNotNullParameter(sidePanelActionProducer, "sidePanelActionProducer");
        this.context = context;
        this.wifiNetwork = wifiNetwork;
        this.bluetoothConnection = bluetoothConnection;
        this.sidePanelActionProvider = sidePanelActionProvider;
        this.sidePanelActionProducer = sidePanelActionProducer;
        this.loadingDotsState = new DotsState.Loading(Dp.m4046constructorimpl(14), 0, null, 0.0f, 0, 30, null);
        DotsState.Idle idle = new DotsState.Idle(Dp.m4046constructorimpl(14));
        this.idleDotsState = idle;
        List<Action> listListOf = CollectionsKt.listOf((Object[]) new Action[]{new Action(2131165322, new ActionsViewModel$defaultActions$1(this), idle), new Action(2131165330, new ActionsViewModel$defaultActions$2(this), idle), new Action(2131165329, new ActionsViewModel$defaultActions$3(this), idle)});
        this.defaultActions = listListOf;
        this.uuid = UUID.fromString("4ab19e4e-e6c1-43ba-b9cd-0b19777da670");
        MutableStateFlow<List<Action>> MutableStateFlow = StateFlowKt.MutableStateFlow(listListOf);
        this._actions = MutableStateFlow;
        Channel<RemoteDevice> channelSingleEventChannel$default = FlowKt.singleEventChannel$default(null, null, 3, null);
        this._remoteDevice = channelSingleEventChannel$default;
        Channel<Unit> channelSingleEventChannel$default2 = FlowKt.singleEventChannel$default(null, null, 3, null);
        this._requestBluetoothPermissions = channelSingleEventChannel$default2;
        this.connected = LazyKt.lazy(new Function0<String>() { // from class: vea.raceremote.features.remote_control.presentation.ActionsViewModel$connected$2
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public final String invoke() {
                return this.this$0.context.getResources().getString(2131689518);
            }
        });
        this.remoteDevice = kotlinx.coroutines.flow.FlowKt.receiveAsFlow(channelSingleEventChannel$default);
        this.requestBluetoothPermissions = kotlinx.coroutines.flow.FlowKt.receiveAsFlow(channelSingleEventChannel$default2);
        this.actions = kotlinx.coroutines.flow.FlowKt.asStateFlow(MutableStateFlow);
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new AnonymousClass1(null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String getConnected() {
        return (String) getValue();
    }

    public final Flow<RemoteDevice> getRemoteDevice() {
        return this.remoteDevice;
    }

    public final Flow<Unit> getRequestBluetoothPermissions() {
        return this.requestBluetoothPermissions;
    }

    public final Flow<List<Action>> getActions() {
        return this.actions;
    }

    /* JADX INFO: renamed from: vea.raceremote.features.remote_control.presentation.ActionsViewModel$1, reason: invalid class name */
    /* JADX INFO: compiled from: ActionsViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\u008a@"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "vea.raceremote.features.remote_control.presentation.ActionsViewModel$1", f = "ActionsViewModel.kt", i = {}, l = {85}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return ActionsViewModel.this.new AnonymousClass1(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    Flow<IWifiNetworkFinder.NetworkState> networkState = ActionsViewModel.this.wifiNetwork.getNetworkState();
                    final ActionsViewModel actionsViewModel = ActionsViewModel.this;
                    this.label = 1;
                    if (networkState.collect(new FlowCollector<IWifiNetworkFinder.NetworkState>() { // from class: vea.raceremote.features.remote_control.presentation.ActionsViewModel.1.1

                        /* JADX INFO: renamed from: vea.raceremote.features.remote_control.presentation.ActionsViewModel$1$1$WhenMappings */
                        /* JADX INFO: compiled from: ActionsViewModel.kt */
                        @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
                        public /* synthetic */ class WhenMappings {
                            public static final /* synthetic */ int[] $EnumSwitchMapping$0;

                            static {
                                int[] iArr = new int[IWifiNetworkFinder.NetworkState.values().length];
                                try {
                                    iArr[IWifiNetworkFinder.NetworkState.Loading.ordinal()] = 1;
                                } catch (NoSuchFieldError e) {
                                }
                                try {
                                    iArr[IWifiNetworkFinder.NetworkState.Mismatch.ordinal()] = 2;
                                } catch (NoSuchFieldError e2) {
                                }
                                try {
                                    iArr[IWifiNetworkFinder.NetworkState.Match.ordinal()] = 3;
                                } catch (NoSuchFieldError e3) {
                                }
                                $EnumSwitchMapping$0 = iArr;
                            }
                        }

                        @Override // kotlinx.coroutines.flow.FlowCollector
                        public /* bridge */ /* synthetic */ Object emit(IWifiNetworkFinder.NetworkState networkState2, Continuation $completion) {
                            return emit2(networkState2, (Continuation<? super Unit>) $completion);
                        }

                        /* JADX INFO: renamed from: emit, reason: avoid collision after fix types in other method */
                        public final Object emit2(IWifiNetworkFinder.NetworkState state, Continuation<? super Unit> continuation) {
                            switch (WhenMappings.$EnumSwitchMapping$0[state.ordinal()]) {
                                case 1:
                                    actionsViewModel.updateState(RemoteDevice.WIFI, actionsViewModel.loadingDotsState);
                                    break;
                                case 2:
                                    actionsViewModel.updateState(RemoteDevice.WIFI, actionsViewModel.idleDotsState);
                                    break;
                                case 3:
                                    ActionsViewModel actionsViewModel2 = actionsViewModel;
                                    RemoteDevice remoteDevice = RemoteDevice.WIFI;
                                    ActionsViewModel actionsViewModel3 = actionsViewModel;
                                    String connected = actionsViewModel3.getConnected();
                                    Intrinsics.checkNotNullExpressionValue(connected, "connected");
                                    actionsViewModel2.updateState(remoteDevice, actionsViewModel3.createDotsTextState(connected));
                                    break;
                            }
                            return Unit.INSTANCE;
                        }
                    }, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    public final void connectBluetooth(String macAddress) {
        Intrinsics.checkNotNullParameter(macAddress, "macAddress");
        LogKt.debug$default(LiveLiterals$ActionsViewModelKt.INSTANCE.m6792String$0$str$arg0$calldebug$funconnectBluetooth$classActionsViewModel() + macAddress, null, 2, null);
        if (BluetoothUtilsKt.hasBluetoothPermissions(this.context)) {
            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C05281(macAddress, null), 3, null);
        }
    }

    /* JADX INFO: renamed from: vea.raceremote.features.remote_control.presentation.ActionsViewModel$connectBluetooth$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: ActionsViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\u008a@"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "vea.raceremote.features.remote_control.presentation.ActionsViewModel$connectBluetooth$1", f = "ActionsViewModel.kt", i = {}, l = {111}, m = "invokeSuspend", n = {}, s = {})
    static final class C05281 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $macAddress;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C05281(String str, Continuation<? super C05281> continuation) {
            super(2, continuation);
            this.$macAddress = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return ActionsViewModel.this.new C05281(this.$macAddress, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C05281) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            C05281 c05281;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    c05281 = this;
                    ActionsViewModel.this.updateState(RemoteDevice.Bluetooth, ActionsViewModel.this.loadingDotsState);
                    IBluetoothConnection iBluetoothConnection = ActionsViewModel.this.bluetoothConnection;
                    Context context = ActionsViewModel.this.context;
                    String str = c05281.$macAddress;
                    UUID uuid = ActionsViewModel.this.uuid;
                    Intrinsics.checkNotNullExpressionValue(uuid, "uuid");
                    c05281.label = 1;
                    Object objConnectWithDevice = iBluetoothConnection.connectWithDevice(context, str, uuid, c05281);
                    if (objConnectWithDevice == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    $result = objConnectWithDevice;
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    c05281 = this;
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            IBluetoothConnection.Connection connection = (IBluetoothConnection.Connection) $result;
            if (connection instanceof IBluetoothConnection.Connection.Success) {
                String deviceName = ((IBluetoothConnection.Connection.Success) connection).getName();
                ActionsViewModel.this.updateState(RemoteDevice.Bluetooth, ActionsViewModel.this.createDotsTextState(deviceName));
            } else if (connection instanceof IBluetoothConnection.Connection.Error) {
                LogKt.debug$default(LiveLiterals$ActionsViewModelKt.INSTANCE.m6794String$arg0$calldebug$branch1$when$fun$anonymous$$arg2$calllaunch$funconnectBluetooth$classActionsViewModel(), null, 2, null);
                ActionsViewModel.this.updateState(RemoteDevice.Bluetooth, ActionsViewModel.this.idleDotsState);
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final DotsState createDotsTextState(String text) {
        return new DotsState.ShowText(text, Dp.m4046constructorimpl(12), 0, 0.0f, Dp.m4046constructorimpl(14), 12);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void updateState(RemoteDevice device, DotsState dotsState) {
        int position;
        switch (WhenMappings.$EnumSwitchMapping$0[device.ordinal()]) {
            case 1:
                position = 0;
                break;
            case 2:
                position = 1;
                break;
            default:
                throw new NoWhenBranchMatchedException();
        }
        List<Action> mutableList = CollectionsKt.toMutableList((Collection) this.defaultActions);
        Action newAction = Action.copy$default(mutableList.get(position), 0, null, dotsState, 3, null);
        mutableList.set(position, newAction);
        tryEmit(mutableList);
    }

    private final boolean checkWifiGranted() {
        Context $this$checkWifiGranted_u24lambda_u240 = this.context;
        if (!WiFiUtilsKt.isWifiEnabled($this$checkWifiGranted_u24lambda_u240)) {
            return LiveLiterals$ActionsViewModelKt.INSTANCE.m6787Boolean$branch$if$fun$anonymous$$arg1$callwith$funcheckWifiGranted$classActionsViewModel();
        }
        return LiveLiterals$ActionsViewModelKt.INSTANCE.m6790Boolean$fun$anonymous$$arg1$callwith$funcheckWifiGranted$classActionsViewModel();
    }

    private final boolean checkBluetoothGranted() {
        Context $this$checkBluetoothGranted_u24lambda_u241 = this.context;
        if (!BluetoothUtilsKt.hasBluetooth($this$checkBluetoothGranted_u24lambda_u241)) {
            LogKt.debug$default(LiveLiterals$ActionsViewModelKt.INSTANCE.m6793String$arg0$calldebug$branch$if$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel(), null, 2, null);
            return LiveLiterals$ActionsViewModelKt.INSTANCE.m6786Boolean$branch$if$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel();
        }
        if (!BluetoothUtilsKt.hasBluetoothPermissions($this$checkBluetoothGranted_u24lambda_u241)) {
            mo5906trySendJP2dKIU(Unit.INSTANCE);
            return LiveLiterals$ActionsViewModelKt.INSTANCE.m6788Boolean$branch$if1$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel();
        }
        return LiveLiterals$ActionsViewModelKt.INSTANCE.m6789Boolean$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel();
    }

    public final void isOpened(boolean value) {
        this.sidePanelActionProducer.produceAction(ISidePanelActionProviderKt.toSidePanelAction(value));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void onBluetoothClick() {
        if (hasBluetoothConnection()) {
            this.bluetoothConnection.closeConnection();
            updateState(RemoteDevice.Bluetooth, this.idleDotsState);
        } else if (checkBluetoothGranted()) {
            mo5906trySendJP2dKIU(RemoteDevice.Bluetooth);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void onWifiClick() {
        Context $this$onWifiClick_u24lambda_u242 = this.context;
        WiFiUtilsKt.pickWifiNetwork($this$onWifiClick_u24lambda_u242);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void onSettingsClick() {
    }

    private final boolean hasBluetoothConnection() {
        return getValue().get(0).getState() instanceof DotsState.ShowText;
    }
}
