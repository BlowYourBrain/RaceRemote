package vea.raceremote.features.remote_control.presentation;

import kotlin.Metadata;
import kotlinx.coroutines.flow.Flow;

/* JADX INFO: compiled from: WifiNetworkFinder.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\bf\u0018\u00002\u00020\u0001:\u0001\u0007R\u0018\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003X¦\u0004¢\u0006\u0006\u001a\u0004\b\u0005\u0010\u0006¨\u0006\b"}, d2 = {"Lvea/raceremote/features/remote_control/presentation/IWifiNetworkFinder;", "", "networkState", "Lkotlinx/coroutines/flow/Flow;", "Lvea/raceremote/features/remote_control/presentation/IWifiNetworkFinder$NetworkState;", "getNetworkState", "()Lkotlinx/coroutines/flow/Flow;", "NetworkState", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public interface IWifiNetworkFinder {

    /* JADX INFO: compiled from: WifiNetworkFinder.kt */
    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005¨\u0006\u0006"}, d2 = {"Lvea/raceremote/features/remote_control/presentation/IWifiNetworkFinder$NetworkState;", "", "(Ljava/lang/String;I)V", "Loading", "Mismatch", "Match", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public enum NetworkState {
        Loading,
        Mismatch,
        Match
    }

    Flow<NetworkState> getNetworkState();
}
