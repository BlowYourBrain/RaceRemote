package vea.raceremote.features.remote_control.presentation;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: ActionsViewModel.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/features/remote_control/presentation/ActionsViewModel.kt")
public final class LiveLiterals$ActionsViewModelKt {

    /* JADX INFO: renamed from: Boolean$branch$if$fun-$anonymous$$arg-1$call-with$fun-checkBluetoothGranted$class-ActionsViewModel, reason: not valid java name */
    private static boolean f1645Boolean$branch$if$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel;

    /* JADX INFO: renamed from: Boolean$branch$if$fun-$anonymous$$arg-1$call-with$fun-checkWifiGranted$class-ActionsViewModel, reason: not valid java name */
    private static boolean f1646Boolean$branch$if$fun$anonymous$$arg1$callwith$funcheckWifiGranted$classActionsViewModel;

    /* JADX INFO: renamed from: Boolean$branch$if-1$fun-$anonymous$$arg-1$call-with$fun-checkBluetoothGranted$class-ActionsViewModel, reason: not valid java name */
    private static boolean f1647Boolean$branch$if1$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel;

    /* JADX INFO: renamed from: State$Boolean$branch$if$fun-$anonymous$$arg-1$call-with$fun-checkBluetoothGranted$class-ActionsViewModel, reason: not valid java name */
    private static State<Boolean> f1651State$Boolean$branch$if$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel;

    /* JADX INFO: renamed from: State$Boolean$branch$if$fun-$anonymous$$arg-1$call-with$fun-checkWifiGranted$class-ActionsViewModel, reason: not valid java name */
    private static State<Boolean> f1652State$Boolean$branch$if$fun$anonymous$$arg1$callwith$funcheckWifiGranted$classActionsViewModel;

    /* JADX INFO: renamed from: State$Boolean$branch$if-1$fun-$anonymous$$arg-1$call-with$fun-checkBluetoothGranted$class-ActionsViewModel, reason: not valid java name */
    private static State<Boolean> f1653State$Boolean$branch$if1$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel;

    /* JADX INFO: renamed from: State$Boolean$fun-$anonymous$$arg-1$call-with$fun-checkBluetoothGranted$class-ActionsViewModel, reason: not valid java name */
    private static State<Boolean> f1654State$Boolean$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel;

    /* JADX INFO: renamed from: State$Boolean$fun-$anonymous$$arg-1$call-with$fun-checkWifiGranted$class-ActionsViewModel, reason: not valid java name */
    private static State<Boolean> f1655State$Boolean$fun$anonymous$$arg1$callwith$funcheckWifiGranted$classActionsViewModel;

    /* JADX INFO: renamed from: State$Int$class-ActionsViewModel, reason: not valid java name */
    private static State<Integer> f1656State$Int$classActionsViewModel;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-debug$fun-connectBluetooth$class-ActionsViewModel, reason: not valid java name */
    private static State<String> f1657State$String$0$str$arg0$calldebug$funconnectBluetooth$classActionsViewModel;

    /* JADX INFO: renamed from: State$String$arg-0$call-debug$branch$if$fun-$anonymous$$arg-1$call-with$fun-checkBluetoothGranted$class-ActionsViewModel, reason: not valid java name */
    private static State<String> f1658State$String$arg0$calldebug$branch$if$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel;

    /* JADX INFO: renamed from: State$String$arg-0$call-debug$branch-1$when$fun-$anonymous$$arg-2$call-launch$fun-connectBluetooth$class-ActionsViewModel, reason: not valid java name */
    private static State<String> f1659State$String$arg0$calldebug$branch1$when$fun$anonymous$$arg2$calllaunch$funconnectBluetooth$classActionsViewModel;
    public static final LiveLiterals$ActionsViewModelKt INSTANCE = new LiveLiterals$ActionsViewModelKt();

    /* JADX INFO: renamed from: String$0$str$arg-0$call-debug$fun-connectBluetooth$class-ActionsViewModel, reason: not valid java name */
    private static String f1660String$0$str$arg0$calldebug$funconnectBluetooth$classActionsViewModel = "found device with address ";

    /* JADX INFO: renamed from: String$arg-0$call-debug$branch-1$when$fun-$anonymous$$arg-2$call-launch$fun-connectBluetooth$class-ActionsViewModel, reason: not valid java name */
    private static String f1662String$arg0$calldebug$branch1$when$fun$anonymous$$arg2$calllaunch$funconnectBluetooth$classActionsViewModel = "connection failed";

    /* JADX INFO: renamed from: Boolean$fun-$anonymous$$arg-1$call-with$fun-checkWifiGranted$class-ActionsViewModel, reason: not valid java name */
    private static boolean f1649Boolean$fun$anonymous$$arg1$callwith$funcheckWifiGranted$classActionsViewModel = true;

    /* JADX INFO: renamed from: String$arg-0$call-debug$branch$if$fun-$anonymous$$arg-1$call-with$fun-checkBluetoothGranted$class-ActionsViewModel, reason: not valid java name */
    private static String f1661String$arg0$calldebug$branch$if$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel = "device has no bluetooth";

    /* JADX INFO: renamed from: Boolean$fun-$anonymous$$arg-1$call-with$fun-checkBluetoothGranted$class-ActionsViewModel, reason: not valid java name */
    private static boolean f1648Boolean$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel = true;

    /* JADX INFO: renamed from: Int$class-ActionsViewModel, reason: not valid java name */
    private static int f1650Int$classActionsViewModel = 8;

    @LiveLiteralInfo(key = "Boolean$branch$if$fun-$anonymous$$arg-1$call-with$fun-checkBluetoothGranted$class-ActionsViewModel", offset = 6315)
    /* JADX INFO: renamed from: Boolean$branch$if$fun-$anonymous$$arg-1$call-with$fun-checkBluetoothGranted$class-ActionsViewModel, reason: not valid java name */
    public final boolean m6786Boolean$branch$if$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1645Boolean$branch$if$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel;
        }
        State<Boolean> stateLiveLiteral = f1651State$Boolean$branch$if$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$if$fun-$anonymous$$arg-1$call-with$fun-checkBluetoothGranted$class-ActionsViewModel", Boolean.valueOf(f1645Boolean$branch$if$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel));
            f1651State$Boolean$branch$if$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$if$fun-$anonymous$$arg-1$call-with$fun-checkWifiGranted$class-ActionsViewModel", offset = 5809)
    /* JADX INFO: renamed from: Boolean$branch$if$fun-$anonymous$$arg-1$call-with$fun-checkWifiGranted$class-ActionsViewModel, reason: not valid java name */
    public final boolean m6787Boolean$branch$if$fun$anonymous$$arg1$callwith$funcheckWifiGranted$classActionsViewModel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1646Boolean$branch$if$fun$anonymous$$arg1$callwith$funcheckWifiGranted$classActionsViewModel;
        }
        State<Boolean> stateLiveLiteral = f1652State$Boolean$branch$if$fun$anonymous$$arg1$callwith$funcheckWifiGranted$classActionsViewModel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$if$fun-$anonymous$$arg-1$call-with$fun-checkWifiGranted$class-ActionsViewModel", Boolean.valueOf(f1646Boolean$branch$if$fun$anonymous$$arg1$callwith$funcheckWifiGranted$classActionsViewModel));
            f1652State$Boolean$branch$if$fun$anonymous$$arg1$callwith$funcheckWifiGranted$classActionsViewModel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$if-1$fun-$anonymous$$arg-1$call-with$fun-checkBluetoothGranted$class-ActionsViewModel", offset = 6448)
    /* JADX INFO: renamed from: Boolean$branch$if-1$fun-$anonymous$$arg-1$call-with$fun-checkBluetoothGranted$class-ActionsViewModel, reason: not valid java name */
    public final boolean m6788Boolean$branch$if1$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1647Boolean$branch$if1$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel;
        }
        State<Boolean> stateLiveLiteral = f1653State$Boolean$branch$if1$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$if-1$fun-$anonymous$$arg-1$call-with$fun-checkBluetoothGranted$class-ActionsViewModel", Boolean.valueOf(f1647Boolean$branch$if1$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel));
            f1653State$Boolean$branch$if1$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$fun-$anonymous$$arg-1$call-with$fun-checkBluetoothGranted$class-ActionsViewModel", offset = 6480)
    /* JADX INFO: renamed from: Boolean$fun-$anonymous$$arg-1$call-with$fun-checkBluetoothGranted$class-ActionsViewModel, reason: not valid java name */
    public final boolean m6789Boolean$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1648Boolean$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel;
        }
        State<Boolean> stateLiveLiteral = f1654State$Boolean$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$fun-$anonymous$$arg-1$call-with$fun-checkBluetoothGranted$class-ActionsViewModel", Boolean.valueOf(f1648Boolean$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel));
            f1654State$Boolean$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$fun-$anonymous$$arg-1$call-with$fun-checkWifiGranted$class-ActionsViewModel", offset = 5981)
    /* JADX INFO: renamed from: Boolean$fun-$anonymous$$arg-1$call-with$fun-checkWifiGranted$class-ActionsViewModel, reason: not valid java name */
    public final boolean m6790Boolean$fun$anonymous$$arg1$callwith$funcheckWifiGranted$classActionsViewModel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1649Boolean$fun$anonymous$$arg1$callwith$funcheckWifiGranted$classActionsViewModel;
        }
        State<Boolean> stateLiveLiteral = f1655State$Boolean$fun$anonymous$$arg1$callwith$funcheckWifiGranted$classActionsViewModel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$fun-$anonymous$$arg-1$call-with$fun-checkWifiGranted$class-ActionsViewModel", Boolean.valueOf(f1649Boolean$fun$anonymous$$arg1$callwith$funcheckWifiGranted$classActionsViewModel));
            f1655State$Boolean$fun$anonymous$$arg1$callwith$funcheckWifiGranted$classActionsViewModel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Int$class-ActionsViewModel", offset = -1)
    /* JADX INFO: renamed from: Int$class-ActionsViewModel, reason: not valid java name */
    public final int m6791Int$classActionsViewModel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1650Int$classActionsViewModel;
        }
        State<Integer> stateLiveLiteral = f1656State$Int$classActionsViewModel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-ActionsViewModel", Integer.valueOf(f1650Int$classActionsViewModel));
            f1656State$Int$classActionsViewModel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-debug$fun-connectBluetooth$class-ActionsViewModel", offset = 4093)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-debug$fun-connectBluetooth$class-ActionsViewModel, reason: not valid java name */
    public final String m6792String$0$str$arg0$calldebug$funconnectBluetooth$classActionsViewModel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1660String$0$str$arg0$calldebug$funconnectBluetooth$classActionsViewModel;
        }
        State<String> stateLiveLiteral = f1657State$String$0$str$arg0$calldebug$funconnectBluetooth$classActionsViewModel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-debug$fun-connectBluetooth$class-ActionsViewModel", f1660String$0$str$arg0$calldebug$funconnectBluetooth$classActionsViewModel);
            f1657State$String$0$str$arg0$calldebug$funconnectBluetooth$classActionsViewModel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-debug$branch$if$fun-$anonymous$$arg-1$call-with$fun-checkBluetoothGranted$class-ActionsViewModel", offset = 6270)
    /* JADX INFO: renamed from: String$arg-0$call-debug$branch$if$fun-$anonymous$$arg-1$call-with$fun-checkBluetoothGranted$class-ActionsViewModel, reason: not valid java name */
    public final String m6793String$arg0$calldebug$branch$if$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1661String$arg0$calldebug$branch$if$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel;
        }
        State<String> stateLiveLiteral = f1658State$String$arg0$calldebug$branch$if$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-debug$branch$if$fun-$anonymous$$arg-1$call-with$fun-checkBluetoothGranted$class-ActionsViewModel", f1661String$arg0$calldebug$branch$if$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel);
            f1658State$String$arg0$calldebug$branch$if$fun$anonymous$$arg1$callwith$funcheckBluetoothGranted$classActionsViewModel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-debug$branch-1$when$fun-$anonymous$$arg-2$call-launch$fun-connectBluetooth$class-ActionsViewModel", offset = 4769)
    /* JADX INFO: renamed from: String$arg-0$call-debug$branch-1$when$fun-$anonymous$$arg-2$call-launch$fun-connectBluetooth$class-ActionsViewModel, reason: not valid java name */
    public final String m6794String$arg0$calldebug$branch1$when$fun$anonymous$$arg2$calllaunch$funconnectBluetooth$classActionsViewModel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1662String$arg0$calldebug$branch1$when$fun$anonymous$$arg2$calllaunch$funconnectBluetooth$classActionsViewModel;
        }
        State<String> stateLiveLiteral = f1659State$String$arg0$calldebug$branch1$when$fun$anonymous$$arg2$calllaunch$funconnectBluetooth$classActionsViewModel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-debug$branch-1$when$fun-$anonymous$$arg-2$call-launch$fun-connectBluetooth$class-ActionsViewModel", f1662String$arg0$calldebug$branch1$when$fun$anonymous$$arg2$calllaunch$funconnectBluetooth$classActionsViewModel);
            f1659State$String$arg0$calldebug$branch1$when$fun$anonymous$$arg2$calllaunch$funconnectBluetooth$classActionsViewModel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
