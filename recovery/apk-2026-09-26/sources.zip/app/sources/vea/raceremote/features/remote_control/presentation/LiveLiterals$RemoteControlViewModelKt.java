package vea.raceremote.features.remote_control.presentation;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: RemoteControlViewModel.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/features/remote_control/presentation/RemoteControlViewModel.kt")
public final class LiveLiterals$RemoteControlViewModelKt {

    /* JADX INFO: renamed from: State$Int$class-RemoteControlViewModel, reason: not valid java name */
    private static State<Integer> f1664State$Int$classRemoteControlViewModel;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-debug$fun-updateMovement$class-RemoteControlViewModel, reason: not valid java name */
    private static State<String> f1665State$String$0$str$arg0$calldebug$funupdateMovement$classRemoteControlViewModel;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-debug$fun-updateSteeringWheel$class-RemoteControlViewModel, reason: not valid java name */
    private static State<String> f1666State$String$0$str$arg0$calldebug$funupdateSteeringWheel$classRemoteControlViewModel;
    public static final LiveLiterals$RemoteControlViewModelKt INSTANCE = new LiveLiterals$RemoteControlViewModelKt();

    /* JADX INFO: renamed from: String$0$str$arg-0$call-debug$fun-updateSteeringWheel$class-RemoteControlViewModel, reason: not valid java name */
    private static String f1668String$0$str$arg0$calldebug$funupdateSteeringWheel$classRemoteControlViewModel = "horizontal: ";

    /* JADX INFO: renamed from: String$0$str$arg-0$call-debug$fun-updateMovement$class-RemoteControlViewModel, reason: not valid java name */
    private static String f1667String$0$str$arg0$calldebug$funupdateMovement$classRemoteControlViewModel = "vertical: ";

    /* JADX INFO: renamed from: Int$class-RemoteControlViewModel, reason: not valid java name */
    private static int f1663Int$classRemoteControlViewModel = 8;

    @LiveLiteralInfo(key = "Int$class-RemoteControlViewModel", offset = -1)
    /* JADX INFO: renamed from: Int$class-RemoteControlViewModel, reason: not valid java name */
    public final int m6795Int$classRemoteControlViewModel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1663Int$classRemoteControlViewModel;
        }
        State<Integer> stateLiveLiteral = f1664State$Int$classRemoteControlViewModel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-RemoteControlViewModel", Integer.valueOf(f1663Int$classRemoteControlViewModel));
            f1664State$Int$classRemoteControlViewModel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-debug$fun-updateMovement$class-RemoteControlViewModel", offset = 2181)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-debug$fun-updateMovement$class-RemoteControlViewModel, reason: not valid java name */
    public final String m6796String$0$str$arg0$calldebug$funupdateMovement$classRemoteControlViewModel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1667String$0$str$arg0$calldebug$funupdateMovement$classRemoteControlViewModel;
        }
        State<String> stateLiveLiteral = f1665State$String$0$str$arg0$calldebug$funupdateMovement$classRemoteControlViewModel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-debug$fun-updateMovement$class-RemoteControlViewModel", f1667String$0$str$arg0$calldebug$funupdateMovement$classRemoteControlViewModel);
            f1665State$String$0$str$arg0$calldebug$funupdateMovement$classRemoteControlViewModel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-debug$fun-updateSteeringWheel$class-RemoteControlViewModel", offset = 2048)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-debug$fun-updateSteeringWheel$class-RemoteControlViewModel, reason: not valid java name */
    public final String m6797String$0$str$arg0$calldebug$funupdateSteeringWheel$classRemoteControlViewModel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1668String$0$str$arg0$calldebug$funupdateSteeringWheel$classRemoteControlViewModel;
        }
        State<String> stateLiveLiteral = f1666State$String$0$str$arg0$calldebug$funupdateSteeringWheel$classRemoteControlViewModel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-debug$fun-updateSteeringWheel$class-RemoteControlViewModel", f1668String$0$str$arg0$calldebug$funupdateSteeringWheel$classRemoteControlViewModel);
            f1666State$String$0$str$arg0$calldebug$funupdateSteeringWheel$classRemoteControlViewModel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
