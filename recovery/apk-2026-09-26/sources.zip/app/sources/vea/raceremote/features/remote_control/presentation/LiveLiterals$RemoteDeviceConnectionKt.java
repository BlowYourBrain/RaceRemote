package vea.raceremote.features.remote_control.presentation;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: RemoteDeviceConnection.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/features/remote_control/presentation/RemoteDeviceConnection.kt")
public final class LiveLiterals$RemoteDeviceConnectionKt {

    /* JADX INFO: renamed from: Boolean$arg-0$call-setSingleDevice$$this$call-build$val-pairingRequest$fun-chooseRemoteDevice$class-RemoteDeviceConnection, reason: not valid java name */
    private static boolean f1669Boolean$arg0$callsetSingleDevice$$this$callbuild$valpairingRequest$funchooseRemoteDevice$classRemoteDeviceConnection;

    /* JADX INFO: renamed from: Int$arg-4$call-startIntentSenderForResult$fun-onAssociationPending$class-$no-name-provided$$val-callback$fun-chooseRemoteDevice$class-RemoteDeviceConnection, reason: not valid java name */
    private static int f1670Int$arg4$callstartIntentSenderForResult$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection;

    /* JADX INFO: renamed from: Int$arg-5$call-startIntentSenderForResult$fun-onAssociationPending$class-$no-name-provided$$val-callback$fun-chooseRemoteDevice$class-RemoteDeviceConnection, reason: not valid java name */
    private static int f1671Int$arg5$callstartIntentSenderForResult$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection;

    /* JADX INFO: renamed from: Int$arg-6$call-startIntentSenderForResult$fun-onAssociationPending$class-$no-name-provided$$val-callback$fun-chooseRemoteDevice$class-RemoteDeviceConnection, reason: not valid java name */
    private static int f1672Int$arg6$callstartIntentSenderForResult$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-setSingleDevice$$this$call-build$val-pairingRequest$fun-chooseRemoteDevice$class-RemoteDeviceConnection, reason: not valid java name */
    private static State<Boolean> f1674State$Boolean$arg0$callsetSingleDevice$$this$callbuild$valpairingRequest$funchooseRemoteDevice$classRemoteDeviceConnection;

    /* JADX INFO: renamed from: State$Int$arg-4$call-startIntentSenderForResult$fun-onAssociationPending$class-$no-name-provided$$val-callback$fun-chooseRemoteDevice$class-RemoteDeviceConnection, reason: not valid java name */
    private static State<Integer> f1675State$Int$arg4$callstartIntentSenderForResult$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection;

    /* JADX INFO: renamed from: State$Int$arg-5$call-startIntentSenderForResult$fun-onAssociationPending$class-$no-name-provided$$val-callback$fun-chooseRemoteDevice$class-RemoteDeviceConnection, reason: not valid java name */
    private static State<Integer> f1676State$Int$arg5$callstartIntentSenderForResult$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection;

    /* JADX INFO: renamed from: State$Int$arg-6$call-startIntentSenderForResult$fun-onAssociationPending$class-$no-name-provided$$val-callback$fun-chooseRemoteDevice$class-RemoteDeviceConnection, reason: not valid java name */
    private static State<Integer> f1677State$Int$arg6$callstartIntentSenderForResult$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection;

    /* JADX INFO: renamed from: State$Int$class-RemoteDeviceConnection, reason: not valid java name */
    private static State<Integer> f1678State$Int$classRemoteDeviceConnection;

    /* JADX INFO: renamed from: State$String$arg-0$call-debug$fun-onAssociationPending$class-$no-name-provided$$val-callback$fun-chooseRemoteDevice$class-RemoteDeviceConnection, reason: not valid java name */
    private static State<String> f1679State$String$arg0$calldebug$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection;
    public static final LiveLiterals$RemoteDeviceConnectionKt INSTANCE = new LiveLiterals$RemoteDeviceConnectionKt();

    /* JADX INFO: renamed from: String$arg-0$call-debug$fun-onAssociationPending$class-$no-name-provided$$val-callback$fun-chooseRemoteDevice$class-RemoteDeviceConnection, reason: not valid java name */
    private static String f1680String$arg0$calldebug$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection = "send intent finding pairing device";

    /* JADX INFO: renamed from: Int$class-RemoteDeviceConnection, reason: not valid java name */
    private static int f1673Int$classRemoteDeviceConnection = 8;

    @LiveLiteralInfo(key = "Boolean$arg-0$call-setSingleDevice$$this$call-build$val-pairingRequest$fun-chooseRemoteDevice$class-RemoteDeviceConnection", offset = 1424)
    /* JADX INFO: renamed from: Boolean$arg-0$call-setSingleDevice$$this$call-build$val-pairingRequest$fun-chooseRemoteDevice$class-RemoteDeviceConnection, reason: not valid java name */
    public final boolean m6798Boolean$arg0$callsetSingleDevice$$this$callbuild$valpairingRequest$funchooseRemoteDevice$classRemoteDeviceConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1669Boolean$arg0$callsetSingleDevice$$this$callbuild$valpairingRequest$funchooseRemoteDevice$classRemoteDeviceConnection;
        }
        State<Boolean> stateLiveLiteral = f1674State$Boolean$arg0$callsetSingleDevice$$this$callbuild$valpairingRequest$funchooseRemoteDevice$classRemoteDeviceConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-setSingleDevice$$this$call-build$val-pairingRequest$fun-chooseRemoteDevice$class-RemoteDeviceConnection", Boolean.valueOf(f1669Boolean$arg0$callsetSingleDevice$$this$callbuild$valpairingRequest$funchooseRemoteDevice$classRemoteDeviceConnection));
            f1674State$Boolean$arg0$callsetSingleDevice$$this$callbuild$valpairingRequest$funchooseRemoteDevice$classRemoteDeviceConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Int$arg-4$call-startIntentSenderForResult$fun-onAssociationPending$class-$no-name-provided$$val-callback$fun-chooseRemoteDevice$class-RemoteDeviceConnection", offset = 1988)
    /* JADX INFO: renamed from: Int$arg-4$call-startIntentSenderForResult$fun-onAssociationPending$class-$no-name-provided$$val-callback$fun-chooseRemoteDevice$class-RemoteDeviceConnection, reason: not valid java name */
    public final int m6799Int$arg4$callstartIntentSenderForResult$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1670Int$arg4$callstartIntentSenderForResult$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection;
        }
        State<Integer> stateLiveLiteral = f1675State$Int$arg4$callstartIntentSenderForResult$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-4$call-startIntentSenderForResult$fun-onAssociationPending$class-$no-name-provided$$val-callback$fun-chooseRemoteDevice$class-RemoteDeviceConnection", Integer.valueOf(f1670Int$arg4$callstartIntentSenderForResult$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection));
            f1675State$Int$arg4$callstartIntentSenderForResult$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-5$call-startIntentSenderForResult$fun-onAssociationPending$class-$no-name-provided$$val-callback$fun-chooseRemoteDevice$class-RemoteDeviceConnection", offset = 2011)
    /* JADX INFO: renamed from: Int$arg-5$call-startIntentSenderForResult$fun-onAssociationPending$class-$no-name-provided$$val-callback$fun-chooseRemoteDevice$class-RemoteDeviceConnection, reason: not valid java name */
    public final int m6800Int$arg5$callstartIntentSenderForResult$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1671Int$arg5$callstartIntentSenderForResult$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection;
        }
        State<Integer> stateLiveLiteral = f1676State$Int$arg5$callstartIntentSenderForResult$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-5$call-startIntentSenderForResult$fun-onAssociationPending$class-$no-name-provided$$val-callback$fun-chooseRemoteDevice$class-RemoteDeviceConnection", Integer.valueOf(f1671Int$arg5$callstartIntentSenderForResult$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection));
            f1676State$Int$arg5$callstartIntentSenderForResult$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-6$call-startIntentSenderForResult$fun-onAssociationPending$class-$no-name-provided$$val-callback$fun-chooseRemoteDevice$class-RemoteDeviceConnection", offset = 2034)
    /* JADX INFO: renamed from: Int$arg-6$call-startIntentSenderForResult$fun-onAssociationPending$class-$no-name-provided$$val-callback$fun-chooseRemoteDevice$class-RemoteDeviceConnection, reason: not valid java name */
    public final int m6801Int$arg6$callstartIntentSenderForResult$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1672Int$arg6$callstartIntentSenderForResult$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection;
        }
        State<Integer> stateLiveLiteral = f1677State$Int$arg6$callstartIntentSenderForResult$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-6$call-startIntentSenderForResult$fun-onAssociationPending$class-$no-name-provided$$val-callback$fun-chooseRemoteDevice$class-RemoteDeviceConnection", Integer.valueOf(f1672Int$arg6$callstartIntentSenderForResult$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection));
            f1677State$Int$arg6$callstartIntentSenderForResult$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-RemoteDeviceConnection", offset = -1)
    /* JADX INFO: renamed from: Int$class-RemoteDeviceConnection, reason: not valid java name */
    public final int m6802Int$classRemoteDeviceConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1673Int$classRemoteDeviceConnection;
        }
        State<Integer> stateLiveLiteral = f1678State$Int$classRemoteDeviceConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-RemoteDeviceConnection", Integer.valueOf(f1673Int$classRemoteDeviceConnection));
            f1678State$Int$classRemoteDeviceConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-debug$fun-onAssociationPending$class-$no-name-provided$$val-callback$fun-chooseRemoteDevice$class-RemoteDeviceConnection", offset = 1735)
    /* JADX INFO: renamed from: String$arg-0$call-debug$fun-onAssociationPending$class-$no-name-provided$$val-callback$fun-chooseRemoteDevice$class-RemoteDeviceConnection, reason: not valid java name */
    public final String m6803String$arg0$calldebug$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1680String$arg0$calldebug$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection;
        }
        State<String> stateLiveLiteral = f1679State$String$arg0$calldebug$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-debug$fun-onAssociationPending$class-$no-name-provided$$val-callback$fun-chooseRemoteDevice$class-RemoteDeviceConnection", f1680String$arg0$calldebug$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection);
            f1679State$String$arg0$calldebug$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
