package vea.raceremote.features.remote_control.presentation;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: WifiNetworkFinder.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/features/remote_control/presentation/WifiNetworkFinder.kt")
public final class LiveLiterals$WifiNetworkFinderKt {

    /* JADX INFO: renamed from: State$Int$class-WifiNetworkFinder, reason: not valid java name */
    private static State<Integer> f1682State$Int$classWifiNetworkFinder;

    /* JADX INFO: renamed from: State$String$arg-0$call-debug$fun-onAvailable$class-$no-name-provided$$arg-0$call-registerDefaultNetworkCallback$else$when$fun-setDefaultCallback$class-WifiNetworkFinder, reason: not valid java name */
    private static State<String> f1683State$String$arg0$calldebug$funonAvailable$class$nonameprovided$$arg0$callregisterDefaultNetworkCallback$else$when$funsetDefaultCallback$classWifiNetworkFinder;

    /* JADX INFO: renamed from: State$String$arg-0$call-debug$fun-onLost$class-$no-name-provided$$arg-0$call-registerDefaultNetworkCallback$else$when$fun-setDefaultCallback$class-WifiNetworkFinder, reason: not valid java name */
    private static State<String> f1684State$String$arg0$calldebug$funonLost$class$nonameprovided$$arg0$callregisterDefaultNetworkCallback$else$when$funsetDefaultCallback$classWifiNetworkFinder;
    public static final LiveLiterals$WifiNetworkFinderKt INSTANCE = new LiveLiterals$WifiNetworkFinderKt();

    /* JADX INFO: renamed from: String$arg-0$call-debug$fun-onAvailable$class-$no-name-provided$$arg-0$call-registerDefaultNetworkCallback$else$when$fun-setDefaultCallback$class-WifiNetworkFinder, reason: not valid java name */
    private static String f1685String$arg0$calldebug$funonAvailable$class$nonameprovided$$arg0$callregisterDefaultNetworkCallback$else$when$funsetDefaultCallback$classWifiNetworkFinder = "onAvailable";

    /* JADX INFO: renamed from: String$arg-0$call-debug$fun-onLost$class-$no-name-provided$$arg-0$call-registerDefaultNetworkCallback$else$when$fun-setDefaultCallback$class-WifiNetworkFinder, reason: not valid java name */
    private static String f1686String$arg0$calldebug$funonLost$class$nonameprovided$$arg0$callregisterDefaultNetworkCallback$else$when$funsetDefaultCallback$classWifiNetworkFinder = "onLost";

    /* JADX INFO: renamed from: Int$class-WifiNetworkFinder, reason: not valid java name */
    private static int f1681Int$classWifiNetworkFinder = 8;

    @LiveLiteralInfo(key = "Int$class-WifiNetworkFinder", offset = -1)
    /* JADX INFO: renamed from: Int$class-WifiNetworkFinder, reason: not valid java name */
    public final int m6804Int$classWifiNetworkFinder() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1681Int$classWifiNetworkFinder;
        }
        State<Integer> stateLiveLiteral = f1682State$Int$classWifiNetworkFinder;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-WifiNetworkFinder", Integer.valueOf(f1681Int$classWifiNetworkFinder));
            f1682State$Int$classWifiNetworkFinder = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-debug$fun-onAvailable$class-$no-name-provided$$arg-0$call-registerDefaultNetworkCallback$else$when$fun-setDefaultCallback$class-WifiNetworkFinder", offset = 2295)
    /* JADX INFO: renamed from: String$arg-0$call-debug$fun-onAvailable$class-$no-name-provided$$arg-0$call-registerDefaultNetworkCallback$else$when$fun-setDefaultCallback$class-WifiNetworkFinder, reason: not valid java name */
    public final String m6805String$arg0$calldebug$funonAvailable$class$nonameprovided$$arg0$callregisterDefaultNetworkCallback$else$when$funsetDefaultCallback$classWifiNetworkFinder() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1685String$arg0$calldebug$funonAvailable$class$nonameprovided$$arg0$callregisterDefaultNetworkCallback$else$when$funsetDefaultCallback$classWifiNetworkFinder;
        }
        State<String> stateLiveLiteral = f1683State$String$arg0$calldebug$funonAvailable$class$nonameprovided$$arg0$callregisterDefaultNetworkCallback$else$when$funsetDefaultCallback$classWifiNetworkFinder;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-debug$fun-onAvailable$class-$no-name-provided$$arg-0$call-registerDefaultNetworkCallback$else$when$fun-setDefaultCallback$class-WifiNetworkFinder", f1685String$arg0$calldebug$funonAvailable$class$nonameprovided$$arg0$callregisterDefaultNetworkCallback$else$when$funsetDefaultCallback$classWifiNetworkFinder);
            f1683State$String$arg0$calldebug$funonAvailable$class$nonameprovided$$arg0$callregisterDefaultNetworkCallback$else$when$funsetDefaultCallback$classWifiNetworkFinder = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-debug$fun-onLost$class-$no-name-provided$$arg-0$call-registerDefaultNetworkCallback$else$when$fun-setDefaultCallback$class-WifiNetworkFinder", offset = 2510)
    /* JADX INFO: renamed from: String$arg-0$call-debug$fun-onLost$class-$no-name-provided$$arg-0$call-registerDefaultNetworkCallback$else$when$fun-setDefaultCallback$class-WifiNetworkFinder, reason: not valid java name */
    public final String m6806String$arg0$calldebug$funonLost$class$nonameprovided$$arg0$callregisterDefaultNetworkCallback$else$when$funsetDefaultCallback$classWifiNetworkFinder() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1686String$arg0$calldebug$funonLost$class$nonameprovided$$arg0$callregisterDefaultNetworkCallback$else$when$funsetDefaultCallback$classWifiNetworkFinder;
        }
        State<String> stateLiveLiteral = f1684State$String$arg0$calldebug$funonLost$class$nonameprovided$$arg0$callregisterDefaultNetworkCallback$else$when$funsetDefaultCallback$classWifiNetworkFinder;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-debug$fun-onLost$class-$no-name-provided$$arg-0$call-registerDefaultNetworkCallback$else$when$fun-setDefaultCallback$class-WifiNetworkFinder", f1686String$arg0$calldebug$funonLost$class$nonameprovided$$arg0$callregisterDefaultNetworkCallback$else$when$funsetDefaultCallback$classWifiNetworkFinder);
            f1684State$String$arg0$calldebug$funonLost$class$nonameprovided$$arg0$callregisterDefaultNetworkCallback$else$when$funsetDefaultCallback$classWifiNetworkFinder = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
