package vea.raceremote.features.remote_control.presentation;

import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelKt;
import kotlin.KotlinNothingValueException;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.channels.Channel;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlowKt;
import vea.raceremote.features.remote_control.data.IRemoteDeviceRepository;
import vea.raceremote.features.remote_control.presentation.mapper.IEngineMapper;
import vea.raceremote.features.remote_control.presentation.mapper.ISteeringWheelMapper;
import vea.raceremote.features.remote_control.presentation.model.RemoteDevice;
import vea.raceremote.features.remote_control.utils.ICompoundCommandCreator;
import vea.raceremote.utils.FlowKt;
import vea.raceremote.utils.LogKt;
import vea.raceremote.utils.bluetooth.IBluetoothConnection;

/* JADX INFO: compiled from: RemoteControlViewModel.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u0000X\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B-\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\u000b¢\u0006\u0002\u0010\fJ\u0010\u0010\u0014\u001a\u00020\u00112\u0006\u0010\u0015\u001a\u00020\u0016H\u0002J\u0010\u0010\u0017\u001a\u00020\u00112\u0006\u0010\u0015\u001a\u00020\u0016H\u0002J$\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u0015\u001a\u00020\u00162\u0012\u0010\u001a\u001a\u000e\u0012\u0004\u0012\u00020\u0016\u0012\u0004\u0012\u00020\u00110\u001bH\u0002J\u000e\u0010\u001c\u001a\u00020\u00192\u0006\u0010\u0015\u001a\u00020\u0016J\u000e\u0010\u001d\u001a\u00020\u00192\u0006\u0010\u0015\u001a\u00020\u0016R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00110\u0010X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00110\u0013X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001e"}, d2 = {"Lvea/raceremote/features/remote_control/presentation/RemoteControlViewModel;", "Landroidx/lifecycle/ViewModel;", "engineMapper", "Lvea/raceremote/features/remote_control/presentation/mapper/IEngineMapper;", "steeringWheelMapper", "Lvea/raceremote/features/remote_control/presentation/mapper/ISteeringWheelMapper;", "bluetoothConnection", "Lvea/raceremote/utils/bluetooth/IBluetoothConnection;", "compoundCommandCreator", "Lvea/raceremote/features/remote_control/utils/ICompoundCommandCreator;", "remoteDeviceRepository", "Lvea/raceremote/features/remote_control/data/IRemoteDeviceRepository;", "(Lvea/raceremote/features/remote_control/presentation/mapper/IEngineMapper;Lvea/raceremote/features/remote_control/presentation/mapper/ISteeringWheelMapper;Lvea/raceremote/utils/bluetooth/IBluetoothConnection;Lvea/raceremote/features/remote_control/utils/ICompoundCommandCreator;Lvea/raceremote/features/remote_control/data/IRemoteDeviceRepository;)V", "activeRemoteDevice", "Lvea/raceremote/features/remote_control/presentation/model/RemoteDevice;", "bluetoothFlow", "Lkotlinx/coroutines/flow/MutableStateFlow;", "", "wifiFlow", "Lkotlinx/coroutines/channels/Channel;", "mapEngineValue", "value", "", "mapSteeringWheelValue", "sendValue", "", "mapper", "Lkotlin/Function1;", "updateMovement", "updateSteeringWheel", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class RemoteControlViewModel extends ViewModel {
    public static final int $stable = LiveLiterals$RemoteControlViewModelKt.INSTANCE.m6795Int$classRemoteControlViewModel();
    private final RemoteDevice activeRemoteDevice;
    private final IBluetoothConnection bluetoothConnection;
    private final MutableStateFlow<Integer> bluetoothFlow;
    private final ICompoundCommandCreator compoundCommandCreator;
    private final IEngineMapper engineMapper;
    private final IRemoteDeviceRepository remoteDeviceRepository;
    private final ISteeringWheelMapper steeringWheelMapper;
    private final Channel<Integer> wifiFlow;

    /* JADX INFO: compiled from: RemoteControlViewModel.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[RemoteDevice.values().length];
            try {
                iArr[RemoteDevice.WIFI.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                iArr[RemoteDevice.Bluetooth.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    public RemoteControlViewModel(IEngineMapper engineMapper, ISteeringWheelMapper steeringWheelMapper, IBluetoothConnection bluetoothConnection, ICompoundCommandCreator compoundCommandCreator, IRemoteDeviceRepository remoteDeviceRepository) {
        Intrinsics.checkNotNullParameter(engineMapper, "engineMapper");
        Intrinsics.checkNotNullParameter(steeringWheelMapper, "steeringWheelMapper");
        Intrinsics.checkNotNullParameter(bluetoothConnection, "bluetoothConnection");
        Intrinsics.checkNotNullParameter(compoundCommandCreator, "compoundCommandCreator");
        Intrinsics.checkNotNullParameter(remoteDeviceRepository, "remoteDeviceRepository");
        this.engineMapper = engineMapper;
        this.steeringWheelMapper = steeringWheelMapper;
        this.bluetoothConnection = bluetoothConnection;
        this.compoundCommandCreator = compoundCommandCreator;
        this.remoteDeviceRepository = remoteDeviceRepository;
        this.bluetoothFlow = StateFlowKt.MutableStateFlow(0);
        this.wifiFlow = FlowKt.singleEventChannel$default(null, null, 3, null);
        this.activeRemoteDevice = RemoteDevice.WIFI;
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), Dispatchers.getIO(), null, new AnonymousClass1(null), 2, null);
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), Dispatchers.getIO(), null, new AnonymousClass2(null), 2, null);
    }

    /* JADX INFO: renamed from: vea.raceremote.features.remote_control.presentation.RemoteControlViewModel$1, reason: invalid class name */
    /* JADX INFO: compiled from: RemoteControlViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\u008a@"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "vea.raceremote.features.remote_control.presentation.RemoteControlViewModel$1", f = "RemoteControlViewModel.kt", i = {}, l = {37}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return RemoteControlViewModel.this.new AnonymousClass1(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    MutableStateFlow mutableStateFlow = RemoteControlViewModel.this.bluetoothFlow;
                    final RemoteControlViewModel remoteControlViewModel = RemoteControlViewModel.this;
                    this.label = 1;
                    if (mutableStateFlow.collect(new FlowCollector<Integer>() { // from class: vea.raceremote.features.remote_control.presentation.RemoteControlViewModel.1.1
                        @Override // kotlinx.coroutines.flow.FlowCollector
                        public /* bridge */ /* synthetic */ Object emit(Integer num, Continuation $completion) {
                            return emit(num.intValue(), (Continuation<? super Unit>) $completion);
                        }

                        public final Object emit(int value, Continuation<? super Unit> continuation) {
                            Object objSendMessage = remoteControlViewModel.bluetoothConnection.sendMessage(value, continuation);
                            return objSendMessage == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendMessage : Unit.INSTANCE;
                        }
                    }, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            throw new KotlinNothingValueException();
        }
    }

    /* JADX INFO: renamed from: vea.raceremote.features.remote_control.presentation.RemoteControlViewModel$2, reason: invalid class name */
    /* JADX INFO: compiled from: RemoteControlViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\u008a@"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "vea.raceremote.features.remote_control.presentation.RemoteControlViewModel$2", f = "RemoteControlViewModel.kt", i = {}, l = {43}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass2(Continuation<? super AnonymousClass2> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return RemoteControlViewModel.this.new AnonymousClass2(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    Flow flowReceiveAsFlow = kotlinx.coroutines.flow.FlowKt.receiveAsFlow(RemoteControlViewModel.this.wifiFlow);
                    final RemoteControlViewModel remoteControlViewModel = RemoteControlViewModel.this;
                    this.label = 1;
                    if (flowReceiveAsFlow.collect(new FlowCollector<Integer>() { // from class: vea.raceremote.features.remote_control.presentation.RemoteControlViewModel.2.1
                        @Override // kotlinx.coroutines.flow.FlowCollector
                        public /* bridge */ /* synthetic */ Object emit(Integer num, Continuation $completion) {
                            return emit(num.intValue(), (Continuation<? super Unit>) $completion);
                        }

                        public final Object emit(int value, Continuation<? super Unit> continuation) {
                            remoteControlViewModel.remoteDeviceRepository.sendData(IRemoteDeviceRepository.Destination.WiFi, value);
                            return Unit.INSTANCE;
                        }
                    }, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: vea.raceremote.features.remote_control.presentation.RemoteControlViewModel$updateSteeringWheel$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: RemoteControlViewModel.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    /* synthetic */ class C05301 extends FunctionReferenceImpl implements Function1<Float, Integer> {
        C05301(Object obj) {
            super(1, obj, RemoteControlViewModel.class, "mapSteeringWheelValue", "mapSteeringWheelValue(F)I", 0);
        }

        public final Integer invoke(float p0) {
            return Integer.valueOf(((RemoteControlViewModel) this.receiver).mapSteeringWheelValue(p0));
        }

        @Override // kotlin.jvm.functions.Function1
        public /* bridge */ /* synthetic */ Integer invoke(Float f) {
            return invoke(f.floatValue());
        }
    }

    public final void updateSteeringWheel(float value) {
        LogKt.debug$default(LiveLiterals$RemoteControlViewModelKt.INSTANCE.m6797String$0$str$arg0$calldebug$funupdateSteeringWheel$classRemoteControlViewModel() + value, null, 2, null);
        sendValue(value, new C05301(this));
    }

    /* JADX INFO: renamed from: vea.raceremote.features.remote_control.presentation.RemoteControlViewModel$updateMovement$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: RemoteControlViewModel.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    /* synthetic */ class C05291 extends FunctionReferenceImpl implements Function1<Float, Integer> {
        C05291(Object obj) {
            super(1, obj, RemoteControlViewModel.class, "mapEngineValue", "mapEngineValue(F)I", 0);
        }

        public final Integer invoke(float p0) {
            return Integer.valueOf(((RemoteControlViewModel) this.receiver).mapEngineValue(p0));
        }

        @Override // kotlin.jvm.functions.Function1
        public /* bridge */ /* synthetic */ Integer invoke(Float f) {
            return invoke(f.floatValue());
        }
    }

    public final void updateMovement(float value) {
        LogKt.debug$default(LiveLiterals$RemoteControlViewModelKt.INSTANCE.m6796String$0$str$arg0$calldebug$funupdateMovement$classRemoteControlViewModel() + value, null, 2, null);
        sendValue(value, new C05291(this));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final int mapSteeringWheelValue(float value) {
        return this.compoundCommandCreator.createSteeringWheelCommand(this.steeringWheelMapper.mapToSteeringWheel(value));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final int mapEngineValue(float value) {
        return this.compoundCommandCreator.createEngineCommand(this.engineMapper.mapToEngineValue(value));
    }

    private final void sendValue(float value, Function1<? super Float, Integer> mapper) {
        switch (WhenMappings.$EnumSwitchMapping$0[this.activeRemoteDevice.ordinal()]) {
            case 1:
                mo5906trySendJP2dKIU(mapper.invoke(Float.valueOf(value)));
                break;
            case 2:
                tryEmit(mapper.invoke(Float.valueOf(value)));
                break;
        }
    }
}
