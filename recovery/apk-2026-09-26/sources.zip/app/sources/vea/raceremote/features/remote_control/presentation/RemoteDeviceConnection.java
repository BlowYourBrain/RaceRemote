package vea.raceremote.features.remote_control.presentation;

import android.app.Activity;
import android.companion.AssociationInfo;
import android.companion.AssociationRequest;
import android.companion.BluetoothDeviceFilter;
import android.companion.CompanionDeviceManager;
import android.companion.WifiDeviceFilter;
import android.content.IntentSender;
import androidx.core.app.ActivityCompat;
import java.util.concurrent.Executor;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import vea.raceremote.features.remote_control.presentation.model.RemoteDevice;
import vea.raceremote.utils.LogKt;

/* JADX INFO: compiled from: RemoteDeviceConnection.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0016\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0013R\u001b\u0010\u0003\u001a\u00020\u00048BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u0007\u0010\b\u001a\u0004\b\u0005\u0010\u0006R\u001b\u0010\t\u001a\u00020\n8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\r\u0010\b\u001a\u0004\b\u000b\u0010\f¨\u0006\u0014"}, d2 = {"Lvea/raceremote/features/remote_control/presentation/RemoteDeviceConnection;", "", "()V", "bluetoothDeviceFilter", "Landroid/companion/BluetoothDeviceFilter;", "getBluetoothDeviceFilter", "()Landroid/companion/BluetoothDeviceFilter;", "bluetoothDeviceFilter$delegate", "Lkotlin/Lazy;", "wifiDeviceFilter", "Landroid/companion/WifiDeviceFilter;", "getWifiDeviceFilter", "()Landroid/companion/WifiDeviceFilter;", "wifiDeviceFilter$delegate", "chooseRemoteDevice", "", "activity", "Landroid/app/Activity;", "remoteDevice", "Lvea/raceremote/features/remote_control/presentation/model/RemoteDevice;", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class RemoteDeviceConnection {
    public static final int $stable = LiveLiterals$RemoteDeviceConnectionKt.INSTANCE.m6802Int$classRemoteDeviceConnection();

    /* JADX INFO: renamed from: bluetoothDeviceFilter$delegate, reason: from kotlin metadata */
    private final Lazy bluetoothDeviceFilter = LazyKt.lazy(new Function0<BluetoothDeviceFilter>() { // from class: vea.raceremote.features.remote_control.presentation.RemoteDeviceConnection$bluetoothDeviceFilter$2
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // kotlin.jvm.functions.Function0
        public final BluetoothDeviceFilter invoke() {
            BluetoothDeviceFilter bluetoothDeviceFilterBuild = new BluetoothDeviceFilter.Builder().build();
            Intrinsics.checkNotNullExpressionValue(bluetoothDeviceFilterBuild, "Builder()\n            .build()");
            return bluetoothDeviceFilterBuild;
        }
    });

    /* JADX INFO: renamed from: wifiDeviceFilter$delegate, reason: from kotlin metadata */
    private final Lazy wifiDeviceFilter = LazyKt.lazy(new Function0<WifiDeviceFilter>() { // from class: vea.raceremote.features.remote_control.presentation.RemoteDeviceConnection$wifiDeviceFilter$2
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // kotlin.jvm.functions.Function0
        public final WifiDeviceFilter invoke() {
            WifiDeviceFilter wifiDeviceFilterBuild = new WifiDeviceFilter.Builder().build();
            Intrinsics.checkNotNullExpressionValue(wifiDeviceFilterBuild, "Builder()\n            .build()");
            return wifiDeviceFilterBuild;
        }
    });

    /* JADX INFO: compiled from: RemoteDeviceConnection.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[RemoteDevice.values().length];
            try {
                iArr[RemoteDevice.WIFI.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                iArr[RemoteDevice.Bluetooth.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    private final BluetoothDeviceFilter getBluetoothDeviceFilter() {
        return (BluetoothDeviceFilter) getValue();
    }

    private final WifiDeviceFilter getWifiDeviceFilter() {
        return (WifiDeviceFilter) getValue();
    }

    public final void chooseRemoteDevice(final Activity activity, final RemoteDevice remoteDevice) {
        WifiDeviceFilter wifiDeviceFilter;
        Intrinsics.checkNotNullParameter(activity, "activity");
        Intrinsics.checkNotNullParameter(remoteDevice, "remoteDevice");
        Object systemService = activity.getSystemService("companiondevice");
        CompanionDeviceManager deviceManager = systemService instanceof CompanionDeviceManager ? (CompanionDeviceManager) systemService : null;
        if (deviceManager == null) {
            return;
        }
        switch (WhenMappings.$EnumSwitchMapping$0[remoteDevice.ordinal()]) {
            case 1:
                wifiDeviceFilter = getWifiDeviceFilter();
                break;
            case 2:
                wifiDeviceFilter = getBluetoothDeviceFilter();
                break;
            default:
                throw new NoWhenBranchMatchedException();
        }
        AssociationRequest pairingRequest = new AssociationRequest.Builder().addDeviceFilter(wifiDeviceFilter).setSingleDevice(LiveLiterals$RemoteDeviceConnectionKt.INSTANCE.m6798Boolean$arg0$callsetSingleDevice$$this$callbuild$valpairingRequest$funchooseRemoteDevice$classRemoteDeviceConnection()).build();
        Intrinsics.checkNotNullExpressionValue(pairingRequest, "Builder()\n            .a…lse)\n            .build()");
        CompanionDeviceManager.Callback callback = new CompanionDeviceManager.Callback() { // from class: vea.raceremote.features.remote_control.presentation.RemoteDeviceConnection$chooseRemoteDevice$callback$1
            @Override // android.companion.CompanionDeviceManager.Callback
            public void onDeviceFound(IntentSender intentSender) {
                Intrinsics.checkNotNullParameter(intentSender, "intentSender");
            }

            @Override // android.companion.CompanionDeviceManager.Callback
            public void onAssociationPending(IntentSender intentSender) throws IntentSender.SendIntentException {
                Intrinsics.checkNotNullParameter(intentSender, "intentSender");
                LogKt.debug$default(LiveLiterals$RemoteDeviceConnectionKt.INSTANCE.m6803String$arg0$calldebug$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection(), null, 2, null);
                ActivityCompat.startIntentSenderForResult(activity, intentSender, remoteDevice.getRequestCode(), null, LiveLiterals$RemoteDeviceConnectionKt.INSTANCE.m6799Int$arg4$callstartIntentSenderForResult$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection(), LiveLiterals$RemoteDeviceConnectionKt.INSTANCE.m6800Int$arg5$callstartIntentSenderForResult$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection(), LiveLiterals$RemoteDeviceConnectionKt.INSTANCE.m6801Int$arg6$callstartIntentSenderForResult$funonAssociationPending$class$nonameprovided$$valcallback$funchooseRemoteDevice$classRemoteDeviceConnection(), null);
            }

            @Override // android.companion.CompanionDeviceManager.Callback
            public void onAssociationCreated(AssociationInfo associationInfo) {
                Intrinsics.checkNotNullParameter(associationInfo, "associationInfo");
            }

            @Override // android.companion.CompanionDeviceManager.Callback
            public void onFailure(CharSequence errorMessage) {
            }
        };
        Executor executor = new Executor() { // from class: vea.raceremote.features.remote_control.presentation.RemoteDeviceConnection$$ExternalSyntheticLambda0
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                runnable.run();
            }
        };
        deviceManager.associate(pairingRequest, executor, callback);
    }
}
