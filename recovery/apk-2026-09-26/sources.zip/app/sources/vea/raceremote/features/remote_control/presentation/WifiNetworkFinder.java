package vea.raceremote.features.remote_control.presentation;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import java.util.concurrent.CancellationException;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlow;
import kotlinx.coroutines.flow.StateFlowKt;
import vea.raceremote.features.remote_control.data.IRemoteDeviceRepository;
import vea.raceremote.utils.LogKt;
import vea.raceremote.utils.wifi.WiFiUtilsKt;

/* JADX INFO: compiled from: WifiNetworkFinder.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\b\u0010\u0012\u001a\u00020\u0013H\u0002J\b\u0010\u0014\u001a\u00020\u0013H\u0002J\b\u0010\u0015\u001a\u00020\u0013H\u0002J\b\u0010\u0016\u001a\u00020\u0013H\u0002R\u0014\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\t0\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\f\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\t0\u000fX\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0017"}, d2 = {"Lvea/raceremote/features/remote_control/presentation/WifiNetworkFinder;", "Lvea/raceremote/features/remote_control/presentation/IWifiNetworkFinder;", "context", "Landroid/content/Context;", "remoteDeviceRepository", "Lvea/raceremote/features/remote_control/data/IRemoteDeviceRepository;", "(Landroid/content/Context;Lvea/raceremote/features/remote_control/data/IRemoteDeviceRepository;)V", "_networkState", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Lvea/raceremote/features/remote_control/presentation/IWifiNetworkFinder$NetworkState;", "coroutineScope", "Lkotlinx/coroutines/CoroutineScope;", "currentJob", "Lkotlinx/coroutines/Job;", "networkState", "Lkotlinx/coroutines/flow/StateFlow;", "getNetworkState", "()Lkotlinx/coroutines/flow/StateFlow;", "cancelJobAndCheckNetwork", "", "initial", "onLostNetwork", "setDefaultCallback", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class WifiNetworkFinder implements IWifiNetworkFinder {
    public static final int $stable = LiveLiterals$WifiNetworkFinderKt.INSTANCE.m6804Int$classWifiNetworkFinder();
    private final MutableStateFlow<IWifiNetworkFinder.NetworkState> _networkState;
    private final Context context;
    private final CoroutineScope coroutineScope;
    private Job currentJob;
    private final StateFlow<IWifiNetworkFinder.NetworkState> networkState;
    private final IRemoteDeviceRepository remoteDeviceRepository;

    public WifiNetworkFinder(Context context, IRemoteDeviceRepository remoteDeviceRepository) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(remoteDeviceRepository, "remoteDeviceRepository");
        this.context = context;
        this.remoteDeviceRepository = remoteDeviceRepository;
        this.coroutineScope = CoroutineScopeKt.CoroutineScope(Dispatchers.getIO());
        MutableStateFlow<IWifiNetworkFinder.NetworkState> MutableStateFlow = StateFlowKt.MutableStateFlow(IWifiNetworkFinder.NetworkState.Mismatch);
        this._networkState = MutableStateFlow;
        this.networkState = FlowKt.asStateFlow(MutableStateFlow);
        initial();
    }

    @Override // vea.raceremote.features.remote_control.presentation.IWifiNetworkFinder
    public StateFlow<IWifiNetworkFinder.NetworkState> getNetworkState() {
        return this.networkState;
    }

    private final void initial() {
        setDefaultCallback();
        cancelJobAndCheckNetwork();
    }

    private final void setDefaultCallback() {
        ConnectivityManager connectivityManager = WiFiUtilsKt.getConnectivityManager(this.context);
        if (connectivityManager != null) {
            connectivityManager.registerDefaultNetworkCallback(new ConnectivityManager.NetworkCallback() { // from class: vea.raceremote.features.remote_control.presentation.WifiNetworkFinder.setDefaultCallback.1
                @Override // android.net.ConnectivityManager.NetworkCallback
                public void onAvailable(Network network) {
                    Intrinsics.checkNotNullParameter(network, "network");
                    super.onAvailable(network);
                    WifiNetworkFinder.this.cancelJobAndCheckNetwork();
                    LogKt.debug(LiveLiterals$WifiNetworkFinderKt.INSTANCE.m6805String$arg0$calldebug$funonAvailable$class$nonameprovided$$arg0$callregisterDefaultNetworkCallback$else$when$funsetDefaultCallback$classWifiNetworkFinder(), "WIFI_CONNECTION_TAG");
                }

                @Override // android.net.ConnectivityManager.NetworkCallback
                public void onLost(Network network) {
                    Intrinsics.checkNotNullParameter(network, "network");
                    super.onLost(network);
                    WifiNetworkFinder.this.onLostNetwork();
                    LogKt.debug(LiveLiterals$WifiNetworkFinderKt.INSTANCE.m6806String$arg0$calldebug$funonLost$class$nonameprovided$$arg0$callregisterDefaultNetworkCallback$else$when$funsetDefaultCallback$classWifiNetworkFinder(), "WIFI_CONNECTION_TAG");
                }

                @Override // android.net.ConnectivityManager.NetworkCallback
                public void onLosing(Network network, int maxMsToLive) {
                    Intrinsics.checkNotNullParameter(network, "network");
                }

                @Override // android.net.ConnectivityManager.NetworkCallback
                public void onUnavailable() {
                }

                @Override // android.net.ConnectivityManager.NetworkCallback
                public void onCapabilitiesChanged(Network network, NetworkCapabilities networkCapabilities) {
                    Intrinsics.checkNotNullParameter(network, "network");
                    Intrinsics.checkNotNullParameter(networkCapabilities, "networkCapabilities");
                }

                @Override // android.net.ConnectivityManager.NetworkCallback
                public void onLinkPropertiesChanged(Network network, LinkProperties linkProperties) {
                    Intrinsics.checkNotNullParameter(network, "network");
                    Intrinsics.checkNotNullParameter(linkProperties, "linkProperties");
                }

                @Override // android.net.ConnectivityManager.NetworkCallback
                public void onBlockedStatusChanged(Network network, boolean blocked) {
                    Intrinsics.checkNotNullParameter(network, "network");
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void cancelJobAndCheckNetwork() {
        Job job = this.currentJob;
        if (job != null) {
            Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
        }
        this.currentJob = BuildersKt__Builders_commonKt.launch$default(this.coroutineScope, null, null, new AnonymousClass1(null), 3, null);
    }

    /* JADX INFO: renamed from: vea.raceremote.features.remote_control.presentation.WifiNetworkFinder$cancelJobAndCheckNetwork$1, reason: invalid class name */
    /* JADX INFO: compiled from: WifiNetworkFinder.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\u008a@"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "vea.raceremote.features.remote_control.presentation.WifiNetworkFinder$cancelJobAndCheckNetwork$1", f = "WifiNetworkFinder.kt", i = {}, l = {104, 105, 109}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return WifiNetworkFinder.this.new AnonymousClass1(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code duplicated, block: B:14:0x004e A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:15:0x004f  */
        /* JADX WARN: Code duplicated, block: B:18:0x005b  */
        /* JADX WARN: Code duplicated, block: B:19:0x005e  */
        /* JADX WARN: Code duplicated, block: B:22:0x0073 A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:23:0x0074  */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            AnonymousClass1 anonymousClass1;
            Object objIsRemoteDeviceAvailable;
            AnonymousClass1 anonymousClass2;
            boolean isRemoteDeviceAvailable;
            IWifiNetworkFinder.NetworkState networkState;
            IWifiNetworkFinder.NetworkState networkState2;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    anonymousClass1 = this;
                    anonymousClass1.label = 1;
                    if (WifiNetworkFinder.this._networkState.emit(IWifiNetworkFinder.NetworkState.Loading, anonymousClass1) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    anonymousClass1.label = 2;
                    objIsRemoteDeviceAvailable = WifiNetworkFinder.this.remoteDeviceRepository.isRemoteDeviceAvailable(anonymousClass1);
                    if (objIsRemoteDeviceAvailable == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    $result = objIsRemoteDeviceAvailable;
                    anonymousClass2 = anonymousClass1;
                    isRemoteDeviceAvailable = ((Boolean) $result).booleanValue();
                    if (isRemoteDeviceAvailable) {
                        networkState = IWifiNetworkFinder.NetworkState.Match;
                    } else {
                        networkState = IWifiNetworkFinder.NetworkState.Mismatch;
                    }
                    networkState2 = networkState;
                    anonymousClass2.label = 3;
                    if (WifiNetworkFinder.this._networkState.emit(networkState2, anonymousClass2) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    return Unit.INSTANCE;
                case 1:
                    anonymousClass1 = this;
                    ResultKt.throwOnFailure($result);
                    anonymousClass1.label = 2;
                    objIsRemoteDeviceAvailable = WifiNetworkFinder.this.remoteDeviceRepository.isRemoteDeviceAvailable(anonymousClass1);
                    if (objIsRemoteDeviceAvailable == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    $result = objIsRemoteDeviceAvailable;
                    anonymousClass2 = anonymousClass1;
                    isRemoteDeviceAvailable = ((Boolean) $result).booleanValue();
                    if (isRemoteDeviceAvailable) {
                        networkState = IWifiNetworkFinder.NetworkState.Match;
                    } else {
                        networkState = IWifiNetworkFinder.NetworkState.Mismatch;
                    }
                    networkState2 = networkState;
                    anonymousClass2.label = 3;
                    if (WifiNetworkFinder.this._networkState.emit(networkState2, anonymousClass2) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    return Unit.INSTANCE;
                case 2:
                    ResultKt.throwOnFailure($result);
                    anonymousClass2 = this;
                    isRemoteDeviceAvailable = ((Boolean) $result).booleanValue();
                    if (isRemoteDeviceAvailable) {
                        networkState = IWifiNetworkFinder.NetworkState.Match;
                    } else {
                        networkState = IWifiNetworkFinder.NetworkState.Mismatch;
                    }
                    networkState2 = networkState;
                    anonymousClass2.label = 3;
                    if (WifiNetworkFinder.this._networkState.emit(networkState2, anonymousClass2) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    return Unit.INSTANCE;
                case 3:
                    ResultKt.throwOnFailure($result);
                    return Unit.INSTANCE;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void onLostNetwork() {
        tryEmit(IWifiNetworkFinder.NetworkState.Mismatch);
    }
}
