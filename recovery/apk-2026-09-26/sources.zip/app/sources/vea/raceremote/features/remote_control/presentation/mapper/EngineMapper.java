package vea.raceremote.features.remote_control.presentation.mapper;

import kotlin.Metadata;

/* JADX INFO: compiled from: EngineMapper.kt */
/* JADX INFO: loaded from: classes7.dex */
@Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u0007H\u0016R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\b"}, d2 = {"Lvea/raceremote/features/remote_control/presentation/mapper/EngineMapper;", "Lvea/raceremote/features/remote_control/presentation/mapper/IEngineMapper;", "()V", "y", "", "mapToEngineValue", "value", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class EngineMapper implements IEngineMapper {
    public static final int $stable = LiveLiterals$EngineMapperKt.INSTANCE.m6812Int$classEngineMapper();
    private int y;

    @Override // vea.raceremote.features.remote_control.presentation.mapper.IEngineMapper
    public int mapToEngineValue(float value) {
        this.y = (int) ((LiveLiterals$EngineMapperKt.INSTANCE.m6807Int$$this$calltimes$$this$calldiv$$this$calltoInt$arg0$call$sety$$funmapToEngineValue$classEngineMapper() * (LiveLiterals$EngineMapperKt.INSTANCE.m6810Int$arg0$callplus$arg0$calltimes$$this$calldiv$$this$calltoInt$arg0$call$sety$$funmapToEngineValue$classEngineMapper() + value)) / LiveLiterals$EngineMapperKt.INSTANCE.m6808Int$arg0$calldiv$$this$calltoInt$arg0$call$sety$$funmapToEngineValue$classEngineMapper());
        return Math.min(Math.max(LiveLiterals$EngineMapperKt.INSTANCE.m6809Int$arg0$callmaxOf$arg0$callminOf$funmapToEngineValue$classEngineMapper(), this.y), LiveLiterals$EngineMapperKt.INSTANCE.m6811Int$arg1$callminOf$funmapToEngineValue$classEngineMapper());
    }
}
