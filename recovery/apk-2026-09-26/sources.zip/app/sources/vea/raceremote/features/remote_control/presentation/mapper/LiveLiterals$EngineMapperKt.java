package vea.raceremote.features.remote_control.presentation.mapper;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: EngineMapper.kt */
/* JADX INFO: loaded from: classes7.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/features/remote_control/presentation/mapper/EngineMapper.kt")
public final class LiveLiterals$EngineMapperKt {

    /* JADX INFO: renamed from: Int$arg-0$call-maxOf$arg-0$call-minOf$fun-mapToEngineValue$class-EngineMapper, reason: not valid java name */
    private static int f1689Int$arg0$callmaxOf$arg0$callminOf$funmapToEngineValue$classEngineMapper;

    /* JADX INFO: renamed from: State$Int$$this$call-times$$this$call-div$$this$call-toInt$arg-0$call-$set-y$$fun-mapToEngineValue$class-EngineMapper, reason: not valid java name */
    private static State<Integer> f1693State$Int$$this$calltimes$$this$calldiv$$this$calltoInt$arg0$call$sety$$funmapToEngineValue$classEngineMapper;

    /* JADX INFO: renamed from: State$Int$arg-0$call-div$$this$call-toInt$arg-0$call-$set-y$$fun-mapToEngineValue$class-EngineMapper, reason: not valid java name */
    private static State<Integer> f1694State$Int$arg0$calldiv$$this$calltoInt$arg0$call$sety$$funmapToEngineValue$classEngineMapper;

    /* JADX INFO: renamed from: State$Int$arg-0$call-maxOf$arg-0$call-minOf$fun-mapToEngineValue$class-EngineMapper, reason: not valid java name */
    private static State<Integer> f1695State$Int$arg0$callmaxOf$arg0$callminOf$funmapToEngineValue$classEngineMapper;

    /* JADX INFO: renamed from: State$Int$arg-0$call-plus$arg-0$call-times$$this$call-div$$this$call-toInt$arg-0$call-$set-y$$fun-mapToEngineValue$class-EngineMapper, reason: not valid java name */
    private static State<Integer> f1696State$Int$arg0$callplus$arg0$calltimes$$this$calldiv$$this$calltoInt$arg0$call$sety$$funmapToEngineValue$classEngineMapper;

    /* JADX INFO: renamed from: State$Int$arg-1$call-minOf$fun-mapToEngineValue$class-EngineMapper, reason: not valid java name */
    private static State<Integer> f1697State$Int$arg1$callminOf$funmapToEngineValue$classEngineMapper;

    /* JADX INFO: renamed from: State$Int$class-EngineMapper, reason: not valid java name */
    private static State<Integer> f1698State$Int$classEngineMapper;
    public static final LiveLiterals$EngineMapperKt INSTANCE = new LiveLiterals$EngineMapperKt();

    /* JADX INFO: renamed from: Int$$this$call-times$$this$call-div$$this$call-toInt$arg-0$call-$set-y$$fun-mapToEngineValue$class-EngineMapper, reason: not valid java name */
    private static int f1687Int$$this$calltimes$$this$calldiv$$this$calltoInt$arg0$call$sety$$funmapToEngineValue$classEngineMapper = 511;

    /* JADX INFO: renamed from: Int$arg-0$call-plus$arg-0$call-times$$this$call-div$$this$call-toInt$arg-0$call-$set-y$$fun-mapToEngineValue$class-EngineMapper, reason: not valid java name */
    private static int f1690Int$arg0$callplus$arg0$calltimes$$this$calldiv$$this$calltoInt$arg0$call$sety$$funmapToEngineValue$classEngineMapper = 1;

    /* JADX INFO: renamed from: Int$arg-0$call-div$$this$call-toInt$arg-0$call-$set-y$$fun-mapToEngineValue$class-EngineMapper, reason: not valid java name */
    private static int f1688Int$arg0$calldiv$$this$calltoInt$arg0$call$sety$$funmapToEngineValue$classEngineMapper = 2;

    /* JADX INFO: renamed from: Int$arg-1$call-minOf$fun-mapToEngineValue$class-EngineMapper, reason: not valid java name */
    private static int f1691Int$arg1$callminOf$funmapToEngineValue$classEngineMapper = 511;

    /* JADX INFO: renamed from: Int$class-EngineMapper, reason: not valid java name */
    private static int f1692Int$classEngineMapper = 8;

    @LiveLiteralInfo(key = "Int$$this$call-times$$this$call-div$$this$call-toInt$arg-0$call-$set-y$$fun-mapToEngineValue$class-EngineMapper", offset = 957)
    /* JADX INFO: renamed from: Int$$this$call-times$$this$call-div$$this$call-toInt$arg-0$call-$set-y$$fun-mapToEngineValue$class-EngineMapper, reason: not valid java name */
    public final int m6807Int$$this$calltimes$$this$calldiv$$this$calltoInt$arg0$call$sety$$funmapToEngineValue$classEngineMapper() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1687Int$$this$calltimes$$this$calldiv$$this$calltoInt$arg0$call$sety$$funmapToEngineValue$classEngineMapper;
        }
        State<Integer> stateLiveLiteral = f1693State$Int$$this$calltimes$$this$calldiv$$this$calltoInt$arg0$call$sety$$funmapToEngineValue$classEngineMapper;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-times$$this$call-div$$this$call-toInt$arg-0$call-$set-y$$fun-mapToEngineValue$class-EngineMapper", Integer.valueOf(f1687Int$$this$calltimes$$this$calldiv$$this$calltoInt$arg0$call$sety$$funmapToEngineValue$classEngineMapper));
            f1693State$Int$$this$calltimes$$this$calldiv$$this$calltoInt$arg0$call$sety$$funmapToEngineValue$classEngineMapper = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-div$$this$call-toInt$arg-0$call-$set-y$$fun-mapToEngineValue$class-EngineMapper", offset = 977)
    /* JADX INFO: renamed from: Int$arg-0$call-div$$this$call-toInt$arg-0$call-$set-y$$fun-mapToEngineValue$class-EngineMapper, reason: not valid java name */
    public final int m6808Int$arg0$calldiv$$this$calltoInt$arg0$call$sety$$funmapToEngineValue$classEngineMapper() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1688Int$arg0$calldiv$$this$calltoInt$arg0$call$sety$$funmapToEngineValue$classEngineMapper;
        }
        State<Integer> stateLiveLiteral = f1694State$Int$arg0$calldiv$$this$calltoInt$arg0$call$sety$$funmapToEngineValue$classEngineMapper;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-div$$this$call-toInt$arg-0$call-$set-y$$fun-mapToEngineValue$class-EngineMapper", Integer.valueOf(f1688Int$arg0$calldiv$$this$calltoInt$arg0$call$sety$$funmapToEngineValue$classEngineMapper));
            f1694State$Int$arg0$calldiv$$this$calltoInt$arg0$call$sety$$funmapToEngineValue$classEngineMapper = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-maxOf$arg-0$call-minOf$fun-mapToEngineValue$class-EngineMapper", offset = 1016)
    /* JADX INFO: renamed from: Int$arg-0$call-maxOf$arg-0$call-minOf$fun-mapToEngineValue$class-EngineMapper, reason: not valid java name */
    public final int m6809Int$arg0$callmaxOf$arg0$callminOf$funmapToEngineValue$classEngineMapper() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1689Int$arg0$callmaxOf$arg0$callminOf$funmapToEngineValue$classEngineMapper;
        }
        State<Integer> stateLiveLiteral = f1695State$Int$arg0$callmaxOf$arg0$callminOf$funmapToEngineValue$classEngineMapper;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-maxOf$arg-0$call-minOf$fun-mapToEngineValue$class-EngineMapper", Integer.valueOf(f1689Int$arg0$callmaxOf$arg0$callminOf$funmapToEngineValue$classEngineMapper));
            f1695State$Int$arg0$callmaxOf$arg0$callminOf$funmapToEngineValue$classEngineMapper = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-plus$arg-0$call-times$$this$call-div$$this$call-toInt$arg-0$call-$set-y$$fun-mapToEngineValue$class-EngineMapper", offset = 972)
    /* JADX INFO: renamed from: Int$arg-0$call-plus$arg-0$call-times$$this$call-div$$this$call-toInt$arg-0$call-$set-y$$fun-mapToEngineValue$class-EngineMapper, reason: not valid java name */
    public final int m6810Int$arg0$callplus$arg0$calltimes$$this$calldiv$$this$calltoInt$arg0$call$sety$$funmapToEngineValue$classEngineMapper() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1690Int$arg0$callplus$arg0$calltimes$$this$calldiv$$this$calltoInt$arg0$call$sety$$funmapToEngineValue$classEngineMapper;
        }
        State<Integer> stateLiveLiteral = f1696State$Int$arg0$callplus$arg0$calltimes$$this$calldiv$$this$calltoInt$arg0$call$sety$$funmapToEngineValue$classEngineMapper;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-plus$arg-0$call-times$$this$call-div$$this$call-toInt$arg-0$call-$set-y$$fun-mapToEngineValue$class-EngineMapper", Integer.valueOf(f1690Int$arg0$callplus$arg0$calltimes$$this$calldiv$$this$calltoInt$arg0$call$sety$$funmapToEngineValue$classEngineMapper));
            f1696State$Int$arg0$callplus$arg0$calltimes$$this$calldiv$$this$calltoInt$arg0$call$sety$$funmapToEngineValue$classEngineMapper = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-minOf$fun-mapToEngineValue$class-EngineMapper", offset = 1023)
    /* JADX INFO: renamed from: Int$arg-1$call-minOf$fun-mapToEngineValue$class-EngineMapper, reason: not valid java name */
    public final int m6811Int$arg1$callminOf$funmapToEngineValue$classEngineMapper() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1691Int$arg1$callminOf$funmapToEngineValue$classEngineMapper;
        }
        State<Integer> stateLiveLiteral = f1697State$Int$arg1$callminOf$funmapToEngineValue$classEngineMapper;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-minOf$fun-mapToEngineValue$class-EngineMapper", Integer.valueOf(f1691Int$arg1$callminOf$funmapToEngineValue$classEngineMapper));
            f1697State$Int$arg1$callminOf$funmapToEngineValue$classEngineMapper = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-EngineMapper", offset = -1)
    /* JADX INFO: renamed from: Int$class-EngineMapper, reason: not valid java name */
    public final int m6812Int$classEngineMapper() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1692Int$classEngineMapper;
        }
        State<Integer> stateLiveLiteral = f1698State$Int$classEngineMapper;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-EngineMapper", Integer.valueOf(f1692Int$classEngineMapper));
            f1698State$Int$classEngineMapper = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }
}
