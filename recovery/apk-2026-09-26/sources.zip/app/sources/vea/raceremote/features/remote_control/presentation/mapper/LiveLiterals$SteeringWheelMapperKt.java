package vea.raceremote.features.remote_control.presentation.mapper;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: SteeringWheelMapper.kt */
/* JADX INFO: loaded from: classes7.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/features/remote_control/presentation/mapper/SteeringWheelMapper.kt")
public final class LiveLiterals$SteeringWheelMapperKt {

    /* JADX INFO: renamed from: Int$arg-0$call-maxOf$arg-0$call-minOf$fun-mapToSteeringWheel$class-SteeringWheelMapper, reason: not valid java name */
    private static int f1700Int$arg0$callmaxOf$arg0$callminOf$funmapToSteeringWheel$classSteeringWheelMapper;

    /* JADX INFO: renamed from: State$Int$$this$call-times$$this$call-unaryMinus$$this$call-plus$$this$call-toInt$arg-0$call-$set-y$$fun-mapToSteeringWheel$class-SteeringWheelMapper, reason: not valid java name */
    private static State<Integer> f1704State$Int$$this$calltimes$$this$callunaryMinus$$this$callplus$$this$calltoInt$arg0$call$sety$$funmapToSteeringWheel$classSteeringWheelMapper;

    /* JADX INFO: renamed from: State$Int$arg-0$call-maxOf$arg-0$call-minOf$fun-mapToSteeringWheel$class-SteeringWheelMapper, reason: not valid java name */
    private static State<Integer> f1705State$Int$arg0$callmaxOf$arg0$callminOf$funmapToSteeringWheel$classSteeringWheelMapper;

    /* JADX INFO: renamed from: State$Int$arg-0$call-plus$$this$call-toInt$arg-0$call-$set-y$$fun-mapToSteeringWheel$class-SteeringWheelMapper, reason: not valid java name */
    private static State<Integer> f1706State$Int$arg0$callplus$$this$calltoInt$arg0$call$sety$$funmapToSteeringWheel$classSteeringWheelMapper;

    /* JADX INFO: renamed from: State$Int$arg-1$call-minOf$fun-mapToSteeringWheel$class-SteeringWheelMapper, reason: not valid java name */
    private static State<Integer> f1707State$Int$arg1$callminOf$funmapToSteeringWheel$classSteeringWheelMapper;

    /* JADX INFO: renamed from: State$Int$class-SteeringWheelMapper, reason: not valid java name */
    private static State<Integer> f1708State$Int$classSteeringWheelMapper;
    public static final LiveLiterals$SteeringWheelMapperKt INSTANCE = new LiveLiterals$SteeringWheelMapperKt();

    /* JADX INFO: renamed from: Int$$this$call-times$$this$call-unaryMinus$$this$call-plus$$this$call-toInt$arg-0$call-$set-y$$fun-mapToSteeringWheel$class-SteeringWheelMapper, reason: not valid java name */
    private static int f1699Int$$this$calltimes$$this$callunaryMinus$$this$callplus$$this$calltoInt$arg0$call$sety$$funmapToSteeringWheel$classSteeringWheelMapper = 90;

    /* JADX INFO: renamed from: Int$arg-0$call-plus$$this$call-toInt$arg-0$call-$set-y$$fun-mapToSteeringWheel$class-SteeringWheelMapper, reason: not valid java name */
    private static int f1701Int$arg0$callplus$$this$calltoInt$arg0$call$sety$$funmapToSteeringWheel$classSteeringWheelMapper = 90;

    /* JADX INFO: renamed from: Int$arg-1$call-minOf$fun-mapToSteeringWheel$class-SteeringWheelMapper, reason: not valid java name */
    private static int f1702Int$arg1$callminOf$funmapToSteeringWheel$classSteeringWheelMapper = 180;

    /* JADX INFO: renamed from: Int$class-SteeringWheelMapper, reason: not valid java name */
    private static int f1703Int$classSteeringWheelMapper = 8;

    @LiveLiteralInfo(key = "Int$$this$call-times$$this$call-unaryMinus$$this$call-plus$$this$call-toInt$arg-0$call-$set-y$$fun-mapToSteeringWheel$class-SteeringWheelMapper", offset = 697)
    /* JADX INFO: renamed from: Int$$this$call-times$$this$call-unaryMinus$$this$call-plus$$this$call-toInt$arg-0$call-$set-y$$fun-mapToSteeringWheel$class-SteeringWheelMapper, reason: not valid java name */
    public final int m6813Int$$this$calltimes$$this$callunaryMinus$$this$callplus$$this$calltoInt$arg0$call$sety$$funmapToSteeringWheel$classSteeringWheelMapper() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1699Int$$this$calltimes$$this$callunaryMinus$$this$callplus$$this$calltoInt$arg0$call$sety$$funmapToSteeringWheel$classSteeringWheelMapper;
        }
        State<Integer> stateLiveLiteral = f1704State$Int$$this$calltimes$$this$callunaryMinus$$this$callplus$$this$calltoInt$arg0$call$sety$$funmapToSteeringWheel$classSteeringWheelMapper;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-times$$this$call-unaryMinus$$this$call-plus$$this$call-toInt$arg-0$call-$set-y$$fun-mapToSteeringWheel$class-SteeringWheelMapper", Integer.valueOf(f1699Int$$this$calltimes$$this$callunaryMinus$$this$callplus$$this$calltoInt$arg0$call$sety$$funmapToSteeringWheel$classSteeringWheelMapper));
            f1704State$Int$$this$calltimes$$this$callunaryMinus$$this$callplus$$this$calltoInt$arg0$call$sety$$funmapToSteeringWheel$classSteeringWheelMapper = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-maxOf$arg-0$call-minOf$fun-mapToSteeringWheel$class-SteeringWheelMapper", offset = 751)
    /* JADX INFO: renamed from: Int$arg-0$call-maxOf$arg-0$call-minOf$fun-mapToSteeringWheel$class-SteeringWheelMapper, reason: not valid java name */
    public final int m6814Int$arg0$callmaxOf$arg0$callminOf$funmapToSteeringWheel$classSteeringWheelMapper() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1700Int$arg0$callmaxOf$arg0$callminOf$funmapToSteeringWheel$classSteeringWheelMapper;
        }
        State<Integer> stateLiveLiteral = f1705State$Int$arg0$callmaxOf$arg0$callminOf$funmapToSteeringWheel$classSteeringWheelMapper;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-maxOf$arg-0$call-minOf$fun-mapToSteeringWheel$class-SteeringWheelMapper", Integer.valueOf(f1700Int$arg0$callmaxOf$arg0$callminOf$funmapToSteeringWheel$classSteeringWheelMapper));
            f1705State$Int$arg0$callmaxOf$arg0$callminOf$funmapToSteeringWheel$classSteeringWheelMapper = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-plus$$this$call-toInt$arg-0$call-$set-y$$fun-mapToSteeringWheel$class-SteeringWheelMapper", offset = 711)
    /* JADX INFO: renamed from: Int$arg-0$call-plus$$this$call-toInt$arg-0$call-$set-y$$fun-mapToSteeringWheel$class-SteeringWheelMapper, reason: not valid java name */
    public final int m6815Int$arg0$callplus$$this$calltoInt$arg0$call$sety$$funmapToSteeringWheel$classSteeringWheelMapper() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1701Int$arg0$callplus$$this$calltoInt$arg0$call$sety$$funmapToSteeringWheel$classSteeringWheelMapper;
        }
        State<Integer> stateLiveLiteral = f1706State$Int$arg0$callplus$$this$calltoInt$arg0$call$sety$$funmapToSteeringWheel$classSteeringWheelMapper;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-plus$$this$call-toInt$arg-0$call-$set-y$$fun-mapToSteeringWheel$class-SteeringWheelMapper", Integer.valueOf(f1701Int$arg0$callplus$$this$calltoInt$arg0$call$sety$$funmapToSteeringWheel$classSteeringWheelMapper));
            f1706State$Int$arg0$callplus$$this$calltoInt$arg0$call$sety$$funmapToSteeringWheel$classSteeringWheelMapper = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-minOf$fun-mapToSteeringWheel$class-SteeringWheelMapper", offset = 758)
    /* JADX INFO: renamed from: Int$arg-1$call-minOf$fun-mapToSteeringWheel$class-SteeringWheelMapper, reason: not valid java name */
    public final int m6816Int$arg1$callminOf$funmapToSteeringWheel$classSteeringWheelMapper() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1702Int$arg1$callminOf$funmapToSteeringWheel$classSteeringWheelMapper;
        }
        State<Integer> stateLiveLiteral = f1707State$Int$arg1$callminOf$funmapToSteeringWheel$classSteeringWheelMapper;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-minOf$fun-mapToSteeringWheel$class-SteeringWheelMapper", Integer.valueOf(f1702Int$arg1$callminOf$funmapToSteeringWheel$classSteeringWheelMapper));
            f1707State$Int$arg1$callminOf$funmapToSteeringWheel$classSteeringWheelMapper = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-SteeringWheelMapper", offset = -1)
    /* JADX INFO: renamed from: Int$class-SteeringWheelMapper, reason: not valid java name */
    public final int m6817Int$classSteeringWheelMapper() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1703Int$classSteeringWheelMapper;
        }
        State<Integer> stateLiveLiteral = f1708State$Int$classSteeringWheelMapper;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-SteeringWheelMapper", Integer.valueOf(f1703Int$classSteeringWheelMapper));
            f1708State$Int$classSteeringWheelMapper = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }
}
