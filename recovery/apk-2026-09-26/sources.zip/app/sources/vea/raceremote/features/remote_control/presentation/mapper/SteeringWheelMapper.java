package vea.raceremote.features.remote_control.presentation.mapper;

import kotlin.Metadata;

/* JADX INFO: compiled from: SteeringWheelMapper.kt */
/* JADX INFO: loaded from: classes7.dex */
@Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u0007H\u0016R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\b"}, d2 = {"Lvea/raceremote/features/remote_control/presentation/mapper/SteeringWheelMapper;", "Lvea/raceremote/features/remote_control/presentation/mapper/ISteeringWheelMapper;", "()V", "y", "", "mapToSteeringWheel", "value", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class SteeringWheelMapper implements ISteeringWheelMapper {
    public static final int $stable = LiveLiterals$SteeringWheelMapperKt.INSTANCE.m6817Int$classSteeringWheelMapper();
    private int y;

    @Override // vea.raceremote.features.remote_control.presentation.mapper.ISteeringWheelMapper
    public int mapToSteeringWheel(float value) {
        this.y = (int) ((-(LiveLiterals$SteeringWheelMapperKt.INSTANCE.m6813Int$$this$calltimes$$this$callunaryMinus$$this$callplus$$this$calltoInt$arg0$call$sety$$funmapToSteeringWheel$classSteeringWheelMapper() * value)) + LiveLiterals$SteeringWheelMapperKt.INSTANCE.m6815Int$arg0$callplus$$this$calltoInt$arg0$call$sety$$funmapToSteeringWheel$classSteeringWheelMapper());
        return Math.min(Math.max(LiveLiterals$SteeringWheelMapperKt.INSTANCE.m6814Int$arg0$callmaxOf$arg0$callminOf$funmapToSteeringWheel$classSteeringWheelMapper(), this.y), LiveLiterals$SteeringWheelMapperKt.INSTANCE.m6816Int$arg1$callminOf$funmapToSteeringWheel$classSteeringWheelMapper());
    }
}
