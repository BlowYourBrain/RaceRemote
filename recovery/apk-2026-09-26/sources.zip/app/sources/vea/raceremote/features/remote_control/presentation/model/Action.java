package vea.raceremote.features.remote_control.presentation.model;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import vea.raceremote.ui.views.DotsState;

/* JADX INFO: compiled from: Action.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001B%\u0012\b\b\u0001\u0010\u0002\u001a\u00020\u0003\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0006\u0010\u0007\u001a\u00020\b¢\u0006\u0002\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\u000f\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005HÆ\u0003J\t\u0010\u0012\u001a\u00020\bHÆ\u0003J-\u0010\u0013\u001a\u00020\u00002\b\b\u0003\u0010\u0002\u001a\u00020\u00032\u000e\b\u0002\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\b\b\u0002\u0010\u0007\u001a\u00020\bHÆ\u0001J\u0013\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0017\u001a\u00020\u0003HÖ\u0001J\t\u0010\u0018\u001a\u00020\u0019HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u001a"}, d2 = {"Lvea/raceremote/features/remote_control/presentation/model/Action;", "", "icon", "", "onClick", "Lkotlin/Function0;", "", "state", "Lvea/raceremote/ui/views/DotsState;", "(ILkotlin/jvm/functions/Function0;Lvea/raceremote/ui/views/DotsState;)V", "getIcon", "()I", "getOnClick", "()Lkotlin/jvm/functions/Function0;", "getState", "()Lvea/raceremote/ui/views/DotsState;", "component1", "component2", "component3", "copy", "equals", "", "other", "hashCode", "toString", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final /* data */ class Action {
    public static final int $stable = LiveLiterals$ActionKt.INSTANCE.m6826Int$classAction();
    private final int icon;
    private final Function0<Unit> onClick;
    private final DotsState state;

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ Action copy$default(Action action, int i, Function0 function0, DotsState dotsState, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            i = action.icon;
        }
        if ((i2 & 2) != 0) {
            function0 = action.onClick;
        }
        if ((i2 & 4) != 0) {
            dotsState = action.state;
        }
        return action.copy(i, function0, dotsState);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final int getIcon() {
        return this.icon;
    }

    public final Function0<Unit> component2() {
        return this.onClick;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final DotsState getState() {
        return this.state;
    }

    public final Action copy(int icon, Function0<Unit> onClick, DotsState state) {
        Intrinsics.checkNotNullParameter(onClick, "onClick");
        Intrinsics.checkNotNullParameter(state, "state");
        return new Action(icon, onClick, state);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return LiveLiterals$ActionKt.INSTANCE.m6818Boolean$branch$when$funequals$classAction();
        }
        if (!(other instanceof Action)) {
            return LiveLiterals$ActionKt.INSTANCE.m6819Boolean$branch$when1$funequals$classAction();
        }
        Action action = (Action) other;
        if (this.icon != action.icon) {
            return LiveLiterals$ActionKt.INSTANCE.m6820Boolean$branch$when2$funequals$classAction();
        }
        if (Intrinsics.areEqual(this.onClick, action.onClick)) {
            return !Intrinsics.areEqual(this.state, action.state) ? LiveLiterals$ActionKt.INSTANCE.m6822Boolean$branch$when4$funequals$classAction() : LiveLiterals$ActionKt.INSTANCE.m6823Boolean$funequals$classAction();
        }
        return LiveLiterals$ActionKt.INSTANCE.m6821Boolean$branch$when3$funequals$classAction();
    }

    public int hashCode() {
        return (LiveLiterals$ActionKt.INSTANCE.m6825Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classAction() * ((LiveLiterals$ActionKt.INSTANCE.m6824Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classAction() * Integer.hashCode(this.icon)) + hashCode())) + this.state.hashCode();
    }

    public String toString() {
        return LiveLiterals$ActionKt.INSTANCE.m6827String$0$str$funtoString$classAction() + LiveLiterals$ActionKt.INSTANCE.m6828String$1$str$funtoString$classAction() + this.icon + LiveLiterals$ActionKt.INSTANCE.m6829String$3$str$funtoString$classAction() + LiveLiterals$ActionKt.INSTANCE.m6830String$4$str$funtoString$classAction() + this.onClick + LiveLiterals$ActionKt.INSTANCE.m6831String$6$str$funtoString$classAction() + LiveLiterals$ActionKt.INSTANCE.m6832String$7$str$funtoString$classAction() + this.state + LiveLiterals$ActionKt.INSTANCE.m6833String$9$str$funtoString$classAction();
    }

    public Action(int icon, Function0<Unit> function0, DotsState state) {
        Intrinsics.checkNotNullParameter(function0, "onClick");
        Intrinsics.checkNotNullParameter(state, "state");
        this.icon = icon;
        this.onClick = function0;
        this.state = state;
    }

    public final int getIcon() {
        return this.icon;
    }

    public final Function0<Unit> getOnClick() {
        return this.onClick;
    }

    public final DotsState getState() {
        return this.state;
    }
}
