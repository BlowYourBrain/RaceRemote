package vea.raceremote.features.remote_control.presentation.model;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: Action.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/features/remote_control/presentation/model/Action.kt")
public final class LiveLiterals$ActionKt {

    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-Action, reason: not valid java name */
    private static boolean f1710Boolean$branch$when1$funequals$classAction;

    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-Action, reason: not valid java name */
    private static boolean f1711Boolean$branch$when2$funequals$classAction;

    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-Action, reason: not valid java name */
    private static boolean f1712Boolean$branch$when3$funequals$classAction;

    /* JADX INFO: renamed from: Boolean$branch$when-4$fun-equals$class-Action, reason: not valid java name */
    private static boolean f1713Boolean$branch$when4$funequals$classAction;

    /* JADX INFO: renamed from: Int$class-Action, reason: not valid java name */
    private static int f1717Int$classAction;

    /* JADX INFO: renamed from: State$Boolean$branch$when$fun-equals$class-Action, reason: not valid java name */
    private static State<Boolean> f1718State$Boolean$branch$when$funequals$classAction;

    /* JADX INFO: renamed from: State$Boolean$branch$when-1$fun-equals$class-Action, reason: not valid java name */
    private static State<Boolean> f1719State$Boolean$branch$when1$funequals$classAction;

    /* JADX INFO: renamed from: State$Boolean$branch$when-2$fun-equals$class-Action, reason: not valid java name */
    private static State<Boolean> f1720State$Boolean$branch$when2$funequals$classAction;

    /* JADX INFO: renamed from: State$Boolean$branch$when-3$fun-equals$class-Action, reason: not valid java name */
    private static State<Boolean> f1721State$Boolean$branch$when3$funequals$classAction;

    /* JADX INFO: renamed from: State$Boolean$branch$when-4$fun-equals$class-Action, reason: not valid java name */
    private static State<Boolean> f1722State$Boolean$branch$when4$funequals$classAction;

    /* JADX INFO: renamed from: State$Boolean$fun-equals$class-Action, reason: not valid java name */
    private static State<Boolean> f1723State$Boolean$funequals$classAction;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Action, reason: not valid java name */
    private static State<Integer> f1724State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classAction;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-Action, reason: not valid java name */
    private static State<Integer> f1725State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classAction;

    /* JADX INFO: renamed from: State$Int$class-Action, reason: not valid java name */
    private static State<Integer> f1726State$Int$classAction;

    /* JADX INFO: renamed from: State$String$0$str$fun-toString$class-Action, reason: not valid java name */
    private static State<String> f1727State$String$0$str$funtoString$classAction;

    /* JADX INFO: renamed from: State$String$1$str$fun-toString$class-Action, reason: not valid java name */
    private static State<String> f1728State$String$1$str$funtoString$classAction;

    /* JADX INFO: renamed from: State$String$3$str$fun-toString$class-Action, reason: not valid java name */
    private static State<String> f1729State$String$3$str$funtoString$classAction;

    /* JADX INFO: renamed from: State$String$4$str$fun-toString$class-Action, reason: not valid java name */
    private static State<String> f1730State$String$4$str$funtoString$classAction;

    /* JADX INFO: renamed from: State$String$6$str$fun-toString$class-Action, reason: not valid java name */
    private static State<String> f1731State$String$6$str$funtoString$classAction;

    /* JADX INFO: renamed from: State$String$7$str$fun-toString$class-Action, reason: not valid java name */
    private static State<String> f1732State$String$7$str$funtoString$classAction;

    /* JADX INFO: renamed from: State$String$9$str$fun-toString$class-Action, reason: not valid java name */
    private static State<String> f1733State$String$9$str$funtoString$classAction;
    public static final LiveLiterals$ActionKt INSTANCE = new LiveLiterals$ActionKt();

    /* JADX INFO: renamed from: String$0$str$fun-toString$class-Action, reason: not valid java name */
    private static String f1734String$0$str$funtoString$classAction = "Action(";

    /* JADX INFO: renamed from: String$1$str$fun-toString$class-Action, reason: not valid java name */
    private static String f1735String$1$str$funtoString$classAction = "icon=";

    /* JADX INFO: renamed from: String$3$str$fun-toString$class-Action, reason: not valid java name */
    private static String f1736String$3$str$funtoString$classAction = ", ";

    /* JADX INFO: renamed from: String$4$str$fun-toString$class-Action, reason: not valid java name */
    private static String f1737String$4$str$funtoString$classAction = "onClick=";

    /* JADX INFO: renamed from: String$6$str$fun-toString$class-Action, reason: not valid java name */
    private static String f1738String$6$str$funtoString$classAction = ", ";

    /* JADX INFO: renamed from: String$7$str$fun-toString$class-Action, reason: not valid java name */
    private static String f1739String$7$str$funtoString$classAction = "state=";

    /* JADX INFO: renamed from: String$9$str$fun-toString$class-Action, reason: not valid java name */
    private static String f1740String$9$str$funtoString$classAction = ")";

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Action, reason: not valid java name */
    private static int f1715Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classAction = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-Action, reason: not valid java name */
    private static int f1716Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classAction = 31;

    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-Action, reason: not valid java name */
    private static boolean f1709Boolean$branch$when$funequals$classAction = true;

    /* JADX INFO: renamed from: Boolean$fun-equals$class-Action, reason: not valid java name */
    private static boolean f1714Boolean$funequals$classAction = true;

    @LiveLiteralInfo(key = "Boolean$branch$when$fun-equals$class-Action", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-Action, reason: not valid java name */
    public final boolean m6818Boolean$branch$when$funequals$classAction() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1709Boolean$branch$when$funequals$classAction;
        }
        State<Boolean> stateLiveLiteral = f1718State$Boolean$branch$when$funequals$classAction;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when$fun-equals$class-Action", Boolean.valueOf(f1709Boolean$branch$when$funequals$classAction));
            f1718State$Boolean$branch$when$funequals$classAction = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-1$fun-equals$class-Action", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-Action, reason: not valid java name */
    public final boolean m6819Boolean$branch$when1$funequals$classAction() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1710Boolean$branch$when1$funequals$classAction;
        }
        State<Boolean> stateLiveLiteral = f1719State$Boolean$branch$when1$funequals$classAction;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-1$fun-equals$class-Action", Boolean.valueOf(f1710Boolean$branch$when1$funequals$classAction));
            f1719State$Boolean$branch$when1$funequals$classAction = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-2$fun-equals$class-Action", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-Action, reason: not valid java name */
    public final boolean m6820Boolean$branch$when2$funequals$classAction() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1711Boolean$branch$when2$funequals$classAction;
        }
        State<Boolean> stateLiveLiteral = f1720State$Boolean$branch$when2$funequals$classAction;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-2$fun-equals$class-Action", Boolean.valueOf(f1711Boolean$branch$when2$funequals$classAction));
            f1720State$Boolean$branch$when2$funequals$classAction = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-3$fun-equals$class-Action", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-Action, reason: not valid java name */
    public final boolean m6821Boolean$branch$when3$funequals$classAction() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1712Boolean$branch$when3$funequals$classAction;
        }
        State<Boolean> stateLiveLiteral = f1721State$Boolean$branch$when3$funequals$classAction;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-3$fun-equals$class-Action", Boolean.valueOf(f1712Boolean$branch$when3$funequals$classAction));
            f1721State$Boolean$branch$when3$funequals$classAction = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-4$fun-equals$class-Action", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-4$fun-equals$class-Action, reason: not valid java name */
    public final boolean m6822Boolean$branch$when4$funequals$classAction() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1713Boolean$branch$when4$funequals$classAction;
        }
        State<Boolean> stateLiveLiteral = f1722State$Boolean$branch$when4$funequals$classAction;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-4$fun-equals$class-Action", Boolean.valueOf(f1713Boolean$branch$when4$funequals$classAction));
            f1722State$Boolean$branch$when4$funequals$classAction = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$fun-equals$class-Action", offset = -2)
    /* JADX INFO: renamed from: Boolean$fun-equals$class-Action, reason: not valid java name */
    public final boolean m6823Boolean$funequals$classAction() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1714Boolean$funequals$classAction;
        }
        State<Boolean> stateLiveLiteral = f1723State$Boolean$funequals$classAction;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$fun-equals$class-Action", Boolean.valueOf(f1714Boolean$funequals$classAction));
            f1723State$Boolean$funequals$classAction = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Action", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Action, reason: not valid java name */
    public final int m6824Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classAction() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1715Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classAction;
        }
        State<Integer> stateLiveLiteral = f1724State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classAction;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Action", Integer.valueOf(f1715Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classAction));
            f1724State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classAction = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-Action", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-Action, reason: not valid java name */
    public final int m6825Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classAction() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1716Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classAction;
        }
        State<Integer> stateLiveLiteral = f1725State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classAction;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-Action", Integer.valueOf(f1716Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classAction));
            f1725State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classAction = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-Action", offset = -1)
    /* JADX INFO: renamed from: Int$class-Action, reason: not valid java name */
    public final int m6826Int$classAction() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1717Int$classAction;
        }
        State<Integer> stateLiveLiteral = f1726State$Int$classAction;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-Action", Integer.valueOf(f1717Int$classAction));
            f1726State$Int$classAction = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "String$0$str$fun-toString$class-Action", offset = -2)
    /* JADX INFO: renamed from: String$0$str$fun-toString$class-Action, reason: not valid java name */
    public final String m6827String$0$str$funtoString$classAction() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1734String$0$str$funtoString$classAction;
        }
        State<String> stateLiveLiteral = f1727State$String$0$str$funtoString$classAction;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$fun-toString$class-Action", f1734String$0$str$funtoString$classAction);
            f1727State$String$0$str$funtoString$classAction = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$1$str$fun-toString$class-Action", offset = -2)
    /* JADX INFO: renamed from: String$1$str$fun-toString$class-Action, reason: not valid java name */
    public final String m6828String$1$str$funtoString$classAction() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1735String$1$str$funtoString$classAction;
        }
        State<String> stateLiveLiteral = f1728State$String$1$str$funtoString$classAction;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$1$str$fun-toString$class-Action", f1735String$1$str$funtoString$classAction);
            f1728State$String$1$str$funtoString$classAction = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$3$str$fun-toString$class-Action", offset = -2)
    /* JADX INFO: renamed from: String$3$str$fun-toString$class-Action, reason: not valid java name */
    public final String m6829String$3$str$funtoString$classAction() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1736String$3$str$funtoString$classAction;
        }
        State<String> stateLiveLiteral = f1729State$String$3$str$funtoString$classAction;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$3$str$fun-toString$class-Action", f1736String$3$str$funtoString$classAction);
            f1729State$String$3$str$funtoString$classAction = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$4$str$fun-toString$class-Action", offset = -2)
    /* JADX INFO: renamed from: String$4$str$fun-toString$class-Action, reason: not valid java name */
    public final String m6830String$4$str$funtoString$classAction() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1737String$4$str$funtoString$classAction;
        }
        State<String> stateLiveLiteral = f1730State$String$4$str$funtoString$classAction;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$4$str$fun-toString$class-Action", f1737String$4$str$funtoString$classAction);
            f1730State$String$4$str$funtoString$classAction = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$6$str$fun-toString$class-Action", offset = -2)
    /* JADX INFO: renamed from: String$6$str$fun-toString$class-Action, reason: not valid java name */
    public final String m6831String$6$str$funtoString$classAction() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1738String$6$str$funtoString$classAction;
        }
        State<String> stateLiveLiteral = f1731State$String$6$str$funtoString$classAction;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$6$str$fun-toString$class-Action", f1738String$6$str$funtoString$classAction);
            f1731State$String$6$str$funtoString$classAction = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$7$str$fun-toString$class-Action", offset = -2)
    /* JADX INFO: renamed from: String$7$str$fun-toString$class-Action, reason: not valid java name */
    public final String m6832String$7$str$funtoString$classAction() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1739String$7$str$funtoString$classAction;
        }
        State<String> stateLiveLiteral = f1732State$String$7$str$funtoString$classAction;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$7$str$fun-toString$class-Action", f1739String$7$str$funtoString$classAction);
            f1732State$String$7$str$funtoString$classAction = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$9$str$fun-toString$class-Action", offset = -2)
    /* JADX INFO: renamed from: String$9$str$fun-toString$class-Action, reason: not valid java name */
    public final String m6833String$9$str$funtoString$classAction() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1740String$9$str$funtoString$classAction;
        }
        State<String> stateLiveLiteral = f1733State$String$9$str$funtoString$classAction;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$9$str$fun-toString$class-Action", f1740String$9$str$funtoString$classAction);
            f1733State$String$9$str$funtoString$classAction = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
