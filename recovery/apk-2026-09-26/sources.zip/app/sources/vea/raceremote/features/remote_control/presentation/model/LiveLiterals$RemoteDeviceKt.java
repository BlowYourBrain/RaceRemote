package vea.raceremote.features.remote_control.presentation.model;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: RemoteDevice.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/features/remote_control/presentation/model/RemoteDevice.kt")
public final class LiveLiterals$RemoteDeviceKt {

    /* JADX INFO: renamed from: State$Int$arg-0$call-$init$$entry-Bluetooth$class-RemoteDevice, reason: not valid java name */
    private static State<Integer> f1743State$Int$arg0$call$init$$entryBluetooth$classRemoteDevice;

    /* JADX INFO: renamed from: State$Int$arg-0$call-$init$$entry-WIFI$class-RemoteDevice, reason: not valid java name */
    private static State<Integer> f1744State$Int$arg0$call$init$$entryWIFI$classRemoteDevice;
    public static final LiveLiterals$RemoteDeviceKt INSTANCE = new LiveLiterals$RemoteDeviceKt();

    /* JADX INFO: renamed from: Int$arg-0$call-$init$$entry-WIFI$class-RemoteDevice, reason: not valid java name */
    private static int f1742Int$arg0$call$init$$entryWIFI$classRemoteDevice = 100000;

    /* JADX INFO: renamed from: Int$arg-0$call-$init$$entry-Bluetooth$class-RemoteDevice, reason: not valid java name */
    private static int f1741Int$arg0$call$init$$entryBluetooth$classRemoteDevice = 100001;

    @LiveLiteralInfo(key = "Int$arg-0$call-$init$$entry-Bluetooth$class-RemoteDevice", offset = 147)
    /* JADX INFO: renamed from: Int$arg-0$call-$init$$entry-Bluetooth$class-RemoteDevice, reason: not valid java name */
    public final int m6834Int$arg0$call$init$$entryBluetooth$classRemoteDevice() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1741Int$arg0$call$init$$entryBluetooth$classRemoteDevice;
        }
        State<Integer> stateLiveLiteral = f1743State$Int$arg0$call$init$$entryBluetooth$classRemoteDevice;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-$init$$entry-Bluetooth$class-RemoteDevice", Integer.valueOf(f1741Int$arg0$call$init$$entryBluetooth$classRemoteDevice));
            f1743State$Int$arg0$call$init$$entryBluetooth$classRemoteDevice = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-$init$$entry-WIFI$class-RemoteDevice", offset = 123)
    /* JADX INFO: renamed from: Int$arg-0$call-$init$$entry-WIFI$class-RemoteDevice, reason: not valid java name */
    public final int m6835Int$arg0$call$init$$entryWIFI$classRemoteDevice() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1742Int$arg0$call$init$$entryWIFI$classRemoteDevice;
        }
        State<Integer> stateLiveLiteral = f1744State$Int$arg0$call$init$$entryWIFI$classRemoteDevice;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-$init$$entry-WIFI$class-RemoteDevice", Integer.valueOf(f1742Int$arg0$call$init$$entryWIFI$classRemoteDevice));
            f1744State$Int$arg0$call$init$$entryWIFI$classRemoteDevice = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }
}
