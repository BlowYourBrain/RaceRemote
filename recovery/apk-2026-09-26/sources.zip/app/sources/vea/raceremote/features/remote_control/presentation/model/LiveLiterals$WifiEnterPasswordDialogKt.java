package vea.raceremote.features.remote_control.presentation.model;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: WifiEnterPasswordDialog.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/features/remote_control/presentation/model/WifiEnterPasswordDialog.kt")
public final class LiveLiterals$WifiEnterPasswordDialogKt {
    public static final LiveLiterals$WifiEnterPasswordDialogKt INSTANCE = new LiveLiterals$WifiEnterPasswordDialogKt();

    /* JADX INFO: renamed from: Int$class-Close$class-WifiEnterPasswordDialog, reason: not valid java name */
    private static int f1745Int$classClose$classWifiEnterPasswordDialog;

    /* JADX INFO: renamed from: Int$class-Open$class-WifiEnterPasswordDialog, reason: not valid java name */
    private static int f1746Int$classOpen$classWifiEnterPasswordDialog;

    /* JADX INFO: renamed from: Int$class-WifiEnterPasswordDialog, reason: not valid java name */
    private static int f1747Int$classWifiEnterPasswordDialog;

    /* JADX INFO: renamed from: State$Int$class-Close$class-WifiEnterPasswordDialog, reason: not valid java name */
    private static State<Integer> f1748State$Int$classClose$classWifiEnterPasswordDialog;

    /* JADX INFO: renamed from: State$Int$class-Open$class-WifiEnterPasswordDialog, reason: not valid java name */
    private static State<Integer> f1749State$Int$classOpen$classWifiEnterPasswordDialog;

    /* JADX INFO: renamed from: State$Int$class-WifiEnterPasswordDialog, reason: not valid java name */
    private static State<Integer> f1750State$Int$classWifiEnterPasswordDialog;

    @LiveLiteralInfo(key = "Int$class-Close$class-WifiEnterPasswordDialog", offset = -1)
    /* JADX INFO: renamed from: Int$class-Close$class-WifiEnterPasswordDialog, reason: not valid java name */
    public final int m6836Int$classClose$classWifiEnterPasswordDialog() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1745Int$classClose$classWifiEnterPasswordDialog;
        }
        State<Integer> stateLiveLiteral = f1748State$Int$classClose$classWifiEnterPasswordDialog;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-Close$class-WifiEnterPasswordDialog", Integer.valueOf(f1745Int$classClose$classWifiEnterPasswordDialog));
            f1748State$Int$classClose$classWifiEnterPasswordDialog = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-Open$class-WifiEnterPasswordDialog", offset = -1)
    /* JADX INFO: renamed from: Int$class-Open$class-WifiEnterPasswordDialog, reason: not valid java name */
    public final int m6837Int$classOpen$classWifiEnterPasswordDialog() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1746Int$classOpen$classWifiEnterPasswordDialog;
        }
        State<Integer> stateLiveLiteral = f1749State$Int$classOpen$classWifiEnterPasswordDialog;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-Open$class-WifiEnterPasswordDialog", Integer.valueOf(f1746Int$classOpen$classWifiEnterPasswordDialog));
            f1749State$Int$classOpen$classWifiEnterPasswordDialog = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-WifiEnterPasswordDialog", offset = -1)
    /* JADX INFO: renamed from: Int$class-WifiEnterPasswordDialog, reason: not valid java name */
    public final int m6838Int$classWifiEnterPasswordDialog() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1747Int$classWifiEnterPasswordDialog;
        }
        State<Integer> stateLiveLiteral = f1750State$Int$classWifiEnterPasswordDialog;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-WifiEnterPasswordDialog", Integer.valueOf(f1747Int$classWifiEnterPasswordDialog));
            f1750State$Int$classWifiEnterPasswordDialog = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }
}
