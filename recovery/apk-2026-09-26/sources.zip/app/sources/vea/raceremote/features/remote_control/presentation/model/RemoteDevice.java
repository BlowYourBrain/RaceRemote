package vea.raceremote.features.remote_control.presentation.model;

import kotlin.Metadata;

/* JADX INFO: compiled from: RemoteDevice.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\b\n\u0002\b\u0006\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u000f\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006j\u0002\b\u0007j\u0002\b\b¨\u0006\t"}, d2 = {"Lvea/raceremote/features/remote_control/presentation/model/RemoteDevice;", "", "requestCode", "", "(Ljava/lang/String;II)V", "getRequestCode", "()I", "WIFI", "Bluetooth", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public enum RemoteDevice {
    WIFI(LiveLiterals$RemoteDeviceKt.INSTANCE.m6835Int$arg0$call$init$$entryWIFI$classRemoteDevice()),
    Bluetooth(LiveLiterals$RemoteDeviceKt.INSTANCE.m6834Int$arg0$call$init$$entryBluetooth$classRemoteDevice());

    private final int requestCode;

    RemoteDevice(int requestCode) {
        this.requestCode = requestCode;
    }

    public final int getRequestCode() {
        return this.requestCode;
    }
}
