package vea.raceremote.features.remote_control.presentation.model;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: WifiEnterPasswordDialog.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b7\u0018\u00002\u00020\u0001:\u0002\u0003\u0004B\u0007\b\u0004¢\u0006\u0002\u0010\u0002\u0082\u0001\u0002\u0005\u0006¨\u0006\u0007"}, d2 = {"Lvea/raceremote/features/remote_control/presentation/model/WifiEnterPasswordDialog;", "", "()V", "Close", "Open", "Lvea/raceremote/features/remote_control/presentation/model/WifiEnterPasswordDialog$Close;", "Lvea/raceremote/features/remote_control/presentation/model/WifiEnterPasswordDialog$Open;", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public abstract class WifiEnterPasswordDialog {
    public static final int $stable = LiveLiterals$WifiEnterPasswordDialogKt.INSTANCE.m6838Int$classWifiEnterPasswordDialog();

    /* JADX INFO: compiled from: WifiEnterPasswordDialog.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"Lvea/raceremote/features/remote_control/presentation/model/WifiEnterPasswordDialog$Open;", "Lvea/raceremote/features/remote_control/presentation/model/WifiEnterPasswordDialog;", "title", "", "(Ljava/lang/String;)V", "getTitle", "()Ljava/lang/String;", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class Open extends WifiEnterPasswordDialog {
        public static final int $stable = LiveLiterals$WifiEnterPasswordDialogKt.INSTANCE.m6837Int$classOpen$classWifiEnterPasswordDialog();
        private final String title;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public Open(String title) {
            super();
            Intrinsics.checkNotNullParameter(title, "title");
            this.title = title;
        }

        public final String getTitle() {
            return this.title;
        }
    }

    private WifiEnterPasswordDialog() {
    }

    /* JADX INFO: compiled from: WifiEnterPasswordDialog.kt */
    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÇ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Lvea/raceremote/features/remote_control/presentation/model/WifiEnterPasswordDialog$Close;", "Lvea/raceremote/features/remote_control/presentation/model/WifiEnterPasswordDialog;", "()V", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class Close extends WifiEnterPasswordDialog {
        public static final Close INSTANCE = new Close();
        public static final int $stable = LiveLiterals$WifiEnterPasswordDialogKt.INSTANCE.m6836Int$classClose$classWifiEnterPasswordDialog();

        private Close() {
            super();
        }
    }
}
