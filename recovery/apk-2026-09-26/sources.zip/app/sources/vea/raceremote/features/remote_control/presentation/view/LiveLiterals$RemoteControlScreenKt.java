package vea.raceremote.features.remote_control.presentation.view;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: RemoteControlScreen.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/features/remote_control/presentation/view/RemoteControlScreen.kt")
public final class LiveLiterals$RemoteControlScreenKt {

    /* JADX INFO: renamed from: State$Float$arg-0$call-weight$arg-0$call-ControllerWrapper$fun-$anonymous$$arg-3$call-Row$fun-Controllers, reason: not valid java name */
    private static State<Float> f1755State$Float$arg0$callweight$arg0$callControllerWrapper$fun$anonymous$$arg3$callRow$funControllers;

    /* JADX INFO: renamed from: State$Float$arg-0$call-weight$arg-0$call-ControllerWrapper-1$fun-$anonymous$$arg-3$call-Row$fun-Controllers, reason: not valid java name */
    private static State<Float> f1756State$Float$arg0$callweight$arg0$callControllerWrapper1$fun$anonymous$$arg3$callRow$funControllers;

    /* JADX INFO: renamed from: State$Int$$$this$call-$get-dp$$arg-0$call-BorderStroke$fun-$anonymous$$arg-0$call-remember$val-border$fun-ControllerWrapper, reason: not valid java name */
    private static State<Integer> f1757State$Int$$$this$call$getdp$$arg0$callBorderStroke$fun$anonymous$$arg0$callremember$valborder$funControllerWrapper;

    /* JADX INFO: renamed from: State$Int$$$this$call-$get-dp$$arg-0$call-height$arg-0$call-Spacer$fun-$anonymous$$arg-3$call-Column$fun-ButtonWrapper, reason: not valid java name */
    private static State<Integer> f1758State$Int$$$this$call$getdp$$arg0$callheight$arg0$callSpacer$fun$anonymous$$arg3$callColumn$funButtonWrapper;
    public static final LiveLiterals$RemoteControlScreenKt INSTANCE = new LiveLiterals$RemoteControlScreenKt();

    /* JADX INFO: renamed from: Int$$$this$call-$get-dp$$arg-0$call-height$arg-0$call-Spacer$fun-$anonymous$$arg-3$call-Column$fun-ButtonWrapper, reason: not valid java name */
    private static int f1754Int$$$this$call$getdp$$arg0$callheight$arg0$callSpacer$fun$anonymous$$arg3$callColumn$funButtonWrapper = 4;

    /* JADX INFO: renamed from: Float$arg-0$call-weight$arg-0$call-ControllerWrapper$fun-$anonymous$$arg-3$call-Row$fun-Controllers, reason: not valid java name */
    private static float f1751Float$arg0$callweight$arg0$callControllerWrapper$fun$anonymous$$arg3$callRow$funControllers = 1.0f;

    /* JADX INFO: renamed from: Float$arg-0$call-weight$arg-0$call-ControllerWrapper-1$fun-$anonymous$$arg-3$call-Row$fun-Controllers, reason: not valid java name */
    private static float f1752Float$arg0$callweight$arg0$callControllerWrapper1$fun$anonymous$$arg3$callRow$funControllers = 1.0f;

    /* JADX INFO: renamed from: Int$$$this$call-$get-dp$$arg-0$call-BorderStroke$fun-$anonymous$$arg-0$call-remember$val-border$fun-ControllerWrapper, reason: not valid java name */
    private static int f1753Int$$$this$call$getdp$$arg0$callBorderStroke$fun$anonymous$$arg0$callremember$valborder$funControllerWrapper = 2;

    @LiveLiteralInfo(key = "Float$arg-0$call-weight$arg-0$call-ControllerWrapper$fun-$anonymous$$arg-3$call-Row$fun-Controllers", offset = 3360)
    /* JADX INFO: renamed from: Float$arg-0$call-weight$arg-0$call-ControllerWrapper$fun-$anonymous$$arg-3$call-Row$fun-Controllers, reason: not valid java name */
    public final float m6839Float$arg0$callweight$arg0$callControllerWrapper$fun$anonymous$$arg3$callRow$funControllers() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1751Float$arg0$callweight$arg0$callControllerWrapper$fun$anonymous$$arg3$callRow$funControllers;
        }
        State<Float> stateLiveLiteral = f1755State$Float$arg0$callweight$arg0$callControllerWrapper$fun$anonymous$$arg3$callRow$funControllers;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-weight$arg-0$call-ControllerWrapper$fun-$anonymous$$arg-3$call-Row$fun-Controllers", Float.valueOf(f1751Float$arg0$callweight$arg0$callControllerWrapper$fun$anonymous$$arg3$callRow$funControllers));
            f1755State$Float$arg0$callweight$arg0$callControllerWrapper$fun$anonymous$$arg3$callRow$funControllers = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-weight$arg-0$call-ControllerWrapper-1$fun-$anonymous$$arg-3$call-Row$fun-Controllers", offset = 3513)
    /* JADX INFO: renamed from: Float$arg-0$call-weight$arg-0$call-ControllerWrapper-1$fun-$anonymous$$arg-3$call-Row$fun-Controllers, reason: not valid java name */
    public final float m6840Float$arg0$callweight$arg0$callControllerWrapper1$fun$anonymous$$arg3$callRow$funControllers() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1752Float$arg0$callweight$arg0$callControllerWrapper1$fun$anonymous$$arg3$callRow$funControllers;
        }
        State<Float> stateLiveLiteral = f1756State$Float$arg0$callweight$arg0$callControllerWrapper1$fun$anonymous$$arg3$callRow$funControllers;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-weight$arg-0$call-ControllerWrapper-1$fun-$anonymous$$arg-3$call-Row$fun-Controllers", Float.valueOf(f1752Float$arg0$callweight$arg0$callControllerWrapper1$fun$anonymous$$arg3$callRow$funControllers));
            f1756State$Float$arg0$callweight$arg0$callControllerWrapper1$fun$anonymous$$arg3$callRow$funControllers = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Int$$$this$call-$get-dp$$arg-0$call-BorderStroke$fun-$anonymous$$arg-0$call-remember$val-border$fun-ControllerWrapper", offset = 3852)
    /* JADX INFO: renamed from: Int$$$this$call-$get-dp$$arg-0$call-BorderStroke$fun-$anonymous$$arg-0$call-remember$val-border$fun-ControllerWrapper, reason: not valid java name */
    public final int m6841Int$$$this$call$getdp$$arg0$callBorderStroke$fun$anonymous$$arg0$callremember$valborder$funControllerWrapper() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1753Int$$$this$call$getdp$$arg0$callBorderStroke$fun$anonymous$$arg0$callremember$valborder$funControllerWrapper;
        }
        State<Integer> stateLiveLiteral = f1757State$Int$$$this$call$getdp$$arg0$callBorderStroke$fun$anonymous$$arg0$callremember$valborder$funControllerWrapper;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$$this$call-$get-dp$$arg-0$call-BorderStroke$fun-$anonymous$$arg-0$call-remember$val-border$fun-ControllerWrapper", Integer.valueOf(f1753Int$$$this$call$getdp$$arg0$callBorderStroke$fun$anonymous$$arg0$callremember$valborder$funControllerWrapper));
            f1757State$Int$$$this$call$getdp$$arg0$callBorderStroke$fun$anonymous$$arg0$callremember$valborder$funControllerWrapper = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$$this$call-$get-dp$$arg-0$call-height$arg-0$call-Spacer$fun-$anonymous$$arg-3$call-Column$fun-ButtonWrapper", offset = 3127)
    /* JADX INFO: renamed from: Int$$$this$call-$get-dp$$arg-0$call-height$arg-0$call-Spacer$fun-$anonymous$$arg-3$call-Column$fun-ButtonWrapper, reason: not valid java name */
    public final int m6842Int$$$this$call$getdp$$arg0$callheight$arg0$callSpacer$fun$anonymous$$arg3$callColumn$funButtonWrapper() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1754Int$$$this$call$getdp$$arg0$callheight$arg0$callSpacer$fun$anonymous$$arg3$callColumn$funButtonWrapper;
        }
        State<Integer> stateLiveLiteral = f1758State$Int$$$this$call$getdp$$arg0$callheight$arg0$callSpacer$fun$anonymous$$arg3$callColumn$funButtonWrapper;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$$this$call-$get-dp$$arg-0$call-height$arg-0$call-Spacer$fun-$anonymous$$arg-3$call-Column$fun-ButtonWrapper", Integer.valueOf(f1754Int$$$this$call$getdp$$arg0$callheight$arg0$callSpacer$fun$anonymous$$arg3$callColumn$funButtonWrapper));
            f1758State$Int$$$this$call$getdp$$arg0$callheight$arg0$callSpacer$fun$anonymous$$arg3$callColumn$funButtonWrapper = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }
}
