package vea.raceremote.features.remote_control.presentation.view;

import androidx.compose.foundation.BorderKt;
import androidx.compose.foundation.BorderStroke;
import androidx.compose.foundation.BorderStrokeKt;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.layout.SpacerKt;
import androidx.compose.foundation.shape.RoundedCornerShape;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.ProvidableCompositionLocal;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.SkippableUpdater;
import androidx.compose.runtime.SnapshotStateKt;
import androidx.compose.runtime.State;
import androidx.compose.runtime.Updater;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.draw.ClipKt;
import androidx.compose.ui.layout.LayoutKt;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.platform.CompositionLocalsKt;
import androidx.compose.ui.platform.ViewConfiguration;
import androidx.compose.ui.unit.Density;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.unit.LayoutDirection;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelLazy;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import org.koin.androidx.compose.ViewModelComposeExtKt;
import org.koin.androidx.viewmodel.ViewModelOwner;
import org.koin.androidx.viewmodel.ViewModelParameter;
import org.koin.androidx.viewmodel.ViewModelResolverKt;
import org.koin.core.context.GlobalContext;
import org.koin.core.qualifier.Qualifier;
import org.koin.core.scope.Scope;
import vea.raceremote.features.remote_control.presentation.ActionsViewModel;
import vea.raceremote.features.remote_control.presentation.RemoteControlViewModel;
import vea.raceremote.features.remote_control.presentation.model.Action;
import vea.raceremote.ui.theme.CornerShapes;
import vea.raceremote.ui.theme.Padding;
import vea.raceremote.ui.theme.Size;
import vea.raceremote.ui.theme.ThemeKt;
import vea.raceremote.ui.views.ButtonsKt;
import vea.raceremote.ui.views.DotsState;
import vea.raceremote.ui.views.FlatLoadingWithContentKt;
import vea.raceremote.ui.views.Orientation;
import vea.raceremote.ui.views.SliderKt;

/* JADX INFO: compiled from: RemoteControlScreen.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u00008\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0010\u0007\n\u0002\b\u0005\u001a%\u0010\u0000\u001a\u00020\u00012\b\b\u0002\u0010\u0002\u001a\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005H\u0007¢\u0006\u0002\u0010\u0007\u001a0\u0010\b\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\n2\u0011\u0010\u000b\u001a\r\u0012\u0004\u0012\u00020\u00010\f¢\u0006\u0002\b\rH\u0003¢\u0006\u0002\u0010\u000e\u001a(\u0010\u000f\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0011\u0010\u000b\u001a\r\u0012\u0004\u0012\u00020\u00010\f¢\u0006\u0002\b\rH\u0003¢\u0006\u0002\u0010\u0010\u001a=\u0010\u0011\u001a\u00020\u00012\u0016\b\u0002\u0010\u0012\u001a\u0010\u0012\u0004\u0012\u00020\u0014\u0012\u0004\u0012\u00020\u0001\u0018\u00010\u00132\u0016\b\u0002\u0010\u0015\u001a\u0010\u0012\u0004\u0012\u00020\u0014\u0012\u0004\u0012\u00020\u0001\u0018\u00010\u0013H\u0003¢\u0006\u0002\u0010\u0016\u001a\u0017\u0010\u0017\u001a\u00020\u00012\b\b\u0002\u0010\u0002\u001a\u00020\u0003H\u0007¢\u0006\u0002\u0010\u0018¨\u0006\u0019"}, d2 = {"Actions", "", "modifier", "Landroidx/compose/ui/Modifier;", "actions", "", "Lvea/raceremote/features/remote_control/presentation/model/Action;", "(Landroidx/compose/ui/Modifier;Ljava/util/List;Landroidx/compose/runtime/Composer;II)V", "ButtonWrapper", "state", "Lvea/raceremote/ui/views/DotsState;", "content", "Lkotlin/Function0;", "Landroidx/compose/runtime/Composable;", "(Landroidx/compose/ui/Modifier;Lvea/raceremote/ui/views/DotsState;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;I)V", "ControllerWrapper", "(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;I)V", "Controllers", "horizontalSlider", "Lkotlin/Function1;", "", "verticalSlider", "(Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V", "RemoteControlScreen", "(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class RemoteControlScreenKt {
    /* JADX WARN: Multi-variable type inference failed */
    public static final void RemoteControlScreen(Modifier modifier, Composer $composer, final int $changed, final int i) {
        final Modifier modifier2;
        Object value$iv$iv$iv$iv;
        Composer $composer2 = $composer.startRestartGroup(2043249864);
        ComposerKt.sourceInformation($composer2, "C(RemoteControlScreen)39@1672L32,40@1738L38,42@1821L37,44@1864L282:RemoteControlScreen.kt#7brr7p");
        int $dirty = $changed;
        int i2 = i & 1;
        if (i2 != 0) {
            $dirty |= 6;
            modifier2 = modifier;
        } else if (($changed & 14) == 0) {
            modifier2 = modifier;
            $dirty |= $composer2.changed(modifier2) ? 4 : 2;
        } else {
            modifier2 = modifier;
        }
        int $dirty2 = $dirty;
        if (($dirty2 & 11) == 2 && $composer2.getSkipping()) {
            $composer2.skipToGroupEnd();
        } else {
            Modifier modifier3 = i2 != 0 ? Modifier.INSTANCE : modifier2;
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(2043249864, $dirty2, -1, "vea.raceremote.features.remote_control.presentation.view.RemoteControlScreen (RemoteControlScreen.kt:36)");
            }
            $composer2.startReplaceableGroup(1509148303);
            ComposerKt.sourceInformation($composer2, "C(getViewModel)P(2!1,3)");
            final Qualifier qualifier$iv = null;
            final Scope scope$iv = GlobalContext.INSTANCE.get().getScopeRegistry().getRootScope();
            final Function0 parameters$iv = null;
            int $changed$iv$iv = (0 & 7168) | 584;
            $composer2.startReplaceableGroup(-1688186670);
            ComposerKt.sourceInformation($composer2, "C(viewModel)P(2!1,3)");
            $composer2.startReplaceableGroup(-1688186362);
            final ViewModelOwner storeOwner$iv$iv = ViewModelComposeExtKt.getComposeViewModelOwner($composer2, 0);
            $composer2.endReplaceableGroup();
            int i3 = (($changed$iv$iv >> 6) & 112) | 8;
            $composer2.startReplaceableGroup(-3686552);
            ComposerKt.sourceInformation($composer2, "C(remember)P(1,2):Composables.kt#9igjgp");
            boolean invalid$iv$iv$iv$iv = $composer2.changed((Object) null) | $composer2.changed((Object) null);
            Object value$iv$iv$iv$iv2 = $composer2.rememberedValue();
            if (invalid$iv$iv$iv$iv || value$iv$iv$iv$iv2 == Composer.INSTANCE.getEmpty()) {
                value$iv$iv$iv$iv2 = new ViewModelLazy(Reflection.getOrCreateKotlinClass(ActionsViewModel.class), new Function0<ViewModelStore>() { // from class: vea.raceremote.features.remote_control.presentation.view.RemoteControlScreenKt$RemoteControlScreen$$inlined$getViewModel$1
                    {
                        super(0);
                    }

                    /* JADX WARN: Can't rename method to resolve collision */
                    @Override // kotlin.jvm.functions.Function0
                    public final ViewModelStore invoke() {
                        ViewModelStore viewModelStore = getStoreOwner().getViewModelStore();
                        Intrinsics.checkNotNullExpressionValue(viewModelStore, "storeOwner.storeOwner.viewModelStore");
                        return viewModelStore;
                    }
                }, new Function0<ViewModelProvider.Factory>() { // from class: vea.raceremote.features.remote_control.presentation.view.RemoteControlScreenKt$RemoteControlScreen$$inlined$getViewModel$2
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    /* JADX WARN: Can't rename method to resolve collision */
                    @Override // kotlin.jvm.functions.Function0
                    public final ViewModelProvider.Factory invoke() {
                        ViewModelOwner ownerValue$iv = storeOwner$iv$iv;
                        Qualifier qualifier$iv2 = qualifier$iv;
                        Function0 parameters$iv2 = parameters$iv;
                        Scope scope$iv2 = scope$iv;
                        ViewModelParameter viewModelParameters$iv = new ViewModelParameter(Reflection.getOrCreateKotlinClass(ActionsViewModel.class), qualifier$iv2, null, parameters$iv2, ownerValue$iv.getStoreOwner(), ownerValue$iv.getStateRegistry());
                        return ViewModelResolverKt.pickFactory(scope$iv2, viewModelParameters$iv);
                    }
                });
                $composer2.updateRememberedValue(value$iv$iv$iv$iv2);
            }
            $composer2.endReplaceableGroup();
            $composer2.endReplaceableGroup();
            ViewModel viewModel = (ViewModel) ((ViewModelLazy) value$iv$iv$iv$iv2).getValue();
            $composer2.endReplaceableGroup();
            ActionsViewModel actionsViewModel = (ActionsViewModel) viewModel;
            $composer2.startReplaceableGroup(1509148303);
            ComposerKt.sourceInformation($composer2, "C(getViewModel)P(2!1,3)");
            final Qualifier qualifier$iv2 = null;
            final Scope scope$iv2 = GlobalContext.INSTANCE.get().getScopeRegistry().getRootScope();
            final Function0 parameters$iv2 = null;
            int $changed$iv$iv2 = (0 & 7168) | 584;
            $composer2.startReplaceableGroup(-1688186670);
            ComposerKt.sourceInformation($composer2, "C(viewModel)P(2!1,3)");
            $composer2.startReplaceableGroup(-1688186362);
            final ViewModelOwner storeOwner$iv$iv2 = ViewModelComposeExtKt.getComposeViewModelOwner($composer2, 0);
            $composer2.endReplaceableGroup();
            int i4 = (($changed$iv$iv2 >> 6) & 112) | 8;
            $composer2.startReplaceableGroup(-3686552);
            ComposerKt.sourceInformation($composer2, "C(remember)P(1,2):Composables.kt#9igjgp");
            boolean invalid$iv$iv$iv$iv2 = $composer2.changed((Object) null) | $composer2.changed((Object) null);
            Object it$iv$iv$iv$iv = $composer2.rememberedValue();
            if (invalid$iv$iv$iv$iv2 || it$iv$iv$iv$iv == Composer.INSTANCE.getEmpty()) {
                value$iv$iv$iv$iv = new ViewModelLazy(Reflection.getOrCreateKotlinClass(RemoteControlViewModel.class), new Function0<ViewModelStore>() { // from class: vea.raceremote.features.remote_control.presentation.view.RemoteControlScreenKt$RemoteControlScreen$$inlined$getViewModel$3
                    {
                        super(0);
                    }

                    /* JADX WARN: Can't rename method to resolve collision */
                    @Override // kotlin.jvm.functions.Function0
                    public final ViewModelStore invoke() {
                        ViewModelStore viewModelStore = getStoreOwner().getViewModelStore();
                        Intrinsics.checkNotNullExpressionValue(viewModelStore, "storeOwner.storeOwner.viewModelStore");
                        return viewModelStore;
                    }
                }, new Function0<ViewModelProvider.Factory>() { // from class: vea.raceremote.features.remote_control.presentation.view.RemoteControlScreenKt$RemoteControlScreen$$inlined$getViewModel$4
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    /* JADX WARN: Can't rename method to resolve collision */
                    @Override // kotlin.jvm.functions.Function0
                    public final ViewModelProvider.Factory invoke() {
                        ViewModelOwner ownerValue$iv = storeOwner$iv$iv2;
                        Qualifier qualifier$iv3 = qualifier$iv2;
                        Function0 parameters$iv3 = parameters$iv2;
                        Scope scope$iv3 = scope$iv2;
                        ViewModelParameter viewModelParameters$iv = new ViewModelParameter(Reflection.getOrCreateKotlinClass(RemoteControlViewModel.class), qualifier$iv3, null, parameters$iv3, ownerValue$iv.getStoreOwner(), ownerValue$iv.getStateRegistry());
                        return ViewModelResolverKt.pickFactory(scope$iv3, viewModelParameters$iv);
                    }
                });
                $composer2.updateRememberedValue(value$iv$iv$iv$iv);
            } else {
                value$iv$iv$iv$iv = it$iv$iv$iv$iv;
            }
            $composer2.endReplaceableGroup();
            $composer2.endReplaceableGroup();
            ViewModel viewModel2 = (ViewModel) ((ViewModelLazy) value$iv$iv$iv$iv).getValue();
            $composer2.endReplaceableGroup();
            final RemoteControlViewModel remoteControlViewModel = (RemoteControlViewModel) viewModel2;
            State actions = SnapshotStateKt.collectAsState(actionsViewModel.getActions(), CollectionsKt.emptyList(), null, $composer2, 56, 2);
            Alignment.Horizontal horizontalAlignment$iv = Alignment.INSTANCE.getCenterHorizontally();
            int $changed$iv = ($dirty2 & 14) | 384;
            $composer2.startReplaceableGroup(-483455358);
            ComposerKt.sourceInformation($composer2, "C(Column)P(2,3,1)77@3880L61,78@3946L133:Column.kt#2w3rfo");
            Arrangement.Vertical verticalArrangement$iv = Arrangement.INSTANCE.getTop();
            MeasurePolicy measurePolicy$iv = ColumnKt.columnMeasurePolicy(verticalArrangement$iv, horizontalAlignment$iv, $composer2, (($changed$iv >> 3) & 14) | (($changed$iv >> 3) & 112));
            int $changed$iv$iv3 = ($changed$iv << 3) & 112;
            $composer2.startReplaceableGroup(-1323940314);
            ComposerKt.sourceInformation($composer2, "C(Layout)P(!1,2)74@2915L7,75@2970L7,76@3029L7,77@3041L460:Layout.kt#80mrfh");
            ProvidableCompositionLocal<Density> localDensity = CompositionLocalsKt.getLocalDensity();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume = $composer2.consume(localDensity);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            Density density$iv$iv = (Density) objConsume;
            ProvidableCompositionLocal<LayoutDirection> localLayoutDirection = CompositionLocalsKt.getLocalLayoutDirection();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume2 = $composer2.consume(localLayoutDirection);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            LayoutDirection layoutDirection$iv$iv = (LayoutDirection) objConsume2;
            ProvidableCompositionLocal<ViewConfiguration> localViewConfiguration = CompositionLocalsKt.getLocalViewConfiguration();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume3 = $composer2.consume(localViewConfiguration);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ViewConfiguration viewConfiguration$iv$iv = (ViewConfiguration) objConsume3;
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            Function3<SkippableUpdater<ComposeUiNode>, Composer, Integer, Unit> function3MaterializerOf = LayoutKt.materializerOf(modifier3);
            Modifier modifier4 = modifier3;
            int $changed$iv$iv$iv = (($changed$iv$iv3 << 9) & 7168) | 6;
            if (!($composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer2.startReusableNode();
            if ($composer2.getInserting()) {
                $composer2.createNode(constructor);
            } else {
                $composer2.useNode();
            }
            $composer2.disableReusing();
            Composer $this$Layout_u24lambda_u2d0$iv$iv = Updater.m1304constructorimpl($composer2);
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, measurePolicy$iv, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, density$iv$iv, ComposeUiNode.INSTANCE.getSetDensity());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, layoutDirection$iv$iv, ComposeUiNode.INSTANCE.getSetLayoutDirection());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, viewConfiguration$iv$iv, ComposeUiNode.INSTANCE.getSetViewConfiguration());
            $composer2.enableReusing();
            function3MaterializerOf.invoke(SkippableUpdater.m1294boximpl(SkippableUpdater.m1295constructorimpl($composer2)), $composer2, Integer.valueOf(($changed$iv$iv$iv >> 3) & 112));
            $composer2.startReplaceableGroup(2058660585);
            $composer2.startReplaceableGroup(-1163856341);
            ComposerKt.sourceInformation($composer2, "C79@3994L9:Column.kt#2w3rfo");
            if ((($changed$iv$iv$iv >> 9) & 14 & 11) == 2 && $composer2.getSkipping()) {
                $composer2.skipToGroupEnd();
            } else {
                ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                int i5 = (($changed$iv >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart($composer2, -1237824375, "C45@1954L32,46@1995L145:RemoteControlScreen.kt#7brr7p");
                Actions(null, (List) actions.getValue(), $composer2, 64, 1);
                Controllers(new Function1<Float, Unit>() { // from class: vea.raceremote.features.remote_control.presentation.view.RemoteControlScreenKt$RemoteControlScreen$1$1
                    {
                        super(1);
                    }

                    @Override // kotlin.jvm.functions.Function1
                    public /* bridge */ /* synthetic */ Unit invoke(Float f) {
                        invoke(f.floatValue());
                        return Unit.INSTANCE;
                    }

                    public final void invoke(float it) {
                        remoteControlViewModel.updateSteeringWheel(it);
                    }
                }, new Function1<Float, Unit>() { // from class: vea.raceremote.features.remote_control.presentation.view.RemoteControlScreenKt$RemoteControlScreen$1$2
                    {
                        super(1);
                    }

                    @Override // kotlin.jvm.functions.Function1
                    public /* bridge */ /* synthetic */ Unit invoke(Float f) {
                        invoke(f.floatValue());
                        return Unit.INSTANCE;
                    }

                    public final void invoke(float it) {
                        remoteControlViewModel.updateMovement(it);
                    }
                }, $composer2, 0, 0);
                ComposerKt.sourceInformationMarkerEnd($composer2);
            }
            $composer2.endReplaceableGroup();
            $composer2.endReplaceableGroup();
            $composer2.endNode();
            $composer2.endReplaceableGroup();
            $composer2.endReplaceableGroup();
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
            modifier2 = modifier4;
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.features.remote_control.presentation.view.RemoteControlScreenKt.RemoteControlScreen.2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i6) {
                RemoteControlScreenKt.RemoteControlScreen(modifier2, composer, $changed | 1, i);
            }
        });
    }

    public static final void Actions(Modifier modifier, final List<Action> list, Composer $composer, final int $changed, final int i) {
        final Modifier.Companion modifier2;
        Intrinsics.checkNotNullParameter(list, "actions");
        Composer $composer2 = $composer.startRestartGroup(1321957784);
        ComposerKt.sourceInformation($composer2, "C(Actions)P(1)58@2245L507:RemoteControlScreen.kt#7brr7p");
        if ((i & 1) != 0) {
            modifier2 = Modifier.INSTANCE;
        } else {
            modifier2 = modifier;
        }
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventStart(1321957784, $changed, -1, "vea.raceremote.features.remote_control.presentation.view.Actions (RemoteControlScreen.kt:54)");
        }
        Arrangement.Horizontal horizontalArrangement$iv = Arrangement.INSTANCE.getCenter();
        int $changed$iv = ($changed & 14) | 48;
        $composer2.startReplaceableGroup(693286680);
        ComposerKt.sourceInformation($composer2, "C(Row)P(2,1,3)78@3880L58,79@3943L130:Row.kt#2w3rfo");
        Alignment.Vertical verticalAlignment$iv = Alignment.INSTANCE.getTop();
        MeasurePolicy measurePolicy$iv = RowKt.rowMeasurePolicy(horizontalArrangement$iv, verticalAlignment$iv, $composer2, (($changed$iv >> 3) & 14) | (($changed$iv >> 3) & 112));
        int $changed$iv$iv = ($changed$iv << 3) & 112;
        $composer2.startReplaceableGroup(-1323940314);
        ComposerKt.sourceInformation($composer2, "C(Layout)P(!1,2)74@2915L7,75@2970L7,76@3029L7,77@3041L460:Layout.kt#80mrfh");
        ProvidableCompositionLocal<Density> localDensity = CompositionLocalsKt.getLocalDensity();
        ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
        Object objConsume = $composer2.consume(localDensity);
        ComposerKt.sourceInformationMarkerEnd($composer2);
        Density density$iv$iv = (Density) objConsume;
        ProvidableCompositionLocal<LayoutDirection> localLayoutDirection = CompositionLocalsKt.getLocalLayoutDirection();
        ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
        Object objConsume2 = $composer2.consume(localLayoutDirection);
        ComposerKt.sourceInformationMarkerEnd($composer2);
        LayoutDirection layoutDirection$iv$iv = (LayoutDirection) objConsume2;
        ProvidableCompositionLocal<ViewConfiguration> localViewConfiguration = CompositionLocalsKt.getLocalViewConfiguration();
        ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
        Object objConsume3 = $composer2.consume(localViewConfiguration);
        ComposerKt.sourceInformationMarkerEnd($composer2);
        ViewConfiguration viewConfiguration$iv$iv = (ViewConfiguration) objConsume3;
        Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
        Function3<SkippableUpdater<ComposeUiNode>, Composer, Integer, Unit> function3MaterializerOf = LayoutKt.materializerOf(modifier2);
        int $dirty = $changed$iv$iv << 9;
        int $changed$iv$iv$iv = ($dirty & 7168) | 6;
        if (!($composer2.getApplier() instanceof Applier)) {
            ComposablesKt.invalidApplier();
        }
        $composer2.startReusableNode();
        if ($composer2.getInserting()) {
            $composer2.createNode(constructor);
        } else {
            $composer2.useNode();
        }
        $composer2.disableReusing();
        Composer $this$Layout_u24lambda_u2d0$iv$iv = Updater.m1304constructorimpl($composer2);
        Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, measurePolicy$iv, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
        Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, density$iv$iv, ComposeUiNode.INSTANCE.getSetDensity());
        Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, layoutDirection$iv$iv, ComposeUiNode.INSTANCE.getSetLayoutDirection());
        Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, viewConfiguration$iv$iv, ComposeUiNode.INSTANCE.getSetViewConfiguration());
        $composer2.enableReusing();
        function3MaterializerOf.invoke(SkippableUpdater.m1294boximpl(SkippableUpdater.m1295constructorimpl($composer2)), $composer2, Integer.valueOf(($changed$iv$iv$iv >> 3) & 112));
        $composer2.startReplaceableGroup(2058660585);
        int $changed$iv2 = ($changed$iv$iv$iv >> 9) & 14;
        $composer2.startReplaceableGroup(-678309503);
        ComposerKt.sourceInformation($composer2, "C80@3988L9:Row.kt#2w3rfo");
        if (($changed$iv2 & 11) == 2 && $composer2.getSkipping()) {
            $composer2.skipToGroupEnd();
        } else {
            RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
            int i2 = (($changed$iv >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer2, -1554857385, "C:RemoteControlScreen.kt#7brr7p");
            $composer2.startReplaceableGroup(223146558);
            ComposerKt.sourceInformation($composer2, "*63@2386L350");
            List<Action> $this$forEach$iv = list;
            int $i$f$forEach = 0;
            for (Object element$iv : $this$forEach$iv) {
                Iterable $this$forEach$iv2 = $this$forEach$iv;
                final Action action = (Action) element$iv;
                ButtonWrapper(SizeKt.m473width3ABfNKs(PaddingKt.m427padding3ABfNKs(Modifier.INSTANCE, Padding.INSTANCE.m6886getContentD9Ej5fM()), Size.INSTANCE.m6888getButtonAsIconD9Ej5fM()), action.getState(), ComposableLambdaKt.composableLambda($composer2, -708138083, true, new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.features.remote_control.presentation.view.RemoteControlScreenKt$Actions$1$1$1
                    {
                        super(2);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                        invoke(composer, num.intValue());
                        return Unit.INSTANCE;
                    }

                    public final void invoke(Composer $composer3, int $changed2) {
                        Object value$iv$iv;
                        ComposerKt.sourceInformation($composer3, "C71@2683L20,69@2599L123:RemoteControlScreen.kt#7brr7p");
                        if (($changed2 & 11) != 2 || !$composer3.getSkipping()) {
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventStart(-708138083, $changed2, -1, "vea.raceremote.features.remote_control.presentation.view.Actions.<anonymous>.<anonymous>.<anonymous> (RemoteControlScreen.kt:68)");
                            }
                            int icon = action.getIcon();
                            Object key1$iv = action;
                            final Action action2 = action;
                            $composer3.startReplaceableGroup(1157296644);
                            ComposerKt.sourceInformation($composer3, "C(remember)P(1):Composables.kt#9igjgp");
                            boolean invalid$iv$iv = $composer3.changed(key1$iv);
                            Object it$iv$iv = $composer3.rememberedValue();
                            if (invalid$iv$iv || it$iv$iv == Composer.INSTANCE.getEmpty()) {
                                value$iv$iv = new Function0<Unit>() { // from class: vea.raceremote.features.remote_control.presentation.view.RemoteControlScreenKt$Actions$1$1$1$1$1
                                    {
                                        super(0);
                                    }

                                    @Override // kotlin.jvm.functions.Function0
                                    public /* bridge */ /* synthetic */ Unit invoke() {
                                        invoke2();
                                        return Unit.INSTANCE;
                                    }

                                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                                    public final void invoke2() {
                                        action2.getOnClick().invoke();
                                    }
                                };
                                $composer3.updateRememberedValue(value$iv$iv);
                            } else {
                                value$iv$iv = it$iv$iv;
                            }
                            $composer3.endReplaceableGroup();
                            ButtonsKt.ActionButton(null, icon, (Function0) value$iv$iv, $composer3, 0, 1);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                                return;
                            }
                            return;
                        }
                        $composer3.skipToGroupEnd();
                    }
                }), $composer2, 390);
                $this$forEach$iv = $this$forEach$iv2;
                measurePolicy$iv = measurePolicy$iv;
                $i$f$forEach = $i$f$forEach;
                $changed$iv2 = $changed$iv2;
                $changed$iv$iv = $changed$iv$iv;
            }
            $composer2.endReplaceableGroup();
            ComposerKt.sourceInformationMarkerEnd($composer2);
        }
        $composer2.endReplaceableGroup();
        $composer2.endReplaceableGroup();
        $composer2.endNode();
        $composer2.endReplaceableGroup();
        $composer2.endReplaceableGroup();
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventEnd();
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.features.remote_control.presentation.view.RemoteControlScreenKt.Actions.2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i3) {
                RemoteControlScreenKt.Actions(modifier2, list, composer, $changed | 1, i);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void ButtonWrapper(final Modifier modifier, final DotsState state, final Function2<? super Composer, ? super Integer, Unit> function2, Composer $composer, final int $changed) {
        Composer $composer2 = $composer.startRestartGroup(1287574577);
        ComposerKt.sourceInformation($composer2, "C(ButtonWrapper)P(1,2)84@2885L272:RemoteControlScreen.kt#7brr7p");
        int $dirty = $changed;
        if (($changed & 14) == 0) {
            $dirty |= $composer2.changed(modifier) ? 4 : 2;
        }
        if (($changed & 112) == 0) {
            $dirty |= $composer2.changed(state) ? 32 : 16;
        }
        if (($changed & 896) == 0) {
            $dirty |= $composer2.changed(function2) ? 256 : 128;
        }
        if (($dirty & 731) != 146 || !$composer2.getSkipping()) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1287574577, $dirty, -1, "vea.raceremote.features.remote_control.presentation.view.ButtonWrapper (RemoteControlScreen.kt:79)");
            }
            Arrangement.Vertical verticalArrangement$iv = Arrangement.INSTANCE.getBottom();
            Alignment.Horizontal horizontalAlignment$iv = Alignment.INSTANCE.getCenterHorizontally();
            int $changed$iv = ($dirty & 14) | 432;
            $composer2.startReplaceableGroup(-483455358);
            ComposerKt.sourceInformation($composer2, "C(Column)P(2,3,1)77@3880L61,78@3946L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicy$iv = ColumnKt.columnMeasurePolicy(verticalArrangement$iv, horizontalAlignment$iv, $composer2, (($changed$iv >> 3) & 14) | (($changed$iv >> 3) & 112));
            int $changed$iv$iv = ($changed$iv << 3) & 112;
            $composer2.startReplaceableGroup(-1323940314);
            ComposerKt.sourceInformation($composer2, "C(Layout)P(!1,2)74@2915L7,75@2970L7,76@3029L7,77@3041L460:Layout.kt#80mrfh");
            ProvidableCompositionLocal<Density> localDensity = CompositionLocalsKt.getLocalDensity();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume = $composer2.consume(localDensity);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            Density density$iv$iv = (Density) objConsume;
            ProvidableCompositionLocal<LayoutDirection> localLayoutDirection = CompositionLocalsKt.getLocalLayoutDirection();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume2 = $composer2.consume(localLayoutDirection);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            LayoutDirection layoutDirection$iv$iv = (LayoutDirection) objConsume2;
            ProvidableCompositionLocal<ViewConfiguration> localViewConfiguration = CompositionLocalsKt.getLocalViewConfiguration();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume3 = $composer2.consume(localViewConfiguration);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ViewConfiguration viewConfiguration$iv$iv = (ViewConfiguration) objConsume3;
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            Function3<SkippableUpdater<ComposeUiNode>, Composer, Integer, Unit> function3MaterializerOf = LayoutKt.materializerOf(modifier);
            int $i$f$Column = $changed$iv$iv << 9;
            int $changed$iv$iv$iv = ($i$f$Column & 7168) | 6;
            if (!($composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer2.startReusableNode();
            if ($composer2.getInserting()) {
                $composer2.createNode(constructor);
            } else {
                $composer2.useNode();
            }
            $composer2.disableReusing();
            Composer $this$Layout_u24lambda_u2d0$iv$iv = Updater.m1304constructorimpl($composer2);
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, measurePolicy$iv, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, density$iv$iv, ComposeUiNode.INSTANCE.getSetDensity());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, layoutDirection$iv$iv, ComposeUiNode.INSTANCE.getSetLayoutDirection());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, viewConfiguration$iv$iv, ComposeUiNode.INSTANCE.getSetViewConfiguration());
            $composer2.enableReusing();
            function3MaterializerOf.invoke(SkippableUpdater.m1294boximpl(SkippableUpdater.m1295constructorimpl($composer2)), $composer2, Integer.valueOf(($changed$iv$iv$iv >> 3) & 112));
            $composer2.startReplaceableGroup(2058660585);
            $composer2.startReplaceableGroup(-1163856341);
            ComposerKt.sourceInformation($composer2, "C79@3994L9:Column.kt#2w3rfo");
            if ((($changed$iv$iv$iv >> 9) & 14 & 11) == 2 && $composer2.getSkipping()) {
                $composer2.skipToGroupEnd();
            } else {
                ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                int i = (($changed$iv >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart($composer2, 2105690320, "C89@3047L37,90@3093L40,91@3142L9:RemoteControlScreen.kt#7brr7p");
                FlatLoadingWithContentKt.FlatLoadingWithContent(null, state, $composer2, $dirty & 112, 1);
                Modifier.Companion companion = Modifier.INSTANCE;
                int $this$dp$iv = LiveLiterals$RemoteControlScreenKt.INSTANCE.m6842Int$$$this$call$getdp$$arg0$callheight$arg0$callSpacer$fun$anonymous$$arg3$callColumn$funButtonWrapper();
                SpacerKt.Spacer(SizeKt.m454height3ABfNKs(companion, Dp.m4046constructorimpl($this$dp$iv)), $composer2, 0);
                function2.invoke($composer2, Integer.valueOf(($dirty >> 6) & 14));
                ComposerKt.sourceInformationMarkerEnd($composer2);
            }
            $composer2.endReplaceableGroup();
            $composer2.endReplaceableGroup();
            $composer2.endNode();
            $composer2.endReplaceableGroup();
            $composer2.endReplaceableGroup();
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            $composer2.skipToGroupEnd();
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.features.remote_control.presentation.view.RemoteControlScreenKt.ButtonWrapper.2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i2) {
                RemoteControlScreenKt.ButtonWrapper(modifier, state, function2, composer, $changed | 1);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void Controllers(Function1<? super Float, Unit> function1, Function1<? super Float, Unit> function2, Composer $composer, final int $changed, final int i) {
        final Function1<? super Float, Unit> function3;
        final Function1<? super Float, Unit> function4;
        Composer $composer2 = $composer.startRestartGroup(1436275493);
        ComposerKt.sourceInformation($composer2, "C(Controllers)100@3301L348:RemoteControlScreen.kt#7brr7p");
        final int $dirty = $changed;
        int i2 = i & 1;
        if (i2 != 0) {
            $dirty |= 6;
            function3 = function1;
        } else if (($changed & 14) == 0) {
            function3 = function1;
            $dirty |= $composer2.changed(function3) ? 4 : 2;
        } else {
            function3 = function1;
        }
        int i3 = i & 2;
        if (i3 != 0) {
            $dirty |= 48;
            function4 = function2;
        } else if (($changed & 112) == 0) {
            function4 = function2;
            $dirty |= $composer2.changed(function4) ? 32 : 16;
        } else {
            function4 = function2;
        }
        if (($dirty & 91) == 18 && $composer2.getSkipping()) {
            $composer2.skipToGroupEnd();
        } else {
            final Function1<? super Float, Unit> function5 = i2 != 0 ? null : function3;
            final Function1<? super Float, Unit> function6 = i3 != 0 ? null : function4;
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1436275493, $dirty, -1, "vea.raceremote.features.remote_control.presentation.view.Controllers (RemoteControlScreen.kt:96)");
            }
            $composer2.startReplaceableGroup(693286680);
            ComposerKt.sourceInformation($composer2, "C(Row)P(2,1,3)78@3880L58,79@3943L130:Row.kt#2w3rfo");
            Modifier modifier$iv = Modifier.INSTANCE;
            Arrangement.Horizontal horizontalArrangement$iv = Arrangement.INSTANCE.getStart();
            Alignment.Vertical verticalAlignment$iv = Alignment.INSTANCE.getTop();
            MeasurePolicy measurePolicy$iv = RowKt.rowMeasurePolicy(horizontalArrangement$iv, verticalAlignment$iv, $composer2, ((0 >> 3) & 14) | ((0 >> 3) & 112));
            int $changed$iv$iv = (0 << 3) & 112;
            $composer2.startReplaceableGroup(-1323940314);
            ComposerKt.sourceInformation($composer2, "C(Layout)P(!1,2)74@2915L7,75@2970L7,76@3029L7,77@3041L460:Layout.kt#80mrfh");
            ProvidableCompositionLocal<Density> localDensity = CompositionLocalsKt.getLocalDensity();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume = $composer2.consume(localDensity);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            Density density$iv$iv = (Density) objConsume;
            ProvidableCompositionLocal<LayoutDirection> localLayoutDirection = CompositionLocalsKt.getLocalLayoutDirection();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume2 = $composer2.consume(localLayoutDirection);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            LayoutDirection layoutDirection$iv$iv = (LayoutDirection) objConsume2;
            ProvidableCompositionLocal<ViewConfiguration> localViewConfiguration = CompositionLocalsKt.getLocalViewConfiguration();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume3 = $composer2.consume(localViewConfiguration);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ViewConfiguration viewConfiguration$iv$iv = (ViewConfiguration) objConsume3;
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            Function3<SkippableUpdater<ComposeUiNode>, Composer, Integer, Unit> function3MaterializerOf = LayoutKt.materializerOf(modifier$iv);
            int $changed$iv$iv$iv = (($changed$iv$iv << 9) & 7168) | 6;
            if (!($composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer2.startReusableNode();
            if ($composer2.getInserting()) {
                $composer2.createNode(constructor);
            } else {
                $composer2.useNode();
            }
            $composer2.disableReusing();
            Composer $this$Layout_u24lambda_u2d0$iv$iv = Updater.m1304constructorimpl($composer2);
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, measurePolicy$iv, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, density$iv$iv, ComposeUiNode.INSTANCE.getSetDensity());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, layoutDirection$iv$iv, ComposeUiNode.INSTANCE.getSetLayoutDirection());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, viewConfiguration$iv$iv, ComposeUiNode.INSTANCE.getSetViewConfiguration());
            $composer2.enableReusing();
            function3MaterializerOf.invoke(SkippableUpdater.m1294boximpl(SkippableUpdater.m1295constructorimpl($composer2)), $composer2, Integer.valueOf(($changed$iv$iv$iv >> 3) & 112));
            $composer2.startReplaceableGroup(2058660585);
            int $changed$iv = ($changed$iv$iv$iv >> 9) & 14;
            $composer2.startReplaceableGroup(-678309503);
            ComposerKt.sourceInformation($composer2, "C80@3988L9:Row.kt#2w3rfo");
            if (($changed$iv & 11) == 2 && $composer2.getSkipping()) {
                $composer2.skipToGroupEnd();
            } else {
                int i4 = ((0 >> 6) & 112) | 6;
                RowScope $this$Controllers_u24lambda_u244 = RowScopeInstance.INSTANCE;
                ComposerKt.sourceInformationMarkerStart($composer2, -1943100282, "C101@3315L143,107@3468L175:RemoteControlScreen.kt#7brr7p");
                ControllerWrapper(RowScope.weight$default($this$Controllers_u24lambda_u244, Modifier.INSTANCE, LiveLiterals$RemoteControlScreenKt.INSTANCE.m6839Float$arg0$callweight$arg0$callControllerWrapper$fun$anonymous$$arg3$callRow$funControllers(), false, 2, null), ComposableLambdaKt.composableLambda($composer2, 772203924, true, new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.features.remote_control.presentation.view.RemoteControlScreenKt$Controllers$1$1
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    /* JADX WARN: Multi-variable type inference failed */
                    {
                        super(2);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                        invoke(composer, num.intValue());
                        return Unit.INSTANCE;
                    }

                    public final void invoke(Composer $composer3, int $changed2) {
                        Object value$iv$iv;
                        ComposerKt.sourceInformation($composer3, "C102@3388L60,102@3379L69:RemoteControlScreen.kt#7brr7p");
                        if (($changed2 & 11) == 2 && $composer3.getSkipping()) {
                            $composer3.skipToGroupEnd();
                            return;
                        }
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(772203924, $changed2, -1, "vea.raceremote.features.remote_control.presentation.view.Controllers.<anonymous>.<anonymous> (RemoteControlScreen.kt:101)");
                        }
                        Object key1$iv = function5;
                        final Function1<Float, Unit> function7 = function5;
                        int i5 = $dirty & 14;
                        $composer3.startReplaceableGroup(1157296644);
                        ComposerKt.sourceInformation($composer3, "C(remember)P(1):Composables.kt#9igjgp");
                        boolean invalid$iv$iv = $composer3.changed(key1$iv);
                        Object it$iv$iv = $composer3.rememberedValue();
                        if (invalid$iv$iv || it$iv$iv == Composer.INSTANCE.getEmpty()) {
                            value$iv$iv = new Function1<Float, Unit>() { // from class: vea.raceremote.features.remote_control.presentation.view.RemoteControlScreenKt$Controllers$1$1$1$1
                                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                /* JADX WARN: Multi-variable type inference failed */
                                {
                                    super(1);
                                }

                                @Override // kotlin.jvm.functions.Function1
                                public /* bridge */ /* synthetic */ Unit invoke(Float f) {
                                    invoke(f.floatValue());
                                    return Unit.INSTANCE;
                                }

                                public final void invoke(float it) {
                                    Function1<Float, Unit> function8 = function7;
                                    if (function8 != null) {
                                        function8.invoke(Float.valueOf(it));
                                    }
                                }
                            };
                            $composer3.updateRememberedValue(value$iv$iv);
                        } else {
                            value$iv$iv = it$iv$iv;
                        }
                        $composer3.endReplaceableGroup();
                        SliderKt.Slider(null, (Function1) value$iv$iv, $composer3, 0, 1);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    }
                }), $composer2, 48);
                ControllerWrapper(RowScope.weight$default($this$Controllers_u24lambda_u244, Modifier.INSTANCE, LiveLiterals$RemoteControlScreenKt.INSTANCE.m6840Float$arg0$callweight$arg0$callControllerWrapper1$fun$anonymous$$arg3$callRow$funControllers(), false, 2, null), ComposableLambdaKt.composableLambda($composer2, -264932277, true, new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.features.remote_control.presentation.view.RemoteControlScreenKt$Controllers$1$2
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    /* JADX WARN: Multi-variable type inference failed */
                    {
                        super(2);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                        invoke(composer, num.intValue());
                        return Unit.INSTANCE;
                    }

                    public final void invoke(Composer $composer3, int $changed2) {
                        Object value$iv$iv;
                        ComposerKt.sourceInformation($composer3, "C108@3575L58,108@3532L101:RemoteControlScreen.kt#7brr7p");
                        if (($changed2 & 11) == 2 && $composer3.getSkipping()) {
                            $composer3.skipToGroupEnd();
                            return;
                        }
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-264932277, $changed2, -1, "vea.raceremote.features.remote_control.presentation.view.Controllers.<anonymous>.<anonymous> (RemoteControlScreen.kt:107)");
                        }
                        Orientation.Vertical vertical = Orientation.Vertical.INSTANCE;
                        Object key1$iv = function6;
                        final Function1<Float, Unit> function7 = function6;
                        int i5 = ($dirty >> 3) & 14;
                        $composer3.startReplaceableGroup(1157296644);
                        ComposerKt.sourceInformation($composer3, "C(remember)P(1):Composables.kt#9igjgp");
                        boolean invalid$iv$iv = $composer3.changed(key1$iv);
                        Object it$iv$iv = $composer3.rememberedValue();
                        if (invalid$iv$iv || it$iv$iv == Composer.INSTANCE.getEmpty()) {
                            value$iv$iv = new Function1<Float, Unit>() { // from class: vea.raceremote.features.remote_control.presentation.view.RemoteControlScreenKt$Controllers$1$2$1$1
                                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                /* JADX WARN: Multi-variable type inference failed */
                                {
                                    super(1);
                                }

                                @Override // kotlin.jvm.functions.Function1
                                public /* bridge */ /* synthetic */ Unit invoke(Float f) {
                                    invoke(f.floatValue());
                                    return Unit.INSTANCE;
                                }

                                public final void invoke(float it) {
                                    Function1<Float, Unit> function8 = function7;
                                    if (function8 != null) {
                                        function8.invoke(Float.valueOf(it));
                                    }
                                }
                            };
                            $composer3.updateRememberedValue(value$iv$iv);
                        } else {
                            value$iv$iv = it$iv$iv;
                        }
                        $composer3.endReplaceableGroup();
                        SliderKt.Slider(vertical, (Function1) value$iv$iv, $composer3, 6, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    }
                }), $composer2, 48);
                ComposerKt.sourceInformationMarkerEnd($composer2);
            }
            $composer2.endReplaceableGroup();
            $composer2.endReplaceableGroup();
            $composer2.endNode();
            $composer2.endReplaceableGroup();
            $composer2.endReplaceableGroup();
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
            function4 = function6;
            function3 = function5;
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.features.remote_control.presentation.view.RemoteControlScreenKt.Controllers.2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i5) {
                RemoteControlScreenKt.Controllers(function3, function4, composer, $changed | 1, i);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void ControllerWrapper(final Modifier modifier, final Function2<? super Composer, ? super Integer, Unit> function2, Composer $composer, final int $changed) {
        Object value$iv$iv;
        Object value$iv$iv2;
        Composer $composer2 = $composer.startRestartGroup(337115648);
        ComposerKt.sourceInformation($composer2, "C(ControllerWrapper)P(1)120@3776L34,121@3828L66,123@3900L158:RemoteControlScreen.kt#7brr7p");
        int $dirty = $changed;
        if (($changed & 14) == 0) {
            $dirty |= $composer2.changed(modifier) ? 4 : 2;
        }
        if (($changed & 112) == 0) {
            $dirty |= $composer2.changed(function2) ? 32 : 16;
        }
        if (($dirty & 91) == 18 && $composer2.getSkipping()) {
            $composer2.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(337115648, $dirty, -1, "vea.raceremote.features.remote_control.presentation.view.ControllerWrapper (RemoteControlScreen.kt:116)");
            }
            $composer2.startReplaceableGroup(-492369756);
            ComposerKt.sourceInformation($composer2, "C(remember):Composables.kt#9igjgp");
            Object it$iv$iv = $composer2.rememberedValue();
            if (it$iv$iv == Composer.INSTANCE.getEmpty()) {
                value$iv$iv = CornerShapes.INSTANCE.getHugeItem();
                $composer2.updateRememberedValue(value$iv$iv);
            } else {
                value$iv$iv = it$iv$iv;
            }
            $composer2.endReplaceableGroup();
            RoundedCornerShape shape = (RoundedCornerShape) value$iv$iv;
            $composer2.startReplaceableGroup(-492369756);
            ComposerKt.sourceInformation($composer2, "C(remember):Composables.kt#9igjgp");
            Object it$iv$iv2 = $composer2.rememberedValue();
            if (it$iv$iv2 == Composer.INSTANCE.getEmpty()) {
                int $this$dp$iv = LiveLiterals$RemoteControlScreenKt.INSTANCE.m6841Int$$$this$call$getdp$$arg0$callBorderStroke$fun$anonymous$$arg0$callremember$valborder$funControllerWrapper();
                value$iv$iv2 = BorderStrokeKt.m194BorderStrokecXLIe8U(Dp.m4046constructorimpl($this$dp$iv), ThemeKt.getPalette$default(false, 1, null).getCustomColors().getOutline());
                $composer2.updateRememberedValue(value$iv$iv2);
            } else {
                value$iv$iv2 = it$iv$iv2;
            }
            $composer2.endReplaceableGroup();
            BorderStroke border = (BorderStroke) value$iv$iv2;
            Modifier modifier$iv = ClipKt.clip(BorderKt.border(PaddingKt.m427padding3ABfNKs(modifier, Padding.INSTANCE.m6886getContentD9Ej5fM()), border, shape), shape);
            $composer2.startReplaceableGroup(733328855);
            ComposerKt.sourceInformation($composer2, "C(Box)P(2,1,3)70@3267L67,71@3339L130:Box.kt#2w3rfo");
            Alignment contentAlignment$iv = Alignment.INSTANCE.getTopStart();
            MeasurePolicy measurePolicy$iv = BoxKt.rememberBoxMeasurePolicy(contentAlignment$iv, false, $composer2, ((0 >> 3) & 14) | ((0 >> 3) & 112));
            int $changed$iv$iv = (0 << 3) & 112;
            $composer2.startReplaceableGroup(-1323940314);
            ComposerKt.sourceInformation($composer2, "C(Layout)P(!1,2)74@2915L7,75@2970L7,76@3029L7,77@3041L460:Layout.kt#80mrfh");
            ProvidableCompositionLocal<Density> localDensity = CompositionLocalsKt.getLocalDensity();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume = $composer2.consume(localDensity);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            Density density$iv$iv = (Density) objConsume;
            ProvidableCompositionLocal<LayoutDirection> localLayoutDirection = CompositionLocalsKt.getLocalLayoutDirection();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume2 = $composer2.consume(localLayoutDirection);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            LayoutDirection layoutDirection$iv$iv = (LayoutDirection) objConsume2;
            ProvidableCompositionLocal<ViewConfiguration> localViewConfiguration = CompositionLocalsKt.getLocalViewConfiguration();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume3 = $composer2.consume(localViewConfiguration);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ViewConfiguration viewConfiguration$iv$iv = (ViewConfiguration) objConsume3;
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            Function3<SkippableUpdater<ComposeUiNode>, Composer, Integer, Unit> function3MaterializerOf = LayoutKt.materializerOf(modifier$iv);
            int $changed$iv$iv$iv = (($changed$iv$iv << 9) & 7168) | 6;
            if (!($composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer2.startReusableNode();
            if ($composer2.getInserting()) {
                $composer2.createNode(constructor);
            } else {
                $composer2.useNode();
            }
            $composer2.disableReusing();
            Composer $this$Layout_u24lambda_u2d0$iv$iv = Updater.m1304constructorimpl($composer2);
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, measurePolicy$iv, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, density$iv$iv, ComposeUiNode.INSTANCE.getSetDensity());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, layoutDirection$iv$iv, ComposeUiNode.INSTANCE.getSetLayoutDirection());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, viewConfiguration$iv$iv, ComposeUiNode.INSTANCE.getSetViewConfiguration());
            $composer2.enableReusing();
            function3MaterializerOf.invoke(SkippableUpdater.m1294boximpl(SkippableUpdater.m1295constructorimpl($composer2)), $composer2, Integer.valueOf(($changed$iv$iv$iv >> 3) & 112));
            $composer2.startReplaceableGroup(2058660585);
            int $changed$iv = ($changed$iv$iv$iv >> 9) & 14;
            $composer2.startReplaceableGroup(-2137368960);
            ComposerKt.sourceInformation($composer2, "C72@3384L9:Box.kt#2w3rfo");
            if (($changed$iv & 11) == 2 && $composer2.getSkipping()) {
                $composer2.skipToGroupEnd();
            } else {
                BoxScopeInstance boxScopeInstance = BoxScopeInstance.INSTANCE;
                int i = ((0 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart($composer2, 1406858135, "C129@4044L8:RemoteControlScreen.kt#7brr7p");
                function2.invoke($composer2, Integer.valueOf(($dirty >> 3) & 14));
                ComposerKt.sourceInformationMarkerEnd($composer2);
            }
            $composer2.endReplaceableGroup();
            $composer2.endReplaceableGroup();
            $composer2.endNode();
            $composer2.endReplaceableGroup();
            $composer2.endReplaceableGroup();
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.features.remote_control.presentation.view.RemoteControlScreenKt.ControllerWrapper.2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i2) {
                RemoteControlScreenKt.ControllerWrapper(modifier, function2, composer, $changed | 1);
            }
        });
    }
}
