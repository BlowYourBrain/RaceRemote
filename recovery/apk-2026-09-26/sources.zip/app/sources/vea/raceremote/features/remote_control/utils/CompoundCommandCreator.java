package vea.raceremote.features.remote_control.utils;

import kotlin.Metadata;

/* JADX INFO: compiled from: CompoundCommandCreator.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\n\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0015\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0004H\u0000¢\u0006\u0002\b\u0006J\u0015\u0010\u0007\u001a\u00020\u00042\u0006\u0010\b\u001a\u00020\u0004H\u0000¢\u0006\u0002\b\tJ\u0010\u0010\n\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0004H\u0016J\u0015\u0010\u000b\u001a\u00020\u00042\u0006\u0010\b\u001a\u00020\u0004H\u0000¢\u0006\u0002\b\fJ\u0010\u0010\r\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0004H\u0016¨\u0006\u000e"}, d2 = {"Lvea/raceremote/features/remote_control/utils/CompoundCommandCreator;", "Lvea/raceremote/features/remote_control/utils/ICompoundCommandCreator;", "()V", "createCommand", "", "value", "createCommand$app_debug", "createEndCommand", "commandValue", "createEndCommand$app_debug", "createEngineCommand", "createStartCommand", "createStartCommand$app_debug", "createSteeringWheelCommand", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class CompoundCommandCreator implements ICompoundCommandCreator {
    public static final int $stable = LiveLiterals$CompoundCommandCreatorKt.INSTANCE.m6845Int$classCompoundCommandCreator();

    public final int createStartCommand$app_debug(int commandValue) {
        return ((commandValue >> LiveLiterals$CompoundCommandCreatorKt.INSTANCE.m6844Int$arg0$callshr$$this$callshl$$this$callor$funcreateStartCommand$classCompoundCommandCreator()) << LiveLiterals$CompoundCommandCreatorKt.INSTANCE.m6843Int$arg0$callshl$$this$callor$funcreateStartCommand$classCompoundCommandCreator()) | 49152;
    }

    public final int createEndCommand$app_debug(int commandValue) {
        return commandValue & 63;
    }

    public final int createCommand$app_debug(int value) {
        return createStartCommand$app_debug(value) | createEndCommand$app_debug(value);
    }

    @Override // vea.raceremote.features.remote_control.utils.ICompoundCommandCreator
    public int createSteeringWheelCommand(int value) {
        return createCommand$app_debug(value) | 8192;
    }

    @Override // vea.raceremote.features.remote_control.utils.ICompoundCommandCreator
    public int createEngineCommand(int value) {
        return createCommand$app_debug(value) | 12288;
    }
}
