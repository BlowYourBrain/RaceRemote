package vea.raceremote.features.remote_control.utils;

import kotlin.Metadata;

/* JADX INFO: compiled from: CompoundCommandCreator.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0003\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0004\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0005"}, d2 = {"END_COMMAND", "", "ENGINE_COMMAND", "START_COMMAND", "STEERING_WHEEL_COMMAND", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class CompoundCommandCreatorKt {
    private static final int END_COMMAND = 63;
    private static final int ENGINE_COMMAND = 12288;
    private static final int START_COMMAND = 49152;
    private static final int STEERING_WHEEL_COMMAND = 8192;
}
