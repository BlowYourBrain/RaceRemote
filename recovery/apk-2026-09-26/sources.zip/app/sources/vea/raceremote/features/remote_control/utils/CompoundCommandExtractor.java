package vea.raceremote.features.remote_control.utils;

import kotlin.Metadata;

/* JADX INFO: compiled from: CompoundCommandExtractor.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0005\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\b\u0007\u0018\u0000 \b2\u00020\u0001:\u0001\bB\u0005¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0016J\u0010\u0010\u0007\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0016¨\u0006\t"}, d2 = {"Lvea/raceremote/features/remote_control/utils/CompoundCommandExtractor;", "Lvea/raceremote/features/remote_control/utils/ICompoundCommandExtractor;", "()V", "extractEndCommand", "", "command", "", "extractStartCommand", "Companion", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class CompoundCommandExtractor implements ICompoundCommandExtractor {
    private static final int clearFirst8Bytes = 255;
    public static final int $stable = LiveLiterals$CompoundCommandExtractorKt.INSTANCE.m6847Int$classCompoundCommandExtractor();

    @Override // vea.raceremote.features.remote_control.utils.ICompoundCommandExtractor
    public byte extractStartCommand(int command) {
        return (byte) (command >> LiveLiterals$CompoundCommandExtractorKt.INSTANCE.m6846Int$arg0$callshr$$this$calltoByte$funextractStartCommand$classCompoundCommandExtractor());
    }

    @Override // vea.raceremote.features.remote_control.utils.ICompoundCommandExtractor
    public byte extractEndCommand(int command) {
        return (byte) (command & 255);
    }
}
