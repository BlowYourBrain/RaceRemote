package vea.raceremote.features.remote_control.utils;

import kotlin.Metadata;

/* JADX INFO: compiled from: CompoundCommandCreator.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\bf\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0003H&J\u0010\u0010\u0005\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0003H&¨\u0006\u0006"}, d2 = {"Lvea/raceremote/features/remote_control/utils/ICompoundCommandCreator;", "", "createEngineCommand", "", "value", "createSteeringWheelCommand", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public interface ICompoundCommandCreator {
    int createEngineCommand(int value);

    int createSteeringWheelCommand(int value);
}
