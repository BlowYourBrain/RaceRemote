package vea.raceremote.features.remote_control.utils;

import kotlin.Metadata;

/* JADX INFO: compiled from: CompoundCommandExtractor.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0005\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\bf\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H&J\u0010\u0010\u0006\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H&¨\u0006\u0007"}, d2 = {"Lvea/raceremote/features/remote_control/utils/ICompoundCommandExtractor;", "", "extractEndCommand", "", "command", "", "extractStartCommand", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public interface ICompoundCommandExtractor {
    byte extractEndCommand(int command);

    byte extractStartCommand(int command);
}
