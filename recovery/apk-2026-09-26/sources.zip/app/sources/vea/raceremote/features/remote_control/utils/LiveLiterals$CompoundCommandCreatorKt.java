package vea.raceremote.features.remote_control.utils;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: CompoundCommandCreator.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/features/remote_control/utils/CompoundCommandCreator.kt")
public final class LiveLiterals$CompoundCommandCreatorKt {

    /* JADX INFO: renamed from: Int$class-CompoundCommandCreator, reason: not valid java name */
    private static int f1761Int$classCompoundCommandCreator;

    /* JADX INFO: renamed from: State$Int$arg-0$call-shl$$this$call-or$fun-createStartCommand$class-CompoundCommandCreator, reason: not valid java name */
    private static State<Integer> f1762State$Int$arg0$callshl$$this$callor$funcreateStartCommand$classCompoundCommandCreator;

    /* JADX INFO: renamed from: State$Int$arg-0$call-shr$$this$call-shl$$this$call-or$fun-createStartCommand$class-CompoundCommandCreator, reason: not valid java name */
    private static State<Integer> f1763State$Int$arg0$callshr$$this$callshl$$this$callor$funcreateStartCommand$classCompoundCommandCreator;

    /* JADX INFO: renamed from: State$Int$class-CompoundCommandCreator, reason: not valid java name */
    private static State<Integer> f1764State$Int$classCompoundCommandCreator;
    public static final LiveLiterals$CompoundCommandCreatorKt INSTANCE = new LiveLiterals$CompoundCommandCreatorKt();

    /* JADX INFO: renamed from: Int$arg-0$call-shr$$this$call-shl$$this$call-or$fun-createStartCommand$class-CompoundCommandCreator, reason: not valid java name */
    private static int f1760Int$arg0$callshr$$this$callshl$$this$callor$funcreateStartCommand$classCompoundCommandCreator = 6;

    /* JADX INFO: renamed from: Int$arg-0$call-shl$$this$call-or$fun-createStartCommand$class-CompoundCommandCreator, reason: not valid java name */
    private static int f1759Int$arg0$callshl$$this$callor$funcreateStartCommand$classCompoundCommandCreator = 8;

    @LiveLiteralInfo(key = "Int$arg-0$call-shl$$this$call-or$fun-createStartCommand$class-CompoundCommandCreator", offset = 620)
    /* JADX INFO: renamed from: Int$arg-0$call-shl$$this$call-or$fun-createStartCommand$class-CompoundCommandCreator, reason: not valid java name */
    public final int m6843Int$arg0$callshl$$this$callor$funcreateStartCommand$classCompoundCommandCreator() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1759Int$arg0$callshl$$this$callor$funcreateStartCommand$classCompoundCommandCreator;
        }
        State<Integer> stateLiveLiteral = f1762State$Int$arg0$callshl$$this$callor$funcreateStartCommand$classCompoundCommandCreator;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-shl$$this$call-or$fun-createStartCommand$class-CompoundCommandCreator", Integer.valueOf(f1759Int$arg0$callshl$$this$callor$funcreateStartCommand$classCompoundCommandCreator));
            f1762State$Int$arg0$callshl$$this$callor$funcreateStartCommand$classCompoundCommandCreator = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-shr$$this$call-shl$$this$call-or$fun-createStartCommand$class-CompoundCommandCreator", offset = 613)
    /* JADX INFO: renamed from: Int$arg-0$call-shr$$this$call-shl$$this$call-or$fun-createStartCommand$class-CompoundCommandCreator, reason: not valid java name */
    public final int m6844Int$arg0$callshr$$this$callshl$$this$callor$funcreateStartCommand$classCompoundCommandCreator() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1760Int$arg0$callshr$$this$callshl$$this$callor$funcreateStartCommand$classCompoundCommandCreator;
        }
        State<Integer> stateLiveLiteral = f1763State$Int$arg0$callshr$$this$callshl$$this$callor$funcreateStartCommand$classCompoundCommandCreator;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-shr$$this$call-shl$$this$call-or$fun-createStartCommand$class-CompoundCommandCreator", Integer.valueOf(f1760Int$arg0$callshr$$this$callshl$$this$callor$funcreateStartCommand$classCompoundCommandCreator));
            f1763State$Int$arg0$callshr$$this$callshl$$this$callor$funcreateStartCommand$classCompoundCommandCreator = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-CompoundCommandCreator", offset = -1)
    /* JADX INFO: renamed from: Int$class-CompoundCommandCreator, reason: not valid java name */
    public final int m6845Int$classCompoundCommandCreator() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1761Int$classCompoundCommandCreator;
        }
        State<Integer> stateLiveLiteral = f1764State$Int$classCompoundCommandCreator;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-CompoundCommandCreator", Integer.valueOf(f1761Int$classCompoundCommandCreator));
            f1764State$Int$classCompoundCommandCreator = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }
}
