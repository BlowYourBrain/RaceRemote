package vea.raceremote.features.remote_control.utils;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: CompoundCommandExtractor.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/features/remote_control/utils/CompoundCommandExtractor.kt")
public final class LiveLiterals$CompoundCommandExtractorKt {
    public static final LiveLiterals$CompoundCommandExtractorKt INSTANCE = new LiveLiterals$CompoundCommandExtractorKt();

    /* JADX INFO: renamed from: Int$arg-0$call-shr$$this$call-toByte$fun-extractStartCommand$class-CompoundCommandExtractor, reason: not valid java name */
    private static int f1765Int$arg0$callshr$$this$calltoByte$funextractStartCommand$classCompoundCommandExtractor = 8;

    /* JADX INFO: renamed from: Int$class-CompoundCommandExtractor, reason: not valid java name */
    private static int f1766Int$classCompoundCommandExtractor;

    /* JADX INFO: renamed from: State$Int$arg-0$call-shr$$this$call-toByte$fun-extractStartCommand$class-CompoundCommandExtractor, reason: not valid java name */
    private static State<Integer> f1767State$Int$arg0$callshr$$this$calltoByte$funextractStartCommand$classCompoundCommandExtractor;

    /* JADX INFO: renamed from: State$Int$class-CompoundCommandExtractor, reason: not valid java name */
    private static State<Integer> f1768State$Int$classCompoundCommandExtractor;

    @LiveLiteralInfo(key = "Int$arg-0$call-shr$$this$call-toByte$fun-extractStartCommand$class-CompoundCommandExtractor", offset = 422)
    /* JADX INFO: renamed from: Int$arg-0$call-shr$$this$call-toByte$fun-extractStartCommand$class-CompoundCommandExtractor, reason: not valid java name */
    public final int m6846Int$arg0$callshr$$this$calltoByte$funextractStartCommand$classCompoundCommandExtractor() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1765Int$arg0$callshr$$this$calltoByte$funextractStartCommand$classCompoundCommandExtractor;
        }
        State<Integer> stateLiveLiteral = f1767State$Int$arg0$callshr$$this$calltoByte$funextractStartCommand$classCompoundCommandExtractor;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-shr$$this$call-toByte$fun-extractStartCommand$class-CompoundCommandExtractor", Integer.valueOf(f1765Int$arg0$callshr$$this$calltoByte$funextractStartCommand$classCompoundCommandExtractor));
            f1767State$Int$arg0$callshr$$this$calltoByte$funextractStartCommand$classCompoundCommandExtractor = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-CompoundCommandExtractor", offset = -1)
    /* JADX INFO: renamed from: Int$class-CompoundCommandExtractor, reason: not valid java name */
    public final int m6847Int$classCompoundCommandExtractor() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1766Int$classCompoundCommandExtractor;
        }
        State<Integer> stateLiveLiteral = f1768State$Int$classCompoundCommandExtractor;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-CompoundCommandExtractor", Integer.valueOf(f1766Int$classCompoundCommandExtractor));
            f1768State$Int$classCompoundCommandExtractor = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }
}
