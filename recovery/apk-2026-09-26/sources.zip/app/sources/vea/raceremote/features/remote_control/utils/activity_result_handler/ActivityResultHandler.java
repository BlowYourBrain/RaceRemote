package vea.raceremote.features.remote_control.utils.activity_result_handler;

import android.content.Intent;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: ActivityResultHandler.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b'\u0018\u0000*\u0004\b\u0000\u0010\u00012\u00020\u0002B+\u0012\u0014\b\u0002\u0010\u0003\u001a\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00020\u00050\u0004\u0012\u000e\b\u0002\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u0007¢\u0006\u0002\u0010\bJ\"\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00102\b\u0010\u0012\u001a\u0004\u0018\u00010\u0013H&R\u0017\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u0007¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u001d\u0010\u0003\u001a\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00020\u00050\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\f¨\u0006\u0014"}, d2 = {"Lvea/raceremote/features/remote_control/utils/activity_result_handler/ActivityResultHandler;", "R", "", "onSuccess", "Lkotlin/Function1;", "", "onFailure", "Lkotlin/Function0;", "(Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;)V", "getOnFailure", "()Lkotlin/jvm/functions/Function0;", "getOnSuccess", "()Lkotlin/jvm/functions/Function1;", "handle", "", "requestCode", "", "resultCode", "data", "Landroid/content/Intent;", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public abstract class ActivityResultHandler<R> {
    public static final int $stable = LiveLiterals$ActivityResultHandlerKt.INSTANCE.m6848Int$classActivityResultHandler();
    private final Function0<Unit> onFailure;
    private final Function1<R, Unit> onSuccess;

    /* JADX WARN: Multi-variable type inference failed */
    public ActivityResultHandler() {
        this(null, 0 == true ? 1 : 0, 3);
    }

    public abstract boolean handle(int requestCode, int resultCode, Intent data);

    /* JADX WARN: Multi-variable type inference failed */
    public ActivityResultHandler(Function1<? super R, Unit> function1, Function0<Unit> function0) {
        Intrinsics.checkNotNullParameter(function1, "onSuccess");
        Intrinsics.checkNotNullParameter(function0, "onFailure");
        this.onSuccess = function1;
        this.onFailure = function0;
    }

    public final Function1<R, Unit> getOnSuccess() {
        return this.onSuccess;
    }

    public final Function0<Unit> getOnFailure() {
        return this.onFailure;
    }
}
