package vea.raceremote.features.remote_control.utils.activity_result_handler;

import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import vea.raceremote.features.remote_control.presentation.model.RemoteDevice;

/* JADX INFO: compiled from: BluetoothResultHandler.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B+\u0012\u0014\b\u0002\u0010\u0003\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00050\u0004\u0012\u000e\b\u0002\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u0007¢\u0006\u0002\u0010\bJ\"\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\f2\b\u0010\u000e\u001a\u0004\u0018\u00010\u000fH\u0016J\u0014\u0010\u0010\u001a\u0004\u0018\u00010\u00022\b\u0010\u000e\u001a\u0004\u0018\u00010\u000fH\u0002¨\u0006\u0011"}, d2 = {"Lvea/raceremote/features/remote_control/utils/activity_result_handler/BluetoothResultHandler;", "Lvea/raceremote/features/remote_control/utils/activity_result_handler/ActivityResultHandler;", "Landroid/bluetooth/BluetoothDevice;", "onSuccess", "Lkotlin/Function1;", "", "onFailure", "Lkotlin/Function0;", "(Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;)V", "handle", "", "requestCode", "", "resultCode", "data", "Landroid/content/Intent;", "retrieveBluetoothDevice", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class BluetoothResultHandler extends ActivityResultHandler<BluetoothDevice> {
    public static final int $stable = LiveLiterals$BluetoothResultHandlerKt.INSTANCE.m6852Int$classBluetoothResultHandler();

    /* JADX WARN: Multi-variable type inference failed */
    public BluetoothResultHandler() {
        this(null, 0 == true ? 1 : 0, 3);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public BluetoothResultHandler(Function1<? super BluetoothDevice, Unit> function1, Function0<Unit> function0) {
        super(function1, function0);
        Intrinsics.checkNotNullParameter(function1, "onSuccess");
        Intrinsics.checkNotNullParameter(function0, "onFailure");
    }

    @Override // vea.raceremote.features.remote_control.utils.activity_result_handler.ActivityResultHandler
    public boolean handle(int requestCode, int resultCode, Intent data) {
        if (requestCode != RemoteDevice.Bluetooth.getRequestCode()) {
            return LiveLiterals$BluetoothResultHandlerKt.INSTANCE.m6849Boolean$branch$if$funhandle$classBluetoothResultHandler();
        }
        if (requestCode == -1) {
            BluetoothDevice bluetoothDevice = retrieveBluetoothDevice(data);
            if (bluetoothDevice == null) {
                return LiveLiterals$BluetoothResultHandlerKt.INSTANCE.m6850Boolean$branch$when$valbluetoothDevice$branch$if1$funhandle$classBluetoothResultHandler();
            }
            getOnSuccess().invoke(bluetoothDevice);
        } else {
            getOnFailure().invoke();
        }
        return LiveLiterals$BluetoothResultHandlerKt.INSTANCE.m6851Boolean$funhandle$classBluetoothResultHandler();
    }

    private final BluetoothDevice retrieveBluetoothDevice(Intent data) {
        if (data != null) {
            return (BluetoothDevice) data.getParcelableExtra("android.companion.extra.DEVICE");
        }
        return null;
    }
}
