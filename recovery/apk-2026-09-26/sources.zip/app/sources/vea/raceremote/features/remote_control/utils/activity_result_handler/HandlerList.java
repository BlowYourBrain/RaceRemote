package vea.raceremote.features.remote_control.utils.activity_result_handler;

import android.content.Intent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: HandlerList.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0012\u0010\u0006\u001a\u00020\u00072\n\u0010\b\u001a\u0006\u0012\u0002\b\u00030\u0005J \u0010\t\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u000b2\b\u0010\r\u001a\u0004\u0018\u00010\u000eR\u0018\u0010\u0003\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00050\u0004X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000f"}, d2 = {"Lvea/raceremote/features/remote_control/utils/activity_result_handler/HandlerList;", "", "()V", "innerList", "", "Lvea/raceremote/features/remote_control/utils/activity_result_handler/ActivityResultHandler;", "addHandler", "", "handler", "handle", "requestCode", "", "resultCode", "data", "Landroid/content/Intent;", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class HandlerList {
    public static final int $stable = LiveLiterals$HandlerListKt.INSTANCE.m6853Int$classHandlerList();
    private final List<ActivityResultHandler<?>> innerList = new ArrayList();

    public final void addHandler(ActivityResultHandler<?> handler) {
        Intrinsics.checkNotNullParameter(handler, "handler");
        this.innerList.add(handler);
    }

    public final void handle(int requestCode, int resultCode, Intent data) {
        Iterator<ActivityResultHandler<?>> it = this.innerList.iterator();
        while (it.hasNext() && !it.next().handle(requestCode, resultCode, data)) {
        }
    }
}
