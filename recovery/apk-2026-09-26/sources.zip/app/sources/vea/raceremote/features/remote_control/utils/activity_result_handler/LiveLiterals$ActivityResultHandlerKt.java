package vea.raceremote.features.remote_control.utils.activity_result_handler;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: ActivityResultHandler.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/features/remote_control/utils/activity_result_handler/ActivityResultHandler.kt")
public final class LiveLiterals$ActivityResultHandlerKt {
    public static final LiveLiterals$ActivityResultHandlerKt INSTANCE = new LiveLiterals$ActivityResultHandlerKt();

    /* JADX INFO: renamed from: Int$class-ActivityResultHandler, reason: not valid java name */
    private static int f1769Int$classActivityResultHandler;

    /* JADX INFO: renamed from: State$Int$class-ActivityResultHandler, reason: not valid java name */
    private static State<Integer> f1770State$Int$classActivityResultHandler;

    @LiveLiteralInfo(key = "Int$class-ActivityResultHandler", offset = -1)
    /* JADX INFO: renamed from: Int$class-ActivityResultHandler, reason: not valid java name */
    public final int m6848Int$classActivityResultHandler() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1769Int$classActivityResultHandler;
        }
        State<Integer> stateLiveLiteral = f1770State$Int$classActivityResultHandler;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-ActivityResultHandler", Integer.valueOf(f1769Int$classActivityResultHandler));
            f1770State$Int$classActivityResultHandler = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }
}
