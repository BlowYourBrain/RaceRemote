package vea.raceremote.features.remote_control.utils.activity_result_handler;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: BluetoothResultHandler.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/features/remote_control/utils/activity_result_handler/BluetoothResultHandler.kt")
public final class LiveLiterals$BluetoothResultHandlerKt {

    /* JADX INFO: renamed from: Boolean$branch$if$fun-handle$class-BluetoothResultHandler, reason: not valid java name */
    private static boolean f1771Boolean$branch$if$funhandle$classBluetoothResultHandler;

    /* JADX INFO: renamed from: Boolean$branch$when$val-bluetoothDevice$branch$if-1$fun-handle$class-BluetoothResultHandler, reason: not valid java name */
    private static boolean f1772Boolean$branch$when$valbluetoothDevice$branch$if1$funhandle$classBluetoothResultHandler;

    /* JADX INFO: renamed from: Int$class-BluetoothResultHandler, reason: not valid java name */
    private static int f1774Int$classBluetoothResultHandler;

    /* JADX INFO: renamed from: State$Boolean$branch$if$fun-handle$class-BluetoothResultHandler, reason: not valid java name */
    private static State<Boolean> f1775State$Boolean$branch$if$funhandle$classBluetoothResultHandler;

    /* JADX INFO: renamed from: State$Boolean$branch$when$val-bluetoothDevice$branch$if-1$fun-handle$class-BluetoothResultHandler, reason: not valid java name */
    private static State<Boolean> f1776State$Boolean$branch$when$valbluetoothDevice$branch$if1$funhandle$classBluetoothResultHandler;

    /* JADX INFO: renamed from: State$Boolean$fun-handle$class-BluetoothResultHandler, reason: not valid java name */
    private static State<Boolean> f1777State$Boolean$funhandle$classBluetoothResultHandler;

    /* JADX INFO: renamed from: State$Int$class-BluetoothResultHandler, reason: not valid java name */
    private static State<Integer> f1778State$Int$classBluetoothResultHandler;
    public static final LiveLiterals$BluetoothResultHandlerKt INSTANCE = new LiveLiterals$BluetoothResultHandlerKt();

    /* JADX INFO: renamed from: Boolean$fun-handle$class-BluetoothResultHandler, reason: not valid java name */
    private static boolean f1773Boolean$funhandle$classBluetoothResultHandler = true;

    @LiveLiteralInfo(key = "Boolean$branch$if$fun-handle$class-BluetoothResultHandler", offset = 700)
    /* JADX INFO: renamed from: Boolean$branch$if$fun-handle$class-BluetoothResultHandler, reason: not valid java name */
    public final boolean m6849Boolean$branch$if$funhandle$classBluetoothResultHandler() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1771Boolean$branch$if$funhandle$classBluetoothResultHandler;
        }
        State<Boolean> stateLiveLiteral = f1775State$Boolean$branch$if$funhandle$classBluetoothResultHandler;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$if$fun-handle$class-BluetoothResultHandler", Boolean.valueOf(f1771Boolean$branch$if$funhandle$classBluetoothResultHandler));
            f1775State$Boolean$branch$if$funhandle$classBluetoothResultHandler = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when$val-bluetoothDevice$branch$if-1$fun-handle$class-BluetoothResultHandler", offset = 830)
    /* JADX INFO: renamed from: Boolean$branch$when$val-bluetoothDevice$branch$if-1$fun-handle$class-BluetoothResultHandler, reason: not valid java name */
    public final boolean m6850Boolean$branch$when$valbluetoothDevice$branch$if1$funhandle$classBluetoothResultHandler() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1772Boolean$branch$when$valbluetoothDevice$branch$if1$funhandle$classBluetoothResultHandler;
        }
        State<Boolean> stateLiveLiteral = f1776State$Boolean$branch$when$valbluetoothDevice$branch$if1$funhandle$classBluetoothResultHandler;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when$val-bluetoothDevice$branch$if-1$fun-handle$class-BluetoothResultHandler", Boolean.valueOf(f1772Boolean$branch$when$valbluetoothDevice$branch$if1$funhandle$classBluetoothResultHandler));
            f1776State$Boolean$branch$when$valbluetoothDevice$branch$if1$funhandle$classBluetoothResultHandler = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$fun-handle$class-BluetoothResultHandler", offset = 957)
    /* JADX INFO: renamed from: Boolean$fun-handle$class-BluetoothResultHandler, reason: not valid java name */
    public final boolean m6851Boolean$funhandle$classBluetoothResultHandler() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1773Boolean$funhandle$classBluetoothResultHandler;
        }
        State<Boolean> stateLiveLiteral = f1777State$Boolean$funhandle$classBluetoothResultHandler;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$fun-handle$class-BluetoothResultHandler", Boolean.valueOf(f1773Boolean$funhandle$classBluetoothResultHandler));
            f1777State$Boolean$funhandle$classBluetoothResultHandler = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Int$class-BluetoothResultHandler", offset = -1)
    /* JADX INFO: renamed from: Int$class-BluetoothResultHandler, reason: not valid java name */
    public final int m6852Int$classBluetoothResultHandler() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1774Int$classBluetoothResultHandler;
        }
        State<Integer> stateLiveLiteral = f1778State$Int$classBluetoothResultHandler;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-BluetoothResultHandler", Integer.valueOf(f1774Int$classBluetoothResultHandler));
            f1778State$Int$classBluetoothResultHandler = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }
}
