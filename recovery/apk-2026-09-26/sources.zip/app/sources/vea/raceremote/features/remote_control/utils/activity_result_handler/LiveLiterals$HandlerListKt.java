package vea.raceremote.features.remote_control.utils.activity_result_handler;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: HandlerList.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/features/remote_control/utils/activity_result_handler/HandlerList.kt")
public final class LiveLiterals$HandlerListKt {
    public static final LiveLiterals$HandlerListKt INSTANCE = new LiveLiterals$HandlerListKt();

    /* JADX INFO: renamed from: Int$class-HandlerList, reason: not valid java name */
    private static int f1779Int$classHandlerList = 8;

    /* JADX INFO: renamed from: State$Int$class-HandlerList, reason: not valid java name */
    private static State<Integer> f1780State$Int$classHandlerList;

    @LiveLiteralInfo(key = "Int$class-HandlerList", offset = -1)
    /* JADX INFO: renamed from: Int$class-HandlerList, reason: not valid java name */
    public final int m6853Int$classHandlerList() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1779Int$classHandlerList;
        }
        State<Integer> stateLiveLiteral = f1780State$Int$classHandlerList;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-HandlerList", Integer.valueOf(f1779Int$classHandlerList));
            f1780State$Int$classHandlerList = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }
}
