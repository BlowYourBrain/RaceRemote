package vea.raceremote.navigation;

import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.navigation.NavBackStackEntry;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import vea.raceremote.features.remote_control.presentation.view.RemoteControlScreenKt;

/* JADX INFO: compiled from: Navigation.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
public final class ComposableSingletons$NavigationKt {
    public static final ComposableSingletons$NavigationKt INSTANCE = new ComposableSingletons$NavigationKt();

    /* JADX INFO: renamed from: lambda-1, reason: not valid java name */
    public static Function3<NavBackStackEntry, Composer, Integer, Unit> f1781lambda1 = ComposableLambdaKt.composableLambdaInstance(1444655070, false, new Function3<NavBackStackEntry, Composer, Integer, Unit>() { // from class: vea.raceremote.navigation.ComposableSingletons$NavigationKt$lambda-1$1
        @Override // kotlin.jvm.functions.Function3
        public /* bridge */ /* synthetic */ Unit invoke(NavBackStackEntry navBackStackEntry, Composer composer, Integer num) {
            invoke(navBackStackEntry, composer, num.intValue());
            return Unit.INSTANCE;
        }

        public final void invoke(NavBackStackEntry it, Composer $composer, int $changed) {
            Intrinsics.checkNotNullParameter(it, "it");
            ComposerKt.sourceInformation($composer, "C38@1300L21:Navigation.kt#yp73o1");
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1444655070, $changed, -1, "vea.raceremote.navigation.ComposableSingletons$NavigationKt.lambda-1.<anonymous> (Navigation.kt:37)");
            }
            RemoteControlScreenKt.RemoteControlScreen(null, $composer, 0, 1);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
    });

    /* JADX INFO: renamed from: getLambda-1$app_debug, reason: not valid java name */
    public final Function3<NavBackStackEntry, Composer, Integer, Unit> m6854getLambda1$app_debug() {
        return f1781lambda1;
    }
}
