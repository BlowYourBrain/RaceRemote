package vea.raceremote.navigation;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: Navigation.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/navigation/Navigation.kt")
public final class LiveLiterals$NavigationKt {

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-setLaunchSingleTop$$this$call-build$arg-1$call-navigate$fun-$anonymous$$arg-0$call-BluetoothPermissionRationale$fun-$anonymous$$arg-3$call-composable-1$fun-$anonymous$$arg-4$call-NavHost$fun-$anonymous$$arg-6$call-Surface$fun-AppScaffold-1, reason: not valid java name */
    private static State<Boolean> f1783State$Boolean$arg0$callsetLaunchSingleTop$$this$callbuild$arg1$callnavigate$fun$anonymous$$arg0$callBluetoothPermissionRationale$fun$anonymous$$arg3$callcomposable1$fun$anonymous$$arg4$callNavHost$fun$anonymous$$arg6$callSurface$funAppScaffold1;
    public static final LiveLiterals$NavigationKt INSTANCE = new LiveLiterals$NavigationKt();

    /* JADX INFO: renamed from: Boolean$arg-0$call-setLaunchSingleTop$$this$call-build$arg-1$call-navigate$fun-$anonymous$$arg-0$call-BluetoothPermissionRationale$fun-$anonymous$$arg-3$call-composable-1$fun-$anonymous$$arg-4$call-NavHost$fun-$anonymous$$arg-6$call-Surface$fun-AppScaffold-1, reason: not valid java name */
    private static boolean f1782Boolean$arg0$callsetLaunchSingleTop$$this$callbuild$arg1$callnavigate$fun$anonymous$$arg0$callBluetoothPermissionRationale$fun$anonymous$$arg3$callcomposable1$fun$anonymous$$arg4$callNavHost$fun$anonymous$$arg6$callSurface$funAppScaffold1 = true;

    @LiveLiteralInfo(key = "Boolean$arg-0$call-setLaunchSingleTop$$this$call-build$arg-1$call-navigate$fun-$anonymous$$arg-0$call-BluetoothPermissionRationale$fun-$anonymous$$arg-3$call-composable-1$fun-$anonymous$$arg-4$call-NavHost$fun-$anonymous$$arg-6$call-Surface$fun-AppScaffold-1", offset = 1709)
    /* JADX INFO: renamed from: Boolean$arg-0$call-setLaunchSingleTop$$this$call-build$arg-1$call-navigate$fun-$anonymous$$arg-0$call-BluetoothPermissionRationale$fun-$anonymous$$arg-3$call-composable-1$fun-$anonymous$$arg-4$call-NavHost$fun-$anonymous$$arg-6$call-Surface$fun-AppScaffold-1, reason: not valid java name */
    public final boolean m6855Boolean$arg0$callsetLaunchSingleTop$$this$callbuild$arg1$callnavigate$fun$anonymous$$arg0$callBluetoothPermissionRationale$fun$anonymous$$arg3$callcomposable1$fun$anonymous$$arg4$callNavHost$fun$anonymous$$arg6$callSurface$funAppScaffold1() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1782Boolean$arg0$callsetLaunchSingleTop$$this$callbuild$arg1$callnavigate$fun$anonymous$$arg0$callBluetoothPermissionRationale$fun$anonymous$$arg3$callcomposable1$fun$anonymous$$arg4$callNavHost$fun$anonymous$$arg6$callSurface$funAppScaffold1;
        }
        State<Boolean> stateLiveLiteral = f1783State$Boolean$arg0$callsetLaunchSingleTop$$this$callbuild$arg1$callnavigate$fun$anonymous$$arg0$callBluetoothPermissionRationale$fun$anonymous$$arg3$callcomposable1$fun$anonymous$$arg4$callNavHost$fun$anonymous$$arg6$callSurface$funAppScaffold1;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-setLaunchSingleTop$$this$call-build$arg-1$call-navigate$fun-$anonymous$$arg-0$call-BluetoothPermissionRationale$fun-$anonymous$$arg-3$call-composable-1$fun-$anonymous$$arg-4$call-NavHost$fun-$anonymous$$arg-6$call-Surface$fun-AppScaffold-1", Boolean.valueOf(f1782Boolean$arg0$callsetLaunchSingleTop$$this$callbuild$arg1$callnavigate$fun$anonymous$$arg0$callBluetoothPermissionRationale$fun$anonymous$$arg3$callcomposable1$fun$anonymous$$arg4$callNavHost$fun$anonymous$$arg6$callSurface$funAppScaffold1));
            f1783State$Boolean$arg0$callsetLaunchSingleTop$$this$callbuild$arg1$callnavigate$fun$anonymous$$arg0$callBluetoothPermissionRationale$fun$anonymous$$arg3$callcomposable1$fun$anonymous$$arg4$callNavHost$fun$anonymous$$arg6$callSurface$funAppScaffold1 = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }
}
