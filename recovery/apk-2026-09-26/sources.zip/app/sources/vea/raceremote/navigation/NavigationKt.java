package vea.raceremote.navigation;

import android.content.Context;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.WindowInsets;
import androidx.compose.foundation.layout.WindowInsetsKt;
import androidx.compose.foundation.layout.WindowInsets_androidKt;
import androidx.compose.material.SurfaceKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.ProvidableCompositionLocal;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;
import androidx.navigation.NavBackStackEntry;
import androidx.navigation.NavController;
import androidx.navigation.NavGraphBuilder;
import androidx.navigation.NavHostController;
import androidx.navigation.NavOptions;
import androidx.navigation.Navigator;
import androidx.navigation.compose.NavGraphBuilderKt;
import androidx.navigation.compose.NavHostControllerKt;
import androidx.navigation.compose.NavHostKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import vea.raceremote.features.BluetoothPermissionRationaleKt;
import vea.raceremote.utils.bluetooth.BluetoothUtilsKt;

/* JADX INFO: compiled from: Navigation.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000\u0012\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\u001a\r\u0010\u0000\u001a\u00020\u0001H\u0007¢\u0006\u0002\u0010\u0002\u001a\u0015\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u0004H\u0007¢\u0006\u0002\u0010\u0005\u001a\r\u0010\u0006\u001a\u00020\u0004H\u0007¢\u0006\u0002\u0010\u0007¨\u0006\b"}, d2 = {"AppScaffold", "", "(Landroidx/compose/runtime/Composer;I)V", "startScreen", "Lvea/raceremote/navigation/Screens;", "(Lvea/raceremote/navigation/Screens;Landroidx/compose/runtime/Composer;I)V", "getStartScreen", "(Landroidx/compose/runtime/Composer;I)Lvea/raceremote/navigation/Screens;", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class NavigationKt {
    public static final void AppScaffold(Composer $composer, final int $changed) {
        Composer $composer2 = $composer.startRestartGroup(6303572);
        ComposerKt.sourceInformation($composer2, "C(AppScaffold)20@874L16,20@848L43:Navigation.kt#yp73o1");
        if ($changed != 0 || !$composer2.getSkipping()) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(6303572, $changed, -1, "vea.raceremote.navigation.AppScaffold (Navigation.kt:19)");
            }
            AppScaffold(getStartScreen($composer2, 0), $composer2, 0);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            $composer2.skipToGroupEnd();
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.navigation.NavigationKt.AppScaffold.1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i) {
                NavigationKt.AppScaffold(composer, $changed | 1);
            }
        });
    }

    public static final void AppScaffold(final Screens startScreen, Composer $composer, final int $changed) {
        Intrinsics.checkNotNullParameter(startScreen, "startScreen");
        Composer $composer2 = $composer.startRestartGroup(1395580957);
        ComposerKt.sourceInformation($composer2, "C(AppScaffold)27@978L23,29@1007L910:Navigation.kt#yp73o1");
        int $dirty = $changed;
        if (($changed & 14) == 0) {
            $dirty |= $composer2.changed(startScreen) ? 4 : 2;
        }
        if (($dirty & 11) != 2 || !$composer2.getSkipping()) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1395580957, $changed, -1, "vea.raceremote.navigation.AppScaffold (Navigation.kt:24)");
            }
            final NavHostController navController = NavHostControllerKt.rememberNavController(new Navigator[0], $composer2, 8);
            SurfaceKt.m1177SurfaceFjzlyU(null, null, 0L, 0L, null, 0.0f, ComposableLambdaKt.composableLambda($composer2, -662132135, true, new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.navigation.NavigationKt.AppScaffold.2
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(2);
                }

                @Override // kotlin.jvm.functions.Function2
                public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                    invoke(composer, num.intValue());
                    return Unit.INSTANCE;
                }

                public final void invoke(Composer $composer3, int $changed2) {
                    ComposerKt.sourceInformation($composer3, "C35@1187L11,35@1199L17,32@1033L878:Navigation.kt#yp73o1");
                    if (($changed2 & 11) != 2 || !$composer3.getSkipping()) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-662132135, $changed2, -1, "vea.raceremote.navigation.AppScaffold.<anonymous> (Navigation.kt:31)");
                        }
                        NavHostController navHostController = navController;
                        String strName = startScreen.name();
                        Modifier modifierPadding = PaddingKt.padding(Modifier.INSTANCE, WindowInsetsKt.asPaddingValues(WindowInsets_androidKt.getSafeContent(WindowInsets.INSTANCE, $composer3, 8), $composer3, 0));
                        final NavHostController navHostController2 = navController;
                        NavHostKt.NavHost(navHostController, strName, modifierPadding, null, new Function1<NavGraphBuilder, Unit>() { // from class: vea.raceremote.navigation.NavigationKt.AppScaffold.2.1
                            {
                                super(1);
                            }

                            @Override // kotlin.jvm.functions.Function1
                            public /* bridge */ /* synthetic */ Unit invoke(NavGraphBuilder navGraphBuilder) {
                                invoke2(navGraphBuilder);
                                return Unit.INSTANCE;
                            }

                            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                            public final void invoke2(NavGraphBuilder $this$NavHost) {
                                Intrinsics.checkNotNullParameter($this$NavHost, "$this$NavHost");
                                NavGraphBuilderKt.composable$default($this$NavHost, "RemoteControl", null, null, ComposableSingletons$NavigationKt.INSTANCE.m6854getLambda1$app_debug(), 6, null);
                                final NavHostController navHostController3 = navHostController2;
                                NavGraphBuilderKt.composable$default($this$NavHost, "BluetoothPermissionsRationale", null, null, ComposableLambdaKt.composableLambdaInstance(-296015467, true, new Function3<NavBackStackEntry, Composer, Integer, Unit>() { // from class: vea.raceremote.navigation.NavigationKt.AppScaffold.2.1.1
                                    {
                                        super(3);
                                    }

                                    @Override // kotlin.jvm.functions.Function3
                                    public /* bridge */ /* synthetic */ Unit invoke(NavBackStackEntry navBackStackEntry, Composer composer, Integer num) {
                                        invoke(navBackStackEntry, composer, num.intValue());
                                        return Unit.INSTANCE;
                                    }

                                    public final void invoke(NavBackStackEntry it, Composer $composer4, int $changed3) {
                                        Intrinsics.checkNotNullParameter(it, "it");
                                        ComposerKt.sourceInformation($composer4, "C41@1421L466:Navigation.kt#yp73o1");
                                        if (ComposerKt.isTraceInProgress()) {
                                            ComposerKt.traceEventStart(-296015467, $changed3, -1, "vea.raceremote.navigation.AppScaffold.<anonymous>.<anonymous>.<anonymous> (Navigation.kt:40)");
                                        }
                                        final NavHostController navHostController4 = navHostController3;
                                        Function0<Unit> function0 = new Function0<Unit>() { // from class: vea.raceremote.navigation.NavigationKt.AppScaffold.2.1.1.1
                                            {
                                                super(0);
                                            }

                                            @Override // kotlin.jvm.functions.Function0
                                            public /* bridge */ /* synthetic */ Unit invoke() {
                                                invoke2();
                                                return Unit.INSTANCE;
                                            }

                                            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                                            public final void invoke2() {
                                                NavController.navigate$default(navHostController4, "RemoteControl", new NavOptions.Builder().setLaunchSingleTop(LiveLiterals$NavigationKt.INSTANCE.m6855Boolean$arg0$callsetLaunchSingleTop$$this$callbuild$arg1$callnavigate$fun$anonymous$$arg0$callBluetoothPermissionRationale$fun$anonymous$$arg3$callcomposable1$fun$anonymous$$arg4$callNavHost$fun$anonymous$$arg6$callSurface$funAppScaffold1()).build(), null, 4, null);
                                            }
                                        };
                                        final NavHostController navHostController5 = navHostController3;
                                        BluetoothPermissionRationaleKt.BluetoothPermissionRationale(function0, new Function0<Unit>() { // from class: vea.raceremote.navigation.NavigationKt.AppScaffold.2.1.1.2
                                            {
                                                super(0);
                                            }

                                            @Override // kotlin.jvm.functions.Function0
                                            public /* bridge */ /* synthetic */ Unit invoke() {
                                                invoke2();
                                                return Unit.INSTANCE;
                                            }

                                            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                                            public final void invoke2() {
                                                popBackStack();
                                            }
                                        }, $composer4, 0, 0);
                                        if (ComposerKt.isTraceInProgress()) {
                                            ComposerKt.traceEventEnd();
                                        }
                                    }
                                }), 6, null);
                            }
                        }, $composer3, 8, 8);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                            return;
                        }
                        return;
                    }
                    $composer3.skipToGroupEnd();
                }
            }), $composer2, 1572864, 63);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            $composer2.skipToGroupEnd();
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.navigation.NavigationKt.AppScaffold.3
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i) {
                NavigationKt.AppScaffold(startScreen, composer, $changed | 1);
            }
        });
    }

    public static final Screens getStartScreen(Composer $composer, int $changed) {
        $composer.startReplaceableGroup(-772229374);
        ComposerKt.sourceInformation($composer, "C(getStartScreen)*58@1983L7:Navigation.kt#yp73o1");
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventStart(-772229374, $changed, -1, "vea.raceremote.navigation.getStartScreen (Navigation.kt:58)");
        }
        ProvidableCompositionLocal<Context> localContext = AndroidCompositionLocals_androidKt.getLocalContext();
        ComposerKt.sourceInformationMarkerStart($composer, 2023513938, "C:CompositionLocal.kt#9igjgp");
        Object objConsume = $composer.consume(localContext);
        ComposerKt.sourceInformationMarkerEnd($composer);
        Context $this$getStartScreen_u24lambda_u240 = (Context) objConsume;
        Screens screens = BluetoothUtilsKt.hasBluetoothPermissions($this$getStartScreen_u24lambda_u240) ? Screens.RemoteControl : Screens.BluetoothPermissionsRationale;
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventEnd();
        }
        $composer.endReplaceableGroup();
        return screens;
    }
}
