package vea.raceremote.navigation;

import kotlin.Metadata;

/* JADX INFO: compiled from: Screens.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0004\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004¨\u0006\u0005"}, d2 = {"Lvea/raceremote/navigation/Screens;", "", "(Ljava/lang/String;I)V", "RemoteControl", "BluetoothPermissionsRationale", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public enum Screens {
    RemoteControl,
    BluetoothPermissionsRationale
}
