package vea.raceremote.network;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: MockRemoteDeviceApi.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/network/MockRemoteDeviceApi.kt")
public final class LiveLiterals$MockRemoteDeviceApiKt {

    /* JADX INFO: renamed from: Int$class-MockRemoteDeviceApi, reason: not valid java name */
    private static int f1784Int$classMockRemoteDeviceApi;

    /* JADX INFO: renamed from: State$Int$class-MockRemoteDeviceApi, reason: not valid java name */
    private static State<Integer> f1786State$Int$classMockRemoteDeviceApi;

    /* JADX INFO: renamed from: State$Long$arg-0$call-delay$fun-isRemoteDevice$class-MockRemoteDeviceApi, reason: not valid java name */
    private static State<Long> f1787State$Long$arg0$calldelay$funisRemoteDevice$classMockRemoteDeviceApi;
    public static final LiveLiterals$MockRemoteDeviceApiKt INSTANCE = new LiveLiterals$MockRemoteDeviceApiKt();

    /* JADX INFO: renamed from: Long$arg-0$call-delay$fun-isRemoteDevice$class-MockRemoteDeviceApi, reason: not valid java name */
    private static long f1785Long$arg0$calldelay$funisRemoteDevice$classMockRemoteDeviceApi = 1000;

    @LiveLiteralInfo(key = "Int$class-MockRemoteDeviceApi", offset = -1)
    /* JADX INFO: renamed from: Int$class-MockRemoteDeviceApi, reason: not valid java name */
    public final int m6856Int$classMockRemoteDeviceApi() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1784Int$classMockRemoteDeviceApi;
        }
        State<Integer> stateLiveLiteral = f1786State$Int$classMockRemoteDeviceApi;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-MockRemoteDeviceApi", Integer.valueOf(f1784Int$classMockRemoteDeviceApi));
            f1786State$Int$classMockRemoteDeviceApi = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-delay$fun-isRemoteDevice$class-MockRemoteDeviceApi", offset = 171)
    /* JADX INFO: renamed from: Long$arg-0$call-delay$fun-isRemoteDevice$class-MockRemoteDeviceApi, reason: not valid java name */
    public final long m6857Long$arg0$calldelay$funisRemoteDevice$classMockRemoteDeviceApi() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1785Long$arg0$calldelay$funisRemoteDevice$classMockRemoteDeviceApi;
        }
        State<Long> stateLiveLiteral = f1787State$Long$arg0$calldelay$funisRemoteDevice$classMockRemoteDeviceApi;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-delay$fun-isRemoteDevice$class-MockRemoteDeviceApi", Long.valueOf(f1785Long$arg0$calldelay$funisRemoteDevice$classMockRemoteDeviceApi));
            f1787State$Long$arg0$calldelay$funisRemoteDevice$classMockRemoteDeviceApi = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }
}
