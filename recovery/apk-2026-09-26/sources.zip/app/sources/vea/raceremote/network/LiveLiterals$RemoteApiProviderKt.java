package vea.raceremote.network;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: RemoteApiProvider.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/network/RemoteApiProvider.kt")
public final class LiveLiterals$RemoteApiProviderKt {
    public static final LiveLiterals$RemoteApiProviderKt INSTANCE = new LiveLiterals$RemoteApiProviderKt();

    /* JADX INFO: renamed from: Int$class-RemoteApiProvider, reason: not valid java name */
    private static int f1788Int$classRemoteApiProvider = 8;

    /* JADX INFO: renamed from: State$Int$class-RemoteApiProvider, reason: not valid java name */
    private static State<Integer> f1789State$Int$classRemoteApiProvider;

    @LiveLiteralInfo(key = "Int$class-RemoteApiProvider", offset = -1)
    /* JADX INFO: renamed from: Int$class-RemoteApiProvider, reason: not valid java name */
    public final int m6858Int$classRemoteApiProvider() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1788Int$classRemoteApiProvider;
        }
        State<Integer> stateLiveLiteral = f1789State$Int$classRemoteApiProvider;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-RemoteApiProvider", Integer.valueOf(f1788Int$classRemoteApiProvider));
            f1789State$Int$classRemoteApiProvider = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }
}
