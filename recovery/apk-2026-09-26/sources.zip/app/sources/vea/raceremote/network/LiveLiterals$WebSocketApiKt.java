package vea.raceremote.network;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: WebSocketApi.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/network/WebSocketApi.kt")
public final class LiveLiterals$WebSocketApiKt {

    /* JADX INFO: renamed from: State$Int$class-WebSocketApi, reason: not valid java name */
    private static State<Integer> f1791State$Int$classWebSocketApi;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-debug$fun-$anonymous$$arg-0$call-let$fun-sendMessage$class-WebSocketApi, reason: not valid java name */
    private static State<String> f1792State$String$0$str$arg0$calldebug$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-debug-1$fun-$anonymous$$arg-0$call-let$fun-sendMessage$class-WebSocketApi, reason: not valid java name */
    private static State<String> f1793State$String$0$str$arg0$calldebug1$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi;

    /* JADX INFO: renamed from: State$String$2$str$arg-0$call-debug$fun-$anonymous$$arg-0$call-let$fun-sendMessage$class-WebSocketApi, reason: not valid java name */
    private static State<String> f1794State$String$2$str$arg0$calldebug$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi;

    /* JADX INFO: renamed from: State$String$2$str$arg-0$call-debug-1$fun-$anonymous$$arg-0$call-let$fun-sendMessage$class-WebSocketApi, reason: not valid java name */
    private static State<String> f1795State$String$2$str$arg0$calldebug1$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi;
    public static final LiveLiterals$WebSocketApiKt INSTANCE = new LiveLiterals$WebSocketApiKt();

    /* JADX INFO: renamed from: String$0$str$arg-0$call-debug$fun-$anonymous$$arg-0$call-let$fun-sendMessage$class-WebSocketApi, reason: not valid java name */
    private static String f1796String$0$str$arg0$calldebug$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi = "size: ";

    /* JADX INFO: renamed from: String$2$str$arg-0$call-debug$fun-$anonymous$$arg-0$call-let$fun-sendMessage$class-WebSocketApi, reason: not valid java name */
    private static String f1798String$2$str$arg0$calldebug$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi = " \nmessage: ";

    /* JADX INFO: renamed from: String$0$str$arg-0$call-debug-1$fun-$anonymous$$arg-0$call-let$fun-sendMessage$class-WebSocketApi, reason: not valid java name */
    private static String f1797String$0$str$arg0$calldebug1$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi = "isSend = ";

    /* JADX INFO: renamed from: String$2$str$arg-0$call-debug-1$fun-$anonymous$$arg-0$call-let$fun-sendMessage$class-WebSocketApi, reason: not valid java name */
    private static String f1799String$2$str$arg0$calldebug1$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi = "\n";

    /* JADX INFO: renamed from: Int$class-WebSocketApi, reason: not valid java name */
    private static int f1790Int$classWebSocketApi = 8;

    @LiveLiteralInfo(key = "Int$class-WebSocketApi", offset = -1)
    /* JADX INFO: renamed from: Int$class-WebSocketApi, reason: not valid java name */
    public final int m6859Int$classWebSocketApi() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1790Int$classWebSocketApi;
        }
        State<Integer> stateLiveLiteral = f1791State$Int$classWebSocketApi;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-WebSocketApi", Integer.valueOf(f1790Int$classWebSocketApi));
            f1791State$Int$classWebSocketApi = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-debug$fun-$anonymous$$arg-0$call-let$fun-sendMessage$class-WebSocketApi", offset = 847)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-debug$fun-$anonymous$$arg-0$call-let$fun-sendMessage$class-WebSocketApi, reason: not valid java name */
    public final String m6860String$0$str$arg0$calldebug$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1796String$0$str$arg0$calldebug$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi;
        }
        State<String> stateLiveLiteral = f1792State$String$0$str$arg0$calldebug$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-debug$fun-$anonymous$$arg-0$call-let$fun-sendMessage$class-WebSocketApi", f1796String$0$str$arg0$calldebug$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi);
            f1792State$String$0$str$arg0$calldebug$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-debug-1$fun-$anonymous$$arg-0$call-let$fun-sendMessage$class-WebSocketApi", offset = 962)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-debug-1$fun-$anonymous$$arg-0$call-let$fun-sendMessage$class-WebSocketApi, reason: not valid java name */
    public final String m6861String$0$str$arg0$calldebug1$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1797String$0$str$arg0$calldebug1$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi;
        }
        State<String> stateLiveLiteral = f1793State$String$0$str$arg0$calldebug1$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-debug-1$fun-$anonymous$$arg-0$call-let$fun-sendMessage$class-WebSocketApi", f1797String$0$str$arg0$calldebug1$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi);
            f1793State$String$0$str$arg0$calldebug1$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$arg-0$call-debug$fun-$anonymous$$arg-0$call-let$fun-sendMessage$class-WebSocketApi", offset = 874)
    /* JADX INFO: renamed from: String$2$str$arg-0$call-debug$fun-$anonymous$$arg-0$call-let$fun-sendMessage$class-WebSocketApi, reason: not valid java name */
    public final String m6862String$2$str$arg0$calldebug$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1798String$2$str$arg0$calldebug$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi;
        }
        State<String> stateLiveLiteral = f1794State$String$2$str$arg0$calldebug$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$arg-0$call-debug$fun-$anonymous$$arg-0$call-let$fun-sendMessage$class-WebSocketApi", f1798String$2$str$arg0$calldebug$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi);
            f1794State$String$2$str$arg0$calldebug$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$arg-0$call-debug-1$fun-$anonymous$$arg-0$call-let$fun-sendMessage$class-WebSocketApi", offset = 978)
    /* JADX INFO: renamed from: String$2$str$arg-0$call-debug-1$fun-$anonymous$$arg-0$call-let$fun-sendMessage$class-WebSocketApi, reason: not valid java name */
    public final String m6863String$2$str$arg0$calldebug1$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1799String$2$str$arg0$calldebug1$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi;
        }
        State<String> stateLiveLiteral = f1795State$String$2$str$arg0$calldebug1$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$arg-0$call-debug-1$fun-$anonymous$$arg-0$call-let$fun-sendMessage$class-WebSocketApi", f1799String$2$str$arg0$calldebug1$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi);
            f1795State$String$2$str$arg0$calldebug1$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
