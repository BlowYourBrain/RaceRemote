package vea.raceremote.network;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlinx.coroutines.DelayKt;

/* JADX INFO: compiled from: MockRemoteDeviceApi.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\bÇ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0011\u0010\u0003\u001a\u00020\u0004H\u0096@ø\u0001\u0000¢\u0006\u0002\u0010\u0005\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u0006"}, d2 = {"Lvea/raceremote/network/MockRemoteDeviceApi;", "Lvea/raceremote/network/RemoteDeviceApi;", "()V", "isRemoteDevice", "", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class MockRemoteDeviceApi implements RemoteDeviceApi {
    public static final MockRemoteDeviceApi INSTANCE = new MockRemoteDeviceApi();
    public static final int $stable = LiveLiterals$MockRemoteDeviceApiKt.INSTANCE.m6856Int$classMockRemoteDeviceApi();

    private MockRemoteDeviceApi() {
    }

    @Override // vea.raceremote.network.RemoteDeviceApi
    public Object isRemoteDevice(Continuation<? super Unit> continuation) {
        Object objDelay = DelayKt.delay(LiveLiterals$MockRemoteDeviceApiKt.INSTANCE.m6857Long$arg0$calldelay$funisRemoteDevice$classMockRemoteDeviceApi(), continuation);
        return objDelay == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objDelay : Unit.INSTANCE;
    }
}
