package vea.raceremote.network;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import retrofit2.Retrofit;

/* JADX INFO: compiled from: RemoteApiProvider.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0006\u0010\u0005\u001a\u00020\u0006R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0007"}, d2 = {"Lvea/raceremote/network/RemoteApiProvider;", "", "retrofit", "Lretrofit2/Retrofit;", "(Lretrofit2/Retrofit;)V", "provideRemoteDeviceApi", "Lvea/raceremote/network/RemoteDeviceApi;", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class RemoteApiProvider {
    public static final int $stable = LiveLiterals$RemoteApiProviderKt.INSTANCE.m6858Int$classRemoteApiProvider();
    private final Retrofit retrofit;

    public RemoteApiProvider(Retrofit retrofit) {
        Intrinsics.checkNotNullParameter(retrofit, "retrofit");
        this.retrofit = retrofit;
    }

    public final RemoteDeviceApi provideRemoteDeviceApi() {
        Object objCreate = create(RemoteDeviceApi.class);
        Intrinsics.checkNotNullExpressionValue(objCreate, "retrofit.create(RemoteDeviceApi::class.java)");
        return (RemoteDeviceApi) objCreate;
    }
}
