package vea.raceremote.network;

import java.util.concurrent.TimeUnit;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;
import vea.raceremote.utils.LogKt;

/* JADX INFO: compiled from: WebSocketApi.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u0000 \u00172\u00020\u0001:\u0001\u0017B\u0005¢\u0006\u0002\u0010\u0002J\u0006\u0010\f\u001a\u00020\rJ\b\u0010\u000e\u001a\u00020\u000bH\u0002J \u0010\u000f\u001a\u00020\r2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0013H\u0016J\u000e\u0010\u0014\u001a\u00020\r2\u0006\u0010\u0015\u001a\u00020\u0016R#\u0010\u0003\u001a\n \u0005*\u0004\u0018\u00010\u00040\u00048BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0018"}, d2 = {"Lvea/raceremote/network/WebSocketApi;", "Lokhttp3/WebSocketListener;", "()V", "okHttpClient", "Lokhttp3/OkHttpClient;", "kotlin.jvm.PlatformType", "getOkHttpClient", "()Lokhttp3/OkHttpClient;", "okHttpClient$delegate", "Lkotlin/Lazy;", "webSocket", "Lokhttp3/WebSocket;", "cancelWebSocket", "", "getOrCreateWebSocket", "onClosing", "code", "", "reason", "", "sendMessage", "message", "Lokio/ByteString;", "Companion", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class WebSocketApi extends WebSocketListener {
    private static final String BASE_URl = "ws://192.168.1.100:1337/";
    private static final long CONNECTION_TIMEOUT = 10;
    private static final long READ_TIMEOUT = 10;

    /* JADX INFO: renamed from: okHttpClient$delegate, reason: from kotlin metadata */
    private final Lazy okHttpClient = LazyKt.lazy(new Function0<OkHttpClient>() { // from class: vea.raceremote.network.WebSocketApi$okHttpClient$2
        @Override // kotlin.jvm.functions.Function0
        public final OkHttpClient invoke() {
            return new OkHttpClient.Builder().connectTimeout(10L, TimeUnit.SECONDS).readTimeout(10L, TimeUnit.SECONDS).build();
        }
    });
    private final WebSocket webSocket;
    public static final int $stable = LiveLiterals$WebSocketApiKt.INSTANCE.m6859Int$classWebSocketApi();

    private final OkHttpClient getOkHttpClient() {
        return (OkHttpClient) getValue();
    }

    public final void sendMessage(ByteString message) {
        Intrinsics.checkNotNullParameter(message, "message");
        WebSocket socket = getOrCreateWebSocket();
        LogKt.debug$default(LiveLiterals$WebSocketApiKt.INSTANCE.m6860String$0$str$arg0$calldebug$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi() + socket.queueSize() + LiveLiterals$WebSocketApiKt.INSTANCE.m6862String$2$str$arg0$calldebug$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi() + message, null, 2, null);
        boolean isSend = socket.send(message);
        LogKt.debug$default(LiveLiterals$WebSocketApiKt.INSTANCE.m6861String$0$str$arg0$calldebug1$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi() + isSend + LiveLiterals$WebSocketApiKt.INSTANCE.m6863String$2$str$arg0$calldebug1$fun$anonymous$$arg0$calllet$funsendMessage$classWebSocketApi(), null, 2, null);
    }

    @Override // okhttp3.WebSocketListener
    public void onClosing(WebSocket webSocket, int code, String reason) {
        Intrinsics.checkNotNullParameter(webSocket, "webSocket");
        Intrinsics.checkNotNullParameter(reason, "reason");
        webSocket.cancel();
    }

    public final void cancelWebSocket() {
        WebSocket webSocket = this.webSocket;
        if (webSocket != null) {
            webSocket.cancel();
        }
    }

    private final WebSocket getOrCreateWebSocket() {
        WebSocket webSocket = this.webSocket;
        if (webSocket != null) {
            return webSocket;
        }
        Request request = new Request.Builder().url("ws://192.168.1.100:1337/").build();
        WebSocket webSocketNewWebSocket = getOkHttpClient().newWebSocket(request, this);
        Intrinsics.checkNotNullExpressionValue(webSocketNewWebSocket, "run {\n            val re…(request, this)\n        }");
        return webSocketNewWebSocket;
    }
}
