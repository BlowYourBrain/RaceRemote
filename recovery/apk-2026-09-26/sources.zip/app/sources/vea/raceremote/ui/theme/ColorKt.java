package vea.raceremote.ui.theme;

import kotlin.Metadata;

/* JADX INFO: compiled from: Color.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\bb\"\u0016\u0010\u0000\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0002\u0010\u0003\"\u0016\u0010\u0005\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0006\u0010\u0003\"\u0016\u0010\u0007\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\b\u0010\u0003\"\u0016\u0010\t\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\n\u0010\u0003\"\u0016\u0010\u000b\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\f\u0010\u0003\"\u0016\u0010\r\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u000e\u0010\u0003\"\u0016\u0010\u000f\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0010\u0010\u0003\"\u0016\u0010\u0011\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0012\u0010\u0003\"\u0016\u0010\u0013\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0014\u0010\u0003\"\u0016\u0010\u0015\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0016\u0010\u0003\"\u0016\u0010\u0017\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0018\u0010\u0003\"\u0016\u0010\u0019\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u001a\u0010\u0003\"\u0016\u0010\u001b\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u001c\u0010\u0003\"\u0016\u0010\u001d\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u001e\u0010\u0003\"\u0016\u0010\u001f\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b \u0010\u0003\"\u0016\u0010!\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\"\u0010\u0003\"\u0016\u0010#\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b$\u0010\u0003\"\u0016\u0010%\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b&\u0010\u0003\"\u0016\u0010'\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b(\u0010\u0003\"\u0016\u0010)\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b*\u0010\u0003\"\u0016\u0010+\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b,\u0010\u0003\"\u0016\u0010-\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b.\u0010\u0003\"\u0016\u0010/\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b0\u0010\u0003\"\u0016\u00101\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b2\u0010\u0003\"\u0016\u00103\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b4\u0010\u0003\"\u0016\u00105\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b6\u0010\u0003\"\u0016\u00107\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b8\u0010\u0003\"\u0016\u00109\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b:\u0010\u0003\"\u0016\u0010;\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b<\u0010\u0003\"\u0016\u0010=\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b>\u0010\u0003\"\u0016\u0010?\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b@\u0010\u0003\"\u0016\u0010A\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\bB\u0010\u0003\"\u0016\u0010C\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\bD\u0010\u0003\"\u0016\u0010E\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\bF\u0010\u0003\"\u0016\u0010G\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\bH\u0010\u0003\"\u0016\u0010I\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\bJ\u0010\u0003\"\u0016\u0010K\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\bL\u0010\u0003\"\u0016\u0010M\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\bN\u0010\u0003\"\u0016\u0010O\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\bP\u0010\u0003\"\u0016\u0010Q\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\bR\u0010\u0003\"\u0016\u0010S\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\bT\u0010\u0003\"\u0016\u0010U\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\bV\u0010\u0003\"\u0016\u0010W\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\bX\u0010\u0003\"\u0016\u0010Y\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\bZ\u0010\u0003\"\u0016\u0010[\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\\\u0010\u0003\"\u0016\u0010]\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b^\u0010\u0003\"\u0016\u0010_\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b`\u0010\u0003\"\u0016\u0010a\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\bb\u0010\u0003\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006c"}, d2 = {"DARK_BACKGROUND", "Landroidx/compose/ui/graphics/Color;", "getDARK_BACKGROUND", "()J", "J", "DARK_ERROR", "getDARK_ERROR", "DARK_ERROR_CONTAINER", "getDARK_ERROR_CONTAINER", "DARK_ON_BACKGROUND", "getDARK_ON_BACKGROUND", "DARK_ON_ERROR", "getDARK_ON_ERROR", "DARK_ON_ERROR_CONTAINER", "getDARK_ON_ERROR_CONTAINER", "DARK_ON_PRIMARY", "getDARK_ON_PRIMARY", "DARK_ON_PRIMARY_CONTAINER", "getDARK_ON_PRIMARY_CONTAINER", "DARK_ON_SECONDARY", "getDARK_ON_SECONDARY", "DARK_ON_SECONDARY_CONTAINER", "getDARK_ON_SECONDARY_CONTAINER", "DARK_ON_SURFACE", "getDARK_ON_SURFACE", "DARK_ON_SURFACE_VARIANT", "getDARK_ON_SURFACE_VARIANT", "DARK_ON_TERTIARY", "getDARK_ON_TERTIARY", "DARK_ON_TERTIARY_CONTAINER", "getDARK_ON_TERTIARY_CONTAINER", "DARK_OUTLINE", "getDARK_OUTLINE", "DARK_OUTLINE_VARIANT", "getDARK_OUTLINE_VARIANT", "DARK_PRIMARY", "getDARK_PRIMARY", "DARK_PRIMARY_CONTAINER", "getDARK_PRIMARY_CONTAINER", "DARK_SECONDARY", "getDARK_SECONDARY", "DARK_SECONDARY_CONTAINER", "getDARK_SECONDARY_CONTAINER", "DARK_SURFACE", "getDARK_SURFACE", "DARK_SURFACE_VARIANT", "getDARK_SURFACE_VARIANT", "DARK_TERTIARY", "getDARK_TERTIARY", "DARK_TERTIARY_CONTAINER", "getDARK_TERTIARY_CONTAINER", "LIGHT_BACKGROUND", "getLIGHT_BACKGROUND", "LIGHT_ERROR", "getLIGHT_ERROR", "LIGHT_ERROR_CONTAINER", "getLIGHT_ERROR_CONTAINER", "LIGHT_ON_BACKGROUND", "getLIGHT_ON_BACKGROUND", "LIGHT_ON_ERROR", "getLIGHT_ON_ERROR", "LIGHT_ON_ERROR_CONTAINER", "getLIGHT_ON_ERROR_CONTAINER", "LIGHT_ON_PRIMARY", "getLIGHT_ON_PRIMARY", "LIGHT_ON_PRIMARY_CONTAINER", "getLIGHT_ON_PRIMARY_CONTAINER", "LIGHT_ON_SECONDARY", "getLIGHT_ON_SECONDARY", "LIGHT_ON_SECONDARY_CONTAINER", "getLIGHT_ON_SECONDARY_CONTAINER", "LIGHT_ON_SURFACE", "getLIGHT_ON_SURFACE", "LIGHT_ON_SURFACE_VARIANT", "getLIGHT_ON_SURFACE_VARIANT", "LIGHT_ON_TERTIARY", "getLIGHT_ON_TERTIARY", "LIGHT_ON_TERTIARY_CONTAINER", "getLIGHT_ON_TERTIARY_CONTAINER", "LIGHT_OUTLINE", "getLIGHT_OUTLINE", "LIGHT_OUTLINE_VARIANT", "getLIGHT_OUTLINE_VARIANT", "LIGHT_PRIMARY", "getLIGHT_PRIMARY", "LIGHT_PRIMARY_CONTAINER", "getLIGHT_PRIMARY_CONTAINER", "LIGHT_SECONDARY", "getLIGHT_SECONDARY", "LIGHT_SECONDARY_CONTAINER", "getLIGHT_SECONDARY_CONTAINER", "LIGHT_SURFACE", "getLIGHT_SURFACE", "LIGHT_SURFACE_VARIANT", "getLIGHT_SURFACE_VARIANT", "LIGHT_TERTIARY", "getLIGHT_TERTIARY", "LIGHT_TERTIARY_CONTAINER", "getLIGHT_TERTIARY_CONTAINER", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class ColorKt {
    private static final long LIGHT_PRIMARY = androidx.compose.ui.graphics.ColorKt.Color(4284960932L);
    private static final long LIGHT_ON_PRIMARY = androidx.compose.ui.graphics.ColorKt.Color(4294967295L);
    private static final long LIGHT_PRIMARY_CONTAINER = androidx.compose.ui.graphics.ColorKt.Color(4293582335L);
    private static final long LIGHT_ON_PRIMARY_CONTAINER = androidx.compose.ui.graphics.ColorKt.Color(4280352861L);
    private static final long LIGHT_SECONDARY = androidx.compose.ui.graphics.ColorKt.Color(4284636017L);
    private static final long LIGHT_ON_SECONDARY = androidx.compose.ui.graphics.ColorKt.Color(4294967295L);
    private static final long LIGHT_SECONDARY_CONTAINER = androidx.compose.ui.graphics.ColorKt.Color(4293451512L);
    private static final long LIGHT_ON_SECONDARY_CONTAINER = androidx.compose.ui.graphics.ColorKt.Color(4280097067L);
    private static final long LIGHT_TERTIARY = androidx.compose.ui.graphics.ColorKt.Color(4286403168L);
    private static final long LIGHT_ON_TERTIARY = androidx.compose.ui.graphics.ColorKt.Color(4294967295L);
    private static final long LIGHT_TERTIARY_CONTAINER = androidx.compose.ui.graphics.ColorKt.Color(4294957284L);
    private static final long LIGHT_ON_TERTIARY_CONTAINER = androidx.compose.ui.graphics.ColorKt.Color(4281405725L);
    private static final long LIGHT_ERROR = androidx.compose.ui.graphics.ColorKt.Color(4289930782L);
    private static final long LIGHT_ERROR_CONTAINER = androidx.compose.ui.graphics.ColorKt.Color(4294565596L);
    private static final long LIGHT_ON_ERROR = androidx.compose.ui.graphics.ColorKt.Color(4294967295L);
    private static final long LIGHT_ON_ERROR_CONTAINER = androidx.compose.ui.graphics.ColorKt.Color(4282453515L);
    private static final long LIGHT_BACKGROUND = androidx.compose.ui.graphics.ColorKt.Color(4294966270L);
    private static final long LIGHT_ON_BACKGROUND = androidx.compose.ui.graphics.ColorKt.Color(4280032031L);
    private static final long LIGHT_SURFACE = androidx.compose.ui.graphics.ColorKt.Color(4294966270L);
    private static final long LIGHT_ON_SURFACE = androidx.compose.ui.graphics.ColorKt.Color(4280032031L);
    private static final long LIGHT_SURFACE_VARIANT = androidx.compose.ui.graphics.ColorKt.Color(4293386476L);
    private static final long LIGHT_ON_SURFACE_VARIANT = androidx.compose.ui.graphics.ColorKt.Color(4282991951L);
    private static final long LIGHT_OUTLINE = androidx.compose.ui.graphics.ColorKt.Color(4286149758L);
    private static final long LIGHT_OUTLINE_VARIANT = androidx.compose.ui.graphics.ColorKt.Color(4291478736L);
    private static final long DARK_PRIMARY = androidx.compose.ui.graphics.ColorKt.Color(4291869951L);
    private static final long DARK_ON_PRIMARY = androidx.compose.ui.graphics.ColorKt.Color(4281867890L);
    private static final long DARK_PRIMARY_CONTAINER = androidx.compose.ui.graphics.ColorKt.Color(4283381643L);
    private static final long DARK_ON_PRIMARY_CONTAINER = androidx.compose.ui.graphics.ColorKt.Color(4293582335L);
    private static final long DARK_SECONDARY = androidx.compose.ui.graphics.ColorKt.Color(4291609308L);
    private static final long DARK_ON_SECONDARY = androidx.compose.ui.graphics.ColorKt.Color(4281544001L);
    private static final long DARK_SECONDARY_CONTAINER = androidx.compose.ui.graphics.ColorKt.Color(4283057240L);
    private static final long DARK_ON_SECONDARY_CONTAINER = androidx.compose.ui.graphics.ColorKt.Color(4293451512L);
    private static final long DARK_TERTIARY = androidx.compose.ui.graphics.ColorKt.Color(4293900488L);
    private static final long DARK_ON_TERTIARY = androidx.compose.ui.graphics.ColorKt.Color(4282983730L);
    private static final long DARK_TERTIARY_CONTAINER = androidx.compose.ui.graphics.ColorKt.Color(4284693320L);
    private static final long DARK_ON_TERTIARY_CONTAINER = androidx.compose.ui.graphics.ColorKt.Color(4294957284L);
    private static final long DARK_ERROR = androidx.compose.ui.graphics.ColorKt.Color(4294097077L);
    private static final long DARK_ERROR_CONTAINER = androidx.compose.ui.graphics.ColorKt.Color(4287372568L);
    private static final long DARK_ON_ERROR = androidx.compose.ui.graphics.ColorKt.Color(4284486672L);
    private static final long DARK_ON_ERROR_CONTAINER = androidx.compose.ui.graphics.ColorKt.Color(4294565596L);
    private static final long DARK_BACKGROUND = androidx.compose.ui.graphics.ColorKt.Color(4280032031L);
    private static final long DARK_ON_BACKGROUND = androidx.compose.ui.graphics.ColorKt.Color(4293321189L);
    private static final long DARK_SURFACE = androidx.compose.ui.graphics.ColorKt.Color(4280032031L);
    private static final long DARK_ON_SURFACE = androidx.compose.ui.graphics.ColorKt.Color(4293321189L);
    private static final long DARK_SURFACE_VARIANT = androidx.compose.ui.graphics.ColorKt.Color(4282991951L);
    private static final long DARK_ON_SURFACE_VARIANT = androidx.compose.ui.graphics.ColorKt.Color(4291478736L);
    private static final long DARK_OUTLINE = androidx.compose.ui.graphics.ColorKt.Color(4287860633L);
    private static final long DARK_OUTLINE_VARIANT = androidx.compose.ui.graphics.ColorKt.Color(4282991951L);

    public static final long getLIGHT_PRIMARY() {
        return LIGHT_PRIMARY;
    }

    public static final long getLIGHT_ON_PRIMARY() {
        return LIGHT_ON_PRIMARY;
    }

    public static final long getLIGHT_PRIMARY_CONTAINER() {
        return LIGHT_PRIMARY_CONTAINER;
    }

    public static final long getLIGHT_ON_PRIMARY_CONTAINER() {
        return LIGHT_ON_PRIMARY_CONTAINER;
    }

    public static final long getLIGHT_SECONDARY() {
        return LIGHT_SECONDARY;
    }

    public static final long getLIGHT_ON_SECONDARY() {
        return LIGHT_ON_SECONDARY;
    }

    public static final long getLIGHT_SECONDARY_CONTAINER() {
        return LIGHT_SECONDARY_CONTAINER;
    }

    public static final long getLIGHT_ON_SECONDARY_CONTAINER() {
        return LIGHT_ON_SECONDARY_CONTAINER;
    }

    public static final long getLIGHT_TERTIARY() {
        return LIGHT_TERTIARY;
    }

    public static final long getLIGHT_ON_TERTIARY() {
        return LIGHT_ON_TERTIARY;
    }

    public static final long getLIGHT_TERTIARY_CONTAINER() {
        return LIGHT_TERTIARY_CONTAINER;
    }

    public static final long getLIGHT_ON_TERTIARY_CONTAINER() {
        return LIGHT_ON_TERTIARY_CONTAINER;
    }

    public static final long getLIGHT_ERROR() {
        return LIGHT_ERROR;
    }

    public static final long getLIGHT_ERROR_CONTAINER() {
        return LIGHT_ERROR_CONTAINER;
    }

    public static final long getLIGHT_ON_ERROR() {
        return LIGHT_ON_ERROR;
    }

    public static final long getLIGHT_ON_ERROR_CONTAINER() {
        return LIGHT_ON_ERROR_CONTAINER;
    }

    public static final long getLIGHT_BACKGROUND() {
        return LIGHT_BACKGROUND;
    }

    public static final long getLIGHT_ON_BACKGROUND() {
        return LIGHT_ON_BACKGROUND;
    }

    public static final long getLIGHT_SURFACE() {
        return LIGHT_SURFACE;
    }

    public static final long getLIGHT_ON_SURFACE() {
        return LIGHT_ON_SURFACE;
    }

    public static final long getLIGHT_SURFACE_VARIANT() {
        return LIGHT_SURFACE_VARIANT;
    }

    public static final long getLIGHT_ON_SURFACE_VARIANT() {
        return LIGHT_ON_SURFACE_VARIANT;
    }

    public static final long getLIGHT_OUTLINE() {
        return LIGHT_OUTLINE;
    }

    public static final long getLIGHT_OUTLINE_VARIANT() {
        return LIGHT_OUTLINE_VARIANT;
    }

    public static final long getDARK_PRIMARY() {
        return DARK_PRIMARY;
    }

    public static final long getDARK_ON_PRIMARY() {
        return DARK_ON_PRIMARY;
    }

    public static final long getDARK_PRIMARY_CONTAINER() {
        return DARK_PRIMARY_CONTAINER;
    }

    public static final long getDARK_ON_PRIMARY_CONTAINER() {
        return DARK_ON_PRIMARY_CONTAINER;
    }

    public static final long getDARK_SECONDARY() {
        return DARK_SECONDARY;
    }

    public static final long getDARK_ON_SECONDARY() {
        return DARK_ON_SECONDARY;
    }

    public static final long getDARK_SECONDARY_CONTAINER() {
        return DARK_SECONDARY_CONTAINER;
    }

    public static final long getDARK_ON_SECONDARY_CONTAINER() {
        return DARK_ON_SECONDARY_CONTAINER;
    }

    public static final long getDARK_TERTIARY() {
        return DARK_TERTIARY;
    }

    public static final long getDARK_ON_TERTIARY() {
        return DARK_ON_TERTIARY;
    }

    public static final long getDARK_TERTIARY_CONTAINER() {
        return DARK_TERTIARY_CONTAINER;
    }

    public static final long getDARK_ON_TERTIARY_CONTAINER() {
        return DARK_ON_TERTIARY_CONTAINER;
    }

    public static final long getDARK_ERROR() {
        return DARK_ERROR;
    }

    public static final long getDARK_ERROR_CONTAINER() {
        return DARK_ERROR_CONTAINER;
    }

    public static final long getDARK_ON_ERROR() {
        return DARK_ON_ERROR;
    }

    public static final long getDARK_ON_ERROR_CONTAINER() {
        return DARK_ON_ERROR_CONTAINER;
    }

    public static final long getDARK_BACKGROUND() {
        return DARK_BACKGROUND;
    }

    public static final long getDARK_ON_BACKGROUND() {
        return DARK_ON_BACKGROUND;
    }

    public static final long getDARK_SURFACE() {
        return DARK_SURFACE;
    }

    public static final long getDARK_ON_SURFACE() {
        return DARK_ON_SURFACE;
    }

    public static final long getDARK_SURFACE_VARIANT() {
        return DARK_SURFACE_VARIANT;
    }

    public static final long getDARK_ON_SURFACE_VARIANT() {
        return DARK_ON_SURFACE_VARIANT;
    }

    public static final long getDARK_OUTLINE() {
        return DARK_OUTLINE;
    }

    public static final long getDARK_OUTLINE_VARIANT() {
        return DARK_OUTLINE_VARIANT;
    }
}
