package vea.raceremote.ui.theme;

import androidx.compose.foundation.shape.RoundedCornerShape;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.ui.unit.Dp;
import kotlin.Metadata;

/* JADX INFO: compiled from: Shape.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\bÇ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u0011\u0010\u0003\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u0011\u0010\u0007\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\u0006R\u0011\u0010\t\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u0006¨\u0006\u000b"}, d2 = {"Lvea/raceremote/ui/theme/CornerShapes;", "", "()V", "HugeItem", "Landroidx/compose/foundation/shape/RoundedCornerShape;", "getHugeItem", "()Landroidx/compose/foundation/shape/RoundedCornerShape;", "Round", "getRound", "SmallItem", "getSmallItem", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class CornerShapes {
    public static final CornerShapes INSTANCE = new CornerShapes();
    private static final RoundedCornerShape HugeItem = RoundedCornerShapeKt.m677RoundedCornerShape0680j_4(Dp.m4046constructorimpl(16));
    private static final RoundedCornerShape SmallItem = RoundedCornerShapeKt.m677RoundedCornerShape0680j_4(Dp.m4046constructorimpl(8));
    private static final RoundedCornerShape Round = RoundedCornerShapeKt.RoundedCornerShape(50);
    public static final int $stable = LiveLiterals$ShapeKt.INSTANCE.m6879Int$classCornerShapes();

    private CornerShapes() {
    }

    public final RoundedCornerShape getHugeItem() {
        return HugeItem;
    }

    public final RoundedCornerShape getSmallItem() {
        return SmallItem;
    }

    public final RoundedCornerShape getRound() {
        return Round;
    }
}
