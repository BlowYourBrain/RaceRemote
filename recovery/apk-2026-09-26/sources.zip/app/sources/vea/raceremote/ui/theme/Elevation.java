package vea.raceremote.ui.theme;

import androidx.compose.ui.unit.Dp;
import kotlin.Metadata;

/* JADX INFO: compiled from: Values.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\bÇ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u001c\u0010\u0003\u001a\u00020\u0004ø\u0001\u0000ø\u0001\u0001ø\u0001\u0002¢\u0006\n\n\u0002\u0010\u0007\u001a\u0004\b\u0005\u0010\u0006\u0082\u0002\u000f\n\u0002\b\u0019\n\u0005\b¡\u001e0\u0001\n\u0002\b!¨\u0006\b"}, d2 = {"Lvea/raceremote/ui/theme/Elevation;", "", "()V", "onSurface", "Landroidx/compose/ui/unit/Dp;", "getOnSurface-D9Ej5fM", "()F", "F", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class Elevation {
    public static final Elevation INSTANCE = new Elevation();
    private static final float onSurface = Dp.m4046constructorimpl(4);
    public static final int $stable = LiveLiterals$ValuesKt.INSTANCE.m6883Int$classElevation();

    private Elevation() {
    }

    /* JADX INFO: renamed from: getOnSurface-D9Ej5fM, reason: not valid java name */
    public final float m6878getOnSurfaceD9Ej5fM() {
        return onSurface;
    }
}
