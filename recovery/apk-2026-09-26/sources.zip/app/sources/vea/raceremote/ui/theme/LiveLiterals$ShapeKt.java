package vea.raceremote.ui.theme;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: Shape.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/ui/theme/Shape.kt")
public final class LiveLiterals$ShapeKt {
    public static final LiveLiterals$ShapeKt INSTANCE = new LiveLiterals$ShapeKt();

    /* JADX INFO: renamed from: Int$class-CornerShapes, reason: not valid java name */
    private static int f1800Int$classCornerShapes;

    /* JADX INFO: renamed from: State$Int$class-CornerShapes, reason: not valid java name */
    private static State<Integer> f1801State$Int$classCornerShapes;

    @LiveLiteralInfo(key = "Int$class-CornerShapes", offset = -1)
    /* JADX INFO: renamed from: Int$class-CornerShapes, reason: not valid java name */
    public final int m6879Int$classCornerShapes() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1800Int$classCornerShapes;
        }
        State<Integer> stateLiveLiteral = f1801State$Int$classCornerShapes;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-CornerShapes", Integer.valueOf(f1800Int$classCornerShapes));
            f1801State$Int$classCornerShapes = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }
}
