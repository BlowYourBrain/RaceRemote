package vea.raceremote.ui.theme;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: Theme.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/ui/theme/Theme.kt")
public final class LiveLiterals$ThemeKt {

    /* JADX INFO: renamed from: Int$class-CustomColors, reason: not valid java name */
    private static int f1803Int$classCustomColors;

    /* JADX INFO: renamed from: Int$class-Palette, reason: not valid java name */
    private static int f1804Int$classPalette;

    /* JADX INFO: renamed from: State$Boolean$param-isSystemInDarkTheme$fun-getPalette, reason: not valid java name */
    private static State<Boolean> f1805State$Boolean$paramisSystemInDarkTheme$fungetPalette;

    /* JADX INFO: renamed from: State$Int$class-CustomColors, reason: not valid java name */
    private static State<Integer> f1806State$Int$classCustomColors;

    /* JADX INFO: renamed from: State$Int$class-Palette, reason: not valid java name */
    private static State<Integer> f1807State$Int$classPalette;
    public static final LiveLiterals$ThemeKt INSTANCE = new LiveLiterals$ThemeKt();

    /* JADX INFO: renamed from: Boolean$param-isSystemInDarkTheme$fun-getPalette, reason: not valid java name */
    private static boolean f1802Boolean$paramisSystemInDarkTheme$fungetPalette = true;

    @LiveLiteralInfo(key = "Boolean$param-isSystemInDarkTheme$fun-getPalette", offset = 3455)
    /* JADX INFO: renamed from: Boolean$param-isSystemInDarkTheme$fun-getPalette, reason: not valid java name */
    public final boolean m6880Boolean$paramisSystemInDarkTheme$fungetPalette() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1802Boolean$paramisSystemInDarkTheme$fungetPalette;
        }
        State<Boolean> stateLiveLiteral = f1805State$Boolean$paramisSystemInDarkTheme$fungetPalette;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$param-isSystemInDarkTheme$fun-getPalette", Boolean.valueOf(f1802Boolean$paramisSystemInDarkTheme$fungetPalette));
            f1805State$Boolean$paramisSystemInDarkTheme$fungetPalette = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Int$class-CustomColors", offset = -1)
    /* JADX INFO: renamed from: Int$class-CustomColors, reason: not valid java name */
    public final int m6881Int$classCustomColors() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1803Int$classCustomColors;
        }
        State<Integer> stateLiveLiteral = f1806State$Int$classCustomColors;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-CustomColors", Integer.valueOf(f1803Int$classCustomColors));
            f1806State$Int$classCustomColors = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-Palette", offset = -1)
    /* JADX INFO: renamed from: Int$class-Palette, reason: not valid java name */
    public final int m6882Int$classPalette() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1804Int$classPalette;
        }
        State<Integer> stateLiveLiteral = f1807State$Int$classPalette;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-Palette", Integer.valueOf(f1804Int$classPalette));
            f1807State$Int$classPalette = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }
}
