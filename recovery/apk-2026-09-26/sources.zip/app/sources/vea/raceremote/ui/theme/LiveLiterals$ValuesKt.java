package vea.raceremote.ui.theme;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: Values.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/ui/theme/Values.kt")
public final class LiveLiterals$ValuesKt {
    public static final LiveLiterals$ValuesKt INSTANCE = new LiveLiterals$ValuesKt();

    /* JADX INFO: renamed from: Int$class-Elevation, reason: not valid java name */
    private static int f1808Int$classElevation;

    /* JADX INFO: renamed from: Int$class-Padding, reason: not valid java name */
    private static int f1809Int$classPadding;

    /* JADX INFO: renamed from: Int$class-Size, reason: not valid java name */
    private static int f1810Int$classSize;

    /* JADX INFO: renamed from: State$Int$class-Elevation, reason: not valid java name */
    private static State<Integer> f1811State$Int$classElevation;

    /* JADX INFO: renamed from: State$Int$class-Padding, reason: not valid java name */
    private static State<Integer> f1812State$Int$classPadding;

    /* JADX INFO: renamed from: State$Int$class-Size, reason: not valid java name */
    private static State<Integer> f1813State$Int$classSize;

    @LiveLiteralInfo(key = "Int$class-Elevation", offset = -1)
    /* JADX INFO: renamed from: Int$class-Elevation, reason: not valid java name */
    public final int m6883Int$classElevation() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1808Int$classElevation;
        }
        State<Integer> stateLiveLiteral = f1811State$Int$classElevation;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-Elevation", Integer.valueOf(f1808Int$classElevation));
            f1811State$Int$classElevation = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-Padding", offset = -1)
    /* JADX INFO: renamed from: Int$class-Padding, reason: not valid java name */
    public final int m6884Int$classPadding() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1809Int$classPadding;
        }
        State<Integer> stateLiveLiteral = f1812State$Int$classPadding;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-Padding", Integer.valueOf(f1809Int$classPadding));
            f1812State$Int$classPadding = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-Size", offset = -1)
    /* JADX INFO: renamed from: Int$class-Size, reason: not valid java name */
    public final int m6885Int$classSize() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1810Int$classSize;
        }
        State<Integer> stateLiveLiteral = f1813State$Int$classSize;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-Size", Integer.valueOf(f1810Int$classSize));
            f1813State$Int$classSize = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }
}
