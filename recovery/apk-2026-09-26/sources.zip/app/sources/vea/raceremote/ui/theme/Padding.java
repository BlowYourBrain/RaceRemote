package vea.raceremote.ui.theme;

import androidx.compose.ui.unit.Dp;
import kotlin.Metadata;

/* JADX INFO: compiled from: Values.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\bÇ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u001c\u0010\u0003\u001a\u00020\u0004ø\u0001\u0000ø\u0001\u0001ø\u0001\u0002¢\u0006\n\n\u0002\u0010\u0007\u001a\u0004\b\u0005\u0010\u0006R\u001c\u0010\b\u001a\u00020\u0004ø\u0001\u0000ø\u0001\u0001ø\u0001\u0002¢\u0006\n\n\u0002\u0010\u0007\u001a\u0004\b\t\u0010\u0006\u0082\u0002\u000f\n\u0002\b\u0019\n\u0005\b¡\u001e0\u0001\n\u0002\b!¨\u0006\n"}, d2 = {"Lvea/raceremote/ui/theme/Padding;", "", "()V", "Content", "Landroidx/compose/ui/unit/Dp;", "getContent-D9Ej5fM", "()F", "F", "ListSpace", "getListSpace-D9Ej5fM", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class Padding {
    public static final Padding INSTANCE = new Padding();
    private static final float Content = Dp.m4046constructorimpl(12);
    private static final float ListSpace = Dp.m4046constructorimpl(4);
    public static final int $stable = LiveLiterals$ValuesKt.INSTANCE.m6884Int$classPadding();

    private Padding() {
    }

    /* JADX INFO: renamed from: getContent-D9Ej5fM, reason: not valid java name */
    public final float m6886getContentD9Ej5fM() {
        return Content;
    }

    /* JADX INFO: renamed from: getListSpace-D9Ej5fM, reason: not valid java name */
    public final float m6887getListSpaceD9Ej5fM() {
        return ListSpace;
    }
}
