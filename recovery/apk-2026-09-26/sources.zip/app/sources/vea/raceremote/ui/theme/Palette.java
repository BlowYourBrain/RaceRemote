package vea.raceremote.ui.theme;

import androidx.compose.material.Colors;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Theme.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0007\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u000b"}, d2 = {"Lvea/raceremote/ui/theme/Palette;", "", "colors", "Landroidx/compose/material/Colors;", "customColors", "Lvea/raceremote/ui/theme/CustomColors;", "(Landroidx/compose/material/Colors;Lvea/raceremote/ui/theme/CustomColors;)V", "getColors", "()Landroidx/compose/material/Colors;", "getCustomColors", "()Lvea/raceremote/ui/theme/CustomColors;", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class Palette {
    public static final int $stable = LiveLiterals$ThemeKt.INSTANCE.m6882Int$classPalette();
    private final Colors colors;
    private final CustomColors customColors;

    public Palette(Colors colors, CustomColors customColors) {
        Intrinsics.checkNotNullParameter(colors, "colors");
        Intrinsics.checkNotNullParameter(customColors, "customColors");
        this.colors = colors;
        this.customColors = customColors;
    }

    public final Colors getColors() {
        return this.colors;
    }

    public final CustomColors getCustomColors() {
        return this.customColors;
    }
}
