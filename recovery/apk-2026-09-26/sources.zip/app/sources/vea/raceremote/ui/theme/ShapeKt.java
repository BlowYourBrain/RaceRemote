package vea.raceremote.ui.theme;

import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.material.Shapes;
import androidx.compose.ui.unit.Dp;
import kotlin.Metadata;

/* JADX INFO: compiled from: Shape.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\"\u0011\u0010\u0000\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Shapes", "Landroidx/compose/material/Shapes;", "getShapes", "()Landroidx/compose/material/Shapes;", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class ShapeKt {
    private static final Shapes Shapes = new Shapes(RoundedCornerShapeKt.m677RoundedCornerShape0680j_4(Dp.m4046constructorimpl(4)), RoundedCornerShapeKt.m677RoundedCornerShape0680j_4(Dp.m4046constructorimpl(4)), RoundedCornerShapeKt.m677RoundedCornerShape0680j_4(Dp.m4046constructorimpl(0)));

    public static final Shapes getShapes() {
        return Shapes;
    }
}
