package vea.raceremote.ui.theme;

import androidx.compose.ui.unit.Dp;
import kotlin.Metadata;

/* JADX INFO: compiled from: Values.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\f\bÇ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u001c\u0010\u0003\u001a\u00020\u0004ø\u0001\u0000ø\u0001\u0001ø\u0001\u0002¢\u0006\n\n\u0002\u0010\u0007\u001a\u0004\b\u0005\u0010\u0006R\u001c\u0010\b\u001a\u00020\u0004ø\u0001\u0000ø\u0001\u0001ø\u0001\u0002¢\u0006\n\n\u0002\u0010\u0007\u001a\u0004\b\t\u0010\u0006R\u001c\u0010\n\u001a\u00020\u0004ø\u0001\u0000ø\u0001\u0001ø\u0001\u0002¢\u0006\n\n\u0002\u0010\u0007\u001a\u0004\b\u000b\u0010\u0006R\u001c\u0010\f\u001a\u00020\u0004ø\u0001\u0000ø\u0001\u0001ø\u0001\u0002¢\u0006\n\n\u0002\u0010\u0007\u001a\u0004\b\r\u0010\u0006R\u001c\u0010\u000e\u001a\u00020\u0004ø\u0001\u0000ø\u0001\u0001ø\u0001\u0002¢\u0006\n\n\u0002\u0010\u0007\u001a\u0004\b\u000f\u0010\u0006\u0082\u0002\u000f\n\u0002\b\u0019\n\u0005\b¡\u001e0\u0001\n\u0002\b!¨\u0006\u0010"}, d2 = {"Lvea/raceremote/ui/theme/Size;", "", "()V", "ButtonAsIcon", "Landroidx/compose/ui/unit/Dp;", "getButtonAsIcon-D9Ej5fM", "()F", "F", "HugeButtonAsIcon", "getHugeButtonAsIcon-D9Ej5fM", "HugeIcon", "getHugeIcon-D9Ej5fM", "Icon", "getIcon-D9Ej5fM", "MediumIcon", "getMediumIcon-D9Ej5fM", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class Size {
    public static final Size INSTANCE = new Size();
    private static final float Icon = Dp.m4046constructorimpl(24);
    private static final float MediumIcon = Dp.m4046constructorimpl(48);
    private static final float HugeIcon = Dp.m4046constructorimpl(64);
    private static final float ButtonAsIcon = Dp.m4046constructorimpl(48);
    private static final float HugeButtonAsIcon = Dp.m4046constructorimpl(64);
    public static final int $stable = LiveLiterals$ValuesKt.INSTANCE.m6885Int$classSize();

    private Size() {
    }

    /* JADX INFO: renamed from: getIcon-D9Ej5fM, reason: not valid java name */
    public final float m6891getIconD9Ej5fM() {
        return Icon;
    }

    /* JADX INFO: renamed from: getMediumIcon-D9Ej5fM, reason: not valid java name */
    public final float m6892getMediumIconD9Ej5fM() {
        return MediumIcon;
    }

    /* JADX INFO: renamed from: getHugeIcon-D9Ej5fM, reason: not valid java name */
    public final float m6890getHugeIconD9Ej5fM() {
        return HugeIcon;
    }

    /* JADX INFO: renamed from: getButtonAsIcon-D9Ej5fM, reason: not valid java name */
    public final float m6888getButtonAsIconD9Ej5fM() {
        return ButtonAsIcon;
    }

    /* JADX INFO: renamed from: getHugeButtonAsIcon-D9Ej5fM, reason: not valid java name */
    public final float m6889getHugeButtonAsIconD9Ej5fM() {
        return HugeButtonAsIcon;
    }
}
