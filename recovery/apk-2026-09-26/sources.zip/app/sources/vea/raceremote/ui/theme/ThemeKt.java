package vea.raceremote.ui.theme;

import androidx.compose.foundation.DarkThemeKt;
import androidx.compose.material.Colors;
import androidx.compose.material.ColorsKt;
import androidx.compose.material.MaterialThemeKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.ui.graphics.Color;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Theme.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u00002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a*\u0010\f\u001a\u00020\r2\b\b\u0002\u0010\u000e\u001a\u00020\u000f2\u0011\u0010\u0010\u001a\r\u0012\u0004\u0012\u00020\r0\u0011¢\u0006\u0002\b\u0012H\u0007¢\u0006\u0002\u0010\u0013\u001a\u0010\u0010\n\u001a\u00020\u00012\b\b\u0002\u0010\u0014\u001a\u00020\u000f\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000\"\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000\"\u000e\u0010\u0005\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000\"\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000\"\u000e\u0010\b\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000\"\u0011\u0010\t\u001a\u00020\u00018G¢\u0006\u0006\u001a\u0004\b\n\u0010\u000b¨\u0006\u0015"}, d2 = {"DarkColorPalette", "Lvea/raceremote/ui/theme/Palette;", "LightColorPalette", "_CustomDarkColorPalette", "Lvea/raceremote/ui/theme/CustomColors;", "_CustomLightColorPalette", "_DarkColorPalette", "Landroidx/compose/material/Colors;", "_LightColorPalette", "palette", "getPalette", "(Landroidx/compose/runtime/Composer;I)Lvea/raceremote/ui/theme/Palette;", "RaceRemoteTheme", "", "darkTheme", "", "content", "Lkotlin/Function0;", "Landroidx/compose/runtime/Composable;", "(ZLkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V", "isSystemInDarkTheme", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class ThemeKt {
    private static final Palette DarkColorPalette;
    private static final Palette LightColorPalette;
    private static final CustomColors _CustomDarkColorPalette;
    private static final CustomColors _CustomLightColorPalette;
    private static final Colors _DarkColorPalette;
    private static final Colors _LightColorPalette;

    static {
        long dark_primary = ColorKt.getDARK_PRIMARY();
        long dark_on_primary = ColorKt.getDARK_ON_PRIMARY();
        long dark_secondary = ColorKt.getDARK_SECONDARY();
        long dark_on_secondary = ColorKt.getDARK_ON_SECONDARY();
        long dark_background = ColorKt.getDARK_BACKGROUND();
        long dark_on_background = ColorKt.getDARK_ON_BACKGROUND();
        Colors colorsM1001darkColors2qZNXz8$default = ColorsKt.m1001darkColors2qZNXz8$default(dark_primary, 0L, dark_secondary, 0L, dark_background, ColorKt.getDARK_SURFACE(), ColorKt.getDARK_ERROR(), dark_on_primary, dark_on_secondary, dark_on_background, ColorKt.getDARK_ON_SURFACE(), ColorKt.getDARK_ON_ERROR(), 10, null);
        _DarkColorPalette = colorsM1001darkColors2qZNXz8$default;
        CustomColors customColors = new CustomColors(ColorKt.getDARK_PRIMARY_CONTAINER(), ColorKt.getDARK_ON_PRIMARY_CONTAINER(), ColorKt.getDARK_SECONDARY_CONTAINER(), ColorKt.getDARK_ON_SECONDARY_CONTAINER(), ColorKt.getDARK_TERTIARY(), ColorKt.getDARK_ON_TERTIARY(), ColorKt.getDARK_TERTIARY_CONTAINER(), ColorKt.getDARK_ON_TERTIARY_CONTAINER(), ColorKt.getDARK_ERROR_CONTAINER(), ColorKt.getDARK_ON_ERROR_CONTAINER(), ColorKt.getDARK_SURFACE_VARIANT(), ColorKt.getDARK_ON_SURFACE_VARIANT(), ColorKt.getDARK_OUTLINE(), ColorKt.getDARK_OUTLINE_VARIANT());
        _CustomDarkColorPalette = customColors;
        long light_primary = ColorKt.getLIGHT_PRIMARY();
        long light_on_primary = ColorKt.getLIGHT_ON_PRIMARY();
        long light_secondary = ColorKt.getLIGHT_SECONDARY();
        long light_on_secondary = ColorKt.getLIGHT_ON_SECONDARY();
        long light_background = ColorKt.getLIGHT_BACKGROUND();
        long light_on_background = ColorKt.getLIGHT_ON_BACKGROUND();
        Colors colorsM1002lightColors2qZNXz8 = ColorsKt.m1002lightColors2qZNXz8((10 & 1) != 0 ? androidx.compose.ui.graphics.ColorKt.Color(4284612846L) : light_primary, (10 & 2) != 0 ? androidx.compose.ui.graphics.ColorKt.Color(4281794739L) : 0L, (10 & 4) != 0 ? androidx.compose.ui.graphics.ColorKt.Color(4278442694L) : light_secondary, (10 & 8) != 0 ? androidx.compose.ui.graphics.ColorKt.Color(4278290310L) : 0L, (10 & 16) != 0 ? Color.INSTANCE.m1698getWhite0d7_KjU() : light_background, (10 & 32) != 0 ? Color.INSTANCE.m1698getWhite0d7_KjU() : ColorKt.getLIGHT_SURFACE(), (10 & 64) != 0 ? androidx.compose.ui.graphics.ColorKt.Color(4289724448L) : ColorKt.getLIGHT_ERROR(), (10 & 128) != 0 ? Color.INSTANCE.m1698getWhite0d7_KjU() : light_on_primary, (10 & 256) != 0 ? Color.INSTANCE.m1687getBlack0d7_KjU() : light_on_secondary, (10 & 512) != 0 ? Color.INSTANCE.m1687getBlack0d7_KjU() : light_on_background, (10 & 1024) != 0 ? Color.INSTANCE.m1687getBlack0d7_KjU() : ColorKt.getLIGHT_ON_SURFACE(), (10 & 2048) != 0 ? Color.INSTANCE.m1698getWhite0d7_KjU() : ColorKt.getLIGHT_ON_ERROR());
        _LightColorPalette = colorsM1002lightColors2qZNXz8;
        CustomColors customColors2 = new CustomColors(ColorKt.getLIGHT_PRIMARY_CONTAINER(), ColorKt.getLIGHT_ON_PRIMARY_CONTAINER(), ColorKt.getLIGHT_SECONDARY_CONTAINER(), ColorKt.getLIGHT_ON_SECONDARY_CONTAINER(), ColorKt.getLIGHT_TERTIARY(), ColorKt.getLIGHT_ON_TERTIARY(), ColorKt.getLIGHT_TERTIARY_CONTAINER(), ColorKt.getLIGHT_ON_TERTIARY_CONTAINER(), ColorKt.getLIGHT_ERROR_CONTAINER(), ColorKt.getLIGHT_ON_ERROR_CONTAINER(), ColorKt.getLIGHT_SURFACE_VARIANT(), ColorKt.getLIGHT_ON_SURFACE_VARIANT(), ColorKt.getLIGHT_OUTLINE(), ColorKt.getLIGHT_OUTLINE_VARIANT());
        _CustomLightColorPalette = customColors2;
        DarkColorPalette = new Palette(colorsM1001darkColors2qZNXz8$default, customColors);
        LightColorPalette = new Palette(colorsM1002lightColors2qZNXz8, customColors2);
    }

    public static final Palette getPalette(Composer $composer, int $changed) {
        Palette palette;
        $composer.startReplaceableGroup(517554229);
        ComposerKt.sourceInformation($composer, "C106@3313L21:Theme.kt#4vwwqe");
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventStart(517554229, $changed, -1, "vea.raceremote.ui.theme.<get-palette> (Theme.kt:105)");
        }
        if (DarkThemeKt.isSystemInDarkTheme($composer, 0)) {
            palette = DarkColorPalette;
        } else {
            palette = LightColorPalette;
        }
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventEnd();
        }
        $composer.endReplaceableGroup();
        return palette;
    }

    public static /* synthetic */ Palette getPalette$default(boolean z, int i, Object obj) {
        if ((i & 1) != 0) {
            z = LiveLiterals$ThemeKt.INSTANCE.m6880Boolean$paramisSystemInDarkTheme$fungetPalette();
        }
        return getPalette(z);
    }

    public static final Palette getPalette(boolean isSystemInDarkTheme) {
        if (isSystemInDarkTheme) {
            return DarkColorPalette;
        }
        return LightColorPalette;
    }

    public static final void RaceRemoteTheme(final boolean darkTheme, final Function2<? super Composer, ? super Integer, Unit> function2, Composer $composer, final int $changed, final int i) {
        Intrinsics.checkNotNullParameter(function2, "content");
        Composer $composer2 = $composer.startRestartGroup(245897191);
        ComposerKt.sourceInformation($composer2, "C(RaceRemoteTheme)P(1)118@3615L21,121@3729L141:Theme.kt#4vwwqe");
        int $dirty = $changed;
        if ((i & 2) != 0) {
            $dirty |= 48;
        } else if (($changed & 112) == 0) {
            $dirty |= $composer2.changed(function2) ? 32 : 16;
        }
        if (($dirty & 81) != 16 || !$composer2.getSkipping()) {
            $composer2.startDefaults();
            if (($changed & 1) != 0 && !$composer2.getDefaultsInvalid()) {
                $composer2.skipToGroupEnd();
                if ((i & 1) != 0) {
                    $dirty &= -15;
                }
            } else if ((i & 1) != 0) {
                darkTheme = DarkThemeKt.isSystemInDarkTheme($composer2, 0);
                $dirty &= -15;
            }
            int $dirty2 = $dirty;
            $composer2.endDefaults();
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(245897191, $dirty2, -1, "vea.raceremote.ui.theme.RaceRemoteTheme (Theme.kt:118)");
            }
            Colors androidThemeColors = getPalette$default(false, 1, null).getColors();
            MaterialThemeKt.MaterialTheme(androidThemeColors, TypeKt.getTypography(), ShapeKt.getShapes(), function2, $composer2, (($dirty2 << 6) & 7168) | 432, 0);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            $composer2.skipToGroupEnd();
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.ui.theme.ThemeKt.RaceRemoteTheme.1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i2) {
                ThemeKt.RaceRemoteTheme(darkTheme, function2, composer, $changed | 1, i);
            }
        });
    }
}
