package vea.raceremote.ui.views;

import androidx.compose.foundation.ImageKt;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.shape.RoundedCornerShape;
import androidx.compose.material.ButtonColors;
import androidx.compose.material.ButtonDefaults;
import androidx.compose.material.ButtonKt;
import androidx.compose.material.MaterialTheme;
import androidx.compose.material.TextKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.graphics.ColorFilter;
import androidx.compose.ui.layout.ContentScale;
import androidx.compose.ui.res.PainterResources_androidKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import vea.raceremote.ui.theme.CornerShapes;
import vea.raceremote.ui.theme.Padding;
import vea.raceremote.ui.theme.Palette;
import vea.raceremote.ui.theme.Size;
import vea.raceremote.ui.theme.ThemeKt;

/* JADX INFO: compiled from: Buttons.kt */
/* JADX INFO: loaded from: classes9.dex */
@Metadata(d1 = {"\u0000$\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000e\n\u0002\b\u0002\u001a3\u0010\u0000\u001a\u00020\u00012\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0001\u0010\u0004\u001a\u00020\u00052\u0010\b\u0002\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\u0001\u0018\u00010\u0007H\u0007¢\u0006\u0002\u0010\b\u001a\r\u0010\t\u001a\u00020\u0001H\u0003¢\u0006\u0002\u0010\n\u001a3\u0010\u000b\u001a\u00020\u00012\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0001\u0010\u0004\u001a\u00020\u00052\u0010\b\u0002\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\u0001\u0018\u00010\u0007H\u0007¢\u0006\u0002\u0010\b\u001aA\u0010\f\u001a\u00020\u00012\b\b\u0002\u0010\u0002\u001a\u00020\u00032\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u000e2\n\b\u0003\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u0010\b\u0002\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\u0001\u0018\u00010\u0007H\u0007¢\u0006\u0002\u0010\u000f¨\u0006\u0010"}, d2 = {"ActionButton", "", "modifier", "Landroidx/compose/ui/Modifier;", "icon", "", "onClick", "Lkotlin/Function0;", "(Landroidx/compose/ui/Modifier;ILkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V", "PreviewActionButton", "(Landroidx/compose/runtime/Composer;I)V", "RoundActionButton", "TextButton", "text", "", "(Landroidx/compose/ui/Modifier;Ljava/lang/String;Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class ButtonsKt {
    public static final void TextButton(Modifier modifier, String text, Integer icon, Function0<Unit> function0, Composer $composer, final int $changed, final int i) {
        Modifier modifier2;
        String str;
        Integer icon2;
        Function0<Unit> function1;
        Object value$iv$iv;
        Modifier modifier3;
        String text2;
        Composer $composer2 = $composer.startRestartGroup(1279517034);
        ComposerKt.sourceInformation($composer2, "C(TextButton)P(1,3)35@1204L6,36@1246L6,34@1164L108,33@1109L21,31@1054L460:Buttons.kt#4usob5");
        final int $dirty = $changed;
        int i2 = i & 1;
        if (i2 != 0) {
            $dirty |= 6;
            modifier2 = modifier;
        } else if (($changed & 14) == 0) {
            modifier2 = modifier;
            $dirty |= $composer2.changed(modifier2) ? 4 : 2;
        } else {
            modifier2 = modifier;
        }
        int i3 = i & 2;
        if (i3 != 0) {
            $dirty |= 48;
            str = text;
        } else if (($changed & 112) == 0) {
            str = text;
            $dirty |= $composer2.changed(str) ? 32 : 16;
        } else {
            str = text;
        }
        int i4 = i & 4;
        if (i4 != 0) {
            $dirty |= 384;
            icon2 = icon;
        } else if (($changed & 896) == 0) {
            icon2 = icon;
            $dirty |= $composer2.changed(icon2) ? 256 : 128;
        } else {
            icon2 = icon;
        }
        int i5 = i & 8;
        if (i5 != 0) {
            $dirty |= 3072;
            function1 = function0;
        } else if (($changed & 7168) == 0) {
            function1 = function0;
            $dirty |= $composer2.changed(function1) ? 2048 : 1024;
        } else {
            function1 = function0;
        }
        if (($dirty & 5851) == 1170 && $composer2.getSkipping()) {
            $composer2.skipToGroupEnd();
            modifier3 = modifier2;
            text2 = str;
        } else {
            Modifier.Companion modifier4 = i2 != 0 ? Modifier.INSTANCE : modifier2;
            final String text3 = i3 != 0 ? null : str;
            final Integer icon3 = i4 != 0 ? null : icon2;
            final Function0<Unit> function2 = i5 != 0 ? null : function1;
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1279517034, $dirty, -1, "vea.raceremote.ui.views.TextButton (Buttons.kt:24)");
            }
            ButtonColors buttonColorsM931buttonColorsro_MJ88 = ButtonDefaults.INSTANCE.m931buttonColorsro_MJ88(MaterialTheme.INSTANCE.getColors($composer2, MaterialTheme.$stable).m985getSurface0d7_KjU(), MaterialTheme.INSTANCE.getColors($composer2, MaterialTheme.$stable).m980getOnSurface0d7_KjU(), 0L, 0L, $composer2, ButtonDefaults.$stable << 12, 12);
            RoundedCornerShape smallItem = CornerShapes.INSTANCE.getSmallItem();
            PaddingValues paddingValuesM420PaddingValues0680j_4 = PaddingKt.m420PaddingValues0680j_4(Padding.INSTANCE.m6886getContentD9Ej5fM());
            int i6 = ($dirty >> 9) & 14;
            $composer2.startReplaceableGroup(1157296644);
            ComposerKt.sourceInformation($composer2, "C(remember)P(1):Composables.kt#9igjgp");
            boolean invalid$iv$iv = $composer2.changed(function2);
            Object it$iv$iv = $composer2.rememberedValue();
            if (invalid$iv$iv || it$iv$iv == Composer.INSTANCE.getEmpty()) {
                value$iv$iv = (Function0) new Function0<Unit>() { // from class: vea.raceremote.ui.views.ButtonsKt$TextButton$1$1
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        Function0<Unit> function3 = function2;
                        if (function3 != null) {
                            function3.invoke();
                        }
                    }
                };
                $composer2.updateRememberedValue(value$iv$iv);
            } else {
                value$iv$iv = it$iv$iv;
            }
            $composer2.endReplaceableGroup();
            ButtonKt.Button((Function0) value$iv$iv, modifier4, false, null, null, smallItem, null, buttonColorsM931buttonColorsro_MJ88, paddingValuesM420PaddingValues0680j_4, ComposableLambdaKt.composableLambda($composer2, 1395323226, true, new Function3<RowScope, Composer, Integer, Unit>() { // from class: vea.raceremote.ui.views.ButtonsKt.TextButton.2
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(3);
                }

                @Override // kotlin.jvm.functions.Function3
                public /* bridge */ /* synthetic */ Unit invoke(RowScope rowScope, Composer composer, Integer num) {
                    invoke(rowScope, composer, num.intValue());
                    return Unit.INSTANCE;
                }

                public final void invoke(RowScope $this$Button, Composer $composer3, int $changed2) {
                    Intrinsics.checkNotNullParameter($this$Button, "$this$Button");
                    ComposerKt.sourceInformation($composer3, "C*42@1489L17:Buttons.kt#4usob5");
                    if (($changed2 & 81) != 16 || !$composer3.getSkipping()) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(1395323226, $changed2, -1, "vea.raceremote.ui.views.TextButton.<anonymous> (Buttons.kt:40)");
                        }
                        Integer num = icon3;
                        $composer3.startReplaceableGroup(532496915);
                        ComposerKt.sourceInformation($composer3, "*41@1414L24,41@1398L68");
                        if (num != null) {
                            int it = num.intValue();
                            ImageKt.Image(PainterResources_androidKt.painterResource(it, $composer3, 0), (String) null, (Modifier) null, (Alignment) null, (ContentScale) null, 0.0f, (ColorFilter) null, $composer3, 56, 124);
                            Unit unit = Unit.INSTANCE;
                        }
                        $composer3.endReplaceableGroup();
                        String str2 = text3;
                        if (str2 != null) {
                            TextKt.m1249TextfLXpl1I(str2, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, null, $composer3, ($dirty >> 3) & 14, 0, 65534);
                        }
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                            return;
                        }
                        return;
                    }
                    $composer3.skipToGroupEnd();
                }
            }), $composer2, (($dirty << 3) & 112) | 906166272, 92);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
            modifier3 = modifier4;
            text2 = text3;
            icon2 = icon3;
            function1 = function2;
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        final Modifier modifier5 = modifier3;
        final String str2 = text2;
        final Integer num = icon2;
        final Function0<Unit> function3 = function1;
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.ui.views.ButtonsKt.TextButton.3
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num2) {
                invoke(composer, num2.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i7) {
                ButtonsKt.TextButton(modifier5, str2, num, function3, composer, $changed | 1, i);
            }
        });
    }

    /* JADX WARN: Code duplicated, block: B:75:0x0220  */
    public static final void ActionButton(Modifier modifier, final int icon, Function0<Unit> function0, Composer $composer, final int $changed, final int i) {
        Modifier modifier2;
        Function0<Unit> function1;
        Object value$iv$iv;
        Object value$iv$iv2;
        Object value$iv$iv3;
        Object value$iv$iv4;
        Modifier modifier3;
        Object value$iv$iv5;
        Modifier modifier4;
        Composer $composer2 = $composer.startRestartGroup(-1131213364);
        ComposerKt.sourceInformation($composer2, "C(ActionButton)P(1)52@1668L25,53@1714L37,54@1778L35,55@1837L37,59@1973L110,64@2142L21,57@1880L460:Buttons.kt#4usob5");
        final int $dirty = $changed;
        int i2 = i & 1;
        if (i2 != 0) {
            $dirty |= 6;
            modifier2 = modifier;
        } else if (($changed & 14) == 0) {
            modifier2 = modifier;
            $dirty |= $composer2.changed(modifier2) ? 4 : 2;
        } else {
            modifier2 = modifier;
        }
        if ((i & 2) != 0) {
            $dirty |= 48;
        } else if (($changed & 112) == 0) {
            $dirty |= $composer2.changed(icon) ? 32 : 16;
        }
        int i3 = i & 4;
        if (i3 != 0) {
            $dirty |= 384;
            function1 = function0;
        } else if (($changed & 896) == 0) {
            function1 = function0;
            $dirty |= $composer2.changed(function1) ? 256 : 128;
        } else {
            function1 = function0;
        }
        if (($dirty & 731) == 146 && $composer2.getSkipping()) {
            $composer2.skipToGroupEnd();
            modifier4 = modifier2;
        } else {
            Modifier.Companion modifier5 = i2 != 0 ? Modifier.INSTANCE : modifier2;
            final Function0<Unit> function2 = i3 != 0 ? null : function1;
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1131213364, $dirty, -1, "vea.raceremote.ui.views.ActionButton (Buttons.kt:47)");
            }
            $composer2.startReplaceableGroup(-492369756);
            ComposerKt.sourceInformation($composer2, "C(remember):Composables.kt#9igjgp");
            Object it$iv$iv = $composer2.rememberedValue();
            if (it$iv$iv == Composer.INSTANCE.getEmpty()) {
                value$iv$iv = ThemeKt.getPalette$default(false, 1, null);
                $composer2.updateRememberedValue(value$iv$iv);
            } else {
                value$iv$iv = it$iv$iv;
            }
            $composer2.endReplaceableGroup();
            Palette palette = (Palette) value$iv$iv;
            $composer2.startReplaceableGroup(-492369756);
            ComposerKt.sourceInformation($composer2, "C(remember):Composables.kt#9igjgp");
            Object it$iv$iv2 = $composer2.rememberedValue();
            if (it$iv$iv2 == Composer.INSTANCE.getEmpty()) {
                value$iv$iv2 = Color.m1651boximpl(palette.getColors().m980getOnSurface0d7_KjU());
                $composer2.updateRememberedValue(value$iv$iv2);
            } else {
                value$iv$iv2 = it$iv$iv2;
            }
            $composer2.endReplaceableGroup();
            final long iconColor = ((Color) value$iv$iv2).m1671unboximpl();
            $composer2.startReplaceableGroup(-492369756);
            ComposerKt.sourceInformation($composer2, "C(remember):Composables.kt#9igjgp");
            Object it$iv$iv3 = $composer2.rememberedValue();
            if (it$iv$iv3 == Composer.INSTANCE.getEmpty()) {
                value$iv$iv3 = Color.m1651boximpl(palette.getColors().m985getSurface0d7_KjU());
                $composer2.updateRememberedValue(value$iv$iv3);
            } else {
                value$iv$iv3 = it$iv$iv3;
            }
            $composer2.endReplaceableGroup();
            long backgroundColor = ((Color) value$iv$iv3).m1671unboximpl();
            $composer2.startReplaceableGroup(-492369756);
            ComposerKt.sourceInformation($composer2, "C(remember):Composables.kt#9igjgp");
            Object it$iv$iv4 = $composer2.rememberedValue();
            if (it$iv$iv4 == Composer.INSTANCE.getEmpty()) {
                value$iv$iv4 = Color.m1651boximpl(palette.getColors().m980getOnSurface0d7_KjU());
                $composer2.updateRememberedValue(value$iv$iv4);
            } else {
                value$iv$iv4 = it$iv$iv4;
            }
            $composer2.endReplaceableGroup();
            long contentColor = ((Color) value$iv$iv4).m1671unboximpl();
            Modifier modifierM468size3ABfNKs = SizeKt.m468size3ABfNKs(modifier5, Size.INSTANCE.m6888getButtonAsIconD9Ej5fM());
            ButtonColors buttonColorsM931buttonColorsro_MJ88 = ButtonDefaults.INSTANCE.m931buttonColorsro_MJ88(backgroundColor, contentColor, 0L, 0L, $composer2, (ButtonDefaults.$stable << 12) | 54, 12);
            RoundedCornerShape hugeItem = CornerShapes.INSTANCE.getHugeItem();
            int i4 = ($dirty >> 6) & 14;
            $composer2.startReplaceableGroup(1157296644);
            ComposerKt.sourceInformation($composer2, "C(remember)P(1):Composables.kt#9igjgp");
            boolean invalid$iv$iv = $composer2.changed(function2);
            Object it$iv$iv5 = $composer2.rememberedValue();
            if (invalid$iv$iv) {
                modifier3 = modifier5;
            } else {
                modifier3 = modifier5;
                if (it$iv$iv5 != Composer.INSTANCE.getEmpty()) {
                    value$iv$iv5 = it$iv$iv5;
                }
                $composer2.endReplaceableGroup();
                ButtonKt.Button((Function0) value$iv$iv5, modifierM468size3ABfNKs, false, null, null, hugeItem, null, buttonColorsM931buttonColorsro_MJ88, null, ComposableLambdaKt.composableLambda($composer2, -1398945828, true, new Function3<RowScope, Composer, Integer, Unit>() { // from class: vea.raceremote.ui.views.ButtonsKt.ActionButton.2
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(3);
                    }

                    @Override // kotlin.jvm.functions.Function3
                    public /* bridge */ /* synthetic */ Unit invoke(RowScope rowScope, Composer composer, Integer num) {
                        invoke(rowScope, composer, num.intValue());
                        return Unit.INSTANCE;
                    }

                    public final void invoke(RowScope $this$Button, Composer $composer3, int $changed2) {
                        Intrinsics.checkNotNullParameter($this$Button, "$this$Button");
                        ComposerKt.sourceInformation($composer3, "C67@2209L21,66@2180L154:Buttons.kt#4usob5");
                        if (($changed2 & 81) != 16 || !$composer3.getSkipping()) {
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventStart(-1398945828, $changed2, -1, "vea.raceremote.ui.views.ActionButton.<anonymous> (Buttons.kt:65)");
                            }
                            ImageKt.Image(PainterResources_androidKt.painterResource(icon, $composer3, ($dirty >> 3) & 14), (String) null, (Modifier) null, (Alignment) null, (ContentScale) null, 0.0f, ColorFilter.Companion.m1702tintxETnrds$default(ColorFilter.INSTANCE, iconColor, 0, 2, null), $composer3, 1572920, 60);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                                return;
                            }
                            return;
                        }
                        $composer3.skipToGroupEnd();
                    }
                }), $composer2, 805502976, 348);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
                modifier4 = modifier3;
                function1 = function2;
            }
            value$iv$iv5 = (Function0) new Function0<Unit>() { // from class: vea.raceremote.ui.views.ButtonsKt$ActionButton$1$1
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    Function0<Unit> function3 = function2;
                    if (function3 != null) {
                        function3.invoke();
                    }
                }
            };
            $composer2.updateRememberedValue(value$iv$iv5);
            $composer2.endReplaceableGroup();
            ButtonKt.Button((Function0) value$iv$iv5, modifierM468size3ABfNKs, false, null, null, hugeItem, null, buttonColorsM931buttonColorsro_MJ88, null, ComposableLambdaKt.composableLambda($composer2, -1398945828, true, new Function3<RowScope, Composer, Integer, Unit>() { // from class: vea.raceremote.ui.views.ButtonsKt.ActionButton.2
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(3);
                }

                @Override // kotlin.jvm.functions.Function3
                public /* bridge */ /* synthetic */ Unit invoke(RowScope rowScope, Composer composer, Integer num) {
                    invoke(rowScope, composer, num.intValue());
                    return Unit.INSTANCE;
                }

                public final void invoke(RowScope $this$Button, Composer $composer3, int $changed2) {
                    Intrinsics.checkNotNullParameter($this$Button, "$this$Button");
                    ComposerKt.sourceInformation($composer3, "C67@2209L21,66@2180L154:Buttons.kt#4usob5");
                    if (($changed2 & 81) != 16 || !$composer3.getSkipping()) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1398945828, $changed2, -1, "vea.raceremote.ui.views.ActionButton.<anonymous> (Buttons.kt:65)");
                        }
                        ImageKt.Image(PainterResources_androidKt.painterResource(icon, $composer3, ($dirty >> 3) & 14), (String) null, (Modifier) null, (Alignment) null, (ContentScale) null, 0.0f, ColorFilter.Companion.m1702tintxETnrds$default(ColorFilter.INSTANCE, iconColor, 0, 2, null), $composer3, 1572920, 60);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                            return;
                        }
                        return;
                    }
                    $composer3.skipToGroupEnd();
                }
            }), $composer2, 805502976, 348);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
            modifier4 = modifier3;
            function1 = function2;
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        final Modifier modifier6 = modifier4;
        final Function0<Unit> function3 = function1;
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.ui.views.ButtonsKt.ActionButton.3
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i5) {
                ButtonsKt.ActionButton(modifier6, icon, function3, composer, $changed | 1, i);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void PreviewActionButton(Composer $composer, final int $changed) {
        Composer $composer2 = $composer.startRestartGroup(-1865915138);
        ComposerKt.sourceInformation($composer2, "C(PreviewActionButton)77@2405L56:Buttons.kt#4usob5");
        if ($changed != 0 || !$composer2.getSkipping()) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1865915138, $changed, -1, "vea.raceremote.ui.views.PreviewActionButton (Buttons.kt:76)");
            }
            ActionButton(null, 2131165330, null, $composer2, 0, 5);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            $composer2.skipToGroupEnd();
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.ui.views.ButtonsKt.PreviewActionButton.1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i) {
                ButtonsKt.PreviewActionButton(composer, $changed | 1);
            }
        });
    }

    /* JADX WARN: Code duplicated, block: B:59:0x013a  */
    public static final void RoundActionButton(Modifier modifier, final int icon, Function0<Unit> function0, Composer $composer, final int $changed, final int i) {
        Modifier modifier2;
        Function0<Unit> function1;
        Modifier modifier3;
        Object value$iv$iv;
        Modifier modifier4;
        Function0<Unit> function2;
        Composer $composer2 = $composer.startRestartGroup(1955800542);
        ComposerKt.sourceInformation($composer2, "C(RoundActionButton)P(1)89@2742L6,90@2784L6,88@2702L108,93@2866L21,86@2605L370:Buttons.kt#4usob5");
        final int $dirty = $changed;
        int i2 = i & 1;
        if (i2 != 0) {
            $dirty |= 6;
            modifier2 = modifier;
        } else if (($changed & 14) == 0) {
            modifier2 = modifier;
            $dirty |= $composer2.changed(modifier2) ? 4 : 2;
        } else {
            modifier2 = modifier;
        }
        if ((i & 2) != 0) {
            $dirty |= 48;
        } else if (($changed & 112) == 0) {
            $dirty |= $composer2.changed(icon) ? 32 : 16;
        }
        int i3 = i & 4;
        if (i3 != 0) {
            $dirty |= 384;
            function1 = function0;
        } else if (($changed & 896) == 0) {
            function1 = function0;
            $dirty |= $composer2.changed(function1) ? 256 : 128;
        } else {
            function1 = function0;
        }
        if (($dirty & 731) == 146 && $composer2.getSkipping()) {
            $composer2.skipToGroupEnd();
            function2 = function1;
            modifier4 = modifier2;
        } else {
            Modifier.Companion modifier5 = i2 != 0 ? Modifier.INSTANCE : modifier2;
            final Function0<Unit> function3 = i3 != 0 ? null : function1;
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1955800542, $dirty, -1, "vea.raceremote.ui.views.RoundActionButton (Buttons.kt:81)");
            }
            Modifier modifierM468size3ABfNKs = SizeKt.m468size3ABfNKs(modifier5, Size.INSTANCE.m6889getHugeButtonAsIconD9Ej5fM());
            ButtonColors buttonColorsM931buttonColorsro_MJ88 = ButtonDefaults.INSTANCE.m931buttonColorsro_MJ88(MaterialTheme.INSTANCE.getColors($composer2, MaterialTheme.$stable).m985getSurface0d7_KjU(), MaterialTheme.INSTANCE.getColors($composer2, MaterialTheme.$stable).m980getOnSurface0d7_KjU(), 0L, 0L, $composer2, ButtonDefaults.$stable << 12, 12);
            RoundedCornerShape round = CornerShapes.INSTANCE.getRound();
            int i4 = ($dirty >> 6) & 14;
            $composer2.startReplaceableGroup(1157296644);
            ComposerKt.sourceInformation($composer2, "C(remember)P(1):Composables.kt#9igjgp");
            boolean invalid$iv$iv = $composer2.changed(function3);
            Object it$iv$iv = $composer2.rememberedValue();
            if (invalid$iv$iv) {
                modifier3 = modifier5;
            } else {
                modifier3 = modifier5;
                if (it$iv$iv != Composer.INSTANCE.getEmpty()) {
                    value$iv$iv = it$iv$iv;
                }
                $composer2.endReplaceableGroup();
                ButtonKt.Button((Function0) value$iv$iv, modifierM468size3ABfNKs, false, null, null, round, null, buttonColorsM931buttonColorsro_MJ88, null, ComposableLambdaKt.composableLambda($composer2, 2071606734, true, new Function3<RowScope, Composer, Integer, Unit>() { // from class: vea.raceremote.ui.views.ButtonsKt.RoundActionButton.2
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(3);
                    }

                    @Override // kotlin.jvm.functions.Function3
                    public /* bridge */ /* synthetic */ Unit invoke(RowScope rowScope, Composer composer, Integer num) {
                        invoke(rowScope, composer, num.intValue());
                        return Unit.INSTANCE;
                    }

                    public final void invoke(RowScope $this$Button, Composer $composer3, int $changed2) {
                        Intrinsics.checkNotNullParameter($this$Button, "$this$Button");
                        ComposerKt.sourceInformation($composer3, "C95@2920L21,95@2904L65:Buttons.kt#4usob5");
                        if (($changed2 & 81) == 16 && $composer3.getSkipping()) {
                            $composer3.skipToGroupEnd();
                            return;
                        }
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(2071606734, $changed2, -1, "vea.raceremote.ui.views.RoundActionButton.<anonymous> (Buttons.kt:94)");
                        }
                        ImageKt.Image(PainterResources_androidKt.painterResource(icon, $composer3, ($dirty >> 3) & 14), (String) null, (Modifier) null, (Alignment) null, (ContentScale) null, 0.0f, (ColorFilter) null, $composer3, 56, 124);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    }
                }), $composer2, 805502976, 348);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
                modifier4 = modifier3;
                function2 = function3;
            }
            value$iv$iv = (Function0) new Function0<Unit>() { // from class: vea.raceremote.ui.views.ButtonsKt$RoundActionButton$1$1
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    Function0<Unit> function4 = function3;
                    if (function4 != null) {
                        function4.invoke();
                    }
                }
            };
            $composer2.updateRememberedValue(value$iv$iv);
            $composer2.endReplaceableGroup();
            ButtonKt.Button((Function0) value$iv$iv, modifierM468size3ABfNKs, false, null, null, round, null, buttonColorsM931buttonColorsro_MJ88, null, ComposableLambdaKt.composableLambda($composer2, 2071606734, true, new Function3<RowScope, Composer, Integer, Unit>() { // from class: vea.raceremote.ui.views.ButtonsKt.RoundActionButton.2
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(3);
                }

                @Override // kotlin.jvm.functions.Function3
                public /* bridge */ /* synthetic */ Unit invoke(RowScope rowScope, Composer composer, Integer num) {
                    invoke(rowScope, composer, num.intValue());
                    return Unit.INSTANCE;
                }

                public final void invoke(RowScope $this$Button, Composer $composer3, int $changed2) {
                    Intrinsics.checkNotNullParameter($this$Button, "$this$Button");
                    ComposerKt.sourceInformation($composer3, "C95@2920L21,95@2904L65:Buttons.kt#4usob5");
                    if (($changed2 & 81) == 16 && $composer3.getSkipping()) {
                        $composer3.skipToGroupEnd();
                        return;
                    }
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventStart(2071606734, $changed2, -1, "vea.raceremote.ui.views.RoundActionButton.<anonymous> (Buttons.kt:94)");
                    }
                    ImageKt.Image(PainterResources_androidKt.painterResource(icon, $composer3, ($dirty >> 3) & 14), (String) null, (Modifier) null, (Alignment) null, (ContentScale) null, 0.0f, (ColorFilter) null, $composer3, 56, 124);
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
                }
            }), $composer2, 805502976, 348);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
            modifier4 = modifier3;
            function2 = function3;
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        final Modifier modifier6 = modifier4;
        final Function0<Unit> function4 = function2;
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.ui.views.ButtonsKt.RoundActionButton.3
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i5) {
                ButtonsKt.RoundActionButton(modifier6, icon, function4, composer, $changed | 1, i);
            }
        });
    }
}
