package vea.raceremote.ui.views;

import kotlin.Metadata;

/* JADX INFO: compiled from: Joystick.kt */
/* JADX INFO: loaded from: classes9.dex */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u000b\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0082\b\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0002\u0010\u0005J\t\u0010\u000b\u001a\u00020\u0003HÆ\u0003J\t\u0010\f\u001a\u00020\u0003HÆ\u0003J\u001d\u0010\r\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u000e\u001a\u00020\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0011\u001a\u00020\u0003HÖ\u0001J\t\u0010\u0012\u001a\u00020\u0013HÖ\u0001R\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\b¨\u0006\u0014"}, d2 = {"Lvea/raceremote/ui/views/Center;", "", "x", "", "y", "(II)V", "radius", "getRadius", "()I", "getX", "getY", "component1", "component2", "copy", "equals", "", "other", "hashCode", "toString", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
final /* data */ class Center {
    private final int radius;
    private final int x;
    private final int y;

    public static /* synthetic */ Center copy$default(Center center, int i, int i2, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            i = center.x;
        }
        if ((i3 & 2) != 0) {
            i2 = center.y;
        }
        return center.copy(i, i2);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final int getX() {
        return this.x;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final int getY() {
        return this.y;
    }

    public final Center copy(int x, int y) {
        return new Center(x, y);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return LiveLiterals$JoystickKt.INSTANCE.m6925Boolean$branch$when$funequals$classCenter();
        }
        if (!(other instanceof Center)) {
            return LiveLiterals$JoystickKt.INSTANCE.m6926Boolean$branch$when1$funequals$classCenter();
        }
        Center center = (Center) other;
        if (this.x != center.x) {
            return LiveLiterals$JoystickKt.INSTANCE.m6927Boolean$branch$when2$funequals$classCenter();
        }
        return this.y != center.y ? LiveLiterals$JoystickKt.INSTANCE.m6928Boolean$branch$when3$funequals$classCenter() : LiveLiterals$JoystickKt.INSTANCE.m6930Boolean$funequals$classCenter();
    }

    public int hashCode() {
        return (LiveLiterals$JoystickKt.INSTANCE.m6952Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCenter() * Integer.hashCode(this.x)) + Integer.hashCode(this.y);
    }

    public String toString() {
        return LiveLiterals$JoystickKt.INSTANCE.m6955String$0$str$funtoString$classCenter() + LiveLiterals$JoystickKt.INSTANCE.m6956String$1$str$funtoString$classCenter() + this.x + LiveLiterals$JoystickKt.INSTANCE.m6957String$3$str$funtoString$classCenter() + LiveLiterals$JoystickKt.INSTANCE.m6958String$4$str$funtoString$classCenter() + this.y + LiveLiterals$JoystickKt.INSTANCE.m6959String$6$str$funtoString$classCenter();
    }

    public Center(int x, int y) {
        this.x = x;
        this.y = y;
        this.radius = x;
    }

    public final int getX() {
        return this.x;
    }

    public final int getY() {
        return this.y;
    }

    public final int getRadius() {
        return this.radius;
    }
}
