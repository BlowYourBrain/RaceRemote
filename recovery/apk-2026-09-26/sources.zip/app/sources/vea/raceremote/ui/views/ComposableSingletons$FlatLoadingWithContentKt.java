package vea.raceremote.ui.views;

import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: FlatLoadingWithContent.kt */
/* JADX INFO: loaded from: classes9.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
public final class ComposableSingletons$FlatLoadingWithContentKt {
    public static final ComposableSingletons$FlatLoadingWithContentKt INSTANCE = new ComposableSingletons$FlatLoadingWithContentKt();

    /* JADX INFO: renamed from: lambda-1, reason: not valid java name */
    public static Function3<DotsState, Composer, Integer, Unit> f1814lambda1 = ComposableLambdaKt.composableLambdaInstance(-349145478, false, new Function3<DotsState, Composer, Integer, Unit>() { // from class: vea.raceremote.ui.views.ComposableSingletons$FlatLoadingWithContentKt$lambda-1$1
        @Override // kotlin.jvm.functions.Function3
        public /* bridge */ /* synthetic */ Unit invoke(DotsState dotsState, Composer composer, Integer num) {
            invoke(dotsState, composer, num.intValue());
            return Unit.INSTANCE;
        }

        public final void invoke(DotsState targetState, Composer $composer, int $changed) {
            Intrinsics.checkNotNullParameter(targetState, "targetState");
            ComposerKt.sourceInformation($composer, "C:FlatLoadingWithContent.kt#4usob5");
            int $dirty = $changed;
            if (($changed & 14) == 0) {
                $dirty |= $composer.changed(targetState) ? 4 : 2;
            }
            if (($dirty & 91) != 18 || !$composer.getSkipping()) {
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventStart(-349145478, $changed, -1, "vea.raceremote.ui.views.ComposableSingletons$FlatLoadingWithContentKt.lambda-1.<anonymous> (FlatLoadingWithContent.kt:107)");
                }
                if (targetState instanceof DotsState.Idle) {
                    $composer.startReplaceableGroup(-1609426289);
                    ComposerKt.sourceInformation($composer, "109@4158L26");
                    FlatLoadingWithContentKt.addEmptySpace((DotsState.Idle) targetState, $composer, 0);
                    $composer.endReplaceableGroup();
                } else if (targetState instanceof DotsState.Loading) {
                    $composer.startReplaceableGroup(-1609426222);
                    ComposerKt.sourceInformation($composer, "110@4225L27");
                    FlatLoadingWithContentKt.addLoadingDots((DotsState.Loading) targetState, $composer, 0);
                    $composer.endReplaceableGroup();
                } else if (targetState instanceof DotsState.ShowText) {
                    $composer.startReplaceableGroup(-1609426153);
                    ComposerKt.sourceInformation($composer, "111@4294L20");
                    FlatLoadingWithContentKt.addText((DotsState.ShowText) targetState, $composer, 0);
                    $composer.endReplaceableGroup();
                } else {
                    $composer.startReplaceableGroup(-1609426119);
                    $composer.endReplaceableGroup();
                }
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                    return;
                }
                return;
            }
            $composer.skipToGroupEnd();
        }
    });

    /* JADX INFO: renamed from: getLambda-1$app_debug, reason: not valid java name */
    public final Function3<DotsState, Composer, Integer, Unit> m6893getLambda1$app_debug() {
        return f1814lambda1;
    }
}
