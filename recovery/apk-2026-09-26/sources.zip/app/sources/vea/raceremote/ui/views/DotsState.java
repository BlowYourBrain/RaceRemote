package vea.raceremote.ui.views;

import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.unit.Dp;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.text.StringsKt;

/* JADX INFO: compiled from: FlatLoadingWithContent.kt */
/* JADX INFO: loaded from: classes9.dex */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b7\u0018\u00002\u00020\u0001:\u0003\b\t\nB\u0012\b\u0004\u0012\u0006\u0010\u0002\u001a\u00020\u0003ø\u0001\u0000¢\u0006\u0002\u0010\u0004R\u001c\u0010\u0002\u001a\u00020\u0003ø\u0001\u0000ø\u0001\u0001ø\u0001\u0002¢\u0006\n\n\u0002\u0010\u0007\u001a\u0004\b\u0005\u0010\u0006\u0082\u0001\u0003\u000b\f\r\u0082\u0002\u000f\n\u0002\b\u0019\n\u0005\b¡\u001e0\u0001\n\u0002\b!¨\u0006\u000e"}, d2 = {"Lvea/raceremote/ui/views/DotsState;", "", "height", "Landroidx/compose/ui/unit/Dp;", "(F)V", "getHeight-D9Ej5fM", "()F", "F", "Idle", "Loading", "ShowText", "Lvea/raceremote/ui/views/DotsState$Idle;", "Lvea/raceremote/ui/views/DotsState$Loading;", "Lvea/raceremote/ui/views/DotsState$ShowText;", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public abstract class DotsState {
    public static final int $stable = LiveLiterals$FlatLoadingWithContentKt.INSTANCE.m6915Int$classDotsState();
    private final float height;

    private DotsState(float height) {
        this.height = height;
    }

    /* JADX INFO: renamed from: getHeight-D9Ej5fM, reason: not valid java name and from getter */
    public final float getHeight() {
        return this.height;
    }

    /* JADX INFO: compiled from: FlatLoadingWithContent.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0012\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003ø\u0001\u0000¢\u0006\u0002\u0010\u0004\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u0005"}, d2 = {"Lvea/raceremote/ui/views/DotsState$Idle;", "Lvea/raceremote/ui/views/DotsState;", "height", "Landroidx/compose/ui/unit/Dp;", "(FLkotlin/jvm/internal/DefaultConstructorMarker;)V", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class Idle extends DotsState {
        public static final int $stable = LiveLiterals$FlatLoadingWithContentKt.INSTANCE.m6916Int$classIdle$classDotsState();

        private Idle(float height) {
            super(height);
        }
    }

    /* JADX INFO: compiled from: FlatLoadingWithContent.kt */
    @Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\f\b\u0007\u0018\u00002\u00020\u0001B<\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0007\u0012\b\b\u0002\u0010\b\u001a\u00020\u0003\u0012\b\b\u0002\u0010\t\u001a\u00020\u0005ø\u0001\u0000¢\u0006\u0002\u0010\nR\u0011\u0010\t\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u001c\u0010\u0006\u001a\u0004\u0018\u00010\u0007ø\u0001\u0000ø\u0001\u0001ø\u0001\u0002¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\fR\u001c\u0010\b\u001a\u00020\u0003ø\u0001\u0000ø\u0001\u0001ø\u0001\u0002¢\u0006\n\n\u0002\u0010\u0012\u001a\u0004\b\u0010\u0010\u0011\u0082\u0002\u000f\n\u0002\b\u0019\n\u0005\b¡\u001e0\u0001\n\u0002\b!¨\u0006\u0013"}, d2 = {"Lvea/raceremote/ui/views/DotsState$Loading;", "Lvea/raceremote/ui/views/DotsState;", "height", "Landroidx/compose/ui/unit/Dp;", "dotsCount", "", "dotsColor", "Landroidx/compose/ui/graphics/Color;", "dotsDividerSpace", "dotsAnimationDuration", "(FILandroidx/compose/ui/graphics/Color;FILkotlin/jvm/internal/DefaultConstructorMarker;)V", "getDotsAnimationDuration", "()I", "getDotsColor-QN2ZGVo", "()Landroidx/compose/ui/graphics/Color;", "getDotsCount", "getDotsDividerSpace-D9Ej5fM", "()F", "F", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class Loading extends DotsState {
        public static final int $stable = LiveLiterals$FlatLoadingWithContentKt.INSTANCE.m6917Int$classLoading$classDotsState();
        private final int dotsAnimationDuration;
        private final Color dotsColor;
        private final int dotsCount;
        private final float dotsDividerSpace;

        /* JADX WARN: Illegal instructions before constructor call */
        public /* synthetic */ Loading(float f, int i, Color color, float f2, int i2, int i3, DefaultConstructorMarker defaultConstructorMarker) {
            float fM4046constructorimpl;
            float fM4046constructorimpl2 = (i3 & 1) != 0 ? Dp.m4046constructorimpl(6) : f;
            int i4 = (i3 & 2) != 0 ? 3 : i;
            Color color2 = (i3 & 4) != 0 ? null : color;
            if ((i3 & 8) != 0) {
                int $this$dp$iv = LiveLiterals$FlatLoadingWithContentKt.INSTANCE.m6907Int$$$this$call$getdp$$paramdotsDividerSpace$classLoading$classDotsState();
                fM4046constructorimpl = Dp.m4046constructorimpl($this$dp$iv);
            } else {
                fM4046constructorimpl = f2;
            }
            this(fM4046constructorimpl2, i4, color2, fM4046constructorimpl, (i3 & 16) != 0 ? 1500 : i2);
        }

        public final int getDotsCount() {
            return this.dotsCount;
        }

        /* JADX INFO: renamed from: getDotsColor-QN2ZGVo, reason: not valid java name and from getter */
        public final Color getDotsColor() {
            return this.dotsColor;
        }

        /* JADX INFO: renamed from: getDotsDividerSpace-D9Ej5fM, reason: not valid java name and from getter */
        public final float getDotsDividerSpace() {
            return this.dotsDividerSpace;
        }

        public final int getDotsAnimationDuration() {
            return this.dotsAnimationDuration;
        }

        private Loading(float height, int dotsCount, Color dotsColor, float dotsDividerSpace, int dotsAnimationDuration) {
            super(height);
            this.dotsCount = dotsCount;
            this.dotsColor = dotsColor;
            this.dotsDividerSpace = dotsDividerSpace;
            this.dotsAnimationDuration = dotsAnimationDuration;
        }
    }

    /* JADX INFO: compiled from: FlatLoadingWithContent.kt */
    @Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u000e\b\u0007\u0018\u00002\u00020\u0001B6\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u0012\b\b\u0002\u0010\b\u001a\u00020\u0005\u0012\b\b\u0002\u0010\t\u001a\u00020\u0005ø\u0001\u0000¢\u0006\u0002\u0010\nR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u001c\u0010\u0004\u001a\u00020\u0005ø\u0001\u0000ø\u0001\u0001ø\u0001\u0002¢\u0006\n\n\u0002\u0010\u0011\u001a\u0004\b\u000f\u0010\u0010R\u001c\u0010\b\u001a\u00020\u0005ø\u0001\u0000ø\u0001\u0001ø\u0001\u0002¢\u0006\n\n\u0002\u0010\u0011\u001a\u0004\b\u0012\u0010\u0010R\u0011\u0010\u0013\u001a\u00020\u00038F¢\u0006\u0006\u001a\u0004\b\u0014\u0010\f\u0082\u0002\u000f\n\u0002\b\u0019\n\u0005\b¡\u001e0\u0001\n\u0002\b!¨\u0006\u0015"}, d2 = {"Lvea/raceremote/ui/views/DotsState$ShowText;", "Lvea/raceremote/ui/views/DotsState;", "text", "", "textSize", "Landroidx/compose/ui/unit/Dp;", "textMaxLength", "", "textVelocity", "height", "(Ljava/lang/String;FIFFLkotlin/jvm/internal/DefaultConstructorMarker;)V", "getText", "()Ljava/lang/String;", "getTextMaxLength", "()I", "getTextSize-D9Ej5fM", "()F", "F", "getTextVelocity-D9Ej5fM", "truncatedText", "getTruncatedText", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class ShowText extends DotsState {
        public static final int $stable = LiveLiterals$FlatLoadingWithContentKt.INSTANCE.m6918Int$classShowText$classDotsState();
        private final String text;
        private final int textMaxLength;
        private final float textSize;
        private final float textVelocity;

        public final String getText() {
            return this.text;
        }

        /* JADX INFO: renamed from: getTextSize-D9Ej5fM, reason: not valid java name and from getter */
        public final float getTextSize() {
            return this.textSize;
        }

        public final int getTextMaxLength() {
            return this.textMaxLength;
        }

        /* JADX INFO: renamed from: getTextVelocity-D9Ej5fM, reason: not valid java name and from getter */
        public final float getTextVelocity() {
            return this.textVelocity;
        }

        private ShowText(String text, float textSize, int textMaxLength, float textVelocity, float height) {
            super(height);
            this.text = text;
            this.textSize = textSize;
            this.textMaxLength = textMaxLength;
            this.textVelocity = textVelocity;
        }

        public final String getTruncatedText() {
            return this.text.length() <= this.textMaxLength ? this.text : StringsKt.take(this.text, this.textMaxLength) + LiveLiterals$FlatLoadingWithContentKt.INSTANCE.m6921String$1$str$else$if$fun$gettruncatedText$$get$valtruncatedText$classShowText$classDotsState();
        }
    }
}
