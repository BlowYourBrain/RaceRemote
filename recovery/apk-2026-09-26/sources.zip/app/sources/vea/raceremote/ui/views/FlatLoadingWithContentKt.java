package vea.raceremote.ui.views;

import androidx.compose.animation.CrossfadeKt;
import androidx.compose.animation.core.AnimationSpecKt;
import androidx.compose.animation.core.EasingKt;
import androidx.compose.animation.core.FiniteAnimationSpec;
import androidx.compose.animation.core.InfiniteRepeatableSpec;
import androidx.compose.animation.core.InfiniteTransition;
import androidx.compose.animation.core.InfiniteTransitionKt;
import androidx.compose.animation.core.KeyframesSpec;
import androidx.compose.animation.core.RepeatMode;
import androidx.compose.animation.core.StartOffset;
import androidx.compose.animation.core.Transition;
import androidx.compose.animation.core.TransitionKt;
import androidx.compose.animation.core.VectorConvertersKt;
import androidx.compose.foundation.BackgroundKt;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.foundation.layout.OffsetKt;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.layout.SpacerKt;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.material.MaterialTheme;
import androidx.compose.material.TextKt;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.ProvidableCompositionLocal;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.SkippableUpdater;
import androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt;
import androidx.compose.runtime.State;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.draw.ClipKt;
import androidx.compose.ui.draw.ScaleKt;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.layout.LayoutCoordinates;
import androidx.compose.ui.layout.LayoutKt;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.layout.OnGloballyPositionedModifierKt;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.platform.CompositionLocalsKt;
import androidx.compose.ui.platform.ViewConfiguration;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.unit.Density;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.unit.IntSize;
import androidx.compose.ui.unit.LayoutDirection;
import androidx.compose.ui.unit.TextUnitKt;
import androidx.compose.ui.unit.TextUnitType;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import vea.raceremote.utils.ComposeUtilsKt;

/* JADX INFO: compiled from: FlatLoadingWithContent.kt */
/* JADX INFO: loaded from: classes9.dex */
@Metadata(d1 = {"\u0000<\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a\u001f\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rH\u0007¢\u0006\u0002\u0010\u000e\u001a\u0015\u0010\u000f\u001a\u00020\t2\u0006\u0010\f\u001a\u00020\u0010H\u0003¢\u0006\u0002\u0010\u0011\u001a\u0015\u0010\u0012\u001a\u00020\t2\u0006\u0010\f\u001a\u00020\u0013H\u0003¢\u0006\u0002\u0010\u0014\u001a\u0015\u0010\u0015\u001a\u00020\t2\u0006\u0010\f\u001a\u00020\u0016H\u0003¢\u0006\u0002\u0010\u0017\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0003\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0004\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0005\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0006\u001a\u00020\u0007X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0018"}, d2 = {"DEFAULT_ANIMATION_DURATION", "", "DEFAULT_DOTS_COUNT", "DEFAULT_HEIGHT", "TEXT_MAX_LENGTH", "TEXT_MAX_LINES", "TEXT_SPEED", "", "FlatLoadingWithContent", "", "modifier", "Landroidx/compose/ui/Modifier;", "state", "Lvea/raceremote/ui/views/DotsState;", "(Landroidx/compose/ui/Modifier;Lvea/raceremote/ui/views/DotsState;Landroidx/compose/runtime/Composer;II)V", "addEmptySpace", "Lvea/raceremote/ui/views/DotsState$Idle;", "(Lvea/raceremote/ui/views/DotsState$Idle;Landroidx/compose/runtime/Composer;I)V", "addLoadingDots", "Lvea/raceremote/ui/views/DotsState$Loading;", "(Lvea/raceremote/ui/views/DotsState$Loading;Landroidx/compose/runtime/Composer;I)V", "addText", "Lvea/raceremote/ui/views/DotsState$ShowText;", "(Lvea/raceremote/ui/views/DotsState$ShowText;Landroidx/compose/runtime/Composer;I)V", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class FlatLoadingWithContentKt {
    private static final int DEFAULT_ANIMATION_DURATION = 1500;
    private static final int DEFAULT_DOTS_COUNT = 3;
    private static final int DEFAULT_HEIGHT = 6;
    private static final int TEXT_MAX_LENGTH = 32;
    private static final int TEXT_MAX_LINES = 1;
    private static final float TEXT_SPEED = 0.024f;

    public static final void FlatLoadingWithContent(Modifier modifier, final DotsState state, Composer $composer, final int $changed, final int i) {
        final Modifier modifier2;
        Intrinsics.checkNotNullParameter(state, "state");
        Composer $composer2 = $composer.startRestartGroup(-367210347);
        ComposerKt.sourceInformation($composer2, "C(FlatLoadingWithContent)101@3912L23,103@3941L403:FlatLoadingWithContent.kt#4usob5");
        int $dirty = $changed;
        int i2 = i & 1;
        if (i2 != 0) {
            $dirty |= 6;
            modifier2 = modifier;
        } else if (($changed & 14) == 0) {
            modifier2 = modifier;
            $dirty |= $composer2.changed(modifier2) ? 4 : 2;
        } else {
            modifier2 = modifier;
        }
        if ((i & 2) != 0) {
            $dirty |= 48;
        } else if (($changed & 112) == 0) {
            $dirty |= $composer2.changed(state) ? 32 : 16;
        }
        if (($dirty & 91) == 18 && $composer2.getSkipping()) {
            $composer2.skipToGroupEnd();
        } else {
            Modifier.Companion modifier3 = i2 != 0 ? Modifier.INSTANCE : modifier2;
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-367210347, $dirty, -1, "vea.raceremote.ui.views.FlatLoadingWithContent (FlatLoadingWithContent.kt:97)");
            }
            Transition transition = TransitionKt.updateTransition(state, (String) null, $composer2, ($dirty >> 3) & 14, 2);
            Modifier modifier$iv = ClipKt.clipToBounds(modifier3);
            Alignment contentAlignment$iv = Alignment.INSTANCE.getCenter();
            $composer2.startReplaceableGroup(733328855);
            ComposerKt.sourceInformation($composer2, "C(Box)P(2,1,3)70@3267L67,71@3339L130:Box.kt#2w3rfo");
            MeasurePolicy measurePolicy$iv = BoxKt.rememberBoxMeasurePolicy(contentAlignment$iv, false, $composer2, ((48 >> 3) & 14) | ((48 >> 3) & 112));
            int $changed$iv$iv = (48 << 3) & 112;
            $composer2.startReplaceableGroup(-1323940314);
            ComposerKt.sourceInformation($composer2, "C(Layout)P(!1,2)74@2915L7,75@2970L7,76@3029L7,77@3041L460:Layout.kt#80mrfh");
            ProvidableCompositionLocal<Density> localDensity = CompositionLocalsKt.getLocalDensity();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume = $composer2.consume(localDensity);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            Density density$iv$iv = (Density) objConsume;
            ProvidableCompositionLocal<LayoutDirection> localLayoutDirection = CompositionLocalsKt.getLocalLayoutDirection();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume2 = $composer2.consume(localLayoutDirection);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            LayoutDirection layoutDirection$iv$iv = (LayoutDirection) objConsume2;
            ProvidableCompositionLocal<ViewConfiguration> localViewConfiguration = CompositionLocalsKt.getLocalViewConfiguration();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume3 = $composer2.consume(localViewConfiguration);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ViewConfiguration viewConfiguration$iv$iv = (ViewConfiguration) objConsume3;
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            Function3<SkippableUpdater<ComposeUiNode>, Composer, Integer, Unit> function3MaterializerOf = LayoutKt.materializerOf(modifier$iv);
            int $changed$iv$iv$iv = (($changed$iv$iv << 9) & 7168) | 6;
            Modifier modifier4 = modifier3;
            if (!($composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer2.startReusableNode();
            if ($composer2.getInserting()) {
                $composer2.createNode(constructor);
            } else {
                $composer2.useNode();
            }
            $composer2.disableReusing();
            Composer $this$Layout_u24lambda_u2d0$iv$iv = Updater.m1304constructorimpl($composer2);
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, measurePolicy$iv, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, density$iv$iv, ComposeUiNode.INSTANCE.getSetDensity());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, layoutDirection$iv$iv, ComposeUiNode.INSTANCE.getSetLayoutDirection());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, viewConfiguration$iv$iv, ComposeUiNode.INSTANCE.getSetViewConfiguration());
            $composer2.enableReusing();
            function3MaterializerOf.invoke(SkippableUpdater.m1294boximpl(SkippableUpdater.m1295constructorimpl($composer2)), $composer2, Integer.valueOf(($changed$iv$iv$iv >> 3) & 112));
            $composer2.startReplaceableGroup(2058660585);
            int $changed$iv = ($changed$iv$iv$iv >> 9) & 14;
            $composer2.startReplaceableGroup(-2137368960);
            ComposerKt.sourceInformation($composer2, "C72@3384L9:Box.kt#2w3rfo");
            if (($changed$iv & 11) == 2 && $composer2.getSkipping()) {
                $composer2.skipToGroupEnd();
            } else {
                BoxScopeInstance boxScopeInstance = BoxScopeInstance.INSTANCE;
                int i3 = ((48 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart($composer2, 566890500, "C107@4061L277:FlatLoadingWithContent.kt#4usob5");
                CrossfadeKt.Crossfade(transition, (Modifier) null, (FiniteAnimationSpec<Float>) null, (Function1) null, ComposableSingletons$FlatLoadingWithContentKt.INSTANCE.m6893getLambda1$app_debug(), $composer2, 24576, 7);
                ComposerKt.sourceInformationMarkerEnd($composer2);
            }
            $composer2.endReplaceableGroup();
            $composer2.endReplaceableGroup();
            $composer2.endNode();
            $composer2.endReplaceableGroup();
            $composer2.endReplaceableGroup();
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
            modifier2 = modifier4;
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.ui.views.FlatLoadingWithContentKt.FlatLoadingWithContent.2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i4) {
                FlatLoadingWithContentKt.FlatLoadingWithContent(modifier2, state, composer, $changed | 1, i);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void addEmptySpace(final DotsState.Idle state, Composer $composer, final int $changed) {
        Composer $composer2 = $composer.startRestartGroup(-1312018679);
        ComposerKt.sourceInformation($composer2, "C(addEmptySpace)119@4415L48:FlatLoadingWithContent.kt#4usob5");
        int $dirty = $changed;
        if (($changed & 14) == 0) {
            $dirty |= $composer2.changed(state) ? 4 : 2;
        }
        if (($dirty & 11) != 2 || !$composer2.getSkipping()) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1312018679, $changed, -1, "vea.raceremote.ui.views.addEmptySpace (FlatLoadingWithContent.kt:118)");
            }
            SpacerKt.Spacer(SizeKt.m454height3ABfNKs(Modifier.INSTANCE, state.getHeight()), $composer2, 0);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            $composer2.skipToGroupEnd();
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.ui.views.FlatLoadingWithContentKt.addEmptySpace.1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i) {
                FlatLoadingWithContentKt.addEmptySpace(state, composer, $changed | 1);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code duplicated, block: B:47:0x03af  */
    /* JADX WARN: Code duplicated, block: B:50:0x03bb  */
    /* JADX WARN: Code duplicated, block: B:51:0x03c1  */
    /* JADX WARN: Code duplicated, block: B:58:0x0443  */
    /* JADX WARN: Code duplicated, block: B:61:0x0480  */
    /* JADX WARN: Code duplicated, block: B:62:0x0491  */
    public static final void addLoadingDots(final DotsState.Loading state, Composer $composer, final int $changed) {
        Composer $composer2;
        Composer $composer$iv;
        MeasurePolicy measurePolicy$iv;
        Composer $composer3;
        Function0<ComposeUiNode> constructor;
        Function0<ComposeUiNode> function0;
        int $changed$iv;
        Composer $composer4 = $composer.startRestartGroup(693043744);
        ComposerKt.sourceInformation($composer4, "C(addLoadingDots)*126@4573L28,130@4736L1335:FlatLoadingWithContent.kt#4usob5");
        int $dirty = $changed;
        if (($changed & 14) == 0) {
            $dirty |= $composer4.changed(state) ? 4 : 2;
        }
        if (($dirty & 11) != 2 || !$composer4.getSkipping()) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(693043744, $changed, -1, "vea.raceremote.ui.views.addLoadingDots (FlatLoadingWithContent.kt:123)");
            }
            InfiniteTransition transition = InfiniteTransitionKt.rememberInfiniteTransition($composer4, 0);
            final int totalAnimationDuration = (state.getDotsAnimationDuration() * state.getDotsCount()) / LiveLiterals$FlatLoadingWithContentKt.INSTANCE.m6912Int$arg0$calldiv$valtotalAnimationDuration$fun$anonymous$$arg0$callrun$funaddLoadingDots();
            Color dotsColor = state.getDotsColor();
            $composer4.startReplaceableGroup(1955018413);
            ComposerKt.sourceInformation($composer4, "128@4716L6");
            long jM981getPrimary0d7_KjU = dotsColor == null ? MaterialTheme.INSTANCE.getColors($composer4, MaterialTheme.$stable).m981getPrimary0d7_KjU() : dotsColor.m1671unboximpl();
            $composer4.endReplaceableGroup();
            long color = jM981getPrimary0d7_KjU;
            Modifier modifier$iv = SizeKt.m454height3ABfNKs(Modifier.INSTANCE, state.getHeight());
            Arrangement.Horizontal horizontalArrangement$iv = Arrangement.INSTANCE.getSpaceAround();
            Alignment.Vertical verticalAlignment$iv = Alignment.INSTANCE.getBottom();
            $composer4.startReplaceableGroup(693286680);
            ComposerKt.sourceInformation($composer4, "C(Row)P(2,1,3)78@3880L58,79@3943L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicy$iv2 = RowKt.rowMeasurePolicy(horizontalArrangement$iv, verticalAlignment$iv, $composer4, ((432 >> 3) & 14) | ((432 >> 3) & 112));
            int $changed$iv$iv = (432 << 3) & 112;
            $composer4.startReplaceableGroup(-1323940314);
            String str = "C(Layout)P(!1,2)74@2915L7,75@2970L7,76@3029L7,77@3041L460:Layout.kt#80mrfh";
            ComposerKt.sourceInformation($composer4, "C(Layout)P(!1,2)74@2915L7,75@2970L7,76@3029L7,77@3041L460:Layout.kt#80mrfh");
            ProvidableCompositionLocal<Density> localDensity = CompositionLocalsKt.getLocalDensity();
            String str2 = "C:CompositionLocal.kt#9igjgp";
            ComposerKt.sourceInformationMarkerStart($composer4, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume = $composer4.consume(localDensity);
            ComposerKt.sourceInformationMarkerEnd($composer4);
            Density density$iv$iv = (Density) objConsume;
            ProvidableCompositionLocal<LayoutDirection> localLayoutDirection = CompositionLocalsKt.getLocalLayoutDirection();
            ComposerKt.sourceInformationMarkerStart($composer4, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume2 = $composer4.consume(localLayoutDirection);
            ComposerKt.sourceInformationMarkerEnd($composer4);
            LayoutDirection layoutDirection$iv$iv = (LayoutDirection) objConsume2;
            ProvidableCompositionLocal<ViewConfiguration> localViewConfiguration = CompositionLocalsKt.getLocalViewConfiguration();
            ComposerKt.sourceInformationMarkerStart($composer4, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume3 = $composer4.consume(localViewConfiguration);
            ComposerKt.sourceInformationMarkerEnd($composer4);
            ViewConfiguration viewConfiguration$iv$iv = (ViewConfiguration) objConsume3;
            Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            int $changed$iv$iv$iv = (($changed$iv$iv << 9) & 7168) | 6;
            Function3<SkippableUpdater<ComposeUiNode>, Composer, Integer, Unit> function3MaterializerOf = LayoutKt.materializerOf(modifier$iv);
            long color2 = color;
            if (!($composer4.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer4.startReusableNode();
            if ($composer4.getInserting()) {
                $composer4.createNode(constructor2);
            } else {
                $composer4.useNode();
            }
            $composer4.disableReusing();
            Composer $this$Layout_u24lambda_u2d0$iv$iv = Updater.m1304constructorimpl($composer4);
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, measurePolicy$iv2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, density$iv$iv, ComposeUiNode.INSTANCE.getSetDensity());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, layoutDirection$iv$iv, ComposeUiNode.INSTANCE.getSetLayoutDirection());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, viewConfiguration$iv$iv, ComposeUiNode.INSTANCE.getSetViewConfiguration());
            $composer4.enableReusing();
            function3MaterializerOf.invoke(SkippableUpdater.m1294boximpl(SkippableUpdater.m1295constructorimpl($composer4)), $composer4, Integer.valueOf(($changed$iv$iv$iv >> 3) & 112));
            $composer4.startReplaceableGroup(2058660585);
            int $changed$iv2 = ($changed$iv$iv$iv >> 9) & 14;
            Composer $composer$iv2 = $composer4;
            $composer$iv2.startReplaceableGroup(-678309503);
            ComposerKt.sourceInformation($composer$iv2, "C80@3988L9:Row.kt#2w3rfo");
            if (($changed$iv2 & 11) == 2 && $composer$iv2.getSkipping()) {
                $composer$iv2.skipToGroupEnd();
                $composer2 = $composer4;
                $composer$iv = $composer$iv2;
            } else {
                RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                int i = ((432 >> 6) & 112) | 6;
                Composer $composer5 = $composer$iv2;
                ComposerKt.sourceInformationMarkerStart($composer5, -669663669, "C:FlatLoadingWithContent.kt#4usob5");
                $composer4.startReplaceableGroup(1955018633);
                ComposerKt.sourceInformation($composer4, "*140@5154L344,136@4977L698,152@5689L271,162@6004L51");
                int dotsCount = state.getDotsCount();
                int i2 = 0;
                while (i2 < dotsCount) {
                    int position = i2;
                    float fM6905Float$arg0$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots = LiveLiterals$FlatLoadingWithContentKt.INSTANCE.m6905Float$arg0$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots();
                    float fM6906Float$arg1$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots = LiveLiterals$FlatLoadingWithContentKt.INSTANCE.m6906Float$arg1$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots();
                    Object key1$iv = Integer.valueOf(totalAnimationDuration);
                    Density density$iv$iv2 = density$iv$iv;
                    $composer5.startReplaceableGroup(511388516);
                    ComposerKt.sourceInformation($composer5, "C(remember)P(1,2):Composables.kt#9igjgp");
                    boolean invalid$iv$iv = $composer5.changed(key1$iv) | $composer5.changed(state);
                    Composer $this$cache$iv$iv = $composer5;
                    Object value$iv$iv = $this$cache$iv$iv.rememberedValue();
                    if (!invalid$iv$iv) {
                        measurePolicy$iv = measurePolicy$iv2;
                        if (value$iv$iv == Composer.INSTANCE.getEmpty()) {
                        }
                        $composer5.endReplaceableGroup();
                        KeyframesSpec keyframesSpecKeyframes = AnimationSpecKt.keyframes((Function1) value$iv$iv);
                        RepeatMode repeatMode = RepeatMode.Restart;
                        int totalAnimationDuration2 = totalAnimationDuration;
                        int i3 = dotsCount;
                        int dotsAnimationDuration = (position * state.getDotsAnimationDuration()) / LiveLiterals$FlatLoadingWithContentKt.INSTANCE.m6909Int$arg0$calldiv$arg0$call$init$$arg2$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots();
                        Function3<SkippableUpdater<ComposeUiNode>, Composer, Integer, Unit> function3 = function3MaterializerOf;
                        Composer $composer$iv3 = $composer$iv2;
                        InfiniteTransition infiniteTransition = transition;
                        MeasurePolicy measurePolicy$iv3 = measurePolicy$iv;
                        InfiniteTransition transition2 = transition;
                        long color3 = color2;
                        Composer $composer6 = $composer4;
                        $composer3 = $composer5;
                        Modifier modifierScale = ScaleKt.scale(SizeKt.m468size3ABfNKs(Modifier.INSTANCE, state.getHeight()), addLoadingDots$lambda$6$lambda$5$lambda$4$lambda$2(InfiniteTransitionKt.animateFloat(infiniteTransition, fM6905Float$arg0$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots, fM6906Float$arg1$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots, AnimationSpecKt.m116infiniteRepeatable9IiC70o(keyframesSpecKeyframes, repeatMode, StartOffset.m138constructorimpl$default(dotsAnimationDuration, 0, 2, null)), $composer5, InfiniteTransition.$stable | (InfiniteRepeatableSpec.$stable << 9))));
                        float arg0$iv = state.getHeight();
                        int other$iv = LiveLiterals$FlatLoadingWithContentKt.INSTANCE.m6910Int$arg0$calldiv$arg0$callRoundedCornerShape$arg1$callbackground$arg0$callBox$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots();
                        Modifier modifier$iv2 = BackgroundKt.m179backgroundbw27NRU(modifierScale, color3, RoundedCornerShapeKt.m677RoundedCornerShape0680j_4(Dp.m4046constructorimpl(arg0$iv / other$iv)));
                        $composer3.startReplaceableGroup(733328855);
                        ComposerKt.sourceInformation($composer3, "C(Box)P(2,1,3)70@3267L67,71@3339L130:Box.kt#2w3rfo");
                        Alignment contentAlignment$iv = Alignment.INSTANCE.getTopStart();
                        MeasurePolicy measurePolicy$iv4 = BoxKt.rememberBoxMeasurePolicy(contentAlignment$iv, false, $composer3, ((0 >> 3) & 14) | ((0 >> 3) & 112));
                        int $changed$iv$iv2 = (0 << 3) & 112;
                        $composer3.startReplaceableGroup(-1323940314);
                        ComposerKt.sourceInformation($composer3, str);
                        ProvidableCompositionLocal<Density> localDensity2 = CompositionLocalsKt.getLocalDensity();
                        ComposerKt.sourceInformationMarkerStart($composer3, 2023513938, str2);
                        Object objConsume4 = $composer3.consume(localDensity2);
                        ComposerKt.sourceInformationMarkerEnd($composer3);
                        Density density$iv$iv3 = (Density) objConsume4;
                        ProvidableCompositionLocal<LayoutDirection> localLayoutDirection2 = CompositionLocalsKt.getLocalLayoutDirection();
                        String str3 = str;
                        ComposerKt.sourceInformationMarkerStart($composer3, 2023513938, str2);
                        Object objConsume5 = $composer3.consume(localLayoutDirection2);
                        ComposerKt.sourceInformationMarkerEnd($composer3);
                        LayoutDirection layoutDirection$iv$iv2 = (LayoutDirection) objConsume5;
                        ProvidableCompositionLocal<ViewConfiguration> localViewConfiguration2 = CompositionLocalsKt.getLocalViewConfiguration();
                        ComposerKt.sourceInformationMarkerStart($composer3, 2023513938, str2);
                        Object objConsume6 = $composer3.consume(localViewConfiguration2);
                        ComposerKt.sourceInformationMarkerEnd($composer3);
                        ViewConfiguration viewConfiguration$iv$iv2 = (ViewConfiguration) objConsume6;
                        constructor = ComposeUiNode.INSTANCE.getConstructor();
                        Function3<SkippableUpdater<ComposeUiNode>, Composer, Integer, Unit> function3MaterializerOf2 = LayoutKt.materializerOf(modifier$iv2);
                        int $changed$iv$iv$iv2 = (($changed$iv$iv2 << 9) & 7168) | 6;
                        String str4 = str2;
                        if (!($composer3.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
                        $composer3.startReusableNode();
                        if ($composer3.getInserting()) {
                            function0 = constructor;
                            $composer3.createNode(function0);
                        } else {
                            function0 = constructor;
                            $composer3.useNode();
                        }
                        $composer3.disableReusing();
                        Composer $this$Layout_u24lambda_u2d0$iv$iv2 = Updater.m1304constructorimpl($composer3);
                        Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv2, measurePolicy$iv4, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                        Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv2, density$iv$iv3, ComposeUiNode.INSTANCE.getSetDensity());
                        Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv2, layoutDirection$iv$iv2, ComposeUiNode.INSTANCE.getSetLayoutDirection());
                        Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv2, viewConfiguration$iv$iv2, ComposeUiNode.INSTANCE.getSetViewConfiguration());
                        $composer3.enableReusing();
                        function3MaterializerOf2.invoke(SkippableUpdater.m1294boximpl(SkippableUpdater.m1295constructorimpl($composer3)), $composer3, Integer.valueOf(($changed$iv$iv$iv2 >> 3) & 112));
                        $composer3.startReplaceableGroup(2058660585);
                        $changed$iv = ($changed$iv$iv$iv2 >> 9) & 14;
                        $composer3.startReplaceableGroup(-2137368960);
                        ComposerKt.sourceInformation($composer3, "C72@3384L9:Box.kt#2w3rfo");
                        if (($changed$iv & 11) == 2 || !$composer3.getSkipping()) {
                            BoxScopeInstance boxScopeInstance = BoxScopeInstance.INSTANCE;
                            int i4 = ((0 >> 6) & 112) | 6;
                            ComposerKt.sourceInformationMarkerStart($composer3, 1720492839, "C:FlatLoadingWithContent.kt#4usob5");
                            ComposerKt.sourceInformationMarkerEnd($composer3);
                        } else {
                            $composer3.skipToGroupEnd();
                        }
                        $composer3.endReplaceableGroup();
                        $composer3.endReplaceableGroup();
                        $composer3.endNode();
                        $composer3.endReplaceableGroup();
                        $composer3.endReplaceableGroup();
                        if (position < state.getDotsCount() - LiveLiterals$FlatLoadingWithContentKt.INSTANCE.m6913Int$arg0$callminus$arg1$callless$cond$if$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots()) {
                            SpacerKt.Spacer(SizeKt.m473width3ABfNKs(Modifier.INSTANCE, state.getDotsDividerSpace()), $composer3, 0);
                        }
                        i2++;
                        $composer5 = $composer3;
                        density$iv$iv = density$iv$iv2;
                        $composer$iv2 = $composer$iv3;
                        $composer4 = $composer6;
                        function3MaterializerOf = function3;
                        dotsCount = i3;
                        measurePolicy$iv2 = measurePolicy$iv3;
                        str = str3;
                        str2 = str4;
                        color2 = color3;
                        transition = transition2;
                        totalAnimationDuration = totalAnimationDuration2;
                    } else {
                        measurePolicy$iv = measurePolicy$iv2;
                    }
                    value$iv$iv = (Function1) new Function1<KeyframesSpec.KeyframesSpecConfig<Float>, Unit>() { // from class: vea.raceremote.ui.views.FlatLoadingWithContentKt$addLoadingDots$1$1$1$scale$2$1
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(1);
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public /* bridge */ /* synthetic */ Unit invoke(KeyframesSpec.KeyframesSpecConfig<Float> keyframesSpecConfig) {
                            invoke2(keyframesSpecConfig);
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2(KeyframesSpec.KeyframesSpecConfig<Float> keyframesSpecConfig) {
                            Intrinsics.checkNotNullParameter(keyframesSpecConfig, "$this$keyframes");
                            keyframesSpecConfig.setDurationMillis(totalAnimationDuration);
                            keyframesSpecConfig.with(keyframesSpecConfig.at(Float.valueOf(LiveLiterals$FlatLoadingWithContentKt.INSTANCE.m6901Float$$$this$callat$$$this$callwith$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots()), LiveLiterals$FlatLoadingWithContentKt.INSTANCE.m6908Int$arg0$callat$$$this$callwith$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots()), EasingKt.getLinearEasing());
                            keyframesSpecConfig.with(keyframesSpecConfig.at(Float.valueOf(LiveLiterals$FlatLoadingWithContentKt.INSTANCE.m6902Float$$$this$callat$$$this$callwith1$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots()), state.getDotsAnimationDuration() / LiveLiterals$FlatLoadingWithContentKt.INSTANCE.m6911Int$arg0$calldiv$arg0$callat$$$this$callwith1$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots()), EasingKt.getLinearEasing());
                            keyframesSpecConfig.with(keyframesSpecConfig.at(Float.valueOf(LiveLiterals$FlatLoadingWithContentKt.INSTANCE.m6903Float$$$this$callat$$$this$callwith2$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots()), state.getDotsAnimationDuration()), EasingKt.getLinearEasing());
                            keyframesSpecConfig.at(Float.valueOf(LiveLiterals$FlatLoadingWithContentKt.INSTANCE.m6904Float$$$this$callat$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots()), totalAnimationDuration);
                        }
                    };
                    $this$cache$iv$iv.updateRememberedValue(value$iv$iv);
                    $composer5.endReplaceableGroup();
                    KeyframesSpec keyframesSpecKeyframes2 = AnimationSpecKt.keyframes((Function1) value$iv$iv);
                    RepeatMode repeatMode2 = RepeatMode.Restart;
                    int totalAnimationDuration3 = totalAnimationDuration;
                    int i5 = dotsCount;
                    int dotsAnimationDuration2 = (position * state.getDotsAnimationDuration()) / LiveLiterals$FlatLoadingWithContentKt.INSTANCE.m6909Int$arg0$calldiv$arg0$call$init$$arg2$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots();
                    Function3<SkippableUpdater<ComposeUiNode>, Composer, Integer, Unit> function4 = function3MaterializerOf;
                    Composer $composer$iv4 = $composer$iv2;
                    InfiniteTransition infiniteTransition2 = transition;
                    MeasurePolicy measurePolicy$iv5 = measurePolicy$iv;
                    InfiniteTransition transition3 = transition;
                    long color4 = color2;
                    Composer $composer7 = $composer4;
                    $composer3 = $composer5;
                    Modifier modifierScale2 = ScaleKt.scale(SizeKt.m468size3ABfNKs(Modifier.INSTANCE, state.getHeight()), addLoadingDots$lambda$6$lambda$5$lambda$4$lambda$2(InfiniteTransitionKt.animateFloat(infiniteTransition2, fM6905Float$arg0$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots, fM6906Float$arg1$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots, AnimationSpecKt.m116infiniteRepeatable9IiC70o(keyframesSpecKeyframes2, repeatMode2, StartOffset.m138constructorimpl$default(dotsAnimationDuration2, 0, 2, null)), $composer5, InfiniteTransition.$stable | (InfiniteRepeatableSpec.$stable << 9))));
                    float arg0$iv2 = state.getHeight();
                    int other$iv2 = LiveLiterals$FlatLoadingWithContentKt.INSTANCE.m6910Int$arg0$calldiv$arg0$callRoundedCornerShape$arg1$callbackground$arg0$callBox$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots();
                    Modifier modifier$iv3 = BackgroundKt.m179backgroundbw27NRU(modifierScale2, color4, RoundedCornerShapeKt.m677RoundedCornerShape0680j_4(Dp.m4046constructorimpl(arg0$iv2 / other$iv2)));
                    $composer3.startReplaceableGroup(733328855);
                    ComposerKt.sourceInformation($composer3, "C(Box)P(2,1,3)70@3267L67,71@3339L130:Box.kt#2w3rfo");
                    Alignment contentAlignment$iv2 = Alignment.INSTANCE.getTopStart();
                    MeasurePolicy measurePolicy$iv6 = BoxKt.rememberBoxMeasurePolicy(contentAlignment$iv2, false, $composer3, ((0 >> 3) & 14) | ((0 >> 3) & 112));
                    int $changed$iv$iv3 = (0 << 3) & 112;
                    $composer3.startReplaceableGroup(-1323940314);
                    ComposerKt.sourceInformation($composer3, str);
                    ProvidableCompositionLocal<Density> localDensity3 = CompositionLocalsKt.getLocalDensity();
                    ComposerKt.sourceInformationMarkerStart($composer3, 2023513938, str2);
                    Object objConsume7 = $composer3.consume(localDensity3);
                    ComposerKt.sourceInformationMarkerEnd($composer3);
                    Density density$iv$iv4 = (Density) objConsume7;
                    ProvidableCompositionLocal<LayoutDirection> localLayoutDirection3 = CompositionLocalsKt.getLocalLayoutDirection();
                    String str5 = str;
                    ComposerKt.sourceInformationMarkerStart($composer3, 2023513938, str2);
                    Object objConsume8 = $composer3.consume(localLayoutDirection3);
                    ComposerKt.sourceInformationMarkerEnd($composer3);
                    LayoutDirection layoutDirection$iv$iv3 = (LayoutDirection) objConsume8;
                    ProvidableCompositionLocal<ViewConfiguration> localViewConfiguration3 = CompositionLocalsKt.getLocalViewConfiguration();
                    ComposerKt.sourceInformationMarkerStart($composer3, 2023513938, str2);
                    Object objConsume9 = $composer3.consume(localViewConfiguration3);
                    ComposerKt.sourceInformationMarkerEnd($composer3);
                    ViewConfiguration viewConfiguration$iv$iv3 = (ViewConfiguration) objConsume9;
                    constructor = ComposeUiNode.INSTANCE.getConstructor();
                    Function3<SkippableUpdater<ComposeUiNode>, Composer, Integer, Unit> function3MaterializerOf3 = LayoutKt.materializerOf(modifier$iv3);
                    int $changed$iv$iv$iv3 = (($changed$iv$iv3 << 9) & 7168) | 6;
                    String str6 = str2;
                    if (!($composer3.getApplier() instanceof Applier)) {
                        ComposablesKt.invalidApplier();
                    }
                    $composer3.startReusableNode();
                    if ($composer3.getInserting()) {
                        function0 = constructor;
                        $composer3.createNode(function0);
                    } else {
                        function0 = constructor;
                        $composer3.useNode();
                    }
                    $composer3.disableReusing();
                    Composer $this$Layout_u24lambda_u2d0$iv$iv3 = Updater.m1304constructorimpl($composer3);
                    Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv3, measurePolicy$iv6, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv3, density$iv$iv4, ComposeUiNode.INSTANCE.getSetDensity());
                    Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv3, layoutDirection$iv$iv3, ComposeUiNode.INSTANCE.getSetLayoutDirection());
                    Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv3, viewConfiguration$iv$iv3, ComposeUiNode.INSTANCE.getSetViewConfiguration());
                    $composer3.enableReusing();
                    function3MaterializerOf3.invoke(SkippableUpdater.m1294boximpl(SkippableUpdater.m1295constructorimpl($composer3)), $composer3, Integer.valueOf(($changed$iv$iv$iv3 >> 3) & 112));
                    $composer3.startReplaceableGroup(2058660585);
                    $changed$iv = ($changed$iv$iv$iv3 >> 9) & 14;
                    $composer3.startReplaceableGroup(-2137368960);
                    ComposerKt.sourceInformation($composer3, "C72@3384L9:Box.kt#2w3rfo");
                    if (($changed$iv & 11) == 2) {
                        BoxScopeInstance boxScopeInstance2 = BoxScopeInstance.INSTANCE;
                        int i6 = ((0 >> 6) & 112) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer3, 1720492839, "C:FlatLoadingWithContent.kt#4usob5");
                        ComposerKt.sourceInformationMarkerEnd($composer3);
                    } else {
                        BoxScopeInstance boxScopeInstance3 = BoxScopeInstance.INSTANCE;
                        int i7 = ((0 >> 6) & 112) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer3, 1720492839, "C:FlatLoadingWithContent.kt#4usob5");
                        ComposerKt.sourceInformationMarkerEnd($composer3);
                    }
                    $composer3.endReplaceableGroup();
                    $composer3.endReplaceableGroup();
                    $composer3.endNode();
                    $composer3.endReplaceableGroup();
                    $composer3.endReplaceableGroup();
                    if (position < state.getDotsCount() - LiveLiterals$FlatLoadingWithContentKt.INSTANCE.m6913Int$arg0$callminus$arg1$callless$cond$if$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots()) {
                        SpacerKt.Spacer(SizeKt.m473width3ABfNKs(Modifier.INSTANCE, state.getDotsDividerSpace()), $composer3, 0);
                    }
                    i2++;
                    $composer5 = $composer3;
                    density$iv$iv = density$iv$iv2;
                    $composer$iv2 = $composer$iv4;
                    $composer4 = $composer7;
                    function3MaterializerOf = function4;
                    dotsCount = i5;
                    measurePolicy$iv2 = measurePolicy$iv5;
                    str = str5;
                    str2 = str6;
                    color2 = color4;
                    transition = transition3;
                    totalAnimationDuration = totalAnimationDuration3;
                }
                $composer2 = $composer4;
                $composer$iv = $composer$iv2;
                $composer2.endReplaceableGroup();
                ComposerKt.sourceInformationMarkerEnd($composer5);
            }
            $composer$iv.endReplaceableGroup();
            $composer2.endReplaceableGroup();
            $composer2.endNode();
            $composer2.endReplaceableGroup();
            $composer2.endReplaceableGroup();
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            $composer4.skipToGroupEnd();
            $composer2 = $composer4;
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.ui.views.FlatLoadingWithContentKt.addLoadingDots.2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i8) {
                FlatLoadingWithContentKt.addLoadingDots(state, composer, $changed | 1);
            }
        });
    }

    private static final float addLoadingDots$lambda$6$lambda$5$lambda$4$lambda$2(State<Float> state) {
        Object thisObj$iv = state.getValue();
        return ((Number) thisObj$iv).floatValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void addText(final DotsState.ShowText state, Composer $composer, final int $changed) {
        Object value$iv$iv;
        Object value$iv$iv2;
        Composer $composer2;
        Composer $composer3 = $composer.startRestartGroup(-1467021877);
        ComposerKt.sourceInformation($composer3, "C(addText)171@6193L28,173@6240L180,189@6738L8,190@6796L8,188@6674L370,205@7262L482,218@7765L27,200@7050L951:FlatLoadingWithContent.kt#4usob5");
        int $dirty = $changed;
        if (($changed & 14) == 0) {
            $dirty |= $composer3.changed(state) ? 4 : 2;
        }
        if (($dirty & 11) == 2 && $composer3.getSkipping()) {
            $composer3.skipToGroupEnd();
            $composer2 = $composer3;
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1467021877, $changed, -1, "vea.raceremote.ui.views.addText (FlatLoadingWithContent.kt:169)");
            }
            InfiniteTransition transition = InfiniteTransitionKt.rememberInfiniteTransition($composer3, 0);
            $composer3.startReplaceableGroup(-492369756);
            ComposerKt.sourceInformation($composer3, "C(remember):Composables.kt#9igjgp");
            Object it$iv$iv = $composer3.rememberedValue();
            int animationDuration = Integer.MAX_VALUE;
            if (it$iv$iv == Composer.INSTANCE.getEmpty()) {
                value$iv$iv = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(new ViewOffset(Integer.MAX_VALUE, Integer.MAX_VALUE), null, 2, null);
                $composer3.updateRememberedValue(value$iv$iv);
            } else {
                value$iv$iv = it$iv$iv;
            }
            $composer3.endReplaceableGroup();
            final MutableState offset = (MutableState) value$iv$iv;
            $composer3.startReplaceableGroup(-62024541);
            ComposerKt.sourceInformation($composer3, "*185@6595L8");
            if (((ViewOffset) offset.getValue()).getTargetOffset() != Integer.MAX_VALUE) {
                float arg0$iv = ComposeUtilsKt.pxToDp(Math.abs(((ViewOffset) offset.getValue()).getTargetOffset()), $composer3, 0);
                float other$iv = state.getTextVelocity();
                animationDuration = (int) (arg0$iv / other$iv);
            }
            $composer3.endReplaceableGroup();
            State animationOffset$delegate = InfiniteTransitionKt.animateValue(transition, Dp.m4044boximpl(ComposeUtilsKt.pxToDp(((ViewOffset) offset.getValue()).getInitialOffset(), $composer3, 0)), Dp.m4044boximpl(ComposeUtilsKt.pxToDp(((ViewOffset) offset.getValue()).getTargetOffset(), $composer3, 0)), VectorConvertersKt.getVectorConverter(Dp.INSTANCE), AnimationSpecKt.m117infiniteRepeatable9IiC70o$default(AnimationSpecKt.tween$default(animationDuration, 0, EasingKt.getLinearEasing(), 2, null), null, 0L, 6, null), $composer3, InfiniteTransition.$stable | 4096 | (InfiniteRepeatableSpec.$stable << 12));
            Modifier modifierWrapContentWidth = SizeKt.wrapContentWidth(SizeKt.m454height3ABfNKs(OffsetKt.m416offsetVpY3zN4$default(Modifier.INSTANCE, addText$lambda$9(animationOffset$delegate), 0.0f, 2, null), state.getHeight()), Alignment.INSTANCE.getStart(), LiveLiterals$FlatLoadingWithContentKt.INSTANCE.m6900Boolean$arg1$callwrapContentWidth$$$this$callonGloballyPositioned$valtmp2_modifier$funaddText());
            $composer3.startReplaceableGroup(1157296644);
            ComposerKt.sourceInformation($composer3, "C(remember)P(1):Composables.kt#9igjgp");
            boolean invalid$iv$iv = $composer3.changed(offset);
            Object it$iv$iv2 = $composer3.rememberedValue();
            if (invalid$iv$iv || it$iv$iv2 == Composer.INSTANCE.getEmpty()) {
                value$iv$iv2 = new Function1<LayoutCoordinates, Unit>() { // from class: vea.raceremote.ui.views.FlatLoadingWithContentKt$addText$1$1
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(1);
                    }

                    @Override // kotlin.jvm.functions.Function1
                    public /* bridge */ /* synthetic */ Unit invoke(LayoutCoordinates layoutCoordinates) {
                        invoke2(layoutCoordinates);
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2(LayoutCoordinates layoutCoordinates) {
                        ViewOffset viewOffset;
                        Intrinsics.checkNotNullParameter(layoutCoordinates, "layoutCoordinates");
                        int viewWidth = IntSize.m4206getWidthimpl(layoutCoordinates.mo3162getSizeYbymL2g());
                        LayoutCoordinates parentCoordinates = layoutCoordinates.getParentCoordinates();
                        int parentWidth = parentCoordinates != null ? IntSize.m4206getWidthimpl(parentCoordinates.mo3162getSizeYbymL2g()) : LiveLiterals$FlatLoadingWithContentKt.INSTANCE.m6914Int$branch$when$valparentWidth$fun$anonymous$$arg0$callonGloballyPositioned$valtmp2_modifier$funaddText();
                        MutableState<ViewOffset> mutableState = offset;
                        if (parentWidth >= viewWidth) {
                            viewOffset = new ViewOffset(0, 0, 3);
                        } else {
                            viewOffset = new ViewOffset(parentWidth, -viewWidth);
                        }
                        mutableState.setValue(viewOffset);
                    }
                };
                $composer3.updateRememberedValue(value$iv$iv2);
            } else {
                value$iv$iv2 = it$iv$iv2;
            }
            $composer3.endReplaceableGroup();
            $composer2 = $composer3;
            TextKt.m1249TextfLXpl1I(state.getTruncatedText(), OnGloballyPositionedModifierKt.onGloballyPositioned(modifierWrapContentWidth, (Function1) value$iv$iv2), 0L, ComposeUtilsKt.m6983dpToSp8Feqmps(state.getTextSize(), $composer3, 0), null, null, null, 0L, null, TextAlign.m3925boximpl(TextAlign.INSTANCE.m3932getCentere0LSkKk()), TextUnitKt.m4239TextUnitanM5pPY(state.getTextSize(), TextUnitType.INSTANCE.m4261getUnspecifiedUIouoOA()), 0, false, 1, null, null, $composer2, 0, 3072, 55796);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.ui.views.FlatLoadingWithContentKt.addText.2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i) {
                FlatLoadingWithContentKt.addText(state, composer, $changed | 1);
            }
        });
    }

    private static final float addText$lambda$9(State<Dp> state) {
        Object thisObj$iv = state.getValue();
        return ((Dp) thisObj$iv).m4060unboximpl();
    }
}
