package vea.raceremote.ui.views;

import android.view.MotionEvent;
import androidx.compose.foundation.BackgroundKt;
import androidx.compose.foundation.layout.AspectRatioKt;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.foundation.layout.OffsetKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.shape.RoundedCornerShape;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.material.MaterialTheme;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.ProvidableCompositionLocal;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.SkippableUpdater;
import androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.input.pointer.PointerInteropFilter_androidKt;
import androidx.compose.ui.layout.LayoutCoordinates;
import androidx.compose.ui.layout.LayoutKt;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.layout.OnGloballyPositionedModifierKt;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.platform.CompositionLocalsKt;
import androidx.compose.ui.platform.ViewConfiguration;
import androidx.compose.ui.unit.Density;
import androidx.compose.ui.unit.IntOffset;
import androidx.compose.ui.unit.IntOffsetKt;
import androidx.compose.ui.unit.IntSize;
import androidx.compose.ui.unit.LayoutDirection;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.math.MathKt;

/* JADX INFO: compiled from: Joystick.kt */
/* JADX INFO: loaded from: classes9.dex */
@Metadata(d1 = {"\u00000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0005\u001a5\u0010\u0000\u001a\u00020\u00012\b\b\u0002\u0010\u0002\u001a\u00020\u00032\u001c\b\u0002\u0010\u0004\u001a\u0016\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u0001\u0018\u00010\u0005H\u0007¢\u0006\u0002\u0010\u0007\u001a^\u0010\b\u001a\u00020\u0001*\u00020\t2\f\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00060\u000b2\f\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00060\u000b2\u0006\u0010\r\u001a\u00020\u00062\u0006\u0010\u000e\u001a\u00020\u00062\u0006\u0010\u000f\u001a\u00020\u00102\u001c\b\u0002\u0010\u0004\u001a\u0016\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u0001\u0018\u00010\u0005H\u0002\u001a,\u0010\u0011\u001a\u00020\u0006*\u00020\t2\u0006\u0010\r\u001a\u00020\u00062\u0006\u0010\u000e\u001a\u00020\u00062\u0006\u0010\u0012\u001a\u00020\u00062\u0006\u0010\u0013\u001a\u00020\u0006H\u0002\u001a\f\u0010\u0014\u001a\u00020\u0006*\u00020\u0006H\u0002¨\u0006\u0015"}, d2 = {"Joystick", "", "modifier", "Landroidx/compose/ui/Modifier;", "onUpdateStickPosition", "Lkotlin/Function2;", "", "(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V", "changeJoystickPosition", "Lvea/raceremote/ui/views/Center;", "offsetX", "Landroidx/compose/runtime/MutableState;", "offsetY", "xTouch", "yTouch", "smallCircleDiameter", "", "getAngle", "a", "hypotenuse", "toRadian", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class JoystickKt {
    /* JADX WARN: Type inference failed for: r8v9, types: [T, vea.raceremote.ui.views.Center] */
    public static final void Joystick(Modifier modifier, Function2<? super Float, ? super Float, Unit> function2, Composer $composer, final int $changed, final int i) {
        final Modifier modifier2;
        final Function2<? super Float, ? super Float, Unit> function3;
        Object value$iv$iv;
        Object value$iv$iv2;
        Object value$iv$iv3;
        Composer $composer2 = $composer.startRestartGroup(1118571248);
        ComposerKt.sourceInformation($composer2, "C(Joystick)55@2180L31,56@2230L31,63@2439L6,58@2267L1409:Joystick.kt#4usob5");
        int $dirty = $changed;
        int i2 = i & 1;
        if (i2 != 0) {
            $dirty |= 6;
            modifier2 = modifier;
        } else if (($changed & 14) == 0) {
            modifier2 = modifier;
            $dirty |= $composer2.changed(modifier2) ? 4 : 2;
        } else {
            modifier2 = modifier;
        }
        int i3 = i & 2;
        if (i3 != 0) {
            $dirty |= 48;
            function3 = function2;
        } else if (($changed & 112) == 0) {
            function3 = function2;
            $dirty |= $composer2.changed(function3) ? 32 : 16;
        } else {
            function3 = function2;
        }
        if (($dirty & 91) == 18 && $composer2.getSkipping()) {
            $composer2.skipToGroupEnd();
        } else {
            Modifier.Companion modifier3 = i2 != 0 ? Modifier.INSTANCE : modifier2;
            Function2<? super Float, ? super Float, Unit> function4 = i3 != 0 ? null : function3;
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1118571248, $changed, -1, "vea.raceremote.ui.views.Joystick (Joystick.kt:46)");
            }
            final Ref.IntRef smallCircleDiameter = new Ref.IntRef();
            smallCircleDiameter.element = LiveLiterals$JoystickKt.INSTANCE.m6954Int$valsmallCircleDiameter$funJoystick();
            final Ref.ObjectRef center = new Ref.ObjectRef();
            center.element = new Center(LiveLiterals$JoystickKt.INSTANCE.m6945Int$arg0$call$init$$valcenter$funJoystick(), LiveLiterals$JoystickKt.INSTANCE.m6953Int$arg1$call$init$$valcenter$funJoystick());
            float smallCircle = LiveLiterals$JoystickKt.INSTANCE.m6935Float$$this$calldiv$valsmallCircle$funJoystick() / LiveLiterals$JoystickKt.INSTANCE.m6940Float$arg0$calldiv$valsmallCircle$funJoystick();
            RoundedCornerShape circle = RoundedCornerShapeKt.RoundedCornerShape(LiveLiterals$JoystickKt.INSTANCE.m6946Int$arg0$callRoundedCornerShape$valcircle$funJoystick());
            $composer2.startReplaceableGroup(-492369756);
            ComposerKt.sourceInformation($composer2, "C(remember):Composables.kt#9igjgp");
            Object it$iv$iv = $composer2.rememberedValue();
            if (it$iv$iv == Composer.INSTANCE.getEmpty()) {
                value$iv$iv = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(Float.valueOf(LiveLiterals$JoystickKt.INSTANCE.m6942Float$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valoffsetX$funJoystick()), null, 2, null);
                $composer2.updateRememberedValue(value$iv$iv);
            } else {
                value$iv$iv = it$iv$iv;
            }
            $composer2.endReplaceableGroup();
            final MutableState offsetX = (MutableState) value$iv$iv;
            $composer2.startReplaceableGroup(-492369756);
            ComposerKt.sourceInformation($composer2, "C(remember):Composables.kt#9igjgp");
            Object it$iv$iv2 = $composer2.rememberedValue();
            if (it$iv$iv2 == Composer.INSTANCE.getEmpty()) {
                value$iv$iv2 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(Float.valueOf(LiveLiterals$JoystickKt.INSTANCE.m6943Float$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valoffsetY$funJoystick()), null, 2, null);
                $composer2.updateRememberedValue(value$iv$iv2);
            } else {
                value$iv$iv2 = it$iv$iv2;
            }
            $composer2.endReplaceableGroup();
            final MutableState offsetY = (MutableState) value$iv$iv2;
            Alignment center2 = Alignment.INSTANCE.getCenter();
            Modifier modifier4 = modifier3;
            final Function2<? super Float, ? super Float, Unit> function5 = function4;
            Modifier modifierPointerInteropFilter$default = PointerInteropFilter_androidKt.pointerInteropFilter$default(OnGloballyPositionedModifierKt.onGloballyPositioned(BackgroundKt.m179backgroundbw27NRU(AspectRatioKt.aspectRatio$default(SizeKt.fillMaxSize$default(modifier3, 0.0f, 1, null), LiveLiterals$JoystickKt.INSTANCE.m6938Float$arg0$callaspectRatio$$$this$callbackground$$$this$callonGloballyPositioned$$$this$callpointerInteropFilter$valtmp1_modifier$funJoystick(), false, 2, null), MaterialTheme.INSTANCE.getColors($composer2, MaterialTheme.$stable).m974getBackground0d7_KjU(), circle), new Function1<LayoutCoordinates, Unit>() { // from class: vea.raceremote.ui.views.JoystickKt.Joystick.1
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(1);
                }

                @Override // kotlin.jvm.functions.Function1
                public /* bridge */ /* synthetic */ Unit invoke(LayoutCoordinates layoutCoordinates) {
                    invoke2(layoutCoordinates);
                    return Unit.INSTANCE;
                }

                /* JADX WARN: Type inference failed for: r2v0, types: [T, vea.raceremote.ui.views.Center] */
                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2(LayoutCoordinates it) {
                    Intrinsics.checkNotNullParameter(it, "it");
                    int radius = IntSize.m4205getHeightimpl(it.mo3162getSizeYbymL2g()) / LiveLiterals$JoystickKt.INSTANCE.m6949Int$arg0$calldiv$valradius$fun$anonymous$$arg0$callonGloballyPositioned$$$this$callpointerInteropFilter$valtmp1_modifier$funJoystick();
                    center.element = new Center(radius, radius);
                }
            }), null, new Function1<MotionEvent, Boolean>() { // from class: vea.raceremote.ui.views.JoystickKt.Joystick.2
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                /* JADX WARN: Multi-variable type inference failed */
                {
                    super(1);
                }

                @Override // kotlin.jvm.functions.Function1
                public final Boolean invoke(MotionEvent it) {
                    boolean zM6923Boolean$branch$when$cond$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;
                    boolean zM6922Boolean$branch$when$cond$when$cond1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;
                    Intrinsics.checkNotNullParameter(it, "it");
                    int action = it.getAction();
                    boolean zM6924Boolean$branch$when$cond1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick = false;
                    if (action == 0) {
                        zM6923Boolean$branch$when$cond$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick = LiveLiterals$JoystickKt.INSTANCE.m6923Boolean$branch$when$cond$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick();
                    } else {
                        zM6923Boolean$branch$when$cond$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick = action == 2;
                    }
                    if (zM6923Boolean$branch$when$cond$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick) {
                        JoystickKt.changeJoystickPosition(center.element, offsetX, offsetY, it.getX(), it.getY(), smallCircleDiameter.element, function5);
                    } else {
                        if (action == 1) {
                            zM6922Boolean$branch$when$cond$when$cond1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick = LiveLiterals$JoystickKt.INSTANCE.m6922Boolean$branch$when$cond$when$cond1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick();
                        } else {
                            zM6922Boolean$branch$when$cond$when$cond1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick = action == 6;
                        }
                        if (zM6922Boolean$branch$when$cond$when$cond1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick) {
                            zM6924Boolean$branch$when$cond1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick = LiveLiterals$JoystickKt.INSTANCE.m6924Boolean$branch$when$cond1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick();
                        } else if (action == 3) {
                            zM6924Boolean$branch$when$cond1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick = true;
                        }
                        if (zM6924Boolean$branch$when$cond1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick) {
                            setValue(Float.valueOf(LiveLiterals$JoystickKt.INSTANCE.m6936Float$arg0$call$setvalue$$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick()));
                            setValue(Float.valueOf(LiveLiterals$JoystickKt.INSTANCE.m6937Float$arg0$call$setvalue$1$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick()));
                            Function2<Float, Float, Unit> function6 = function5;
                            if (function6 != null) {
                                function6.invoke(Float.valueOf(LiveLiterals$JoystickKt.INSTANCE.m6941Float$arg0$callinvoke$else$when$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick()), Float.valueOf(LiveLiterals$JoystickKt.INSTANCE.m6944Float$arg1$callinvoke$else$when$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick()));
                            }
                        }
                    }
                    return Boolean.valueOf(LiveLiterals$JoystickKt.INSTANCE.m6929Boolean$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick());
                }
            }, 1, null);
            $composer2.startReplaceableGroup(733328855);
            ComposerKt.sourceInformation($composer2, "C(Box)P(2,1,3)70@3267L67,71@3339L130:Box.kt#2w3rfo");
            MeasurePolicy measurePolicy$iv = BoxKt.rememberBoxMeasurePolicy(center2, false, $composer2, ((48 >> 3) & 14) | ((48 >> 3) & 112));
            int $changed$iv$iv = (48 << 3) & 112;
            $composer2.startReplaceableGroup(-1323940314);
            ComposerKt.sourceInformation($composer2, "C(Layout)P(!1,2)74@2915L7,75@2970L7,76@3029L7,77@3041L460:Layout.kt#80mrfh");
            ProvidableCompositionLocal<Density> localDensity = CompositionLocalsKt.getLocalDensity();
            Function2<? super Float, ? super Float, Unit> function6 = function4;
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume = $composer2.consume(localDensity);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            Density density$iv$iv = (Density) objConsume;
            ProvidableCompositionLocal<LayoutDirection> localLayoutDirection = CompositionLocalsKt.getLocalLayoutDirection();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume2 = $composer2.consume(localLayoutDirection);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            LayoutDirection layoutDirection$iv$iv = (LayoutDirection) objConsume2;
            ProvidableCompositionLocal<ViewConfiguration> localViewConfiguration = CompositionLocalsKt.getLocalViewConfiguration();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume3 = $composer2.consume(localViewConfiguration);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ViewConfiguration viewConfiguration$iv$iv = (ViewConfiguration) objConsume3;
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            Function3<SkippableUpdater<ComposeUiNode>, Composer, Integer, Unit> function3MaterializerOf = LayoutKt.materializerOf(modifierPointerInteropFilter$default);
            int $changed$iv$iv$iv = (($changed$iv$iv << 9) & 7168) | 6;
            if (!($composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer2.startReusableNode();
            if ($composer2.getInserting()) {
                $composer2.createNode(constructor);
            } else {
                $composer2.useNode();
            }
            $composer2.disableReusing();
            Composer $this$Layout_u24lambda_u2d0$iv$iv = Updater.m1304constructorimpl($composer2);
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, measurePolicy$iv, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, density$iv$iv, ComposeUiNode.INSTANCE.getSetDensity());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, layoutDirection$iv$iv, ComposeUiNode.INSTANCE.getSetLayoutDirection());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, viewConfiguration$iv$iv, ComposeUiNode.INSTANCE.getSetViewConfiguration());
            $composer2.enableReusing();
            function3MaterializerOf.invoke(SkippableUpdater.m1294boximpl(SkippableUpdater.m1295constructorimpl($composer2)), $composer2, Integer.valueOf(($changed$iv$iv$iv >> 3) & 112));
            $composer2.startReplaceableGroup(2058660585);
            int $changed$iv = ($changed$iv$iv$iv >> 9) & 14;
            $composer2.startReplaceableGroup(-2137368960);
            ComposerKt.sourceInformation($composer2, "C72@3384L9:Box.kt#2w3rfo");
            if (($changed$iv & 11) == 2 && $composer2.getSkipping()) {
                $composer2.skipToGroupEnd();
            } else {
                BoxScopeInstance boxScopeInstance = BoxScopeInstance.INSTANCE;
                int i4 = ((48 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart($composer2, -1779221889, "C91@3382L69,89@3321L349:Joystick.kt#4usob5");
                Modifier.Companion companion = Modifier.INSTANCE;
                $composer2.startReplaceableGroup(511388516);
                ComposerKt.sourceInformation($composer2, "C(remember)P(1,2):Composables.kt#9igjgp");
                boolean invalid$iv$iv = $composer2.changed(offsetX) | $composer2.changed(offsetY);
                Object it$iv$iv3 = $composer2.rememberedValue();
                if (invalid$iv$iv || it$iv$iv3 == Composer.INSTANCE.getEmpty()) {
                    value$iv$iv3 = (Function1) new Function1<Density, IntOffset>() { // from class: vea.raceremote.ui.views.JoystickKt$Joystick$3$1$1
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(1);
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public /* bridge */ /* synthetic */ IntOffset invoke(Density density) {
                            return IntOffset.m4155boximpl(m6899invokeBjo55l4(density));
                        }

                        /* JADX INFO: renamed from: invoke-Bjo55l4, reason: not valid java name */
                        public final long m6899invokeBjo55l4(Density $this$offset) {
                            Intrinsics.checkNotNullParameter($this$offset, "$this$offset");
                            return IntOffsetKt.IntOffset(MathKt.roundToInt(getValue().floatValue()), MathKt.roundToInt(getValue().floatValue()));
                        }
                    };
                    $composer2.updateRememberedValue(value$iv$iv3);
                } else {
                    value$iv$iv3 = it$iv$iv3;
                }
                $composer2.endReplaceableGroup();
                BoxKt.Box(OnGloballyPositionedModifierKt.onGloballyPositioned(BackgroundKt.m179backgroundbw27NRU(AspectRatioKt.aspectRatio$default(SizeKt.fillMaxSize(OffsetKt.offset(companion, (Function1) value$iv$iv3), smallCircle), LiveLiterals$JoystickKt.INSTANCE.m6939Float$arg0$callaspectRatio$$$this$callbackground$$$this$callonGloballyPositioned$arg0$callBox$fun$anonymous$$arg3$callBox$funJoystick(), false, 2, null), Color.INSTANCE.m1695getRed0d7_KjU(), circle), new Function1<LayoutCoordinates, Unit>() { // from class: vea.raceremote.ui.views.JoystickKt$Joystick$3$2
                    {
                        super(1);
                    }

                    @Override // kotlin.jvm.functions.Function1
                    public /* bridge */ /* synthetic */ Unit invoke(LayoutCoordinates layoutCoordinates) {
                        invoke2(layoutCoordinates);
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2(LayoutCoordinates it) {
                        Intrinsics.checkNotNullParameter(it, "it");
                        smallCircleDiameter.element = IntSize.m4205getHeightimpl(it.mo3162getSizeYbymL2g());
                    }
                }), $composer2, 0);
                ComposerKt.sourceInformationMarkerEnd($composer2);
            }
            $composer2.endReplaceableGroup();
            $composer2.endReplaceableGroup();
            $composer2.endNode();
            $composer2.endReplaceableGroup();
            $composer2.endReplaceableGroup();
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
            function3 = function6;
            modifier2 = modifier4;
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.ui.views.JoystickKt.Joystick.4
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i5) {
                JoystickKt.Joystick(modifier2, function3, composer, $changed | 1, i);
            }
        });
    }

    private static final float getAngle(Center $this$getAngle, float xTouch, float yTouch, float a, float hypotenuse) {
        float triangleAngle = (float) Math.asin(a / hypotenuse);
        if (xTouch >= $this$getAngle.getX() && yTouch <= $this$getAngle.getY()) {
            return toRadian(LiveLiterals$JoystickKt.INSTANCE.m6931Float$$$this$calltoRadian$$this$callminus$branch$when$fungetAngle()) - triangleAngle;
        }
        if (xTouch >= $this$getAngle.getX() || yTouch >= $this$getAngle.getY()) {
            return (xTouch >= ((float) $this$getAngle.getX()) || yTouch <= ((float) $this$getAngle.getY())) ? toRadian(LiveLiterals$JoystickKt.INSTANCE.m6934Float$$$this$calltoRadian$$this$callplus$else$when$fungetAngle()) + triangleAngle : toRadian(LiveLiterals$JoystickKt.INSTANCE.m6932Float$$$this$calltoRadian$$this$callminus$branch2$when$fungetAngle()) - triangleAngle;
        }
        return toRadian(LiveLiterals$JoystickKt.INSTANCE.m6933Float$$$this$calltoRadian$$this$callplus$branch1$when$fungetAngle()) + triangleAngle;
    }

    private static final float toRadian(float $this$toRadian) {
        return (float) (((double) ($this$toRadian / LiveLiterals$JoystickKt.INSTANCE.m6947Int$arg0$calldiv$$this$calltimes$$this$calltoFloat$funtoRadian())) * 3.141592653589793d);
    }

    static /* synthetic */ void changeJoystickPosition$default(Center center, MutableState mutableState, MutableState mutableState2, float f, float f2, int i, Function2 function2, int i2, Object obj) {
        Function2 function3;
        if ((i2 & 32) == 0) {
            function3 = function2;
        } else {
            function3 = null;
        }
        changeJoystickPosition(center, mutableState, mutableState2, f, f2, i, function3);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void changeJoystickPosition(Center $this$changeJoystickPosition, MutableState<Float> mutableState, MutableState<Float> mutableState2, float xTouch, float yTouch, int smallCircleDiameter, Function2<? super Float, ? super Float, Unit> function2) {
        Pair pair;
        float a = Math.abs($this$changeJoystickPosition.getX() - xTouch);
        float b = Math.abs($this$changeJoystickPosition.getY() - yTouch);
        float hypotenuse = (float) Math.sqrt(((float) Math.pow(a, LiveLiterals$JoystickKt.INSTANCE.m6950Int$arg0$callpow$$this$callplus$arg0$callsqrt$valhypotenuse$funchangeJoystickPosition())) + ((float) Math.pow(b, LiveLiterals$JoystickKt.INSTANCE.m6951Int$arg0$callpow$arg0$callplus$arg0$callsqrt$valhypotenuse$funchangeJoystickPosition())));
        float angle = getAngle($this$changeJoystickPosition, xTouch, yTouch, a, hypotenuse);
        int radiusOffset = $this$changeJoystickPosition.getRadius() - (smallCircleDiameter / LiveLiterals$JoystickKt.INSTANCE.m6948Int$arg0$calldiv$arg0$callminus$valradiusOffset$funchangeJoystickPosition());
        if (hypotenuse > radiusOffset) {
            float newX = radiusOffset * ((float) Math.cos(angle));
            float newY = radiusOffset * ((float) Math.sin(angle));
            pair = TuplesKt.to(Float.valueOf(newX), Float.valueOf(-newY));
        } else {
            pair = TuplesKt.to(Float.valueOf(xTouch - $this$changeJoystickPosition.getX()), Float.valueOf(yTouch - $this$changeJoystickPosition.getY()));
        }
        float aX = ((Number) pair.component1()).floatValue();
        float aY = ((Number) pair.component2()).floatValue();
        mutableState.setValue(Float.valueOf(aX));
        mutableState2.setValue(Float.valueOf(aY));
        if (function2 != null) {
            function2.invoke(Float.valueOf(aX / radiusOffset), Float.valueOf(-(aY / radiusOffset)));
        }
    }
}
