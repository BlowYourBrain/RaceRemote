package vea.raceremote.ui.views;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: FlatLoadingWithContent.kt */
/* JADX INFO: loaded from: classes9.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/ui/views/FlatLoadingWithContent.kt")
public final class LiveLiterals$FlatLoadingWithContentKt {

    /* JADX INFO: renamed from: Float$$$this$call-at$$$this$call-with$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    private static float f1816Float$$$this$callat$$$this$callwith$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;

    /* JADX INFO: renamed from: Float$$$this$call-at$$$this$call-with-2$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    private static float f1818Float$$$this$callat$$$this$callwith2$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;

    /* JADX INFO: renamed from: Float$$$this$call-at$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    private static float f1819Float$$$this$callat$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;

    /* JADX INFO: renamed from: Float$arg-0$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    private static float f1820Float$arg0$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;

    /* JADX INFO: renamed from: Int$arg-0$call-at$$$this$call-with$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    private static int f1823Int$arg0$callat$$$this$callwith$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;

    /* JADX INFO: renamed from: Int$branch$when$val-parentWidth$fun-$anonymous$$arg-0$call-onGloballyPositioned$val-tmp2_modifier$fun-addText, reason: not valid java name */
    private static int f1829Int$branch$when$valparentWidth$fun$anonymous$$arg0$callonGloballyPositioned$valtmp2_modifier$funaddText;

    /* JADX INFO: renamed from: Int$class-DotsState, reason: not valid java name */
    private static int f1830Int$classDotsState;

    /* JADX INFO: renamed from: Int$class-Idle$class-DotsState, reason: not valid java name */
    private static int f1831Int$classIdle$classDotsState;

    /* JADX INFO: renamed from: Int$class-Loading$class-DotsState, reason: not valid java name */
    private static int f1832Int$classLoading$classDotsState;

    /* JADX INFO: renamed from: Int$class-ShowText$class-DotsState, reason: not valid java name */
    private static int f1833Int$classShowText$classDotsState;

    /* JADX INFO: renamed from: Int$param-initialOffset$class-ViewOffset, reason: not valid java name */
    private static int f1834Int$paraminitialOffset$classViewOffset;

    /* JADX INFO: renamed from: Int$param-targetOffset$class-ViewOffset, reason: not valid java name */
    private static int f1835Int$paramtargetOffset$classViewOffset;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-wrapContentWidth$$$this$call-onGloballyPositioned$val-tmp2_modifier$fun-addText, reason: not valid java name */
    private static State<Boolean> f1836State$Boolean$arg1$callwrapContentWidth$$$this$callonGloballyPositioned$valtmp2_modifier$funaddText;

    /* JADX INFO: renamed from: State$Float$$$this$call-at$$$this$call-with$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    private static State<Float> f1837State$Float$$$this$callat$$$this$callwith$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;

    /* JADX INFO: renamed from: State$Float$$$this$call-at$$$this$call-with-1$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    private static State<Float> f1838State$Float$$$this$callat$$$this$callwith1$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;

    /* JADX INFO: renamed from: State$Float$$$this$call-at$$$this$call-with-2$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    private static State<Float> f1839State$Float$$$this$callat$$$this$callwith2$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;

    /* JADX INFO: renamed from: State$Float$$$this$call-at$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    private static State<Float> f1840State$Float$$$this$callat$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;

    /* JADX INFO: renamed from: State$Float$arg-0$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    private static State<Float> f1841State$Float$arg0$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;

    /* JADX INFO: renamed from: State$Float$arg-1$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    private static State<Float> f1842State$Float$arg1$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;

    /* JADX INFO: renamed from: State$Int$$$this$call-$get-dp$$param-dotsDividerSpace$class-Loading$class-DotsState, reason: not valid java name */
    private static State<Integer> f1843State$Int$$$this$call$getdp$$paramdotsDividerSpace$classLoading$classDotsState;

    /* JADX INFO: renamed from: State$Int$arg-0$call-at$$$this$call-with$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    private static State<Integer> f1844State$Int$arg0$callat$$$this$callwith$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;

    /* JADX INFO: renamed from: State$Int$arg-0$call-div$arg-0$call-$init$$arg-2$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    private static State<Integer> f1845State$Int$arg0$calldiv$arg0$call$init$$arg2$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;

    /* JADX INFO: renamed from: State$Int$arg-0$call-div$arg-0$call-RoundedCornerShape$arg-1$call-background$arg-0$call-Box$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    private static State<Integer> f1846State$Int$arg0$calldiv$arg0$callRoundedCornerShape$arg1$callbackground$arg0$callBox$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;

    /* JADX INFO: renamed from: State$Int$arg-0$call-div$arg-0$call-at$$$this$call-with-1$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    private static State<Integer> f1847State$Int$arg0$calldiv$arg0$callat$$$this$callwith1$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;

    /* JADX INFO: renamed from: State$Int$arg-0$call-div$val-totalAnimationDuration$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    private static State<Integer> f1848State$Int$arg0$calldiv$valtotalAnimationDuration$fun$anonymous$$arg0$callrun$funaddLoadingDots;

    /* JADX INFO: renamed from: State$Int$arg-0$call-minus$arg-1$call-less$cond$if$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    private static State<Integer> f1849State$Int$arg0$callminus$arg1$callless$cond$if$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;

    /* JADX INFO: renamed from: State$Int$branch$when$val-parentWidth$fun-$anonymous$$arg-0$call-onGloballyPositioned$val-tmp2_modifier$fun-addText, reason: not valid java name */
    private static State<Integer> f1850State$Int$branch$when$valparentWidth$fun$anonymous$$arg0$callonGloballyPositioned$valtmp2_modifier$funaddText;

    /* JADX INFO: renamed from: State$Int$class-DotsState, reason: not valid java name */
    private static State<Integer> f1851State$Int$classDotsState;

    /* JADX INFO: renamed from: State$Int$class-Idle$class-DotsState, reason: not valid java name */
    private static State<Integer> f1852State$Int$classIdle$classDotsState;

    /* JADX INFO: renamed from: State$Int$class-Loading$class-DotsState, reason: not valid java name */
    private static State<Integer> f1853State$Int$classLoading$classDotsState;

    /* JADX INFO: renamed from: State$Int$class-ShowText$class-DotsState, reason: not valid java name */
    private static State<Integer> f1854State$Int$classShowText$classDotsState;

    /* JADX INFO: renamed from: State$Int$param-initialOffset$class-ViewOffset, reason: not valid java name */
    private static State<Integer> f1855State$Int$paraminitialOffset$classViewOffset;

    /* JADX INFO: renamed from: State$Int$param-targetOffset$class-ViewOffset, reason: not valid java name */
    private static State<Integer> f1856State$Int$paramtargetOffset$classViewOffset;

    /* JADX INFO: renamed from: State$String$1$str$else$if$fun-$get-truncatedText$$get$val-truncatedText$class-ShowText$class-DotsState, reason: not valid java name */
    private static State<String> f1857State$String$1$str$else$if$fun$gettruncatedText$$get$valtruncatedText$classShowText$classDotsState;
    public static final LiveLiterals$FlatLoadingWithContentKt INSTANCE = new LiveLiterals$FlatLoadingWithContentKt();

    /* JADX INFO: renamed from: Int$$$this$call-$get-dp$$param-dotsDividerSpace$class-Loading$class-DotsState, reason: not valid java name */
    private static int f1822Int$$$this$call$getdp$$paramdotsDividerSpace$classLoading$classDotsState = 4;

    /* JADX INFO: renamed from: String$1$str$else$if$fun-$get-truncatedText$$get$val-truncatedText$class-ShowText$class-DotsState, reason: not valid java name */
    private static String f1858String$1$str$else$if$fun$gettruncatedText$$get$valtruncatedText$classShowText$classDotsState = "...";

    /* JADX INFO: renamed from: Int$arg-0$call-div$val-totalAnimationDuration$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    private static int f1827Int$arg0$calldiv$valtotalAnimationDuration$fun$anonymous$$arg0$callrun$funaddLoadingDots = 2;

    /* JADX INFO: renamed from: Float$arg-1$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    private static float f1821Float$arg1$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots = 1.0f;

    /* JADX INFO: renamed from: Float$$$this$call-at$$$this$call-with-1$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    private static float f1817Float$$$this$callat$$$this$callwith1$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots = 1.0f;

    /* JADX INFO: renamed from: Int$arg-0$call-div$arg-0$call-at$$$this$call-with-1$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    private static int f1826Int$arg0$calldiv$arg0$callat$$$this$callwith1$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots = 2;

    /* JADX INFO: renamed from: Int$arg-0$call-div$arg-0$call-$init$$arg-2$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    private static int f1824Int$arg0$calldiv$arg0$call$init$$arg2$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots = 2;

    /* JADX INFO: renamed from: Int$arg-0$call-div$arg-0$call-RoundedCornerShape$arg-1$call-background$arg-0$call-Box$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    private static int f1825Int$arg0$calldiv$arg0$callRoundedCornerShape$arg1$callbackground$arg0$callBox$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots = 2;

    /* JADX INFO: renamed from: Int$arg-0$call-minus$arg-1$call-less$cond$if$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    private static int f1828Int$arg0$callminus$arg1$callless$cond$if$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots = 1;

    /* JADX INFO: renamed from: Boolean$arg-1$call-wrapContentWidth$$$this$call-onGloballyPositioned$val-tmp2_modifier$fun-addText, reason: not valid java name */
    private static boolean f1815Boolean$arg1$callwrapContentWidth$$$this$callonGloballyPositioned$valtmp2_modifier$funaddText = true;

    @LiveLiteralInfo(key = "Boolean$arg-1$call-wrapContentWidth$$$this$call-onGloballyPositioned$val-tmp2_modifier$fun-addText", offset = 7197)
    /* JADX INFO: renamed from: Boolean$arg-1$call-wrapContentWidth$$$this$call-onGloballyPositioned$val-tmp2_modifier$fun-addText, reason: not valid java name */
    public final boolean m6900Boolean$arg1$callwrapContentWidth$$$this$callonGloballyPositioned$valtmp2_modifier$funaddText() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1815Boolean$arg1$callwrapContentWidth$$$this$callonGloballyPositioned$valtmp2_modifier$funaddText;
        }
        State<Boolean> stateLiveLiteral = f1836State$Boolean$arg1$callwrapContentWidth$$$this$callonGloballyPositioned$valtmp2_modifier$funaddText;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-wrapContentWidth$$$this$call-onGloballyPositioned$val-tmp2_modifier$fun-addText", Boolean.valueOf(f1815Boolean$arg1$callwrapContentWidth$$$this$callonGloballyPositioned$valtmp2_modifier$funaddText));
            f1836State$Boolean$arg1$callwrapContentWidth$$$this$callonGloballyPositioned$valtmp2_modifier$funaddText = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Float$$$this$call-at$$$this$call-with$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots", offset = 5244)
    /* JADX INFO: renamed from: Float$$$this$call-at$$$this$call-with$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    public final float m6901Float$$$this$callat$$$this$callwith$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1816Float$$$this$callat$$$this$callwith$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;
        }
        State<Float> stateLiveLiteral = f1837State$Float$$$this$callat$$$this$callwith$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$$$this$call-at$$$this$call-with$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots", Float.valueOf(f1816Float$$$this$callat$$$this$callwith$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots));
            f1837State$Float$$$this$callat$$$this$callwith$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$$$this$call-at$$$this$call-with-1$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots", offset = 5296)
    /* JADX INFO: renamed from: Float$$$this$call-at$$$this$call-with-1$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    public final float m6902Float$$$this$callat$$$this$callwith1$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1817Float$$$this$callat$$$this$callwith1$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;
        }
        State<Float> stateLiveLiteral = f1838State$Float$$$this$callat$$$this$callwith1$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$$$this$call-at$$$this$call-with-1$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots", Float.valueOf(f1817Float$$$this$callat$$$this$callwith1$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots));
            f1838State$Float$$$this$callat$$$this$callwith1$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$$$this$call-at$$$this$call-with-2$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots", offset = 5374)
    /* JADX INFO: renamed from: Float$$$this$call-at$$$this$call-with-2$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    public final float m6903Float$$$this$callat$$$this$callwith2$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1818Float$$$this$callat$$$this$callwith2$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;
        }
        State<Float> stateLiveLiteral = f1839State$Float$$$this$callat$$$this$callwith2$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$$$this$call-at$$$this$call-with-2$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots", Float.valueOf(f1818Float$$$this$callat$$$this$callwith2$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots));
            f1839State$Float$$$this$callat$$$this$callwith2$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$$$this$call-at$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots", offset = 5446)
    /* JADX INFO: renamed from: Float$$$this$call-at$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    public final float m6904Float$$$this$callat$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1819Float$$$this$callat$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;
        }
        State<Float> stateLiveLiteral = f1840State$Float$$$this$callat$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$$$this$call-at$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots", Float.valueOf(f1819Float$$$this$callat$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots));
            f1840State$Float$$$this$callat$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots", offset = 5022)
    /* JADX INFO: renamed from: Float$arg-0$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    public final float m6905Float$arg0$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1820Float$arg0$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;
        }
        State<Float> stateLiveLiteral = f1841State$Float$arg0$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots", Float.valueOf(f1820Float$arg0$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots));
            f1841State$Float$arg0$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-1$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots", offset = 5056)
    /* JADX INFO: renamed from: Float$arg-1$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    public final float m6906Float$arg1$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1821Float$arg1$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;
        }
        State<Float> stateLiveLiteral = f1842State$Float$arg1$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-1$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots", Float.valueOf(f1821Float$arg1$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots));
            f1842State$Float$arg1$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Int$$$this$call-$get-dp$$param-dotsDividerSpace$class-Loading$class-DotsState", offset = 2682)
    /* JADX INFO: renamed from: Int$$$this$call-$get-dp$$param-dotsDividerSpace$class-Loading$class-DotsState, reason: not valid java name */
    public final int m6907Int$$$this$call$getdp$$paramdotsDividerSpace$classLoading$classDotsState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1822Int$$$this$call$getdp$$paramdotsDividerSpace$classLoading$classDotsState;
        }
        State<Integer> stateLiveLiteral = f1843State$Int$$$this$call$getdp$$paramdotsDividerSpace$classLoading$classDotsState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$$this$call-$get-dp$$param-dotsDividerSpace$class-Loading$class-DotsState", Integer.valueOf(f1822Int$$$this$call$getdp$$paramdotsDividerSpace$classLoading$classDotsState));
            f1843State$Int$$$this$call$getdp$$paramdotsDividerSpace$classLoading$classDotsState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-at$$$this$call-with$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots", offset = 5252)
    /* JADX INFO: renamed from: Int$arg-0$call-at$$$this$call-with$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    public final int m6908Int$arg0$callat$$$this$callwith$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1823Int$arg0$callat$$$this$callwith$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;
        }
        State<Integer> stateLiveLiteral = f1844State$Int$arg0$callat$$$this$callwith$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-at$$$this$call-with$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots", Integer.valueOf(f1823Int$arg0$callat$$$this$callwith$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots));
            f1844State$Int$arg0$callat$$$this$callwith$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-div$arg-0$call-$init$$arg-2$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots", offset = 5641)
    /* JADX INFO: renamed from: Int$arg-0$call-div$arg-0$call-$init$$arg-2$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    public final int m6909Int$arg0$calldiv$arg0$call$init$$arg2$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1824Int$arg0$calldiv$arg0$call$init$$arg2$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;
        }
        State<Integer> stateLiveLiteral = f1845State$Int$arg0$calldiv$arg0$call$init$$arg2$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-div$arg-0$call-$init$$arg-2$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots", Integer.valueOf(f1824Int$arg0$calldiv$arg0$call$init$$arg2$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots));
            f1845State$Int$arg0$calldiv$arg0$call$init$$arg2$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-div$arg-0$call-RoundedCornerShape$arg-1$call-background$arg-0$call-Box$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots", offset = 5919)
    /* JADX INFO: renamed from: Int$arg-0$call-div$arg-0$call-RoundedCornerShape$arg-1$call-background$arg-0$call-Box$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    public final int m6910Int$arg0$calldiv$arg0$callRoundedCornerShape$arg1$callbackground$arg0$callBox$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1825Int$arg0$calldiv$arg0$callRoundedCornerShape$arg1$callbackground$arg0$callBox$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;
        }
        State<Integer> stateLiveLiteral = f1846State$Int$arg0$calldiv$arg0$callRoundedCornerShape$arg1$callbackground$arg0$callBox$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-div$arg-0$call-RoundedCornerShape$arg-1$call-background$arg-0$call-Box$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots", Integer.valueOf(f1825Int$arg0$calldiv$arg0$callRoundedCornerShape$arg1$callbackground$arg0$callBox$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots));
            f1846State$Int$arg0$calldiv$arg0$callRoundedCornerShape$arg1$callbackground$arg0$callBox$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-div$arg-0$call-at$$$this$call-with-1$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots", offset = 5329)
    /* JADX INFO: renamed from: Int$arg-0$call-div$arg-0$call-at$$$this$call-with-1$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    public final int m6911Int$arg0$calldiv$arg0$callat$$$this$callwith1$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1826Int$arg0$calldiv$arg0$callat$$$this$callwith1$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;
        }
        State<Integer> stateLiveLiteral = f1847State$Int$arg0$calldiv$arg0$callat$$$this$callwith1$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-div$arg-0$call-at$$$this$call-with-1$fun-$anonymous$$arg-0$call-keyframes$arg-0$call-infiniteRepeatable$arg-2$call-animateFloat$val-scale$delegate$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots", Integer.valueOf(f1826Int$arg0$calldiv$arg0$callat$$$this$callwith1$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots));
            f1847State$Int$arg0$calldiv$arg0$callat$$$this$callwith1$fun$anonymous$$arg0$callkeyframes$arg0$callinfiniteRepeatable$arg2$callanimateFloat$valscale$delegate$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-div$val-totalAnimationDuration$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots", offset = 4671)
    /* JADX INFO: renamed from: Int$arg-0$call-div$val-totalAnimationDuration$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    public final int m6912Int$arg0$calldiv$valtotalAnimationDuration$fun$anonymous$$arg0$callrun$funaddLoadingDots() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1827Int$arg0$calldiv$valtotalAnimationDuration$fun$anonymous$$arg0$callrun$funaddLoadingDots;
        }
        State<Integer> stateLiveLiteral = f1848State$Int$arg0$calldiv$valtotalAnimationDuration$fun$anonymous$$arg0$callrun$funaddLoadingDots;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-div$val-totalAnimationDuration$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots", Integer.valueOf(f1827Int$arg0$calldiv$valtotalAnimationDuration$fun$anonymous$$arg0$callrun$funaddLoadingDots));
            f1848State$Int$arg0$calldiv$valtotalAnimationDuration$fun$anonymous$$arg0$callrun$funaddLoadingDots = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-minus$arg-1$call-less$cond$if$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots", offset = 6001)
    /* JADX INFO: renamed from: Int$arg-0$call-minus$arg-1$call-less$cond$if$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots, reason: not valid java name */
    public final int m6913Int$arg0$callminus$arg1$callless$cond$if$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1828Int$arg0$callminus$arg1$callless$cond$if$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;
        }
        State<Integer> stateLiveLiteral = f1849State$Int$arg0$callminus$arg1$callless$cond$if$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-minus$arg-1$call-less$cond$if$fun-$anonymous$$arg-1$call-repeat$fun-$anonymous$$arg-3$call-Row$fun-$anonymous$$arg-0$call-run$fun-addLoadingDots", Integer.valueOf(f1828Int$arg0$callminus$arg1$callless$cond$if$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots));
            f1849State$Int$arg0$callminus$arg1$callless$cond$if$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg3$callRow$fun$anonymous$$arg0$callrun$funaddLoadingDots = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$branch$when$val-parentWidth$fun-$anonymous$$arg-0$call-onGloballyPositioned$val-tmp2_modifier$fun-addText", offset = 7432)
    /* JADX INFO: renamed from: Int$branch$when$val-parentWidth$fun-$anonymous$$arg-0$call-onGloballyPositioned$val-tmp2_modifier$fun-addText, reason: not valid java name */
    public final int m6914Int$branch$when$valparentWidth$fun$anonymous$$arg0$callonGloballyPositioned$valtmp2_modifier$funaddText() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1829Int$branch$when$valparentWidth$fun$anonymous$$arg0$callonGloballyPositioned$valtmp2_modifier$funaddText;
        }
        State<Integer> stateLiveLiteral = f1850State$Int$branch$when$valparentWidth$fun$anonymous$$arg0$callonGloballyPositioned$valtmp2_modifier$funaddText;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$branch$when$val-parentWidth$fun-$anonymous$$arg-0$call-onGloballyPositioned$val-tmp2_modifier$fun-addText", Integer.valueOf(f1829Int$branch$when$valparentWidth$fun$anonymous$$arg0$callonGloballyPositioned$valtmp2_modifier$funaddText));
            f1850State$Int$branch$when$valparentWidth$fun$anonymous$$arg0$callonGloballyPositioned$valtmp2_modifier$funaddText = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-DotsState", offset = -1)
    /* JADX INFO: renamed from: Int$class-DotsState, reason: not valid java name */
    public final int m6915Int$classDotsState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1830Int$classDotsState;
        }
        State<Integer> stateLiveLiteral = f1851State$Int$classDotsState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-DotsState", Integer.valueOf(f1830Int$classDotsState));
            f1851State$Int$classDotsState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-Idle$class-DotsState", offset = -1)
    /* JADX INFO: renamed from: Int$class-Idle$class-DotsState, reason: not valid java name */
    public final int m6916Int$classIdle$classDotsState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1831Int$classIdle$classDotsState;
        }
        State<Integer> stateLiveLiteral = f1852State$Int$classIdle$classDotsState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-Idle$class-DotsState", Integer.valueOf(f1831Int$classIdle$classDotsState));
            f1852State$Int$classIdle$classDotsState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-Loading$class-DotsState", offset = -1)
    /* JADX INFO: renamed from: Int$class-Loading$class-DotsState, reason: not valid java name */
    public final int m6917Int$classLoading$classDotsState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1832Int$classLoading$classDotsState;
        }
        State<Integer> stateLiveLiteral = f1853State$Int$classLoading$classDotsState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-Loading$class-DotsState", Integer.valueOf(f1832Int$classLoading$classDotsState));
            f1853State$Int$classLoading$classDotsState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-ShowText$class-DotsState", offset = -1)
    /* JADX INFO: renamed from: Int$class-ShowText$class-DotsState, reason: not valid java name */
    public final int m6918Int$classShowText$classDotsState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1833Int$classShowText$classDotsState;
        }
        State<Integer> stateLiveLiteral = f1854State$Int$classShowText$classDotsState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-ShowText$class-DotsState", Integer.valueOf(f1833Int$classShowText$classDotsState));
            f1854State$Int$classShowText$classDotsState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$param-initialOffset$class-ViewOffset", offset = 8060)
    /* JADX INFO: renamed from: Int$param-initialOffset$class-ViewOffset, reason: not valid java name */
    public final int m6919Int$paraminitialOffset$classViewOffset() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1834Int$paraminitialOffset$classViewOffset;
        }
        State<Integer> stateLiveLiteral = f1855State$Int$paraminitialOffset$classViewOffset;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$param-initialOffset$class-ViewOffset", Integer.valueOf(f1834Int$paraminitialOffset$classViewOffset));
            f1855State$Int$paraminitialOffset$classViewOffset = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$param-targetOffset$class-ViewOffset", offset = 8091)
    /* JADX INFO: renamed from: Int$param-targetOffset$class-ViewOffset, reason: not valid java name */
    public final int m6920Int$paramtargetOffset$classViewOffset() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1835Int$paramtargetOffset$classViewOffset;
        }
        State<Integer> stateLiveLiteral = f1856State$Int$paramtargetOffset$classViewOffset;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$param-targetOffset$class-ViewOffset", Integer.valueOf(f1835Int$paramtargetOffset$classViewOffset));
            f1856State$Int$paramtargetOffset$classViewOffset = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "String$1$str$else$if$fun-$get-truncatedText$$get$val-truncatedText$class-ShowText$class-DotsState", offset = 3167)
    /* JADX INFO: renamed from: String$1$str$else$if$fun-$get-truncatedText$$get$val-truncatedText$class-ShowText$class-DotsState, reason: not valid java name */
    public final String m6921String$1$str$else$if$fun$gettruncatedText$$get$valtruncatedText$classShowText$classDotsState() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1858String$1$str$else$if$fun$gettruncatedText$$get$valtruncatedText$classShowText$classDotsState;
        }
        State<String> stateLiveLiteral = f1857State$String$1$str$else$if$fun$gettruncatedText$$get$valtruncatedText$classShowText$classDotsState;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$1$str$else$if$fun-$get-truncatedText$$get$val-truncatedText$class-ShowText$class-DotsState", f1858String$1$str$else$if$fun$gettruncatedText$$get$valtruncatedText$classShowText$classDotsState);
            f1857State$String$1$str$else$if$fun$gettruncatedText$$get$valtruncatedText$classShowText$classDotsState = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
