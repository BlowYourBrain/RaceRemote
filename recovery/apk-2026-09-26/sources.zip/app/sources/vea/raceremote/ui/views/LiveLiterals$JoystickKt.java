package vea.raceremote.ui.views;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: Joystick.kt */
/* JADX INFO: loaded from: classes9.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/ui/views/Joystick.kt")
public final class LiveLiterals$JoystickKt {

    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-Center, reason: not valid java name */
    private static boolean f1863Boolean$branch$when1$funequals$classCenter;

    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-Center, reason: not valid java name */
    private static boolean f1864Boolean$branch$when2$funequals$classCenter;

    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-Center, reason: not valid java name */
    private static boolean f1865Boolean$branch$when3$funequals$classCenter;

    /* JADX INFO: renamed from: Float$arg-0$call-$set-value$$branch-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    private static float f1873Float$arg0$call$setvalue$$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;

    /* JADX INFO: renamed from: Float$arg-0$call-$set-value$-1$branch-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    private static float f1874Float$arg0$call$setvalue$1$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;

    /* JADX INFO: renamed from: Float$arg-0$call-invoke$else$when$branch-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    private static float f1878Float$arg0$callinvoke$else$when$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;

    /* JADX INFO: renamed from: Float$arg-0$call-mutableStateOf$fun-$anonymous$$arg-0$call-remember$val-offsetX$fun-Joystick, reason: not valid java name */
    private static float f1879Float$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valoffsetX$funJoystick;

    /* JADX INFO: renamed from: Float$arg-0$call-mutableStateOf$fun-$anonymous$$arg-0$call-remember$val-offsetY$fun-Joystick, reason: not valid java name */
    private static float f1880Float$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valoffsetY$funJoystick;

    /* JADX INFO: renamed from: Float$arg-1$call-invoke$else$when$branch-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    private static float f1881Float$arg1$callinvoke$else$when$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;

    /* JADX INFO: renamed from: Int$arg-0$call-$init$$val-center$fun-Joystick, reason: not valid java name */
    private static int f1882Int$arg0$call$init$$valcenter$funJoystick;

    /* JADX INFO: renamed from: Int$arg-1$call-$init$$val-center$fun-Joystick, reason: not valid java name */
    private static int f1890Int$arg1$call$init$$valcenter$funJoystick;

    /* JADX INFO: renamed from: Int$val-smallCircleDiameter$fun-Joystick, reason: not valid java name */
    private static int f1891Int$valsmallCircleDiameter$funJoystick;

    /* JADX INFO: renamed from: State$Boolean$branch$when$cond$when$cond-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    private static State<Boolean> f1892State$Boolean$branch$when$cond$when$cond1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;

    /* JADX INFO: renamed from: State$Boolean$branch$when$cond$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    private static State<Boolean> f1893State$Boolean$branch$when$cond$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;

    /* JADX INFO: renamed from: State$Boolean$branch$when$cond-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    private static State<Boolean> f1894State$Boolean$branch$when$cond1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;

    /* JADX INFO: renamed from: State$Boolean$branch$when$fun-equals$class-Center, reason: not valid java name */
    private static State<Boolean> f1895State$Boolean$branch$when$funequals$classCenter;

    /* JADX INFO: renamed from: State$Boolean$branch$when-1$fun-equals$class-Center, reason: not valid java name */
    private static State<Boolean> f1896State$Boolean$branch$when1$funequals$classCenter;

    /* JADX INFO: renamed from: State$Boolean$branch$when-2$fun-equals$class-Center, reason: not valid java name */
    private static State<Boolean> f1897State$Boolean$branch$when2$funequals$classCenter;

    /* JADX INFO: renamed from: State$Boolean$branch$when-3$fun-equals$class-Center, reason: not valid java name */
    private static State<Boolean> f1898State$Boolean$branch$when3$funequals$classCenter;

    /* JADX INFO: renamed from: State$Boolean$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    private static State<Boolean> f1899State$Boolean$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;

    /* JADX INFO: renamed from: State$Boolean$fun-equals$class-Center, reason: not valid java name */
    private static State<Boolean> f1900State$Boolean$funequals$classCenter;

    /* JADX INFO: renamed from: State$Float$$$this$call-toRadian$$this$call-minus$branch$when$fun-getAngle, reason: not valid java name */
    private static State<Float> f1901State$Float$$$this$calltoRadian$$this$callminus$branch$when$fungetAngle;

    /* JADX INFO: renamed from: State$Float$$$this$call-toRadian$$this$call-minus$branch-2$when$fun-getAngle, reason: not valid java name */
    private static State<Float> f1902State$Float$$$this$calltoRadian$$this$callminus$branch2$when$fungetAngle;

    /* JADX INFO: renamed from: State$Float$$$this$call-toRadian$$this$call-plus$branch-1$when$fun-getAngle, reason: not valid java name */
    private static State<Float> f1903State$Float$$$this$calltoRadian$$this$callplus$branch1$when$fungetAngle;

    /* JADX INFO: renamed from: State$Float$$$this$call-toRadian$$this$call-plus$else$when$fun-getAngle, reason: not valid java name */
    private static State<Float> f1904State$Float$$$this$calltoRadian$$this$callplus$else$when$fungetAngle;

    /* JADX INFO: renamed from: State$Float$$this$call-div$val-smallCircle$fun-Joystick, reason: not valid java name */
    private static State<Float> f1905State$Float$$this$calldiv$valsmallCircle$funJoystick;

    /* JADX INFO: renamed from: State$Float$arg-0$call-$set-value$$branch-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    private static State<Float> f1906State$Float$arg0$call$setvalue$$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;

    /* JADX INFO: renamed from: State$Float$arg-0$call-$set-value$-1$branch-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    private static State<Float> f1907State$Float$arg0$call$setvalue$1$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;

    /* JADX INFO: renamed from: State$Float$arg-0$call-aspectRatio$$$this$call-background$$$this$call-onGloballyPositioned$$$this$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    private static State<Float> f1908State$Float$arg0$callaspectRatio$$$this$callbackground$$$this$callonGloballyPositioned$$$this$callpointerInteropFilter$valtmp1_modifier$funJoystick;

    /* JADX INFO: renamed from: State$Float$arg-0$call-aspectRatio$$$this$call-background$$$this$call-onGloballyPositioned$arg-0$call-Box$fun-$anonymous$$arg-3$call-Box$fun-Joystick, reason: not valid java name */
    private static State<Float> f1909State$Float$arg0$callaspectRatio$$$this$callbackground$$$this$callonGloballyPositioned$arg0$callBox$fun$anonymous$$arg3$callBox$funJoystick;

    /* JADX INFO: renamed from: State$Float$arg-0$call-div$val-smallCircle$fun-Joystick, reason: not valid java name */
    private static State<Float> f1910State$Float$arg0$calldiv$valsmallCircle$funJoystick;

    /* JADX INFO: renamed from: State$Float$arg-0$call-invoke$else$when$branch-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    private static State<Float> f1911State$Float$arg0$callinvoke$else$when$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;

    /* JADX INFO: renamed from: State$Float$arg-0$call-mutableStateOf$fun-$anonymous$$arg-0$call-remember$val-offsetX$fun-Joystick, reason: not valid java name */
    private static State<Float> f1912State$Float$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valoffsetX$funJoystick;

    /* JADX INFO: renamed from: State$Float$arg-0$call-mutableStateOf$fun-$anonymous$$arg-0$call-remember$val-offsetY$fun-Joystick, reason: not valid java name */
    private static State<Float> f1913State$Float$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valoffsetY$funJoystick;

    /* JADX INFO: renamed from: State$Float$arg-1$call-invoke$else$when$branch-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    private static State<Float> f1914State$Float$arg1$callinvoke$else$when$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;

    /* JADX INFO: renamed from: State$Int$arg-0$call-$init$$val-center$fun-Joystick, reason: not valid java name */
    private static State<Integer> f1915State$Int$arg0$call$init$$valcenter$funJoystick;

    /* JADX INFO: renamed from: State$Int$arg-0$call-RoundedCornerShape$val-circle$fun-Joystick, reason: not valid java name */
    private static State<Integer> f1916State$Int$arg0$callRoundedCornerShape$valcircle$funJoystick;

    /* JADX INFO: renamed from: State$Int$arg-0$call-div$$this$call-times$$this$call-toFloat$fun-toRadian, reason: not valid java name */
    private static State<Integer> f1917State$Int$arg0$calldiv$$this$calltimes$$this$calltoFloat$funtoRadian;

    /* JADX INFO: renamed from: State$Int$arg-0$call-div$arg-0$call-minus$val-radiusOffset$fun-changeJoystickPosition, reason: not valid java name */
    private static State<Integer> f1918State$Int$arg0$calldiv$arg0$callminus$valradiusOffset$funchangeJoystickPosition;

    /* JADX INFO: renamed from: State$Int$arg-0$call-div$val-radius$fun-$anonymous$$arg-0$call-onGloballyPositioned$$$this$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    private static State<Integer> f1919State$Int$arg0$calldiv$valradius$fun$anonymous$$arg0$callonGloballyPositioned$$$this$callpointerInteropFilter$valtmp1_modifier$funJoystick;

    /* JADX INFO: renamed from: State$Int$arg-0$call-pow$$this$call-plus$arg-0$call-sqrt$val-hypotenuse$fun-changeJoystickPosition, reason: not valid java name */
    private static State<Integer> f1920State$Int$arg0$callpow$$this$callplus$arg0$callsqrt$valhypotenuse$funchangeJoystickPosition;

    /* JADX INFO: renamed from: State$Int$arg-0$call-pow$arg-0$call-plus$arg-0$call-sqrt$val-hypotenuse$fun-changeJoystickPosition, reason: not valid java name */
    private static State<Integer> f1921State$Int$arg0$callpow$arg0$callplus$arg0$callsqrt$valhypotenuse$funchangeJoystickPosition;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Center, reason: not valid java name */
    private static State<Integer> f1922State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCenter;

    /* JADX INFO: renamed from: State$Int$arg-1$call-$init$$val-center$fun-Joystick, reason: not valid java name */
    private static State<Integer> f1923State$Int$arg1$call$init$$valcenter$funJoystick;

    /* JADX INFO: renamed from: State$Int$val-smallCircleDiameter$fun-Joystick, reason: not valid java name */
    private static State<Integer> f1924State$Int$valsmallCircleDiameter$funJoystick;

    /* JADX INFO: renamed from: State$String$0$str$fun-toString$class-Center, reason: not valid java name */
    private static State<String> f1925State$String$0$str$funtoString$classCenter;

    /* JADX INFO: renamed from: State$String$1$str$fun-toString$class-Center, reason: not valid java name */
    private static State<String> f1926State$String$1$str$funtoString$classCenter;

    /* JADX INFO: renamed from: State$String$3$str$fun-toString$class-Center, reason: not valid java name */
    private static State<String> f1927State$String$3$str$funtoString$classCenter;

    /* JADX INFO: renamed from: State$String$4$str$fun-toString$class-Center, reason: not valid java name */
    private static State<String> f1928State$String$4$str$funtoString$classCenter;

    /* JADX INFO: renamed from: State$String$6$str$fun-toString$class-Center, reason: not valid java name */
    private static State<String> f1929State$String$6$str$funtoString$classCenter;
    public static final LiveLiterals$JoystickKt INSTANCE = new LiveLiterals$JoystickKt();

    /* JADX INFO: renamed from: Float$$this$call-div$val-smallCircle$fun-Joystick, reason: not valid java name */
    private static float f1872Float$$this$calldiv$valsmallCircle$funJoystick = 1.0f;

    /* JADX INFO: renamed from: Float$arg-0$call-div$val-smallCircle$fun-Joystick, reason: not valid java name */
    private static float f1877Float$arg0$calldiv$valsmallCircle$funJoystick = 5.0f;

    /* JADX INFO: renamed from: Int$arg-0$call-RoundedCornerShape$val-circle$fun-Joystick, reason: not valid java name */
    private static int f1883Int$arg0$callRoundedCornerShape$valcircle$funJoystick = 50;

    /* JADX INFO: renamed from: Float$arg-0$call-aspectRatio$$$this$call-background$$$this$call-onGloballyPositioned$$$this$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    private static float f1875Float$arg0$callaspectRatio$$$this$callbackground$$$this$callonGloballyPositioned$$$this$callpointerInteropFilter$valtmp1_modifier$funJoystick = 1.0f;

    /* JADX INFO: renamed from: Int$arg-0$call-div$val-radius$fun-$anonymous$$arg-0$call-onGloballyPositioned$$$this$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    private static int f1886Int$arg0$calldiv$valradius$fun$anonymous$$arg0$callonGloballyPositioned$$$this$callpointerInteropFilter$valtmp1_modifier$funJoystick = 2;

    /* JADX INFO: renamed from: Boolean$branch$when$cond$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    private static boolean f1860Boolean$branch$when$cond$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick = true;

    /* JADX INFO: renamed from: Boolean$branch$when$cond$when$cond-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    private static boolean f1859Boolean$branch$when$cond$when$cond1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick = true;

    /* JADX INFO: renamed from: Boolean$branch$when$cond-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    private static boolean f1861Boolean$branch$when$cond1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick = true;

    /* JADX INFO: renamed from: Boolean$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    private static boolean f1866Boolean$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick = true;

    /* JADX INFO: renamed from: Float$arg-0$call-aspectRatio$$$this$call-background$$$this$call-onGloballyPositioned$arg-0$call-Box$fun-$anonymous$$arg-3$call-Box$fun-Joystick, reason: not valid java name */
    private static float f1876Float$arg0$callaspectRatio$$$this$callbackground$$$this$callonGloballyPositioned$arg0$callBox$fun$anonymous$$arg3$callBox$funJoystick = 1.0f;

    /* JADX INFO: renamed from: Float$$$this$call-toRadian$$this$call-minus$branch$when$fun-getAngle, reason: not valid java name */
    private static float f1868Float$$$this$calltoRadian$$this$callminus$branch$when$fungetAngle = 90.0f;

    /* JADX INFO: renamed from: Float$$$this$call-toRadian$$this$call-plus$branch-1$when$fun-getAngle, reason: not valid java name */
    private static float f1870Float$$$this$calltoRadian$$this$callplus$branch1$when$fungetAngle = 90.0f;

    /* JADX INFO: renamed from: Float$$$this$call-toRadian$$this$call-minus$branch-2$when$fun-getAngle, reason: not valid java name */
    private static float f1869Float$$$this$calltoRadian$$this$callminus$branch2$when$fungetAngle = 270.0f;

    /* JADX INFO: renamed from: Float$$$this$call-toRadian$$this$call-plus$else$when$fun-getAngle, reason: not valid java name */
    private static float f1871Float$$$this$calltoRadian$$this$callplus$else$when$fungetAngle = 270.0f;

    /* JADX INFO: renamed from: Int$arg-0$call-div$$this$call-times$$this$call-toFloat$fun-toRadian, reason: not valid java name */
    private static int f1884Int$arg0$calldiv$$this$calltimes$$this$calltoFloat$funtoRadian = 180;

    /* JADX INFO: renamed from: Int$arg-0$call-pow$$this$call-plus$arg-0$call-sqrt$val-hypotenuse$fun-changeJoystickPosition, reason: not valid java name */
    private static int f1887Int$arg0$callpow$$this$callplus$arg0$callsqrt$valhypotenuse$funchangeJoystickPosition = 2;

    /* JADX INFO: renamed from: Int$arg-0$call-pow$arg-0$call-plus$arg-0$call-sqrt$val-hypotenuse$fun-changeJoystickPosition, reason: not valid java name */
    private static int f1888Int$arg0$callpow$arg0$callplus$arg0$callsqrt$valhypotenuse$funchangeJoystickPosition = 2;

    /* JADX INFO: renamed from: Int$arg-0$call-div$arg-0$call-minus$val-radiusOffset$fun-changeJoystickPosition, reason: not valid java name */
    private static int f1885Int$arg0$calldiv$arg0$callminus$valradiusOffset$funchangeJoystickPosition = 2;

    /* JADX INFO: renamed from: String$0$str$fun-toString$class-Center, reason: not valid java name */
    private static String f1930String$0$str$funtoString$classCenter = "Center(";

    /* JADX INFO: renamed from: String$1$str$fun-toString$class-Center, reason: not valid java name */
    private static String f1931String$1$str$funtoString$classCenter = "x=";

    /* JADX INFO: renamed from: String$3$str$fun-toString$class-Center, reason: not valid java name */
    private static String f1932String$3$str$funtoString$classCenter = ", ";

    /* JADX INFO: renamed from: String$4$str$fun-toString$class-Center, reason: not valid java name */
    private static String f1933String$4$str$funtoString$classCenter = "y=";

    /* JADX INFO: renamed from: String$6$str$fun-toString$class-Center, reason: not valid java name */
    private static String f1934String$6$str$funtoString$classCenter = ")";

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Center, reason: not valid java name */
    private static int f1889Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCenter = 31;

    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-Center, reason: not valid java name */
    private static boolean f1862Boolean$branch$when$funequals$classCenter = true;

    /* JADX INFO: renamed from: Boolean$fun-equals$class-Center, reason: not valid java name */
    private static boolean f1867Boolean$funequals$classCenter = true;

    @LiveLiteralInfo(key = "Boolean$branch$when$cond$when$cond-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick", offset = 3032)
    /* JADX INFO: renamed from: Boolean$branch$when$cond$when$cond-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    public final boolean m6922Boolean$branch$when$cond$when$cond1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1859Boolean$branch$when$cond$when$cond1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;
        }
        State<Boolean> stateLiveLiteral = f1892State$Boolean$branch$when$cond$when$cond1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when$cond$when$cond-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick", Boolean.valueOf(f1859Boolean$branch$when$cond$when$cond1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick));
            f1892State$Boolean$branch$when$cond$when$cond1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when$cond$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick", offset = 2713)
    /* JADX INFO: renamed from: Boolean$branch$when$cond$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    public final boolean m6923Boolean$branch$when$cond$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1860Boolean$branch$when$cond$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;
        }
        State<Boolean> stateLiveLiteral = f1893State$Boolean$branch$when$cond$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when$cond$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick", Boolean.valueOf(f1860Boolean$branch$when$cond$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick));
            f1893State$Boolean$branch$when$cond$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when$cond-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick", offset = 3043)
    /* JADX INFO: renamed from: Boolean$branch$when$cond-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    public final boolean m6924Boolean$branch$when$cond1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1861Boolean$branch$when$cond1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;
        }
        State<Boolean> stateLiveLiteral = f1894State$Boolean$branch$when$cond1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when$cond-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick", Boolean.valueOf(f1861Boolean$branch$when$cond1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick));
            f1894State$Boolean$branch$when$cond1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when$fun-equals$class-Center", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-Center, reason: not valid java name */
    public final boolean m6925Boolean$branch$when$funequals$classCenter() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1862Boolean$branch$when$funequals$classCenter;
        }
        State<Boolean> stateLiveLiteral = f1895State$Boolean$branch$when$funequals$classCenter;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when$fun-equals$class-Center", Boolean.valueOf(f1862Boolean$branch$when$funequals$classCenter));
            f1895State$Boolean$branch$when$funequals$classCenter = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-1$fun-equals$class-Center", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-Center, reason: not valid java name */
    public final boolean m6926Boolean$branch$when1$funequals$classCenter() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1863Boolean$branch$when1$funequals$classCenter;
        }
        State<Boolean> stateLiveLiteral = f1896State$Boolean$branch$when1$funequals$classCenter;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-1$fun-equals$class-Center", Boolean.valueOf(f1863Boolean$branch$when1$funequals$classCenter));
            f1896State$Boolean$branch$when1$funequals$classCenter = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-2$fun-equals$class-Center", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-Center, reason: not valid java name */
    public final boolean m6927Boolean$branch$when2$funequals$classCenter() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1864Boolean$branch$when2$funequals$classCenter;
        }
        State<Boolean> stateLiveLiteral = f1897State$Boolean$branch$when2$funequals$classCenter;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-2$fun-equals$class-Center", Boolean.valueOf(f1864Boolean$branch$when2$funequals$classCenter));
            f1897State$Boolean$branch$when2$funequals$classCenter = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-3$fun-equals$class-Center", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-Center, reason: not valid java name */
    public final boolean m6928Boolean$branch$when3$funequals$classCenter() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1865Boolean$branch$when3$funequals$classCenter;
        }
        State<Boolean> stateLiveLiteral = f1898State$Boolean$branch$when3$funequals$classCenter;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-3$fun-equals$class-Center", Boolean.valueOf(f1865Boolean$branch$when3$funequals$classCenter));
            f1898State$Boolean$branch$when3$funequals$classCenter = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick", offset = 3286)
    /* JADX INFO: renamed from: Boolean$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    public final boolean m6929Boolean$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1866Boolean$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;
        }
        State<Boolean> stateLiveLiteral = f1899State$Boolean$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick", Boolean.valueOf(f1866Boolean$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick));
            f1899State$Boolean$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$fun-equals$class-Center", offset = -2)
    /* JADX INFO: renamed from: Boolean$fun-equals$class-Center, reason: not valid java name */
    public final boolean m6930Boolean$funequals$classCenter() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1867Boolean$funequals$classCenter;
        }
        State<Boolean> stateLiveLiteral = f1900State$Boolean$funequals$classCenter;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$fun-equals$class-Center", Boolean.valueOf(f1867Boolean$funequals$classCenter));
            f1900State$Boolean$funequals$classCenter = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Float$$$this$call-toRadian$$this$call-minus$branch$when$fun-getAngle", offset = 3895)
    /* JADX INFO: renamed from: Float$$$this$call-toRadian$$this$call-minus$branch$when$fun-getAngle, reason: not valid java name */
    public final float m6931Float$$$this$calltoRadian$$this$callminus$branch$when$fungetAngle() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1868Float$$$this$calltoRadian$$this$callminus$branch$when$fungetAngle;
        }
        State<Float> stateLiveLiteral = f1901State$Float$$$this$calltoRadian$$this$callminus$branch$when$fungetAngle;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$$$this$call-toRadian$$this$call-minus$branch$when$fun-getAngle", Float.valueOf(f1868Float$$$this$calltoRadian$$this$callminus$branch$when$fungetAngle));
            f1901State$Float$$$this$calltoRadian$$this$callminus$branch$when$fungetAngle = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$$$this$call-toRadian$$this$call-minus$branch-2$when$fun-getAngle", offset = 4029)
    /* JADX INFO: renamed from: Float$$$this$call-toRadian$$this$call-minus$branch-2$when$fun-getAngle, reason: not valid java name */
    public final float m6932Float$$$this$calltoRadian$$this$callminus$branch2$when$fungetAngle() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1869Float$$$this$calltoRadian$$this$callminus$branch2$when$fungetAngle;
        }
        State<Float> stateLiveLiteral = f1902State$Float$$$this$calltoRadian$$this$callminus$branch2$when$fungetAngle;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$$$this$call-toRadian$$this$call-minus$branch-2$when$fun-getAngle", Float.valueOf(f1869Float$$$this$calltoRadian$$this$callminus$branch2$when$fungetAngle));
            f1902State$Float$$$this$calltoRadian$$this$callminus$branch2$when$fungetAngle = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$$$this$call-toRadian$$this$call-plus$branch-1$when$fun-getAngle", offset = 3962)
    /* JADX INFO: renamed from: Float$$$this$call-toRadian$$this$call-plus$branch-1$when$fun-getAngle, reason: not valid java name */
    public final float m6933Float$$$this$calltoRadian$$this$callplus$branch1$when$fungetAngle() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1870Float$$$this$calltoRadian$$this$callplus$branch1$when$fungetAngle;
        }
        State<Float> stateLiveLiteral = f1903State$Float$$$this$calltoRadian$$this$callplus$branch1$when$fungetAngle;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$$$this$call-toRadian$$this$call-plus$branch-1$when$fun-getAngle", Float.valueOf(f1870Float$$$this$calltoRadian$$this$callplus$branch1$when$fungetAngle));
            f1903State$Float$$$this$calltoRadian$$this$callplus$branch1$when$fungetAngle = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$$$this$call-toRadian$$this$call-plus$else$when$fun-getAngle", offset = 4077)
    /* JADX INFO: renamed from: Float$$$this$call-toRadian$$this$call-plus$else$when$fun-getAngle, reason: not valid java name */
    public final float m6934Float$$$this$calltoRadian$$this$callplus$else$when$fungetAngle() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1871Float$$$this$calltoRadian$$this$callplus$else$when$fungetAngle;
        }
        State<Float> stateLiveLiteral = f1904State$Float$$$this$calltoRadian$$this$callplus$else$when$fungetAngle;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$$$this$call-toRadian$$this$call-plus$else$when$fun-getAngle", Float.valueOf(f1871Float$$$this$calltoRadian$$this$callplus$else$when$fungetAngle));
            f1904State$Float$$$this$calltoRadian$$this$callplus$else$when$fungetAngle = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$$this$call-div$val-smallCircle$fun-Joystick", offset = 2114)
    /* JADX INFO: renamed from: Float$$this$call-div$val-smallCircle$fun-Joystick, reason: not valid java name */
    public final float m6935Float$$this$calldiv$valsmallCircle$funJoystick() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1872Float$$this$calldiv$valsmallCircle$funJoystick;
        }
        State<Float> stateLiveLiteral = f1905State$Float$$this$calldiv$valsmallCircle$funJoystick;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$$this$call-div$val-smallCircle$fun-Joystick", Float.valueOf(f1872Float$$this$calldiv$valsmallCircle$funJoystick));
            f1905State$Float$$this$calldiv$valsmallCircle$funJoystick = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-$set-value$$branch-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick", offset = 3121)
    /* JADX INFO: renamed from: Float$arg-0$call-$set-value$$branch-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    public final float m6936Float$arg0$call$setvalue$$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1873Float$arg0$call$setvalue$$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;
        }
        State<Float> stateLiveLiteral = f1906State$Float$arg0$call$setvalue$$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-$set-value$$branch-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick", Float.valueOf(f1873Float$arg0$call$setvalue$$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick));
            f1906State$Float$arg0$call$setvalue$$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-$set-value$-1$branch-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick", offset = 3164)
    /* JADX INFO: renamed from: Float$arg-0$call-$set-value$-1$branch-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    public final float m6937Float$arg0$call$setvalue$1$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1874Float$arg0$call$setvalue$1$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;
        }
        State<Float> stateLiveLiteral = f1907State$Float$arg0$call$setvalue$1$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-$set-value$-1$branch-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick", Float.valueOf(f1874Float$arg0$call$setvalue$1$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick));
            f1907State$Float$arg0$call$setvalue$1$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-aspectRatio$$$this$call-background$$$this$call-onGloballyPositioned$$$this$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick", offset = 2397)
    /* JADX INFO: renamed from: Float$arg-0$call-aspectRatio$$$this$call-background$$$this$call-onGloballyPositioned$$$this$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    public final float m6938Float$arg0$callaspectRatio$$$this$callbackground$$$this$callonGloballyPositioned$$$this$callpointerInteropFilter$valtmp1_modifier$funJoystick() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1875Float$arg0$callaspectRatio$$$this$callbackground$$$this$callonGloballyPositioned$$$this$callpointerInteropFilter$valtmp1_modifier$funJoystick;
        }
        State<Float> stateLiveLiteral = f1908State$Float$arg0$callaspectRatio$$$this$callbackground$$$this$callonGloballyPositioned$$$this$callpointerInteropFilter$valtmp1_modifier$funJoystick;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-aspectRatio$$$this$call-background$$$this$call-onGloballyPositioned$$$this$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick", Float.valueOf(f1875Float$arg0$callaspectRatio$$$this$callbackground$$$this$callonGloballyPositioned$$$this$callpointerInteropFilter$valtmp1_modifier$funJoystick));
            f1908State$Float$arg0$callaspectRatio$$$this$callbackground$$$this$callonGloballyPositioned$$$this$callpointerInteropFilter$valtmp1_modifier$funJoystick = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-aspectRatio$$$this$call-background$$$this$call-onGloballyPositioned$arg-0$call-Box$fun-$anonymous$$arg-3$call-Box$fun-Joystick", offset = 3523)
    /* JADX INFO: renamed from: Float$arg-0$call-aspectRatio$$$this$call-background$$$this$call-onGloballyPositioned$arg-0$call-Box$fun-$anonymous$$arg-3$call-Box$fun-Joystick, reason: not valid java name */
    public final float m6939Float$arg0$callaspectRatio$$$this$callbackground$$$this$callonGloballyPositioned$arg0$callBox$fun$anonymous$$arg3$callBox$funJoystick() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1876Float$arg0$callaspectRatio$$$this$callbackground$$$this$callonGloballyPositioned$arg0$callBox$fun$anonymous$$arg3$callBox$funJoystick;
        }
        State<Float> stateLiveLiteral = f1909State$Float$arg0$callaspectRatio$$$this$callbackground$$$this$callonGloballyPositioned$arg0$callBox$fun$anonymous$$arg3$callBox$funJoystick;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-aspectRatio$$$this$call-background$$$this$call-onGloballyPositioned$arg-0$call-Box$fun-$anonymous$$arg-3$call-Box$fun-Joystick", Float.valueOf(f1876Float$arg0$callaspectRatio$$$this$callbackground$$$this$callonGloballyPositioned$arg0$callBox$fun$anonymous$$arg3$callBox$funJoystick));
            f1909State$Float$arg0$callaspectRatio$$$this$callbackground$$$this$callonGloballyPositioned$arg0$callBox$fun$anonymous$$arg3$callBox$funJoystick = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-div$val-smallCircle$fun-Joystick", offset = 2119)
    /* JADX INFO: renamed from: Float$arg-0$call-div$val-smallCircle$fun-Joystick, reason: not valid java name */
    public final float m6940Float$arg0$calldiv$valsmallCircle$funJoystick() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1877Float$arg0$calldiv$valsmallCircle$funJoystick;
        }
        State<Float> stateLiveLiteral = f1910State$Float$arg0$calldiv$valsmallCircle$funJoystick;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-div$val-smallCircle$fun-Joystick", Float.valueOf(f1877Float$arg0$calldiv$valsmallCircle$funJoystick));
            f1910State$Float$arg0$calldiv$valsmallCircle$funJoystick = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-invoke$else$when$branch-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick", offset = 3221)
    /* JADX INFO: renamed from: Float$arg-0$call-invoke$else$when$branch-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    public final float m6941Float$arg0$callinvoke$else$when$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1878Float$arg0$callinvoke$else$when$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;
        }
        State<Float> stateLiveLiteral = f1911State$Float$arg0$callinvoke$else$when$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-invoke$else$when$branch-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick", Float.valueOf(f1878Float$arg0$callinvoke$else$when$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick));
            f1911State$Float$arg0$callinvoke$else$when$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-mutableStateOf$fun-$anonymous$$arg-0$call-remember$val-offsetX$fun-Joystick", offset = 2206)
    /* JADX INFO: renamed from: Float$arg-0$call-mutableStateOf$fun-$anonymous$$arg-0$call-remember$val-offsetX$fun-Joystick, reason: not valid java name */
    public final float m6942Float$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valoffsetX$funJoystick() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1879Float$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valoffsetX$funJoystick;
        }
        State<Float> stateLiveLiteral = f1912State$Float$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valoffsetX$funJoystick;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-mutableStateOf$fun-$anonymous$$arg-0$call-remember$val-offsetX$fun-Joystick", Float.valueOf(f1879Float$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valoffsetX$funJoystick));
            f1912State$Float$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valoffsetX$funJoystick = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-mutableStateOf$fun-$anonymous$$arg-0$call-remember$val-offsetY$fun-Joystick", offset = 2256)
    /* JADX INFO: renamed from: Float$arg-0$call-mutableStateOf$fun-$anonymous$$arg-0$call-remember$val-offsetY$fun-Joystick, reason: not valid java name */
    public final float m6943Float$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valoffsetY$funJoystick() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1880Float$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valoffsetY$funJoystick;
        }
        State<Float> stateLiveLiteral = f1913State$Float$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valoffsetY$funJoystick;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-mutableStateOf$fun-$anonymous$$arg-0$call-remember$val-offsetY$fun-Joystick", Float.valueOf(f1880Float$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valoffsetY$funJoystick));
            f1913State$Float$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valoffsetY$funJoystick = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-1$call-invoke$else$when$branch-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick", offset = 3225)
    /* JADX INFO: renamed from: Float$arg-1$call-invoke$else$when$branch-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    public final float m6944Float$arg1$callinvoke$else$when$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1881Float$arg1$callinvoke$else$when$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;
        }
        State<Float> stateLiveLiteral = f1914State$Float$arg1$callinvoke$else$when$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-1$call-invoke$else$when$branch-1$when$fun-$anonymous$$arg-1$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick", Float.valueOf(f1881Float$arg1$callinvoke$else$when$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick));
            f1914State$Float$arg1$callinvoke$else$when$branch1$when$fun$anonymous$$arg1$callpointerInteropFilter$valtmp1_modifier$funJoystick = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-$init$$val-center$fun-Joystick", offset = 2085)
    /* JADX INFO: renamed from: Int$arg-0$call-$init$$val-center$fun-Joystick, reason: not valid java name */
    public final int m6945Int$arg0$call$init$$valcenter$funJoystick() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1882Int$arg0$call$init$$valcenter$funJoystick;
        }
        State<Integer> stateLiveLiteral = f1915State$Int$arg0$call$init$$valcenter$funJoystick;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-$init$$val-center$fun-Joystick", Integer.valueOf(f1882Int$arg0$call$init$$valcenter$funJoystick));
            f1915State$Int$arg0$call$init$$valcenter$funJoystick = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-RoundedCornerShape$val-circle$fun-Joystick", offset = 2158)
    /* JADX INFO: renamed from: Int$arg-0$call-RoundedCornerShape$val-circle$fun-Joystick, reason: not valid java name */
    public final int m6946Int$arg0$callRoundedCornerShape$valcircle$funJoystick() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1883Int$arg0$callRoundedCornerShape$valcircle$funJoystick;
        }
        State<Integer> stateLiveLiteral = f1916State$Int$arg0$callRoundedCornerShape$valcircle$funJoystick;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-RoundedCornerShape$val-circle$fun-Joystick", Integer.valueOf(f1883Int$arg0$callRoundedCornerShape$valcircle$funJoystick));
            f1916State$Int$arg0$callRoundedCornerShape$valcircle$funJoystick = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-div$$this$call-times$$this$call-toFloat$fun-toRadian", offset = 4157)
    /* JADX INFO: renamed from: Int$arg-0$call-div$$this$call-times$$this$call-toFloat$fun-toRadian, reason: not valid java name */
    public final int m6947Int$arg0$calldiv$$this$calltimes$$this$calltoFloat$funtoRadian() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1884Int$arg0$calldiv$$this$calltimes$$this$calltoFloat$funtoRadian;
        }
        State<Integer> stateLiveLiteral = f1917State$Int$arg0$calldiv$$this$calltimes$$this$calltoFloat$funtoRadian;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-div$$this$call-times$$this$call-toFloat$fun-toRadian", Integer.valueOf(f1884Int$arg0$calldiv$$this$calltimes$$this$calltoFloat$funtoRadian));
            f1917State$Int$arg0$calldiv$$this$calltimes$$this$calltoFloat$funtoRadian = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-div$arg-0$call-minus$val-radiusOffset$fun-changeJoystickPosition", offset = 4741)
    /* JADX INFO: renamed from: Int$arg-0$call-div$arg-0$call-minus$val-radiusOffset$fun-changeJoystickPosition, reason: not valid java name */
    public final int m6948Int$arg0$calldiv$arg0$callminus$valradiusOffset$funchangeJoystickPosition() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1885Int$arg0$calldiv$arg0$callminus$valradiusOffset$funchangeJoystickPosition;
        }
        State<Integer> stateLiveLiteral = f1918State$Int$arg0$calldiv$arg0$callminus$valradiusOffset$funchangeJoystickPosition;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-div$arg-0$call-minus$val-radiusOffset$fun-changeJoystickPosition", Integer.valueOf(f1885Int$arg0$calldiv$arg0$callminus$valradiusOffset$funchangeJoystickPosition));
            f1918State$Int$arg0$calldiv$arg0$callminus$valradiusOffset$funchangeJoystickPosition = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-div$val-radius$fun-$anonymous$$arg-0$call-onGloballyPositioned$$$this$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick", offset = 2556)
    /* JADX INFO: renamed from: Int$arg-0$call-div$val-radius$fun-$anonymous$$arg-0$call-onGloballyPositioned$$$this$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick, reason: not valid java name */
    public final int m6949Int$arg0$calldiv$valradius$fun$anonymous$$arg0$callonGloballyPositioned$$$this$callpointerInteropFilter$valtmp1_modifier$funJoystick() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1886Int$arg0$calldiv$valradius$fun$anonymous$$arg0$callonGloballyPositioned$$$this$callpointerInteropFilter$valtmp1_modifier$funJoystick;
        }
        State<Integer> stateLiveLiteral = f1919State$Int$arg0$calldiv$valradius$fun$anonymous$$arg0$callonGloballyPositioned$$$this$callpointerInteropFilter$valtmp1_modifier$funJoystick;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-div$val-radius$fun-$anonymous$$arg-0$call-onGloballyPositioned$$$this$call-pointerInteropFilter$val-tmp1_modifier$fun-Joystick", Integer.valueOf(f1886Int$arg0$calldiv$valradius$fun$anonymous$$arg0$callonGloballyPositioned$$$this$callpointerInteropFilter$valtmp1_modifier$funJoystick));
            f1919State$Int$arg0$calldiv$valradius$fun$anonymous$$arg0$callonGloballyPositioned$$$this$callpointerInteropFilter$valtmp1_modifier$funJoystick = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-pow$$this$call-plus$arg-0$call-sqrt$val-hypotenuse$fun-changeJoystickPosition", offset = 4616)
    /* JADX INFO: renamed from: Int$arg-0$call-pow$$this$call-plus$arg-0$call-sqrt$val-hypotenuse$fun-changeJoystickPosition, reason: not valid java name */
    public final int m6950Int$arg0$callpow$$this$callplus$arg0$callsqrt$valhypotenuse$funchangeJoystickPosition() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1887Int$arg0$callpow$$this$callplus$arg0$callsqrt$valhypotenuse$funchangeJoystickPosition;
        }
        State<Integer> stateLiveLiteral = f1920State$Int$arg0$callpow$$this$callplus$arg0$callsqrt$valhypotenuse$funchangeJoystickPosition;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-pow$$this$call-plus$arg-0$call-sqrt$val-hypotenuse$fun-changeJoystickPosition", Integer.valueOf(f1887Int$arg0$callpow$$this$callplus$arg0$callsqrt$valhypotenuse$funchangeJoystickPosition));
            f1920State$Int$arg0$callpow$$this$callplus$arg0$callsqrt$valhypotenuse$funchangeJoystickPosition = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-pow$arg-0$call-plus$arg-0$call-sqrt$val-hypotenuse$fun-changeJoystickPosition", offset = 4627)
    /* JADX INFO: renamed from: Int$arg-0$call-pow$arg-0$call-plus$arg-0$call-sqrt$val-hypotenuse$fun-changeJoystickPosition, reason: not valid java name */
    public final int m6951Int$arg0$callpow$arg0$callplus$arg0$callsqrt$valhypotenuse$funchangeJoystickPosition() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1888Int$arg0$callpow$arg0$callplus$arg0$callsqrt$valhypotenuse$funchangeJoystickPosition;
        }
        State<Integer> stateLiveLiteral = f1921State$Int$arg0$callpow$arg0$callplus$arg0$callsqrt$valhypotenuse$funchangeJoystickPosition;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-pow$arg-0$call-plus$arg-0$call-sqrt$val-hypotenuse$fun-changeJoystickPosition", Integer.valueOf(f1888Int$arg0$callpow$arg0$callplus$arg0$callsqrt$valhypotenuse$funchangeJoystickPosition));
            f1921State$Int$arg0$callpow$arg0$callplus$arg0$callsqrt$valhypotenuse$funchangeJoystickPosition = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Center", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Center, reason: not valid java name */
    public final int m6952Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCenter() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1889Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCenter;
        }
        State<Integer> stateLiveLiteral = f1922State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCenter;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Center", Integer.valueOf(f1889Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCenter));
            f1922State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classCenter = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-$init$$val-center$fun-Joystick", offset = 2088)
    /* JADX INFO: renamed from: Int$arg-1$call-$init$$val-center$fun-Joystick, reason: not valid java name */
    public final int m6953Int$arg1$call$init$$valcenter$funJoystick() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1890Int$arg1$call$init$$valcenter$funJoystick;
        }
        State<Integer> stateLiveLiteral = f1923State$Int$arg1$call$init$$valcenter$funJoystick;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-$init$$val-center$fun-Joystick", Integer.valueOf(f1890Int$arg1$call$init$$valcenter$funJoystick));
            f1923State$Int$arg1$call$init$$valcenter$funJoystick = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$val-smallCircleDiameter$fun-Joystick", offset = 2059)
    /* JADX INFO: renamed from: Int$val-smallCircleDiameter$fun-Joystick, reason: not valid java name */
    public final int m6954Int$valsmallCircleDiameter$funJoystick() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1891Int$valsmallCircleDiameter$funJoystick;
        }
        State<Integer> stateLiveLiteral = f1924State$Int$valsmallCircleDiameter$funJoystick;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$val-smallCircleDiameter$fun-Joystick", Integer.valueOf(f1891Int$valsmallCircleDiameter$funJoystick));
            f1924State$Int$valsmallCircleDiameter$funJoystick = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "String$0$str$fun-toString$class-Center", offset = -2)
    /* JADX INFO: renamed from: String$0$str$fun-toString$class-Center, reason: not valid java name */
    public final String m6955String$0$str$funtoString$classCenter() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1930String$0$str$funtoString$classCenter;
        }
        State<String> stateLiveLiteral = f1925State$String$0$str$funtoString$classCenter;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$fun-toString$class-Center", f1930String$0$str$funtoString$classCenter);
            f1925State$String$0$str$funtoString$classCenter = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$1$str$fun-toString$class-Center", offset = -2)
    /* JADX INFO: renamed from: String$1$str$fun-toString$class-Center, reason: not valid java name */
    public final String m6956String$1$str$funtoString$classCenter() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1931String$1$str$funtoString$classCenter;
        }
        State<String> stateLiveLiteral = f1926State$String$1$str$funtoString$classCenter;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$1$str$fun-toString$class-Center", f1931String$1$str$funtoString$classCenter);
            f1926State$String$1$str$funtoString$classCenter = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$3$str$fun-toString$class-Center", offset = -2)
    /* JADX INFO: renamed from: String$3$str$fun-toString$class-Center, reason: not valid java name */
    public final String m6957String$3$str$funtoString$classCenter() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1932String$3$str$funtoString$classCenter;
        }
        State<String> stateLiveLiteral = f1927State$String$3$str$funtoString$classCenter;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$3$str$fun-toString$class-Center", f1932String$3$str$funtoString$classCenter);
            f1927State$String$3$str$funtoString$classCenter = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$4$str$fun-toString$class-Center", offset = -2)
    /* JADX INFO: renamed from: String$4$str$fun-toString$class-Center, reason: not valid java name */
    public final String m6958String$4$str$funtoString$classCenter() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1933String$4$str$funtoString$classCenter;
        }
        State<String> stateLiveLiteral = f1928State$String$4$str$funtoString$classCenter;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$4$str$fun-toString$class-Center", f1933String$4$str$funtoString$classCenter);
            f1928State$String$4$str$funtoString$classCenter = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$6$str$fun-toString$class-Center", offset = -2)
    /* JADX INFO: renamed from: String$6$str$fun-toString$class-Center, reason: not valid java name */
    public final String m6959String$6$str$funtoString$classCenter() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1934String$6$str$funtoString$classCenter;
        }
        State<String> stateLiveLiteral = f1929State$String$6$str$funtoString$classCenter;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$6$str$fun-toString$class-Center", f1934String$6$str$funtoString$classCenter);
            f1929State$String$6$str$funtoString$classCenter = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
