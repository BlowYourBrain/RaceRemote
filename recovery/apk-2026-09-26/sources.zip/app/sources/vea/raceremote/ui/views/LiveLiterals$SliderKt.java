package vea.raceremote.ui.views;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: Slider.kt */
/* JADX INFO: loaded from: classes9.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/ui/views/Slider.kt")
public final class LiveLiterals$SliderKt {

    /* JADX INFO: renamed from: Int$class-Horizontal$class-Orientation, reason: not valid java name */
    private static int f1941Int$classHorizontal$classOrientation;

    /* JADX INFO: renamed from: Int$class-Orientation, reason: not valid java name */
    private static int f1942Int$classOrientation;

    /* JADX INFO: renamed from: Int$class-Vertical$class-Orientation, reason: not valid java name */
    private static int f1943Int$classVertical$classOrientation;

    /* JADX INFO: renamed from: State$Float$arg-0$call-weight$arg-0$call-paintContent$fun-$anonymous$$arg-3$call-Column$branch$when$fun-paintIcons, reason: not valid java name */
    private static State<Float> f1944State$Float$arg0$callweight$arg0$callpaintContent$fun$anonymous$$arg3$callColumn$branch$when$funpaintIcons;

    /* JADX INFO: renamed from: State$Float$arg-0$call-weight$arg-0$call-paintContent$fun-$anonymous$$arg-3$call-Row$branch-1$when$fun-paintIcons, reason: not valid java name */
    private static State<Float> f1945State$Float$arg0$callweight$arg0$callpaintContent$fun$anonymous$$arg3$callRow$branch1$when$funpaintIcons;

    /* JADX INFO: renamed from: State$Int$arg-0$call-div$val-halfHeight$fun-drawVertical, reason: not valid java name */
    private static State<Integer> f1946State$Int$arg0$calldiv$valhalfHeight$fundrawVertical;

    /* JADX INFO: renamed from: State$Int$arg-0$call-div$val-halfWidth$fun-drawHorizontal, reason: not valid java name */
    private static State<Integer> f1947State$Int$arg0$calldiv$valhalfWidth$fundrawHorizontal;

    /* JADX INFO: renamed from: State$Int$arg-0$call-div$val-horizontalCenter$branch$when$val-tmp1_container$fun-drawSeparator, reason: not valid java name */
    private static State<Integer> f1948State$Int$arg0$calldiv$valhorizontalCenter$branch$when$valtmp1_container$fundrawSeparator;

    /* JADX INFO: renamed from: State$Int$arg-0$call-div$val-verticalCenter$branch-1$when$val-tmp1_container$fun-drawSeparator, reason: not valid java name */
    private static State<Integer> f1949State$Int$arg0$calldiv$valverticalCenter$branch1$when$valtmp1_container$fundrawSeparator;

    /* JADX INFO: renamed from: State$Int$class-Horizontal$class-Orientation, reason: not valid java name */
    private static State<Integer> f1950State$Int$classHorizontal$classOrientation;

    /* JADX INFO: renamed from: State$Int$class-Orientation, reason: not valid java name */
    private static State<Integer> f1951State$Int$classOrientation;

    /* JADX INFO: renamed from: State$Int$class-Vertical$class-Orientation, reason: not valid java name */
    private static State<Integer> f1952State$Int$classVertical$classOrientation;

    /* JADX INFO: renamed from: State$String$fun-toString$class-Horizontal$class-Orientation, reason: not valid java name */
    private static State<String> f1953State$String$funtoString$classHorizontal$classOrientation;

    /* JADX INFO: renamed from: State$String$fun-toString$class-Vertical$class-Orientation, reason: not valid java name */
    private static State<String> f1954State$String$funtoString$classVertical$classOrientation;
    public static final LiveLiterals$SliderKt INSTANCE = new LiveLiterals$SliderKt();

    /* JADX INFO: renamed from: String$fun-toString$class-Horizontal$class-Orientation, reason: not valid java name */
    private static String f1955String$funtoString$classHorizontal$classOrientation = "Horizontal";

    /* JADX INFO: renamed from: String$fun-toString$class-Vertical$class-Orientation, reason: not valid java name */
    private static String f1956String$funtoString$classVertical$classOrientation = "Vertical";

    /* JADX INFO: renamed from: Float$arg-0$call-weight$arg-0$call-paintContent$fun-$anonymous$$arg-3$call-Column$branch$when$fun-paintIcons, reason: not valid java name */
    private static float f1935Float$arg0$callweight$arg0$callpaintContent$fun$anonymous$$arg3$callColumn$branch$when$funpaintIcons = 1.0f;

    /* JADX INFO: renamed from: Float$arg-0$call-weight$arg-0$call-paintContent$fun-$anonymous$$arg-3$call-Row$branch-1$when$fun-paintIcons, reason: not valid java name */
    private static float f1936Float$arg0$callweight$arg0$callpaintContent$fun$anonymous$$arg3$callRow$branch1$when$funpaintIcons = 1.0f;

    /* JADX INFO: renamed from: Int$arg-0$call-div$val-halfHeight$fun-drawVertical, reason: not valid java name */
    private static int f1937Int$arg0$calldiv$valhalfHeight$fundrawVertical = 2;

    /* JADX INFO: renamed from: Int$arg-0$call-div$val-halfWidth$fun-drawHorizontal, reason: not valid java name */
    private static int f1938Int$arg0$calldiv$valhalfWidth$fundrawHorizontal = 2;

    /* JADX INFO: renamed from: Int$arg-0$call-div$val-horizontalCenter$branch$when$val-tmp1_container$fun-drawSeparator, reason: not valid java name */
    private static int f1939Int$arg0$calldiv$valhorizontalCenter$branch$when$valtmp1_container$fundrawSeparator = 2;

    /* JADX INFO: renamed from: Int$arg-0$call-div$val-verticalCenter$branch-1$when$val-tmp1_container$fun-drawSeparator, reason: not valid java name */
    private static int f1940Int$arg0$calldiv$valverticalCenter$branch1$when$valtmp1_container$fundrawSeparator = 2;

    @LiveLiteralInfo(key = "Float$arg-0$call-weight$arg-0$call-paintContent$fun-$anonymous$$arg-3$call-Column$branch$when$fun-paintIcons", offset = 5746)
    /* JADX INFO: renamed from: Float$arg-0$call-weight$arg-0$call-paintContent$fun-$anonymous$$arg-3$call-Column$branch$when$fun-paintIcons, reason: not valid java name */
    public final float m6960Float$arg0$callweight$arg0$callpaintContent$fun$anonymous$$arg3$callColumn$branch$when$funpaintIcons() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1935Float$arg0$callweight$arg0$callpaintContent$fun$anonymous$$arg3$callColumn$branch$when$funpaintIcons;
        }
        State<Float> stateLiveLiteral = f1944State$Float$arg0$callweight$arg0$callpaintContent$fun$anonymous$$arg3$callColumn$branch$when$funpaintIcons;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-weight$arg-0$call-paintContent$fun-$anonymous$$arg-3$call-Column$branch$when$fun-paintIcons", Float.valueOf(f1935Float$arg0$callweight$arg0$callpaintContent$fun$anonymous$$arg3$callColumn$branch$when$funpaintIcons));
            f1944State$Float$arg0$callweight$arg0$callpaintContent$fun$anonymous$$arg3$callColumn$branch$when$funpaintIcons = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-weight$arg-0$call-paintContent$fun-$anonymous$$arg-3$call-Row$branch-1$when$fun-paintIcons", offset = 6234)
    /* JADX INFO: renamed from: Float$arg-0$call-weight$arg-0$call-paintContent$fun-$anonymous$$arg-3$call-Row$branch-1$when$fun-paintIcons, reason: not valid java name */
    public final float m6961Float$arg0$callweight$arg0$callpaintContent$fun$anonymous$$arg3$callRow$branch1$when$funpaintIcons() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1936Float$arg0$callweight$arg0$callpaintContent$fun$anonymous$$arg3$callRow$branch1$when$funpaintIcons;
        }
        State<Float> stateLiveLiteral = f1945State$Float$arg0$callweight$arg0$callpaintContent$fun$anonymous$$arg3$callRow$branch1$when$funpaintIcons;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-weight$arg-0$call-paintContent$fun-$anonymous$$arg-3$call-Row$branch-1$when$fun-paintIcons", Float.valueOf(f1936Float$arg0$callweight$arg0$callpaintContent$fun$anonymous$$arg3$callRow$branch1$when$funpaintIcons));
            f1945State$Float$arg0$callweight$arg0$callpaintContent$fun$anonymous$$arg3$callRow$branch1$when$funpaintIcons = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-div$val-halfHeight$fun-drawVertical", offset = 7127)
    /* JADX INFO: renamed from: Int$arg-0$call-div$val-halfHeight$fun-drawVertical, reason: not valid java name */
    public final int m6962Int$arg0$calldiv$valhalfHeight$fundrawVertical() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1937Int$arg0$calldiv$valhalfHeight$fundrawVertical;
        }
        State<Integer> stateLiveLiteral = f1946State$Int$arg0$calldiv$valhalfHeight$fundrawVertical;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-div$val-halfHeight$fun-drawVertical", Integer.valueOf(f1937Int$arg0$calldiv$valhalfHeight$fundrawVertical));
            f1946State$Int$arg0$calldiv$valhalfHeight$fundrawVertical = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-div$val-halfWidth$fun-drawHorizontal", offset = 8380)
    /* JADX INFO: renamed from: Int$arg-0$call-div$val-halfWidth$fun-drawHorizontal, reason: not valid java name */
    public final int m6963Int$arg0$calldiv$valhalfWidth$fundrawHorizontal() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1938Int$arg0$calldiv$valhalfWidth$fundrawHorizontal;
        }
        State<Integer> stateLiveLiteral = f1947State$Int$arg0$calldiv$valhalfWidth$fundrawHorizontal;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-div$val-halfWidth$fun-drawHorizontal", Integer.valueOf(f1938Int$arg0$calldiv$valhalfWidth$fundrawHorizontal));
            f1947State$Int$arg0$calldiv$valhalfWidth$fundrawHorizontal = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-div$val-horizontalCenter$branch$when$val-tmp1_container$fun-drawSeparator", offset = 9570)
    /* JADX INFO: renamed from: Int$arg-0$call-div$val-horizontalCenter$branch$when$val-tmp1_container$fun-drawSeparator, reason: not valid java name */
    public final int m6964Int$arg0$calldiv$valhorizontalCenter$branch$when$valtmp1_container$fundrawSeparator() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1939Int$arg0$calldiv$valhorizontalCenter$branch$when$valtmp1_container$fundrawSeparator;
        }
        State<Integer> stateLiveLiteral = f1948State$Int$arg0$calldiv$valhorizontalCenter$branch$when$valtmp1_container$fundrawSeparator;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-div$val-horizontalCenter$branch$when$val-tmp1_container$fun-drawSeparator", Integer.valueOf(f1939Int$arg0$calldiv$valhorizontalCenter$branch$when$valtmp1_container$fundrawSeparator));
            f1948State$Int$arg0$calldiv$valhorizontalCenter$branch$when$valtmp1_container$fundrawSeparator = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-div$val-verticalCenter$branch-1$when$val-tmp1_container$fun-drawSeparator", offset = 9755)
    /* JADX INFO: renamed from: Int$arg-0$call-div$val-verticalCenter$branch-1$when$val-tmp1_container$fun-drawSeparator, reason: not valid java name */
    public final int m6965Int$arg0$calldiv$valverticalCenter$branch1$when$valtmp1_container$fundrawSeparator() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1940Int$arg0$calldiv$valverticalCenter$branch1$when$valtmp1_container$fundrawSeparator;
        }
        State<Integer> stateLiveLiteral = f1949State$Int$arg0$calldiv$valverticalCenter$branch1$when$valtmp1_container$fundrawSeparator;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-div$val-verticalCenter$branch-1$when$val-tmp1_container$fun-drawSeparator", Integer.valueOf(f1940Int$arg0$calldiv$valverticalCenter$branch1$when$valtmp1_container$fundrawSeparator));
            f1949State$Int$arg0$calldiv$valverticalCenter$branch1$when$valtmp1_container$fundrawSeparator = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-Horizontal$class-Orientation", offset = -1)
    /* JADX INFO: renamed from: Int$class-Horizontal$class-Orientation, reason: not valid java name */
    public final int m6966Int$classHorizontal$classOrientation() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1941Int$classHorizontal$classOrientation;
        }
        State<Integer> stateLiveLiteral = f1950State$Int$classHorizontal$classOrientation;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-Horizontal$class-Orientation", Integer.valueOf(f1941Int$classHorizontal$classOrientation));
            f1950State$Int$classHorizontal$classOrientation = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-Orientation", offset = -1)
    /* JADX INFO: renamed from: Int$class-Orientation, reason: not valid java name */
    public final int m6967Int$classOrientation() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1942Int$classOrientation;
        }
        State<Integer> stateLiveLiteral = f1951State$Int$classOrientation;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-Orientation", Integer.valueOf(f1942Int$classOrientation));
            f1951State$Int$classOrientation = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-Vertical$class-Orientation", offset = -1)
    /* JADX INFO: renamed from: Int$class-Vertical$class-Orientation, reason: not valid java name */
    public final int m6968Int$classVertical$classOrientation() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1943Int$classVertical$classOrientation;
        }
        State<Integer> stateLiveLiteral = f1952State$Int$classVertical$classOrientation;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-Vertical$class-Orientation", Integer.valueOf(f1943Int$classVertical$classOrientation));
            f1952State$Int$classVertical$classOrientation = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "String$fun-toString$class-Horizontal$class-Orientation", offset = 2230)
    /* JADX INFO: renamed from: String$fun-toString$class-Horizontal$class-Orientation, reason: not valid java name */
    public final String m6969String$funtoString$classHorizontal$classOrientation() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1955String$funtoString$classHorizontal$classOrientation;
        }
        State<String> stateLiveLiteral = f1953State$String$funtoString$classHorizontal$classOrientation;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$fun-toString$class-Horizontal$class-Orientation", f1955String$funtoString$classHorizontal$classOrientation);
            f1953State$String$funtoString$classHorizontal$classOrientation = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$fun-toString$class-Vertical$class-Orientation", offset = 2508)
    /* JADX INFO: renamed from: String$fun-toString$class-Vertical$class-Orientation, reason: not valid java name */
    public final String m6970String$funtoString$classVertical$classOrientation() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1956String$funtoString$classVertical$classOrientation;
        }
        State<String> stateLiveLiteral = f1954State$String$funtoString$classVertical$classOrientation;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$fun-toString$class-Vertical$class-Orientation", f1956String$funtoString$classVertical$classOrientation);
            f1954State$String$funtoString$classVertical$classOrientation = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
