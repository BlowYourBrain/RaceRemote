package vea.raceremote.ui.views;

import kotlin.Metadata;

/* JADX INFO: compiled from: Slider.kt */
/* JADX INFO: loaded from: classes9.dex */
@Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b7\u0018\u00002\u00020\u0001:\u0002\u0003\u0004B\u0007\b\u0004¢\u0006\u0002\u0010\u0002\u0082\u0001\u0002\u0005\u0006¨\u0006\u0007"}, d2 = {"Lvea/raceremote/ui/views/Orientation;", "", "()V", "Horizontal", "Vertical", "Lvea/raceremote/ui/views/Orientation$Horizontal;", "Lvea/raceremote/ui/views/Orientation$Vertical;", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public abstract class Orientation {
    public static final int $stable = LiveLiterals$SliderKt.INSTANCE.m6967Int$classOrientation();

    /* JADX INFO: compiled from: Slider.kt */
    @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\t\u001a\u00020\nH\u0016R\u0016\u0010\u0003\u001a\u00020\u00048\u0006X\u0087D¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u0016\u0010\u0007\u001a\u00020\u00048\u0006X\u0087D¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\u0006¨\u0006\u000b"}, d2 = {"Lvea/raceremote/ui/views/Orientation$Horizontal;", "Lvea/raceremote/ui/views/Orientation;", "()V", "iconLeft", "", "getIconLeft", "()I", "iconRight", "getIconRight", "toString", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class Horizontal extends Orientation {
        public static final Horizontal INSTANCE = new Horizontal();
        private static final int iconLeft = 2131165323;
        private static final int iconRight = 2131165324;
        public static final int $stable = LiveLiterals$SliderKt.INSTANCE.m6966Int$classHorizontal$classOrientation();

        private Horizontal() {
            super();
        }

        public final int getIconLeft() {
            return iconLeft;
        }

        public final int getIconRight() {
            return iconRight;
        }

        public String toString() {
            return LiveLiterals$SliderKt.INSTANCE.m6969String$funtoString$classHorizontal$classOrientation();
        }
    }

    private Orientation() {
    }

    /* JADX INFO: compiled from: Slider.kt */
    @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\t\u001a\u00020\nH\u0016R\u0016\u0010\u0003\u001a\u00020\u00048\u0006X\u0087D¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u0016\u0010\u0007\u001a\u00020\u00048\u0006X\u0087D¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\u0006¨\u0006\u000b"}, d2 = {"Lvea/raceremote/ui/views/Orientation$Vertical;", "Lvea/raceremote/ui/views/Orientation;", "()V", "iconDown", "", "getIconDown", "()I", "iconUp", "getIconUp", "toString", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class Vertical extends Orientation {
        public static final Vertical INSTANCE = new Vertical();
        private static final int iconUp = 2131165326;
        private static final int iconDown = 2131165325;
        public static final int $stable = LiveLiterals$SliderKt.INSTANCE.m6968Int$classVertical$classOrientation();

        private Vertical() {
            super();
        }

        public final int getIconUp() {
            return iconUp;
        }

        public final int getIconDown() {
            return iconDown;
        }

        public String toString() {
            return LiveLiterals$SliderKt.INSTANCE.m6970String$funtoString$classVertical$classOrientation();
        }
    }
}
