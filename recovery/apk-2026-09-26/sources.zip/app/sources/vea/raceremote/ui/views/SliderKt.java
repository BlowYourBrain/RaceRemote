package vea.raceremote.ui.views;

import androidx.compose.foundation.BackgroundKt;
import androidx.compose.foundation.CanvasKt;
import androidx.compose.foundation.ImageKt;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.material.MaterialTheme;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.ProvidableCompositionLocal;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.SkippableUpdater;
import androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.geometry.Offset;
import androidx.compose.ui.geometry.OffsetKt;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.graphics.ColorFilter;
import androidx.compose.ui.graphics.drawscope.DrawScope;
import androidx.compose.ui.input.pointer.PointerEvent;
import androidx.compose.ui.input.pointer.PointerEventKt;
import androidx.compose.ui.input.pointer.PointerInputChange;
import androidx.compose.ui.input.pointer.PointerInputScope;
import androidx.compose.ui.input.pointer.SuspendingPointerInputFilterKt;
import androidx.compose.ui.layout.ContentScale;
import androidx.compose.ui.layout.LayoutKt;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.platform.CompositionLocalsKt;
import androidx.compose.ui.platform.ViewConfiguration;
import androidx.compose.ui.res.PainterResources_androidKt;
import androidx.compose.ui.unit.Density;
import androidx.compose.ui.unit.LayoutDirection;
import java.util.List;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import vea.raceremote.ui.theme.Palette;
import vea.raceremote.ui.theme.Size;
import vea.raceremote.ui.theme.ThemeKt;
import vea.raceremote.utils.LogKt;

/* JADX INFO: compiled from: Slider.kt */
/* JADX INFO: loaded from: classes9.dex */
@Metadata(d1 = {"\u0000J\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\u0005\u001a/\u0010\u0005\u001a\u00020\u00062\b\b\u0002\u0010\u0007\u001a\u00020\b2\u0016\b\u0002\u0010\t\u001a\u0010\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\u0006\u0018\u00010\nH\u0007¢\u0006\u0002\u0010\u000b\u001a9\u0010\f\u001a\u00020\u00062\u0006\u0010\r\u001a\u00020\u000e2\b\b\u0001\u0010\u000f\u001a\u00020\u00102\b\b\u0001\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u0012\u001a\u00020\u0013H\u0003ø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b\u0014\u0010\u0015\u001a\r\u0010\u0016\u001a\u00020\u0006H\u0003¢\u0006\u0002\u0010\u0017\u001aO\u0010\u0018\u001a\u00020\u0006*\u00020\u00192\f\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u00010\u001b2\u0006\u0010\u001c\u001a\u00020\u00132\u0006\u0010\u001d\u001a\u00020\u00132\u0016\b\u0002\u0010\t\u001a\u0010\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\u0006\u0018\u00010\nH\u0002ø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b\u001e\u0010\u001f\u001a3\u0010 \u001a\u00020\u0006*\u00020\u00192\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\u001d\u001a\u00020\u00132\b\b\u0002\u0010!\u001a\u00020\u0001H\u0002ø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b\"\u0010#\u001aO\u0010$\u001a\u00020\u0006*\u00020\u00192\f\u0010%\u001a\b\u0012\u0004\u0012\u00020\u00010\u001b2\u0006\u0010&\u001a\u00020\u00132\u0006\u0010\u001d\u001a\u00020\u00132\u0016\b\u0002\u0010\t\u001a\u0010\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\u0006\u0018\u00010\nH\u0002ø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b'\u0010\u001f\u001a(\u0010(\u001a\u00020)*\u00020)2\f\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u00010\u001b2\f\u0010%\u001a\b\u0012\u0004\u0012\u00020\u00010\u001bH\u0002\u001a!\u0010*\u001a\u00020\u0006*\u00020\b2\u0006\u0010+\u001a\u00020\u0013H\u0003ø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b,\u0010-\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0003\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0004\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\u0082\u0002\u000b\n\u0005\b¡\u001e0\u0001\n\u0002\b\u0019¨\u0006."}, d2 = {"MAX", "", "MIN", "NO_OFFSET", "UNDEFINED", "Slider", "", "orientation", "Lvea/raceremote/ui/views/Orientation;", "onOffsetChange", "Lkotlin/Function1;", "(Lvea/raceremote/ui/views/Orientation;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V", "paintContent", "modifier", "Landroidx/compose/ui/Modifier;", "first", "", "second", "paintColor", "Landroidx/compose/ui/graphics/Color;", "paintContent-Bx497Mc", "(Landroidx/compose/ui/Modifier;IIJLandroidx/compose/runtime/Composer;I)V", "previewPaintIcons", "(Landroidx/compose/runtime/Composer;I)V", "drawHorizontal", "Landroidx/compose/ui/graphics/drawscope/DrawScope;", "x", "Landroidx/compose/runtime/MutableState;", "selectionColor", "separatorColor", "drawHorizontal-OoHUuok", "(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/runtime/MutableState;JJLkotlin/jvm/functions/Function1;)V", "drawSeparator", "separatorWidth", "drawSeparator-9LQNqLg", "(Landroidx/compose/ui/graphics/drawscope/DrawScope;Lvea/raceremote/ui/views/Orientation;JF)V", "drawVertical", "y", "onBackgroundColor", "drawVertical-OoHUuok", "onPointerInput", "Landroidx/compose/ui/input/pointer/PointerEvent;", "paintIcons", "iconColor", "paintIcons-RPmYEkk", "(Lvea/raceremote/ui/views/Orientation;JLandroidx/compose/runtime/Composer;I)V", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class SliderKt {
    private static final float MAX = 1.0f;
    private static final float MIN = -1.0f;
    private static final float NO_OFFSET = 0.0f;
    private static final float UNDEFINED = -1.0f;

    public static final void Slider(Orientation orientation, Function1<? super Float, Unit> function1, Composer $composer, final int $changed, final int i) {
        Orientation orientation2;
        Function1<? super Float, Unit> function2;
        final Orientation.Horizontal orientation3;
        final Function1<? super Float, Unit> function3;
        Object value$iv$iv;
        Object value$iv$iv2;
        Object value$iv$iv3;
        Object value$iv$iv4;
        Object value$iv$iv5;
        Object value$iv$iv6;
        Composer $composer2 = $composer.startRestartGroup(-193680244);
        ComposerKt.sourceInformation($composer2, "C(Slider)P(1)83@3308L38,84@3359L38,86@3421L25,87@3472L35,88@3528L37,89@3591L37,90@3652L48,96@3839L215,103@4061L527,92@3706L882,121@4606L21:Slider.kt#4usob5");
        int $dirty = $changed;
        int i2 = i & 1;
        if (i2 != 0) {
            $dirty |= 6;
            orientation2 = orientation;
        } else if (($changed & 14) == 0) {
            orientation2 = orientation;
            $dirty |= $composer2.changed(orientation2) ? 4 : 2;
        } else {
            orientation2 = orientation;
        }
        int i3 = i & 2;
        if (i3 != 0) {
            $dirty |= 48;
            function2 = function1;
        } else if (($changed & 112) == 0) {
            function2 = function1;
            $dirty |= $composer2.changed(function2) ? 32 : 16;
        } else {
            function2 = function1;
        }
        if (($dirty & 91) == 18 && $composer2.getSkipping()) {
            $composer2.skipToGroupEnd();
            orientation3 = orientation2;
            function3 = function2;
        } else {
            orientation3 = i2 != 0 ? Orientation.Horizontal.INSTANCE : orientation2;
            function3 = i3 != 0 ? null : function2;
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-193680244, $dirty, -1, "vea.raceremote.ui.views.Slider (Slider.kt:79)");
            }
            $composer2.startReplaceableGroup(-492369756);
            ComposerKt.sourceInformation($composer2, "C(remember):Composables.kt#9igjgp");
            Object value$iv$iv7 = $composer2.rememberedValue();
            if (value$iv$iv7 == Composer.INSTANCE.getEmpty()) {
                value$iv$iv7 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(Float.valueOf(-1.0f), null, 2, null);
                $composer2.updateRememberedValue(value$iv$iv7);
            }
            $composer2.endReplaceableGroup();
            final MutableState x = (MutableState) value$iv$iv7;
            $composer2.startReplaceableGroup(-492369756);
            ComposerKt.sourceInformation($composer2, "C(remember):Composables.kt#9igjgp");
            Object it$iv$iv = $composer2.rememberedValue();
            if (it$iv$iv == Composer.INSTANCE.getEmpty()) {
                value$iv$iv = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(Float.valueOf(-1.0f), null, 2, null);
                $composer2.updateRememberedValue(value$iv$iv);
            } else {
                value$iv$iv = it$iv$iv;
            }
            $composer2.endReplaceableGroup();
            final MutableState y = (MutableState) value$iv$iv;
            $composer2.startReplaceableGroup(-492369756);
            ComposerKt.sourceInformation($composer2, "C(remember):Composables.kt#9igjgp");
            Object it$iv$iv2 = $composer2.rememberedValue();
            if (it$iv$iv2 == Composer.INSTANCE.getEmpty()) {
                value$iv$iv2 = ThemeKt.getPalette$default(false, 1, null);
                $composer2.updateRememberedValue(value$iv$iv2);
            } else {
                value$iv$iv2 = it$iv$iv2;
            }
            $composer2.endReplaceableGroup();
            Palette palette = (Palette) value$iv$iv2;
            $composer2.startReplaceableGroup(-492369756);
            ComposerKt.sourceInformation($composer2, "C(remember):Composables.kt#9igjgp");
            Object it$iv$iv3 = $composer2.rememberedValue();
            if (it$iv$iv3 == Composer.INSTANCE.getEmpty()) {
                value$iv$iv3 = Color.m1651boximpl(palette.getColors().m985getSurface0d7_KjU());
                $composer2.updateRememberedValue(value$iv$iv3);
            } else {
                value$iv$iv3 = it$iv$iv3;
            }
            $composer2.endReplaceableGroup();
            final long selectionColor = ((Color) value$iv$iv3).m1671unboximpl();
            $composer2.startReplaceableGroup(-492369756);
            ComposerKt.sourceInformation($composer2, "C(remember):Composables.kt#9igjgp");
            Object it$iv$iv4 = $composer2.rememberedValue();
            if (it$iv$iv4 == Composer.INSTANCE.getEmpty()) {
                value$iv$iv4 = Color.m1651boximpl(palette.getColors().m980getOnSurface0d7_KjU());
                $composer2.updateRememberedValue(value$iv$iv4);
            } else {
                value$iv$iv4 = it$iv$iv4;
            }
            $composer2.endReplaceableGroup();
            long jM1671unboximpl = ((Color) value$iv$iv4).m1671unboximpl();
            $composer2.startReplaceableGroup(-492369756);
            ComposerKt.sourceInformation($composer2, "C(remember):Composables.kt#9igjgp");
            Object it$iv$iv5 = $composer2.rememberedValue();
            if (it$iv$iv5 == Composer.INSTANCE.getEmpty()) {
                value$iv$iv5 = Color.m1651boximpl(palette.getColors().m980getOnSurface0d7_KjU());
                $composer2.updateRememberedValue(value$iv$iv5);
            } else {
                value$iv$iv5 = it$iv$iv5;
            }
            $composer2.endReplaceableGroup();
            final long separatorColor = ((Color) value$iv$iv5).m1671unboximpl();
            $composer2.startReplaceableGroup(-492369756);
            ComposerKt.sourceInformation($composer2, "C(remember):Composables.kt#9igjgp");
            Object it$iv$iv6 = $composer2.rememberedValue();
            if (it$iv$iv6 == Composer.INSTANCE.getEmpty()) {
                value$iv$iv6 = Color.m1651boximpl(palette.getCustomColors().getSurfaceVariant());
                $composer2.updateRememberedValue(value$iv$iv6);
            } else {
                value$iv$iv6 = it$iv$iv6;
            }
            $composer2.endReplaceableGroup();
            long surfaceColor = ((Color) value$iv$iv6).m1671unboximpl();
            Modifier modifierM180backgroundbw27NRU$default = BackgroundKt.m180backgroundbw27NRU$default(SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null), surfaceColor, null, 2, null);
            Unit unit = Unit.INSTANCE;
            $composer2.startReplaceableGroup(511388516);
            ComposerKt.sourceInformation($composer2, "C(remember)P(1,2):Composables.kt#9igjgp");
            boolean invalid$iv$iv = $composer2.changed(x) | $composer2.changed(y);
            SliderKt$Slider$1$1 value$iv$iv8 = $composer2.rememberedValue();
            if (invalid$iv$iv || value$iv$iv8 == Composer.INSTANCE.getEmpty()) {
                value$iv$iv8 = new SliderKt$Slider$1$1(x, y, null);
                $composer2.updateRememberedValue(value$iv$iv8);
            }
            $composer2.endReplaceableGroup();
            Modifier modifierPointerInput = SuspendingPointerInputFilterKt.pointerInput(modifierM180backgroundbw27NRU$default, unit, (Function2<? super PointerInputScope, ? super Continuation<? super Unit>, ? extends Object>) value$iv$iv8);
            Object[] keys$iv = {orientation3, x, Color.m1651boximpl(selectionColor), Color.m1651boximpl(separatorColor), function3, y};
            $composer2.startReplaceableGroup(-568225417);
            ComposerKt.sourceInformation($composer2, "C(remember)P(1):Composables.kt#9igjgp");
            boolean invalid$iv = false;
            for (Object key$iv : keys$iv) {
                invalid$iv |= $composer2.changed(key$iv);
            }
            Object value$iv$iv9 = $composer2.rememberedValue();
            if (invalid$iv || value$iv$iv9 == Composer.INSTANCE.getEmpty()) {
                final Orientation orientation4 = orientation3;
                final Function1<? super Float, Unit> function4 = function3;
                value$iv$iv9 = new Function1<DrawScope, Unit>() { // from class: vea.raceremote.ui.views.SliderKt$Slider$2$1
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    /* JADX WARN: Multi-variable type inference failed */
                    {
                        super(1);
                    }

                    @Override // kotlin.jvm.functions.Function1
                    public /* bridge */ /* synthetic */ Unit invoke(DrawScope drawScope) {
                        invoke2(drawScope);
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2(DrawScope $this$Canvas) {
                        Intrinsics.checkNotNullParameter($this$Canvas, "$this$Canvas");
                        Orientation orientation5 = orientation4;
                        if (orientation5 instanceof Orientation.Horizontal) {
                            SliderKt.m6975drawHorizontalOoHUuok($this$Canvas, x, selectionColor, separatorColor, function4);
                        } else if (orientation5 instanceof Orientation.Vertical) {
                            SliderKt.m6979drawVerticalOoHUuok($this$Canvas, y, selectionColor, separatorColor, function4);
                        }
                    }
                };
                $composer2.updateRememberedValue(value$iv$iv9);
            }
            $composer2.endReplaceableGroup();
            CanvasKt.Canvas(modifierPointerInput, (Function1) value$iv$iv9, $composer2, 0);
            m6982paintIconsRPmYEkk(orientation3, jM1671unboximpl, $composer2, ($dirty & 14) | 48);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.ui.views.SliderKt.Slider.3
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i4) {
                SliderKt.Slider(orientation3, function3, composer, $changed | 1, i);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final PointerEvent onPointerInput(PointerEvent $this$onPointerInput, MutableState<Float> mutableState, MutableState<Float> mutableState2) {
        PointerInputChange $this$onPointerInput_u24lambda_u2410_u24lambda_u249 = (PointerInputChange) CollectionsKt.firstOrNull((List) $this$onPointerInput.getChanges());
        if ($this$onPointerInput_u24lambda_u2410_u24lambda_u249 != null) {
            LogKt.debug$default($this$onPointerInput_u24lambda_u2410_u24lambda_u249.toString(), null, 2, null);
            if (!$this$onPointerInput_u24lambda_u2410_u24lambda_u249.isConsumed()) {
                if ($this$onPointerInput_u24lambda_u2410_u24lambda_u249.getPressed()) {
                    mutableState.setValue(Float.valueOf(Offset.m1425getXimpl($this$onPointerInput_u24lambda_u2410_u24lambda_u249.getPosition())));
                    mutableState2.setValue(Float.valueOf(Offset.m1426getYimpl($this$onPointerInput_u24lambda_u2410_u24lambda_u249.getPosition())));
                } else {
                    mutableState.setValue(Float.valueOf(-1.0f));
                    mutableState2.setValue(Float.valueOf(-1.0f));
                }
                PointerEventKt.consumeDownChange($this$onPointerInput_u24lambda_u2410_u24lambda_u249);
            }
        }
        return $this$onPointerInput;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void previewPaintIcons(Composer $composer, final int $changed) {
        Composer $composer2 = $composer.startRestartGroup(-1376608742);
        ComposerKt.sourceInformation($composer2, "C(previewPaintIcons)148@5207L6,148@5182L45:Slider.kt#4usob5");
        if ($changed != 0 || !$composer2.getSkipping()) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1376608742, $changed, -1, "vea.raceremote.ui.views.previewPaintIcons (Slider.kt:147)");
            }
            m6982paintIconsRPmYEkk(Orientation.Horizontal.INSTANCE, MaterialTheme.INSTANCE.getColors($composer2, MaterialTheme.$stable).m976getOnBackground0d7_KjU(), $composer2, 6);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            $composer2.skipToGroupEnd();
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.ui.views.SliderKt.previewPaintIcons.1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i) {
                SliderKt.previewPaintIcons(composer, $changed | 1);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: paintIcons-RPmYEkk, reason: not valid java name */
    public static final void m6982paintIconsRPmYEkk(final Orientation $this$paintIcons_u2dRPmYEkk, final long iconColor, Composer $composer, final int $changed) {
        Composer $composer$iv;
        Composer $composer$iv2;
        Composer $composer2 = $composer.startRestartGroup(-493418965);
        ComposerKt.sourceInformation($composer2, "C(paintIcons)P(0:c#ui.graphics.Color):Slider.kt#4usob5");
        int $dirty = $changed;
        if (($changed & 14) == 0) {
            $dirty |= $composer2.changed($this$paintIcons_u2dRPmYEkk) ? 4 : 2;
        }
        if (($changed & 112) == 0) {
            $dirty |= $composer2.changed(iconColor) ? 32 : 16;
        }
        int $dirty2 = $dirty;
        if (($dirty2 & 91) != 18 || !$composer2.getSkipping()) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-493418965, $dirty2, -1, "vea.raceremote.ui.views.paintIcons (Slider.kt:152)");
            }
            Modifier containerModifier = SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null);
            Modifier iconModifier = SizeKt.m468size3ABfNKs(Modifier.INSTANCE, Size.INSTANCE.m6890getHugeIconD9Ej5fM());
            if ($this$paintIcons_u2dRPmYEkk instanceof Orientation.Vertical) {
                $composer2.startReplaceableGroup(-738378763);
                ComposerKt.sourceInformation($composer2, "160@5470L430");
                Arrangement.Vertical verticalArrangement$iv = Arrangement.INSTANCE.getCenter();
                Alignment.Horizontal horizontalAlignment$iv = Alignment.INSTANCE.getCenterHorizontally();
                $composer2.startReplaceableGroup(-483455358);
                ComposerKt.sourceInformation($composer2, "C(Column)P(2,3,1)77@3880L61,78@3946L133:Column.kt#2w3rfo");
                MeasurePolicy measurePolicy$iv = ColumnKt.columnMeasurePolicy(verticalArrangement$iv, horizontalAlignment$iv, $composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
                int $changed$iv$iv = (438 << 3) & 112;
                $composer2.startReplaceableGroup(-1323940314);
                ComposerKt.sourceInformation($composer2, "C(Layout)P(!1,2)74@2915L7,75@2970L7,76@3029L7,77@3041L460:Layout.kt#80mrfh");
                ProvidableCompositionLocal<Density> localDensity = CompositionLocalsKt.getLocalDensity();
                ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
                Object objConsume = $composer2.consume(localDensity);
                ComposerKt.sourceInformationMarkerEnd($composer2);
                Density density$iv$iv = (Density) objConsume;
                ProvidableCompositionLocal<LayoutDirection> localLayoutDirection = CompositionLocalsKt.getLocalLayoutDirection();
                ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
                Object objConsume2 = $composer2.consume(localLayoutDirection);
                ComposerKt.sourceInformationMarkerEnd($composer2);
                LayoutDirection layoutDirection$iv$iv = (LayoutDirection) objConsume2;
                ProvidableCompositionLocal<ViewConfiguration> localViewConfiguration = CompositionLocalsKt.getLocalViewConfiguration();
                ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
                Object objConsume3 = $composer2.consume(localViewConfiguration);
                ComposerKt.sourceInformationMarkerEnd($composer2);
                ViewConfiguration viewConfiguration$iv$iv = (ViewConfiguration) objConsume3;
                Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
                Function3<SkippableUpdater<ComposeUiNode>, Composer, Integer, Unit> function3MaterializerOf = LayoutKt.materializerOf(containerModifier);
                int $changed$iv$iv$iv = (($changed$iv$iv << 9) & 7168) | 6;
                if (!($composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                $composer2.startReusableNode();
                if ($composer2.getInserting()) {
                    $composer2.createNode(constructor);
                } else {
                    $composer2.useNode();
                }
                $composer2.disableReusing();
                Composer $this$Layout_u24lambda_u2d0$iv$iv = Updater.m1304constructorimpl($composer2);
                Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, measurePolicy$iv, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, density$iv$iv, ComposeUiNode.INSTANCE.getSetDensity());
                Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, layoutDirection$iv$iv, ComposeUiNode.INSTANCE.getSetLayoutDirection());
                Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, viewConfiguration$iv$iv, ComposeUiNode.INSTANCE.getSetViewConfiguration());
                $composer2.enableReusing();
                function3MaterializerOf.invoke(SkippableUpdater.m1294boximpl(SkippableUpdater.m1295constructorimpl($composer2)), $composer2, Integer.valueOf(($changed$iv$iv$iv >> 3) & 112));
                $composer2.startReplaceableGroup(2058660585);
                int $changed$iv = ($changed$iv$iv$iv >> 9) & 14;
                $composer2.startReplaceableGroup(-1163856341);
                ComposerKt.sourceInformation($composer2, "C79@3994L9:Column.kt#2w3rfo");
                if (($changed$iv & 11) == 2 && $composer2.getSkipping()) {
                    $composer2.skipToGroupEnd();
                    $composer$iv2 = $composer2;
                } else {
                    int i = ((438 >> 6) & 112) | 6;
                    ColumnScope $this$paintIcons_RPmYEkk_u24lambda_u2411 = ColumnScopeInstance.INSTANCE;
                    ComposerKt.sourceInformationMarkerStart($composer2, -1495371913, "C165@5681L205:Slider.kt#4usob5");
                    $composer$iv2 = $composer2;
                    m6981paintContentBx497Mc(ColumnScope.weight$default($this$paintIcons_RPmYEkk_u24lambda_u2411, iconModifier, LiveLiterals$SliderKt.INSTANCE.m6960Float$arg0$callweight$arg0$callpaintContent$fun$anonymous$$arg3$callColumn$branch$when$funpaintIcons(), false, 2, null), ((Orientation.Vertical) $this$paintIcons_u2dRPmYEkk).getIconUp(), ((Orientation.Vertical) $this$paintIcons_u2dRPmYEkk).getIconDown(), iconColor, $composer2, ($dirty2 << 6) & 7168);
                    ComposerKt.sourceInformationMarkerEnd($composer2);
                }
                $composer$iv2.endReplaceableGroup();
                $composer2.endReplaceableGroup();
                $composer2.endNode();
                $composer2.endReplaceableGroup();
                $composer2.endReplaceableGroup();
                $composer2.endReplaceableGroup();
            } else if ($this$paintIcons_u2dRPmYEkk instanceof Orientation.Horizontal) {
                $composer2.startReplaceableGroup(-738378270);
                ComposerKt.sourceInformation($composer2, "175@5963L428");
                Arrangement.Horizontal horizontalArrangement$iv = Arrangement.INSTANCE.getCenter();
                Alignment.Vertical verticalAlignment$iv = Alignment.INSTANCE.getCenterVertically();
                $composer2.startReplaceableGroup(693286680);
                ComposerKt.sourceInformation($composer2, "C(Row)P(2,1,3)78@3880L58,79@3943L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicy$iv2 = RowKt.rowMeasurePolicy(horizontalArrangement$iv, verticalAlignment$iv, $composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
                int $changed$iv$iv2 = (438 << 3) & 112;
                $composer2.startReplaceableGroup(-1323940314);
                ComposerKt.sourceInformation($composer2, "C(Layout)P(!1,2)74@2915L7,75@2970L7,76@3029L7,77@3041L460:Layout.kt#80mrfh");
                ProvidableCompositionLocal<Density> localDensity2 = CompositionLocalsKt.getLocalDensity();
                ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
                Object objConsume4 = $composer2.consume(localDensity2);
                ComposerKt.sourceInformationMarkerEnd($composer2);
                Density density$iv$iv2 = (Density) objConsume4;
                ProvidableCompositionLocal<LayoutDirection> localLayoutDirection2 = CompositionLocalsKt.getLocalLayoutDirection();
                ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
                Object objConsume5 = $composer2.consume(localLayoutDirection2);
                ComposerKt.sourceInformationMarkerEnd($composer2);
                LayoutDirection layoutDirection$iv$iv2 = (LayoutDirection) objConsume5;
                ProvidableCompositionLocal<ViewConfiguration> localViewConfiguration2 = CompositionLocalsKt.getLocalViewConfiguration();
                ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
                Object objConsume6 = $composer2.consume(localViewConfiguration2);
                ComposerKt.sourceInformationMarkerEnd($composer2);
                ViewConfiguration viewConfiguration$iv$iv2 = (ViewConfiguration) objConsume6;
                Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
                Function3<SkippableUpdater<ComposeUiNode>, Composer, Integer, Unit> function3MaterializerOf2 = LayoutKt.materializerOf(containerModifier);
                int $changed$iv$iv$iv2 = (($changed$iv$iv2 << 9) & 7168) | 6;
                if (!($composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                $composer2.startReusableNode();
                if ($composer2.getInserting()) {
                    $composer2.createNode(constructor2);
                } else {
                    $composer2.useNode();
                }
                $composer2.disableReusing();
                Composer $this$Layout_u24lambda_u2d0$iv$iv2 = Updater.m1304constructorimpl($composer2);
                Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv2, measurePolicy$iv2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv2, density$iv$iv2, ComposeUiNode.INSTANCE.getSetDensity());
                Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv2, layoutDirection$iv$iv2, ComposeUiNode.INSTANCE.getSetLayoutDirection());
                Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv2, viewConfiguration$iv$iv2, ComposeUiNode.INSTANCE.getSetViewConfiguration());
                $composer2.enableReusing();
                function3MaterializerOf2.invoke(SkippableUpdater.m1294boximpl(SkippableUpdater.m1295constructorimpl($composer2)), $composer2, Integer.valueOf(($changed$iv$iv$iv2 >> 3) & 112));
                $composer2.startReplaceableGroup(2058660585);
                int $changed$iv2 = ($changed$iv$iv$iv2 >> 9) & 14;
                $composer2.startReplaceableGroup(-678309503);
                ComposerKt.sourceInformation($composer2, "C80@3988L9:Row.kt#2w3rfo");
                if (($changed$iv2 & 11) == 2 && $composer2.getSkipping()) {
                    $composer2.skipToGroupEnd();
                    $composer$iv = $composer2;
                } else {
                    int i2 = ((438 >> 6) & 112) | 6;
                    RowScope $this$paintIcons_RPmYEkk_u24lambda_u2412 = RowScopeInstance.INSTANCE;
                    ComposerKt.sourceInformationMarkerStart($composer2, -1495371425, "C180@6169L208:Slider.kt#4usob5");
                    $composer$iv = $composer2;
                    m6981paintContentBx497Mc(RowScope.weight$default($this$paintIcons_RPmYEkk_u24lambda_u2412, iconModifier, LiveLiterals$SliderKt.INSTANCE.m6961Float$arg0$callweight$arg0$callpaintContent$fun$anonymous$$arg3$callRow$branch1$when$funpaintIcons(), false, 2, null), ((Orientation.Horizontal) $this$paintIcons_u2dRPmYEkk).getIconLeft(), ((Orientation.Horizontal) $this$paintIcons_u2dRPmYEkk).getIconRight(), iconColor, $composer2, ($dirty2 << 6) & 7168);
                    ComposerKt.sourceInformationMarkerEnd($composer2);
                }
                $composer$iv.endReplaceableGroup();
                $composer2.endReplaceableGroup();
                $composer2.endNode();
                $composer2.endReplaceableGroup();
                $composer2.endReplaceableGroup();
                $composer2.endReplaceableGroup();
            } else {
                $composer2.startReplaceableGroup(-738377812);
                $composer2.endReplaceableGroup();
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            $composer2.skipToGroupEnd();
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.ui.views.SliderKt$paintIcons$3
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i3) {
                SliderKt.m6982paintIconsRPmYEkk($this$paintIcons_u2dRPmYEkk, iconColor, composer, $changed | 1);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: paintContent-Bx497Mc, reason: not valid java name */
    public static final void m6981paintContentBx497Mc(final Modifier modifier, final int first, final int second, final long paintColor, Composer $composer, final int $changed) {
        Composer $composer2 = $composer.startRestartGroup(326087547);
        ComposerKt.sourceInformation($composer2, "C(paintContent)P(1!1,3,2:c#ui.graphics.Color)202@6662L27,200@6608L151,209@6819L28,207@6765L152:Slider.kt#4usob5");
        int $dirty = $changed;
        if (($changed & 14) == 0) {
            $dirty |= $composer2.changed(modifier) ? 4 : 2;
        }
        if (($changed & 112) == 0) {
            $dirty |= $composer2.changed(first) ? 32 : 16;
        }
        if (($changed & 896) == 0) {
            $dirty |= $composer2.changed(second) ? 256 : 128;
        }
        if (($changed & 7168) == 0) {
            $dirty |= $composer2.changed(paintColor) ? 2048 : 1024;
        }
        int $dirty2 = $dirty;
        if (($dirty2 & 5851) != 1170 || !$composer2.getSkipping()) {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(326087547, $dirty2, -1, "vea.raceremote.ui.views.paintContent (Slider.kt:192)");
            }
            ColorFilter color = ColorFilter.Companion.m1702tintxETnrds$default(ColorFilter.INSTANCE, paintColor, 0, 2, null);
            ImageKt.Image(PainterResources_androidKt.painterResource(first, $composer2, ($dirty2 >> 3) & 14), (String) null, modifier, (Alignment) null, (ContentScale) null, 0.0f, color, $composer2, (($dirty2 << 6) & 896) | 56, 56);
            ImageKt.Image(PainterResources_androidKt.painterResource(second, $composer2, ($dirty2 >> 6) & 14), (String) null, modifier, (Alignment) null, (ContentScale) null, 0.0f, color, $composer2, (($dirty2 << 6) & 896) | 56, 56);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        } else {
            $composer2.skipToGroupEnd();
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.ui.views.SliderKt$paintContent$1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i) {
                SliderKt.m6981paintContentBx497Mc(modifier, first, second, paintColor, composer, $changed | 1);
            }
        });
    }

    /* JADX INFO: renamed from: drawVertical-OoHUuok$default, reason: not valid java name */
    static /* synthetic */ void m6980drawVerticalOoHUuok$default(DrawScope drawScope, MutableState mutableState, long j, long j2, Function1 function1, int i, Object obj) {
        Function1 function2;
        if ((i & 8) == 0) {
            function2 = function1;
        } else {
            function2 = null;
        }
        m6979drawVerticalOoHUuok(drawScope, mutableState, j, j2, function2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: drawVertical-OoHUuok, reason: not valid java name */
    public static final void m6979drawVerticalOoHUuok(DrawScope $this$drawVertical_u2dOoHUuok, MutableState<Float> mutableState, long onBackgroundColor, long separatorColor, Function1<? super Float, Unit> function1) {
        float halfHeight = androidx.compose.ui.geometry.Size.m1491getHeightimpl($this$drawVertical_u2dOoHUuok.mo2155getSizeNHjbRc()) / LiveLiterals$SliderKt.INSTANCE.m6962Int$arg0$calldiv$valhalfHeight$fundrawVertical();
        float fMax = 0.0f;
        if (!(mutableState.getValue().floatValue() == -1.0f)) {
            if (mutableState.getValue().floatValue() < halfHeight) {
                float pointerOffset = Math.min(mutableState.getValue().floatValue() - halfHeight, 0.0f);
                DrawScope.m2150drawRectnJ9OG0$default($this$drawVertical_u2dOoHUuok, onBackgroundColor, OffsetKt.Offset(0.0f, halfHeight), androidx.compose.ui.geometry.SizeKt.Size(androidx.compose.ui.geometry.Size.m1494getWidthimpl($this$drawVertical_u2dOoHUuok.mo2155getSizeNHjbRc()), pointerOffset), 0.0f, null, null, 0, 120, null);
                fMax = Math.min(-(pointerOffset / halfHeight), 1.0f);
            } else {
                float pointerOffset2 = Math.max(mutableState.getValue().floatValue() - halfHeight, -1.0f);
                DrawScope.m2150drawRectnJ9OG0$default($this$drawVertical_u2dOoHUuok, onBackgroundColor, OffsetKt.Offset(0.0f, halfHeight), androidx.compose.ui.geometry.SizeKt.Size(androidx.compose.ui.geometry.Size.m1494getWidthimpl($this$drawVertical_u2dOoHUuok.mo2155getSizeNHjbRc()), pointerOffset2), 0.0f, null, null, 0, 120, null);
                fMax = Math.max(-1.0f, -(pointerOffset2 / halfHeight));
            }
        }
        float update = fMax;
        if (function1 != null) {
            function1.invoke(Float.valueOf(update));
        }
        m6978drawSeparator9LQNqLg$default($this$drawVertical_u2dOoHUuok, Orientation.Vertical.INSTANCE, separatorColor, 0.0f, 4, null);
    }

    /* JADX INFO: renamed from: drawHorizontal-OoHUuok$default, reason: not valid java name */
    static /* synthetic */ void m6976drawHorizontalOoHUuok$default(DrawScope drawScope, MutableState mutableState, long j, long j2, Function1 function1, int i, Object obj) {
        Function1 function2;
        if ((i & 8) == 0) {
            function2 = function1;
        } else {
            function2 = null;
        }
        m6975drawHorizontalOoHUuok(drawScope, mutableState, j, j2, function2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: drawHorizontal-OoHUuok, reason: not valid java name */
    public static final void m6975drawHorizontalOoHUuok(DrawScope $this$drawHorizontal_u2dOoHUuok, MutableState<Float> mutableState, long selectionColor, long separatorColor, Function1<? super Float, Unit> function1) {
        float halfWidth = androidx.compose.ui.geometry.Size.m1494getWidthimpl($this$drawHorizontal_u2dOoHUuok.mo2155getSizeNHjbRc()) / LiveLiterals$SliderKt.INSTANCE.m6963Int$arg0$calldiv$valhalfWidth$fundrawHorizontal();
        float fMin = 0.0f;
        if (!(mutableState.getValue().floatValue() == -1.0f)) {
            if (mutableState.getValue().floatValue() < halfWidth) {
                float pointerOffset = Math.max(halfWidth - mutableState.getValue().floatValue(), 0.0f);
                DrawScope.m2150drawRectnJ9OG0$default($this$drawHorizontal_u2dOoHUuok, selectionColor, OffsetKt.Offset(mutableState.getValue().floatValue(), 0.0f), androidx.compose.ui.geometry.SizeKt.Size(pointerOffset, androidx.compose.ui.geometry.Size.m1491getHeightimpl($this$drawHorizontal_u2dOoHUuok.mo2155getSizeNHjbRc())), 0.0f, null, null, 0, 120, null);
                fMin = Math.max(-(pointerOffset / halfWidth), -1.0f);
            } else {
                float pointerOffset2 = Math.min(mutableState.getValue().floatValue() - halfWidth, halfWidth);
                DrawScope.m2150drawRectnJ9OG0$default($this$drawHorizontal_u2dOoHUuok, selectionColor, OffsetKt.Offset(halfWidth, 0.0f), androidx.compose.ui.geometry.SizeKt.Size(pointerOffset2, androidx.compose.ui.geometry.Size.m1491getHeightimpl($this$drawHorizontal_u2dOoHUuok.mo2155getSizeNHjbRc())), 0.0f, null, null, 0, 120, null);
                fMin = Math.min(pointerOffset2 / halfWidth, 1.0f);
            }
        }
        float update = fMin;
        if (function1 != null) {
            function1.invoke(Float.valueOf(update));
        }
        m6978drawSeparator9LQNqLg$default($this$drawHorizontal_u2dOoHUuok, Orientation.Horizontal.INSTANCE, separatorColor, 0.0f, 4, null);
    }

    /* JADX INFO: renamed from: drawSeparator-9LQNqLg$default, reason: not valid java name */
    static /* synthetic */ void m6978drawSeparator9LQNqLg$default(DrawScope drawScope, Orientation orientation, long j, float f, int i, Object obj) {
        if ((i & 4) != 0) {
            f = 4.0f;
        }
        m6977drawSeparator9LQNqLg(drawScope, orientation, j, f);
    }

    /* JADX INFO: renamed from: drawSeparator-9LQNqLg, reason: not valid java name */
    private static final void m6977drawSeparator9LQNqLg(DrawScope $this$drawSeparator_u2d9LQNqLg, Orientation orientation, long separatorColor, float separatorWidth) {
        Pair pair;
        if (orientation instanceof Orientation.Horizontal) {
            float horizontalCenter = androidx.compose.ui.geometry.Size.m1494getWidthimpl($this$drawSeparator_u2d9LQNqLg.mo2155getSizeNHjbRc()) / LiveLiterals$SliderKt.INSTANCE.m6964Int$arg0$calldiv$valhorizontalCenter$branch$when$valtmp1_container$fundrawSeparator();
            pair = TuplesKt.to(Offset.m1414boximpl(OffsetKt.Offset(horizontalCenter, 0.0f)), Offset.m1414boximpl(OffsetKt.Offset(horizontalCenter, androidx.compose.ui.geometry.Size.m1491getHeightimpl($this$drawSeparator_u2d9LQNqLg.mo2155getSizeNHjbRc()))));
        } else if (orientation instanceof Orientation.Vertical) {
            float verticalCenter = androidx.compose.ui.geometry.Size.m1491getHeightimpl($this$drawSeparator_u2d9LQNqLg.mo2155getSizeNHjbRc()) / LiveLiterals$SliderKt.INSTANCE.m6965Int$arg0$calldiv$valverticalCenter$branch1$when$valtmp1_container$fundrawSeparator();
            pair = TuplesKt.to(Offset.m1414boximpl(OffsetKt.Offset(0.0f, verticalCenter)), Offset.m1414boximpl(OffsetKt.Offset(androidx.compose.ui.geometry.Size.m1494getWidthimpl($this$drawSeparator_u2d9LQNqLg.mo2155getSizeNHjbRc()), verticalCenter)));
        } else {
            throw new NoWhenBranchMatchedException();
        }
        long start = ((Offset) pair.component1()).getPackedValue();
        long end = ((Offset) pair.component2()).getPackedValue();
        DrawScope.m2142drawLineNGM6Ib0$default($this$drawSeparator_u2d9LQNqLg, separatorColor, start, end, separatorWidth, 0, null, 0.0f, null, 0, 496, null);
    }
}
