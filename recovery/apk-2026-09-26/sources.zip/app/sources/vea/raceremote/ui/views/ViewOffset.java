package vea.raceremote.ui.views;

import kotlin.Metadata;

/* JADX INFO: compiled from: FlatLoadingWithContent.kt */
/* JADX INFO: loaded from: classes9.dex */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0006\b\u0002\u0018\u00002\u00020\u0001B\u0019\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003¢\u0006\u0002\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\u0007¨\u0006\t"}, d2 = {"Lvea/raceremote/ui/views/ViewOffset;", "", "initialOffset", "", "targetOffset", "(II)V", "getInitialOffset", "()I", "getTargetOffset", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class ViewOffset {
    private final int initialOffset;
    private final int targetOffset;

    /* JADX WARN: Illegal instructions before constructor call */
    public ViewOffset() {
        int i = 0;
        this(i, i, 3);
    }

    public ViewOffset(int initialOffset, int targetOffset) {
        this.initialOffset = initialOffset;
        this.targetOffset = targetOffset;
    }

    public final int getInitialOffset() {
        return this.initialOffset;
    }

    public final int getTargetOffset() {
        return this.targetOffset;
    }
}
