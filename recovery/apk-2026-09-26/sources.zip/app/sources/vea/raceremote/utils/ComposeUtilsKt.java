package vea.raceremote.utils;

import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.ProvidableCompositionLocal;
import androidx.compose.ui.input.pointer.AwaitPointerEventScope;
import androidx.compose.ui.input.pointer.PointerEventPass;
import androidx.compose.ui.platform.CompositionLocalsKt;
import androidx.compose.ui.unit.Density;
import androidx.compose.ui.unit.Dp;
import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.jvm.functions.Function1;

/* JADX INFO: compiled from: ComposeUtils.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u00008\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\u001a\u001d\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\u0007ø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b\u0004\u0010\u0005\u001a8\u0010\u0006\u001a\u00020\u0007*\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\n2\u0017\u0010\u000b\u001a\u0013\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u00070\f¢\u0006\u0002\b\u000eH\u0086@ø\u0001\u0001¢\u0006\u0002\u0010\u000f\u001a\u0014\u0010\u0010\u001a\u00020\u0003*\u00020\u0011H\u0007ø\u0001\u0001¢\u0006\u0002\u0010\u0012\u0082\u0002\u000b\n\u0005\b¡\u001e0\u0001\n\u0002\b\u0019¨\u0006\u0013"}, d2 = {"dpToSp", "Landroidx/compose/ui/unit/TextUnit;", "dp", "Landroidx/compose/ui/unit/Dp;", "dpToSp-8Feqmps", "(FLandroidx/compose/runtime/Composer;I)J", "awaitPointerEventInfinitely", "", "Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;", "pass", "Landroidx/compose/ui/input/pointer/PointerEventPass;", "block", "Lkotlin/Function1;", "Landroidx/compose/ui/input/pointer/PointerEvent;", "Lkotlin/ExtensionFunctionType;", "(Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;Landroidx/compose/ui/input/pointer/PointerEventPass;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "pxToDp", "", "(ILandroidx/compose/runtime/Composer;I)F", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class ComposeUtilsKt {

    /* JADX INFO: renamed from: vea.raceremote.utils.ComposeUtilsKt$awaitPointerEventInfinitely$1, reason: invalid class name */
    /* JADX INFO: compiled from: ComposeUtils.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "vea.raceremote.utils.ComposeUtilsKt", f = "ComposeUtils.kt", i = {0, 0, 0}, l = {22}, m = "awaitPointerEventInfinitely", n = {"$this$awaitPointerEventInfinitely", "pass", "block"}, s = {"L$0", "L$1", "L$2"})
    static final class AnonymousClass1 extends ContinuationImpl {
        Object L$0;
        Object L$1;
        Object L$2;
        int label;
        /* synthetic */ Object result;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return ComposeUtilsKt.awaitPointerEventInfinitely(null, null, null, this);
        }
    }

    /* JADX INFO: renamed from: dpToSp-8Feqmps, reason: not valid java name */
    public static final long m6983dpToSp8Feqmps(float dp, Composer $composer, int $changed) {
        $composer.startReplaceableGroup(86741224);
        ComposerKt.sourceInformation($composer, "C(dpToSp)P(0:c#ui.unit.Dp)*11@420L7:ComposeUtils.kt#ue36q2");
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventStart(86741224, $changed, -1, "vea.raceremote.utils.dpToSp (ComposeUtils.kt:11)");
        }
        ProvidableCompositionLocal<Density> localDensity = CompositionLocalsKt.getLocalDensity();
        ComposerKt.sourceInformationMarkerStart($composer, 2023513938, "C:CompositionLocal.kt#9igjgp");
        Object objConsume = $composer.consume(localDensity);
        ComposerKt.sourceInformationMarkerEnd($composer);
        Density $this$dpToSp_8Feqmps_u24lambda_u240 = (Density) objConsume;
        long jMo324toSp0xMU5do = $this$dpToSp_8Feqmps_u24lambda_u240.mo324toSp0xMU5do(dp);
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventEnd();
        }
        $composer.endReplaceableGroup();
        return jMo324toSp0xMU5do;
    }

    public static final float pxToDp(int $this$pxToDp, Composer $composer, int $changed) {
        $composer.startReplaceableGroup(1267577849);
        ComposerKt.sourceInformation($composer, "C(pxToDp)*14@500L7:ComposeUtils.kt#ue36q2");
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventStart(1267577849, $changed, -1, "vea.raceremote.utils.pxToDp (ComposeUtils.kt:14)");
        }
        ProvidableCompositionLocal<Density> localDensity = CompositionLocalsKt.getLocalDensity();
        ComposerKt.sourceInformationMarkerStart($composer, 2023513938, "C:CompositionLocal.kt#9igjgp");
        Object objConsume = $composer.consume(localDensity);
        ComposerKt.sourceInformationMarkerEnd($composer);
        float $this$dp$iv = $this$pxToDp / ((Density) objConsume).getDensity();
        float $this$dp$iv2 = Dp.m4046constructorimpl($this$dp$iv);
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventEnd();
        }
        $composer.endReplaceableGroup();
        return $this$dp$iv2;
    }

    /* JADX WARN: Code duplicated, block: B:16:0x0055 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:17:0x0056  */
    /* JADX WARN: Code duplicated, block: B:7:0x0014  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:17:0x0056 -> B:18:0x005a). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    public static final java.lang.Object awaitPointerEventInfinitely(androidx.compose.ui.input.pointer.AwaitPointerEventScope r5, androidx.compose.ui.input.pointer.PointerEventPass r6, kotlin.jvm.functions.Function1<? super androidx.compose.ui.input.pointer.PointerEvent, kotlin.Unit> r7, kotlin.coroutines.Continuation<? super kotlin.Unit> r8) {
        /*
            boolean r0 = r8 instanceof vea.raceremote.utils.ComposeUtilsKt.AnonymousClass1
            if (r0 == 0) goto L14
            r0 = r8
            vea.raceremote.utils.ComposeUtilsKt$awaitPointerEventInfinitely$1 r0 = (vea.raceremote.utils.ComposeUtilsKt.AnonymousClass1) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r1 = r1 & r2
            if (r1 == 0) goto L14
            int r8 = r0.label
            int r8 = r8 - r2
            r0.label = r8
            goto L19
        L14:
            vea.raceremote.utils.ComposeUtilsKt$awaitPointerEventInfinitely$1 r0 = new vea.raceremote.utils.ComposeUtilsKt$awaitPointerEventInfinitely$1
            r0.<init>(r8)
        L19:
            r8 = r0
            java.lang.Object r0 = r8.result
            java.lang.Object r1 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
            int r2 = r8.label
            switch(r2) {
                case 0: goto L3f;
                case 1: goto L2d;
                default: goto L25;
            }
        L25:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
            r5.<init>(r6)
            throw r5
        L2d:
            java.lang.Object r5 = r8.L$2
            kotlin.jvm.functions.Function1 r5 = (kotlin.jvm.functions.Function1) r5
            java.lang.Object r6 = r8.L$1
            androidx.compose.ui.input.pointer.PointerEventPass r6 = (androidx.compose.ui.input.pointer.PointerEventPass) r6
            java.lang.Object r7 = r8.L$0
            androidx.compose.ui.input.pointer.AwaitPointerEventScope r7 = (androidx.compose.ui.input.pointer.AwaitPointerEventScope) r7
            kotlin.ResultKt.throwOnFailure(r0)
            r2 = r1
            r1 = r0
            goto L5a
        L3f:
            kotlin.ResultKt.throwOnFailure(r0)
            r4 = r7
            r7 = r5
            r5 = r4
        L45:
            r8.L$0 = r7
            r8.L$1 = r6
            r8.L$2 = r5
            r2 = 1
            r8.label = r2
            java.lang.Object r2 = r7.awaitPointerEvent(r6, r8)
            if (r2 != r1) goto L56
            return r1
        L56:
            r4 = r1
            r1 = r0
            r0 = r2
            r2 = r4
        L5a:
            androidx.compose.ui.input.pointer.PointerEvent r0 = (androidx.compose.ui.input.pointer.PointerEvent) r0
            r3 = 0
            r5.invoke(r0)
            r0 = r1
            r1 = r2
            goto L45
        */
        throw new UnsupportedOperationException("Method not decompiled: vea.raceremote.utils.ComposeUtilsKt.awaitPointerEventInfinitely(androidx.compose.ui.input.pointer.AwaitPointerEventScope, androidx.compose.ui.input.pointer.PointerEventPass, kotlin.jvm.functions.Function1, kotlin.coroutines.Continuation):java.lang.Object");
    }

    public static /* synthetic */ Object awaitPointerEventInfinitely$default(AwaitPointerEventScope awaitPointerEventScope, PointerEventPass pointerEventPass, Function1 function1, Continuation continuation, int i, Object obj) {
        if ((i & 1) != 0) {
            pointerEventPass = PointerEventPass.Main;
        }
        return awaitPointerEventInfinitely(awaitPointerEventScope, pointerEventPass, function1, continuation);
    }
}
