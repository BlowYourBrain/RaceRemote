package vea.raceremote.utils;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.channels.BufferOverflow;
import kotlinx.coroutines.channels.Channel;
import kotlinx.coroutines.channels.ChannelKt;

/* JADX INFO: compiled from: Flow.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000\u0012\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a-\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u00022\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u0001H\u00022\b\b\u0002\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006¨\u0006\u0007"}, d2 = {"singleEventChannel", "Lkotlinx/coroutines/channels/Channel;", "T", "initial", "onBufferOverflow", "Lkotlinx/coroutines/channels/BufferOverflow;", "(Ljava/lang/Object;Lkotlinx/coroutines/channels/BufferOverflow;)Lkotlinx/coroutines/channels/Channel;", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class FlowKt {
    public static /* synthetic */ Channel singleEventChannel$default(Object obj, BufferOverflow bufferOverflow, int i, Object obj2) {
        if ((i & 1) != 0) {
            obj = null;
        }
        if ((i & 2) != 0) {
            bufferOverflow = BufferOverflow.DROP_OLDEST;
        }
        return singleEventChannel(obj, bufferOverflow);
    }

    public static final <T> Channel<T> singleEventChannel(T t, BufferOverflow onBufferOverflow) {
        Intrinsics.checkNotNullParameter(onBufferOverflow, "onBufferOverflow");
        Channel<T> channelChannel$default = ChannelKt.Channel$default(0, onBufferOverflow, null, 5, null);
        if (t != null) {
            channelChannel$default.mo5906trySendJP2dKIU(t);
        }
        return channelChannel$default;
    }
}
