package vea.raceremote.utils;

import android.content.IntentFilter;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: IntentFilter.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0002\b\u0002\u001a\u001f\u0010\u0000\u001a\u00020\u00012\u0012\u0010\u0002\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00040\u0003\"\u00020\u0004¢\u0006\u0002\u0010\u0005¨\u0006\u0006"}, d2 = {"intentFilterOf", "Landroid/content/IntentFilter;", "filter", "", "", "([Ljava/lang/String;)Landroid/content/IntentFilter;", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class IntentFilterKt {
    public static final IntentFilter intentFilterOf(String... filter) {
        Intrinsics.checkNotNullParameter(filter, "filter");
        IntentFilter $this$intentFilterOf_u24lambda_u241 = new IntentFilter();
        for (String str : filter) {
            $this$intentFilterOf_u24lambda_u241.addAction(str);
        }
        return $this$intentFilterOf_u24lambda_u241;
    }
}
