package vea.raceremote.utils;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: Permissions.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/utils/Permissions.kt")
public final class LiveLiterals$PermissionsKt {

    /* JADX INFO: renamed from: Boolean$set-hasPermissions$branch$if$body$loop$fun-hasPermissions, reason: not valid java name */
    private static boolean f1957Boolean$sethasPermissions$branch$if$body$loop$funhasPermissions;

    /* JADX INFO: renamed from: State$Boolean$set-hasPermissions$branch$if$body$loop$fun-hasPermissions, reason: not valid java name */
    private static State<Boolean> f1959State$Boolean$sethasPermissions$branch$if$body$loop$funhasPermissions;

    /* JADX INFO: renamed from: State$Boolean$val-hasPermissions$fun-hasPermissions, reason: not valid java name */
    private static State<Boolean> f1960State$Boolean$valhasPermissions$funhasPermissions;
    public static final LiveLiterals$PermissionsKt INSTANCE = new LiveLiterals$PermissionsKt();

    /* JADX INFO: renamed from: Boolean$val-hasPermissions$fun-hasPermissions, reason: not valid java name */
    private static boolean f1958Boolean$valhasPermissions$funhasPermissions = true;

    @LiveLiteralInfo(key = "Boolean$set-hasPermissions$branch$if$body$loop$fun-hasPermissions", offset = 512)
    /* JADX INFO: renamed from: Boolean$set-hasPermissions$branch$if$body$loop$fun-hasPermissions, reason: not valid java name */
    public final boolean m6984Boolean$sethasPermissions$branch$if$body$loop$funhasPermissions() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1957Boolean$sethasPermissions$branch$if$body$loop$funhasPermissions;
        }
        State<Boolean> stateLiveLiteral = f1959State$Boolean$sethasPermissions$branch$if$body$loop$funhasPermissions;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$set-hasPermissions$branch$if$body$loop$fun-hasPermissions", Boolean.valueOf(f1957Boolean$sethasPermissions$branch$if$body$loop$funhasPermissions));
            f1959State$Boolean$sethasPermissions$branch$if$body$loop$funhasPermissions = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$val-hasPermissions$fun-hasPermissions", offset = 409)
    /* JADX INFO: renamed from: Boolean$val-hasPermissions$fun-hasPermissions, reason: not valid java name */
    public final boolean m6985Boolean$valhasPermissions$funhasPermissions() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1958Boolean$valhasPermissions$funhasPermissions;
        }
        State<Boolean> stateLiveLiteral = f1960State$Boolean$valhasPermissions$funhasPermissions;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$val-hasPermissions$fun-hasPermissions", Boolean.valueOf(f1958Boolean$valhasPermissions$funhasPermissions));
            f1960State$Boolean$valhasPermissions$funhasPermissions = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }
}
