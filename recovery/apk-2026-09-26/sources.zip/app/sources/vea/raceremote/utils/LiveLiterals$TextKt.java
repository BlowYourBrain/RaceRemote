package vea.raceremote.utils;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: Text.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/utils/Text.kt")
public final class LiveLiterals$TextKt {
    public static final LiveLiterals$TextKt INSTANCE = new LiveLiterals$TextKt();

    /* JADX INFO: renamed from: Int$arg-1$call-setSpan$fun-$anonymous$$arg-0$call-apply$fun-setColor, reason: not valid java name */
    private static int f1961Int$arg1$callsetSpan$fun$anonymous$$arg0$callapply$funsetColor;

    /* JADX INFO: renamed from: State$Int$arg-1$call-setSpan$fun-$anonymous$$arg-0$call-apply$fun-setColor, reason: not valid java name */
    private static State<Integer> f1962State$Int$arg1$callsetSpan$fun$anonymous$$arg0$callapply$funsetColor;

    @LiveLiteralInfo(key = "Int$arg-1$call-setSpan$fun-$anonymous$$arg-0$call-apply$fun-setColor", offset = 266)
    /* JADX INFO: renamed from: Int$arg-1$call-setSpan$fun-$anonymous$$arg-0$call-apply$fun-setColor, reason: not valid java name */
    public final int m6986Int$arg1$callsetSpan$fun$anonymous$$arg0$callapply$funsetColor() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1961Int$arg1$callsetSpan$fun$anonymous$$arg0$callapply$funsetColor;
        }
        State<Integer> stateLiveLiteral = f1962State$Int$arg1$callsetSpan$fun$anonymous$$arg0$callapply$funsetColor;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-setSpan$fun-$anonymous$$arg-0$call-apply$fun-setColor", Integer.valueOf(f1961Int$arg1$callsetSpan$fun$anonymous$$arg0$callapply$funsetColor));
            f1962State$Int$arg1$callsetSpan$fun$anonymous$$arg0$callapply$funsetColor = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }
}
