package vea.raceremote.utils;

import android.util.Log;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Log.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000\u0010\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\u001a\u001a\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0001\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0006"}, d2 = {"TAG", "", "debug", "", "value", "tag", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class LogKt {
    private static final String TAG = "DEBUG_APP";

    public static /* synthetic */ void debug$default(String str, String str2, int i, Object obj) {
        if ((i & 2) != 0) {
            str2 = null;
        }
        debug(str, str2);
    }

    public static final void debug(String value, String tag) {
        Intrinsics.checkNotNullParameter(value, "value");
        Log.d(tag == null ? "DEBUG_APP" : tag, value);
    }
}
