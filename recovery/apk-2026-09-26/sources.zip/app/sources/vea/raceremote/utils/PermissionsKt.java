package vea.raceremote.utils;

import android.content.Context;
import androidx.core.content.ContextCompat;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Permissions.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000\u001a\n\u0000\n\u0002\u0010\u000b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010 \n\u0000\u001a\u0012\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u0004\u001a\u0018\u0010\u0005\u001a\u00020\u0001*\u00020\u00022\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00040\u0007¨\u0006\b"}, d2 = {"hasPermission", "", "Landroid/content/Context;", "permission", "", "hasPermissions", "permissions", "", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class PermissionsKt {
    public static final boolean hasPermission(Context $this$hasPermission, String permission) {
        Intrinsics.checkNotNullParameter($this$hasPermission, "<this>");
        Intrinsics.checkNotNullParameter(permission, "permission");
        return ContextCompat.checkSelfPermission($this$hasPermission, permission) == 0;
    }

    public static final boolean hasPermissions(Context $this$hasPermissions, List<String> list) {
        Intrinsics.checkNotNullParameter($this$hasPermissions, "<this>");
        Intrinsics.checkNotNullParameter(list, "permissions");
        boolean hasPermissions = LiveLiterals$PermissionsKt.INSTANCE.m6985Boolean$valhasPermissions$funhasPermissions();
        for (String perm : list) {
            if (!hasPermission($this$hasPermissions, perm)) {
                boolean hasPermissions2 = LiveLiterals$PermissionsKt.INSTANCE.m6984Boolean$sethasPermissions$branch$if$body$loop$funhasPermissions();
                return hasPermissions2;
            }
        }
        return hasPermissions;
    }
}
