package vea.raceremote.utils;

import android.text.Spannable;
import android.text.style.ForegroundColorSpan;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Text.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\u001a\u0014\u0010\u0000\u001a\u00020\u0001*\u00020\u00012\b\b\u0001\u0010\u0002\u001a\u00020\u0003¨\u0006\u0004"}, d2 = {"setColor", "Landroid/text/Spannable;", "color", "", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class TextKt {
    public static final Spannable setColor(Spannable $this$setColor, int color) {
        Intrinsics.checkNotNullParameter($this$setColor, "<this>");
        $this$setColor.setSpan(new ForegroundColorSpan(color), LiveLiterals$TextKt.INSTANCE.m6986Int$arg1$callsetSpan$fun$anonymous$$arg0$callapply$funsetColor(), $this$setColor.length(), 33);
        return $this$setColor;
    }
}
