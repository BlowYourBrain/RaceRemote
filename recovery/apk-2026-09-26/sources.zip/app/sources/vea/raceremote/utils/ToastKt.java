package vea.raceremote.utils;

import android.content.Context;
import android.widget.Toast;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Toast.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000\u0018\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\u001a\u001c\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u00042\b\b\u0002\u0010\u0005\u001a\u00020\u0006¨\u0006\u0007"}, d2 = {"toast", "", "Landroid/content/Context;", "message", "", "duration", "", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class ToastKt {
    public static /* synthetic */ void toast$default(Context context, String str, int i, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            i = 0;
        }
        toast(context, str, i);
    }

    public static final void toast(Context $this$toast, String message, int duration) {
        Intrinsics.checkNotNullParameter($this$toast, "<this>");
        Intrinsics.checkNotNullParameter(message, "message");
        Toast.makeText($this$toast, message, duration).show();
    }
}
