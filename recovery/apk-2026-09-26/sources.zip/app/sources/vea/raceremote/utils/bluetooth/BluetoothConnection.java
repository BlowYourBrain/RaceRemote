package vea.raceremote.utils.bluetooth;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.util.UUID;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.jvm.internal.Intrinsics;
import vea.raceremote.features.remote_control.utils.ICompoundCommandExtractor;
import vea.raceremote.utils.LogKt;

/* JADX INFO: compiled from: IBluetoothConnection.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\b\u0010\u000b\u001a\u00020\fH\u0016J)\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0014H\u0096@ø\u0001\u0000¢\u0006\u0002\u0010\u0015J\u0019\u0010\u0016\u001a\u00020\f2\u0006\u0010\u0017\u001a\u00020\u0018H\u0096@ø\u0001\u0000¢\u0006\u0002\u0010\u0019R\u0010\u0010\u0005\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u0007\u001a\u0004\u0018\u00010\b8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\t\u0010\n\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u001a"}, d2 = {"Lvea/raceremote/utils/bluetooth/BluetoothConnection;", "Lvea/raceremote/utils/bluetooth/IBluetoothConnection;", "compoundCommandExtractor", "Lvea/raceremote/features/remote_control/utils/ICompoundCommandExtractor;", "(Lvea/raceremote/features/remote_control/utils/ICompoundCommandExtractor;)V", "bluetoothSocket", "Landroid/bluetooth/BluetoothSocket;", "outputStream", "Ljava/io/OutputStream;", "getOutputStream", "()Ljava/io/OutputStream;", "closeConnection", "", "connectWithDevice", "Lvea/raceremote/utils/bluetooth/IBluetoothConnection$Connection;", "context", "Landroid/content/Context;", "macAddress", "", "uuid", "Ljava/util/UUID;", "(Landroid/content/Context;Ljava/lang/String;Ljava/util/UUID;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendMessage", "bytes", "", "(ILkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class BluetoothConnection implements IBluetoothConnection {
    public static final int $stable = LiveLiterals$IBluetoothConnectionKt.INSTANCE.m7005Int$classBluetoothConnection();
    private BluetoothSocket bluetoothSocket;
    private final ICompoundCommandExtractor compoundCommandExtractor;

    public BluetoothConnection(ICompoundCommandExtractor compoundCommandExtractor) {
        Intrinsics.checkNotNullParameter(compoundCommandExtractor, "compoundCommandExtractor");
        this.compoundCommandExtractor = compoundCommandExtractor;
    }

    private final OutputStream getOutputStream() {
        BluetoothSocket bluetoothSocket = this.bluetoothSocket;
        if (bluetoothSocket != null) {
            return bluetoothSocket.getOutputStream();
        }
        return null;
    }

    @Override // vea.raceremote.utils.bluetooth.IBluetoothConnection
    public Object connectWithDevice(Context context, String macAddress, UUID uuid, Continuation<? super IBluetoothConnection.Connection> continuation) throws IllegalAccessException, InvocationTargetException {
        Object objM4399constructorimpl;
        BluetoothAdapter bluetoothAdapter = BluetoothUtilsKt.getBluetoothAdapter(context);
        BluetoothDevice remoteDevice = bluetoothAdapter != null ? bluetoothAdapter.getRemoteDevice(macAddress) : null;
        if (remoteDevice == null) {
            return IBluetoothConnection.Connection.Error.INSTANCE;
        }
        Object objInvoke = remoteDevice.getClass().getMethod(LiveLiterals$IBluetoothConnectionKt.INSTANCE.m7013String$arg0$callgetMethod$$this$callinvoke$arg0$call$setbluetoothSocket$$funconnectWithDevice$classBluetoothConnection(), Integer.TYPE).invoke(remoteDevice, Boxing.boxInt(LiveLiterals$IBluetoothConnectionKt.INSTANCE.m7004Int$0$vararg$arg1$callinvoke$arg0$call$setbluetoothSocket$$funconnectWithDevice$classBluetoothConnection()));
        Intrinsics.checkNotNull(objInvoke, "null cannot be cast to non-null type android.bluetooth.BluetoothSocket");
        this.bluetoothSocket = (BluetoothSocket) objInvoke;
        try {
            Result.Companion companion = Result.INSTANCE;
            BluetoothSocket bluetoothSocket = this.bluetoothSocket;
            if (bluetoothSocket != null) {
                bluetoothSocket.connect();
            }
            LogKt.debug$default(LiveLiterals$IBluetoothConnectionKt.INSTANCE.m7009String$arg0$calldebug$fun$anonymous$$arg0$callrunCatching$$$this$callonFailure$$$this$callgetOrElse$funconnectWithDevice$classBluetoothConnection(), null, 2, null);
            String name = remoteDevice.getName();
            Intrinsics.checkNotNullExpressionValue(name, "remoteDevice.name");
            objM4399constructorimpl = Result.m4399constructorimpl(new IBluetoothConnection.Connection.Success(name));
        } catch (Throwable th) {
            Result.Companion companion2 = Result.INSTANCE;
            objM4399constructorimpl = Result.m4399constructorimpl(ResultKt.createFailure(th));
        }
        Throwable it = Result.m4402exceptionOrNullimpl(objM4399constructorimpl);
        if (it != null) {
            String localizedMessage = it.getLocalizedMessage();
            if (localizedMessage == null) {
                localizedMessage = "";
            }
            LogKt.debug$default(localizedMessage, null, 2, null);
            LogKt.debug$default(LiveLiterals$IBluetoothConnectionKt.INSTANCE.m7010String$arg0$calldebug1$fun$anonymous$$arg0$callonFailure$$$this$callgetOrElse$funconnectWithDevice$classBluetoothConnection(), null, 2, null);
        }
        if (Result.m4402exceptionOrNullimpl(objM4399constructorimpl) == null) {
            return objM4399constructorimpl;
        }
        return IBluetoothConnection.Connection.Error.INSTANCE;
    }

    @Override // vea.raceremote.utils.bluetooth.IBluetoothConnection
    public Object sendMessage(int bytes, Continuation<? super Unit> continuation) {
        Object objM4399constructorimpl;
        Unit unit;
        try {
            Result.Companion companion = Result.INSTANCE;
            OutputStream outputStream = getOutputStream();
            if (outputStream != null) {
                outputStream.write(this.compoundCommandExtractor.extractStartCommand(bytes));
            }
            OutputStream outputStream2 = getOutputStream();
            if (outputStream2 != null) {
                outputStream2.write(this.compoundCommandExtractor.extractEndCommand(bytes));
                unit = Unit.INSTANCE;
            } else {
                unit = null;
            }
            objM4399constructorimpl = Result.m4399constructorimpl(unit);
        } catch (Throwable th) {
            Result.Companion companion2 = Result.INSTANCE;
            objM4399constructorimpl = Result.m4399constructorimpl(ResultKt.createFailure(th));
        }
        Throwable it = Result.m4402exceptionOrNullimpl(objM4399constructorimpl);
        if (it != null) {
            LogKt.debug$default(it.toString(), null, 2, null);
            LogKt.debug$default(LiveLiterals$IBluetoothConnectionKt.INSTANCE.m7012String$arg0$calldebug1$fun$anonymous$$arg0$callonFailure$funsendMessage$classBluetoothConnection(), null, 2, null);
        }
        return Unit.INSTANCE;
    }

    @Override // vea.raceremote.utils.bluetooth.IBluetoothConnection
    public void closeConnection() {
        Object objM4399constructorimpl;
        Unit unit;
        try {
            Result.Companion companion = Result.INSTANCE;
            BluetoothSocket bluetoothSocket = this.bluetoothSocket;
            if (bluetoothSocket != null) {
                bluetoothSocket.close();
                unit = Unit.INSTANCE;
            } else {
                unit = null;
            }
            objM4399constructorimpl = Result.m4399constructorimpl(unit);
        } catch (Throwable th) {
            Result.Companion companion2 = Result.INSTANCE;
            objM4399constructorimpl = Result.m4399constructorimpl(ResultKt.createFailure(th));
        }
        Throwable it = Result.m4402exceptionOrNullimpl(objM4399constructorimpl);
        if (it != null) {
            LogKt.debug$default(it.toString(), null, 2, null);
            LogKt.debug$default(LiveLiterals$IBluetoothConnectionKt.INSTANCE.m7011String$arg0$calldebug1$fun$anonymous$$arg0$callonFailure$funcloseConnection$classBluetoothConnection(), null, 2, null);
        }
    }
}
