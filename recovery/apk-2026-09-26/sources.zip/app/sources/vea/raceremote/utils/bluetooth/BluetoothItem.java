package vea.raceremote.utils.bluetooth;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: BlutoothItem.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\f\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006¢\u0006\u0002\u0010\u0007J\t\u0010\f\u001a\u00020\u0003HÆ\u0003J\t\u0010\r\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000e\u001a\u00020\u0006HÆ\u0003J'\u0010\u000f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u0006HÆ\u0001J\u0013\u0010\u0010\u001a\u00020\u00062\b\u0010\u0011\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0012\u001a\u00020\u0013HÖ\u0001J\t\u0010\u0014\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\n¨\u0006\u0015"}, d2 = {"Lvea/raceremote/utils/bluetooth/BluetoothItem;", "", "name", "", "macAddress", "isPaired", "", "(Ljava/lang/String;Ljava/lang/String;Z)V", "()Z", "getMacAddress", "()Ljava/lang/String;", "getName", "component1", "component2", "component3", "copy", "equals", "other", "hashCode", "", "toString", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final /* data */ class BluetoothItem {
    public static final int $stable = LiveLiterals$BlutoothItemKt.INSTANCE.m6996Int$classBluetoothItem();
    private final boolean isPaired;
    private final String macAddress;
    private final String name;

    public static /* synthetic */ BluetoothItem copy$default(BluetoothItem bluetoothItem, String str, String str2, boolean z, int i, Object obj) {
        if ((i & 1) != 0) {
            str = bluetoothItem.name;
        }
        if ((i & 2) != 0) {
            str2 = bluetoothItem.macAddress;
        }
        if ((i & 4) != 0) {
            z = bluetoothItem.isPaired;
        }
        return bluetoothItem.copy(str, str2, z);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getName() {
        return this.name;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getMacAddress() {
        return this.macAddress;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final boolean getIsPaired() {
        return this.isPaired;
    }

    public final BluetoothItem copy(String name, String macAddress, boolean isPaired) {
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(macAddress, "macAddress");
        return new BluetoothItem(name, macAddress, isPaired);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return LiveLiterals$BlutoothItemKt.INSTANCE.m6988Boolean$branch$when$funequals$classBluetoothItem();
        }
        if (!(other instanceof BluetoothItem)) {
            return LiveLiterals$BlutoothItemKt.INSTANCE.m6989Boolean$branch$when1$funequals$classBluetoothItem();
        }
        BluetoothItem bluetoothItem = (BluetoothItem) other;
        if (!Intrinsics.areEqual(this.name, bluetoothItem.name)) {
            return LiveLiterals$BlutoothItemKt.INSTANCE.m6990Boolean$branch$when2$funequals$classBluetoothItem();
        }
        if (Intrinsics.areEqual(this.macAddress, bluetoothItem.macAddress)) {
            return this.isPaired != bluetoothItem.isPaired ? LiveLiterals$BlutoothItemKt.INSTANCE.m6992Boolean$branch$when4$funequals$classBluetoothItem() : LiveLiterals$BlutoothItemKt.INSTANCE.m6993Boolean$funequals$classBluetoothItem();
        }
        return LiveLiterals$BlutoothItemKt.INSTANCE.m6991Boolean$branch$when3$funequals$classBluetoothItem();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v5, types: [int] */
    /* JADX WARN: Type inference failed for: r2v3, types: [int] */
    /* JADX WARN: Type inference failed for: r2v4 */
    /* JADX WARN: Type inference failed for: r2v5 */
    public int hashCode() {
        int iM6995Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classBluetoothItem = LiveLiterals$BlutoothItemKt.INSTANCE.m6995Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classBluetoothItem() * ((LiveLiterals$BlutoothItemKt.INSTANCE.m6994Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classBluetoothItem() * this.name.hashCode()) + this.macAddress.hashCode());
        boolean z = this.isPaired;
        ?? r2 = z;
        if (z) {
            r2 = 1;
        }
        return iM6995Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classBluetoothItem + r2;
    }

    public String toString() {
        return LiveLiterals$BlutoothItemKt.INSTANCE.m6997String$0$str$funtoString$classBluetoothItem() + LiveLiterals$BlutoothItemKt.INSTANCE.m6998String$1$str$funtoString$classBluetoothItem() + this.name + LiveLiterals$BlutoothItemKt.INSTANCE.m6999String$3$str$funtoString$classBluetoothItem() + LiveLiterals$BlutoothItemKt.INSTANCE.m7000String$4$str$funtoString$classBluetoothItem() + this.macAddress + LiveLiterals$BlutoothItemKt.INSTANCE.m7001String$6$str$funtoString$classBluetoothItem() + LiveLiterals$BlutoothItemKt.INSTANCE.m7002String$7$str$funtoString$classBluetoothItem() + this.isPaired + LiveLiterals$BlutoothItemKt.INSTANCE.m7003String$9$str$funtoString$classBluetoothItem();
    }

    public BluetoothItem(String name, String macAddress, boolean isPaired) {
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(macAddress, "macAddress");
        this.name = name;
        this.macAddress = macAddress;
        this.isPaired = isPaired;
    }

    public final String getName() {
        return this.name;
    }

    public final String getMacAddress() {
        return this.macAddress;
    }

    public final boolean isPaired() {
        return this.isPaired;
    }
}
