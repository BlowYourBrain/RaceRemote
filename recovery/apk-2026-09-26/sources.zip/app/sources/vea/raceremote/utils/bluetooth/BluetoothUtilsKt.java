package vea.raceremote.utils.bluetooth;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import androidx.core.app.ActivityCompat;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import vea.raceremote.utils.PermissionsKt;

/* JADX INFO: compiled from: BluetoothUtils.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u00002\n\u0000\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\u001a\u0016\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b\u001a\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001\u001a\u000e\u0010\n\u001a\u0004\u0018\u00010\u000b*\u00020\fH\u0007\u001a\n\u0010\r\u001a\u00020\u000e*\u00020\f\u001a\n\u0010\u000f\u001a\u00020\u000e*\u00020\f\u001a\n\u0010\u0010\u001a\u00020\u000e*\u00020\f\"\u0014\u0010\u0000\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0011"}, d2 = {"BLUETOOTH_PERMISSIONS", "", "", "enableBluetooth", "", "requestCode", "", "activity", "Landroid/app/Activity;", "getBluetoothPermissions", "getBluetoothAdapter", "Landroid/bluetooth/BluetoothAdapter;", "Landroid/content/Context;", "hasBluetooth", "", "hasBluetoothPermissions", "isBluetoothEnabled", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class BluetoothUtilsKt {
    private static final List<String> BLUETOOTH_PERMISSIONS = CollectionsKt.listOf((Object[]) new String[]{"android.permission.BLUETOOTH", "android.permission.BLUETOOTH_ADMIN", "android.permission.BLUETOOTH_CONNECT"});

    public static final boolean hasBluetoothPermissions(Context $this$hasBluetoothPermissions) {
        Intrinsics.checkNotNullParameter($this$hasBluetoothPermissions, "<this>");
        return PermissionsKt.hasPermissions($this$hasBluetoothPermissions, getBluetoothPermissions());
    }

    public static final void enableBluetooth(int requestCode, Activity activity) {
        Intrinsics.checkNotNullParameter(activity, "activity");
        Intent enableBtIntent = new Intent("android.bluetooth.adapter.action.REQUEST_ENABLE");
        ActivityCompat.startActivityForResult(activity, enableBtIntent, requestCode, null);
    }

    public static final List<String> getBluetoothPermissions() {
        return BLUETOOTH_PERMISSIONS;
    }

    public static final boolean isBluetoothEnabled(Context $this$isBluetoothEnabled) {
        Intrinsics.checkNotNullParameter($this$isBluetoothEnabled, "<this>");
        BluetoothAdapter bluetoothAdapter = getBluetoothAdapter($this$isBluetoothEnabled);
        return bluetoothAdapter != null ? bluetoothAdapter.isEnabled() : LiveLiterals$BluetoothUtilsKt.INSTANCE.m6987Boolean$branch$when$funisBluetoothEnabled();
    }

    public static final boolean hasBluetooth(Context $this$hasBluetooth) {
        Intrinsics.checkNotNullParameter($this$hasBluetooth, "<this>");
        return $this$hasBluetooth.getPackageManager().hasSystemFeature("android.hardware.bluetooth");
    }

    public static final BluetoothAdapter getBluetoothAdapter(Context $this$getBluetoothAdapter) {
        Intrinsics.checkNotNullParameter($this$getBluetoothAdapter, "<this>");
        if (!hasBluetoothPermissions($this$getBluetoothAdapter)) {
            return null;
        }
        Object systemService = $this$getBluetoothAdapter.getSystemService("bluetooth");
        BluetoothManager bluetoothManager = systemService instanceof BluetoothManager ? (BluetoothManager) systemService : null;
        if (bluetoothManager != null) {
            return bluetoothManager.getAdapter();
        }
        return null;
    }
}
