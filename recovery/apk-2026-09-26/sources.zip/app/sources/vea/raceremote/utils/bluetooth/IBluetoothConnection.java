package vea.raceremote.utils.bluetooth;

import android.content.Context;
import java.util.UUID;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: IBluetoothConnection.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\bf\u0018\u00002\u00020\u0001:\u0001\u0011J\b\u0010\u0002\u001a\u00020\u0003H&J)\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH¦@ø\u0001\u0000¢\u0006\u0002\u0010\fJ\u0019\u0010\r\u001a\u00020\u00032\u0006\u0010\u000e\u001a\u00020\u000fH¦@ø\u0001\u0000¢\u0006\u0002\u0010\u0010\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u0012"}, d2 = {"Lvea/raceremote/utils/bluetooth/IBluetoothConnection;", "", "closeConnection", "", "connectWithDevice", "Lvea/raceremote/utils/bluetooth/IBluetoothConnection$Connection;", "context", "Landroid/content/Context;", "macAddress", "", "uuid", "Ljava/util/UUID;", "(Landroid/content/Context;Ljava/lang/String;Ljava/util/UUID;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendMessage", "bytes", "", "(ILkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Connection", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public interface IBluetoothConnection {
    void closeConnection();

    Object connectWithDevice(Context context, String str, UUID uuid, Continuation<? super Connection> continuation);

    Object sendMessage(int i, Continuation<? super Unit> continuation);

    /* JADX INFO: compiled from: IBluetoothConnection.kt */
    @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b7\u0018\u00002\u00020\u0001:\u0002\u0003\u0004B\u0007\b\u0004¢\u0006\u0002\u0010\u0002\u0082\u0001\u0002\u0005\u0006¨\u0006\u0007"}, d2 = {"Lvea/raceremote/utils/bluetooth/IBluetoothConnection$Connection;", "", "()V", "Error", "Success", "Lvea/raceremote/utils/bluetooth/IBluetoothConnection$Connection$Error;", "Lvea/raceremote/utils/bluetooth/IBluetoothConnection$Connection$Success;", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static abstract class Connection {
        public static final int $stable = LiveLiterals$IBluetoothConnectionKt.INSTANCE.m7006Int$classConnection$classIBluetoothConnection();

        /* JADX INFO: compiled from: IBluetoothConnection.kt */
        @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"Lvea/raceremote/utils/bluetooth/IBluetoothConnection$Connection$Success;", "Lvea/raceremote/utils/bluetooth/IBluetoothConnection$Connection;", "name", "", "(Ljava/lang/String;)V", "getName", "()Ljava/lang/String;", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
        public static final class Success extends Connection {
            public static final int $stable = LiveLiterals$IBluetoothConnectionKt.INSTANCE.m7008Int$classSuccess$classConnection$classIBluetoothConnection();
            private final String name;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public Success(String name) {
                super();
                Intrinsics.checkNotNullParameter(name, "name");
                this.name = name;
            }

            public final String getName() {
                return this.name;
            }
        }

        private Connection() {
        }

        /* JADX INFO: compiled from: IBluetoothConnection.kt */
        @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÇ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Lvea/raceremote/utils/bluetooth/IBluetoothConnection$Connection$Error;", "Lvea/raceremote/utils/bluetooth/IBluetoothConnection$Connection;", "()V", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
        public static final class Error extends Connection {
            public static final Error INSTANCE = new Error();
            public static final int $stable = LiveLiterals$IBluetoothConnectionKt.INSTANCE.m7007Int$classError$classConnection$classIBluetoothConnection();

            private Error() {
                super();
            }
        }
    }
}
