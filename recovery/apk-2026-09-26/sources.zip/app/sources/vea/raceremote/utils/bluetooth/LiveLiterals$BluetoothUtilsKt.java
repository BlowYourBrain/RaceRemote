package vea.raceremote.utils.bluetooth;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: BluetoothUtils.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/utils/bluetooth/BluetoothUtils.kt")
public final class LiveLiterals$BluetoothUtilsKt {

    /* JADX INFO: renamed from: Boolean$branch$when$fun-isBluetoothEnabled, reason: not valid java name */
    private static boolean f1963Boolean$branch$when$funisBluetoothEnabled;
    public static final LiveLiterals$BluetoothUtilsKt INSTANCE = new LiveLiterals$BluetoothUtilsKt();

    /* JADX INFO: renamed from: State$Boolean$branch$when$fun-isBluetoothEnabled, reason: not valid java name */
    private static State<Boolean> f1964State$Boolean$branch$when$funisBluetoothEnabled;

    @LiveLiteralInfo(key = "Boolean$branch$when$fun-isBluetoothEnabled", offset = 1211)
    /* JADX INFO: renamed from: Boolean$branch$when$fun-isBluetoothEnabled, reason: not valid java name */
    public final boolean m6987Boolean$branch$when$funisBluetoothEnabled() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1963Boolean$branch$when$funisBluetoothEnabled;
        }
        State<Boolean> stateLiveLiteral = f1964State$Boolean$branch$when$funisBluetoothEnabled;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when$fun-isBluetoothEnabled", Boolean.valueOf(f1963Boolean$branch$when$funisBluetoothEnabled));
            f1964State$Boolean$branch$when$funisBluetoothEnabled = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }
}
