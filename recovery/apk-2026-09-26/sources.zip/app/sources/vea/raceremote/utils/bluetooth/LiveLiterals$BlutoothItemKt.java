package vea.raceremote.utils.bluetooth;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: BlutoothItem.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/utils/bluetooth/BlutoothItem.kt")
public final class LiveLiterals$BlutoothItemKt {

    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-BluetoothItem, reason: not valid java name */
    private static boolean f1966Boolean$branch$when1$funequals$classBluetoothItem;

    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-BluetoothItem, reason: not valid java name */
    private static boolean f1967Boolean$branch$when2$funequals$classBluetoothItem;

    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-BluetoothItem, reason: not valid java name */
    private static boolean f1968Boolean$branch$when3$funequals$classBluetoothItem;

    /* JADX INFO: renamed from: Boolean$branch$when-4$fun-equals$class-BluetoothItem, reason: not valid java name */
    private static boolean f1969Boolean$branch$when4$funequals$classBluetoothItem;

    /* JADX INFO: renamed from: Int$class-BluetoothItem, reason: not valid java name */
    private static int f1973Int$classBluetoothItem;

    /* JADX INFO: renamed from: State$Boolean$branch$when$fun-equals$class-BluetoothItem, reason: not valid java name */
    private static State<Boolean> f1974State$Boolean$branch$when$funequals$classBluetoothItem;

    /* JADX INFO: renamed from: State$Boolean$branch$when-1$fun-equals$class-BluetoothItem, reason: not valid java name */
    private static State<Boolean> f1975State$Boolean$branch$when1$funequals$classBluetoothItem;

    /* JADX INFO: renamed from: State$Boolean$branch$when-2$fun-equals$class-BluetoothItem, reason: not valid java name */
    private static State<Boolean> f1976State$Boolean$branch$when2$funequals$classBluetoothItem;

    /* JADX INFO: renamed from: State$Boolean$branch$when-3$fun-equals$class-BluetoothItem, reason: not valid java name */
    private static State<Boolean> f1977State$Boolean$branch$when3$funequals$classBluetoothItem;

    /* JADX INFO: renamed from: State$Boolean$branch$when-4$fun-equals$class-BluetoothItem, reason: not valid java name */
    private static State<Boolean> f1978State$Boolean$branch$when4$funequals$classBluetoothItem;

    /* JADX INFO: renamed from: State$Boolean$fun-equals$class-BluetoothItem, reason: not valid java name */
    private static State<Boolean> f1979State$Boolean$funequals$classBluetoothItem;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-BluetoothItem, reason: not valid java name */
    private static State<Integer> f1980State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classBluetoothItem;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-BluetoothItem, reason: not valid java name */
    private static State<Integer> f1981State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classBluetoothItem;

    /* JADX INFO: renamed from: State$Int$class-BluetoothItem, reason: not valid java name */
    private static State<Integer> f1982State$Int$classBluetoothItem;

    /* JADX INFO: renamed from: State$String$0$str$fun-toString$class-BluetoothItem, reason: not valid java name */
    private static State<String> f1983State$String$0$str$funtoString$classBluetoothItem;

    /* JADX INFO: renamed from: State$String$1$str$fun-toString$class-BluetoothItem, reason: not valid java name */
    private static State<String> f1984State$String$1$str$funtoString$classBluetoothItem;

    /* JADX INFO: renamed from: State$String$3$str$fun-toString$class-BluetoothItem, reason: not valid java name */
    private static State<String> f1985State$String$3$str$funtoString$classBluetoothItem;

    /* JADX INFO: renamed from: State$String$4$str$fun-toString$class-BluetoothItem, reason: not valid java name */
    private static State<String> f1986State$String$4$str$funtoString$classBluetoothItem;

    /* JADX INFO: renamed from: State$String$6$str$fun-toString$class-BluetoothItem, reason: not valid java name */
    private static State<String> f1987State$String$6$str$funtoString$classBluetoothItem;

    /* JADX INFO: renamed from: State$String$7$str$fun-toString$class-BluetoothItem, reason: not valid java name */
    private static State<String> f1988State$String$7$str$funtoString$classBluetoothItem;

    /* JADX INFO: renamed from: State$String$9$str$fun-toString$class-BluetoothItem, reason: not valid java name */
    private static State<String> f1989State$String$9$str$funtoString$classBluetoothItem;
    public static final LiveLiterals$BlutoothItemKt INSTANCE = new LiveLiterals$BlutoothItemKt();

    /* JADX INFO: renamed from: String$0$str$fun-toString$class-BluetoothItem, reason: not valid java name */
    private static String f1990String$0$str$funtoString$classBluetoothItem = "BluetoothItem(";

    /* JADX INFO: renamed from: String$1$str$fun-toString$class-BluetoothItem, reason: not valid java name */
    private static String f1991String$1$str$funtoString$classBluetoothItem = "name=";

    /* JADX INFO: renamed from: String$3$str$fun-toString$class-BluetoothItem, reason: not valid java name */
    private static String f1992String$3$str$funtoString$classBluetoothItem = ", ";

    /* JADX INFO: renamed from: String$4$str$fun-toString$class-BluetoothItem, reason: not valid java name */
    private static String f1993String$4$str$funtoString$classBluetoothItem = "macAddress=";

    /* JADX INFO: renamed from: String$6$str$fun-toString$class-BluetoothItem, reason: not valid java name */
    private static String f1994String$6$str$funtoString$classBluetoothItem = ", ";

    /* JADX INFO: renamed from: String$7$str$fun-toString$class-BluetoothItem, reason: not valid java name */
    private static String f1995String$7$str$funtoString$classBluetoothItem = "isPaired=";

    /* JADX INFO: renamed from: String$9$str$fun-toString$class-BluetoothItem, reason: not valid java name */
    private static String f1996String$9$str$funtoString$classBluetoothItem = ")";

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-BluetoothItem, reason: not valid java name */
    private static int f1971Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classBluetoothItem = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-BluetoothItem, reason: not valid java name */
    private static int f1972Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classBluetoothItem = 31;

    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-BluetoothItem, reason: not valid java name */
    private static boolean f1965Boolean$branch$when$funequals$classBluetoothItem = true;

    /* JADX INFO: renamed from: Boolean$fun-equals$class-BluetoothItem, reason: not valid java name */
    private static boolean f1970Boolean$funequals$classBluetoothItem = true;

    @LiveLiteralInfo(key = "Boolean$branch$when$fun-equals$class-BluetoothItem", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-BluetoothItem, reason: not valid java name */
    public final boolean m6988Boolean$branch$when$funequals$classBluetoothItem() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1965Boolean$branch$when$funequals$classBluetoothItem;
        }
        State<Boolean> stateLiveLiteral = f1974State$Boolean$branch$when$funequals$classBluetoothItem;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when$fun-equals$class-BluetoothItem", Boolean.valueOf(f1965Boolean$branch$when$funequals$classBluetoothItem));
            f1974State$Boolean$branch$when$funequals$classBluetoothItem = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-1$fun-equals$class-BluetoothItem", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-BluetoothItem, reason: not valid java name */
    public final boolean m6989Boolean$branch$when1$funequals$classBluetoothItem() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1966Boolean$branch$when1$funequals$classBluetoothItem;
        }
        State<Boolean> stateLiveLiteral = f1975State$Boolean$branch$when1$funequals$classBluetoothItem;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-1$fun-equals$class-BluetoothItem", Boolean.valueOf(f1966Boolean$branch$when1$funequals$classBluetoothItem));
            f1975State$Boolean$branch$when1$funequals$classBluetoothItem = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-2$fun-equals$class-BluetoothItem", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-BluetoothItem, reason: not valid java name */
    public final boolean m6990Boolean$branch$when2$funequals$classBluetoothItem() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1967Boolean$branch$when2$funequals$classBluetoothItem;
        }
        State<Boolean> stateLiveLiteral = f1976State$Boolean$branch$when2$funequals$classBluetoothItem;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-2$fun-equals$class-BluetoothItem", Boolean.valueOf(f1967Boolean$branch$when2$funequals$classBluetoothItem));
            f1976State$Boolean$branch$when2$funequals$classBluetoothItem = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-3$fun-equals$class-BluetoothItem", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-BluetoothItem, reason: not valid java name */
    public final boolean m6991Boolean$branch$when3$funequals$classBluetoothItem() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1968Boolean$branch$when3$funequals$classBluetoothItem;
        }
        State<Boolean> stateLiveLiteral = f1977State$Boolean$branch$when3$funequals$classBluetoothItem;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-3$fun-equals$class-BluetoothItem", Boolean.valueOf(f1968Boolean$branch$when3$funequals$classBluetoothItem));
            f1977State$Boolean$branch$when3$funequals$classBluetoothItem = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-4$fun-equals$class-BluetoothItem", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-4$fun-equals$class-BluetoothItem, reason: not valid java name */
    public final boolean m6992Boolean$branch$when4$funequals$classBluetoothItem() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1969Boolean$branch$when4$funequals$classBluetoothItem;
        }
        State<Boolean> stateLiveLiteral = f1978State$Boolean$branch$when4$funequals$classBluetoothItem;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-4$fun-equals$class-BluetoothItem", Boolean.valueOf(f1969Boolean$branch$when4$funequals$classBluetoothItem));
            f1978State$Boolean$branch$when4$funequals$classBluetoothItem = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$fun-equals$class-BluetoothItem", offset = -2)
    /* JADX INFO: renamed from: Boolean$fun-equals$class-BluetoothItem, reason: not valid java name */
    public final boolean m6993Boolean$funequals$classBluetoothItem() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1970Boolean$funequals$classBluetoothItem;
        }
        State<Boolean> stateLiveLiteral = f1979State$Boolean$funequals$classBluetoothItem;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$fun-equals$class-BluetoothItem", Boolean.valueOf(f1970Boolean$funequals$classBluetoothItem));
            f1979State$Boolean$funequals$classBluetoothItem = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-BluetoothItem", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-BluetoothItem, reason: not valid java name */
    public final int m6994Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classBluetoothItem() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1971Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classBluetoothItem;
        }
        State<Integer> stateLiveLiteral = f1980State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classBluetoothItem;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-BluetoothItem", Integer.valueOf(f1971Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classBluetoothItem));
            f1980State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classBluetoothItem = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-BluetoothItem", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-BluetoothItem, reason: not valid java name */
    public final int m6995Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classBluetoothItem() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1972Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classBluetoothItem;
        }
        State<Integer> stateLiveLiteral = f1981State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classBluetoothItem;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-BluetoothItem", Integer.valueOf(f1972Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classBluetoothItem));
            f1981State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classBluetoothItem = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-BluetoothItem", offset = -1)
    /* JADX INFO: renamed from: Int$class-BluetoothItem, reason: not valid java name */
    public final int m6996Int$classBluetoothItem() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1973Int$classBluetoothItem;
        }
        State<Integer> stateLiveLiteral = f1982State$Int$classBluetoothItem;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-BluetoothItem", Integer.valueOf(f1973Int$classBluetoothItem));
            f1982State$Int$classBluetoothItem = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "String$0$str$fun-toString$class-BluetoothItem", offset = -2)
    /* JADX INFO: renamed from: String$0$str$fun-toString$class-BluetoothItem, reason: not valid java name */
    public final String m6997String$0$str$funtoString$classBluetoothItem() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1990String$0$str$funtoString$classBluetoothItem;
        }
        State<String> stateLiveLiteral = f1983State$String$0$str$funtoString$classBluetoothItem;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$fun-toString$class-BluetoothItem", f1990String$0$str$funtoString$classBluetoothItem);
            f1983State$String$0$str$funtoString$classBluetoothItem = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$1$str$fun-toString$class-BluetoothItem", offset = -2)
    /* JADX INFO: renamed from: String$1$str$fun-toString$class-BluetoothItem, reason: not valid java name */
    public final String m6998String$1$str$funtoString$classBluetoothItem() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1991String$1$str$funtoString$classBluetoothItem;
        }
        State<String> stateLiveLiteral = f1984State$String$1$str$funtoString$classBluetoothItem;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$1$str$fun-toString$class-BluetoothItem", f1991String$1$str$funtoString$classBluetoothItem);
            f1984State$String$1$str$funtoString$classBluetoothItem = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$3$str$fun-toString$class-BluetoothItem", offset = -2)
    /* JADX INFO: renamed from: String$3$str$fun-toString$class-BluetoothItem, reason: not valid java name */
    public final String m6999String$3$str$funtoString$classBluetoothItem() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1992String$3$str$funtoString$classBluetoothItem;
        }
        State<String> stateLiveLiteral = f1985State$String$3$str$funtoString$classBluetoothItem;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$3$str$fun-toString$class-BluetoothItem", f1992String$3$str$funtoString$classBluetoothItem);
            f1985State$String$3$str$funtoString$classBluetoothItem = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$4$str$fun-toString$class-BluetoothItem", offset = -2)
    /* JADX INFO: renamed from: String$4$str$fun-toString$class-BluetoothItem, reason: not valid java name */
    public final String m7000String$4$str$funtoString$classBluetoothItem() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1993String$4$str$funtoString$classBluetoothItem;
        }
        State<String> stateLiveLiteral = f1986State$String$4$str$funtoString$classBluetoothItem;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$4$str$fun-toString$class-BluetoothItem", f1993String$4$str$funtoString$classBluetoothItem);
            f1986State$String$4$str$funtoString$classBluetoothItem = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$6$str$fun-toString$class-BluetoothItem", offset = -2)
    /* JADX INFO: renamed from: String$6$str$fun-toString$class-BluetoothItem, reason: not valid java name */
    public final String m7001String$6$str$funtoString$classBluetoothItem() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1994String$6$str$funtoString$classBluetoothItem;
        }
        State<String> stateLiveLiteral = f1987State$String$6$str$funtoString$classBluetoothItem;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$6$str$fun-toString$class-BluetoothItem", f1994String$6$str$funtoString$classBluetoothItem);
            f1987State$String$6$str$funtoString$classBluetoothItem = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$7$str$fun-toString$class-BluetoothItem", offset = -2)
    /* JADX INFO: renamed from: String$7$str$fun-toString$class-BluetoothItem, reason: not valid java name */
    public final String m7002String$7$str$funtoString$classBluetoothItem() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1995String$7$str$funtoString$classBluetoothItem;
        }
        State<String> stateLiveLiteral = f1988State$String$7$str$funtoString$classBluetoothItem;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$7$str$fun-toString$class-BluetoothItem", f1995String$7$str$funtoString$classBluetoothItem);
            f1988State$String$7$str$funtoString$classBluetoothItem = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$9$str$fun-toString$class-BluetoothItem", offset = -2)
    /* JADX INFO: renamed from: String$9$str$fun-toString$class-BluetoothItem, reason: not valid java name */
    public final String m7003String$9$str$funtoString$classBluetoothItem() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1996String$9$str$funtoString$classBluetoothItem;
        }
        State<String> stateLiveLiteral = f1989State$String$9$str$funtoString$classBluetoothItem;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$9$str$fun-toString$class-BluetoothItem", f1996String$9$str$funtoString$classBluetoothItem);
            f1989State$String$9$str$funtoString$classBluetoothItem = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
