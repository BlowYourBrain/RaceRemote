package vea.raceremote.utils.bluetooth;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: IBluetoothConnection.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/utils/bluetooth/IBluetoothConnection.kt")
public final class LiveLiterals$IBluetoothConnectionKt {

    /* JADX INFO: renamed from: Int$class-Connection$class-IBluetoothConnection, reason: not valid java name */
    private static int f1999Int$classConnection$classIBluetoothConnection;

    /* JADX INFO: renamed from: Int$class-Error$class-Connection$class-IBluetoothConnection, reason: not valid java name */
    private static int f2000Int$classError$classConnection$classIBluetoothConnection;

    /* JADX INFO: renamed from: Int$class-Success$class-Connection$class-IBluetoothConnection, reason: not valid java name */
    private static int f2001Int$classSuccess$classConnection$classIBluetoothConnection;

    /* JADX INFO: renamed from: State$Int$0$vararg$arg-1$call-invoke$arg-0$call-$set-bluetoothSocket$$fun-connectWithDevice$class-BluetoothConnection, reason: not valid java name */
    private static State<Integer> f2002State$Int$0$vararg$arg1$callinvoke$arg0$call$setbluetoothSocket$$funconnectWithDevice$classBluetoothConnection;

    /* JADX INFO: renamed from: State$Int$class-BluetoothConnection, reason: not valid java name */
    private static State<Integer> f2003State$Int$classBluetoothConnection;

    /* JADX INFO: renamed from: State$Int$class-Connection$class-IBluetoothConnection, reason: not valid java name */
    private static State<Integer> f2004State$Int$classConnection$classIBluetoothConnection;

    /* JADX INFO: renamed from: State$Int$class-Error$class-Connection$class-IBluetoothConnection, reason: not valid java name */
    private static State<Integer> f2005State$Int$classError$classConnection$classIBluetoothConnection;

    /* JADX INFO: renamed from: State$Int$class-Success$class-Connection$class-IBluetoothConnection, reason: not valid java name */
    private static State<Integer> f2006State$Int$classSuccess$classConnection$classIBluetoothConnection;

    /* JADX INFO: renamed from: State$String$arg-0$call-debug$fun-$anonymous$$arg-0$call-runCatching$$$this$call-onFailure$$$this$call-getOrElse$fun-connectWithDevice$class-BluetoothConnection, reason: not valid java name */
    private static State<String> f2007State$String$arg0$calldebug$fun$anonymous$$arg0$callrunCatching$$$this$callonFailure$$$this$callgetOrElse$funconnectWithDevice$classBluetoothConnection;

    /* JADX INFO: renamed from: State$String$arg-0$call-debug-1$fun-$anonymous$$arg-0$call-onFailure$$$this$call-getOrElse$fun-connectWithDevice$class-BluetoothConnection, reason: not valid java name */
    private static State<String> f2008State$String$arg0$calldebug1$fun$anonymous$$arg0$callonFailure$$$this$callgetOrElse$funconnectWithDevice$classBluetoothConnection;

    /* JADX INFO: renamed from: State$String$arg-0$call-debug-1$fun-$anonymous$$arg-0$call-onFailure$fun-closeConnection$class-BluetoothConnection, reason: not valid java name */
    private static State<String> f2009State$String$arg0$calldebug1$fun$anonymous$$arg0$callonFailure$funcloseConnection$classBluetoothConnection;

    /* JADX INFO: renamed from: State$String$arg-0$call-debug-1$fun-$anonymous$$arg-0$call-onFailure$fun-sendMessage$class-BluetoothConnection, reason: not valid java name */
    private static State<String> f2010State$String$arg0$calldebug1$fun$anonymous$$arg0$callonFailure$funsendMessage$classBluetoothConnection;

    /* JADX INFO: renamed from: State$String$arg-0$call-getMethod$$this$call-invoke$arg-0$call-$set-bluetoothSocket$$fun-connectWithDevice$class-BluetoothConnection, reason: not valid java name */
    private static State<String> f2011State$String$arg0$callgetMethod$$this$callinvoke$arg0$call$setbluetoothSocket$$funconnectWithDevice$classBluetoothConnection;
    public static final LiveLiterals$IBluetoothConnectionKt INSTANCE = new LiveLiterals$IBluetoothConnectionKt();

    /* JADX INFO: renamed from: String$arg-0$call-getMethod$$this$call-invoke$arg-0$call-$set-bluetoothSocket$$fun-connectWithDevice$class-BluetoothConnection, reason: not valid java name */
    private static String f2016String$arg0$callgetMethod$$this$callinvoke$arg0$call$setbluetoothSocket$$funconnectWithDevice$classBluetoothConnection = "createRfcommSocket";

    /* JADX INFO: renamed from: Int$0$vararg$arg-1$call-invoke$arg-0$call-$set-bluetoothSocket$$fun-connectWithDevice$class-BluetoothConnection, reason: not valid java name */
    private static int f1997Int$0$vararg$arg1$callinvoke$arg0$call$setbluetoothSocket$$funconnectWithDevice$classBluetoothConnection = 1;

    /* JADX INFO: renamed from: String$arg-0$call-debug$fun-$anonymous$$arg-0$call-runCatching$$$this$call-onFailure$$$this$call-getOrElse$fun-connectWithDevice$class-BluetoothConnection, reason: not valid java name */
    private static String f2012String$arg0$calldebug$fun$anonymous$$arg0$callrunCatching$$$this$callonFailure$$$this$callgetOrElse$funconnectWithDevice$classBluetoothConnection = "bluetooth connection established";

    /* JADX INFO: renamed from: String$arg-0$call-debug-1$fun-$anonymous$$arg-0$call-onFailure$$$this$call-getOrElse$fun-connectWithDevice$class-BluetoothConnection, reason: not valid java name */
    private static String f2013String$arg0$calldebug1$fun$anonymous$$arg0$callonFailure$$$this$callgetOrElse$funconnectWithDevice$classBluetoothConnection = "bluetooth connection failed";

    /* JADX INFO: renamed from: String$arg-0$call-debug-1$fun-$anonymous$$arg-0$call-onFailure$fun-sendMessage$class-BluetoothConnection, reason: not valid java name */
    private static String f2015String$arg0$calldebug1$fun$anonymous$$arg0$callonFailure$funsendMessage$classBluetoothConnection = "bluetooth send message failed";

    /* JADX INFO: renamed from: String$arg-0$call-debug-1$fun-$anonymous$$arg-0$call-onFailure$fun-closeConnection$class-BluetoothConnection, reason: not valid java name */
    private static String f2014String$arg0$calldebug1$fun$anonymous$$arg0$callonFailure$funcloseConnection$classBluetoothConnection = "close bluetooth connection failed";

    /* JADX INFO: renamed from: Int$class-BluetoothConnection, reason: not valid java name */
    private static int f1998Int$classBluetoothConnection = 8;

    @LiveLiteralInfo(key = "Int$0$vararg$arg-1$call-invoke$arg-0$call-$set-bluetoothSocket$$fun-connectWithDevice$class-BluetoothConnection", offset = 1610)
    /* JADX INFO: renamed from: Int$0$vararg$arg-1$call-invoke$arg-0$call-$set-bluetoothSocket$$fun-connectWithDevice$class-BluetoothConnection, reason: not valid java name */
    public final int m7004Int$0$vararg$arg1$callinvoke$arg0$call$setbluetoothSocket$$funconnectWithDevice$classBluetoothConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1997Int$0$vararg$arg1$callinvoke$arg0$call$setbluetoothSocket$$funconnectWithDevice$classBluetoothConnection;
        }
        State<Integer> stateLiveLiteral = f2002State$Int$0$vararg$arg1$callinvoke$arg0$call$setbluetoothSocket$$funconnectWithDevice$classBluetoothConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$0$vararg$arg-1$call-invoke$arg-0$call-$set-bluetoothSocket$$fun-connectWithDevice$class-BluetoothConnection", Integer.valueOf(f1997Int$0$vararg$arg1$callinvoke$arg0$call$setbluetoothSocket$$funconnectWithDevice$classBluetoothConnection));
            f2002State$Int$0$vararg$arg1$callinvoke$arg0$call$setbluetoothSocket$$funconnectWithDevice$classBluetoothConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-BluetoothConnection", offset = -1)
    /* JADX INFO: renamed from: Int$class-BluetoothConnection, reason: not valid java name */
    public final int m7005Int$classBluetoothConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1998Int$classBluetoothConnection;
        }
        State<Integer> stateLiveLiteral = f2003State$Int$classBluetoothConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-BluetoothConnection", Integer.valueOf(f1998Int$classBluetoothConnection));
            f2003State$Int$classBluetoothConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-Connection$class-IBluetoothConnection", offset = -1)
    /* JADX INFO: renamed from: Int$class-Connection$class-IBluetoothConnection, reason: not valid java name */
    public final int m7006Int$classConnection$classIBluetoothConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1999Int$classConnection$classIBluetoothConnection;
        }
        State<Integer> stateLiveLiteral = f2004State$Int$classConnection$classIBluetoothConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-Connection$class-IBluetoothConnection", Integer.valueOf(f1999Int$classConnection$classIBluetoothConnection));
            f2004State$Int$classConnection$classIBluetoothConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-Error$class-Connection$class-IBluetoothConnection", offset = -1)
    /* JADX INFO: renamed from: Int$class-Error$class-Connection$class-IBluetoothConnection, reason: not valid java name */
    public final int m7007Int$classError$classConnection$classIBluetoothConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2000Int$classError$classConnection$classIBluetoothConnection;
        }
        State<Integer> stateLiveLiteral = f2005State$Int$classError$classConnection$classIBluetoothConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-Error$class-Connection$class-IBluetoothConnection", Integer.valueOf(f2000Int$classError$classConnection$classIBluetoothConnection));
            f2005State$Int$classError$classConnection$classIBluetoothConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-Success$class-Connection$class-IBluetoothConnection", offset = -1)
    /* JADX INFO: renamed from: Int$class-Success$class-Connection$class-IBluetoothConnection, reason: not valid java name */
    public final int m7008Int$classSuccess$classConnection$classIBluetoothConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2001Int$classSuccess$classConnection$classIBluetoothConnection;
        }
        State<Integer> stateLiveLiteral = f2006State$Int$classSuccess$classConnection$classIBluetoothConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-Success$class-Connection$class-IBluetoothConnection", Integer.valueOf(f2001Int$classSuccess$classConnection$classIBluetoothConnection));
            f2006State$Int$classSuccess$classConnection$classIBluetoothConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-debug$fun-$anonymous$$arg-0$call-runCatching$$$this$call-onFailure$$$this$call-getOrElse$fun-connectWithDevice$class-BluetoothConnection", offset = 1829)
    /* JADX INFO: renamed from: String$arg-0$call-debug$fun-$anonymous$$arg-0$call-runCatching$$$this$call-onFailure$$$this$call-getOrElse$fun-connectWithDevice$class-BluetoothConnection, reason: not valid java name */
    public final String m7009String$arg0$calldebug$fun$anonymous$$arg0$callrunCatching$$$this$callonFailure$$$this$callgetOrElse$funconnectWithDevice$classBluetoothConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2012String$arg0$calldebug$fun$anonymous$$arg0$callrunCatching$$$this$callonFailure$$$this$callgetOrElse$funconnectWithDevice$classBluetoothConnection;
        }
        State<String> stateLiveLiteral = f2007State$String$arg0$calldebug$fun$anonymous$$arg0$callrunCatching$$$this$callonFailure$$$this$callgetOrElse$funconnectWithDevice$classBluetoothConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-debug$fun-$anonymous$$arg-0$call-runCatching$$$this$call-onFailure$$$this$call-getOrElse$fun-connectWithDevice$class-BluetoothConnection", f2012String$arg0$calldebug$fun$anonymous$$arg0$callrunCatching$$$this$callonFailure$$$this$callgetOrElse$funconnectWithDevice$classBluetoothConnection);
            f2007State$String$arg0$calldebug$fun$anonymous$$arg0$callrunCatching$$$this$callonFailure$$$this$callgetOrElse$funconnectWithDevice$classBluetoothConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-debug-1$fun-$anonymous$$arg-0$call-onFailure$$$this$call-getOrElse$fun-connectWithDevice$class-BluetoothConnection", offset = 2045)
    /* JADX INFO: renamed from: String$arg-0$call-debug-1$fun-$anonymous$$arg-0$call-onFailure$$$this$call-getOrElse$fun-connectWithDevice$class-BluetoothConnection, reason: not valid java name */
    public final String m7010String$arg0$calldebug1$fun$anonymous$$arg0$callonFailure$$$this$callgetOrElse$funconnectWithDevice$classBluetoothConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2013String$arg0$calldebug1$fun$anonymous$$arg0$callonFailure$$$this$callgetOrElse$funconnectWithDevice$classBluetoothConnection;
        }
        State<String> stateLiveLiteral = f2008State$String$arg0$calldebug1$fun$anonymous$$arg0$callonFailure$$$this$callgetOrElse$funconnectWithDevice$classBluetoothConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-debug-1$fun-$anonymous$$arg-0$call-onFailure$$$this$call-getOrElse$fun-connectWithDevice$class-BluetoothConnection", f2013String$arg0$calldebug1$fun$anonymous$$arg0$callonFailure$$$this$callgetOrElse$funconnectWithDevice$classBluetoothConnection);
            f2008State$String$arg0$calldebug1$fun$anonymous$$arg0$callonFailure$$$this$callgetOrElse$funconnectWithDevice$classBluetoothConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-debug-1$fun-$anonymous$$arg-0$call-onFailure$fun-closeConnection$class-BluetoothConnection", offset = 2708)
    /* JADX INFO: renamed from: String$arg-0$call-debug-1$fun-$anonymous$$arg-0$call-onFailure$fun-closeConnection$class-BluetoothConnection, reason: not valid java name */
    public final String m7011String$arg0$calldebug1$fun$anonymous$$arg0$callonFailure$funcloseConnection$classBluetoothConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2014String$arg0$calldebug1$fun$anonymous$$arg0$callonFailure$funcloseConnection$classBluetoothConnection;
        }
        State<String> stateLiveLiteral = f2009State$String$arg0$calldebug1$fun$anonymous$$arg0$callonFailure$funcloseConnection$classBluetoothConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-debug-1$fun-$anonymous$$arg-0$call-onFailure$fun-closeConnection$class-BluetoothConnection", f2014String$arg0$calldebug1$fun$anonymous$$arg0$callonFailure$funcloseConnection$classBluetoothConnection);
            f2009State$String$arg0$calldebug1$fun$anonymous$$arg0$callonFailure$funcloseConnection$classBluetoothConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-debug-1$fun-$anonymous$$arg-0$call-onFailure$fun-sendMessage$class-BluetoothConnection", offset = 2482)
    /* JADX INFO: renamed from: String$arg-0$call-debug-1$fun-$anonymous$$arg-0$call-onFailure$fun-sendMessage$class-BluetoothConnection, reason: not valid java name */
    public final String m7012String$arg0$calldebug1$fun$anonymous$$arg0$callonFailure$funsendMessage$classBluetoothConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2015String$arg0$calldebug1$fun$anonymous$$arg0$callonFailure$funsendMessage$classBluetoothConnection;
        }
        State<String> stateLiveLiteral = f2010State$String$arg0$calldebug1$fun$anonymous$$arg0$callonFailure$funsendMessage$classBluetoothConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-debug-1$fun-$anonymous$$arg-0$call-onFailure$fun-sendMessage$class-BluetoothConnection", f2015String$arg0$calldebug1$fun$anonymous$$arg0$callonFailure$funsendMessage$classBluetoothConnection);
            f2010State$String$arg0$calldebug1$fun$anonymous$$arg0$callonFailure$funsendMessage$classBluetoothConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-getMethod$$this$call-invoke$arg-0$call-$set-bluetoothSocket$$fun-connectWithDevice$class-BluetoothConnection", offset = 1466)
    /* JADX INFO: renamed from: String$arg-0$call-getMethod$$this$call-invoke$arg-0$call-$set-bluetoothSocket$$fun-connectWithDevice$class-BluetoothConnection, reason: not valid java name */
    public final String m7013String$arg0$callgetMethod$$this$callinvoke$arg0$call$setbluetoothSocket$$funconnectWithDevice$classBluetoothConnection() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2016String$arg0$callgetMethod$$this$callinvoke$arg0$call$setbluetoothSocket$$funconnectWithDevice$classBluetoothConnection;
        }
        State<String> stateLiveLiteral = f2011State$String$arg0$callgetMethod$$this$callinvoke$arg0$call$setbluetoothSocket$$funconnectWithDevice$classBluetoothConnection;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-getMethod$$this$call-invoke$arg-0$call-$set-bluetoothSocket$$fun-connectWithDevice$class-BluetoothConnection", f2016String$arg0$callgetMethod$$this$callinvoke$arg0$call$setbluetoothSocket$$funconnectWithDevice$classBluetoothConnection);
            f2011State$String$arg0$callgetMethod$$this$callinvoke$arg0$call$setbluetoothSocket$$funconnectWithDevice$classBluetoothConnection = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
