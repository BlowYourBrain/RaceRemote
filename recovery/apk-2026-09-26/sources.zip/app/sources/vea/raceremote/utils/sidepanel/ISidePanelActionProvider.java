package vea.raceremote.utils.sidepanel;

import kotlin.Metadata;
import kotlinx.coroutines.flow.Flow;

/* JADX INFO: compiled from: ISidePanelActionProvider.kt */
/* JADX INFO: loaded from: classes9.dex */
@Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bf\u0018\u00002\u00020\u0001R\u0018\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003X¦\u0004¢\u0006\u0006\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"Lvea/raceremote/utils/sidepanel/ISidePanelActionProvider;", "", "action", "Lkotlinx/coroutines/flow/Flow;", "Lvea/raceremote/utils/sidepanel/SidePanelAction;", "getAction", "()Lkotlinx/coroutines/flow/Flow;", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public interface ISidePanelActionProvider {
    Flow<SidePanelAction> getAction();
}
