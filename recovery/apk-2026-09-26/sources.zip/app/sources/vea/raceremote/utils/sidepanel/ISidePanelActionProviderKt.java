package vea.raceremote.utils.sidepanel;

import kotlin.Metadata;

/* JADX INFO: compiled from: ISidePanelActionProvider.kt */
/* JADX INFO: loaded from: classes9.dex */
@Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\u001a\n\u0010\u0000\u001a\u00020\u0001*\u00020\u0002¨\u0006\u0003"}, d2 = {"toSidePanelAction", "Lvea/raceremote/utils/sidepanel/SidePanelAction;", "", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class ISidePanelActionProviderKt {
    public static final SidePanelAction toSidePanelAction(boolean $this$toSidePanelAction) {
        return $this$toSidePanelAction ? SidePanelAction.Open : SidePanelAction.Close;
    }
}
