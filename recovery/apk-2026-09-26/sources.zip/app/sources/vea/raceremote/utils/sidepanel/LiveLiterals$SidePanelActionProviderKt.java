package vea.raceremote.utils.sidepanel;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: SidePanelActionProvider.kt */
/* JADX INFO: loaded from: classes9.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/utils/sidepanel/SidePanelActionProvider.kt")
public final class LiveLiterals$SidePanelActionProviderKt {
    public static final LiveLiterals$SidePanelActionProviderKt INSTANCE = new LiveLiterals$SidePanelActionProviderKt();

    /* JADX INFO: renamed from: Int$class-SidePanelActionProvider, reason: not valid java name */
    private static int f2017Int$classSidePanelActionProvider = 8;

    /* JADX INFO: renamed from: State$Int$class-SidePanelActionProvider, reason: not valid java name */
    private static State<Integer> f2018State$Int$classSidePanelActionProvider;

    @LiveLiteralInfo(key = "Int$class-SidePanelActionProvider", offset = -1)
    /* JADX INFO: renamed from: Int$class-SidePanelActionProvider, reason: not valid java name */
    public final int m7014Int$classSidePanelActionProvider() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2017Int$classSidePanelActionProvider;
        }
        State<Integer> stateLiveLiteral = f2018State$Int$classSidePanelActionProvider;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-SidePanelActionProvider", Integer.valueOf(f2017Int$classSidePanelActionProvider));
            f2018State$Int$classSidePanelActionProvider = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }
}
