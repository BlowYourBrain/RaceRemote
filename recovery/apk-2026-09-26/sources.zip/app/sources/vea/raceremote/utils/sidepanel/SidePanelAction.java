package vea.raceremote.utils.sidepanel;

import kotlin.Metadata;

/* JADX INFO: compiled from: ISidePanelActionProvider.kt */
/* JADX INFO: loaded from: classes9.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0006\u0010\u0003\u001a\u00020\u0004j\u0002\b\u0005j\u0002\b\u0006¨\u0006\u0007"}, d2 = {"Lvea/raceremote/utils/sidepanel/SidePanelAction;", "", "(Ljava/lang/String;I)V", "isOpenAction", "", "Open", "Close", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public enum SidePanelAction {
    Open,
    Close;

    public final boolean isOpenAction() {
        return this == Open;
    }
}
