package vea.raceremote.utils.sidepanel;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlowKt;

/* JADX INFO: compiled from: SidePanelActionProvider.kt */
/* JADX INFO: loaded from: classes9.dex */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u00012\u00020\u0002B\u0005¢\u0006\u0002\u0010\u0003J\u0010\u0010\u000b\u001a\u00020\f2\u0006\u0010\u0007\u001a\u00020\u0006H\u0016R\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00060\bX\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\r"}, d2 = {"Lvea/raceremote/utils/sidepanel/SidePanelActionProvider;", "Lvea/raceremote/utils/sidepanel/ISidePanelActionProvider;", "Lvea/raceremote/utils/sidepanel/ISidePanelActionProducer;", "()V", "_action", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Lvea/raceremote/utils/sidepanel/SidePanelAction;", "action", "Lkotlinx/coroutines/flow/Flow;", "getAction", "()Lkotlinx/coroutines/flow/Flow;", "produceAction", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class SidePanelActionProvider implements ISidePanelActionProvider, ISidePanelActionProducer {
    public static final int $stable = LiveLiterals$SidePanelActionProviderKt.INSTANCE.m7014Int$classSidePanelActionProvider();
    private final MutableStateFlow<SidePanelAction> _action;
    private final Flow<SidePanelAction> action;

    public SidePanelActionProvider() {
        MutableStateFlow<SidePanelAction> MutableStateFlow = StateFlowKt.MutableStateFlow(SidePanelAction.Close);
        this._action = MutableStateFlow;
        this.action = FlowKt.asStateFlow(MutableStateFlow);
    }

    @Override // vea.raceremote.utils.sidepanel.ISidePanelActionProvider
    public Flow<SidePanelAction> getAction() {
        return this.action;
    }

    @Override // vea.raceremote.utils.sidepanel.ISidePanelActionProducer
    public void produceAction(SidePanelAction action) {
        Intrinsics.checkNotNullParameter(action, "action");
        MutableStateFlow<SidePanelAction> mutableStateFlow = this._action;
        while (!mutableStateFlow.compareAndSet(mutableStateFlow.getValue(), action)) {
        }
    }
}
