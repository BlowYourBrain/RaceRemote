package vea.raceremote.utils.wifi;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: WiFiUtils.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/utils/wifi/WiFiUtils.kt")
public final class LiveLiterals$WiFiUtilsKt {

    /* JADX INFO: renamed from: Boolean$branch$when$fun-isWifiEnabled, reason: not valid java name */
    private static boolean f2019Boolean$branch$when$funisWifiEnabled;
    public static final LiveLiterals$WiFiUtilsKt INSTANCE = new LiveLiterals$WiFiUtilsKt();

    /* JADX INFO: renamed from: State$Boolean$branch$when$fun-isWifiEnabled, reason: not valid java name */
    private static State<Boolean> f2020State$Boolean$branch$when$funisWifiEnabled;

    @LiveLiteralInfo(key = "Boolean$branch$when$fun-isWifiEnabled", offset = 488)
    /* JADX INFO: renamed from: Boolean$branch$when$fun-isWifiEnabled, reason: not valid java name */
    public final boolean m7015Boolean$branch$when$funisWifiEnabled() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2019Boolean$branch$when$funisWifiEnabled;
        }
        State<Boolean> stateLiveLiteral = f2020State$Boolean$branch$when$funisWifiEnabled;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when$fun-isWifiEnabled", Boolean.valueOf(f2019Boolean$branch$when$funisWifiEnabled));
            f2020State$Boolean$branch$when$funisWifiEnabled = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }
}
