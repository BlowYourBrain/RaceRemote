package vea.raceremote.utils.wifi;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.wifi.WifiManager;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: WiFiUtils.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000\u001e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0000\u001a\f\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u00020\u0002\u001a\f\u0010\u0003\u001a\u0004\u0018\u00010\u0004*\u00020\u0002\u001a\n\u0010\u0005\u001a\u00020\u0006*\u00020\u0002\u001a\n\u0010\u0007\u001a\u00020\b*\u00020\u0002¨\u0006\t"}, d2 = {"getConnectivityManager", "Landroid/net/ConnectivityManager;", "Landroid/content/Context;", "getWiFiManager", "Landroid/net/wifi/WifiManager;", "isWifiEnabled", "", "pickWifiNetwork", "", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class WiFiUtilsKt {
    public static final ConnectivityManager getConnectivityManager(Context $this$getConnectivityManager) {
        Intrinsics.checkNotNullParameter($this$getConnectivityManager, "<this>");
        Object systemService = $this$getConnectivityManager.getSystemService("connectivity");
        if (systemService instanceof ConnectivityManager) {
            return (ConnectivityManager) systemService;
        }
        return null;
    }

    public static final boolean isWifiEnabled(Context $this$isWifiEnabled) {
        Intrinsics.checkNotNullParameter($this$isWifiEnabled, "<this>");
        WifiManager wiFiManager = getWiFiManager($this$isWifiEnabled);
        return wiFiManager != null ? wiFiManager.isWifiEnabled() : LiveLiterals$WiFiUtilsKt.INSTANCE.m7015Boolean$branch$when$funisWifiEnabled();
    }

    public static final WifiManager getWiFiManager(Context $this$getWiFiManager) {
        Intrinsics.checkNotNullParameter($this$getWiFiManager, "<this>");
        Object systemService = $this$getWiFiManager.getSystemService("wifi");
        if (systemService instanceof WifiManager) {
            return (WifiManager) systemService;
        }
        return null;
    }

    public static final void pickWifiNetwork(Context $this$pickWifiNetwork) {
        Intrinsics.checkNotNullParameter($this$pickWifiNetwork, "<this>");
        Intent $this$pickWifiNetwork_u24lambda_u240 = new Intent("android.net.wifi.PICK_WIFI_NETWORK");
        $this$pickWifiNetwork_u24lambda_u240.addFlags(268435456);
        $this$pickWifiNetwork.startActivity($this$pickWifiNetwork_u24lambda_u240);
    }
}
