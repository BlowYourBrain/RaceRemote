package vea.raceremote.video;

import androidx.compose.material.TextKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;

/* JADX INFO: compiled from: VideoPanel.kt */
/* JADX INFO: loaded from: classes11.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
public final class ComposableSingletons$VideoPanelKt {
    public static final ComposableSingletons$VideoPanelKt INSTANCE = new ComposableSingletons$VideoPanelKt();

    /* JADX INFO: renamed from: lambda-1, reason: not valid java name */
    public static Function2<Composer, Integer, Unit> f2021lambda1 = ComposableLambdaKt.composableLambdaInstance(-279821138, false, new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.video.ComposableSingletons$VideoPanelKt$lambda-1$1
        @Override // kotlin.jvm.functions.Function2
        public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
            invoke(composer, num.intValue());
            return Unit.INSTANCE;
        }

        public final void invoke(Composer $composer, int $changed) {
            ComposerKt.sourceInformation($composer, "C43@2076L19:VideoPanel.kt#udqiv4");
            if (($changed & 11) == 2 && $composer.getSkipping()) {
                $composer.skipToGroupEnd();
                return;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-279821138, $changed, -1, "vea.raceremote.video.ComposableSingletons$VideoPanelKt.lambda-1.<anonymous> (VideoPanel.kt:43)");
            }
            TextKt.m1249TextfLXpl1I(LiveLiterals$VideoPanelKt.INSTANCE.m7194String$arg0$callText$fun$anonymous$$arg6$callOutlinedTextField$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel(), null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, null, $composer, 0, 0, 65534);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
    });

    /* JADX INFO: renamed from: getLambda-1$app_debug, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m7016getLambda1$app_debug() {
        return f2021lambda1;
    }
}
