package vea.raceremote.video;

import java.io.IOException;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: MjpegFrame.kt */
/* JADX INFO: loaded from: classes11.dex */
@Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0000\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u000e\u0010\b\u001a\u00020\u00052\u0006\u0010\t\u001a\u00020\u0007R\u001c\u0010\u0003\u001a\u0010\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u0005\u0018\u00010\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0006\u001a\u0004\u0018\u00010\u0007X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\n"}, d2 = {"Lvea/raceremote/video/FrameFreshness;", "", "()V", "metadataMode", "Lkotlin/Pair;", "", "previous", "Lvea/raceremote/video/MjpegFrame;", "accept", "frame", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class FrameFreshness {
    private Pair<Boolean, Boolean> metadataMode;
    private MjpegFrame previous;

    public final boolean accept(MjpegFrame frame) throws IOException {
        Intrinsics.checkNotNullParameter(frame, "frame");
        Pair<Boolean, Boolean> pair = TuplesKt.to(Boolean.valueOf(frame.getSequence() != null), Boolean.valueOf(frame.getCapturedUs() != null));
        Pair<Boolean, Boolean> pair2 = this.metadataMode;
        if (pair2 != null && !Intrinsics.areEqual(pair2, pair)) {
            throw new IOException(LiveLiterals$MjpegFrameKt.INSTANCE.m7041String$arg0$call$init$$branch$if$funaccept$classFrameFreshness());
        }
        this.metadataMode = pair;
        MjpegFrame old = this.previous;
        if (old != null) {
            if (frame.getSequence() != null && old.getSequence() != null) {
                long delta = (frame.getSequence().longValue() - old.getSequence().longValue()) & LiveLiterals$MjpegFrameKt.INSTANCE.m7032Long$arg0$calland$valdelta$branch$if$branch$if1$funaccept$classFrameFreshness();
                if (delta == 0 || delta >= LiveLiterals$MjpegFrameKt.INSTANCE.m7033Long$arg1$callgreaterOrEqual$else$cond$if$branch$if$branch$if1$funaccept$classFrameFreshness()) {
                    return LiveLiterals$MjpegFrameKt.INSTANCE.m7017Boolean$branch$if$branch$if$branch$if1$funaccept$classFrameFreshness();
                }
            }
            if (frame.getCapturedUs() != null && old.getCapturedUs() != null && frame.getCapturedUs().longValue() <= old.getCapturedUs().longValue()) {
                return LiveLiterals$MjpegFrameKt.INSTANCE.m7018Boolean$branch$if1$branch$if1$funaccept$classFrameFreshness();
            }
        }
        this.previous = new MjpegFrame(new byte[LiveLiterals$MjpegFrameKt.INSTANCE.m7026Int$arg0$call$init$$arg0$call$init$$arg0$call$setprevious$$funaccept$classFrameFreshness()], frame.getSequence(), frame.getCapturedUs());
        return LiveLiterals$MjpegFrameKt.INSTANCE.m7024Boolean$funaccept$classFrameFreshness();
    }
}
