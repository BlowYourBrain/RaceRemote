package vea.raceremote.video;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: MjpegFrame.kt */
/* JADX INFO: loaded from: classes11.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/video/MjpegFrame.kt")
public final class LiveLiterals$MjpegFrameKt {

    /* JADX INFO: renamed from: Boolean$branch$if$branch$if$branch$if-1$fun-accept$class-FrameFreshness, reason: not valid java name */
    private static boolean f2022Boolean$branch$if$branch$if$branch$if1$funaccept$classFrameFreshness;

    /* JADX INFO: renamed from: Boolean$branch$if-1$branch$if-1$fun-accept$class-FrameFreshness, reason: not valid java name */
    private static boolean f2023Boolean$branch$if1$branch$if1$funaccept$classFrameFreshness;

    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-MjpegFrame, reason: not valid java name */
    private static boolean f2025Boolean$branch$when1$funequals$classMjpegFrame;

    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-MjpegFrame, reason: not valid java name */
    private static boolean f2026Boolean$branch$when2$funequals$classMjpegFrame;

    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-MjpegFrame, reason: not valid java name */
    private static boolean f2027Boolean$branch$when3$funequals$classMjpegFrame;

    /* JADX INFO: renamed from: Boolean$branch$when-4$fun-equals$class-MjpegFrame, reason: not valid java name */
    private static boolean f2028Boolean$branch$when4$funequals$classMjpegFrame;

    /* JADX INFO: renamed from: Int$arg-0$call-$init$$arg-0$call-$init$$arg-0$call-$set-previous$$fun-accept$class-FrameFreshness, reason: not valid java name */
    private static int f2031Int$arg0$call$init$$arg0$call$init$$arg0$call$setprevious$$funaccept$classFrameFreshness;

    /* JADX INFO: renamed from: Int$branch$when$arg-0$call-plus$set-result$fun-hashCode$class-MjpegFrame, reason: not valid java name */
    private static int f2034Int$branch$when$arg0$callplus$setresult$funhashCode$classMjpegFrame;

    /* JADX INFO: renamed from: Int$branch$when$arg-0$call-plus$set-result-1$fun-hashCode$class-MjpegFrame, reason: not valid java name */
    private static int f2035Int$branch$when$arg0$callplus$setresult1$funhashCode$classMjpegFrame;

    /* JADX INFO: renamed from: State$Boolean$branch$if$branch$if$branch$if-1$fun-accept$class-FrameFreshness, reason: not valid java name */
    private static State<Boolean> f2039State$Boolean$branch$if$branch$if$branch$if1$funaccept$classFrameFreshness;

    /* JADX INFO: renamed from: State$Boolean$branch$if-1$branch$if-1$fun-accept$class-FrameFreshness, reason: not valid java name */
    private static State<Boolean> f2040State$Boolean$branch$if1$branch$if1$funaccept$classFrameFreshness;

    /* JADX INFO: renamed from: State$Boolean$branch$when$fun-equals$class-MjpegFrame, reason: not valid java name */
    private static State<Boolean> f2041State$Boolean$branch$when$funequals$classMjpegFrame;

    /* JADX INFO: renamed from: State$Boolean$branch$when-1$fun-equals$class-MjpegFrame, reason: not valid java name */
    private static State<Boolean> f2042State$Boolean$branch$when1$funequals$classMjpegFrame;

    /* JADX INFO: renamed from: State$Boolean$branch$when-2$fun-equals$class-MjpegFrame, reason: not valid java name */
    private static State<Boolean> f2043State$Boolean$branch$when2$funequals$classMjpegFrame;

    /* JADX INFO: renamed from: State$Boolean$branch$when-3$fun-equals$class-MjpegFrame, reason: not valid java name */
    private static State<Boolean> f2044State$Boolean$branch$when3$funequals$classMjpegFrame;

    /* JADX INFO: renamed from: State$Boolean$branch$when-4$fun-equals$class-MjpegFrame, reason: not valid java name */
    private static State<Boolean> f2045State$Boolean$branch$when4$funequals$classMjpegFrame;

    /* JADX INFO: renamed from: State$Boolean$fun-accept$class-FrameFreshness, reason: not valid java name */
    private static State<Boolean> f2046State$Boolean$funaccept$classFrameFreshness;

    /* JADX INFO: renamed from: State$Boolean$fun-equals$class-MjpegFrame, reason: not valid java name */
    private static State<Boolean> f2047State$Boolean$funequals$classMjpegFrame;

    /* JADX INFO: renamed from: State$Int$arg-0$call-$init$$arg-0$call-$init$$arg-0$call-$set-previous$$fun-accept$class-FrameFreshness, reason: not valid java name */
    private static State<Integer> f2048State$Int$arg0$call$init$$arg0$call$init$$arg0$call$setprevious$$funaccept$classFrameFreshness;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-MjpegFrame, reason: not valid java name */
    private static State<Integer> f2049State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classMjpegFrame;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-MjpegFrame, reason: not valid java name */
    private static State<Integer> f2050State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classMjpegFrame;

    /* JADX INFO: renamed from: State$Int$branch$when$arg-0$call-plus$set-result$fun-hashCode$class-MjpegFrame, reason: not valid java name */
    private static State<Integer> f2051State$Int$branch$when$arg0$callplus$setresult$funhashCode$classMjpegFrame;

    /* JADX INFO: renamed from: State$Int$branch$when$arg-0$call-plus$set-result-1$fun-hashCode$class-MjpegFrame, reason: not valid java name */
    private static State<Integer> f2052State$Int$branch$when$arg0$callplus$setresult1$funhashCode$classMjpegFrame;

    /* JADX INFO: renamed from: State$Int$class-MjpegFrame, reason: not valid java name */
    private static State<Integer> f2053State$Int$classMjpegFrame;

    /* JADX INFO: renamed from: State$Long$arg-0$call-and$val-delta$branch$if$branch$if-1$fun-accept$class-FrameFreshness, reason: not valid java name */
    private static State<Long> f2054State$Long$arg0$calland$valdelta$branch$if$branch$if1$funaccept$classFrameFreshness;

    /* JADX INFO: renamed from: State$Long$arg-1$call-greaterOrEqual$else$cond$if$branch$if$branch$if-1$fun-accept$class-FrameFreshness, reason: not valid java name */
    private static State<Long> f2055State$Long$arg1$callgreaterOrEqual$else$cond$if$branch$if$branch$if1$funaccept$classFrameFreshness;

    /* JADX INFO: renamed from: State$String$0$str$fun-toString$class-MjpegFrame, reason: not valid java name */
    private static State<String> f2056State$String$0$str$funtoString$classMjpegFrame;

    /* JADX INFO: renamed from: State$String$1$str$fun-toString$class-MjpegFrame, reason: not valid java name */
    private static State<String> f2057State$String$1$str$funtoString$classMjpegFrame;

    /* JADX INFO: renamed from: State$String$3$str$fun-toString$class-MjpegFrame, reason: not valid java name */
    private static State<String> f2058State$String$3$str$funtoString$classMjpegFrame;

    /* JADX INFO: renamed from: State$String$4$str$fun-toString$class-MjpegFrame, reason: not valid java name */
    private static State<String> f2059State$String$4$str$funtoString$classMjpegFrame;

    /* JADX INFO: renamed from: State$String$6$str$fun-toString$class-MjpegFrame, reason: not valid java name */
    private static State<String> f2060State$String$6$str$funtoString$classMjpegFrame;

    /* JADX INFO: renamed from: State$String$7$str$fun-toString$class-MjpegFrame, reason: not valid java name */
    private static State<String> f2061State$String$7$str$funtoString$classMjpegFrame;

    /* JADX INFO: renamed from: State$String$9$str$fun-toString$class-MjpegFrame, reason: not valid java name */
    private static State<String> f2062State$String$9$str$funtoString$classMjpegFrame;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$branch$if$fun-accept$class-FrameFreshness, reason: not valid java name */
    private static State<String> f2063State$String$arg0$call$init$$branch$if$funaccept$classFrameFreshness;
    public static final LiveLiterals$MjpegFrameKt INSTANCE = new LiveLiterals$MjpegFrameKt();

    /* JADX INFO: renamed from: String$0$str$fun-toString$class-MjpegFrame, reason: not valid java name */
    private static String f2064String$0$str$funtoString$classMjpegFrame = "MjpegFrame(";

    /* JADX INFO: renamed from: String$1$str$fun-toString$class-MjpegFrame, reason: not valid java name */
    private static String f2065String$1$str$funtoString$classMjpegFrame = "bytes=";

    /* JADX INFO: renamed from: String$3$str$fun-toString$class-MjpegFrame, reason: not valid java name */
    private static String f2066String$3$str$funtoString$classMjpegFrame = ", ";

    /* JADX INFO: renamed from: String$4$str$fun-toString$class-MjpegFrame, reason: not valid java name */
    private static String f2067String$4$str$funtoString$classMjpegFrame = "sequence=";

    /* JADX INFO: renamed from: String$6$str$fun-toString$class-MjpegFrame, reason: not valid java name */
    private static String f2068String$6$str$funtoString$classMjpegFrame = ", ";

    /* JADX INFO: renamed from: String$7$str$fun-toString$class-MjpegFrame, reason: not valid java name */
    private static String f2069String$7$str$funtoString$classMjpegFrame = "capturedUs=";

    /* JADX INFO: renamed from: String$9$str$fun-toString$class-MjpegFrame, reason: not valid java name */
    private static String f2070String$9$str$funtoString$classMjpegFrame = ")";

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-MjpegFrame, reason: not valid java name */
    private static int f2032Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classMjpegFrame = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-MjpegFrame, reason: not valid java name */
    private static int f2033Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classMjpegFrame = 31;

    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-MjpegFrame, reason: not valid java name */
    private static boolean f2024Boolean$branch$when$funequals$classMjpegFrame = true;

    /* JADX INFO: renamed from: Boolean$fun-equals$class-MjpegFrame, reason: not valid java name */
    private static boolean f2030Boolean$funequals$classMjpegFrame = true;

    /* JADX INFO: renamed from: Int$class-MjpegFrame, reason: not valid java name */
    private static int f2036Int$classMjpegFrame = 8;

    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if$fun-accept$class-FrameFreshness, reason: not valid java name */
    private static String f2071String$arg0$call$init$$branch$if$funaccept$classFrameFreshness = "Video metadata changed within stream";

    /* JADX INFO: renamed from: Long$arg-0$call-and$val-delta$branch$if$branch$if-1$fun-accept$class-FrameFreshness, reason: not valid java name */
    private static long f2037Long$arg0$calland$valdelta$branch$if$branch$if1$funaccept$classFrameFreshness = 4294967295L;

    /* JADX INFO: renamed from: Long$arg-1$call-greaterOrEqual$else$cond$if$branch$if$branch$if-1$fun-accept$class-FrameFreshness, reason: not valid java name */
    private static long f2038Long$arg1$callgreaterOrEqual$else$cond$if$branch$if$branch$if1$funaccept$classFrameFreshness = 2147483648L;

    /* JADX INFO: renamed from: Boolean$fun-accept$class-FrameFreshness, reason: not valid java name */
    private static boolean f2029Boolean$funaccept$classFrameFreshness = true;

    @LiveLiteralInfo(key = "Boolean$branch$if$branch$if$branch$if-1$fun-accept$class-FrameFreshness", offset = 1009)
    /* JADX INFO: renamed from: Boolean$branch$if$branch$if$branch$if-1$fun-accept$class-FrameFreshness, reason: not valid java name */
    public final boolean m7017Boolean$branch$if$branch$if$branch$if1$funaccept$classFrameFreshness() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2022Boolean$branch$if$branch$if$branch$if1$funaccept$classFrameFreshness;
        }
        State<Boolean> stateLiveLiteral = f2039State$Boolean$branch$if$branch$if$branch$if1$funaccept$classFrameFreshness;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$if$branch$if$branch$if-1$fun-accept$class-FrameFreshness", Boolean.valueOf(f2022Boolean$branch$if$branch$if$branch$if1$funaccept$classFrameFreshness));
            f2039State$Boolean$branch$if$branch$if$branch$if1$funaccept$classFrameFreshness = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$if-1$branch$if-1$fun-accept$class-FrameFreshness", offset = 1158)
    /* JADX INFO: renamed from: Boolean$branch$if-1$branch$if-1$fun-accept$class-FrameFreshness, reason: not valid java name */
    public final boolean m7018Boolean$branch$if1$branch$if1$funaccept$classFrameFreshness() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2023Boolean$branch$if1$branch$if1$funaccept$classFrameFreshness;
        }
        State<Boolean> stateLiveLiteral = f2040State$Boolean$branch$if1$branch$if1$funaccept$classFrameFreshness;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$if-1$branch$if-1$fun-accept$class-FrameFreshness", Boolean.valueOf(f2023Boolean$branch$if1$branch$if1$funaccept$classFrameFreshness));
            f2040State$Boolean$branch$if1$branch$if1$funaccept$classFrameFreshness = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when$fun-equals$class-MjpegFrame", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-MjpegFrame, reason: not valid java name */
    public final boolean m7019Boolean$branch$when$funequals$classMjpegFrame() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2024Boolean$branch$when$funequals$classMjpegFrame;
        }
        State<Boolean> stateLiveLiteral = f2041State$Boolean$branch$when$funequals$classMjpegFrame;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when$fun-equals$class-MjpegFrame", Boolean.valueOf(f2024Boolean$branch$when$funequals$classMjpegFrame));
            f2041State$Boolean$branch$when$funequals$classMjpegFrame = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-1$fun-equals$class-MjpegFrame", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-MjpegFrame, reason: not valid java name */
    public final boolean m7020Boolean$branch$when1$funequals$classMjpegFrame() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2025Boolean$branch$when1$funequals$classMjpegFrame;
        }
        State<Boolean> stateLiveLiteral = f2042State$Boolean$branch$when1$funequals$classMjpegFrame;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-1$fun-equals$class-MjpegFrame", Boolean.valueOf(f2025Boolean$branch$when1$funequals$classMjpegFrame));
            f2042State$Boolean$branch$when1$funequals$classMjpegFrame = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-2$fun-equals$class-MjpegFrame", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-MjpegFrame, reason: not valid java name */
    public final boolean m7021Boolean$branch$when2$funequals$classMjpegFrame() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2026Boolean$branch$when2$funequals$classMjpegFrame;
        }
        State<Boolean> stateLiveLiteral = f2043State$Boolean$branch$when2$funequals$classMjpegFrame;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-2$fun-equals$class-MjpegFrame", Boolean.valueOf(f2026Boolean$branch$when2$funequals$classMjpegFrame));
            f2043State$Boolean$branch$when2$funequals$classMjpegFrame = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-3$fun-equals$class-MjpegFrame", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-MjpegFrame, reason: not valid java name */
    public final boolean m7022Boolean$branch$when3$funequals$classMjpegFrame() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2027Boolean$branch$when3$funequals$classMjpegFrame;
        }
        State<Boolean> stateLiveLiteral = f2044State$Boolean$branch$when3$funequals$classMjpegFrame;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-3$fun-equals$class-MjpegFrame", Boolean.valueOf(f2027Boolean$branch$when3$funequals$classMjpegFrame));
            f2044State$Boolean$branch$when3$funequals$classMjpegFrame = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-4$fun-equals$class-MjpegFrame", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-4$fun-equals$class-MjpegFrame, reason: not valid java name */
    public final boolean m7023Boolean$branch$when4$funequals$classMjpegFrame() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2028Boolean$branch$when4$funequals$classMjpegFrame;
        }
        State<Boolean> stateLiveLiteral = f2045State$Boolean$branch$when4$funequals$classMjpegFrame;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-4$fun-equals$class-MjpegFrame", Boolean.valueOf(f2028Boolean$branch$when4$funequals$classMjpegFrame));
            f2045State$Boolean$branch$when4$funequals$classMjpegFrame = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$fun-accept$class-FrameFreshness", offset = 1333)
    /* JADX INFO: renamed from: Boolean$fun-accept$class-FrameFreshness, reason: not valid java name */
    public final boolean m7024Boolean$funaccept$classFrameFreshness() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2029Boolean$funaccept$classFrameFreshness;
        }
        State<Boolean> stateLiveLiteral = f2046State$Boolean$funaccept$classFrameFreshness;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$fun-accept$class-FrameFreshness", Boolean.valueOf(f2029Boolean$funaccept$classFrameFreshness));
            f2046State$Boolean$funaccept$classFrameFreshness = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$fun-equals$class-MjpegFrame", offset = -2)
    /* JADX INFO: renamed from: Boolean$fun-equals$class-MjpegFrame, reason: not valid java name */
    public final boolean m7025Boolean$funequals$classMjpegFrame() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2030Boolean$funequals$classMjpegFrame;
        }
        State<Boolean> stateLiveLiteral = f2047State$Boolean$funequals$classMjpegFrame;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$fun-equals$class-MjpegFrame", Boolean.valueOf(f2030Boolean$funequals$classMjpegFrame));
            f2047State$Boolean$funequals$classMjpegFrame = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-$init$$arg-0$call-$init$$arg-0$call-$set-previous$$fun-accept$class-FrameFreshness", offset = 1280)
    /* JADX INFO: renamed from: Int$arg-0$call-$init$$arg-0$call-$init$$arg-0$call-$set-previous$$fun-accept$class-FrameFreshness, reason: not valid java name */
    public final int m7026Int$arg0$call$init$$arg0$call$init$$arg0$call$setprevious$$funaccept$classFrameFreshness() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2031Int$arg0$call$init$$arg0$call$init$$arg0$call$setprevious$$funaccept$classFrameFreshness;
        }
        State<Integer> stateLiveLiteral = f2048State$Int$arg0$call$init$$arg0$call$init$$arg0$call$setprevious$$funaccept$classFrameFreshness;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-$init$$arg-0$call-$init$$arg-0$call-$set-previous$$fun-accept$class-FrameFreshness", Integer.valueOf(f2031Int$arg0$call$init$$arg0$call$init$$arg0$call$setprevious$$funaccept$classFrameFreshness));
            f2048State$Int$arg0$call$init$$arg0$call$init$$arg0$call$setprevious$$funaccept$classFrameFreshness = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-MjpegFrame", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-MjpegFrame, reason: not valid java name */
    public final int m7027Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classMjpegFrame() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2032Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classMjpegFrame;
        }
        State<Integer> stateLiveLiteral = f2049State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classMjpegFrame;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-MjpegFrame", Integer.valueOf(f2032Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classMjpegFrame));
            f2049State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classMjpegFrame = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-MjpegFrame", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-MjpegFrame, reason: not valid java name */
    public final int m7028Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classMjpegFrame() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2033Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classMjpegFrame;
        }
        State<Integer> stateLiveLiteral = f2050State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classMjpegFrame;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-MjpegFrame", Integer.valueOf(f2033Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classMjpegFrame));
            f2050State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classMjpegFrame = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$branch$when$arg-0$call-plus$set-result$fun-hashCode$class-MjpegFrame", offset = -2)
    /* JADX INFO: renamed from: Int$branch$when$arg-0$call-plus$set-result$fun-hashCode$class-MjpegFrame, reason: not valid java name */
    public final int m7029Int$branch$when$arg0$callplus$setresult$funhashCode$classMjpegFrame() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2034Int$branch$when$arg0$callplus$setresult$funhashCode$classMjpegFrame;
        }
        State<Integer> stateLiveLiteral = f2051State$Int$branch$when$arg0$callplus$setresult$funhashCode$classMjpegFrame;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$branch$when$arg-0$call-plus$set-result$fun-hashCode$class-MjpegFrame", Integer.valueOf(f2034Int$branch$when$arg0$callplus$setresult$funhashCode$classMjpegFrame));
            f2051State$Int$branch$when$arg0$callplus$setresult$funhashCode$classMjpegFrame = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$branch$when$arg-0$call-plus$set-result-1$fun-hashCode$class-MjpegFrame", offset = -2)
    /* JADX INFO: renamed from: Int$branch$when$arg-0$call-plus$set-result-1$fun-hashCode$class-MjpegFrame, reason: not valid java name */
    public final int m7030Int$branch$when$arg0$callplus$setresult1$funhashCode$classMjpegFrame() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2035Int$branch$when$arg0$callplus$setresult1$funhashCode$classMjpegFrame;
        }
        State<Integer> stateLiveLiteral = f2052State$Int$branch$when$arg0$callplus$setresult1$funhashCode$classMjpegFrame;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$branch$when$arg-0$call-plus$set-result-1$fun-hashCode$class-MjpegFrame", Integer.valueOf(f2035Int$branch$when$arg0$callplus$setresult1$funhashCode$classMjpegFrame));
            f2052State$Int$branch$when$arg0$callplus$setresult1$funhashCode$classMjpegFrame = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-MjpegFrame", offset = -1)
    /* JADX INFO: renamed from: Int$class-MjpegFrame, reason: not valid java name */
    public final int m7031Int$classMjpegFrame() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2036Int$classMjpegFrame;
        }
        State<Integer> stateLiveLiteral = f2053State$Int$classMjpegFrame;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-MjpegFrame", Integer.valueOf(f2036Int$classMjpegFrame));
            f2053State$Int$classMjpegFrame = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-and$val-delta$branch$if$branch$if-1$fun-accept$class-FrameFreshness", offset = 838)
    /* JADX INFO: renamed from: Long$arg-0$call-and$val-delta$branch$if$branch$if-1$fun-accept$class-FrameFreshness, reason: not valid java name */
    public final long m7032Long$arg0$calland$valdelta$branch$if$branch$if1$funaccept$classFrameFreshness() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2037Long$arg0$calland$valdelta$branch$if$branch$if1$funaccept$classFrameFreshness;
        }
        State<Long> stateLiveLiteral = f2054State$Long$arg0$calland$valdelta$branch$if$branch$if1$funaccept$classFrameFreshness;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-and$val-delta$branch$if$branch$if-1$fun-accept$class-FrameFreshness", Long.valueOf(f2037Long$arg0$calland$valdelta$branch$if$branch$if1$funaccept$classFrameFreshness));
            f2054State$Long$arg0$calland$valdelta$branch$if$branch$if1$funaccept$classFrameFreshness = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-1$call-greaterOrEqual$else$cond$if$branch$if$branch$if-1$fun-accept$class-FrameFreshness", offset = 988)
    /* JADX INFO: renamed from: Long$arg-1$call-greaterOrEqual$else$cond$if$branch$if$branch$if-1$fun-accept$class-FrameFreshness, reason: not valid java name */
    public final long m7033Long$arg1$callgreaterOrEqual$else$cond$if$branch$if$branch$if1$funaccept$classFrameFreshness() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2038Long$arg1$callgreaterOrEqual$else$cond$if$branch$if$branch$if1$funaccept$classFrameFreshness;
        }
        State<Long> stateLiveLiteral = f2055State$Long$arg1$callgreaterOrEqual$else$cond$if$branch$if$branch$if1$funaccept$classFrameFreshness;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-1$call-greaterOrEqual$else$cond$if$branch$if$branch$if-1$fun-accept$class-FrameFreshness", Long.valueOf(f2038Long$arg1$callgreaterOrEqual$else$cond$if$branch$if$branch$if1$funaccept$classFrameFreshness));
            f2055State$Long$arg1$callgreaterOrEqual$else$cond$if$branch$if$branch$if1$funaccept$classFrameFreshness = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "String$0$str$fun-toString$class-MjpegFrame", offset = -2)
    /* JADX INFO: renamed from: String$0$str$fun-toString$class-MjpegFrame, reason: not valid java name */
    public final String m7034String$0$str$funtoString$classMjpegFrame() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2064String$0$str$funtoString$classMjpegFrame;
        }
        State<String> stateLiveLiteral = f2056State$String$0$str$funtoString$classMjpegFrame;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$fun-toString$class-MjpegFrame", f2064String$0$str$funtoString$classMjpegFrame);
            f2056State$String$0$str$funtoString$classMjpegFrame = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$1$str$fun-toString$class-MjpegFrame", offset = -2)
    /* JADX INFO: renamed from: String$1$str$fun-toString$class-MjpegFrame, reason: not valid java name */
    public final String m7035String$1$str$funtoString$classMjpegFrame() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2065String$1$str$funtoString$classMjpegFrame;
        }
        State<String> stateLiveLiteral = f2057State$String$1$str$funtoString$classMjpegFrame;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$1$str$fun-toString$class-MjpegFrame", f2065String$1$str$funtoString$classMjpegFrame);
            f2057State$String$1$str$funtoString$classMjpegFrame = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$3$str$fun-toString$class-MjpegFrame", offset = -2)
    /* JADX INFO: renamed from: String$3$str$fun-toString$class-MjpegFrame, reason: not valid java name */
    public final String m7036String$3$str$funtoString$classMjpegFrame() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2066String$3$str$funtoString$classMjpegFrame;
        }
        State<String> stateLiveLiteral = f2058State$String$3$str$funtoString$classMjpegFrame;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$3$str$fun-toString$class-MjpegFrame", f2066String$3$str$funtoString$classMjpegFrame);
            f2058State$String$3$str$funtoString$classMjpegFrame = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$4$str$fun-toString$class-MjpegFrame", offset = -2)
    /* JADX INFO: renamed from: String$4$str$fun-toString$class-MjpegFrame, reason: not valid java name */
    public final String m7037String$4$str$funtoString$classMjpegFrame() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2067String$4$str$funtoString$classMjpegFrame;
        }
        State<String> stateLiveLiteral = f2059State$String$4$str$funtoString$classMjpegFrame;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$4$str$fun-toString$class-MjpegFrame", f2067String$4$str$funtoString$classMjpegFrame);
            f2059State$String$4$str$funtoString$classMjpegFrame = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$6$str$fun-toString$class-MjpegFrame", offset = -2)
    /* JADX INFO: renamed from: String$6$str$fun-toString$class-MjpegFrame, reason: not valid java name */
    public final String m7038String$6$str$funtoString$classMjpegFrame() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2068String$6$str$funtoString$classMjpegFrame;
        }
        State<String> stateLiveLiteral = f2060State$String$6$str$funtoString$classMjpegFrame;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$6$str$fun-toString$class-MjpegFrame", f2068String$6$str$funtoString$classMjpegFrame);
            f2060State$String$6$str$funtoString$classMjpegFrame = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$7$str$fun-toString$class-MjpegFrame", offset = -2)
    /* JADX INFO: renamed from: String$7$str$fun-toString$class-MjpegFrame, reason: not valid java name */
    public final String m7039String$7$str$funtoString$classMjpegFrame() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2069String$7$str$funtoString$classMjpegFrame;
        }
        State<String> stateLiveLiteral = f2061State$String$7$str$funtoString$classMjpegFrame;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$7$str$fun-toString$class-MjpegFrame", f2069String$7$str$funtoString$classMjpegFrame);
            f2061State$String$7$str$funtoString$classMjpegFrame = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$9$str$fun-toString$class-MjpegFrame", offset = -2)
    /* JADX INFO: renamed from: String$9$str$fun-toString$class-MjpegFrame, reason: not valid java name */
    public final String m7040String$9$str$funtoString$classMjpegFrame() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2070String$9$str$funtoString$classMjpegFrame;
        }
        State<String> stateLiveLiteral = f2062State$String$9$str$funtoString$classMjpegFrame;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$9$str$fun-toString$class-MjpegFrame", f2070String$9$str$funtoString$classMjpegFrame);
            f2062State$String$9$str$funtoString$classMjpegFrame = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$branch$if$fun-accept$class-FrameFreshness", offset = 587)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if$fun-accept$class-FrameFreshness, reason: not valid java name */
    public final String m7041String$arg0$call$init$$branch$if$funaccept$classFrameFreshness() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2071String$arg0$call$init$$branch$if$funaccept$classFrameFreshness;
        }
        State<String> stateLiveLiteral = f2063State$String$arg0$call$init$$branch$if$funaccept$classFrameFreshness;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$branch$if$fun-accept$class-FrameFreshness", f2071String$arg0$call$init$$branch$if$funaccept$classFrameFreshness);
            f2063State$String$arg0$call$init$$branch$if$funaccept$classFrameFreshness = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
