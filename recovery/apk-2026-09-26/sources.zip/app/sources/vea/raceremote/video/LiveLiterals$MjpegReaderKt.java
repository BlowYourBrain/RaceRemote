package vea.raceremote.video;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: MjpegReader.kt */
/* JADX INFO: loaded from: classes11.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/video/MjpegReader.kt")
public final class LiveLiterals$MjpegReaderKt {

    /* JADX INFO: renamed from: Int$arg-0$call-substring$$$this$call-trim$$$this$call-lowercase$val-name$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static int f2091Int$arg0$callsubstring$$$this$calltrim$$$this$calllowercase$valname$body$loop1$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: Int$arg-1$call-less$cond$if$body$loop$fun-readLine$class-MjpegReader, reason: not valid java name */
    private static int f2094Int$arg1$callless$cond$if$body$loop$funreadLine$classMjpegReader;

    /* JADX INFO: renamed from: Int$arg-1$call-less$cond$if$body$loop-2$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static int f2095Int$arg1$callless$cond$if$body$loop2$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: Int$val-emptyLines$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static int f2098Int$valemptyLines$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: Int$val-headerBytes$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static int f2099Int$valheaderBytes$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: Int$val-offset$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static int f2100Int$valoffset$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-equals$$this$call-not$cond$if$class-MjpegReader, reason: not valid java name */
    private static State<Boolean> f2104State$Boolean$arg1$callequals$$this$callnot$cond$if$classMjpegReader;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-equals$$this$call-not$cond$if-2$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<Boolean> f2105State$Boolean$arg1$callequals$$this$callnot$cond$if2$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-equals$fun-$anonymous$$arg-0$call-firstOrNull$val-tmp0_safe_receiver$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader, reason: not valid java name */
    private static State<Boolean> f2106State$Boolean$arg1$callequals$fun$anonymous$$arg0$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader;

    /* JADX INFO: renamed from: State$Char$0$vararg$arg-0$call-split$$$this$call-drop$$$this$call-map$$$this$call-firstOrNull$val-tmp0_safe_receiver$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader, reason: not valid java name */
    private static State<Character> f2107State$Char$0$vararg$arg0$callsplit$$$this$calldrop$$$this$callmap$$$this$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader;

    /* JADX INFO: renamed from: State$Char$arg-0$call-indexOf$val-colon$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<Character> f2108State$Char$arg0$callindexOf$valcolon$body$loop1$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$Char$arg-0$call-substringAfter$$$this$call-toLong$arg-0$call-plus$fun-timestamp$class-MjpegReader, reason: not valid java name */
    private static State<Character> f2109State$Char$arg0$callsubstringAfter$$$this$calltoLong$arg0$callplus$funtimestamp$classMjpegReader;

    /* JADX INFO: renamed from: State$Char$arg-0$call-substringAfter$else$when$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader, reason: not valid java name */
    private static State<Character> f2110State$Char$arg0$callsubstringAfter$else$when$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader;

    /* JADX INFO: renamed from: State$Char$arg-0$call-substringBefore$$$this$call-equals$fun-$anonymous$$arg-0$call-firstOrNull$val-tmp0_safe_receiver$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader, reason: not valid java name */
    private static State<Character> f2111State$Char$arg0$callsubstringBefore$$$this$callequals$fun$anonymous$$arg0$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader;

    /* JADX INFO: renamed from: State$Char$arg-0$call-substringBefore$$$this$call-toLong$val-seconds$fun-timestamp$class-MjpegReader, reason: not valid java name */
    private static State<Character> f2112State$Char$arg0$callsubstringBefore$$$this$calltoLong$valseconds$funtimestamp$classMjpegReader;

    /* JADX INFO: renamed from: State$Char$arg-0$call-substringBefore$$$this$call-trim$$$this$call-equals$$this$call-not$cond$if$class-MjpegReader, reason: not valid java name */
    private static State<Character> f2113State$Char$arg0$callsubstringBefore$$$this$calltrim$$$this$callequals$$this$callnot$cond$if$classMjpegReader;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$$this$call-not$cond$if-3$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<Integer> f2114State$Int$$this$callrangeTo$$this$callcontains$$this$callnot$cond$if3$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$$this$call-not$fun-$anonymous$$arg-0$call-any$else$cond$if-1$class-MjpegReader, reason: not valid java name */
    private static State<Integer> f2115State$Int$$this$callrangeTo$$this$callcontains$$this$callnot$fun$anonymous$$arg0$callany$else$cond$if1$classMjpegReader;

    /* JADX INFO: renamed from: State$Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$$this$call-not$else$cond$if-4$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<Integer> f2116State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if4$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$Int$arg-0$call-drop$$$this$call-map$$$this$call-firstOrNull$val-tmp0_safe_receiver$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader, reason: not valid java name */
    private static State<Integer> f2117State$Int$arg0$calldrop$$$this$callmap$$$this$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader;

    /* JADX INFO: renamed from: State$Int$arg-0$call-minus$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$$this$call-not$else$cond$if-4$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<Integer> f2118State$Int$arg0$callminus$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if4$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$Int$arg-0$call-plus$arg-0$call-plus$set-headerBytes$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<Integer> f2119State$Int$arg0$callplus$arg0$callplus$setheaderBytes$body$loop1$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$Int$arg-0$call-plus$arg-0$call-substring$$$this$call-trim$arg-1$call-put$arg-0$call-EQEQ$$this$call-not$cond$if-3$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<Integer> f2120State$Int$arg0$callplus$arg0$callsubstring$$$this$calltrim$arg1$callput$arg0$callEQEQ$$this$callnot$cond$if3$body$loop1$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rangeTo$$this$call-contains$$this$call-not$cond$if-3$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<Integer> f2121State$Int$arg0$callrangeTo$$this$callcontains$$this$callnot$cond$if3$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rangeTo$$this$call-contains$$this$call-not$fun-$anonymous$$arg-0$call-any$else$cond$if-1$class-MjpegReader, reason: not valid java name */
    private static State<Integer> f2122State$Int$arg0$callrangeTo$$this$callcontains$$this$callnot$fun$anonymous$$arg0$callany$else$cond$if1$classMjpegReader;

    /* JADX INFO: renamed from: State$Int$arg-0$call-substring$$$this$call-trim$$$this$call-lowercase$val-name$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<Integer> f2123State$Int$arg0$callsubstring$$$this$calltrim$$$this$calllowercase$valname$body$loop1$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$Int$arg-1$call-EQEQ$cond$if-1$body$loop$fun-readLine$class-MjpegReader, reason: not valid java name */
    private static State<Integer> f2124State$Int$arg1$callEQEQ$cond$if1$body$loop$funreadLine$classMjpegReader;

    /* JADX INFO: renamed from: State$Int$arg-1$call-greater$cond$if$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<Integer> f2125State$Int$arg1$callgreater$cond$if$body$loop1$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$Int$arg-1$call-less$cond$if$body$loop$fun-readLine$class-MjpegReader, reason: not valid java name */
    private static State<Integer> f2126State$Int$arg1$callless$cond$if$body$loop$funreadLine$classMjpegReader;

    /* JADX INFO: renamed from: State$Int$arg-1$call-less$cond$if$body$loop-2$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<Integer> f2127State$Int$arg1$callless$cond$if$body$loop2$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$Int$arg-1$call-less$cond$if-2$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<Integer> f2128State$Int$arg1$callless$cond$if2$body$loop1$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$Int$class-MjpegReader, reason: not valid java name */
    private static State<Integer> f2129State$Int$classMjpegReader;

    /* JADX INFO: renamed from: State$Int$val-emptyLines$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<Integer> f2130State$Int$valemptyLines$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$Int$val-headerBytes$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<Integer> f2131State$Int$valheaderBytes$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$Int$val-offset$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<Integer> f2132State$Int$valoffset$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$Long$arg-0$call-times$$this$call-plus$fun-timestamp$class-MjpegReader, reason: not valid java name */
    private static State<Long> f2133State$Long$arg0$calltimes$$this$callplus$funtimestamp$classMjpegReader;

    /* JADX INFO: renamed from: State$Long$arg-1$call-greater$cond$if-2$fun-timestamp$class-MjpegReader, reason: not valid java name */
    private static State<Long> f2134State$Long$arg1$callgreater$cond$if2$funtimestamp$classMjpegReader;

    /* JADX INFO: renamed from: State$Long$arg-1$call-lessOrEqual$fun-$anonymous$$arg-0$call-takeIf$else$when$val-tmp1_elvis_lhs$fun-sequence$class-MjpegReader, reason: not valid java name */
    private static State<Long> f2135State$Long$arg1$calllessOrEqual$fun$anonymous$$arg0$calltakeIf$else$when$valtmp1_elvis_lhs$funsequence$classMjpegReader;

    /* JADX INFO: renamed from: State$String$0$str$set-delimiter$class-MjpegReader, reason: not valid java name */
    private static State<String> f2136State$String$0$str$setdelimiter$classMjpegReader;

    /* JADX INFO: renamed from: State$String$1$str$arg-1$call-EQEQ$cond$if$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<String> f2137State$String$1$str$arg1$callEQEQ$cond$if$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$arg-0$call-matches$$this$call-not$cond$if-1$fun-sequence$class-MjpegReader, reason: not valid java name */
    private static State<String> f2138State$String$arg0$call$init$$arg0$callmatches$$this$callnot$cond$if1$funsequence$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$arg-0$call-matches$$this$call-not$cond$if-1$fun-timestamp$class-MjpegReader, reason: not valid java name */
    private static State<String> f2139State$String$arg0$call$init$$arg0$callmatches$$this$callnot$cond$if1$funtimestamp$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$branch$if$body$loop$fun-readLine$class-MjpegReader, reason: not valid java name */
    private static State<String> f2140State$String$arg0$call$init$$branch$if$body$loop$funreadLine$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$branch$if$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<String> f2141State$String$arg0$call$init$$branch$if$body$loop1$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$branch$if$body$loop-2$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<String> f2142State$String$arg0$call$init$$branch$if$body$loop2$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$branch$if$class-MjpegReader, reason: not valid java name */
    private static State<String> f2143State$String$arg0$call$init$$branch$if$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$branch$if-1$class-MjpegReader, reason: not valid java name */
    private static State<String> f2144State$String$arg0$call$init$$branch$if1$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$branch$if-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<String> f2145State$String$arg0$call$init$$branch$if1$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$branch$if-1$fun-sequence$class-MjpegReader, reason: not valid java name */
    private static State<String> f2146State$String$arg0$call$init$$branch$if1$funsequence$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$branch$if-1$fun-timestamp$class-MjpegReader, reason: not valid java name */
    private static State<String> f2147State$String$arg0$call$init$$branch$if1$funtimestamp$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$branch$if-2$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<String> f2148State$String$arg0$call$init$$branch$if2$body$loop1$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$branch$if-2$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<String> f2149State$String$arg0$call$init$$branch$if2$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$branch$if-2$fun-timestamp$class-MjpegReader, reason: not valid java name */
    private static State<String> f2150State$String$arg0$call$init$$branch$if2$funtimestamp$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$branch$if-3$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<String> f2151State$String$arg0$call$init$$branch$if3$body$loop1$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$branch$if-3$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<String> f2152State$String$arg0$call$init$$branch$if3$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$branch$if-4$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<String> f2153State$String$arg0$call$init$$branch$if4$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$branch$when$fun-sequence$class-MjpegReader, reason: not valid java name */
    private static State<String> f2154State$String$arg0$call$init$$branch$when$funsequence$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$branch$when$set-line$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<String> f2155State$String$arg0$call$init$$branch$when$setline$body$loop1$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$branch$when$val-boundary$class-MjpegReader, reason: not valid java name */
    private static State<String> f2156State$String$arg0$call$init$$branch$when$valboundary$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$branch$when$val-length$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<String> f2157State$String$arg0$call$init$$branch$when$vallength$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$fun-readLine$class-MjpegReader, reason: not valid java name */
    private static State<String> f2158State$String$arg0$call$init$$funreadLine$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-equals$$this$call-not$cond$if$class-MjpegReader, reason: not valid java name */
    private static State<String> f2159State$String$arg0$callequals$$this$callnot$cond$if$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-equals$$this$call-not$cond$if-2$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<String> f2160State$String$arg0$callequals$$this$callnot$cond$if2$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-equals$fun-$anonymous$$arg-0$call-firstOrNull$val-tmp0_safe_receiver$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader, reason: not valid java name */
    private static State<String> f2161State$String$arg0$callequals$fun$anonymous$$arg0$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-get$$$this$call-equals$$this$call-not$cond$if-2$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<String> f2162State$String$arg0$callget$$$this$callequals$$this$callnot$cond$if2$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-get$arg-0$call-sequence$arg-1$call-$init$$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<String> f2163State$String$arg0$callget$arg0$callsequence$arg1$call$init$$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-get$arg-0$call-timestamp$arg-2$call-$init$$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<String> f2164State$String$arg0$callget$arg0$calltimestamp$arg2$call$init$$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-get$val-tmp4_safe_receiver$val-tmp5_elvis_lhs$val-length$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static State<String> f2165State$String$arg0$callget$valtmp4_safe_receiver$valtmp5_elvis_lhs$vallength$funnextPart$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-removeSuffix$branch$if-1$body$loop$fun-readLine$class-MjpegReader, reason: not valid java name */
    private static State<String> f2166State$String$arg0$callremoveSuffix$branch$if1$body$loop$funreadLine$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-0$call-removeSurrounding$else$when$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader, reason: not valid java name */
    private static State<String> f2167State$String$arg0$callremoveSurrounding$else$when$valtmp3_elvis_lhs$valboundary$classMjpegReader;

    /* JADX INFO: renamed from: State$String$arg-1$call-substringAfter$else$when$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader, reason: not valid java name */
    private static State<String> f2168State$String$arg1$callsubstringAfter$else$when$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader;
    public static final LiveLiterals$MjpegReaderKt INSTANCE = new LiveLiterals$MjpegReaderKt();

    /* JADX INFO: renamed from: Char$arg-0$call-substringBefore$$$this$call-trim$$$this$call-equals$$this$call-not$cond$if$class-MjpegReader, reason: not valid java name */
    private static char f2081Char$arg0$callsubstringBefore$$$this$calltrim$$$this$callequals$$this$callnot$cond$if$classMjpegReader = ';';

    /* JADX INFO: renamed from: String$arg-0$call-equals$$this$call-not$cond$if$class-MjpegReader, reason: not valid java name */
    private static String f2192String$arg0$callequals$$this$callnot$cond$if$classMjpegReader = "multipart/x-mixed-replace";

    /* JADX INFO: renamed from: Boolean$arg-1$call-equals$$this$call-not$cond$if$class-MjpegReader, reason: not valid java name */
    private static boolean f2072Boolean$arg1$callequals$$this$callnot$cond$if$classMjpegReader = true;

    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if$class-MjpegReader, reason: not valid java name */
    private static String f2176String$arg0$call$init$$branch$if$classMjpegReader = "Expected multipart MJPEG";

    /* JADX INFO: renamed from: Char$0$vararg$arg-0$call-split$$$this$call-drop$$$this$call-map$$$this$call-firstOrNull$val-tmp0_safe_receiver$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader, reason: not valid java name */
    private static char f2075Char$0$vararg$arg0$callsplit$$$this$calldrop$$$this$callmap$$$this$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader = ';';

    /* JADX INFO: renamed from: Int$arg-0$call-drop$$$this$call-map$$$this$call-firstOrNull$val-tmp0_safe_receiver$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader, reason: not valid java name */
    private static int f2085Int$arg0$calldrop$$$this$callmap$$$this$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader = 1;

    /* JADX INFO: renamed from: Char$arg-0$call-substringBefore$$$this$call-equals$fun-$anonymous$$arg-0$call-firstOrNull$val-tmp0_safe_receiver$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader, reason: not valid java name */
    private static char f2079Char$arg0$callsubstringBefore$$$this$callequals$fun$anonymous$$arg0$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader = '=';

    /* JADX INFO: renamed from: String$arg-0$call-equals$fun-$anonymous$$arg-0$call-firstOrNull$val-tmp0_safe_receiver$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader, reason: not valid java name */
    private static String f2194String$arg0$callequals$fun$anonymous$$arg0$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader = "boundary";

    /* JADX INFO: renamed from: Boolean$arg-1$call-equals$fun-$anonymous$$arg-0$call-firstOrNull$val-tmp0_safe_receiver$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader, reason: not valid java name */
    private static boolean f2074Boolean$arg1$callequals$fun$anonymous$$arg0$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader = true;

    /* JADX INFO: renamed from: Char$arg-0$call-substringAfter$else$when$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader, reason: not valid java name */
    private static char f2078Char$arg0$callsubstringAfter$else$when$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader = '=';

    /* JADX INFO: renamed from: String$arg-1$call-substringAfter$else$when$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader, reason: not valid java name */
    private static String f2201String$arg1$callsubstringAfter$else$when$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader = "";

    /* JADX INFO: renamed from: String$arg-0$call-removeSurrounding$else$when$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader, reason: not valid java name */
    private static String f2200String$arg0$callremoveSurrounding$else$when$valtmp3_elvis_lhs$valboundary$classMjpegReader = "\"";

    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$when$val-boundary$class-MjpegReader, reason: not valid java name */
    private static String f2189String$arg0$call$init$$branch$when$valboundary$classMjpegReader = "Missing boundary";

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$$this$call-not$fun-$anonymous$$arg-0$call-any$else$cond$if-1$class-MjpegReader, reason: not valid java name */
    private static int f2083Int$$this$callrangeTo$$this$callcontains$$this$callnot$fun$anonymous$$arg0$callany$else$cond$if1$classMjpegReader = 33;

    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$$this$call-not$fun-$anonymous$$arg-0$call-any$else$cond$if-1$class-MjpegReader, reason: not valid java name */
    private static int f2090Int$arg0$callrangeTo$$this$callcontains$$this$callnot$fun$anonymous$$arg0$callany$else$cond$if1$classMjpegReader = 126;

    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if-1$class-MjpegReader, reason: not valid java name */
    private static String f2177String$arg0$call$init$$branch$if1$classMjpegReader = "Invalid boundary";

    /* JADX INFO: renamed from: String$0$str$set-delimiter$class-MjpegReader, reason: not valid java name */
    private static String f2169String$0$str$setdelimiter$classMjpegReader = "--";

    /* JADX INFO: renamed from: String$1$str$arg-1$call-EQEQ$cond$if$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static String f2170String$1$str$arg1$callEQEQ$cond$if$funnextPart$classMjpegReader = "--";

    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static String f2178String$arg0$call$init$$branch$if1$funnextPart$classMjpegReader = "Invalid frame boundary";

    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$when$set-line$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static String f2188String$arg0$call$init$$branch$when$setline$body$loop1$funnextPart$classMjpegReader = "Incomplete headers";

    /* JADX INFO: renamed from: Int$arg-0$call-plus$arg-0$call-plus$set-headerBytes$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static int f2087Int$arg0$callplus$arg0$callplus$setheaderBytes$body$loop1$funnextPart$classMjpegReader = 2;

    /* JADX INFO: renamed from: Int$arg-1$call-greater$cond$if$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static int f2093Int$arg1$callgreater$cond$if$body$loop1$funnextPart$classMjpegReader = 16384;

    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static String f2174String$arg0$call$init$$branch$if$body$loop1$funnextPart$classMjpegReader = "Headers too large";

    /* JADX INFO: renamed from: Char$arg-0$call-indexOf$val-colon$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static char f2076Char$arg0$callindexOf$valcolon$body$loop1$funnextPart$classMjpegReader = ':';

    /* JADX INFO: renamed from: Int$arg-1$call-less$cond$if-2$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static int f2096Int$arg1$callless$cond$if2$body$loop1$funnextPart$classMjpegReader = 1;

    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if-2$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static String f2181String$arg0$call$init$$branch$if2$body$loop1$funnextPart$classMjpegReader = "Invalid header";

    /* JADX INFO: renamed from: Int$arg-0$call-plus$arg-0$call-substring$$$this$call-trim$arg-1$call-put$arg-0$call-EQEQ$$this$call-not$cond$if-3$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static int f2088Int$arg0$callplus$arg0$callsubstring$$$this$calltrim$arg1$callput$arg0$callEQEQ$$this$callnot$cond$if3$body$loop1$funnextPart$classMjpegReader = 1;

    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if-3$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static String f2184String$arg0$call$init$$branch$if3$body$loop1$funnextPart$classMjpegReader = "Duplicate header";

    /* JADX INFO: renamed from: String$arg-0$call-get$$$this$call-equals$$this$call-not$cond$if-2$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static String f2195String$arg0$callget$$$this$callequals$$this$callnot$cond$if2$funnextPart$classMjpegReader = "content-type";

    /* JADX INFO: renamed from: String$arg-0$call-equals$$this$call-not$cond$if-2$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static String f2193String$arg0$callequals$$this$callnot$cond$if2$funnextPart$classMjpegReader = "image/jpeg";

    /* JADX INFO: renamed from: Boolean$arg-1$call-equals$$this$call-not$cond$if-2$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static boolean f2073Boolean$arg1$callequals$$this$callnot$cond$if2$funnextPart$classMjpegReader = true;

    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if-2$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static String f2182String$arg0$call$init$$branch$if2$funnextPart$classMjpegReader = "Expected JPEG part";

    /* JADX INFO: renamed from: String$arg-0$call-get$val-tmp4_safe_receiver$val-tmp5_elvis_lhs$val-length$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static String f2198String$arg0$callget$valtmp4_safe_receiver$valtmp5_elvis_lhs$vallength$funnextPart$classMjpegReader = "content-length";

    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$when$val-length$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static String f2190String$arg0$call$init$$branch$when$vallength$funnextPart$classMjpegReader = "Missing JPEG length";

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$$this$call-not$cond$if-3$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static int f2082Int$$this$callrangeTo$$this$callcontains$$this$callnot$cond$if3$funnextPart$classMjpegReader = 4;

    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$$this$call-not$cond$if-3$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static int f2089Int$arg0$callrangeTo$$this$callcontains$$this$callnot$cond$if3$funnextPart$classMjpegReader = 524288;

    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if-3$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static String f2185String$arg0$call$init$$branch$if3$funnextPart$classMjpegReader = "JPEG exceeds frame size limit";

    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if$body$loop-2$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static String f2175String$arg0$call$init$$branch$if$body$loop2$funnextPart$classMjpegReader = "Incomplete JPEG";

    /* JADX INFO: renamed from: Int$arg-0$call-minus$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$$this$call-not$else$cond$if-4$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static int f2086Int$arg0$callminus$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if4$funnextPart$classMjpegReader = 1;

    /* JADX INFO: renamed from: Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$$this$call-not$else$cond$if-4$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static int f2084Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if4$funnextPart$classMjpegReader = 217;

    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if-4$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static String f2186String$arg0$call$init$$branch$if4$funnextPart$classMjpegReader = "Invalid JPEG markers";

    /* JADX INFO: renamed from: String$arg-0$call-get$arg-0$call-sequence$arg-1$call-$init$$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static String f2196String$arg0$callget$arg0$callsequence$arg1$call$init$$funnextPart$classMjpegReader = "x-sequence";

    /* JADX INFO: renamed from: String$arg-0$call-get$arg-0$call-timestamp$arg-2$call-$init$$fun-nextPart$class-MjpegReader, reason: not valid java name */
    private static String f2197String$arg0$callget$arg0$calltimestamp$arg2$call$init$$funnextPart$classMjpegReader = "x-timestamp";

    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-0$call-matches$$this$call-not$cond$if-1$fun-sequence$class-MjpegReader, reason: not valid java name */
    private static String f2171String$arg0$call$init$$arg0$callmatches$$this$callnot$cond$if1$funsequence$classMjpegReader = "[0-9]{1,10}";

    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if-1$fun-sequence$class-MjpegReader, reason: not valid java name */
    private static String f2179String$arg0$call$init$$branch$if1$funsequence$classMjpegReader = "Invalid frame sequence";

    /* JADX INFO: renamed from: Long$arg-1$call-lessOrEqual$fun-$anonymous$$arg-0$call-takeIf$else$when$val-tmp1_elvis_lhs$fun-sequence$class-MjpegReader, reason: not valid java name */
    private static long f2103Long$arg1$calllessOrEqual$fun$anonymous$$arg0$calltakeIf$else$when$valtmp1_elvis_lhs$funsequence$classMjpegReader = 4294967295L;

    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$when$fun-sequence$class-MjpegReader, reason: not valid java name */
    private static String f2187String$arg0$call$init$$branch$when$funsequence$classMjpegReader = "Invalid frame sequence";

    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-0$call-matches$$this$call-not$cond$if-1$fun-timestamp$class-MjpegReader, reason: not valid java name */
    private static String f2172String$arg0$call$init$$arg0$callmatches$$this$callnot$cond$if1$funtimestamp$classMjpegReader = "[0-9]{1,10}\\.[0-9]{6}";

    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if-1$fun-timestamp$class-MjpegReader, reason: not valid java name */
    private static String f2180String$arg0$call$init$$branch$if1$funtimestamp$classMjpegReader = "Invalid capture timestamp";

    /* JADX INFO: renamed from: Char$arg-0$call-substringBefore$$$this$call-toLong$val-seconds$fun-timestamp$class-MjpegReader, reason: not valid java name */
    private static char f2080Char$arg0$callsubstringBefore$$$this$calltoLong$valseconds$funtimestamp$classMjpegReader = '.';

    /* JADX INFO: renamed from: Long$arg-1$call-greater$cond$if-2$fun-timestamp$class-MjpegReader, reason: not valid java name */
    private static long f2102Long$arg1$callgreater$cond$if2$funtimestamp$classMjpegReader = 4294967295L;

    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if-2$fun-timestamp$class-MjpegReader, reason: not valid java name */
    private static String f2183String$arg0$call$init$$branch$if2$funtimestamp$classMjpegReader = "Invalid capture timestamp";

    /* JADX INFO: renamed from: Long$arg-0$call-times$$this$call-plus$fun-timestamp$class-MjpegReader, reason: not valid java name */
    private static long f2101Long$arg0$calltimes$$this$callplus$funtimestamp$classMjpegReader = 1000000;

    /* JADX INFO: renamed from: Char$arg-0$call-substringAfter$$$this$call-toLong$arg-0$call-plus$fun-timestamp$class-MjpegReader, reason: not valid java name */
    private static char f2077Char$arg0$callsubstringAfter$$$this$calltoLong$arg0$callplus$funtimestamp$classMjpegReader = '.';

    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if$body$loop$fun-readLine$class-MjpegReader, reason: not valid java name */
    private static String f2173String$arg0$call$init$$branch$if$body$loop$funreadLine$classMjpegReader = "Incomplete line";

    /* JADX INFO: renamed from: Int$arg-1$call-EQEQ$cond$if-1$body$loop$fun-readLine$class-MjpegReader, reason: not valid java name */
    private static int f2092Int$arg1$callEQEQ$cond$if1$body$loop$funreadLine$classMjpegReader = 10;

    /* JADX INFO: renamed from: String$arg-0$call-removeSuffix$branch$if-1$body$loop$fun-readLine$class-MjpegReader, reason: not valid java name */
    private static String f2199String$arg0$callremoveSuffix$branch$if1$body$loop$funreadLine$classMjpegReader = "\r";

    /* JADX INFO: renamed from: String$arg-0$call-$init$$fun-readLine$class-MjpegReader, reason: not valid java name */
    private static String f2191String$arg0$call$init$$funreadLine$classMjpegReader = "Line too long";

    /* JADX INFO: renamed from: Int$class-MjpegReader, reason: not valid java name */
    private static int f2097Int$classMjpegReader = 8;

    @LiveLiteralInfo(key = "Boolean$arg-1$call-equals$$this$call-not$cond$if$class-MjpegReader", offset = 463)
    /* JADX INFO: renamed from: Boolean$arg-1$call-equals$$this$call-not$cond$if$class-MjpegReader, reason: not valid java name */
    public final boolean m7042Boolean$arg1$callequals$$this$callnot$cond$if$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2072Boolean$arg1$callequals$$this$callnot$cond$if$classMjpegReader;
        }
        State<Boolean> stateLiveLiteral = f2104State$Boolean$arg1$callequals$$this$callnot$cond$if$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-equals$$this$call-not$cond$if$class-MjpegReader", Boolean.valueOf(f2072Boolean$arg1$callequals$$this$callnot$cond$if$classMjpegReader));
            f2104State$Boolean$arg1$callequals$$this$callnot$cond$if$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-equals$$this$call-not$cond$if-2$fun-nextPart$class-MjpegReader", offset = 2082)
    /* JADX INFO: renamed from: Boolean$arg-1$call-equals$$this$call-not$cond$if-2$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final boolean m7043Boolean$arg1$callequals$$this$callnot$cond$if2$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2073Boolean$arg1$callequals$$this$callnot$cond$if2$funnextPart$classMjpegReader;
        }
        State<Boolean> stateLiveLiteral = f2105State$Boolean$arg1$callequals$$this$callnot$cond$if2$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-equals$$this$call-not$cond$if-2$fun-nextPart$class-MjpegReader", Boolean.valueOf(f2073Boolean$arg1$callequals$$this$callnot$cond$if2$funnextPart$classMjpegReader));
            f2105State$Boolean$arg1$callequals$$this$callnot$cond$if2$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-equals$fun-$anonymous$$arg-0$call-firstOrNull$val-tmp0_safe_receiver$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader", offset = 670)
    /* JADX INFO: renamed from: Boolean$arg-1$call-equals$fun-$anonymous$$arg-0$call-firstOrNull$val-tmp0_safe_receiver$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader, reason: not valid java name */
    public final boolean m7044Boolean$arg1$callequals$fun$anonymous$$arg0$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2074Boolean$arg1$callequals$fun$anonymous$$arg0$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader;
        }
        State<Boolean> stateLiveLiteral = f2106State$Boolean$arg1$callequals$fun$anonymous$$arg0$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-equals$fun-$anonymous$$arg-0$call-firstOrNull$val-tmp0_safe_receiver$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader", Boolean.valueOf(f2074Boolean$arg1$callequals$fun$anonymous$$arg0$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader));
            f2106State$Boolean$arg1$callequals$fun$anonymous$$arg0$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Char$0$vararg$arg-0$call-split$$$this$call-drop$$$this$call-map$$$this$call-firstOrNull$val-tmp0_safe_receiver$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader", offset = 569)
    /* JADX INFO: renamed from: Char$0$vararg$arg-0$call-split$$$this$call-drop$$$this$call-map$$$this$call-firstOrNull$val-tmp0_safe_receiver$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader, reason: not valid java name */
    public final char m7045Char$0$vararg$arg0$callsplit$$$this$calldrop$$$this$callmap$$$this$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2075Char$0$vararg$arg0$callsplit$$$this$calldrop$$$this$callmap$$$this$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader;
        }
        State<Character> stateLiveLiteral = f2107State$Char$0$vararg$arg0$callsplit$$$this$calldrop$$$this$callmap$$$this$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Char$0$vararg$arg-0$call-split$$$this$call-drop$$$this$call-map$$$this$call-firstOrNull$val-tmp0_safe_receiver$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader", Character.valueOf(f2075Char$0$vararg$arg0$callsplit$$$this$calldrop$$$this$callmap$$$this$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader));
            f2107State$Char$0$vararg$arg0$callsplit$$$this$calldrop$$$this$callmap$$$this$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().charValue();
    }

    @LiveLiteralInfo(key = "Char$arg-0$call-indexOf$val-colon$body$loop-1$fun-nextPart$class-MjpegReader", offset = 1737)
    /* JADX INFO: renamed from: Char$arg-0$call-indexOf$val-colon$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final char m7046Char$arg0$callindexOf$valcolon$body$loop1$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2076Char$arg0$callindexOf$valcolon$body$loop1$funnextPart$classMjpegReader;
        }
        State<Character> stateLiveLiteral = f2108State$Char$arg0$callindexOf$valcolon$body$loop1$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Char$arg-0$call-indexOf$val-colon$body$loop-1$fun-nextPart$class-MjpegReader", Character.valueOf(f2076Char$arg0$callindexOf$valcolon$body$loop1$funnextPart$classMjpegReader));
            f2108State$Char$arg0$callindexOf$valcolon$body$loop1$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().charValue();
    }

    @LiveLiteralInfo(key = "Char$arg-0$call-substringAfter$$$this$call-toLong$arg-0$call-plus$fun-timestamp$class-MjpegReader", offset = 3706)
    /* JADX INFO: renamed from: Char$arg-0$call-substringAfter$$$this$call-toLong$arg-0$call-plus$fun-timestamp$class-MjpegReader, reason: not valid java name */
    public final char m7047Char$arg0$callsubstringAfter$$$this$calltoLong$arg0$callplus$funtimestamp$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2077Char$arg0$callsubstringAfter$$$this$calltoLong$arg0$callplus$funtimestamp$classMjpegReader;
        }
        State<Character> stateLiveLiteral = f2109State$Char$arg0$callsubstringAfter$$$this$calltoLong$arg0$callplus$funtimestamp$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Char$arg-0$call-substringAfter$$$this$call-toLong$arg-0$call-plus$fun-timestamp$class-MjpegReader", Character.valueOf(f2077Char$arg0$callsubstringAfter$$$this$calltoLong$arg0$callplus$funtimestamp$classMjpegReader));
            f2109State$Char$arg0$callsubstringAfter$$$this$calltoLong$arg0$callplus$funtimestamp$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().charValue();
    }

    @LiveLiteralInfo(key = "Char$arg-0$call-substringAfter$else$when$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader", offset = 707)
    /* JADX INFO: renamed from: Char$arg-0$call-substringAfter$else$when$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader, reason: not valid java name */
    public final char m7048Char$arg0$callsubstringAfter$else$when$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2078Char$arg0$callsubstringAfter$else$when$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader;
        }
        State<Character> stateLiveLiteral = f2110State$Char$arg0$callsubstringAfter$else$when$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Char$arg-0$call-substringAfter$else$when$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader", Character.valueOf(f2078Char$arg0$callsubstringAfter$else$when$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader));
            f2110State$Char$arg0$callsubstringAfter$else$when$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().charValue();
    }

    @LiveLiteralInfo(key = "Char$arg-0$call-substringBefore$$$this$call-equals$fun-$anonymous$$arg-0$call-firstOrNull$val-tmp0_safe_receiver$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader", offset = 646)
    /* JADX INFO: renamed from: Char$arg-0$call-substringBefore$$$this$call-equals$fun-$anonymous$$arg-0$call-firstOrNull$val-tmp0_safe_receiver$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader, reason: not valid java name */
    public final char m7049Char$arg0$callsubstringBefore$$$this$callequals$fun$anonymous$$arg0$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2079Char$arg0$callsubstringBefore$$$this$callequals$fun$anonymous$$arg0$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader;
        }
        State<Character> stateLiveLiteral = f2111State$Char$arg0$callsubstringBefore$$$this$callequals$fun$anonymous$$arg0$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Char$arg-0$call-substringBefore$$$this$call-equals$fun-$anonymous$$arg-0$call-firstOrNull$val-tmp0_safe_receiver$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader", Character.valueOf(f2079Char$arg0$callsubstringBefore$$$this$callequals$fun$anonymous$$arg0$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader));
            f2111State$Char$arg0$callsubstringBefore$$$this$callequals$fun$anonymous$$arg0$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().charValue();
    }

    @LiveLiteralInfo(key = "Char$arg-0$call-substringBefore$$$this$call-toLong$val-seconds$fun-timestamp$class-MjpegReader", offset = 3550)
    /* JADX INFO: renamed from: Char$arg-0$call-substringBefore$$$this$call-toLong$val-seconds$fun-timestamp$class-MjpegReader, reason: not valid java name */
    public final char m7050Char$arg0$callsubstringBefore$$$this$calltoLong$valseconds$funtimestamp$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2080Char$arg0$callsubstringBefore$$$this$calltoLong$valseconds$funtimestamp$classMjpegReader;
        }
        State<Character> stateLiveLiteral = f2112State$Char$arg0$callsubstringBefore$$$this$calltoLong$valseconds$funtimestamp$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Char$arg-0$call-substringBefore$$$this$call-toLong$val-seconds$fun-timestamp$class-MjpegReader", Character.valueOf(f2080Char$arg0$callsubstringBefore$$$this$calltoLong$valseconds$funtimestamp$classMjpegReader));
            f2112State$Char$arg0$callsubstringBefore$$$this$calltoLong$valseconds$funtimestamp$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().charValue();
    }

    @LiveLiteralInfo(key = "Char$arg-0$call-substringBefore$$$this$call-trim$$$this$call-equals$$this$call-not$cond$if$class-MjpegReader", offset = 415)
    /* JADX INFO: renamed from: Char$arg-0$call-substringBefore$$$this$call-trim$$$this$call-equals$$this$call-not$cond$if$class-MjpegReader, reason: not valid java name */
    public final char m7051Char$arg0$callsubstringBefore$$$this$calltrim$$$this$callequals$$this$callnot$cond$if$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2081Char$arg0$callsubstringBefore$$$this$calltrim$$$this$callequals$$this$callnot$cond$if$classMjpegReader;
        }
        State<Character> stateLiveLiteral = f2113State$Char$arg0$callsubstringBefore$$$this$calltrim$$$this$callequals$$this$callnot$cond$if$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Char$arg-0$call-substringBefore$$$this$call-trim$$$this$call-equals$$this$call-not$cond$if$class-MjpegReader", Character.valueOf(f2081Char$arg0$callsubstringBefore$$$this$calltrim$$$this$callequals$$this$callnot$cond$if$classMjpegReader));
            f2113State$Char$arg0$callsubstringBefore$$$this$calltrim$$$this$callequals$$this$callnot$cond$if$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().charValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$$this$call-not$cond$if-3$fun-nextPart$class-MjpegReader", offset = 2258)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$$this$call-not$cond$if-3$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final int m7052Int$$this$callrangeTo$$this$callcontains$$this$callnot$cond$if3$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2082Int$$this$callrangeTo$$this$callcontains$$this$callnot$cond$if3$funnextPart$classMjpegReader;
        }
        State<Integer> stateLiveLiteral = f2114State$Int$$this$callrangeTo$$this$callcontains$$this$callnot$cond$if3$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$$this$call-not$cond$if-3$fun-nextPart$class-MjpegReader", Integer.valueOf(f2082Int$$this$callrangeTo$$this$callcontains$$this$callnot$cond$if3$funnextPart$classMjpegReader));
            f2114State$Int$$this$callrangeTo$$this$callcontains$$this$callnot$cond$if3$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$$this$call-not$fun-$anonymous$$arg-0$call-any$else$cond$if-1$class-MjpegReader", offset = 887)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$$this$call-not$fun-$anonymous$$arg-0$call-any$else$cond$if-1$class-MjpegReader, reason: not valid java name */
    public final int m7053Int$$this$callrangeTo$$this$callcontains$$this$callnot$fun$anonymous$$arg0$callany$else$cond$if1$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2083Int$$this$callrangeTo$$this$callcontains$$this$callnot$fun$anonymous$$arg0$callany$else$cond$if1$classMjpegReader;
        }
        State<Integer> stateLiveLiteral = f2115State$Int$$this$callrangeTo$$this$callcontains$$this$callnot$fun$anonymous$$arg0$callany$else$cond$if1$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$$this$call-not$fun-$anonymous$$arg-0$call-any$else$cond$if-1$class-MjpegReader", Integer.valueOf(f2083Int$$this$callrangeTo$$this$callcontains$$this$callnot$fun$anonymous$$arg0$callany$else$cond$if1$classMjpegReader));
            f2115State$Int$$this$callrangeTo$$this$callcontains$$this$callnot$fun$anonymous$$arg0$callany$else$cond$if1$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$$this$call-not$else$cond$if-4$fun-nextPart$class-MjpegReader", offset = 2727)
    /* JADX INFO: renamed from: Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$$this$call-not$else$cond$if-4$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final int m7054Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if4$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2084Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if4$funnextPart$classMjpegReader;
        }
        State<Integer> stateLiveLiteral = f2116State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if4$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-toByte$$this$call-toInt$arg-1$call-EQEQ$$this$call-not$else$cond$if-4$fun-nextPart$class-MjpegReader", Integer.valueOf(f2084Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if4$funnextPart$classMjpegReader));
            f2116State$Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if4$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-drop$$$this$call-map$$$this$call-firstOrNull$val-tmp0_safe_receiver$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader", offset = 579)
    /* JADX INFO: renamed from: Int$arg-0$call-drop$$$this$call-map$$$this$call-firstOrNull$val-tmp0_safe_receiver$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader, reason: not valid java name */
    public final int m7055Int$arg0$calldrop$$$this$callmap$$$this$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2085Int$arg0$calldrop$$$this$callmap$$$this$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader;
        }
        State<Integer> stateLiveLiteral = f2117State$Int$arg0$calldrop$$$this$callmap$$$this$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-drop$$$this$call-map$$$this$call-firstOrNull$val-tmp0_safe_receiver$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader", Integer.valueOf(f2085Int$arg0$calldrop$$$this$callmap$$$this$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader));
            f2117State$Int$arg0$calldrop$$$this$callmap$$$this$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-minus$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$$this$call-not$else$cond$if-4$fun-nextPart$class-MjpegReader", offset = 2721)
    /* JADX INFO: renamed from: Int$arg-0$call-minus$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$$this$call-not$else$cond$if-4$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final int m7056Int$arg0$callminus$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if4$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2086Int$arg0$callminus$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if4$funnextPart$classMjpegReader;
        }
        State<Integer> stateLiveLiteral = f2118State$Int$arg0$callminus$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if4$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-minus$arg-0$call-get$$this$call-toInt$arg-0$call-EQEQ$$this$call-not$else$cond$if-4$fun-nextPart$class-MjpegReader", Integer.valueOf(f2086Int$arg0$callminus$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if4$funnextPart$classMjpegReader));
            f2118State$Int$arg0$callminus$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if4$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-plus$arg-0$call-plus$set-headerBytes$body$loop-1$fun-nextPart$class-MjpegReader", offset = 1583)
    /* JADX INFO: renamed from: Int$arg-0$call-plus$arg-0$call-plus$set-headerBytes$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final int m7057Int$arg0$callplus$arg0$callplus$setheaderBytes$body$loop1$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2087Int$arg0$callplus$arg0$callplus$setheaderBytes$body$loop1$funnextPart$classMjpegReader;
        }
        State<Integer> stateLiveLiteral = f2119State$Int$arg0$callplus$arg0$callplus$setheaderBytes$body$loop1$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-plus$arg-0$call-plus$set-headerBytes$body$loop-1$fun-nextPart$class-MjpegReader", Integer.valueOf(f2087Int$arg0$callplus$arg0$callplus$setheaderBytes$body$loop1$funnextPart$classMjpegReader));
            f2119State$Int$arg0$callplus$arg0$callplus$setheaderBytes$body$loop1$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-plus$arg-0$call-substring$$$this$call-trim$arg-1$call-put$arg-0$call-EQEQ$$this$call-not$cond$if-3$body$loop-1$fun-nextPart$class-MjpegReader", offset = 1940)
    /* JADX INFO: renamed from: Int$arg-0$call-plus$arg-0$call-substring$$$this$call-trim$arg-1$call-put$arg-0$call-EQEQ$$this$call-not$cond$if-3$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final int m7058Int$arg0$callplus$arg0$callsubstring$$$this$calltrim$arg1$callput$arg0$callEQEQ$$this$callnot$cond$if3$body$loop1$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2088Int$arg0$callplus$arg0$callsubstring$$$this$calltrim$arg1$callput$arg0$callEQEQ$$this$callnot$cond$if3$body$loop1$funnextPart$classMjpegReader;
        }
        State<Integer> stateLiveLiteral = f2120State$Int$arg0$callplus$arg0$callsubstring$$$this$calltrim$arg1$callput$arg0$callEQEQ$$this$callnot$cond$if3$body$loop1$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-plus$arg-0$call-substring$$$this$call-trim$arg-1$call-put$arg-0$call-EQEQ$$this$call-not$cond$if-3$body$loop-1$fun-nextPart$class-MjpegReader", Integer.valueOf(f2088Int$arg0$callplus$arg0$callsubstring$$$this$calltrim$arg1$callput$arg0$callEQEQ$$this$callnot$cond$if3$body$loop1$funnextPart$classMjpegReader));
            f2120State$Int$arg0$callplus$arg0$callsubstring$$$this$calltrim$arg1$callput$arg0$callEQEQ$$this$callnot$cond$if3$body$loop1$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rangeTo$$this$call-contains$$this$call-not$cond$if-3$fun-nextPart$class-MjpegReader", offset = 2261)
    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$$this$call-not$cond$if-3$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final int m7059Int$arg0$callrangeTo$$this$callcontains$$this$callnot$cond$if3$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2089Int$arg0$callrangeTo$$this$callcontains$$this$callnot$cond$if3$funnextPart$classMjpegReader;
        }
        State<Integer> stateLiveLiteral = f2121State$Int$arg0$callrangeTo$$this$callcontains$$this$callnot$cond$if3$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rangeTo$$this$call-contains$$this$call-not$cond$if-3$fun-nextPart$class-MjpegReader", Integer.valueOf(f2089Int$arg0$callrangeTo$$this$callcontains$$this$callnot$cond$if3$funnextPart$classMjpegReader));
            f2121State$Int$arg0$callrangeTo$$this$callcontains$$this$callnot$cond$if3$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rangeTo$$this$call-contains$$this$call-not$fun-$anonymous$$arg-0$call-any$else$cond$if-1$class-MjpegReader", offset = 891)
    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$$this$call-not$fun-$anonymous$$arg-0$call-any$else$cond$if-1$class-MjpegReader, reason: not valid java name */
    public final int m7060Int$arg0$callrangeTo$$this$callcontains$$this$callnot$fun$anonymous$$arg0$callany$else$cond$if1$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2090Int$arg0$callrangeTo$$this$callcontains$$this$callnot$fun$anonymous$$arg0$callany$else$cond$if1$classMjpegReader;
        }
        State<Integer> stateLiveLiteral = f2122State$Int$arg0$callrangeTo$$this$callcontains$$this$callnot$fun$anonymous$$arg0$callany$else$cond$if1$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rangeTo$$this$call-contains$$this$call-not$fun-$anonymous$$arg-0$call-any$else$cond$if-1$class-MjpegReader", Integer.valueOf(f2090Int$arg0$callrangeTo$$this$callcontains$$this$callnot$fun$anonymous$$arg0$callany$else$cond$if1$classMjpegReader));
            f2122State$Int$arg0$callrangeTo$$this$callcontains$$this$callnot$fun$anonymous$$arg0$callany$else$cond$if1$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-substring$$$this$call-trim$$$this$call-lowercase$val-name$body$loop-1$fun-nextPart$class-MjpegReader", offset = 1843)
    /* JADX INFO: renamed from: Int$arg-0$call-substring$$$this$call-trim$$$this$call-lowercase$val-name$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final int m7061Int$arg0$callsubstring$$$this$calltrim$$$this$calllowercase$valname$body$loop1$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2091Int$arg0$callsubstring$$$this$calltrim$$$this$calllowercase$valname$body$loop1$funnextPart$classMjpegReader;
        }
        State<Integer> stateLiveLiteral = f2123State$Int$arg0$callsubstring$$$this$calltrim$$$this$calllowercase$valname$body$loop1$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-substring$$$this$call-trim$$$this$call-lowercase$val-name$body$loop-1$fun-nextPart$class-MjpegReader", Integer.valueOf(f2091Int$arg0$callsubstring$$$this$calltrim$$$this$calllowercase$valname$body$loop1$funnextPart$classMjpegReader));
            f2123State$Int$arg0$callsubstring$$$this$calltrim$$$this$calllowercase$valname$body$loop1$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-EQEQ$cond$if-1$body$loop$fun-readLine$class-MjpegReader", offset = 4042)
    /* JADX INFO: renamed from: Int$arg-1$call-EQEQ$cond$if-1$body$loop$fun-readLine$class-MjpegReader, reason: not valid java name */
    public final int m7062Int$arg1$callEQEQ$cond$if1$body$loop$funreadLine$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2092Int$arg1$callEQEQ$cond$if1$body$loop$funreadLine$classMjpegReader;
        }
        State<Integer> stateLiveLiteral = f2124State$Int$arg1$callEQEQ$cond$if1$body$loop$funreadLine$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-EQEQ$cond$if-1$body$loop$fun-readLine$class-MjpegReader", Integer.valueOf(f2092Int$arg1$callEQEQ$cond$if1$body$loop$funreadLine$classMjpegReader));
            f2124State$Int$arg1$callEQEQ$cond$if1$body$loop$funreadLine$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-greater$cond$if$body$loop-1$fun-nextPart$class-MjpegReader", offset = 1615)
    /* JADX INFO: renamed from: Int$arg-1$call-greater$cond$if$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final int m7063Int$arg1$callgreater$cond$if$body$loop1$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2093Int$arg1$callgreater$cond$if$body$loop1$funnextPart$classMjpegReader;
        }
        State<Integer> stateLiveLiteral = f2125State$Int$arg1$callgreater$cond$if$body$loop1$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-greater$cond$if$body$loop-1$fun-nextPart$class-MjpegReader", Integer.valueOf(f2093Int$arg1$callgreater$cond$if$body$loop1$funnextPart$classMjpegReader));
            f2125State$Int$arg1$callgreater$cond$if$body$loop1$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-less$cond$if$body$loop$fun-readLine$class-MjpegReader", offset = 3897)
    /* JADX INFO: renamed from: Int$arg-1$call-less$cond$if$body$loop$fun-readLine$class-MjpegReader, reason: not valid java name */
    public final int m7064Int$arg1$callless$cond$if$body$loop$funreadLine$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2094Int$arg1$callless$cond$if$body$loop$funreadLine$classMjpegReader;
        }
        State<Integer> stateLiveLiteral = f2126State$Int$arg1$callless$cond$if$body$loop$funreadLine$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-less$cond$if$body$loop$fun-readLine$class-MjpegReader", Integer.valueOf(f2094Int$arg1$callless$cond$if$body$loop$funreadLine$classMjpegReader));
            f2126State$Int$arg1$callless$cond$if$body$loop$funreadLine$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-less$cond$if$body$loop-2$fun-nextPart$class-MjpegReader", offset = 2507)
    /* JADX INFO: renamed from: Int$arg-1$call-less$cond$if$body$loop-2$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final int m7065Int$arg1$callless$cond$if$body$loop2$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2095Int$arg1$callless$cond$if$body$loop2$funnextPart$classMjpegReader;
        }
        State<Integer> stateLiveLiteral = f2127State$Int$arg1$callless$cond$if$body$loop2$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-less$cond$if$body$loop-2$fun-nextPart$class-MjpegReader", Integer.valueOf(f2095Int$arg1$callless$cond$if$body$loop2$funnextPart$classMjpegReader));
            f2127State$Int$arg1$callless$cond$if$body$loop2$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-less$cond$if-2$body$loop-1$fun-nextPart$class-MjpegReader", offset = 1766)
    /* JADX INFO: renamed from: Int$arg-1$call-less$cond$if-2$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final int m7066Int$arg1$callless$cond$if2$body$loop1$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2096Int$arg1$callless$cond$if2$body$loop1$funnextPart$classMjpegReader;
        }
        State<Integer> stateLiveLiteral = f2128State$Int$arg1$callless$cond$if2$body$loop1$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-less$cond$if-2$body$loop-1$fun-nextPart$class-MjpegReader", Integer.valueOf(f2096Int$arg1$callless$cond$if2$body$loop1$funnextPart$classMjpegReader));
            f2128State$Int$arg1$callless$cond$if2$body$loop1$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-MjpegReader", offset = -1)
    /* JADX INFO: renamed from: Int$class-MjpegReader, reason: not valid java name */
    public final int m7067Int$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2097Int$classMjpegReader;
        }
        State<Integer> stateLiveLiteral = f2129State$Int$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-MjpegReader", Integer.valueOf(f2097Int$classMjpegReader));
            f2129State$Int$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$val-emptyLines$fun-nextPart$class-MjpegReader", offset = 1146)
    /* JADX INFO: renamed from: Int$val-emptyLines$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final int m7068Int$valemptyLines$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2098Int$valemptyLines$funnextPart$classMjpegReader;
        }
        State<Integer> stateLiveLiteral = f2130State$Int$valemptyLines$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$val-emptyLines$fun-nextPart$class-MjpegReader", Integer.valueOf(f2098Int$valemptyLines$funnextPart$classMjpegReader));
            f2130State$Int$valemptyLines$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$val-headerBytes$fun-nextPart$class-MjpegReader", offset = 1443)
    /* JADX INFO: renamed from: Int$val-headerBytes$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final int m7069Int$valheaderBytes$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2099Int$valheaderBytes$funnextPart$classMjpegReader;
        }
        State<Integer> stateLiveLiteral = f2131State$Int$valheaderBytes$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$val-headerBytes$fun-nextPart$class-MjpegReader", Integer.valueOf(f2099Int$valheaderBytes$funnextPart$classMjpegReader));
            f2131State$Int$valheaderBytes$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$val-offset$fun-nextPart$class-MjpegReader", offset = 2380)
    /* JADX INFO: renamed from: Int$val-offset$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final int m7070Int$valoffset$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2100Int$valoffset$funnextPart$classMjpegReader;
        }
        State<Integer> stateLiveLiteral = f2132State$Int$valoffset$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$val-offset$fun-nextPart$class-MjpegReader", Integer.valueOf(f2100Int$valoffset$funnextPart$classMjpegReader));
            f2132State$Int$valoffset$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-times$$this$call-plus$fun-timestamp$class-MjpegReader", offset = 3672)
    /* JADX INFO: renamed from: Long$arg-0$call-times$$this$call-plus$fun-timestamp$class-MjpegReader, reason: not valid java name */
    public final long m7071Long$arg0$calltimes$$this$callplus$funtimestamp$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2101Long$arg0$calltimes$$this$callplus$funtimestamp$classMjpegReader;
        }
        State<Long> stateLiveLiteral = f2133State$Long$arg0$calltimes$$this$callplus$funtimestamp$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-times$$this$call-plus$fun-timestamp$class-MjpegReader", Long.valueOf(f2101Long$arg0$calltimes$$this$callplus$funtimestamp$classMjpegReader));
            f2133State$Long$arg0$calltimes$$this$callplus$funtimestamp$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-1$call-greater$cond$if-2$fun-timestamp$class-MjpegReader", offset = 3586)
    /* JADX INFO: renamed from: Long$arg-1$call-greater$cond$if-2$fun-timestamp$class-MjpegReader, reason: not valid java name */
    public final long m7072Long$arg1$callgreater$cond$if2$funtimestamp$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2102Long$arg1$callgreater$cond$if2$funtimestamp$classMjpegReader;
        }
        State<Long> stateLiveLiteral = f2134State$Long$arg1$callgreater$cond$if2$funtimestamp$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-1$call-greater$cond$if-2$fun-timestamp$class-MjpegReader", Long.valueOf(f2102Long$arg1$callgreater$cond$if2$funtimestamp$classMjpegReader));
            f2134State$Long$arg1$callgreater$cond$if2$funtimestamp$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-1$call-lessOrEqual$fun-$anonymous$$arg-0$call-takeIf$else$when$val-tmp1_elvis_lhs$fun-sequence$class-MjpegReader", offset = 3139)
    /* JADX INFO: renamed from: Long$arg-1$call-lessOrEqual$fun-$anonymous$$arg-0$call-takeIf$else$when$val-tmp1_elvis_lhs$fun-sequence$class-MjpegReader, reason: not valid java name */
    public final long m7073Long$arg1$calllessOrEqual$fun$anonymous$$arg0$calltakeIf$else$when$valtmp1_elvis_lhs$funsequence$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2103Long$arg1$calllessOrEqual$fun$anonymous$$arg0$calltakeIf$else$when$valtmp1_elvis_lhs$funsequence$classMjpegReader;
        }
        State<Long> stateLiveLiteral = f2135State$Long$arg1$calllessOrEqual$fun$anonymous$$arg0$calltakeIf$else$when$valtmp1_elvis_lhs$funsequence$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-1$call-lessOrEqual$fun-$anonymous$$arg-0$call-takeIf$else$when$val-tmp1_elvis_lhs$fun-sequence$class-MjpegReader", Long.valueOf(f2103Long$arg1$calllessOrEqual$fun$anonymous$$arg0$calltakeIf$else$when$valtmp1_elvis_lhs$funsequence$classMjpegReader));
            f2135State$Long$arg1$calllessOrEqual$fun$anonymous$$arg0$calltakeIf$else$when$valtmp1_elvis_lhs$funsequence$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "String$0$str$set-delimiter$class-MjpegReader", offset = 969)
    /* JADX INFO: renamed from: String$0$str$set-delimiter$class-MjpegReader, reason: not valid java name */
    public final String m7074String$0$str$setdelimiter$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2169String$0$str$setdelimiter$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2136State$String$0$str$setdelimiter$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$set-delimiter$class-MjpegReader", f2169String$0$str$setdelimiter$classMjpegReader);
            f2136State$String$0$str$setdelimiter$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$1$str$arg-1$call-EQEQ$cond$if$fun-nextPart$class-MjpegReader", offset = 1272)
    /* JADX INFO: renamed from: String$1$str$arg-1$call-EQEQ$cond$if$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final String m7075String$1$str$arg1$callEQEQ$cond$if$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2170String$1$str$arg1$callEQEQ$cond$if$funnextPart$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2137State$String$1$str$arg1$callEQEQ$cond$if$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$1$str$arg-1$call-EQEQ$cond$if$fun-nextPart$class-MjpegReader", f2170String$1$str$arg1$callEQEQ$cond$if$funnextPart$classMjpegReader);
            f2137State$String$1$str$arg1$callEQEQ$cond$if$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$arg-0$call-matches$$this$call-not$cond$if-1$fun-sequence$class-MjpegReader", offset = 3027)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-0$call-matches$$this$call-not$cond$if-1$fun-sequence$class-MjpegReader, reason: not valid java name */
    public final String m7076String$arg0$call$init$$arg0$callmatches$$this$callnot$cond$if1$funsequence$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2171String$arg0$call$init$$arg0$callmatches$$this$callnot$cond$if1$funsequence$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2138State$String$arg0$call$init$$arg0$callmatches$$this$callnot$cond$if1$funsequence$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$arg-0$call-matches$$this$call-not$cond$if-1$fun-sequence$class-MjpegReader", f2171String$arg0$call$init$$arg0$callmatches$$this$callnot$cond$if1$funsequence$classMjpegReader);
            f2138State$String$arg0$call$init$$arg0$callmatches$$this$callnot$cond$if1$funsequence$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$arg-0$call-matches$$this$call-not$cond$if-1$fun-timestamp$class-MjpegReader", offset = 3432)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-0$call-matches$$this$call-not$cond$if-1$fun-timestamp$class-MjpegReader, reason: not valid java name */
    public final String m7077String$arg0$call$init$$arg0$callmatches$$this$callnot$cond$if1$funtimestamp$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2172String$arg0$call$init$$arg0$callmatches$$this$callnot$cond$if1$funtimestamp$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2139State$String$arg0$call$init$$arg0$callmatches$$this$callnot$cond$if1$funtimestamp$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$arg-0$call-matches$$this$call-not$cond$if-1$fun-timestamp$class-MjpegReader", f2172String$arg0$call$init$$arg0$callmatches$$this$callnot$cond$if1$funtimestamp$classMjpegReader);
            f2139State$String$arg0$call$init$$arg0$callmatches$$this$callnot$cond$if1$funtimestamp$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$branch$if$body$loop$fun-readLine$class-MjpegReader", offset = 3986)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if$body$loop$fun-readLine$class-MjpegReader, reason: not valid java name */
    public final String m7078String$arg0$call$init$$branch$if$body$loop$funreadLine$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2173String$arg0$call$init$$branch$if$body$loop$funreadLine$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2140State$String$arg0$call$init$$branch$if$body$loop$funreadLine$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$branch$if$body$loop$fun-readLine$class-MjpegReader", f2173String$arg0$call$init$$branch$if$body$loop$funreadLine$classMjpegReader);
            f2140State$String$arg0$call$init$$branch$if$body$loop$funreadLine$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$branch$if$body$loop-1$fun-nextPart$class-MjpegReader", offset = 1642)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final String m7079String$arg0$call$init$$branch$if$body$loop1$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2174String$arg0$call$init$$branch$if$body$loop1$funnextPart$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2141State$String$arg0$call$init$$branch$if$body$loop1$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$branch$if$body$loop-1$fun-nextPart$class-MjpegReader", f2174String$arg0$call$init$$branch$if$body$loop1$funnextPart$classMjpegReader);
            f2141State$String$arg0$call$init$$branch$if$body$loop1$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$branch$if$body$loop-2$fun-nextPart$class-MjpegReader", offset = 2530)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if$body$loop-2$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final String m7080String$arg0$call$init$$branch$if$body$loop2$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2175String$arg0$call$init$$branch$if$body$loop2$funnextPart$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2142State$String$arg0$call$init$$branch$if$body$loop2$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$branch$if$body$loop-2$fun-nextPart$class-MjpegReader", f2175String$arg0$call$init$$branch$if$body$loop2$funnextPart$classMjpegReader);
            f2142State$String$arg0$call$init$$branch$if$body$loop2$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$branch$if$class-MjpegReader", offset = 501)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if$class-MjpegReader, reason: not valid java name */
    public final String m7081String$arg0$call$init$$branch$if$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2176String$arg0$call$init$$branch$if$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2143State$String$arg0$call$init$$branch$if$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$branch$if$class-MjpegReader", f2176String$arg0$call$init$$branch$if$classMjpegReader);
            f2143State$String$arg0$call$init$$branch$if$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$branch$if-1$class-MjpegReader", offset = 929)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if-1$class-MjpegReader, reason: not valid java name */
    public final String m7082String$arg0$call$init$$branch$if1$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2177String$arg0$call$init$$branch$if1$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2144State$String$arg0$call$init$$branch$if1$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$branch$if-1$class-MjpegReader", f2177String$arg0$call$init$$branch$if1$classMjpegReader);
            f2144State$String$arg0$call$init$$branch$if1$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$branch$if-1$fun-nextPart$class-MjpegReader", offset = 1339)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final String m7083String$arg0$call$init$$branch$if1$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2178String$arg0$call$init$$branch$if1$funnextPart$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2145State$String$arg0$call$init$$branch$if1$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$branch$if-1$fun-nextPart$class-MjpegReader", f2178String$arg0$call$init$$branch$if1$funnextPart$classMjpegReader);
            f2145State$String$arg0$call$init$$branch$if1$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$branch$if-1$fun-sequence$class-MjpegReader", offset = 3062)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if-1$fun-sequence$class-MjpegReader, reason: not valid java name */
    public final String m7084String$arg0$call$init$$branch$if1$funsequence$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2179String$arg0$call$init$$branch$if1$funsequence$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2146State$String$arg0$call$init$$branch$if1$funsequence$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$branch$if-1$fun-sequence$class-MjpegReader", f2179String$arg0$call$init$$branch$if1$funsequence$classMjpegReader);
            f2146State$String$arg0$call$init$$branch$if1$funsequence$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$branch$if-1$fun-timestamp$class-MjpegReader", offset = 3478)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if-1$fun-timestamp$class-MjpegReader, reason: not valid java name */
    public final String m7085String$arg0$call$init$$branch$if1$funtimestamp$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2180String$arg0$call$init$$branch$if1$funtimestamp$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2147State$String$arg0$call$init$$branch$if1$funtimestamp$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$branch$if-1$fun-timestamp$class-MjpegReader", f2180String$arg0$call$init$$branch$if1$funtimestamp$classMjpegReader);
            f2147State$String$arg0$call$init$$branch$if1$funtimestamp$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$branch$if-2$body$loop-1$fun-nextPart$class-MjpegReader", offset = 1788)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if-2$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final String m7086String$arg0$call$init$$branch$if2$body$loop1$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2181String$arg0$call$init$$branch$if2$body$loop1$funnextPart$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2148State$String$arg0$call$init$$branch$if2$body$loop1$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$branch$if-2$body$loop-1$fun-nextPart$class-MjpegReader", f2181String$arg0$call$init$$branch$if2$body$loop1$funnextPart$classMjpegReader);
            f2148State$String$arg0$call$init$$branch$if2$body$loop1$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$branch$if-2$fun-nextPart$class-MjpegReader", offset = 2108)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if-2$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final String m7087String$arg0$call$init$$branch$if2$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2182String$arg0$call$init$$branch$if2$funnextPart$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2149State$String$arg0$call$init$$branch$if2$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$branch$if-2$fun-nextPart$class-MjpegReader", f2182String$arg0$call$init$$branch$if2$funnextPart$classMjpegReader);
            f2149State$String$arg0$call$init$$branch$if2$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$branch$if-2$fun-timestamp$class-MjpegReader", offset = 3619)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if-2$fun-timestamp$class-MjpegReader, reason: not valid java name */
    public final String m7088String$arg0$call$init$$branch$if2$funtimestamp$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2183String$arg0$call$init$$branch$if2$funtimestamp$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2150State$String$arg0$call$init$$branch$if2$funtimestamp$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$branch$if-2$fun-timestamp$class-MjpegReader", f2183String$arg0$call$init$$branch$if2$funtimestamp$classMjpegReader);
            f2150State$String$arg0$call$init$$branch$if2$funtimestamp$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$branch$if-3$body$loop-1$fun-nextPart$class-MjpegReader", offset = 1995)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if-3$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final String m7089String$arg0$call$init$$branch$if3$body$loop1$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2184String$arg0$call$init$$branch$if3$body$loop1$funnextPart$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2151State$String$arg0$call$init$$branch$if3$body$loop1$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$branch$if-3$body$loop-1$fun-nextPart$class-MjpegReader", f2184String$arg0$call$init$$branch$if3$body$loop1$funnextPart$classMjpegReader);
            f2151State$String$arg0$call$init$$branch$if3$body$loop1$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$branch$if-3$fun-nextPart$class-MjpegReader", offset = 2289)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if-3$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final String m7090String$arg0$call$init$$branch$if3$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2185String$arg0$call$init$$branch$if3$funnextPart$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2152State$String$arg0$call$init$$branch$if3$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$branch$if-3$fun-nextPart$class-MjpegReader", f2185String$arg0$call$init$$branch$if3$funnextPart$classMjpegReader);
            f2152State$String$arg0$call$init$$branch$if3$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$branch$if-4$fun-nextPart$class-MjpegReader", offset = 2773)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$if-4$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final String m7091String$arg0$call$init$$branch$if4$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2186String$arg0$call$init$$branch$if4$funnextPart$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2153State$String$arg0$call$init$$branch$if4$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$branch$if-4$fun-nextPart$class-MjpegReader", f2186String$arg0$call$init$$branch$if4$funnextPart$classMjpegReader);
            f2153State$String$arg0$call$init$$branch$if4$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$branch$when$fun-sequence$class-MjpegReader", offset = 3188)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$when$fun-sequence$class-MjpegReader, reason: not valid java name */
    public final String m7092String$arg0$call$init$$branch$when$funsequence$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2187String$arg0$call$init$$branch$when$funsequence$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2154State$String$arg0$call$init$$branch$when$funsequence$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$branch$when$fun-sequence$class-MjpegReader", f2187String$arg0$call$init$$branch$when$funsequence$classMjpegReader);
            f2154State$String$arg0$call$init$$branch$when$funsequence$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$branch$when$set-line$body$loop-1$fun-nextPart$class-MjpegReader", offset = 1521)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$when$set-line$body$loop-1$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final String m7093String$arg0$call$init$$branch$when$setline$body$loop1$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2188String$arg0$call$init$$branch$when$setline$body$loop1$funnextPart$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2155State$String$arg0$call$init$$branch$when$setline$body$loop1$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$branch$when$set-line$body$loop-1$fun-nextPart$class-MjpegReader", f2188String$arg0$call$init$$branch$when$setline$body$loop1$funnextPart$classMjpegReader);
            f2155State$String$arg0$call$init$$branch$when$setline$body$loop1$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$branch$when$val-boundary$class-MjpegReader", offset = 783)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$when$val-boundary$class-MjpegReader, reason: not valid java name */
    public final String m7094String$arg0$call$init$$branch$when$valboundary$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2189String$arg0$call$init$$branch$when$valboundary$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2156State$String$arg0$call$init$$branch$when$valboundary$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$branch$when$val-boundary$class-MjpegReader", f2189String$arg0$call$init$$branch$when$valboundary$classMjpegReader);
            f2156State$String$arg0$call$init$$branch$when$valboundary$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$branch$when$val-length$fun-nextPart$class-MjpegReader", offset = 2213)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$when$val-length$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final String m7095String$arg0$call$init$$branch$when$vallength$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2190String$arg0$call$init$$branch$when$vallength$funnextPart$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2157State$String$arg0$call$init$$branch$when$vallength$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$branch$when$val-length$fun-nextPart$class-MjpegReader", f2190String$arg0$call$init$$branch$when$vallength$funnextPart$classMjpegReader);
            f2157State$String$arg0$call$init$$branch$when$vallength$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$fun-readLine$class-MjpegReader", offset = 4164)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$fun-readLine$class-MjpegReader, reason: not valid java name */
    public final String m7096String$arg0$call$init$$funreadLine$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2191String$arg0$call$init$$funreadLine$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2158State$String$arg0$call$init$$funreadLine$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$fun-readLine$class-MjpegReader", f2191String$arg0$call$init$$funreadLine$classMjpegReader);
            f2158State$String$arg0$call$init$$funreadLine$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-equals$$this$call-not$cond$if$class-MjpegReader", offset = 435)
    /* JADX INFO: renamed from: String$arg-0$call-equals$$this$call-not$cond$if$class-MjpegReader, reason: not valid java name */
    public final String m7097String$arg0$callequals$$this$callnot$cond$if$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2192String$arg0$callequals$$this$callnot$cond$if$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2159State$String$arg0$callequals$$this$callnot$cond$if$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-equals$$this$call-not$cond$if$class-MjpegReader", f2192String$arg0$callequals$$this$callnot$cond$if$classMjpegReader);
            f2159State$String$arg0$callequals$$this$callnot$cond$if$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-equals$$this$call-not$cond$if-2$fun-nextPart$class-MjpegReader", offset = 2069)
    /* JADX INFO: renamed from: String$arg-0$call-equals$$this$call-not$cond$if-2$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final String m7098String$arg0$callequals$$this$callnot$cond$if2$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2193String$arg0$callequals$$this$callnot$cond$if2$funnextPart$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2160State$String$arg0$callequals$$this$callnot$cond$if2$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-equals$$this$call-not$cond$if-2$fun-nextPart$class-MjpegReader", f2193String$arg0$callequals$$this$callnot$cond$if2$funnextPart$classMjpegReader);
            f2160State$String$arg0$callequals$$this$callnot$cond$if2$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-equals$fun-$anonymous$$arg-0$call-firstOrNull$val-tmp0_safe_receiver$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader", offset = 659)
    /* JADX INFO: renamed from: String$arg-0$call-equals$fun-$anonymous$$arg-0$call-firstOrNull$val-tmp0_safe_receiver$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader, reason: not valid java name */
    public final String m7099String$arg0$callequals$fun$anonymous$$arg0$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2194String$arg0$callequals$fun$anonymous$$arg0$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2161State$String$arg0$callequals$fun$anonymous$$arg0$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-equals$fun-$anonymous$$arg-0$call-firstOrNull$val-tmp0_safe_receiver$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader", f2194String$arg0$callequals$fun$anonymous$$arg0$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader);
            f2161State$String$arg0$callequals$fun$anonymous$$arg0$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-get$$$this$call-equals$$this$call-not$cond$if-2$fun-nextPart$class-MjpegReader", offset = 2046)
    /* JADX INFO: renamed from: String$arg-0$call-get$$$this$call-equals$$this$call-not$cond$if-2$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final String m7100String$arg0$callget$$$this$callequals$$this$callnot$cond$if2$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2195String$arg0$callget$$$this$callequals$$this$callnot$cond$if2$funnextPart$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2162State$String$arg0$callget$$$this$callequals$$this$callnot$cond$if2$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-get$$$this$call-equals$$this$call-not$cond$if-2$fun-nextPart$class-MjpegReader", f2195String$arg0$callget$$$this$callequals$$this$callnot$cond$if2$funnextPart$classMjpegReader);
            f2162State$String$arg0$callget$$$this$callequals$$this$callnot$cond$if2$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-get$arg-0$call-sequence$arg-1$call-$init$$fun-nextPart$class-MjpegReader", offset = 2847)
    /* JADX INFO: renamed from: String$arg-0$call-get$arg-0$call-sequence$arg-1$call-$init$$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final String m7101String$arg0$callget$arg0$callsequence$arg1$call$init$$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2196String$arg0$callget$arg0$callsequence$arg1$call$init$$funnextPart$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2163State$String$arg0$callget$arg0$callsequence$arg1$call$init$$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-get$arg-0$call-sequence$arg-1$call-$init$$fun-nextPart$class-MjpegReader", f2196String$arg0$callget$arg0$callsequence$arg1$call$init$$funnextPart$classMjpegReader);
            f2163State$String$arg0$callget$arg0$callsequence$arg1$call$init$$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-get$arg-0$call-timestamp$arg-2$call-$init$$fun-nextPart$class-MjpegReader", offset = 2881)
    /* JADX INFO: renamed from: String$arg-0$call-get$arg-0$call-timestamp$arg-2$call-$init$$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final String m7102String$arg0$callget$arg0$calltimestamp$arg2$call$init$$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2197String$arg0$callget$arg0$calltimestamp$arg2$call$init$$funnextPart$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2164State$String$arg0$callget$arg0$calltimestamp$arg2$call$init$$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-get$arg-0$call-timestamp$arg-2$call-$init$$fun-nextPart$class-MjpegReader", f2197String$arg0$callget$arg0$calltimestamp$arg2$call$init$$funnextPart$classMjpegReader);
            f2164State$String$arg0$callget$arg0$calltimestamp$arg2$call$init$$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-get$val-tmp4_safe_receiver$val-tmp5_elvis_lhs$val-length$fun-nextPart$class-MjpegReader", offset = 2159)
    /* JADX INFO: renamed from: String$arg-0$call-get$val-tmp4_safe_receiver$val-tmp5_elvis_lhs$val-length$fun-nextPart$class-MjpegReader, reason: not valid java name */
    public final String m7103String$arg0$callget$valtmp4_safe_receiver$valtmp5_elvis_lhs$vallength$funnextPart$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2198String$arg0$callget$valtmp4_safe_receiver$valtmp5_elvis_lhs$vallength$funnextPart$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2165State$String$arg0$callget$valtmp4_safe_receiver$valtmp5_elvis_lhs$vallength$funnextPart$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-get$val-tmp4_safe_receiver$val-tmp5_elvis_lhs$val-length$fun-nextPart$class-MjpegReader", f2198String$arg0$callget$valtmp4_safe_receiver$valtmp5_elvis_lhs$vallength$funnextPart$classMjpegReader);
            f2165State$String$arg0$callget$valtmp4_safe_receiver$valtmp5_elvis_lhs$vallength$funnextPart$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-removeSuffix$branch$if-1$body$loop$fun-readLine$class-MjpegReader", offset = 4083)
    /* JADX INFO: renamed from: String$arg-0$call-removeSuffix$branch$if-1$body$loop$fun-readLine$class-MjpegReader, reason: not valid java name */
    public final String m7104String$arg0$callremoveSuffix$branch$if1$body$loop$funreadLine$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2199String$arg0$callremoveSuffix$branch$if1$body$loop$funreadLine$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2166State$String$arg0$callremoveSuffix$branch$if1$body$loop$funreadLine$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-removeSuffix$branch$if-1$body$loop$fun-readLine$class-MjpegReader", f2199String$arg0$callremoveSuffix$branch$if1$body$loop$funreadLine$classMjpegReader);
            f2166State$String$arg0$callremoveSuffix$branch$if1$body$loop$funreadLine$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-removeSurrounding$else$when$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader", offset = 744)
    /* JADX INFO: renamed from: String$arg-0$call-removeSurrounding$else$when$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader, reason: not valid java name */
    public final String m7105String$arg0$callremoveSurrounding$else$when$valtmp3_elvis_lhs$valboundary$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2200String$arg0$callremoveSurrounding$else$when$valtmp3_elvis_lhs$valboundary$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2167State$String$arg0$callremoveSurrounding$else$when$valtmp3_elvis_lhs$valboundary$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-removeSurrounding$else$when$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader", f2200String$arg0$callremoveSurrounding$else$when$valtmp3_elvis_lhs$valboundary$classMjpegReader);
            f2167State$String$arg0$callremoveSurrounding$else$when$valtmp3_elvis_lhs$valboundary$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-1$call-substringAfter$else$when$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader", offset = 712)
    /* JADX INFO: renamed from: String$arg-1$call-substringAfter$else$when$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader, reason: not valid java name */
    public final String m7106String$arg1$callsubstringAfter$else$when$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2201String$arg1$callsubstringAfter$else$when$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader;
        }
        State<String> stateLiveLiteral = f2168State$String$arg1$callsubstringAfter$else$when$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-1$call-substringAfter$else$when$val-tmp1_safe_receiver$val-tmp2_safe_receiver$val-tmp3_elvis_lhs$val-boundary$class-MjpegReader", f2201String$arg1$callsubstringAfter$else$when$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader);
            f2168State$String$arg1$callsubstringAfter$else$when$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
