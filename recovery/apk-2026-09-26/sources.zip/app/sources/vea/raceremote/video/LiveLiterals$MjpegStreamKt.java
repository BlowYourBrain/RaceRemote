package vea.raceremote.video;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: MjpegStream.kt */
/* JADX INFO: loaded from: classes11.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/video/MjpegStream.kt")
public final class LiveLiterals$MjpegStreamKt {

    /* JADX INFO: renamed from: Boolean$arg-0$call-followRedirects$$this$call-followSslRedirects$$this$call-build$val-transport$fun-start$class-MjpegStream, reason: not valid java name */
    private static boolean f2203Boolean$arg0$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream;

    /* JADX INFO: renamed from: Boolean$arg-0$call-followSslRedirects$$this$call-build$val-transport$fun-start$class-MjpegStream, reason: not valid java name */
    private static boolean f2204Boolean$arg0$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream;

    /* JADX INFO: renamed from: Boolean$arg-0$call-retryOnConnectionFailure$$this$call-followRedirects$$this$call-followSslRedirects$$this$call-build$val-transport$fun-start$class-MjpegStream, reason: not valid java name */
    private static boolean f2205Boolean$arg0$callretryOnConnectionFailure$$this$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-$set-closed$$fun-close$class-MjpegStream, reason: not valid java name */
    private static State<Boolean> f2209State$Boolean$arg0$call$setclosed$$funclose$classMjpegStream;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-followRedirects$$this$call-followSslRedirects$$this$call-build$val-transport$fun-start$class-MjpegStream, reason: not valid java name */
    private static State<Boolean> f2210State$Boolean$arg0$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-followSslRedirects$$this$call-build$val-transport$fun-start$class-MjpegStream, reason: not valid java name */
    private static State<Boolean> f2211State$Boolean$arg0$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-retryOnConnectionFailure$$this$call-followRedirects$$this$call-followSslRedirects$$this$call-build$val-transport$fun-start$class-MjpegStream, reason: not valid java name */
    private static State<Boolean> f2212State$Boolean$arg0$callretryOnConnectionFailure$$this$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream;

    /* JADX INFO: renamed from: State$Int$class-MjpegStream, reason: not valid java name */
    private static State<Integer> f2213State$Int$classMjpegStream;

    /* JADX INFO: renamed from: State$Long$arg-0$call-connectTimeout$$this$call-readTimeout$$this$call-retryOnConnectionFailure$$this$call-followRedirects$$this$call-followSslRedirects$$this$call-build$val-transport$fun-start$class-MjpegStream, reason: not valid java name */
    private static State<Long> f2214State$Long$arg0$callconnectTimeout$$this$callreadTimeout$$this$callretryOnConnectionFailure$$this$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream;

    /* JADX INFO: renamed from: State$Long$arg-0$call-readTimeout$$this$call-retryOnConnectionFailure$$this$call-followRedirects$$this$call-followSslRedirects$$this$call-build$val-transport$fun-start$class-MjpegStream, reason: not valid java name */
    private static State<Long> f2215State$Long$arg0$callreadTimeout$$this$callretryOnConnectionFailure$$this$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-$init$$branch$if$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream, reason: not valid java name */
    private static State<String> f2216State$String$0$str$arg0$call$init$$branch$if$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-invoke$branch$if$catch$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream, reason: not valid java name */
    private static State<String> f2217State$String$0$str$arg0$callinvoke$branch$if$catch$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$branch$when$val-body$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream, reason: not valid java name */
    private static State<String> f2218State$String$arg0$call$init$$branch$when$valbody$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream;

    /* JADX INFO: renamed from: State$String$arg-0$call-header$$this$call-build$arg-0$call-newCall$val-request$fun-start$class-MjpegStream, reason: not valid java name */
    private static State<String> f2219State$String$arg0$callheader$$this$callbuild$arg0$callnewCall$valrequest$funstart$classMjpegStream;

    /* JADX INFO: renamed from: State$String$arg-0$call-header$val-tmp1_elvis_lhs$arg-1$call-$init$$val-reader$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream, reason: not valid java name */
    private static State<String> f2220State$String$arg0$callheader$valtmp1_elvis_lhs$arg1$call$init$$valreader$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream;

    /* JADX INFO: renamed from: State$String$arg-0$call-invoke$branch$if$fun-start$class-MjpegStream, reason: not valid java name */
    private static State<String> f2221State$String$arg0$callinvoke$branch$if$funstart$classMjpegStream;

    /* JADX INFO: renamed from: State$String$arg-0$call-invoke$branch$if$try$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream, reason: not valid java name */
    private static State<String> f2222State$String$arg0$callinvoke$branch$if$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream;

    /* JADX INFO: renamed from: State$String$arg-1$call-header$$this$call-build$arg-0$call-newCall$val-request$fun-start$class-MjpegStream, reason: not valid java name */
    private static State<String> f2223State$String$arg1$callheader$$this$callbuild$arg0$callnewCall$valrequest$funstart$classMjpegStream;

    /* JADX INFO: renamed from: State$String$branch$when$arg-1$call-$init$$val-reader$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream, reason: not valid java name */
    private static State<String> f2224State$String$branch$when$arg1$call$init$$valreader$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream;

    /* JADX INFO: renamed from: State$String$fun-$anonymous$$arg-1$call-check$fun-start$class-MjpegStream, reason: not valid java name */
    private static State<String> f2225State$String$fun$anonymous$$arg1$callcheck$funstart$classMjpegStream;
    public static final LiveLiterals$MjpegStreamKt INSTANCE = new LiveLiterals$MjpegStreamKt();

    /* JADX INFO: renamed from: String$fun-$anonymous$$arg-1$call-check$fun-start$class-MjpegStream, reason: not valid java name */
    private static String f2235String$fun$anonymous$$arg1$callcheck$funstart$classMjpegStream = "Use a new stream for each connection";

    /* JADX INFO: renamed from: String$arg-0$call-invoke$branch$if$fun-start$class-MjpegStream, reason: not valid java name */
    private static String f2231String$arg0$callinvoke$branch$if$funstart$classMjpegStream = "Проверь адрес видеопотока";

    /* JADX INFO: renamed from: Long$arg-0$call-connectTimeout$$this$call-readTimeout$$this$call-retryOnConnectionFailure$$this$call-followRedirects$$this$call-followSslRedirects$$this$call-build$val-transport$fun-start$class-MjpegStream, reason: not valid java name */
    private static long f2207Long$arg0$callconnectTimeout$$this$callreadTimeout$$this$callretryOnConnectionFailure$$this$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream = 4;

    /* JADX INFO: renamed from: Long$arg-0$call-readTimeout$$this$call-retryOnConnectionFailure$$this$call-followRedirects$$this$call-followSslRedirects$$this$call-build$val-transport$fun-start$class-MjpegStream, reason: not valid java name */
    private static long f2208Long$arg0$callreadTimeout$$this$callretryOnConnectionFailure$$this$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream = 1500;

    /* JADX INFO: renamed from: String$arg-0$call-header$$this$call-build$arg-0$call-newCall$val-request$fun-start$class-MjpegStream, reason: not valid java name */
    private static String f2229String$arg0$callheader$$this$callbuild$arg0$callnewCall$valrequest$funstart$classMjpegStream = "Accept";

    /* JADX INFO: renamed from: String$arg-1$call-header$$this$call-build$arg-0$call-newCall$val-request$fun-start$class-MjpegStream, reason: not valid java name */
    private static String f2233String$arg1$callheader$$this$callbuild$arg0$callnewCall$valrequest$funstart$classMjpegStream = "multipart/x-mixed-replace";

    /* JADX INFO: renamed from: String$0$str$arg-0$call-$init$$branch$if$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream, reason: not valid java name */
    private static String f2226String$0$str$arg0$call$init$$branch$if$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream = "HTTP ";

    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$when$val-body$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream, reason: not valid java name */
    private static String f2228String$arg0$call$init$$branch$when$valbody$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream = "Empty video response";

    /* JADX INFO: renamed from: String$arg-0$call-header$val-tmp1_elvis_lhs$arg-1$call-$init$$val-reader$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream, reason: not valid java name */
    private static String f2230String$arg0$callheader$valtmp1_elvis_lhs$arg1$call$init$$valreader$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream = "Content-Type";

    /* JADX INFO: renamed from: String$branch$when$arg-1$call-$init$$val-reader$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream, reason: not valid java name */
    private static String f2234String$branch$when$arg1$call$init$$valreader$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream = "";

    /* JADX INFO: renamed from: String$arg-0$call-invoke$branch$if$try$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream, reason: not valid java name */
    private static String f2232String$arg0$callinvoke$branch$if$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream = "Видеопоток завершён";

    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$branch$if$catch$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream, reason: not valid java name */
    private static String f2227String$0$str$arg0$callinvoke$branch$if$catch$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream = "Видео недоступно: ";

    /* JADX INFO: renamed from: Boolean$arg-0$call-$set-closed$$fun-close$class-MjpegStream, reason: not valid java name */
    private static boolean f2202Boolean$arg0$call$setclosed$$funclose$classMjpegStream = true;

    /* JADX INFO: renamed from: Int$class-MjpegStream, reason: not valid java name */
    private static int f2206Int$classMjpegStream = 8;

    @LiveLiteralInfo(key = "Boolean$arg-0$call-$set-closed$$fun-close$class-MjpegStream", offset = 2309)
    /* JADX INFO: renamed from: Boolean$arg-0$call-$set-closed$$fun-close$class-MjpegStream, reason: not valid java name */
    public final boolean m7107Boolean$arg0$call$setclosed$$funclose$classMjpegStream() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2202Boolean$arg0$call$setclosed$$funclose$classMjpegStream;
        }
        State<Boolean> stateLiveLiteral = f2209State$Boolean$arg0$call$setclosed$$funclose$classMjpegStream;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-$set-closed$$fun-close$class-MjpegStream", Boolean.valueOf(f2202Boolean$arg0$call$setclosed$$funclose$classMjpegStream));
            f2209State$Boolean$arg0$call$setclosed$$funclose$classMjpegStream = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-followRedirects$$this$call-followSslRedirects$$this$call-build$val-transport$fun-start$class-MjpegStream", offset = 1160)
    /* JADX INFO: renamed from: Boolean$arg-0$call-followRedirects$$this$call-followSslRedirects$$this$call-build$val-transport$fun-start$class-MjpegStream, reason: not valid java name */
    public final boolean m7108Boolean$arg0$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2203Boolean$arg0$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream;
        }
        State<Boolean> stateLiveLiteral = f2210State$Boolean$arg0$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-followRedirects$$this$call-followSslRedirects$$this$call-build$val-transport$fun-start$class-MjpegStream", Boolean.valueOf(f2203Boolean$arg0$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream));
            f2210State$Boolean$arg0$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-followSslRedirects$$this$call-build$val-transport$fun-start$class-MjpegStream", offset = 1186)
    /* JADX INFO: renamed from: Boolean$arg-0$call-followSslRedirects$$this$call-build$val-transport$fun-start$class-MjpegStream, reason: not valid java name */
    public final boolean m7109Boolean$arg0$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2204Boolean$arg0$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream;
        }
        State<Boolean> stateLiveLiteral = f2211State$Boolean$arg0$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-followSslRedirects$$this$call-build$val-transport$fun-start$class-MjpegStream", Boolean.valueOf(f2204Boolean$arg0$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream));
            f2211State$Boolean$arg0$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-retryOnConnectionFailure$$this$call-followRedirects$$this$call-followSslRedirects$$this$call-build$val-transport$fun-start$class-MjpegStream", offset = 1124)
    /* JADX INFO: renamed from: Boolean$arg-0$call-retryOnConnectionFailure$$this$call-followRedirects$$this$call-followSslRedirects$$this$call-build$val-transport$fun-start$class-MjpegStream, reason: not valid java name */
    public final boolean m7110Boolean$arg0$callretryOnConnectionFailure$$this$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2205Boolean$arg0$callretryOnConnectionFailure$$this$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream;
        }
        State<Boolean> stateLiveLiteral = f2212State$Boolean$arg0$callretryOnConnectionFailure$$this$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-retryOnConnectionFailure$$this$call-followRedirects$$this$call-followSslRedirects$$this$call-build$val-transport$fun-start$class-MjpegStream", Boolean.valueOf(f2205Boolean$arg0$callretryOnConnectionFailure$$this$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream));
            f2212State$Boolean$arg0$callretryOnConnectionFailure$$this$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Int$class-MjpegStream", offset = -1)
    /* JADX INFO: renamed from: Int$class-MjpegStream, reason: not valid java name */
    public final int m7111Int$classMjpegStream() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2206Int$classMjpegStream;
        }
        State<Integer> stateLiveLiteral = f2213State$Int$classMjpegStream;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-MjpegStream", Integer.valueOf(f2206Int$classMjpegStream));
            f2213State$Int$classMjpegStream = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-connectTimeout$$this$call-readTimeout$$this$call-retryOnConnectionFailure$$this$call-followRedirects$$this$call-followSslRedirects$$this$call-build$val-transport$fun-start$class-MjpegStream", offset = 1024)
    /* JADX INFO: renamed from: Long$arg-0$call-connectTimeout$$this$call-readTimeout$$this$call-retryOnConnectionFailure$$this$call-followRedirects$$this$call-followSslRedirects$$this$call-build$val-transport$fun-start$class-MjpegStream, reason: not valid java name */
    public final long m7112Long$arg0$callconnectTimeout$$this$callreadTimeout$$this$callretryOnConnectionFailure$$this$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2207Long$arg0$callconnectTimeout$$this$callreadTimeout$$this$callretryOnConnectionFailure$$this$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream;
        }
        State<Long> stateLiveLiteral = f2214State$Long$arg0$callconnectTimeout$$this$callreadTimeout$$this$callretryOnConnectionFailure$$this$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-connectTimeout$$this$call-readTimeout$$this$call-retryOnConnectionFailure$$this$call-followRedirects$$this$call-followSslRedirects$$this$call-build$val-transport$fun-start$class-MjpegStream", Long.valueOf(f2207Long$arg0$callconnectTimeout$$this$callreadTimeout$$this$callretryOnConnectionFailure$$this$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream));
            f2214State$Long$arg0$callconnectTimeout$$this$callreadTimeout$$this$callretryOnConnectionFailure$$this$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-readTimeout$$this$call-retryOnConnectionFailure$$this$call-followRedirects$$this$call-followSslRedirects$$this$call-build$val-transport$fun-start$class-MjpegStream", offset = 1070)
    /* JADX INFO: renamed from: Long$arg-0$call-readTimeout$$this$call-retryOnConnectionFailure$$this$call-followRedirects$$this$call-followSslRedirects$$this$call-build$val-transport$fun-start$class-MjpegStream, reason: not valid java name */
    public final long m7113Long$arg0$callreadTimeout$$this$callretryOnConnectionFailure$$this$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2208Long$arg0$callreadTimeout$$this$callretryOnConnectionFailure$$this$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream;
        }
        State<Long> stateLiveLiteral = f2215State$Long$arg0$callreadTimeout$$this$callretryOnConnectionFailure$$this$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-readTimeout$$this$call-retryOnConnectionFailure$$this$call-followRedirects$$this$call-followSslRedirects$$this$call-build$val-transport$fun-start$class-MjpegStream", Long.valueOf(f2208Long$arg0$callreadTimeout$$this$callretryOnConnectionFailure$$this$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream));
            f2215State$Long$arg0$callreadTimeout$$this$callretryOnConnectionFailure$$this$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-$init$$branch$if$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream", offset = 1511)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-$init$$branch$if$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream, reason: not valid java name */
    public final String m7114String$0$str$arg0$call$init$$branch$if$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2226String$0$str$arg0$call$init$$branch$if$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream;
        }
        State<String> stateLiveLiteral = f2216State$String$0$str$arg0$call$init$$branch$if$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-$init$$branch$if$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream", f2226String$0$str$arg0$call$init$$branch$if$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream);
            f2216State$String$0$str$arg0$call$init$$branch$if$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-invoke$branch$if$catch$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream", offset = 2146)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-invoke$branch$if$catch$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream, reason: not valid java name */
    public final String m7115String$0$str$arg0$callinvoke$branch$if$catch$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2227String$0$str$arg0$callinvoke$branch$if$catch$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream;
        }
        State<String> stateLiveLiteral = f2217State$String$0$str$arg0$callinvoke$branch$if$catch$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-invoke$branch$if$catch$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream", f2227String$0$str$arg0$callinvoke$branch$if$catch$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream);
            f2217State$String$0$str$arg0$callinvoke$branch$if$catch$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$branch$when$val-body$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream", offset = 1606)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$branch$when$val-body$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream, reason: not valid java name */
    public final String m7116String$arg0$call$init$$branch$when$valbody$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2228String$arg0$call$init$$branch$when$valbody$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream;
        }
        State<String> stateLiveLiteral = f2218State$String$arg0$call$init$$branch$when$valbody$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$branch$when$val-body$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream", f2228String$arg0$call$init$$branch$when$valbody$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream);
            f2218State$String$arg0$call$init$$branch$when$valbody$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-header$$this$call-build$arg-0$call-newCall$val-request$fun-start$class-MjpegStream", offset = 1279)
    /* JADX INFO: renamed from: String$arg-0$call-header$$this$call-build$arg-0$call-newCall$val-request$fun-start$class-MjpegStream, reason: not valid java name */
    public final String m7117String$arg0$callheader$$this$callbuild$arg0$callnewCall$valrequest$funstart$classMjpegStream() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2229String$arg0$callheader$$this$callbuild$arg0$callnewCall$valrequest$funstart$classMjpegStream;
        }
        State<String> stateLiveLiteral = f2219State$String$arg0$callheader$$this$callbuild$arg0$callnewCall$valrequest$funstart$classMjpegStream;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-header$$this$call-build$arg-0$call-newCall$val-request$fun-start$class-MjpegStream", f2229String$arg0$callheader$$this$callbuild$arg0$callnewCall$valrequest$funstart$classMjpegStream);
            f2219State$String$arg0$callheader$$this$callbuild$arg0$callnewCall$valrequest$funstart$classMjpegStream = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-header$val-tmp1_elvis_lhs$arg-1$call-$init$$val-reader$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream", offset = 1710)
    /* JADX INFO: renamed from: String$arg-0$call-header$val-tmp1_elvis_lhs$arg-1$call-$init$$val-reader$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream, reason: not valid java name */
    public final String m7118String$arg0$callheader$valtmp1_elvis_lhs$arg1$call$init$$valreader$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2230String$arg0$callheader$valtmp1_elvis_lhs$arg1$call$init$$valreader$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream;
        }
        State<String> stateLiveLiteral = f2220State$String$arg0$callheader$valtmp1_elvis_lhs$arg1$call$init$$valreader$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-header$val-tmp1_elvis_lhs$arg-1$call-$init$$val-reader$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream", f2230String$arg0$callheader$valtmp1_elvis_lhs$arg1$call$init$$valreader$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream);
            f2220State$String$arg0$callheader$valtmp1_elvis_lhs$arg1$call$init$$valreader$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-invoke$branch$if$fun-start$class-MjpegStream", offset = 912)
    /* JADX INFO: renamed from: String$arg-0$call-invoke$branch$if$fun-start$class-MjpegStream, reason: not valid java name */
    public final String m7119String$arg0$callinvoke$branch$if$funstart$classMjpegStream() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2231String$arg0$callinvoke$branch$if$funstart$classMjpegStream;
        }
        State<String> stateLiveLiteral = f2221State$String$arg0$callinvoke$branch$if$funstart$classMjpegStream;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-invoke$branch$if$fun-start$class-MjpegStream", f2231String$arg0$callinvoke$branch$if$funstart$classMjpegStream);
            f2221State$String$arg0$callinvoke$branch$if$funstart$classMjpegStream = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-invoke$branch$if$try$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream", offset = 2047)
    /* JADX INFO: renamed from: String$arg-0$call-invoke$branch$if$try$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream, reason: not valid java name */
    public final String m7120String$arg0$callinvoke$branch$if$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2232String$arg0$callinvoke$branch$if$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream;
        }
        State<String> stateLiveLiteral = f2222State$String$arg0$callinvoke$branch$if$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-invoke$branch$if$try$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream", f2232String$arg0$callinvoke$branch$if$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream);
            f2222State$String$arg0$callinvoke$branch$if$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-1$call-header$$this$call-build$arg-0$call-newCall$val-request$fun-start$class-MjpegStream", offset = 1289)
    /* JADX INFO: renamed from: String$arg-1$call-header$$this$call-build$arg-0$call-newCall$val-request$fun-start$class-MjpegStream, reason: not valid java name */
    public final String m7121String$arg1$callheader$$this$callbuild$arg0$callnewCall$valrequest$funstart$classMjpegStream() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2233String$arg1$callheader$$this$callbuild$arg0$callnewCall$valrequest$funstart$classMjpegStream;
        }
        State<String> stateLiveLiteral = f2223State$String$arg1$callheader$$this$callbuild$arg0$callnewCall$valrequest$funstart$classMjpegStream;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-1$call-header$$this$call-build$arg-0$call-newCall$val-request$fun-start$class-MjpegStream", f2233String$arg1$callheader$$this$callbuild$arg0$callnewCall$valrequest$funstart$classMjpegStream);
            f2223State$String$arg1$callheader$$this$callbuild$arg0$callnewCall$valrequest$funstart$classMjpegStream = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$branch$when$arg-1$call-$init$$val-reader$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream", offset = 1728)
    /* JADX INFO: renamed from: String$branch$when$arg-1$call-$init$$val-reader$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream, reason: not valid java name */
    public final String m7122String$branch$when$arg1$call$init$$valreader$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2234String$branch$when$arg1$call$init$$valreader$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream;
        }
        State<String> stateLiveLiteral = f2224State$String$branch$when$arg1$call$init$$valreader$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$branch$when$arg-1$call-$init$$val-reader$fun-$anonymous$$arg-0$call-use$try$fun-$anonymous$$arg-0$call-execute$fun-start$class-MjpegStream", f2234String$branch$when$arg1$call$init$$valreader$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream);
            f2224State$String$branch$when$arg1$call$init$$valreader$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$fun-$anonymous$$arg-1$call-check$fun-start$class-MjpegStream", offset = 656)
    /* JADX INFO: renamed from: String$fun-$anonymous$$arg-1$call-check$fun-start$class-MjpegStream, reason: not valid java name */
    public final String m7123String$fun$anonymous$$arg1$callcheck$funstart$classMjpegStream() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2235String$fun$anonymous$$arg1$callcheck$funstart$classMjpegStream;
        }
        State<String> stateLiveLiteral = f2225State$String$fun$anonymous$$arg1$callcheck$funstart$classMjpegStream;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$fun-$anonymous$$arg-1$call-check$fun-start$class-MjpegStream", f2235String$fun$anonymous$$arg1$callcheck$funstart$classMjpegStream);
            f2225State$String$fun$anonymous$$arg1$callcheck$funstart$classMjpegStream = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
