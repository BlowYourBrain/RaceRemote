package vea.raceremote.video;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: MjpegVideoView.kt */
/* JADX INFO: loaded from: classes11.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/video/MjpegVideoView.kt")
public final class LiveLiterals$MjpegVideoViewKt {

    /* JADX INFO: renamed from: Boolean$arg-0$call-$set-decoding$$branch$if$fun-$anonymous$$arg-1$call-synchronized$val-tmp0_elvis_lhs$val-encoded$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    private static boolean f2237Boolean$arg0$call$setdecoding$$branch$if$fun$anonymous$$arg1$callsynchronized$valtmp0_elvis_lhs$valencoded$body$loop$fundecodeLatest$classMjpegVideoView;

    /* JADX INFO: renamed from: Boolean$arg-1$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-stop$class-MjpegVideoView, reason: not valid java name */
    private static boolean f2240Boolean$arg1$callinvoke$fun$anonymous$$arg1$callsynchronized$funstop$classMjpegVideoView;

    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static boolean f2243Boolean$branch$when1$funequals$classDecoded$classMjpegVideoView;

    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static boolean f2244Boolean$branch$when1$funequals$classEncoded$classMjpegVideoView;

    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static boolean f2245Boolean$branch$when2$funequals$classDecoded$classMjpegVideoView;

    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static boolean f2246Boolean$branch$when2$funequals$classEncoded$classMjpegVideoView;

    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static boolean f2247Boolean$branch$when3$funequals$classDecoded$classMjpegVideoView;

    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static boolean f2248Boolean$branch$when3$funequals$classEncoded$classMjpegVideoView;

    /* JADX INFO: renamed from: Boolean$branch$when-4$fun-equals$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static boolean f2249Boolean$branch$when4$funequals$classDecoded$classMjpegVideoView;

    /* JADX INFO: renamed from: Boolean$branch$when-4$fun-equals$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static boolean f2250Boolean$branch$when4$funequals$classEncoded$classMjpegVideoView;

    /* JADX INFO: renamed from: Float$arg-0$call-drawRect$fun-onDraw$class-MjpegVideoView, reason: not valid java name */
    private static float f2254Float$arg0$calldrawRect$funonDraw$classMjpegVideoView;

    /* JADX INFO: renamed from: Float$arg-1$call-drawRect$fun-onDraw$class-MjpegVideoView, reason: not valid java name */
    private static float f2255Float$arg1$calldrawRect$funonDraw$classMjpegVideoView;

    /* JADX INFO: renamed from: Int$arg-0$call-$set-decodedFrames$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    private static int f2260Int$arg0$call$setdecodedFrames$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;

    /* JADX INFO: renamed from: Int$arg-0$call-$set-drawnFrames$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    private static int f2261Int$arg0$call$setdrawnFrames$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;

    /* JADX INFO: renamed from: Int$arg-0$call-$set-receivedFrames$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    private static int f2262Int$arg0$call$setreceivedFrames$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;

    /* JADX INFO: renamed from: Int$arg-1$call-decodeByteArray$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    private static int f2273Int$arg1$calldecodeByteArray$body$loop$fundecodeLatest$classMjpegVideoView;

    /* JADX INFO: renamed from: Int$arg-1$call-decodeByteArray$branch$if$val-bitmap$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    private static int f2274Int$arg1$calldecodeByteArray$branch$if$valbitmap$body$loop$fundecodeLatest$classMjpegVideoView;

    /* JADX INFO: renamed from: Long$arg-0$call-$set-lastReceivedAt$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    private static long f2277Long$arg0$call$setlastReceivedAt$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-$set-decoding$$branch$if$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-$anonymous$$arg-0$call-$init$$arg-0$call-$set-stream$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    private static State<Boolean> f2279State$Boolean$arg0$call$setdecoding$$branch$if$branch$if$fun$anonymous$$arg1$callsynchronized$fun$anonymous$$arg0$call$init$$arg0$call$setstream$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-$set-decoding$$branch$if$fun-$anonymous$$arg-1$call-synchronized$val-tmp0_elvis_lhs$val-encoded$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    private static State<Boolean> f2280State$Boolean$arg0$call$setdecoding$$branch$if$fun$anonymous$$arg1$callsynchronized$valtmp0_elvis_lhs$valencoded$body$loop$fundecodeLatest$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-$set-disposed$$fun-$anonymous$$arg-1$call-synchronized$fun-close$class-MjpegVideoView, reason: not valid java name */
    private static State<Boolean> f2281State$Boolean$arg0$call$setdisposed$$fun$anonymous$$arg1$callsynchronized$funclose$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    private static State<Boolean> f2282State$Boolean$arg1$callinvoke$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-stop$class-MjpegVideoView, reason: not valid java name */
    private static State<Boolean> f2283State$Boolean$arg1$callinvoke$fun$anonymous$$arg1$callsynchronized$funstop$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Boolean$branch$when$fun-equals$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static State<Boolean> f2284State$Boolean$branch$when$funequals$classDecoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Boolean$branch$when$fun-equals$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static State<Boolean> f2285State$Boolean$branch$when$funequals$classEncoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Boolean$branch$when-1$fun-equals$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static State<Boolean> f2286State$Boolean$branch$when1$funequals$classDecoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Boolean$branch$when-1$fun-equals$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static State<Boolean> f2287State$Boolean$branch$when1$funequals$classEncoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Boolean$branch$when-2$fun-equals$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static State<Boolean> f2288State$Boolean$branch$when2$funequals$classDecoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Boolean$branch$when-2$fun-equals$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static State<Boolean> f2289State$Boolean$branch$when2$funequals$classEncoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Boolean$branch$when-3$fun-equals$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static State<Boolean> f2290State$Boolean$branch$when3$funequals$classDecoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Boolean$branch$when-3$fun-equals$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static State<Boolean> f2291State$Boolean$branch$when3$funequals$classEncoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Boolean$branch$when-4$fun-equals$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static State<Boolean> f2292State$Boolean$branch$when4$funequals$classDecoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Boolean$branch$when-4$fun-equals$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static State<Boolean> f2293State$Boolean$branch$when4$funequals$classEncoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Boolean$fun-equals$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static State<Boolean> f2294State$Boolean$funequals$classDecoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Boolean$fun-equals$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static State<Boolean> f2295State$Boolean$funequals$classEncoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Boolean$set-inJustDecodeBounds$fun-$anonymous$$arg-0$call-apply$val-options$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    private static State<Boolean> f2296State$Boolean$setinJustDecodeBounds$fun$anonymous$$arg0$callapply$valoptions$body$loop$fundecodeLatest$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Float$arg-0$call-drawRect$fun-onDraw$class-MjpegVideoView, reason: not valid java name */
    private static State<Float> f2297State$Float$arg0$calldrawRect$funonDraw$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Float$arg-1$call-drawRect$fun-onDraw$class-MjpegVideoView, reason: not valid java name */
    private static State<Float> f2298State$Float$arg1$calldrawRect$funonDraw$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$branch$cond$val-valid$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    private static State<Integer> f2299State$Int$$this$callrangeTo$$this$callcontains$branch$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Int$$this$call-rangeTo$$this$call-contains$cond$cond$val-valid$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    private static State<Integer> f2300State$Int$$this$callrangeTo$$this$callcontains$cond$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onDraw$class-MjpegVideoView, reason: not valid java name */
    private static State<Integer> f2301State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if1$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Int$$this$call-toLong$arg-1$call-lessOrEqual$branch$val-valid$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    private static State<Integer> f2302State$Int$$this$calltoLong$arg1$calllessOrEqual$branch$valvalid$body$loop$fundecodeLatest$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Int$arg-0$call-$set-decodedFrames$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    private static State<Integer> f2303State$Int$arg0$call$setdecodedFrames$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Int$arg-0$call-$set-drawnFrames$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    private static State<Integer> f2304State$Int$arg0$call$setdrawnFrames$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Int$arg-0$call-$set-receivedFrames$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    private static State<Integer> f2305State$Int$arg0$call$setreceivedFrames$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Int$arg-0$call-div$arg-0$call-$init$$arg-2$call-drawBitmap$fun-$anonymous$$arg-1$call-synchronized$fun-onDraw$class-MjpegVideoView, reason: not valid java name */
    private static State<Integer> f2306State$Int$arg0$calldiv$arg0$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Int$arg-0$call-div$arg-1$call-$init$$arg-2$call-drawBitmap$fun-$anonymous$$arg-1$call-synchronized$fun-onDraw$class-MjpegVideoView, reason: not valid java name */
    private static State<Integer> f2307State$Int$arg0$calldiv$arg1$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Int$arg-0$call-div$arg-2$call-$init$$arg-2$call-drawBitmap$fun-$anonymous$$arg-1$call-synchronized$fun-onDraw$class-MjpegVideoView, reason: not valid java name */
    private static State<Integer> f2308State$Int$arg0$calldiv$arg2$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Int$arg-0$call-div$arg-3$call-$init$$arg-2$call-drawBitmap$fun-$anonymous$$arg-1$call-synchronized$fun-onDraw$class-MjpegVideoView, reason: not valid java name */
    private static State<Integer> f2309State$Int$arg0$calldiv$arg3$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rangeTo$$this$call-contains$branch$cond$val-valid$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    private static State<Integer> f2310State$Int$arg0$callrangeTo$$this$callcontains$branch$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Int$arg-0$call-rangeTo$$this$call-contains$cond$cond$val-valid$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    private static State<Integer> f2311State$Int$arg0$callrangeTo$$this$callcontains$cond$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static State<Integer> f2312State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classDecoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static State<Integer> f2313State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classEncoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static State<Integer> f2314State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classDecoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static State<Integer> f2315State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classEncoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Int$arg-1$call-decodeByteArray$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    private static State<Integer> f2316State$Int$arg1$calldecodeByteArray$body$loop$fundecodeLatest$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Int$arg-1$call-decodeByteArray$branch$if$val-bitmap$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    private static State<Integer> f2317State$Int$arg1$calldecodeByteArray$branch$if$valbitmap$body$loop$fundecodeLatest$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Int$class-MjpegVideoView, reason: not valid java name */
    private static State<Integer> f2318State$Int$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Long$arg-0$call-$set-drawnSequence$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    private static State<Long> f2319State$Long$arg0$call$setdrawnSequence$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Long$arg-0$call-$set-lastReceivedAt$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    private static State<Long> f2320State$Long$arg0$call$setlastReceivedAt$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;

    /* JADX INFO: renamed from: State$Long$arg-1$call-postDelayed$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    private static State<Long> f2321State$Long$arg1$callpostDelayed$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;

    /* JADX INFO: renamed from: State$String$0$str$fun-toString$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static State<String> f2322State$String$0$str$funtoString$classDecoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$String$0$str$fun-toString$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static State<String> f2323State$String$0$str$funtoString$classEncoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$String$1$str$fun-toString$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static State<String> f2324State$String$1$str$funtoString$classDecoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$String$1$str$fun-toString$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static State<String> f2325State$String$1$str$funtoString$classEncoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$String$3$str$fun-toString$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static State<String> f2326State$String$3$str$funtoString$classDecoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$String$3$str$fun-toString$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static State<String> f2327State$String$3$str$funtoString$classEncoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$String$4$str$fun-toString$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static State<String> f2328State$String$4$str$funtoString$classDecoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$String$4$str$fun-toString$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static State<String> f2329State$String$4$str$funtoString$classEncoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$String$6$str$fun-toString$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static State<String> f2330State$String$6$str$funtoString$classDecoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$String$6$str$fun-toString$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static State<String> f2331State$String$6$str$funtoString$classEncoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$String$7$str$fun-toString$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static State<String> f2332State$String$7$str$funtoString$classDecoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$String$7$str$fun-toString$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static State<String> f2333State$String$7$str$funtoString$classEncoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$String$9$str$fun-toString$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static State<String> f2334State$String$9$str$funtoString$classDecoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$String$9$str$fun-toString$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static State<String> f2335State$String$9$str$funtoString$classEncoded$classMjpegVideoView;

    /* JADX INFO: renamed from: State$String$arg-0$call-d$fun-$anonymous$$arg-1$call-synchronized$fun-stop$class-MjpegVideoView, reason: not valid java name */
    private static State<String> f2336State$String$arg0$calld$fun$anonymous$$arg1$callsynchronized$funstop$classMjpegVideoView;

    /* JADX INFO: renamed from: State$String$arg-0$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    private static State<String> f2337State$String$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;

    /* JADX INFO: renamed from: State$String$arg-0$call-stop$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-$anonymous$$arg-0$call-post$branch$if$branch$if$fun-$anonymous$$arg-1$call-synchronized$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    private static State<String> f2338State$String$arg0$callstop$branch$if$fun$anonymous$$arg1$callsynchronized$fun$anonymous$$arg0$callpost$branch$if$branch$if$fun$anonymous$$arg1$callsynchronized$body$loop$fundecodeLatest$classMjpegVideoView;

    /* JADX INFO: renamed from: State$String$param-message$fun-stop$class-MjpegVideoView, reason: not valid java name */
    private static State<String> f2339State$String$parammessage$funstop$classMjpegVideoView;
    public static final LiveLiterals$MjpegVideoViewKt INSTANCE = new LiveLiterals$MjpegVideoViewKt();

    /* JADX INFO: renamed from: String$0$str$fun-toString$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static String f2341String$0$str$funtoString$classEncoded$classMjpegVideoView = "Encoded(";

    /* JADX INFO: renamed from: String$1$str$fun-toString$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static String f2343String$1$str$funtoString$classEncoded$classMjpegVideoView = "bytes=";

    /* JADX INFO: renamed from: String$3$str$fun-toString$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static String f2345String$3$str$funtoString$classEncoded$classMjpegVideoView = ", ";

    /* JADX INFO: renamed from: String$4$str$fun-toString$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static String f2347String$4$str$funtoString$classEncoded$classMjpegVideoView = "generation=";

    /* JADX INFO: renamed from: String$6$str$fun-toString$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static String f2349String$6$str$funtoString$classEncoded$classMjpegVideoView = ", ";

    /* JADX INFO: renamed from: String$7$str$fun-toString$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static String f2351String$7$str$funtoString$classEncoded$classMjpegVideoView = "receivedMs=";

    /* JADX INFO: renamed from: String$9$str$fun-toString$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static String f2353String$9$str$funtoString$classEncoded$classMjpegVideoView = ")";

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static int f2270Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classEncoded$classMjpegVideoView = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static int f2272Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classEncoded$classMjpegVideoView = 31;

    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static boolean f2242Boolean$branch$when$funequals$classEncoded$classMjpegVideoView = true;

    /* JADX INFO: renamed from: Boolean$fun-equals$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    private static boolean f2252Boolean$funequals$classEncoded$classMjpegVideoView = true;

    /* JADX INFO: renamed from: String$0$str$fun-toString$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static String f2340String$0$str$funtoString$classDecoded$classMjpegVideoView = "Decoded(";

    /* JADX INFO: renamed from: String$1$str$fun-toString$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static String f2342String$1$str$funtoString$classDecoded$classMjpegVideoView = "bitmap=";

    /* JADX INFO: renamed from: String$3$str$fun-toString$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static String f2344String$3$str$funtoString$classDecoded$classMjpegVideoView = ", ";

    /* JADX INFO: renamed from: String$4$str$fun-toString$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static String f2346String$4$str$funtoString$classDecoded$classMjpegVideoView = "sequence=";

    /* JADX INFO: renamed from: String$6$str$fun-toString$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static String f2348String$6$str$funtoString$classDecoded$classMjpegVideoView = ", ";

    /* JADX INFO: renamed from: String$7$str$fun-toString$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static String f2350String$7$str$funtoString$classDecoded$classMjpegVideoView = "receivedMs=";

    /* JADX INFO: renamed from: String$9$str$fun-toString$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static String f2352String$9$str$funtoString$classDecoded$classMjpegVideoView = ")";

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static int f2269Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classDecoded$classMjpegVideoView = 31;

    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static int f2271Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classDecoded$classMjpegVideoView = 31;

    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static boolean f2241Boolean$branch$when$funequals$classDecoded$classMjpegVideoView = true;

    /* JADX INFO: renamed from: Boolean$fun-equals$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    private static boolean f2251Boolean$funequals$classDecoded$classMjpegVideoView = true;

    /* JADX INFO: renamed from: Long$arg-0$call-$set-drawnSequence$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    private static long f2276Long$arg0$call$setdrawnSequence$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView = -1;

    /* JADX INFO: renamed from: Boolean$arg-0$call-$set-decoding$$branch$if$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-$anonymous$$arg-0$call-$init$$arg-0$call-$set-stream$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    private static boolean f2236Boolean$arg0$call$setdecoding$$branch$if$branch$if$fun$anonymous$$arg1$callsynchronized$fun$anonymous$$arg0$call$init$$arg0$call$setstream$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView = true;

    /* JADX INFO: renamed from: String$arg-0$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    private static String f2355String$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView = "Подключение видео…";

    /* JADX INFO: renamed from: Boolean$arg-1$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    private static boolean f2239Boolean$arg1$callinvoke$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView = true;

    /* JADX INFO: renamed from: Long$arg-1$call-postDelayed$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    private static long f2278Long$arg1$callpostDelayed$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView = 250;

    /* JADX INFO: renamed from: Boolean$set-inJustDecodeBounds$fun-$anonymous$$arg-0$call-apply$val-options$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    private static boolean f2253Boolean$setinJustDecodeBounds$fun$anonymous$$arg0$callapply$valoptions$body$loop$fundecodeLatest$classMjpegVideoView = true;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$cond$cond$val-valid$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    private static int f2257Int$$this$callrangeTo$$this$callcontains$cond$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView = 1;

    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$cond$cond$val-valid$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    private static int f2268Int$arg0$callrangeTo$$this$callcontains$cond$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView = 1920;

    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$cond$val-valid$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    private static int f2256Int$$this$callrangeTo$$this$callcontains$branch$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView = 1;

    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$cond$val-valid$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    private static int f2267Int$arg0$callrangeTo$$this$callcontains$branch$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView = 1080;

    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-lessOrEqual$branch$val-valid$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    private static int f2259Int$$this$calltoLong$arg1$calllessOrEqual$branch$valvalid$body$loop$fundecodeLatest$classMjpegVideoView = 2073600;

    /* JADX INFO: renamed from: String$arg-0$call-stop$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-$anonymous$$arg-0$call-post$branch$if$branch$if$fun-$anonymous$$arg-1$call-synchronized$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    private static String f2356String$arg0$callstop$branch$if$fun$anonymous$$arg1$callsynchronized$fun$anonymous$$arg0$callpost$branch$if$branch$if$fun$anonymous$$arg1$callsynchronized$body$loop$fundecodeLatest$classMjpegVideoView = "Не удалось декодировать кадр";

    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onDraw$class-MjpegVideoView, reason: not valid java name */
    private static int f2258Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if1$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView = 1500;

    /* JADX INFO: renamed from: Int$arg-0$call-div$arg-0$call-$init$$arg-2$call-drawBitmap$fun-$anonymous$$arg-1$call-synchronized$fun-onDraw$class-MjpegVideoView, reason: not valid java name */
    private static int f2263Int$arg0$calldiv$arg0$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView = 2;

    /* JADX INFO: renamed from: Int$arg-0$call-div$arg-1$call-$init$$arg-2$call-drawBitmap$fun-$anonymous$$arg-1$call-synchronized$fun-onDraw$class-MjpegVideoView, reason: not valid java name */
    private static int f2264Int$arg0$calldiv$arg1$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView = 2;

    /* JADX INFO: renamed from: Int$arg-0$call-div$arg-2$call-$init$$arg-2$call-drawBitmap$fun-$anonymous$$arg-1$call-synchronized$fun-onDraw$class-MjpegVideoView, reason: not valid java name */
    private static int f2265Int$arg0$calldiv$arg2$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView = 2;

    /* JADX INFO: renamed from: Int$arg-0$call-div$arg-3$call-$init$$arg-2$call-drawBitmap$fun-$anonymous$$arg-1$call-synchronized$fun-onDraw$class-MjpegVideoView, reason: not valid java name */
    private static int f2266Int$arg0$calldiv$arg3$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView = 2;

    /* JADX INFO: renamed from: String$param-message$fun-stop$class-MjpegVideoView, reason: not valid java name */
    private static String f2357String$parammessage$funstop$classMjpegVideoView = "Видео выключено";

    /* JADX INFO: renamed from: String$arg-0$call-d$fun-$anonymous$$arg-1$call-synchronized$fun-stop$class-MjpegVideoView, reason: not valid java name */
    private static String f2354String$arg0$calld$fun$anonymous$$arg1$callsynchronized$funstop$classMjpegVideoView = "RaceRemoteVideo";

    /* JADX INFO: renamed from: Boolean$arg-0$call-$set-disposed$$fun-$anonymous$$arg-1$call-synchronized$fun-close$class-MjpegVideoView, reason: not valid java name */
    private static boolean f2238Boolean$arg0$call$setdisposed$$fun$anonymous$$arg1$callsynchronized$funclose$classMjpegVideoView = true;

    /* JADX INFO: renamed from: Int$class-MjpegVideoView, reason: not valid java name */
    private static int f2275Int$classMjpegVideoView = 8;

    @LiveLiteralInfo(key = "Boolean$arg-0$call-$set-decoding$$branch$if$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-$anonymous$$arg-0$call-$init$$arg-0$call-$set-stream$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView", offset = 3217)
    /* JADX INFO: renamed from: Boolean$arg-0$call-$set-decoding$$branch$if$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-$anonymous$$arg-0$call-$init$$arg-0$call-$set-stream$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    public final boolean m7124Boolean$arg0$call$setdecoding$$branch$if$branch$if$fun$anonymous$$arg1$callsynchronized$fun$anonymous$$arg0$call$init$$arg0$call$setstream$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2236Boolean$arg0$call$setdecoding$$branch$if$branch$if$fun$anonymous$$arg1$callsynchronized$fun$anonymous$$arg0$call$init$$arg0$call$setstream$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;
        }
        State<Boolean> stateLiveLiteral = f2279State$Boolean$arg0$call$setdecoding$$branch$if$branch$if$fun$anonymous$$arg1$callsynchronized$fun$anonymous$$arg0$call$init$$arg0$call$setstream$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-$set-decoding$$branch$if$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-$anonymous$$arg-0$call-$init$$arg-0$call-$set-stream$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView", Boolean.valueOf(f2236Boolean$arg0$call$setdecoding$$branch$if$branch$if$fun$anonymous$$arg1$callsynchronized$fun$anonymous$$arg0$call$init$$arg0$call$setstream$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView));
            f2279State$Boolean$arg0$call$setdecoding$$branch$if$branch$if$fun$anonymous$$arg1$callsynchronized$fun$anonymous$$arg0$call$init$$arg0$call$setstream$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-$set-decoding$$branch$if$fun-$anonymous$$arg-1$call-synchronized$val-tmp0_elvis_lhs$val-encoded$body$loop$fun-decodeLatest$class-MjpegVideoView", offset = 3837)
    /* JADX INFO: renamed from: Boolean$arg-0$call-$set-decoding$$branch$if$fun-$anonymous$$arg-1$call-synchronized$val-tmp0_elvis_lhs$val-encoded$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    public final boolean m7125Boolean$arg0$call$setdecoding$$branch$if$fun$anonymous$$arg1$callsynchronized$valtmp0_elvis_lhs$valencoded$body$loop$fundecodeLatest$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2237Boolean$arg0$call$setdecoding$$branch$if$fun$anonymous$$arg1$callsynchronized$valtmp0_elvis_lhs$valencoded$body$loop$fundecodeLatest$classMjpegVideoView;
        }
        State<Boolean> stateLiveLiteral = f2280State$Boolean$arg0$call$setdecoding$$branch$if$fun$anonymous$$arg1$callsynchronized$valtmp0_elvis_lhs$valencoded$body$loop$fundecodeLatest$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-$set-decoding$$branch$if$fun-$anonymous$$arg-1$call-synchronized$val-tmp0_elvis_lhs$val-encoded$body$loop$fun-decodeLatest$class-MjpegVideoView", Boolean.valueOf(f2237Boolean$arg0$call$setdecoding$$branch$if$fun$anonymous$$arg1$callsynchronized$valtmp0_elvis_lhs$valencoded$body$loop$fundecodeLatest$classMjpegVideoView));
            f2280State$Boolean$arg0$call$setdecoding$$branch$if$fun$anonymous$$arg1$callsynchronized$valtmp0_elvis_lhs$valencoded$body$loop$fundecodeLatest$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-$set-disposed$$fun-$anonymous$$arg-1$call-synchronized$fun-close$class-MjpegVideoView", offset = 6220)
    /* JADX INFO: renamed from: Boolean$arg-0$call-$set-disposed$$fun-$anonymous$$arg-1$call-synchronized$fun-close$class-MjpegVideoView, reason: not valid java name */
    public final boolean m7126Boolean$arg0$call$setdisposed$$fun$anonymous$$arg1$callsynchronized$funclose$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2238Boolean$arg0$call$setdisposed$$fun$anonymous$$arg1$callsynchronized$funclose$classMjpegVideoView;
        }
        State<Boolean> stateLiveLiteral = f2281State$Boolean$arg0$call$setdisposed$$fun$anonymous$$arg1$callsynchronized$funclose$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-$set-disposed$$fun-$anonymous$$arg-1$call-synchronized$fun-close$class-MjpegVideoView", Boolean.valueOf(f2238Boolean$arg0$call$setdisposed$$fun$anonymous$$arg1$callsynchronized$funclose$classMjpegVideoView));
            f2281State$Boolean$arg0$call$setdisposed$$fun$anonymous$$arg1$callsynchronized$funclose$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView", offset = 3483)
    /* JADX INFO: renamed from: Boolean$arg-1$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    public final boolean m7127Boolean$arg1$callinvoke$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2239Boolean$arg1$callinvoke$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;
        }
        State<Boolean> stateLiveLiteral = f2282State$Boolean$arg1$callinvoke$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView", Boolean.valueOf(f2239Boolean$arg1$callinvoke$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView));
            f2282State$Boolean$arg1$callinvoke$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-stop$class-MjpegVideoView", offset = 6079)
    /* JADX INFO: renamed from: Boolean$arg-1$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-stop$class-MjpegVideoView, reason: not valid java name */
    public final boolean m7128Boolean$arg1$callinvoke$fun$anonymous$$arg1$callsynchronized$funstop$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2240Boolean$arg1$callinvoke$fun$anonymous$$arg1$callsynchronized$funstop$classMjpegVideoView;
        }
        State<Boolean> stateLiveLiteral = f2283State$Boolean$arg1$callinvoke$fun$anonymous$$arg1$callsynchronized$funstop$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-stop$class-MjpegVideoView", Boolean.valueOf(f2240Boolean$arg1$callinvoke$fun$anonymous$$arg1$callsynchronized$funstop$classMjpegVideoView));
            f2283State$Boolean$arg1$callinvoke$fun$anonymous$$arg1$callsynchronized$funstop$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when$fun-equals$class-Decoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    public final boolean m7129Boolean$branch$when$funequals$classDecoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2241Boolean$branch$when$funequals$classDecoded$classMjpegVideoView;
        }
        State<Boolean> stateLiveLiteral = f2284State$Boolean$branch$when$funequals$classDecoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when$fun-equals$class-Decoded$class-MjpegVideoView", Boolean.valueOf(f2241Boolean$branch$when$funequals$classDecoded$classMjpegVideoView));
            f2284State$Boolean$branch$when$funequals$classDecoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when$fun-equals$class-Encoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when$fun-equals$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    public final boolean m7130Boolean$branch$when$funequals$classEncoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2242Boolean$branch$when$funequals$classEncoded$classMjpegVideoView;
        }
        State<Boolean> stateLiveLiteral = f2285State$Boolean$branch$when$funequals$classEncoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when$fun-equals$class-Encoded$class-MjpegVideoView", Boolean.valueOf(f2242Boolean$branch$when$funequals$classEncoded$classMjpegVideoView));
            f2285State$Boolean$branch$when$funequals$classEncoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-1$fun-equals$class-Decoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    public final boolean m7131Boolean$branch$when1$funequals$classDecoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2243Boolean$branch$when1$funequals$classDecoded$classMjpegVideoView;
        }
        State<Boolean> stateLiveLiteral = f2286State$Boolean$branch$when1$funequals$classDecoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-1$fun-equals$class-Decoded$class-MjpegVideoView", Boolean.valueOf(f2243Boolean$branch$when1$funequals$classDecoded$classMjpegVideoView));
            f2286State$Boolean$branch$when1$funequals$classDecoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-1$fun-equals$class-Encoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-1$fun-equals$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    public final boolean m7132Boolean$branch$when1$funequals$classEncoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2244Boolean$branch$when1$funequals$classEncoded$classMjpegVideoView;
        }
        State<Boolean> stateLiveLiteral = f2287State$Boolean$branch$when1$funequals$classEncoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-1$fun-equals$class-Encoded$class-MjpegVideoView", Boolean.valueOf(f2244Boolean$branch$when1$funequals$classEncoded$classMjpegVideoView));
            f2287State$Boolean$branch$when1$funequals$classEncoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-2$fun-equals$class-Decoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    public final boolean m7133Boolean$branch$when2$funequals$classDecoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2245Boolean$branch$when2$funequals$classDecoded$classMjpegVideoView;
        }
        State<Boolean> stateLiveLiteral = f2288State$Boolean$branch$when2$funequals$classDecoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-2$fun-equals$class-Decoded$class-MjpegVideoView", Boolean.valueOf(f2245Boolean$branch$when2$funequals$classDecoded$classMjpegVideoView));
            f2288State$Boolean$branch$when2$funequals$classDecoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-2$fun-equals$class-Encoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-2$fun-equals$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    public final boolean m7134Boolean$branch$when2$funequals$classEncoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2246Boolean$branch$when2$funequals$classEncoded$classMjpegVideoView;
        }
        State<Boolean> stateLiveLiteral = f2289State$Boolean$branch$when2$funequals$classEncoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-2$fun-equals$class-Encoded$class-MjpegVideoView", Boolean.valueOf(f2246Boolean$branch$when2$funequals$classEncoded$classMjpegVideoView));
            f2289State$Boolean$branch$when2$funequals$classEncoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-3$fun-equals$class-Decoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    public final boolean m7135Boolean$branch$when3$funequals$classDecoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2247Boolean$branch$when3$funequals$classDecoded$classMjpegVideoView;
        }
        State<Boolean> stateLiveLiteral = f2290State$Boolean$branch$when3$funequals$classDecoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-3$fun-equals$class-Decoded$class-MjpegVideoView", Boolean.valueOf(f2247Boolean$branch$when3$funequals$classDecoded$classMjpegVideoView));
            f2290State$Boolean$branch$when3$funequals$classDecoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-3$fun-equals$class-Encoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-3$fun-equals$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    public final boolean m7136Boolean$branch$when3$funequals$classEncoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2248Boolean$branch$when3$funequals$classEncoded$classMjpegVideoView;
        }
        State<Boolean> stateLiveLiteral = f2291State$Boolean$branch$when3$funequals$classEncoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-3$fun-equals$class-Encoded$class-MjpegVideoView", Boolean.valueOf(f2248Boolean$branch$when3$funequals$classEncoded$classMjpegVideoView));
            f2291State$Boolean$branch$when3$funequals$classEncoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-4$fun-equals$class-Decoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-4$fun-equals$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    public final boolean m7137Boolean$branch$when4$funequals$classDecoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2249Boolean$branch$when4$funequals$classDecoded$classMjpegVideoView;
        }
        State<Boolean> stateLiveLiteral = f2292State$Boolean$branch$when4$funequals$classDecoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-4$fun-equals$class-Decoded$class-MjpegVideoView", Boolean.valueOf(f2249Boolean$branch$when4$funequals$classDecoded$classMjpegVideoView));
            f2292State$Boolean$branch$when4$funequals$classDecoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$branch$when-4$fun-equals$class-Encoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: Boolean$branch$when-4$fun-equals$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    public final boolean m7138Boolean$branch$when4$funequals$classEncoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2250Boolean$branch$when4$funequals$classEncoded$classMjpegVideoView;
        }
        State<Boolean> stateLiveLiteral = f2293State$Boolean$branch$when4$funequals$classEncoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$branch$when-4$fun-equals$class-Encoded$class-MjpegVideoView", Boolean.valueOf(f2250Boolean$branch$when4$funequals$classEncoded$classMjpegVideoView));
            f2293State$Boolean$branch$when4$funequals$classEncoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$fun-equals$class-Decoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: Boolean$fun-equals$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    public final boolean m7139Boolean$funequals$classDecoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2251Boolean$funequals$classDecoded$classMjpegVideoView;
        }
        State<Boolean> stateLiveLiteral = f2294State$Boolean$funequals$classDecoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$fun-equals$class-Decoded$class-MjpegVideoView", Boolean.valueOf(f2251Boolean$funequals$classDecoded$classMjpegVideoView));
            f2294State$Boolean$funequals$classDecoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$fun-equals$class-Encoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: Boolean$fun-equals$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    public final boolean m7140Boolean$funequals$classEncoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2252Boolean$funequals$classEncoded$classMjpegVideoView;
        }
        State<Boolean> stateLiveLiteral = f2295State$Boolean$funequals$classEncoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$fun-equals$class-Encoded$class-MjpegVideoView", Boolean.valueOf(f2252Boolean$funequals$classEncoded$classMjpegVideoView));
            f2295State$Boolean$funequals$classEncoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$set-inJustDecodeBounds$fun-$anonymous$$arg-0$call-apply$val-options$body$loop$fun-decodeLatest$class-MjpegVideoView", offset = 3967)
    /* JADX INFO: renamed from: Boolean$set-inJustDecodeBounds$fun-$anonymous$$arg-0$call-apply$val-options$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    public final boolean m7141Boolean$setinJustDecodeBounds$fun$anonymous$$arg0$callapply$valoptions$body$loop$fundecodeLatest$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2253Boolean$setinJustDecodeBounds$fun$anonymous$$arg0$callapply$valoptions$body$loop$fundecodeLatest$classMjpegVideoView;
        }
        State<Boolean> stateLiveLiteral = f2296State$Boolean$setinJustDecodeBounds$fun$anonymous$$arg0$callapply$valoptions$body$loop$fundecodeLatest$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$set-inJustDecodeBounds$fun-$anonymous$$arg-0$call-apply$val-options$body$loop$fun-decodeLatest$class-MjpegVideoView", Boolean.valueOf(f2253Boolean$setinJustDecodeBounds$fun$anonymous$$arg0$callapply$valoptions$body$loop$fundecodeLatest$classMjpegVideoView));
            f2296State$Boolean$setinJustDecodeBounds$fun$anonymous$$arg0$callapply$valoptions$body$loop$fundecodeLatest$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-drawRect$fun-onDraw$class-MjpegVideoView", offset = 4982)
    /* JADX INFO: renamed from: Float$arg-0$call-drawRect$fun-onDraw$class-MjpegVideoView, reason: not valid java name */
    public final float m7142Float$arg0$calldrawRect$funonDraw$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2254Float$arg0$calldrawRect$funonDraw$classMjpegVideoView;
        }
        State<Float> stateLiveLiteral = f2297State$Float$arg0$calldrawRect$funonDraw$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-drawRect$fun-onDraw$class-MjpegVideoView", Float.valueOf(f2254Float$arg0$calldrawRect$funonDraw$classMjpegVideoView));
            f2297State$Float$arg0$calldrawRect$funonDraw$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-1$call-drawRect$fun-onDraw$class-MjpegVideoView", offset = 4986)
    /* JADX INFO: renamed from: Float$arg-1$call-drawRect$fun-onDraw$class-MjpegVideoView, reason: not valid java name */
    public final float m7143Float$arg1$calldrawRect$funonDraw$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2255Float$arg1$calldrawRect$funonDraw$classMjpegVideoView;
        }
        State<Float> stateLiveLiteral = f2298State$Float$arg1$calldrawRect$funonDraw$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-1$call-drawRect$fun-onDraw$class-MjpegVideoView", Float.valueOf(f2255Float$arg1$calldrawRect$funonDraw$classMjpegVideoView));
            f2298State$Float$arg1$calldrawRect$funonDraw$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$branch$cond$val-valid$body$loop$fun-decodeLatest$class-MjpegVideoView", offset = 4139)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$branch$cond$val-valid$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    public final int m7144Int$$this$callrangeTo$$this$callcontains$branch$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2256Int$$this$callrangeTo$$this$callcontains$branch$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView;
        }
        State<Integer> stateLiveLiteral = f2299State$Int$$this$callrangeTo$$this$callcontains$branch$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$branch$cond$val-valid$body$loop$fun-decodeLatest$class-MjpegVideoView", Integer.valueOf(f2256Int$$this$callrangeTo$$this$callcontains$branch$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView));
            f2299State$Int$$this$callrangeTo$$this$callcontains$branch$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-rangeTo$$this$call-contains$cond$cond$val-valid$body$loop$fun-decodeLatest$class-MjpegVideoView", offset = 4107)
    /* JADX INFO: renamed from: Int$$this$call-rangeTo$$this$call-contains$cond$cond$val-valid$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    public final int m7145Int$$this$callrangeTo$$this$callcontains$cond$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2257Int$$this$callrangeTo$$this$callcontains$cond$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView;
        }
        State<Integer> stateLiveLiteral = f2300State$Int$$this$callrangeTo$$this$callcontains$cond$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-rangeTo$$this$call-contains$cond$cond$val-valid$body$loop$fun-decodeLatest$class-MjpegVideoView", Integer.valueOf(f2257Int$$this$callrangeTo$$this$callcontains$cond$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView));
            f2300State$Int$$this$callrangeTo$$this$callcontains$cond$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onDraw$class-MjpegVideoView", offset = 5383)
    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onDraw$class-MjpegVideoView, reason: not valid java name */
    public final int m7146Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if1$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2258Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if1$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView;
        }
        State<Integer> stateLiveLiteral = f2301State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if1$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-toLong$arg-1$call-greaterOrEqual$cond$if-1$fun-$anonymous$$arg-1$call-synchronized$fun-onDraw$class-MjpegVideoView", Integer.valueOf(f2258Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if1$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView));
            f2301State$Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if1$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-toLong$arg-1$call-lessOrEqual$branch$val-valid$body$loop$fun-decodeLatest$class-MjpegVideoView", offset = 4215)
    /* JADX INFO: renamed from: Int$$this$call-toLong$arg-1$call-lessOrEqual$branch$val-valid$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    public final int m7147Int$$this$calltoLong$arg1$calllessOrEqual$branch$valvalid$body$loop$fundecodeLatest$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2259Int$$this$calltoLong$arg1$calllessOrEqual$branch$valvalid$body$loop$fundecodeLatest$classMjpegVideoView;
        }
        State<Integer> stateLiveLiteral = f2302State$Int$$this$calltoLong$arg1$calllessOrEqual$branch$valvalid$body$loop$fundecodeLatest$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-toLong$arg-1$call-lessOrEqual$branch$val-valid$body$loop$fun-decodeLatest$class-MjpegVideoView", Integer.valueOf(f2259Int$$this$calltoLong$arg1$calllessOrEqual$branch$valvalid$body$loop$fundecodeLatest$classMjpegVideoView));
            f2302State$Int$$this$calltoLong$arg1$calllessOrEqual$branch$valvalid$body$loop$fundecodeLatest$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-$set-decodedFrames$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView", offset = 2827)
    /* JADX INFO: renamed from: Int$arg-0$call-$set-decodedFrames$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    public final int m7148Int$arg0$call$setdecodedFrames$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2260Int$arg0$call$setdecodedFrames$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;
        }
        State<Integer> stateLiveLiteral = f2303State$Int$arg0$call$setdecodedFrames$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-$set-decodedFrames$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView", Integer.valueOf(f2260Int$arg0$call$setdecodedFrames$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView));
            f2303State$Int$arg0$call$setdecodedFrames$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-$set-drawnFrames$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView", offset = 2788)
    /* JADX INFO: renamed from: Int$arg-0$call-$set-drawnFrames$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    public final int m7149Int$arg0$call$setdrawnFrames$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2261Int$arg0$call$setdrawnFrames$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;
        }
        State<Integer> stateLiveLiteral = f2304State$Int$arg0$call$setdrawnFrames$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-$set-drawnFrames$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView", Integer.valueOf(f2261Int$arg0$call$setdrawnFrames$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView));
            f2304State$Int$arg0$call$setdrawnFrames$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-$set-receivedFrames$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView", offset = 2808)
    /* JADX INFO: renamed from: Int$arg-0$call-$set-receivedFrames$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    public final int m7150Int$arg0$call$setreceivedFrames$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2262Int$arg0$call$setreceivedFrames$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;
        }
        State<Integer> stateLiveLiteral = f2305State$Int$arg0$call$setreceivedFrames$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-$set-receivedFrames$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView", Integer.valueOf(f2262Int$arg0$call$setreceivedFrames$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView));
            f2305State$Int$arg0$call$setreceivedFrames$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-div$arg-0$call-$init$$arg-2$call-drawBitmap$fun-$anonymous$$arg-1$call-synchronized$fun-onDraw$class-MjpegVideoView", offset = 5658)
    /* JADX INFO: renamed from: Int$arg-0$call-div$arg-0$call-$init$$arg-2$call-drawBitmap$fun-$anonymous$$arg-1$call-synchronized$fun-onDraw$class-MjpegVideoView, reason: not valid java name */
    public final int m7151Int$arg0$calldiv$arg0$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2263Int$arg0$calldiv$arg0$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView;
        }
        State<Integer> stateLiveLiteral = f2306State$Int$arg0$calldiv$arg0$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-div$arg-0$call-$init$$arg-2$call-drawBitmap$fun-$anonymous$$arg-1$call-synchronized$fun-onDraw$class-MjpegVideoView", Integer.valueOf(f2263Int$arg0$calldiv$arg0$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView));
            f2306State$Int$arg0$calldiv$arg0$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-div$arg-1$call-$init$$arg-2$call-drawBitmap$fun-$anonymous$$arg-1$call-synchronized$fun-onDraw$class-MjpegVideoView", offset = 5676)
    /* JADX INFO: renamed from: Int$arg-0$call-div$arg-1$call-$init$$arg-2$call-drawBitmap$fun-$anonymous$$arg-1$call-synchronized$fun-onDraw$class-MjpegVideoView, reason: not valid java name */
    public final int m7152Int$arg0$calldiv$arg1$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2264Int$arg0$calldiv$arg1$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView;
        }
        State<Integer> stateLiveLiteral = f2307State$Int$arg0$calldiv$arg1$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-div$arg-1$call-$init$$arg-2$call-drawBitmap$fun-$anonymous$$arg-1$call-synchronized$fun-onDraw$class-MjpegVideoView", Integer.valueOf(f2264Int$arg0$calldiv$arg1$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView));
            f2307State$Int$arg0$calldiv$arg1$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-div$arg-2$call-$init$$arg-2$call-drawBitmap$fun-$anonymous$$arg-1$call-synchronized$fun-onDraw$class-MjpegVideoView", offset = 5693)
    /* JADX INFO: renamed from: Int$arg-0$call-div$arg-2$call-$init$$arg-2$call-drawBitmap$fun-$anonymous$$arg-1$call-synchronized$fun-onDraw$class-MjpegVideoView, reason: not valid java name */
    public final int m7153Int$arg0$calldiv$arg2$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2265Int$arg0$calldiv$arg2$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView;
        }
        State<Integer> stateLiveLiteral = f2308State$Int$arg0$calldiv$arg2$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-div$arg-2$call-$init$$arg-2$call-drawBitmap$fun-$anonymous$$arg-1$call-synchronized$fun-onDraw$class-MjpegVideoView", Integer.valueOf(f2265Int$arg0$calldiv$arg2$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView));
            f2308State$Int$arg0$calldiv$arg2$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-div$arg-3$call-$init$$arg-2$call-drawBitmap$fun-$anonymous$$arg-1$call-synchronized$fun-onDraw$class-MjpegVideoView", offset = 5711)
    /* JADX INFO: renamed from: Int$arg-0$call-div$arg-3$call-$init$$arg-2$call-drawBitmap$fun-$anonymous$$arg-1$call-synchronized$fun-onDraw$class-MjpegVideoView, reason: not valid java name */
    public final int m7154Int$arg0$calldiv$arg3$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2266Int$arg0$calldiv$arg3$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView;
        }
        State<Integer> stateLiveLiteral = f2309State$Int$arg0$calldiv$arg3$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-div$arg-3$call-$init$$arg-2$call-drawBitmap$fun-$anonymous$$arg-1$call-synchronized$fun-onDraw$class-MjpegVideoView", Integer.valueOf(f2266Int$arg0$calldiv$arg3$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView));
            f2309State$Int$arg0$calldiv$arg3$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rangeTo$$this$call-contains$branch$cond$val-valid$body$loop$fun-decodeLatest$class-MjpegVideoView", offset = 4142)
    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$branch$cond$val-valid$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    public final int m7155Int$arg0$callrangeTo$$this$callcontains$branch$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2267Int$arg0$callrangeTo$$this$callcontains$branch$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView;
        }
        State<Integer> stateLiveLiteral = f2310State$Int$arg0$callrangeTo$$this$callcontains$branch$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rangeTo$$this$call-contains$branch$cond$val-valid$body$loop$fun-decodeLatest$class-MjpegVideoView", Integer.valueOf(f2267Int$arg0$callrangeTo$$this$callcontains$branch$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView));
            f2310State$Int$arg0$callrangeTo$$this$callcontains$branch$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-rangeTo$$this$call-contains$cond$cond$val-valid$body$loop$fun-decodeLatest$class-MjpegVideoView", offset = 4110)
    /* JADX INFO: renamed from: Int$arg-0$call-rangeTo$$this$call-contains$cond$cond$val-valid$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    public final int m7156Int$arg0$callrangeTo$$this$callcontains$cond$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2268Int$arg0$callrangeTo$$this$callcontains$cond$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView;
        }
        State<Integer> stateLiveLiteral = f2311State$Int$arg0$callrangeTo$$this$callcontains$cond$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-rangeTo$$this$call-contains$cond$cond$val-valid$body$loop$fun-decodeLatest$class-MjpegVideoView", Integer.valueOf(f2268Int$arg0$callrangeTo$$this$callcontains$cond$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView));
            f2311State$Int$arg0$callrangeTo$$this$callcontains$cond$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Decoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    public final int m7157Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classDecoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2269Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classDecoded$classMjpegVideoView;
        }
        State<Integer> stateLiveLiteral = f2312State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classDecoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Decoded$class-MjpegVideoView", Integer.valueOf(f2269Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classDecoded$classMjpegVideoView));
            f2312State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classDecoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Encoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    public final int m7158Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classEncoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2270Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classEncoded$classMjpegVideoView;
        }
        State<Integer> stateLiveLiteral = f2313State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classEncoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result$fun-hashCode$class-Encoded$class-MjpegVideoView", Integer.valueOf(f2270Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classEncoded$classMjpegVideoView));
            f2313State$Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classEncoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-Decoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    public final int m7159Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classDecoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2271Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classDecoded$classMjpegVideoView;
        }
        State<Integer> stateLiveLiteral = f2314State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classDecoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-Decoded$class-MjpegVideoView", Integer.valueOf(f2271Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classDecoded$classMjpegVideoView));
            f2314State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classDecoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-Encoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    public final int m7160Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classEncoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2272Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classEncoded$classMjpegVideoView;
        }
        State<Integer> stateLiveLiteral = f2315State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classEncoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$$this$call-plus$set-result-1$fun-hashCode$class-Encoded$class-MjpegVideoView", Integer.valueOf(f2272Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classEncoded$classMjpegVideoView));
            f2315State$Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classEncoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-decodeByteArray$body$loop$fun-decodeLatest$class-MjpegVideoView", offset = 4031)
    /* JADX INFO: renamed from: Int$arg-1$call-decodeByteArray$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    public final int m7161Int$arg1$calldecodeByteArray$body$loop$fundecodeLatest$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2273Int$arg1$calldecodeByteArray$body$loop$fundecodeLatest$classMjpegVideoView;
        }
        State<Integer> stateLiveLiteral = f2316State$Int$arg1$calldecodeByteArray$body$loop$fundecodeLatest$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-decodeByteArray$body$loop$fun-decodeLatest$class-MjpegVideoView", Integer.valueOf(f2273Int$arg1$calldecodeByteArray$body$loop$fundecodeLatest$classMjpegVideoView));
            f2316State$Int$arg1$calldecodeByteArray$body$loop$fundecodeLatest$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-decodeByteArray$branch$if$val-bitmap$body$loop$fun-decodeLatest$class-MjpegVideoView", offset = 4306)
    /* JADX INFO: renamed from: Int$arg-1$call-decodeByteArray$branch$if$val-bitmap$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    public final int m7162Int$arg1$calldecodeByteArray$branch$if$valbitmap$body$loop$fundecodeLatest$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2274Int$arg1$calldecodeByteArray$branch$if$valbitmap$body$loop$fundecodeLatest$classMjpegVideoView;
        }
        State<Integer> stateLiveLiteral = f2317State$Int$arg1$calldecodeByteArray$branch$if$valbitmap$body$loop$fundecodeLatest$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-decodeByteArray$branch$if$val-bitmap$body$loop$fun-decodeLatest$class-MjpegVideoView", Integer.valueOf(f2274Int$arg1$calldecodeByteArray$branch$if$valbitmap$body$loop$fundecodeLatest$classMjpegVideoView));
            f2317State$Int$arg1$calldecodeByteArray$branch$if$valbitmap$body$loop$fundecodeLatest$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Int$class-MjpegVideoView", offset = -1)
    /* JADX INFO: renamed from: Int$class-MjpegVideoView, reason: not valid java name */
    public final int m7163Int$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2275Int$classMjpegVideoView;
        }
        State<Integer> stateLiveLiteral = f2318State$Int$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-MjpegVideoView", Integer.valueOf(f2275Int$classMjpegVideoView));
            f2318State$Int$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-$set-drawnSequence$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView", offset = 2846)
    /* JADX INFO: renamed from: Long$arg-0$call-$set-drawnSequence$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    public final long m7164Long$arg0$call$setdrawnSequence$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2276Long$arg0$call$setdrawnSequence$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;
        }
        State<Long> stateLiveLiteral = f2319State$Long$arg0$call$setdrawnSequence$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-$set-drawnSequence$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView", Long.valueOf(f2276Long$arg0$call$setdrawnSequence$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView));
            f2319State$Long$arg0$call$setdrawnSequence$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-$set-lastReceivedAt$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView", offset = 2760)
    /* JADX INFO: renamed from: Long$arg-0$call-$set-lastReceivedAt$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    public final long m7165Long$arg0$call$setlastReceivedAt$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2277Long$arg0$call$setlastReceivedAt$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;
        }
        State<Long> stateLiveLiteral = f2320State$Long$arg0$call$setlastReceivedAt$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-$set-lastReceivedAt$$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView", Long.valueOf(f2277Long$arg0$call$setlastReceivedAt$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView));
            f2320State$Long$arg0$call$setlastReceivedAt$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-1$call-postDelayed$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView", offset = 3601)
    /* JADX INFO: renamed from: Long$arg-1$call-postDelayed$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    public final long m7166Long$arg1$callpostDelayed$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2278Long$arg1$callpostDelayed$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;
        }
        State<Long> stateLiveLiteral = f2321State$Long$arg1$callpostDelayed$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-1$call-postDelayed$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView", Long.valueOf(f2278Long$arg1$callpostDelayed$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView));
            f2321State$Long$arg1$callpostDelayed$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().longValue();
    }

    @LiveLiteralInfo(key = "String$0$str$fun-toString$class-Decoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: String$0$str$fun-toString$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    public final String m7167String$0$str$funtoString$classDecoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2340String$0$str$funtoString$classDecoded$classMjpegVideoView;
        }
        State<String> stateLiveLiteral = f2322State$String$0$str$funtoString$classDecoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$fun-toString$class-Decoded$class-MjpegVideoView", f2340String$0$str$funtoString$classDecoded$classMjpegVideoView);
            f2322State$String$0$str$funtoString$classDecoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$fun-toString$class-Encoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: String$0$str$fun-toString$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    public final String m7168String$0$str$funtoString$classEncoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2341String$0$str$funtoString$classEncoded$classMjpegVideoView;
        }
        State<String> stateLiveLiteral = f2323State$String$0$str$funtoString$classEncoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$fun-toString$class-Encoded$class-MjpegVideoView", f2341String$0$str$funtoString$classEncoded$classMjpegVideoView);
            f2323State$String$0$str$funtoString$classEncoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$1$str$fun-toString$class-Decoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: String$1$str$fun-toString$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    public final String m7169String$1$str$funtoString$classDecoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2342String$1$str$funtoString$classDecoded$classMjpegVideoView;
        }
        State<String> stateLiveLiteral = f2324State$String$1$str$funtoString$classDecoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$1$str$fun-toString$class-Decoded$class-MjpegVideoView", f2342String$1$str$funtoString$classDecoded$classMjpegVideoView);
            f2324State$String$1$str$funtoString$classDecoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$1$str$fun-toString$class-Encoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: String$1$str$fun-toString$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    public final String m7170String$1$str$funtoString$classEncoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2343String$1$str$funtoString$classEncoded$classMjpegVideoView;
        }
        State<String> stateLiveLiteral = f2325State$String$1$str$funtoString$classEncoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$1$str$fun-toString$class-Encoded$class-MjpegVideoView", f2343String$1$str$funtoString$classEncoded$classMjpegVideoView);
            f2325State$String$1$str$funtoString$classEncoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$3$str$fun-toString$class-Decoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: String$3$str$fun-toString$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    public final String m7171String$3$str$funtoString$classDecoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2344String$3$str$funtoString$classDecoded$classMjpegVideoView;
        }
        State<String> stateLiveLiteral = f2326State$String$3$str$funtoString$classDecoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$3$str$fun-toString$class-Decoded$class-MjpegVideoView", f2344String$3$str$funtoString$classDecoded$classMjpegVideoView);
            f2326State$String$3$str$funtoString$classDecoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$3$str$fun-toString$class-Encoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: String$3$str$fun-toString$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    public final String m7172String$3$str$funtoString$classEncoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2345String$3$str$funtoString$classEncoded$classMjpegVideoView;
        }
        State<String> stateLiveLiteral = f2327State$String$3$str$funtoString$classEncoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$3$str$fun-toString$class-Encoded$class-MjpegVideoView", f2345String$3$str$funtoString$classEncoded$classMjpegVideoView);
            f2327State$String$3$str$funtoString$classEncoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$4$str$fun-toString$class-Decoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: String$4$str$fun-toString$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    public final String m7173String$4$str$funtoString$classDecoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2346String$4$str$funtoString$classDecoded$classMjpegVideoView;
        }
        State<String> stateLiveLiteral = f2328State$String$4$str$funtoString$classDecoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$4$str$fun-toString$class-Decoded$class-MjpegVideoView", f2346String$4$str$funtoString$classDecoded$classMjpegVideoView);
            f2328State$String$4$str$funtoString$classDecoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$4$str$fun-toString$class-Encoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: String$4$str$fun-toString$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    public final String m7174String$4$str$funtoString$classEncoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2347String$4$str$funtoString$classEncoded$classMjpegVideoView;
        }
        State<String> stateLiveLiteral = f2329State$String$4$str$funtoString$classEncoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$4$str$fun-toString$class-Encoded$class-MjpegVideoView", f2347String$4$str$funtoString$classEncoded$classMjpegVideoView);
            f2329State$String$4$str$funtoString$classEncoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$6$str$fun-toString$class-Decoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: String$6$str$fun-toString$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    public final String m7175String$6$str$funtoString$classDecoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2348String$6$str$funtoString$classDecoded$classMjpegVideoView;
        }
        State<String> stateLiveLiteral = f2330State$String$6$str$funtoString$classDecoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$6$str$fun-toString$class-Decoded$class-MjpegVideoView", f2348String$6$str$funtoString$classDecoded$classMjpegVideoView);
            f2330State$String$6$str$funtoString$classDecoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$6$str$fun-toString$class-Encoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: String$6$str$fun-toString$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    public final String m7176String$6$str$funtoString$classEncoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2349String$6$str$funtoString$classEncoded$classMjpegVideoView;
        }
        State<String> stateLiveLiteral = f2331State$String$6$str$funtoString$classEncoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$6$str$fun-toString$class-Encoded$class-MjpegVideoView", f2349String$6$str$funtoString$classEncoded$classMjpegVideoView);
            f2331State$String$6$str$funtoString$classEncoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$7$str$fun-toString$class-Decoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: String$7$str$fun-toString$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    public final String m7177String$7$str$funtoString$classDecoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2350String$7$str$funtoString$classDecoded$classMjpegVideoView;
        }
        State<String> stateLiveLiteral = f2332State$String$7$str$funtoString$classDecoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$7$str$fun-toString$class-Decoded$class-MjpegVideoView", f2350String$7$str$funtoString$classDecoded$classMjpegVideoView);
            f2332State$String$7$str$funtoString$classDecoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$7$str$fun-toString$class-Encoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: String$7$str$fun-toString$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    public final String m7178String$7$str$funtoString$classEncoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2351String$7$str$funtoString$classEncoded$classMjpegVideoView;
        }
        State<String> stateLiveLiteral = f2333State$String$7$str$funtoString$classEncoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$7$str$fun-toString$class-Encoded$class-MjpegVideoView", f2351String$7$str$funtoString$classEncoded$classMjpegVideoView);
            f2333State$String$7$str$funtoString$classEncoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$9$str$fun-toString$class-Decoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: String$9$str$fun-toString$class-Decoded$class-MjpegVideoView, reason: not valid java name */
    public final String m7179String$9$str$funtoString$classDecoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2352String$9$str$funtoString$classDecoded$classMjpegVideoView;
        }
        State<String> stateLiveLiteral = f2334State$String$9$str$funtoString$classDecoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$9$str$fun-toString$class-Decoded$class-MjpegVideoView", f2352String$9$str$funtoString$classDecoded$classMjpegVideoView);
            f2334State$String$9$str$funtoString$classDecoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$9$str$fun-toString$class-Encoded$class-MjpegVideoView", offset = -2)
    /* JADX INFO: renamed from: String$9$str$fun-toString$class-Encoded$class-MjpegVideoView, reason: not valid java name */
    public final String m7180String$9$str$funtoString$classEncoded$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2353String$9$str$funtoString$classEncoded$classMjpegVideoView;
        }
        State<String> stateLiveLiteral = f2335State$String$9$str$funtoString$classEncoded$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$9$str$fun-toString$class-Encoded$class-MjpegVideoView", f2353String$9$str$funtoString$classEncoded$classMjpegVideoView);
            f2335State$String$9$str$funtoString$classEncoded$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-d$fun-$anonymous$$arg-1$call-synchronized$fun-stop$class-MjpegVideoView", offset = 6118)
    /* JADX INFO: renamed from: String$arg-0$call-d$fun-$anonymous$$arg-1$call-synchronized$fun-stop$class-MjpegVideoView, reason: not valid java name */
    public final String m7181String$arg0$calld$fun$anonymous$$arg1$callsynchronized$funstop$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2354String$arg0$calld$fun$anonymous$$arg1$callsynchronized$funstop$classMjpegVideoView;
        }
        State<String> stateLiveLiteral = f2336State$String$arg0$calld$fun$anonymous$$arg1$callsynchronized$funstop$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-d$fun-$anonymous$$arg-1$call-synchronized$fun-stop$class-MjpegVideoView", f2354String$arg0$calld$fun$anonymous$$arg1$callsynchronized$funstop$classMjpegVideoView);
            f2336State$String$arg0$calld$fun$anonymous$$arg1$callsynchronized$funstop$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView", offset = 3462)
    /* JADX INFO: renamed from: String$arg-0$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView, reason: not valid java name */
    public final String m7182String$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2355String$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;
        }
        State<String> stateLiveLiteral = f2337State$String$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-invoke$fun-$anonymous$$arg-1$call-synchronized$fun-start$class-MjpegVideoView", f2355String$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView);
            f2337State$String$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-stop$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-$anonymous$$arg-0$call-post$branch$if$branch$if$fun-$anonymous$$arg-1$call-synchronized$body$loop$fun-decodeLatest$class-MjpegVideoView", offset = 4607)
    /* JADX INFO: renamed from: String$arg-0$call-stop$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-$anonymous$$arg-0$call-post$branch$if$branch$if$fun-$anonymous$$arg-1$call-synchronized$body$loop$fun-decodeLatest$class-MjpegVideoView, reason: not valid java name */
    public final String m7183String$arg0$callstop$branch$if$fun$anonymous$$arg1$callsynchronized$fun$anonymous$$arg0$callpost$branch$if$branch$if$fun$anonymous$$arg1$callsynchronized$body$loop$fundecodeLatest$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2356String$arg0$callstop$branch$if$fun$anonymous$$arg1$callsynchronized$fun$anonymous$$arg0$callpost$branch$if$branch$if$fun$anonymous$$arg1$callsynchronized$body$loop$fundecodeLatest$classMjpegVideoView;
        }
        State<String> stateLiveLiteral = f2338State$String$arg0$callstop$branch$if$fun$anonymous$$arg1$callsynchronized$fun$anonymous$$arg0$callpost$branch$if$branch$if$fun$anonymous$$arg1$callsynchronized$body$loop$fundecodeLatest$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-stop$branch$if$fun-$anonymous$$arg-1$call-synchronized$fun-$anonymous$$arg-0$call-post$branch$if$branch$if$fun-$anonymous$$arg-1$call-synchronized$body$loop$fun-decodeLatest$class-MjpegVideoView", f2356String$arg0$callstop$branch$if$fun$anonymous$$arg1$callsynchronized$fun$anonymous$$arg0$callpost$branch$if$branch$if$fun$anonymous$$arg1$callsynchronized$body$loop$fundecodeLatest$classMjpegVideoView);
            f2338State$String$arg0$callstop$branch$if$fun$anonymous$$arg1$callsynchronized$fun$anonymous$$arg0$callpost$branch$if$branch$if$fun$anonymous$$arg1$callsynchronized$body$loop$fundecodeLatest$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$param-message$fun-stop$class-MjpegVideoView", offset = 5870)
    /* JADX INFO: renamed from: String$param-message$fun-stop$class-MjpegVideoView, reason: not valid java name */
    public final String m7184String$parammessage$funstop$classMjpegVideoView() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2357String$parammessage$funstop$classMjpegVideoView;
        }
        State<String> stateLiveLiteral = f2339State$String$parammessage$funstop$classMjpegVideoView;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$param-message$fun-stop$class-MjpegVideoView", f2357String$parammessage$funstop$classMjpegVideoView);
            f2339State$String$parammessage$funstop$classMjpegVideoView = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
