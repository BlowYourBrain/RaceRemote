package vea.raceremote.video;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: VideoPanel.kt */
/* JADX INFO: loaded from: classes11.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/main/java/vea/raceremote/video/VideoPanel.kt")
public final class LiveLiterals$VideoPanelKt {

    /* JADX INFO: renamed from: Boolean$arg-0$call-mutableStateOf$fun-$anonymous$$arg-0$call-remember$val-active$delegate$fun-VideoPanel, reason: not valid java name */
    private static boolean f2358Boolean$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valactive$delegate$funVideoPanel;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-mutableStateOf$fun-$anonymous$$arg-0$call-remember$val-active$delegate$fun-VideoPanel, reason: not valid java name */
    private static State<Boolean> f2365State$Boolean$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valactive$delegate$funVideoPanel;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-EQEQ$fun-$anonymous$$arg-0$call-firstOrNull$val-wifi$else$if$fun-$anonymous$$arg-0$call-Button$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    private static State<Boolean> f2366State$Boolean$arg1$callEQEQ$fun$anonymous$$arg0$callfirstOrNull$valwifi$else$if$fun$anonymous$$arg0$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;

    /* JADX INFO: renamed from: State$Boolean$arg-14$call-OutlinedTextField$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    private static State<Boolean> f2367State$Boolean$arg14$callOutlinedTextField$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;

    /* JADX INFO: renamed from: State$Boolean$param-showSettings$fun-VideoPanel, reason: not valid java name */
    private static State<Boolean> f2368State$Boolean$paramshowSettings$funVideoPanel;

    /* JADX INFO: renamed from: State$Float$arg-0$call-weight$$$this$call-clipToBounds$$$this$call-testTag$arg-1$call-AndroidView$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    private static State<Float> f2369State$Float$arg0$callweight$$$this$callclipToBounds$$$this$calltestTag$arg1$callAndroidView$fun$anonymous$$arg3$callColumn$funVideoPanel;

    /* JADX INFO: renamed from: State$Float$arg-0$call-weight$$$this$call-testTag$val-tmp2_modifier$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    private static State<Float> f2370State$Float$arg0$callweight$$$this$calltestTag$valtmp2_modifier$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;

    /* JADX INFO: renamed from: State$Int$$$this$call-$get-dp$$arg-0$call-spacedBy$arg-1$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    private static State<Integer> f2371State$Int$$$this$call$getdp$$arg0$callspacedBy$arg1$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-mutableStateOf$fun-$anonymous$$arg-3$call-rememberSaveable$val-url$delegate$fun-VideoPanel, reason: not valid java name */
    private static State<String> f2372State$String$0$str$arg0$callmutableStateOf$fun$anonymous$$arg3$callrememberSaveable$valurl$delegate$funVideoPanel;

    /* JADX INFO: renamed from: State$String$2$str$arg-0$call-mutableStateOf$fun-$anonymous$$arg-3$call-rememberSaveable$val-url$delegate$fun-VideoPanel, reason: not valid java name */
    private static State<String> f2373State$String$2$str$arg0$callmutableStateOf$fun$anonymous$$arg3$callrememberSaveable$valurl$delegate$funVideoPanel;

    /* JADX INFO: renamed from: State$String$arg-0$call-Text$fun-$anonymous$$arg-6$call-OutlinedTextField$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    private static State<String> f2374State$String$arg0$callText$fun$anonymous$$arg6$callOutlinedTextField$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;

    /* JADX INFO: renamed from: State$String$arg-0$call-mutableStateOf$fun-$anonymous$$arg-0$call-remember$val-message$delegate$fun-VideoPanel, reason: not valid java name */
    private static State<String> f2375State$String$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valmessage$delegate$funVideoPanel;

    /* JADX INFO: renamed from: State$String$arg-0$call-testTag$arg-1$call-AndroidView$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    private static State<String> f2376State$String$arg0$calltestTag$arg1$callAndroidView$fun$anonymous$$arg3$callColumn$funVideoPanel;

    /* JADX INFO: renamed from: State$String$arg-0$call-testTag$arg-1$call-Button$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    private static State<String> f2377State$String$arg0$calltestTag$arg1$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;

    /* JADX INFO: renamed from: State$String$arg-0$call-testTag$arg-1$call-Text$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    private static State<String> f2378State$String$arg0$calltestTag$arg1$callText$fun$anonymous$$arg3$callColumn$funVideoPanel;

    /* JADX INFO: renamed from: State$String$arg-0$call-testTag$val-tmp2_modifier$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    private static State<String> f2379State$String$arg0$calltestTag$valtmp2_modifier$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;

    /* JADX INFO: renamed from: State$String$branch$if$arg-0$call-Text$fun-$anonymous$$arg-9$call-Button$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    private static State<String> f2380State$String$branch$if$arg0$callText$fun$anonymous$$arg9$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;

    /* JADX INFO: renamed from: State$String$else$if$arg-0$call-Text$fun-$anonymous$$arg-9$call-Button$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    private static State<String> f2381State$String$else$if$arg0$callText$fun$anonymous$$arg9$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;
    public static final LiveLiterals$VideoPanelKt INSTANCE = new LiveLiterals$VideoPanelKt();

    /* JADX INFO: renamed from: Boolean$param-showSettings$fun-VideoPanel, reason: not valid java name */
    private static boolean f2361Boolean$paramshowSettings$funVideoPanel = true;

    /* JADX INFO: renamed from: String$0$str$arg-0$call-mutableStateOf$fun-$anonymous$$arg-3$call-rememberSaveable$val-url$delegate$fun-VideoPanel, reason: not valid java name */
    private static String f2382String$0$str$arg0$callmutableStateOf$fun$anonymous$$arg3$callrememberSaveable$valurl$delegate$funVideoPanel = "http://";

    /* JADX INFO: renamed from: String$2$str$arg-0$call-mutableStateOf$fun-$anonymous$$arg-3$call-rememberSaveable$val-url$delegate$fun-VideoPanel, reason: not valid java name */
    private static String f2383String$2$str$arg0$callmutableStateOf$fun$anonymous$$arg3$callrememberSaveable$valurl$delegate$funVideoPanel = ":81/stream";

    /* JADX INFO: renamed from: String$arg-0$call-mutableStateOf$fun-$anonymous$$arg-0$call-remember$val-message$delegate$fun-VideoPanel, reason: not valid java name */
    private static String f2385String$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valmessage$delegate$funVideoPanel = "Видео выключено";

    /* JADX INFO: renamed from: Int$$$this$call-$get-dp$$arg-0$call-spacedBy$arg-1$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    private static int f2364Int$$$this$call$getdp$$arg0$callspacedBy$arg1$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel = 8;

    /* JADX INFO: renamed from: Float$arg-0$call-weight$$$this$call-testTag$val-tmp2_modifier$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    private static float f2363Float$arg0$callweight$$$this$calltestTag$valtmp2_modifier$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel = 1.0f;

    /* JADX INFO: renamed from: String$arg-0$call-testTag$val-tmp2_modifier$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    private static String f2389String$arg0$calltestTag$valtmp2_modifier$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel = "video_address";

    /* JADX INFO: renamed from: String$arg-0$call-Text$fun-$anonymous$$arg-6$call-OutlinedTextField$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    private static String f2384String$arg0$callText$fun$anonymous$$arg6$callOutlinedTextField$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel = "Адрес видео";

    /* JADX INFO: renamed from: Boolean$arg-14$call-OutlinedTextField$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    private static boolean f2360Boolean$arg14$callOutlinedTextField$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel = true;

    /* JADX INFO: renamed from: Boolean$arg-1$call-EQEQ$fun-$anonymous$$arg-0$call-firstOrNull$val-wifi$else$if$fun-$anonymous$$arg-0$call-Button$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    private static boolean f2359Boolean$arg1$callEQEQ$fun$anonymous$$arg0$callfirstOrNull$valwifi$else$if$fun$anonymous$$arg0$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel = true;

    /* JADX INFO: renamed from: String$arg-0$call-testTag$arg-1$call-Button$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    private static String f2387String$arg0$calltestTag$arg1$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel = "toggle_video";

    /* JADX INFO: renamed from: String$branch$if$arg-0$call-Text$fun-$anonymous$$arg-9$call-Button$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    private static String f2390String$branch$if$arg0$callText$fun$anonymous$$arg9$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel = "Выключить";

    /* JADX INFO: renamed from: String$else$if$arg-0$call-Text$fun-$anonymous$$arg-9$call-Button$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    private static String f2391String$else$if$arg0$callText$fun$anonymous$$arg9$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel = "Смотреть";

    /* JADX INFO: renamed from: String$arg-0$call-testTag$arg-1$call-Text$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    private static String f2388String$arg0$calltestTag$arg1$callText$fun$anonymous$$arg3$callColumn$funVideoPanel = "video_status";

    /* JADX INFO: renamed from: Float$arg-0$call-weight$$$this$call-clipToBounds$$$this$call-testTag$arg-1$call-AndroidView$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    private static float f2362Float$arg0$callweight$$$this$callclipToBounds$$$this$calltestTag$arg1$callAndroidView$fun$anonymous$$arg3$callColumn$funVideoPanel = 1.0f;

    /* JADX INFO: renamed from: String$arg-0$call-testTag$arg-1$call-AndroidView$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    private static String f2386String$arg0$calltestTag$arg1$callAndroidView$fun$anonymous$$arg3$callColumn$funVideoPanel = "video_image";

    @LiveLiteralInfo(key = "Boolean$arg-0$call-mutableStateOf$fun-$anonymous$$arg-0$call-remember$val-active$delegate$fun-VideoPanel", offset = 1203)
    /* JADX INFO: renamed from: Boolean$arg-0$call-mutableStateOf$fun-$anonymous$$arg-0$call-remember$val-active$delegate$fun-VideoPanel, reason: not valid java name */
    public final boolean m7185Boolean$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valactive$delegate$funVideoPanel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2358Boolean$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valactive$delegate$funVideoPanel;
        }
        State<Boolean> stateLiveLiteral = f2365State$Boolean$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valactive$delegate$funVideoPanel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-mutableStateOf$fun-$anonymous$$arg-0$call-remember$val-active$delegate$fun-VideoPanel", Boolean.valueOf(f2358Boolean$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valactive$delegate$funVideoPanel));
            f2365State$Boolean$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valactive$delegate$funVideoPanel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-EQEQ$fun-$anonymous$$arg-0$call-firstOrNull$val-wifi$else$if$fun-$anonymous$$arg-0$call-Button$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel", offset = 2503)
    /* JADX INFO: renamed from: Boolean$arg-1$call-EQEQ$fun-$anonymous$$arg-0$call-firstOrNull$val-wifi$else$if$fun-$anonymous$$arg-0$call-Button$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    public final boolean m7186Boolean$arg1$callEQEQ$fun$anonymous$$arg0$callfirstOrNull$valwifi$else$if$fun$anonymous$$arg0$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2359Boolean$arg1$callEQEQ$fun$anonymous$$arg0$callfirstOrNull$valwifi$else$if$fun$anonymous$$arg0$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;
        }
        State<Boolean> stateLiveLiteral = f2366State$Boolean$arg1$callEQEQ$fun$anonymous$$arg0$callfirstOrNull$valwifi$else$if$fun$anonymous$$arg0$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-EQEQ$fun-$anonymous$$arg-0$call-firstOrNull$val-wifi$else$if$fun-$anonymous$$arg-0$call-Button$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel", Boolean.valueOf(f2359Boolean$arg1$callEQEQ$fun$anonymous$$arg0$callfirstOrNull$valwifi$else$if$fun$anonymous$$arg0$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel));
            f2366State$Boolean$arg1$callEQEQ$fun$anonymous$$arg0$callfirstOrNull$valwifi$else$if$fun$anonymous$$arg0$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-14$call-OutlinedTextField$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel", offset = 2044)
    /* JADX INFO: renamed from: Boolean$arg-14$call-OutlinedTextField$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    public final boolean m7187Boolean$arg14$callOutlinedTextField$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2360Boolean$arg14$callOutlinedTextField$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;
        }
        State<Boolean> stateLiveLiteral = f2367State$Boolean$arg14$callOutlinedTextField$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-14$call-OutlinedTextField$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel", Boolean.valueOf(f2360Boolean$arg14$callOutlinedTextField$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel));
            f2367State$Boolean$arg14$callOutlinedTextField$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$param-showSettings$fun-VideoPanel", offset = 808)
    /* JADX INFO: renamed from: Boolean$param-showSettings$fun-VideoPanel, reason: not valid java name */
    public final boolean m7188Boolean$paramshowSettings$funVideoPanel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2361Boolean$paramshowSettings$funVideoPanel;
        }
        State<Boolean> stateLiveLiteral = f2368State$Boolean$paramshowSettings$funVideoPanel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$param-showSettings$fun-VideoPanel", Boolean.valueOf(f2361Boolean$paramshowSettings$funVideoPanel));
            f2368State$Boolean$paramshowSettings$funVideoPanel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().booleanValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-weight$$$this$call-clipToBounds$$$this$call-testTag$arg-1$call-AndroidView$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel", offset = 3026)
    /* JADX INFO: renamed from: Float$arg-0$call-weight$$$this$call-clipToBounds$$$this$call-testTag$arg-1$call-AndroidView$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    public final float m7189Float$arg0$callweight$$$this$callclipToBounds$$$this$calltestTag$arg1$callAndroidView$fun$anonymous$$arg3$callColumn$funVideoPanel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2362Float$arg0$callweight$$$this$callclipToBounds$$$this$calltestTag$arg1$callAndroidView$fun$anonymous$$arg3$callColumn$funVideoPanel;
        }
        State<Float> stateLiveLiteral = f2369State$Float$arg0$callweight$$$this$callclipToBounds$$$this$calltestTag$arg1$callAndroidView$fun$anonymous$$arg3$callColumn$funVideoPanel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-weight$$$this$call-clipToBounds$$$this$call-testTag$arg-1$call-AndroidView$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel", Float.valueOf(f2362Float$arg0$callweight$$$this$callclipToBounds$$$this$calltestTag$arg1$callAndroidView$fun$anonymous$$arg3$callColumn$funVideoPanel));
            f2369State$Float$arg0$callweight$$$this$callclipToBounds$$$this$calltestTag$arg1$callAndroidView$fun$anonymous$$arg3$callColumn$funVideoPanel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Float$arg-0$call-weight$$$this$call-testTag$val-tmp2_modifier$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel", offset = 2126)
    /* JADX INFO: renamed from: Float$arg-0$call-weight$$$this$call-testTag$val-tmp2_modifier$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    public final float m7190Float$arg0$callweight$$$this$calltestTag$valtmp2_modifier$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2363Float$arg0$callweight$$$this$calltestTag$valtmp2_modifier$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;
        }
        State<Float> stateLiveLiteral = f2370State$Float$arg0$callweight$$$this$calltestTag$valtmp2_modifier$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Float$arg-0$call-weight$$$this$call-testTag$val-tmp2_modifier$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel", Float.valueOf(f2363Float$arg0$callweight$$$this$calltestTag$valtmp2_modifier$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel));
            f2370State$Float$arg0$callweight$$$this$calltestTag$valtmp2_modifier$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().floatValue();
    }

    @LiveLiteralInfo(key = "Int$$$this$call-$get-dp$$arg-0$call-spacedBy$arg-1$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel", offset = 1954)
    /* JADX INFO: renamed from: Int$$$this$call-$get-dp$$arg-0$call-spacedBy$arg-1$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    public final int m7191Int$$$this$call$getdp$$arg0$callspacedBy$arg1$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2364Int$$$this$call$getdp$$arg0$callspacedBy$arg1$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;
        }
        State<Integer> stateLiveLiteral = f2371State$Int$$$this$call$getdp$$arg0$callspacedBy$arg1$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$$this$call-$get-dp$$arg-0$call-spacedBy$arg-1$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel", Integer.valueOf(f2364Int$$$this$call$getdp$$arg0$callspacedBy$arg1$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel));
            f2371State$Int$$$this$call$getdp$$arg0$callspacedBy$arg1$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue().intValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-mutableStateOf$fun-$anonymous$$arg-3$call-rememberSaveable$val-url$delegate$fun-VideoPanel", offset = 1063)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-mutableStateOf$fun-$anonymous$$arg-3$call-rememberSaveable$val-url$delegate$fun-VideoPanel, reason: not valid java name */
    public final String m7192String$0$str$arg0$callmutableStateOf$fun$anonymous$$arg3$callrememberSaveable$valurl$delegate$funVideoPanel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2382String$0$str$arg0$callmutableStateOf$fun$anonymous$$arg3$callrememberSaveable$valurl$delegate$funVideoPanel;
        }
        State<String> stateLiveLiteral = f2372State$String$0$str$arg0$callmutableStateOf$fun$anonymous$$arg3$callrememberSaveable$valurl$delegate$funVideoPanel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-mutableStateOf$fun-$anonymous$$arg-3$call-rememberSaveable$val-url$delegate$fun-VideoPanel", f2382String$0$str$arg0$callmutableStateOf$fun$anonymous$$arg3$callrememberSaveable$valurl$delegate$funVideoPanel);
            f2372State$String$0$str$arg0$callmutableStateOf$fun$anonymous$$arg3$callrememberSaveable$valurl$delegate$funVideoPanel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$arg-0$call-mutableStateOf$fun-$anonymous$$arg-3$call-rememberSaveable$val-url$delegate$fun-VideoPanel", offset = 1078)
    /* JADX INFO: renamed from: String$2$str$arg-0$call-mutableStateOf$fun-$anonymous$$arg-3$call-rememberSaveable$val-url$delegate$fun-VideoPanel, reason: not valid java name */
    public final String m7193String$2$str$arg0$callmutableStateOf$fun$anonymous$$arg3$callrememberSaveable$valurl$delegate$funVideoPanel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2383String$2$str$arg0$callmutableStateOf$fun$anonymous$$arg3$callrememberSaveable$valurl$delegate$funVideoPanel;
        }
        State<String> stateLiveLiteral = f2373State$String$2$str$arg0$callmutableStateOf$fun$anonymous$$arg3$callrememberSaveable$valurl$delegate$funVideoPanel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$arg-0$call-mutableStateOf$fun-$anonymous$$arg-3$call-rememberSaveable$val-url$delegate$fun-VideoPanel", f2383String$2$str$arg0$callmutableStateOf$fun$anonymous$$arg3$callrememberSaveable$valurl$delegate$funVideoPanel);
            f2373State$String$2$str$arg0$callmutableStateOf$fun$anonymous$$arg3$callrememberSaveable$valurl$delegate$funVideoPanel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-Text$fun-$anonymous$$arg-6$call-OutlinedTextField$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel", offset = 2082)
    /* JADX INFO: renamed from: String$arg-0$call-Text$fun-$anonymous$$arg-6$call-OutlinedTextField$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    public final String m7194String$arg0$callText$fun$anonymous$$arg6$callOutlinedTextField$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2384String$arg0$callText$fun$anonymous$$arg6$callOutlinedTextField$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;
        }
        State<String> stateLiveLiteral = f2374State$String$arg0$callText$fun$anonymous$$arg6$callOutlinedTextField$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-Text$fun-$anonymous$$arg-6$call-OutlinedTextField$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel", f2384String$arg0$callText$fun$anonymous$$arg6$callOutlinedTextField$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel);
            f2374State$String$arg0$callText$fun$anonymous$$arg6$callOutlinedTextField$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-mutableStateOf$fun-$anonymous$$arg-0$call-remember$val-message$delegate$fun-VideoPanel", offset = 1139)
    /* JADX INFO: renamed from: String$arg-0$call-mutableStateOf$fun-$anonymous$$arg-0$call-remember$val-message$delegate$fun-VideoPanel, reason: not valid java name */
    public final String m7195String$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valmessage$delegate$funVideoPanel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2385String$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valmessage$delegate$funVideoPanel;
        }
        State<String> stateLiveLiteral = f2375State$String$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valmessage$delegate$funVideoPanel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-mutableStateOf$fun-$anonymous$$arg-0$call-remember$val-message$delegate$fun-VideoPanel", f2385String$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valmessage$delegate$funVideoPanel);
            f2375State$String$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valmessage$delegate$funVideoPanel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-testTag$arg-1$call-AndroidView$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel", offset = 3054)
    /* JADX INFO: renamed from: String$arg-0$call-testTag$arg-1$call-AndroidView$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    public final String m7196String$arg0$calltestTag$arg1$callAndroidView$fun$anonymous$$arg3$callColumn$funVideoPanel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2386String$arg0$calltestTag$arg1$callAndroidView$fun$anonymous$$arg3$callColumn$funVideoPanel;
        }
        State<String> stateLiveLiteral = f2376State$String$arg0$calltestTag$arg1$callAndroidView$fun$anonymous$$arg3$callColumn$funVideoPanel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-testTag$arg-1$call-AndroidView$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel", f2386String$arg0$calltestTag$arg1$callAndroidView$fun$anonymous$$arg3$callColumn$funVideoPanel);
            f2376State$String$arg0$calltestTag$arg1$callAndroidView$fun$anonymous$$arg3$callColumn$funVideoPanel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-testTag$arg-1$call-Button$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel", offset = 2770)
    /* JADX INFO: renamed from: String$arg-0$call-testTag$arg-1$call-Button$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    public final String m7197String$arg0$calltestTag$arg1$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2387String$arg0$calltestTag$arg1$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;
        }
        State<String> stateLiveLiteral = f2377State$String$arg0$calltestTag$arg1$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-testTag$arg-1$call-Button$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel", f2387String$arg0$calltestTag$arg1$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel);
            f2377State$String$arg0$calltestTag$arg1$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-testTag$arg-1$call-Text$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel", offset = 2886)
    /* JADX INFO: renamed from: String$arg-0$call-testTag$arg-1$call-Text$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    public final String m7198String$arg0$calltestTag$arg1$callText$fun$anonymous$$arg3$callColumn$funVideoPanel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2388String$arg0$calltestTag$arg1$callText$fun$anonymous$$arg3$callColumn$funVideoPanel;
        }
        State<String> stateLiveLiteral = f2378State$String$arg0$calltestTag$arg1$callText$fun$anonymous$$arg3$callColumn$funVideoPanel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-testTag$arg-1$call-Text$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel", f2388String$arg0$calltestTag$arg1$callText$fun$anonymous$$arg3$callColumn$funVideoPanel);
            f2378State$String$arg0$calltestTag$arg1$callText$fun$anonymous$$arg3$callColumn$funVideoPanel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-testTag$val-tmp2_modifier$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel", offset = 2139)
    /* JADX INFO: renamed from: String$arg-0$call-testTag$val-tmp2_modifier$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    public final String m7199String$arg0$calltestTag$valtmp2_modifier$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2389String$arg0$calltestTag$valtmp2_modifier$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;
        }
        State<String> stateLiveLiteral = f2379State$String$arg0$calltestTag$valtmp2_modifier$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-testTag$val-tmp2_modifier$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel", f2389String$arg0$calltestTag$valtmp2_modifier$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel);
            f2379State$String$arg0$calltestTag$valtmp2_modifier$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$branch$if$arg-0$call-Text$fun-$anonymous$$arg-9$call-Button$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel", offset = 2806)
    /* JADX INFO: renamed from: String$branch$if$arg-0$call-Text$fun-$anonymous$$arg-9$call-Button$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    public final String m7200String$branch$if$arg0$callText$fun$anonymous$$arg9$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2390String$branch$if$arg0$callText$fun$anonymous$$arg9$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;
        }
        State<String> stateLiveLiteral = f2380State$String$branch$if$arg0$callText$fun$anonymous$$arg9$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$branch$if$arg-0$call-Text$fun-$anonymous$$arg-9$call-Button$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel", f2390String$branch$if$arg0$callText$fun$anonymous$$arg9$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel);
            f2380State$String$branch$if$arg0$callText$fun$anonymous$$arg9$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$else$if$arg-0$call-Text$fun-$anonymous$$arg-9$call-Button$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel", offset = 2823)
    /* JADX INFO: renamed from: String$else$if$arg-0$call-Text$fun-$anonymous$$arg-9$call-Button$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel, reason: not valid java name */
    public final String m7201String$else$if$arg0$callText$fun$anonymous$$arg9$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2391String$else$if$arg0$callText$fun$anonymous$$arg9$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;
        }
        State<String> stateLiveLiteral = f2381State$String$else$if$arg0$callText$fun$anonymous$$arg9$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$else$if$arg-0$call-Text$fun-$anonymous$$arg-9$call-Button$fun-$anonymous$$arg-3$call-Row$branch$if$fun-$anonymous$$arg-3$call-Column$fun-VideoPanel", f2391String$else$if$arg0$callText$fun$anonymous$$arg9$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel);
            f2381State$String$else$if$arg0$callText$fun$anonymous$$arg9$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel = stateLiveLiteral;
        }
        return stateLiveLiteral.getValue();
    }
}
