package vea.raceremote.video;

import java.util.Arrays;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: MjpegFrame.kt */
/* JADX INFO: loaded from: classes11.dex */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\t\n\u0002\b\u000e\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001B!\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0005¢\u0006\u0002\u0010\u0007J\t\u0010\u000e\u001a\u00020\u0003HÆ\u0003J\u0010\u0010\u000f\u001a\u0004\u0018\u00010\u0005HÆ\u0003¢\u0006\u0002\u0010\u000bJ\u0010\u0010\u0010\u001a\u0004\u0018\u00010\u0005HÆ\u0003¢\u0006\u0002\u0010\u000bJ0\u0010\u0011\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0005HÆ\u0001¢\u0006\u0002\u0010\u0012J\u0013\u0010\u0013\u001a\u00020\u00142\b\u0010\u0015\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0016\u001a\u00020\u0017HÖ\u0001J\t\u0010\u0018\u001a\u00020\u0019HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0015\u0010\u0006\u001a\u0004\u0018\u00010\u0005¢\u0006\n\n\u0002\u0010\f\u001a\u0004\b\n\u0010\u000bR\u0015\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\n\n\u0002\u0010\f\u001a\u0004\b\r\u0010\u000b¨\u0006\u001a"}, d2 = {"Lvea/raceremote/video/MjpegFrame;", "", "bytes", "", "sequence", "", "capturedUs", "([BLjava/lang/Long;Ljava/lang/Long;)V", "getBytes", "()[B", "getCapturedUs", "()Ljava/lang/Long;", "Ljava/lang/Long;", "getSequence", "component1", "component2", "component3", "copy", "([BLjava/lang/Long;Ljava/lang/Long;)Lvea/raceremote/video/MjpegFrame;", "equals", "", "other", "hashCode", "", "toString", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final /* data */ class MjpegFrame {
    public static final int $stable = LiveLiterals$MjpegFrameKt.INSTANCE.m7031Int$classMjpegFrame();
    private final byte[] bytes;
    private final Long capturedUs;
    private final Long sequence;

    public static /* synthetic */ MjpegFrame copy$default(MjpegFrame mjpegFrame, byte[] bArr, Long l, Long l2, int i, Object obj) {
        if ((i & 1) != 0) {
            bArr = mjpegFrame.bytes;
        }
        if ((i & 2) != 0) {
            l = mjpegFrame.sequence;
        }
        if ((i & 4) != 0) {
            l2 = mjpegFrame.capturedUs;
        }
        return mjpegFrame.copy(bArr, l, l2);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final byte[] getBytes() {
        return this.bytes;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final Long getSequence() {
        return this.sequence;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final Long getCapturedUs() {
        return this.capturedUs;
    }

    public final MjpegFrame copy(byte[] bytes, Long sequence, Long capturedUs) {
        Intrinsics.checkNotNullParameter(bytes, "bytes");
        return new MjpegFrame(bytes, sequence, capturedUs);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return LiveLiterals$MjpegFrameKt.INSTANCE.m7019Boolean$branch$when$funequals$classMjpegFrame();
        }
        if (!(other instanceof MjpegFrame)) {
            return LiveLiterals$MjpegFrameKt.INSTANCE.m7020Boolean$branch$when1$funequals$classMjpegFrame();
        }
        MjpegFrame mjpegFrame = (MjpegFrame) other;
        if (!Intrinsics.areEqual(this.bytes, mjpegFrame.bytes)) {
            return LiveLiterals$MjpegFrameKt.INSTANCE.m7021Boolean$branch$when2$funequals$classMjpegFrame();
        }
        if (Intrinsics.areEqual(this.sequence, mjpegFrame.sequence)) {
            return !Intrinsics.areEqual(this.capturedUs, mjpegFrame.capturedUs) ? LiveLiterals$MjpegFrameKt.INSTANCE.m7023Boolean$branch$when4$funequals$classMjpegFrame() : LiveLiterals$MjpegFrameKt.INSTANCE.m7025Boolean$funequals$classMjpegFrame();
        }
        return LiveLiterals$MjpegFrameKt.INSTANCE.m7022Boolean$branch$when3$funequals$classMjpegFrame();
    }

    public int hashCode() {
        int iM7027Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classMjpegFrame = LiveLiterals$MjpegFrameKt.INSTANCE.m7027Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classMjpegFrame() * Arrays.hashCode(this.bytes);
        Long l = this.sequence;
        int iM7028Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classMjpegFrame = LiveLiterals$MjpegFrameKt.INSTANCE.m7028Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classMjpegFrame() * (iM7027Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classMjpegFrame + (l == null ? LiveLiterals$MjpegFrameKt.INSTANCE.m7029Int$branch$when$arg0$callplus$setresult$funhashCode$classMjpegFrame() : l.hashCode()));
        Long l2 = this.capturedUs;
        return iM7028Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classMjpegFrame + (l2 == null ? LiveLiterals$MjpegFrameKt.INSTANCE.m7030Int$branch$when$arg0$callplus$setresult1$funhashCode$classMjpegFrame() : l2.hashCode());
    }

    public String toString() {
        return LiveLiterals$MjpegFrameKt.INSTANCE.m7034String$0$str$funtoString$classMjpegFrame() + LiveLiterals$MjpegFrameKt.INSTANCE.m7035String$1$str$funtoString$classMjpegFrame() + Arrays.toString(this.bytes) + LiveLiterals$MjpegFrameKt.INSTANCE.m7036String$3$str$funtoString$classMjpegFrame() + LiveLiterals$MjpegFrameKt.INSTANCE.m7037String$4$str$funtoString$classMjpegFrame() + this.sequence + LiveLiterals$MjpegFrameKt.INSTANCE.m7038String$6$str$funtoString$classMjpegFrame() + LiveLiterals$MjpegFrameKt.INSTANCE.m7039String$7$str$funtoString$classMjpegFrame() + this.capturedUs + LiveLiterals$MjpegFrameKt.INSTANCE.m7040String$9$str$funtoString$classMjpegFrame();
    }

    public MjpegFrame(byte[] bytes, Long sequence, Long capturedUs) {
        Intrinsics.checkNotNullParameter(bytes, "bytes");
        this.bytes = bytes;
        this.sequence = sequence;
        this.capturedUs = capturedUs;
    }

    public final byte[] getBytes() {
        return this.bytes;
    }

    public final Long getCapturedUs() {
        return this.capturedUs;
    }

    public final Long getSequence() {
        return this.sequence;
    }
}
