package vea.raceremote.video;

import java.io.BufferedInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;
import kotlin.text.StringsKt;

/* JADX INFO: compiled from: MjpegReader.kt */
/* JADX INFO: loaded from: classes11.dex */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0012\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\b\u0010\t\u001a\u0004\u0018\u00010\nJ\b\u0010\u000b\u001a\u0004\u0018\u00010\fJ\n\u0010\r\u001a\u0004\u0018\u00010\u0005H\u0002J\u0019\u0010\u000e\u001a\u0004\u0018\u00010\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0005H\u0002¢\u0006\u0002\u0010\u0011J\u0019\u0010\u0012\u001a\u0004\u0018\u00010\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0005H\u0002¢\u0006\u0002\u0010\u0011R\u000e\u0010\u0007\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0013"}, d2 = {"Lvea/raceremote/video/MjpegReader;", "", "input", "Ljava/io/InputStream;", "contentType", "", "(Ljava/io/InputStream;Ljava/lang/String;)V", "delimiter", "Ljava/io/BufferedInputStream;", "nextFrame", "", "nextPart", "Lvea/raceremote/video/MjpegFrame;", "readLine", "sequence", "", "value", "(Ljava/lang/String;)Ljava/lang/Long;", "timestamp", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class MjpegReader {
    public static final int $stable = LiveLiterals$MjpegReaderKt.INSTANCE.m7067Int$classMjpegReader();
    private final String delimiter;
    private final BufferedInputStream input;

    public MjpegReader(InputStream input, String contentType) throws IOException {
        String strSubstringAfter;
        String string;
        String boundary;
        Intrinsics.checkNotNullParameter(input, "input");
        Intrinsics.checkNotNullParameter(contentType, "contentType");
        this.input = input instanceof BufferedInputStream ? (BufferedInputStream) input : new BufferedInputStream(input, 8192);
        Object obj = null;
        if (!StringsKt.equals(StringsKt.trim((CharSequence) StringsKt.substringBefore$default(contentType, LiveLiterals$MjpegReaderKt.INSTANCE.m7051Char$arg0$callsubstringBefore$$$this$calltrim$$$this$callequals$$this$callnot$cond$if$classMjpegReader(), (String) null, 2, (Object) null)).toString(), LiveLiterals$MjpegReaderKt.INSTANCE.m7097String$arg0$callequals$$this$callnot$cond$if$classMjpegReader(), LiveLiterals$MjpegReaderKt.INSTANCE.m7042Boolean$arg1$callequals$$this$callnot$cond$if$classMjpegReader())) {
            throw new IOException(LiveLiterals$MjpegReaderKt.INSTANCE.m7081String$arg0$call$init$$branch$if$classMjpegReader());
        }
        boolean z = true;
        Iterable $this$map$iv = CollectionsKt.drop(StringsKt.split$default((CharSequence) contentType, new char[]{LiveLiterals$MjpegReaderKt.INSTANCE.m7045Char$0$vararg$arg0$callsplit$$$this$calldrop$$$this$callmap$$$this$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader()}, false, 0, 6, (Object) null), LiveLiterals$MjpegReaderKt.INSTANCE.m7055Int$arg0$calldrop$$$this$callmap$$$this$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader());
        Collection destination$iv$iv = new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10));
        for (Object item$iv$iv : $this$map$iv) {
            String it = (String) item$iv$iv;
            destination$iv$iv.add(StringsKt.trim((CharSequence) it).toString());
        }
        Iterable $this$firstOrNull$iv = (List) destination$iv$iv;
        for (Object element$iv : $this$firstOrNull$iv) {
            String it2 = (String) element$iv;
            if (StringsKt.equals(StringsKt.substringBefore$default(it2, LiveLiterals$MjpegReaderKt.INSTANCE.m7049Char$arg0$callsubstringBefore$$$this$callequals$fun$anonymous$$arg0$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader(), (String) null, 2, (Object) null), LiveLiterals$MjpegReaderKt.INSTANCE.m7099String$arg0$callequals$fun$anonymous$$arg0$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader(), LiveLiterals$MjpegReaderKt.INSTANCE.m7044Boolean$arg1$callequals$fun$anonymous$$arg0$callfirstOrNull$valtmp0_safe_receiver$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader())) {
                obj = element$iv;
                break;
            }
        }
        String str = (String) obj;
        if (str == null || (strSubstringAfter = StringsKt.substringAfter(str, LiveLiterals$MjpegReaderKt.INSTANCE.m7048Char$arg0$callsubstringAfter$else$when$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader(), LiveLiterals$MjpegReaderKt.INSTANCE.m7106String$arg1$callsubstringAfter$else$when$valtmp1_safe_receiver$valtmp2_safe_receiver$valtmp3_elvis_lhs$valboundary$classMjpegReader())) == null || (string = StringsKt.trim((CharSequence) strSubstringAfter).toString()) == null || (boundary = StringsKt.removeSurrounding(string, (CharSequence) LiveLiterals$MjpegReaderKt.INSTANCE.m7105String$arg0$callremoveSurrounding$else$when$valtmp3_elvis_lhs$valboundary$classMjpegReader())) == null) {
            throw new IOException(LiveLiterals$MjpegReaderKt.INSTANCE.m7094String$arg0$call$init$$branch$when$valboundary$classMjpegReader());
        }
        if (!(boundary.length() == 0) && boundary.length() <= 70) {
            String $this$any$iv = boundary;
            int i = 0;
            while (true) {
                if (i >= $this$any$iv.length()) {
                    z = false;
                    break;
                }
                char element$iv2 = $this$any$iv.charAt(i);
                if (!(LiveLiterals$MjpegReaderKt.INSTANCE.m7053Int$$this$callrangeTo$$this$callcontains$$this$callnot$fun$anonymous$$arg0$callany$else$cond$if1$classMjpegReader() <= element$iv2 && element$iv2 <= LiveLiterals$MjpegReaderKt.INSTANCE.m7060Int$arg0$callrangeTo$$this$callcontains$$this$callnot$fun$anonymous$$arg0$callany$else$cond$if1$classMjpegReader())) {
                    break;
                } else {
                    i++;
                }
            }
            if (!z) {
                this.delimiter = LiveLiterals$MjpegReaderKt.INSTANCE.m7074String$0$str$setdelimiter$classMjpegReader() + boundary;
                return;
            }
        }
        throw new IOException(LiveLiterals$MjpegReaderKt.INSTANCE.m7082String$arg0$call$init$$branch$if1$classMjpegReader());
    }

    public final byte[] nextFrame() throws IOException {
        MjpegFrame mjpegFrameNextPart = nextPart();
        if (mjpegFrameNextPart != null) {
            return mjpegFrameNextPart.getBytes();
        }
        return null;
    }

    public final MjpegFrame nextPart() throws IOException {
        Integer intOrNull;
        String name;
        String strSubstring;
        String line = readLine();
        if (line == null) {
            return null;
        }
        int emptyLines = LiveLiterals$MjpegReaderKt.INSTANCE.m7068Int$valemptyLines$funnextPart$classMjpegReader();
        while (true) {
            if (!(line.length() == 0)) {
                break;
            }
            int emptyLines2 = emptyLines + 1;
            if (emptyLines >= 2) {
                break;
            }
            String line2 = readLine();
            if (line2 == null) {
                throw new EOFException();
            }
            line = line2;
            emptyLines = emptyLines2;
        }
        if (Intrinsics.areEqual(line, this.delimiter + LiveLiterals$MjpegReaderKt.INSTANCE.m7075String$1$str$arg1$callEQEQ$cond$if$funnextPart$classMjpegReader())) {
            return null;
        }
        if (!Intrinsics.areEqual(line, this.delimiter)) {
            throw new IOException(LiveLiterals$MjpegReaderKt.INSTANCE.m7083String$arg0$call$init$$branch$if1$funnextPart$classMjpegReader());
        }
        Map headers = new LinkedHashMap();
        int headerBytes = LiveLiterals$MjpegReaderKt.INSTANCE.m7069Int$valheaderBytes$funnextPart$classMjpegReader();
        do {
            String line3 = readLine();
            if (line3 == null) {
                throw new EOFException(LiveLiterals$MjpegReaderKt.INSTANCE.m7093String$arg0$call$init$$branch$when$setline$body$loop1$funnextPart$classMjpegReader());
            }
            headerBytes += line3.length() + LiveLiterals$MjpegReaderKt.INSTANCE.m7057Int$arg0$callplus$arg0$callplus$setheaderBytes$body$loop1$funnextPart$classMjpegReader();
            if (headerBytes > LiveLiterals$MjpegReaderKt.INSTANCE.m7063Int$arg1$callgreater$cond$if$body$loop1$funnextPart$classMjpegReader()) {
                throw new IOException(LiveLiterals$MjpegReaderKt.INSTANCE.m7079String$arg0$call$init$$branch$if$body$loop1$funnextPart$classMjpegReader());
            }
            if (!(line3.length() == 0)) {
                int colon = StringsKt.indexOf$default((CharSequence) line3, LiveLiterals$MjpegReaderKt.INSTANCE.m7046Char$arg0$callindexOf$valcolon$body$loop1$funnextPart$classMjpegReader(), 0, false, 6, (Object) null);
                if (colon < LiveLiterals$MjpegReaderKt.INSTANCE.m7066Int$arg1$callless$cond$if2$body$loop1$funnextPart$classMjpegReader()) {
                    throw new IOException(LiveLiterals$MjpegReaderKt.INSTANCE.m7086String$arg0$call$init$$branch$if2$body$loop1$funnextPart$classMjpegReader());
                }
                String strSubstring2 = line3.substring(LiveLiterals$MjpegReaderKt.INSTANCE.m7061Int$arg0$callsubstring$$$this$calltrim$$$this$calllowercase$valname$body$loop1$funnextPart$classMjpegReader(), colon);
                Intrinsics.checkNotNullExpressionValue(strSubstring2, "this as java.lang.String…ing(startIndex, endIndex)");
                String string = StringsKt.trim((CharSequence) strSubstring2).toString();
                Locale locale = Locale.ROOT;
                Intrinsics.checkNotNullExpressionValue(locale, "ROOT");
                name = string.toLowerCase(locale);
                Intrinsics.checkNotNullExpressionValue(name, "this as java.lang.String).toLowerCase(locale)");
                strSubstring = line3.substring(LiveLiterals$MjpegReaderKt.INSTANCE.m7058Int$arg0$callplus$arg0$callsubstring$$$this$calltrim$arg1$callput$arg0$callEQEQ$$this$callnot$cond$if3$body$loop1$funnextPart$classMjpegReader() + colon);
                Intrinsics.checkNotNullExpressionValue(strSubstring, "this as java.lang.String).substring(startIndex)");
            } else {
                if (!StringsKt.equals((String) headers.get(LiveLiterals$MjpegReaderKt.INSTANCE.m7100String$arg0$callget$$$this$callequals$$this$callnot$cond$if2$funnextPart$classMjpegReader()), LiveLiterals$MjpegReaderKt.INSTANCE.m7098String$arg0$callequals$$this$callnot$cond$if2$funnextPart$classMjpegReader(), LiveLiterals$MjpegReaderKt.INSTANCE.m7043Boolean$arg1$callequals$$this$callnot$cond$if2$funnextPart$classMjpegReader())) {
                    throw new IOException(LiveLiterals$MjpegReaderKt.INSTANCE.m7087String$arg0$call$init$$branch$if2$funnextPart$classMjpegReader());
                }
                String str = (String) headers.get(LiveLiterals$MjpegReaderKt.INSTANCE.m7103String$arg0$callget$valtmp4_safe_receiver$valtmp5_elvis_lhs$vallength$funnextPart$classMjpegReader());
                if (str == null || (intOrNull = StringsKt.toIntOrNull(str)) == null) {
                    throw new IOException(LiveLiterals$MjpegReaderKt.INSTANCE.m7095String$arg0$call$init$$branch$when$vallength$funnextPart$classMjpegReader());
                }
                int length = intOrNull.intValue();
                if (!(length <= LiveLiterals$MjpegReaderKt.INSTANCE.m7059Int$arg0$callrangeTo$$this$callcontains$$this$callnot$cond$if3$funnextPart$classMjpegReader() && LiveLiterals$MjpegReaderKt.INSTANCE.m7052Int$$this$callrangeTo$$this$callcontains$$this$callnot$cond$if3$funnextPart$classMjpegReader() <= length)) {
                    throw new IOException(LiveLiterals$MjpegReaderKt.INSTANCE.m7090String$arg0$call$init$$branch$if3$funnextPart$classMjpegReader());
                }
                byte[] bytes = new byte[length];
                int offset = LiveLiterals$MjpegReaderKt.INSTANCE.m7070Int$valoffset$funnextPart$classMjpegReader();
                while (offset < length) {
                    int count = this.input.read(bytes, offset, length - offset);
                    if (count < LiveLiterals$MjpegReaderKt.INSTANCE.m7065Int$arg1$callless$cond$if$body$loop2$funnextPart$classMjpegReader()) {
                        throw new EOFException(LiveLiterals$MjpegReaderKt.INSTANCE.m7080String$arg0$call$init$$branch$if$body$loop2$funnextPart$classMjpegReader());
                    }
                    offset += count;
                }
                if (bytes[0] != -1 || bytes[1] != -40 || bytes[length - 2] != -1 || bytes[length - LiveLiterals$MjpegReaderKt.INSTANCE.m7056Int$arg0$callminus$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if4$funnextPart$classMjpegReader()] != ((byte) LiveLiterals$MjpegReaderKt.INSTANCE.m7054Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if4$funnextPart$classMjpegReader())) {
                    throw new IOException(LiveLiterals$MjpegReaderKt.INSTANCE.m7091String$arg0$call$init$$branch$if4$funnextPart$classMjpegReader());
                }
                return new MjpegFrame(bytes, sequence((String) headers.get(LiveLiterals$MjpegReaderKt.INSTANCE.m7101String$arg0$callget$arg0$callsequence$arg1$call$init$$funnextPart$classMjpegReader())), timestamp((String) headers.get(LiveLiterals$MjpegReaderKt.INSTANCE.m7102String$arg0$callget$arg0$calltimestamp$arg2$call$init$$funnextPart$classMjpegReader())));
            }
        } while (headers.put(name, StringsKt.trim((CharSequence) strSubstring).toString()) == null);
        throw new IOException(LiveLiterals$MjpegReaderKt.INSTANCE.m7089String$arg0$call$init$$branch$if3$body$loop1$funnextPart$classMjpegReader());
    }

    private final Long sequence(String value) throws IOException {
        if (value == null) {
            return null;
        }
        if (!new Regex(LiveLiterals$MjpegReaderKt.INSTANCE.m7076String$arg0$call$init$$arg0$callmatches$$this$callnot$cond$if1$funsequence$classMjpegReader()).matches(value)) {
            throw new IOException(LiveLiterals$MjpegReaderKt.INSTANCE.m7084String$arg0$call$init$$branch$if1$funsequence$classMjpegReader());
        }
        Long longOrNull = StringsKt.toLongOrNull(value);
        if (longOrNull != null) {
            long it = longOrNull.longValue();
            Long l = (it > LiveLiterals$MjpegReaderKt.INSTANCE.m7073Long$arg1$calllessOrEqual$fun$anonymous$$arg0$calltakeIf$else$when$valtmp1_elvis_lhs$funsequence$classMjpegReader() ? 1 : (it == LiveLiterals$MjpegReaderKt.INSTANCE.m7073Long$arg1$calllessOrEqual$fun$anonymous$$arg0$calltakeIf$else$when$valtmp1_elvis_lhs$funsequence$classMjpegReader() ? 0 : -1)) <= 0 ? longOrNull : null;
            if (l != null) {
                return l;
            }
        }
        throw new IOException(LiveLiterals$MjpegReaderKt.INSTANCE.m7092String$arg0$call$init$$branch$when$funsequence$classMjpegReader());
    }

    private final Long timestamp(String value) throws IOException {
        if (value == null) {
            return null;
        }
        if (new Regex(LiveLiterals$MjpegReaderKt.INSTANCE.m7077String$arg0$call$init$$arg0$callmatches$$this$callnot$cond$if1$funtimestamp$classMjpegReader()).matches(value)) {
            long seconds = Long.parseLong(StringsKt.substringBefore$default(value, LiveLiterals$MjpegReaderKt.INSTANCE.m7050Char$arg0$callsubstringBefore$$$this$calltoLong$valseconds$funtimestamp$classMjpegReader(), (String) null, 2, (Object) null));
            if (seconds <= LiveLiterals$MjpegReaderKt.INSTANCE.m7072Long$arg1$callgreater$cond$if2$funtimestamp$classMjpegReader()) {
                return Long.valueOf((LiveLiterals$MjpegReaderKt.INSTANCE.m7071Long$arg0$calltimes$$this$callplus$funtimestamp$classMjpegReader() * seconds) + Long.parseLong(StringsKt.substringAfter$default(value, LiveLiterals$MjpegReaderKt.INSTANCE.m7047Char$arg0$callsubstringAfter$$$this$calltoLong$arg0$callplus$funtimestamp$classMjpegReader(), (String) null, 2, (Object) null)));
            }
            throw new IOException(LiveLiterals$MjpegReaderKt.INSTANCE.m7088String$arg0$call$init$$branch$if2$funtimestamp$classMjpegReader());
        }
        throw new IOException(LiveLiterals$MjpegReaderKt.INSTANCE.m7085String$arg0$call$init$$branch$if1$funtimestamp$classMjpegReader());
    }

    private final String readLine() throws IOException {
        StringBuilder line = new StringBuilder();
        while (line.length() <= 4096) {
            int i = this.input.read();
            if (i < LiveLiterals$MjpegReaderKt.INSTANCE.m7064Int$arg1$callless$cond$if$body$loop$funreadLine$classMjpegReader()) {
                if (line.length() == 0) {
                    return null;
                }
                throw new EOFException(LiveLiterals$MjpegReaderKt.INSTANCE.m7078String$arg0$call$init$$branch$if$body$loop$funreadLine$classMjpegReader());
            }
            if (i == LiveLiterals$MjpegReaderKt.INSTANCE.m7062Int$arg1$callEQEQ$cond$if1$body$loop$funreadLine$classMjpegReader()) {
                String string = line.toString();
                Intrinsics.checkNotNullExpressionValue(string, "line.toString()");
                return StringsKt.removeSuffix(string, (CharSequence) LiveLiterals$MjpegReaderKt.INSTANCE.m7104String$arg0$callremoveSuffix$branch$if1$body$loop$funreadLine$classMjpegReader());
            }
            line.append((char) i);
        }
        throw new IOException(LiveLiterals$MjpegReaderKt.INSTANCE.m7096String$arg0$call$init$$funreadLine$classMjpegReader());
    }
}
