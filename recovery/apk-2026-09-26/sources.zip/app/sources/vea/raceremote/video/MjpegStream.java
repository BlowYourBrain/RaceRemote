package vea.raceremote.video;

import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.io.CloseableKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.Call;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

/* JADX INFO: compiled from: MjpegStream.kt */
/* JADX INFO: loaded from: classes11.dex */
@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0012\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B-\u0012\u0012\u0010\u0002\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00050\u0003\u0012\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00050\u0003¢\u0006\u0002\u0010\bJ\u0006\u0010\u0010\u001a\u00020\u0005J\u0016\u0010\u0011\u001a\u00020\u00052\u0006\u0010\u0012\u001a\u00020\u00072\u0006\u0010\u0013\u001a\u00020\u0014R\u0010\u0010\t\u001a\u0004\u0018\u00010\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00050\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0002\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00050\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\r\u001a\n \u000f*\u0004\u0018\u00010\u000e0\u000eX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0015"}, d2 = {"Lvea/raceremote/video/MjpegStream;", "", "onFrame", "Lkotlin/Function1;", "", "", "onEnd", "", "(Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V", "call", "Lokhttp3/Call;", "closed", "", "worker", "Ljava/util/concurrent/ExecutorService;", "kotlin.jvm.PlatformType", "close", "start", "url", "http", "Lokhttp3/OkHttpClient;", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class MjpegStream {
    public static final int $stable = LiveLiterals$MjpegStreamKt.INSTANCE.m7111Int$classMjpegStream();
    private Call call;
    private volatile boolean closed;
    private final Function1<String, Unit> onEnd;
    private final Function1<byte[], Unit> onFrame;
    private final ExecutorService worker;

    /* JADX WARN: Multi-variable type inference failed */
    public MjpegStream(Function1<? super byte[], Unit> function1, Function1<? super String, Unit> function2) {
        Intrinsics.checkNotNullParameter(function1, "onFrame");
        Intrinsics.checkNotNullParameter(function2, "onEnd");
        this.onFrame = function1;
        this.onEnd = function2;
        this.worker = Executors.newSingleThreadExecutor();
    }

    public final synchronized void start(String url, OkHttpClient http) {
        Intrinsics.checkNotNullParameter(url, "url");
        Intrinsics.checkNotNullParameter(http, "http");
        boolean z = true;
        if (!(this.call == null && !this.closed)) {
            throw new IllegalStateException(LiveLiterals$MjpegStreamKt.INSTANCE.m7123String$fun$anonymous$$arg1$callcheck$funstart$classMjpegStream().toString());
        }
        HttpUrl parsed = HttpUrl.parse(url);
        if (parsed != null && CollectionsKt.listOf((Object[]) new String[]{"http", "https"}).contains(parsed.scheme())) {
            String strUsername = parsed.username();
            Intrinsics.checkNotNullExpressionValue(strUsername, "parsed.username()");
            if (!(strUsername.length() > 0)) {
                String strPassword = parsed.password();
                Intrinsics.checkNotNullExpressionValue(strPassword, "parsed.password()");
                if (strPassword.length() <= 0) {
                    z = false;
                }
                if (!z) {
                    OkHttpClient transport = http.newBuilder().connectTimeout(LiveLiterals$MjpegStreamKt.INSTANCE.m7112Long$arg0$callconnectTimeout$$this$callreadTimeout$$this$callretryOnConnectionFailure$$this$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream(), TimeUnit.SECONDS).readTimeout(LiveLiterals$MjpegStreamKt.INSTANCE.m7113Long$arg0$callreadTimeout$$this$callretryOnConnectionFailure$$this$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream(), TimeUnit.MILLISECONDS).retryOnConnectionFailure(LiveLiterals$MjpegStreamKt.INSTANCE.m7110Boolean$arg0$callretryOnConnectionFailure$$this$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream()).followRedirects(LiveLiterals$MjpegStreamKt.INSTANCE.m7108Boolean$arg0$callfollowRedirects$$this$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream()).followSslRedirects(LiveLiterals$MjpegStreamKt.INSTANCE.m7109Boolean$arg0$callfollowSslRedirects$$this$callbuild$valtransport$funstart$classMjpegStream()).build();
                    final Call request = transport.newCall(new Request.Builder().url(parsed).header(LiveLiterals$MjpegStreamKt.INSTANCE.m7117String$arg0$callheader$$this$callbuild$arg0$callnewCall$valrequest$funstart$classMjpegStream(), LiveLiterals$MjpegStreamKt.INSTANCE.m7121String$arg1$callheader$$this$callbuild$arg0$callnewCall$valrequest$funstart$classMjpegStream()).build());
                    this.call = request;
                    this.worker.execute(new Runnable() { // from class: vea.raceremote.video.MjpegStream$$ExternalSyntheticLambda0
                        @Override // java.lang.Runnable
                        public final void run() {
                            MjpegStream.start$lambda$2(request, this);
                        }
                    });
                    return;
                }
            }
        }
        invoke(LiveLiterals$MjpegStreamKt.INSTANCE.m7119String$arg0$callinvoke$branch$if$funstart$classMjpegStream());
        close();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void start$lambda$2(Call $request, MjpegStream this$0) {
        MjpegFrame frame;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        try {
            try {
                Response responseExecute = $request.execute();
                try {
                    Response response = responseExecute;
                    if (!response.isSuccessful()) {
                        throw new IOException(LiveLiterals$MjpegStreamKt.INSTANCE.m7114String$0$str$arg0$call$init$$branch$if$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream() + response.code());
                    }
                    ResponseBody body = response.body();
                    if (body == null) {
                        throw new IOException(LiveLiterals$MjpegStreamKt.INSTANCE.m7116String$arg0$call$init$$branch$when$valbody$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream());
                    }
                    Intrinsics.checkNotNullExpressionValue(body, "response.body() ?: throw…n(\"Empty video response\")");
                    InputStream inputStreamByteStream = body.byteStream();
                    Intrinsics.checkNotNullExpressionValue(inputStreamByteStream, "body.byteStream()");
                    String strHeader = response.header(LiveLiterals$MjpegStreamKt.INSTANCE.m7118String$arg0$callheader$valtmp1_elvis_lhs$arg1$call$init$$valreader$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream());
                    if (strHeader == null) {
                        strHeader = LiveLiterals$MjpegStreamKt.INSTANCE.m7122String$branch$when$arg1$call$init$$valreader$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream();
                    }
                    Intrinsics.checkNotNullExpressionValue(strHeader, "response.header(\"Content-Type\") ?: \"\"");
                    MjpegReader reader = new MjpegReader(inputStreamByteStream, strHeader);
                    FrameFreshness freshness = new FrameFreshness();
                    while (!this$0.closed && (frame = reader.nextPart()) != null) {
                        if (!this$0.closed && freshness.accept(frame)) {
                            this$0.onFrame.invoke(frame.getBytes());
                        }
                    }
                    Unit unit = Unit.INSTANCE;
                    CloseableKt.closeFinally(responseExecute, null);
                    if (!this$0.closed) {
                        this$0.onEnd.invoke(LiveLiterals$MjpegStreamKt.INSTANCE.m7120String$arg0$callinvoke$branch$if$try$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream());
                    }
                    this$0.close();
                } catch (Throwable th) {
                    try {
                        throw th;
                    } catch (Throwable th2) {
                        CloseableKt.closeFinally(responseExecute, th);
                        throw th2;
                    }
                }
            } catch (Exception error) {
                if (!this$0.closed) {
                    Function1<String, Unit> function1 = this$0.onEnd;
                    StringBuilder sbAppend = new StringBuilder().append(LiveLiterals$MjpegStreamKt.INSTANCE.m7115String$0$str$arg0$callinvoke$branch$if$catch$fun$anonymous$$arg0$callexecute$funstart$classMjpegStream());
                    String message = error.getMessage();
                    if (message == null) {
                        message = error.getClass().getSimpleName();
                    }
                    function1.invoke(sbAppend.append(message).toString());
                }
            }
        } catch (Throwable th3) {
            this$0.close();
            throw th3;
        }
    }

    public final synchronized void close() {
        this.closed = LiveLiterals$MjpegStreamKt.INSTANCE.m7107Boolean$arg0$call$setclosed$$funclose$classMjpegStream();
        Call call = this.call;
        if (call != null) {
            call.cancel();
        }
        this.worker.shutdownNow();
    }
}
