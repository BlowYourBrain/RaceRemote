package vea.raceremote.video;

import android.os.SystemClock;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;

/* JADX INFO: compiled from: MjpegVideoView.kt */
/* JADX INFO: loaded from: classes11.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0012\n\u0000\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n¢\u0006\u0002\b\u0004"}, d2 = {"<anonymous>", "", "bytes", "", "invoke"}, k = 3, mv = {1, 8, 0}, xi = 48)
final class MjpegVideoView$start$1$1 extends Lambda implements Function1<byte[], Unit> {
    final /* synthetic */ long $current;
    final /* synthetic */ MjpegVideoView this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    MjpegVideoView$start$1$1(MjpegVideoView mjpegVideoView, long j) {
        super(1);
        this.this$0 = mjpegVideoView;
        this.$current = j;
    }

    @Override // kotlin.jvm.functions.Function1
    public /* bridge */ /* synthetic */ Unit invoke(byte[] bArr) {
        invoke2(bArr);
        return Unit.INSTANCE;
    }

    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
    public final void invoke2(byte[] bytes) {
        Intrinsics.checkNotNullParameter(bytes, "bytes");
        Object obj = this.this$0.gate;
        long j = this.$current;
        final MjpegVideoView mjpegVideoView = this.this$0;
        synchronized (obj) {
            if (j == mjpegVideoView.generation && !mjpegVideoView.disposed) {
                mjpegVideoView.lastReceivedAt = SystemClock.elapsedRealtime();
                mjpegVideoView.receivedFrames++;
                mjpegVideoView.pending = new MjpegVideoView.Encoded(bytes, j, mjpegVideoView.lastReceivedAt);
                if (!mjpegVideoView.decoding) {
                    mjpegVideoView.decoding = LiveLiterals$MjpegVideoViewKt.INSTANCE.m7124Boolean$arg0$call$setdecoding$$branch$if$branch$if$fun$anonymous$$arg1$callsynchronized$fun$anonymous$$arg0$call$init$$arg0$call$setstream$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView();
                    mjpegVideoView.decoder.execute(new Runnable() { // from class: vea.raceremote.video.MjpegVideoView$start$1$1$$ExternalSyntheticLambda0
                        @Override // java.lang.Runnable
                        public final void run() {
                            MjpegVideoView$start$1$1.invoke$lambda$1$lambda$0(mjpegVideoView);
                        }
                    });
                }
            }
            Unit unit = Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void invoke$lambda$1$lambda$0(MjpegVideoView this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.decodeLatest();
    }
}
