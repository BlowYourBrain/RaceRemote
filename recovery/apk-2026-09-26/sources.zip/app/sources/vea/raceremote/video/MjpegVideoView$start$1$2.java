package vea.raceremote.video;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;

/* JADX INFO: compiled from: MjpegVideoView.kt */
/* JADX INFO: loaded from: classes11.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n¢\u0006\u0002\b\u0004"}, d2 = {"<anonymous>", "", "message", "", "invoke"}, k = 3, mv = {1, 8, 0}, xi = 48)
final class MjpegVideoView$start$1$2 extends Lambda implements Function1<String, Unit> {
    final /* synthetic */ long $current;
    final /* synthetic */ MjpegVideoView this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    MjpegVideoView$start$1$2(MjpegVideoView mjpegVideoView, long j) {
        super(1);
        this.this$0 = mjpegVideoView;
        this.$current = j;
    }

    @Override // kotlin.jvm.functions.Function1
    public /* bridge */ /* synthetic */ Unit invoke(String str) {
        invoke2(str);
        return Unit.INSTANCE;
    }

    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
    public final void invoke2(final String message) {
        Intrinsics.checkNotNullParameter(message, "message");
        final MjpegVideoView mjpegVideoView = this.this$0;
        final long j = this.$current;
        mjpegVideoView.post(new Runnable() { // from class: vea.raceremote.video.MjpegVideoView$start$1$2$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                MjpegVideoView$start$1$2.invoke$lambda$1(mjpegVideoView, j, message);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void invoke$lambda$1(MjpegVideoView this$0, long $current, String $message) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter($message, "$message");
        synchronized (this$0.gate) {
            if ($current == this$0.generation) {
                this$0.stop($message);
            }
            Unit unit = Unit.INSTANCE;
        }
    }
}
