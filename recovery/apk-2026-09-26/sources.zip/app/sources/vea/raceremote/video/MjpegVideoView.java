package vea.raceremote.video;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.OkHttpClient;

/* JADX INFO: compiled from: MjpegVideoView.kt */
/* JADX INFO: loaded from: classes11.dex */
@Metadata(d1 = {"\u0000y\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005*\u0001\u0016\b\u0007\u0018\u00002\u00020\u0001:\u000278B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0006\u0010,\u001a\u00020\u001eJ\b\u0010-\u001a\u00020\u001eH\u0002J\u0010\u0010.\u001a\u00020\u001e2\u0006\u0010/\u001a\u000200H\u0014J\u0016\u00101\u001a\u00020\u001e2\u0006\u00102\u001a\u00020\u001d2\u0006\u00103\u001a\u000204J\u0010\u00105\u001a\u00020\u001e2\b\b\u0002\u00106\u001a\u00020\u001dR\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0016\u0010\t\u001a\n \u000b*\u0004\u0018\u00010\n0\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0015\u001a\u00020\u0016X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0017R\u000e\u0010\u0018\u001a\u00020\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0019\u001a\u0004\u0018\u00010\u001aX\u0082\u000e¢\u0006\u0002\n\u0000R,\u0010\u001b\u001a\u0014\u0012\u0004\u0012\u00020\u001d\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u001e0\u001cX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001f\u0010 \"\u0004\b!\u0010\"R\u000e\u0010#\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010$\u001a\u0004\u0018\u00010%X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010(\u001a\u00020\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010*\u001a\u0004\u0018\u00010+X\u0082\u000e¢\u0006\u0002\n\u0000¨\u00069"}, d2 = {"Lvea/raceremote/video/MjpegVideoView;", "Landroid/view/View;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "background", "Landroid/graphics/Paint;", "decodedFrames", "", "decoder", "Ljava/util/concurrent/ExecutorService;", "kotlin.jvm.PlatformType", "decoding", "", "disposed", "drawnFrames", "drawnSequence", "", "gate", "", "generation", "heartbeat", "vea/raceremote/video/MjpegVideoView$heartbeat$1", "Lvea/raceremote/video/MjpegVideoView$heartbeat$1;", "lastReceivedAt", "latest", "Lvea/raceremote/video/MjpegVideoView$Decoded;", "onStatus", "Lkotlin/Function2;", "", "", "getOnStatus", "()Lkotlin/jvm/functions/Function2;", "setOnStatus", "(Lkotlin/jvm/functions/Function2;)V", "paint", "pending", "Lvea/raceremote/video/MjpegVideoView$Encoded;", "receivedFrames", "sequence", "startedAt", "statsAt", "stream", "Lvea/raceremote/video/MjpegStream;", "close", "decodeLatest", "onDraw", "canvas", "Landroid/graphics/Canvas;", "start", "url", "http", "Lokhttp3/OkHttpClient;", "stop", "message", "Decoded", "Encoded", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class MjpegVideoView extends View {
    public static final int $stable = LiveLiterals$MjpegVideoViewKt.INSTANCE.m7163Int$classMjpegVideoView();
    private final Paint background;
    private int decodedFrames;
    private final ExecutorService decoder;
    private boolean decoding;
    private boolean disposed;
    private int drawnFrames;
    private long drawnSequence;
    private final Object gate;
    private long generation;
    private final MjpegVideoView$heartbeat$1 heartbeat;
    private long lastReceivedAt;
    private Decoded latest;
    private Function2<? super String, ? super Boolean, Unit> onStatus;
    private final Paint paint;
    private Encoded pending;
    private int receivedFrames;
    private long sequence;
    private long startedAt;
    private long statsAt;
    private MjpegStream stream;

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: MjpegVideoView.kt */
    @Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\t\n\u0002\b\f\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0082\b\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005¢\u0006\u0002\u0010\u0007J\t\u0010\r\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000e\u001a\u00020\u0005HÆ\u0003J\t\u0010\u000f\u001a\u00020\u0005HÆ\u0003J'\u0010\u0010\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u0011\u001a\u00020\u00122\b\u0010\u0013\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0014\u001a\u00020\u0015HÖ\u0001J\t\u0010\u0016\u001a\u00020\u0017HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u000b¨\u0006\u0018"}, d2 = {"Lvea/raceremote/video/MjpegVideoView$Encoded;", "", "bytes", "", "generation", "", "receivedMs", "([BJJ)V", "getBytes", "()[B", "getGeneration", "()J", "getReceivedMs", "component1", "component2", "component3", "copy", "equals", "", "other", "hashCode", "", "toString", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
    static final /* data */ class Encoded {
        private final byte[] bytes;
        private final long generation;
        private final long receivedMs;

        public static /* synthetic */ Encoded copy$default(Encoded encoded, byte[] bArr, long j, long j2, int i, Object obj) {
            if ((i & 1) != 0) {
                bArr = encoded.bytes;
            }
            if ((i & 2) != 0) {
                j = encoded.generation;
            }
            long j3 = j;
            if ((i & 4) != 0) {
                j2 = encoded.receivedMs;
            }
            return encoded.copy(bArr, j3, j2);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final byte[] getBytes() {
            return this.bytes;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final long getGeneration() {
            return this.generation;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final long getReceivedMs() {
            return this.receivedMs;
        }

        public final Encoded copy(byte[] bytes, long generation, long receivedMs) {
            Intrinsics.checkNotNullParameter(bytes, "bytes");
            return new Encoded(bytes, generation, receivedMs);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return LiveLiterals$MjpegVideoViewKt.INSTANCE.m7130Boolean$branch$when$funequals$classEncoded$classMjpegVideoView();
            }
            if (!(other instanceof Encoded)) {
                return LiveLiterals$MjpegVideoViewKt.INSTANCE.m7132Boolean$branch$when1$funequals$classEncoded$classMjpegVideoView();
            }
            Encoded encoded = (Encoded) other;
            if (!Intrinsics.areEqual(this.bytes, encoded.bytes)) {
                return LiveLiterals$MjpegVideoViewKt.INSTANCE.m7134Boolean$branch$when2$funequals$classEncoded$classMjpegVideoView();
            }
            if (this.generation != encoded.generation) {
                return LiveLiterals$MjpegVideoViewKt.INSTANCE.m7136Boolean$branch$when3$funequals$classEncoded$classMjpegVideoView();
            }
            return this.receivedMs != encoded.receivedMs ? LiveLiterals$MjpegVideoViewKt.INSTANCE.m7138Boolean$branch$when4$funequals$classEncoded$classMjpegVideoView() : LiveLiterals$MjpegVideoViewKt.INSTANCE.m7140Boolean$funequals$classEncoded$classMjpegVideoView();
        }

        public int hashCode() {
            return (LiveLiterals$MjpegVideoViewKt.INSTANCE.m7160Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classEncoded$classMjpegVideoView() * ((LiveLiterals$MjpegVideoViewKt.INSTANCE.m7158Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classEncoded$classMjpegVideoView() * Arrays.hashCode(this.bytes)) + Long.hashCode(this.generation))) + Long.hashCode(this.receivedMs);
        }

        public String toString() {
            return LiveLiterals$MjpegVideoViewKt.INSTANCE.m7168String$0$str$funtoString$classEncoded$classMjpegVideoView() + LiveLiterals$MjpegVideoViewKt.INSTANCE.m7170String$1$str$funtoString$classEncoded$classMjpegVideoView() + Arrays.toString(this.bytes) + LiveLiterals$MjpegVideoViewKt.INSTANCE.m7172String$3$str$funtoString$classEncoded$classMjpegVideoView() + LiveLiterals$MjpegVideoViewKt.INSTANCE.m7174String$4$str$funtoString$classEncoded$classMjpegVideoView() + this.generation + LiveLiterals$MjpegVideoViewKt.INSTANCE.m7176String$6$str$funtoString$classEncoded$classMjpegVideoView() + LiveLiterals$MjpegVideoViewKt.INSTANCE.m7178String$7$str$funtoString$classEncoded$classMjpegVideoView() + this.receivedMs + LiveLiterals$MjpegVideoViewKt.INSTANCE.m7180String$9$str$funtoString$classEncoded$classMjpegVideoView();
        }

        public Encoded(byte[] bytes, long generation, long receivedMs) {
            Intrinsics.checkNotNullParameter(bytes, "bytes");
            this.bytes = bytes;
            this.generation = generation;
            this.receivedMs = receivedMs;
        }

        public final byte[] getBytes() {
            return this.bytes;
        }

        public final long getGeneration() {
            return this.generation;
        }

        public final long getReceivedMs() {
            return this.receivedMs;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Type inference failed for: r0v8, types: [vea.raceremote.video.MjpegVideoView$heartbeat$1] */
    public MjpegVideoView(Context context) {
        super(context);
        Intrinsics.checkNotNullParameter(context, "context");
        this.gate = new Object();
        this.decoder = Executors.newSingleThreadExecutor();
        this.paint = new Paint(2);
        Paint $this$background_u24lambda_u240 = new Paint();
        $this$background_u24lambda_u240.setColor(-16777216);
        this.background = $this$background_u24lambda_u240;
        this.drawnSequence = -1L;
        this.onStatus = new Function2<String, Boolean, Unit>() { // from class: vea.raceremote.video.MjpegVideoView$onStatus$1
            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(String str, Boolean bool) {
                invoke(str, bool.booleanValue());
                return Unit.INSTANCE;
            }

            public final void invoke(String str, boolean z) {
                Intrinsics.checkNotNullParameter(str, "<anonymous parameter 0>");
            }
        };
        this.heartbeat = new Runnable() { // from class: vea.raceremote.video.MjpegVideoView$heartbeat$1
            @Override // java.lang.Runnable
            public void run() {
                long j;
                int i;
                long now = SystemClock.elapsedRealtime();
                Object obj = this.this$0.gate;
                MjpegVideoView mjpegVideoView = this.this$0;
                synchronized (obj) {
                    if (mjpegVideoView.stream == null) {
                        return;
                    }
                    if (mjpegVideoView.lastReceivedAt == 0) {
                        j = mjpegVideoView.startedAt;
                        i = 4000;
                    } else {
                        j = mjpegVideoView.lastReceivedAt;
                        i = 1500;
                    }
                    long deadline = j + ((long) i);
                    if (now < deadline) {
                        if (now - mjpegVideoView.statsAt >= 1000) {
                            double seconds = (now - mjpegVideoView.statsAt) / 1000.0d;
                            String message = String.format("Принято %.1f · отрисовано %.1f кадр/с", Arrays.copyOf(new Object[]{Double.valueOf(((double) mjpegVideoView.receivedFrames) / seconds), Double.valueOf(((double) mjpegVideoView.drawnFrames) / seconds)}, 2));
                            Intrinsics.checkNotNullExpressionValue(message, "format(this, *args)");
                            mjpegVideoView.getOnStatus().invoke(message, true);
                            Log.d("RaceRemoteVideo", "fps accepted=" + (((double) mjpegVideoView.receivedFrames) / seconds) + " decoded=" + (((double) mjpegVideoView.decodedFrames) / seconds) + " drawn=" + (((double) mjpegVideoView.drawnFrames) / seconds));
                            mjpegVideoView.drawnFrames = 0;
                            mjpegVideoView.receivedFrames = 0;
                            mjpegVideoView.decodedFrames = 0;
                            mjpegVideoView.statsAt = now;
                        }
                        Unit unit = Unit.INSTANCE;
                        this.this$0.postDelayed(this, 250L);
                        return;
                    }
                    mjpegVideoView.stop("Нет свежего видео");
                }
            }
        };
    }

    /* JADX INFO: compiled from: MjpegVideoView.kt */
    @Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\f\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0082\b\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005¢\u0006\u0002\u0010\u0007J\t\u0010\r\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000e\u001a\u00020\u0005HÆ\u0003J\t\u0010\u000f\u001a\u00020\u0005HÆ\u0003J'\u0010\u0010\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u0011\u001a\u00020\u00122\b\u0010\u0013\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0014\u001a\u00020\u0015HÖ\u0001J\t\u0010\u0016\u001a\u00020\u0017HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u000b¨\u0006\u0018"}, d2 = {"Lvea/raceremote/video/MjpegVideoView$Decoded;", "", "bitmap", "Landroid/graphics/Bitmap;", "sequence", "", "receivedMs", "(Landroid/graphics/Bitmap;JJ)V", "getBitmap", "()Landroid/graphics/Bitmap;", "getReceivedMs", "()J", "getSequence", "component1", "component2", "component3", "copy", "equals", "", "other", "hashCode", "", "toString", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
    private static final /* data */ class Decoded {
        private final Bitmap bitmap;
        private final long receivedMs;
        private final long sequence;

        public static /* synthetic */ Decoded copy$default(Decoded decoded, Bitmap bitmap, long j, long j2, int i, Object obj) {
            if ((i & 1) != 0) {
                bitmap = decoded.bitmap;
            }
            if ((i & 2) != 0) {
                j = decoded.sequence;
            }
            long j3 = j;
            if ((i & 4) != 0) {
                j2 = decoded.receivedMs;
            }
            return decoded.copy(bitmap, j3, j2);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final Bitmap getBitmap() {
            return this.bitmap;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final long getSequence() {
            return this.sequence;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final long getReceivedMs() {
            return this.receivedMs;
        }

        public final Decoded copy(Bitmap bitmap, long sequence, long receivedMs) {
            Intrinsics.checkNotNullParameter(bitmap, "bitmap");
            return new Decoded(bitmap, sequence, receivedMs);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return LiveLiterals$MjpegVideoViewKt.INSTANCE.m7129Boolean$branch$when$funequals$classDecoded$classMjpegVideoView();
            }
            if (!(other instanceof Decoded)) {
                return LiveLiterals$MjpegVideoViewKt.INSTANCE.m7131Boolean$branch$when1$funequals$classDecoded$classMjpegVideoView();
            }
            Decoded decoded = (Decoded) other;
            if (!Intrinsics.areEqual(this.bitmap, decoded.bitmap)) {
                return LiveLiterals$MjpegVideoViewKt.INSTANCE.m7133Boolean$branch$when2$funequals$classDecoded$classMjpegVideoView();
            }
            if (this.sequence != decoded.sequence) {
                return LiveLiterals$MjpegVideoViewKt.INSTANCE.m7135Boolean$branch$when3$funequals$classDecoded$classMjpegVideoView();
            }
            return this.receivedMs != decoded.receivedMs ? LiveLiterals$MjpegVideoViewKt.INSTANCE.m7137Boolean$branch$when4$funequals$classDecoded$classMjpegVideoView() : LiveLiterals$MjpegVideoViewKt.INSTANCE.m7139Boolean$funequals$classDecoded$classMjpegVideoView();
        }

        public int hashCode() {
            return (LiveLiterals$MjpegVideoViewKt.INSTANCE.m7159Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classDecoded$classMjpegVideoView() * ((LiveLiterals$MjpegVideoViewKt.INSTANCE.m7157Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classDecoded$classMjpegVideoView() * this.bitmap.hashCode()) + Long.hashCode(this.sequence))) + Long.hashCode(this.receivedMs);
        }

        public String toString() {
            return LiveLiterals$MjpegVideoViewKt.INSTANCE.m7167String$0$str$funtoString$classDecoded$classMjpegVideoView() + LiveLiterals$MjpegVideoViewKt.INSTANCE.m7169String$1$str$funtoString$classDecoded$classMjpegVideoView() + this.bitmap + LiveLiterals$MjpegVideoViewKt.INSTANCE.m7171String$3$str$funtoString$classDecoded$classMjpegVideoView() + LiveLiterals$MjpegVideoViewKt.INSTANCE.m7173String$4$str$funtoString$classDecoded$classMjpegVideoView() + this.sequence + LiveLiterals$MjpegVideoViewKt.INSTANCE.m7175String$6$str$funtoString$classDecoded$classMjpegVideoView() + LiveLiterals$MjpegVideoViewKt.INSTANCE.m7177String$7$str$funtoString$classDecoded$classMjpegVideoView() + this.receivedMs + LiveLiterals$MjpegVideoViewKt.INSTANCE.m7179String$9$str$funtoString$classDecoded$classMjpegVideoView();
        }

        public Decoded(Bitmap bitmap, long sequence, long receivedMs) {
            Intrinsics.checkNotNullParameter(bitmap, "bitmap");
            this.bitmap = bitmap;
            this.sequence = sequence;
            this.receivedMs = receivedMs;
        }

        public final Bitmap getBitmap() {
            return this.bitmap;
        }

        public final long getReceivedMs() {
            return this.receivedMs;
        }

        public final long getSequence() {
            return this.sequence;
        }
    }

    public final Function2<String, Boolean, Unit> getOnStatus() {
        return this.onStatus;
    }

    public final void setOnStatus(Function2<? super String, ? super Boolean, Unit> function2) {
        Intrinsics.checkNotNullParameter(function2, "<set-?>");
        this.onStatus = function2;
    }

    public final void start(String url, OkHttpClient http) {
        Intrinsics.checkNotNullParameter(url, "url");
        Intrinsics.checkNotNullParameter(http, "http");
        stop$default(this, null, 1, null);
        synchronized (this.gate) {
            if (this.disposed) {
                return;
            }
            long current = this.generation;
            long jElapsedRealtime = SystemClock.elapsedRealtime();
            this.startedAt = jElapsedRealtime;
            this.statsAt = jElapsedRealtime;
            this.lastReceivedAt = LiveLiterals$MjpegVideoViewKt.INSTANCE.m7165Long$arg0$call$setlastReceivedAt$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView();
            this.drawnFrames = LiveLiterals$MjpegVideoViewKt.INSTANCE.m7149Int$arg0$call$setdrawnFrames$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView();
            this.receivedFrames = LiveLiterals$MjpegVideoViewKt.INSTANCE.m7150Int$arg0$call$setreceivedFrames$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView();
            this.decodedFrames = LiveLiterals$MjpegVideoViewKt.INSTANCE.m7148Int$arg0$call$setdecodedFrames$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView();
            this.drawnSequence = LiveLiterals$MjpegVideoViewKt.INSTANCE.m7164Long$arg0$call$setdrawnSequence$$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView();
            this.stream = new MjpegStream(new MjpegVideoView$start$1$1(this, current), new MjpegVideoView$start$1$2(this, current));
            invoke(LiveLiterals$MjpegVideoViewKt.INSTANCE.m7182String$arg0$callinvoke$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView(), Boolean.valueOf(LiveLiterals$MjpegVideoViewKt.INSTANCE.m7127Boolean$arg1$callinvoke$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView()));
            MjpegStream mjpegStream = this.stream;
            if (mjpegStream != null) {
                mjpegStream.start(url, http);
            }
            postInvalidateOnAnimation();
            postDelayed(this.heartbeat, LiveLiterals$MjpegVideoViewKt.INSTANCE.m7166Long$arg1$callpostDelayed$fun$anonymous$$arg1$callsynchronized$funstart$classMjpegVideoView());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void decodeLatest() {
        final Encoded next;
        while (true) {
            synchronized (this.gate) {
                next = this.pending;
                this.pending = null;
                if (next == null) {
                    this.decoding = LiveLiterals$MjpegVideoViewKt.INSTANCE.m7125Boolean$arg0$call$setdecoding$$branch$if$fun$anonymous$$arg1$callsynchronized$valtmp0_elvis_lhs$valencoded$body$loop$fundecodeLatest$classMjpegVideoView();
                }
            }
            if (next == null) {
                return;
            }
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = LiveLiterals$MjpegVideoViewKt.INSTANCE.m7141Boolean$setinJustDecodeBounds$fun$anonymous$$arg0$callapply$valoptions$body$loop$fundecodeLatest$classMjpegVideoView();
            BitmapFactory.decodeByteArray(next.getBytes(), LiveLiterals$MjpegVideoViewKt.INSTANCE.m7161Int$arg1$calldecodeByteArray$body$loop$fundecodeLatest$classMjpegVideoView(), next.getBytes().length, options);
            int iM7145Int$$this$callrangeTo$$this$callcontains$cond$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView = LiveLiterals$MjpegVideoViewKt.INSTANCE.m7145Int$$this$callrangeTo$$this$callcontains$cond$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView();
            int iM7156Int$arg0$callrangeTo$$this$callcontains$cond$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView = LiveLiterals$MjpegVideoViewKt.INSTANCE.m7156Int$arg0$callrangeTo$$this$callcontains$cond$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView();
            int i = options.outWidth;
            boolean z = false;
            if (iM7145Int$$this$callrangeTo$$this$callcontains$cond$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView <= i && i <= iM7156Int$arg0$callrangeTo$$this$callcontains$cond$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView) {
                int iM7144Int$$this$callrangeTo$$this$callcontains$branch$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView = LiveLiterals$MjpegVideoViewKt.INSTANCE.m7144Int$$this$callrangeTo$$this$callcontains$branch$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView();
                int iM7155Int$arg0$callrangeTo$$this$callcontains$branch$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView = LiveLiterals$MjpegVideoViewKt.INSTANCE.m7155Int$arg0$callrangeTo$$this$callcontains$branch$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView();
                int i2 = options.outHeight;
                if ((iM7144Int$$this$callrangeTo$$this$callcontains$branch$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView <= i2 && i2 <= iM7155Int$arg0$callrangeTo$$this$callcontains$branch$cond$valvalid$body$loop$fundecodeLatest$classMjpegVideoView) && ((long) options.outWidth) * ((long) options.outHeight) <= LiveLiterals$MjpegVideoViewKt.INSTANCE.m7147Int$$this$calltoLong$arg1$calllessOrEqual$branch$valvalid$body$loop$fundecodeLatest$classMjpegVideoView()) {
                    z = true;
                }
            }
            boolean valid = z;
            Bitmap bitmap = valid ? BitmapFactory.decodeByteArray(next.getBytes(), LiveLiterals$MjpegVideoViewKt.INSTANCE.m7162Int$arg1$calldecodeByteArray$branch$if$valbitmap$body$loop$fundecodeLatest$classMjpegVideoView(), next.getBytes().length) : null;
            synchronized (this.gate) {
                if (next.getGeneration() == this.generation && !this.disposed) {
                    if (bitmap == null) {
                        post(new Runnable() { // from class: vea.raceremote.video.MjpegVideoView$$ExternalSyntheticLambda0
                            @Override // java.lang.Runnable
                            public final void run() {
                                MjpegVideoView.decodeLatest$lambda$6$lambda$5(this.f$0, next);
                            }
                        });
                    } else {
                        long j = 1 + this.sequence;
                        this.sequence = j;
                        this.latest = new Decoded(bitmap, j, next.getReceivedMs());
                        this.decodedFrames++;
                    }
                }
                Unit unit = Unit.INSTANCE;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void decodeLatest$lambda$6$lambda$5(MjpegVideoView this$0, Encoded $encoded) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter($encoded, "$encoded");
        synchronized (this$0.gate) {
            if ($encoded.getGeneration() == this$0.generation) {
                this$0.stop(LiveLiterals$MjpegVideoViewKt.INSTANCE.m7183String$arg0$callstop$branch$if$fun$anonymous$$arg1$callsynchronized$fun$anonymous$$arg0$callpost$branch$if$branch$if$fun$anonymous$$arg1$callsynchronized$body$loop$fundecodeLatest$classMjpegVideoView());
            }
            Unit unit = Unit.INSTANCE;
        }
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        Intrinsics.checkNotNullParameter(canvas, "canvas");
        super.onDraw(canvas);
        canvas.drawRect(LiveLiterals$MjpegVideoViewKt.INSTANCE.m7142Float$arg0$calldrawRect$funonDraw$classMjpegVideoView(), LiveLiterals$MjpegVideoViewKt.INSTANCE.m7143Float$arg1$calldrawRect$funonDraw$classMjpegVideoView(), getWidth(), getHeight(), this.background);
        synchronized (this.gate) {
            if (this.stream != null) {
                postInvalidateOnAnimation();
            }
            Decoded frame = this.latest;
            if (frame == null) {
                return;
            }
            if (SystemClock.elapsedRealtime() - frame.getReceivedMs() >= LiveLiterals$MjpegVideoViewKt.INSTANCE.m7146Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if1$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView()) {
                return;
            }
            float scale = Math.min(getWidth() / frame.getBitmap().getWidth(), getHeight() / frame.getBitmap().getHeight());
            float w = frame.getBitmap().getWidth() * scale;
            float h = frame.getBitmap().getHeight() * scale;
            canvas.drawBitmap(frame.getBitmap(), (Rect) null, new RectF((getWidth() - w) / LiveLiterals$MjpegVideoViewKt.INSTANCE.m7151Int$arg0$calldiv$arg0$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView(), (getHeight() - h) / LiveLiterals$MjpegVideoViewKt.INSTANCE.m7152Int$arg0$calldiv$arg1$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView(), (getWidth() + w) / LiveLiterals$MjpegVideoViewKt.INSTANCE.m7153Int$arg0$calldiv$arg2$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView(), (getHeight() + h) / LiveLiterals$MjpegVideoViewKt.INSTANCE.m7154Int$arg0$calldiv$arg3$call$init$$arg2$calldrawBitmap$fun$anonymous$$arg1$callsynchronized$funonDraw$classMjpegVideoView()), this.paint);
            if (frame.getSequence() != this.drawnSequence) {
                this.drawnSequence = frame.getSequence();
                this.drawnFrames++;
            }
            Unit unit = Unit.INSTANCE;
        }
    }

    public static /* synthetic */ void stop$default(MjpegVideoView mjpegVideoView, String str, int i, Object obj) {
        if ((i & 1) != 0) {
            str = LiveLiterals$MjpegVideoViewKt.INSTANCE.m7184String$parammessage$funstop$classMjpegVideoView();
        }
        mjpegVideoView.stop(str);
    }

    public final void stop(String message) {
        Intrinsics.checkNotNullParameter(message, "message");
        synchronized (this.gate) {
            this.generation++;
            MjpegStream mjpegStream = this.stream;
            if (mjpegStream != null) {
                mjpegStream.close();
            }
            this.stream = null;
            this.pending = null;
            this.latest = null;
            removeCallbacks(this.heartbeat);
            invalidate();
            invoke(message, Boolean.valueOf(LiveLiterals$MjpegVideoViewKt.INSTANCE.m7128Boolean$arg1$callinvoke$fun$anonymous$$arg1$callsynchronized$funstop$classMjpegVideoView()));
            Log.d(LiveLiterals$MjpegVideoViewKt.INSTANCE.m7181String$arg0$calld$fun$anonymous$$arg1$callsynchronized$funstop$classMjpegVideoView(), message);
        }
    }

    public final void close() {
        stop$default(this, null, 1, null);
        synchronized (this.gate) {
            this.disposed = LiveLiterals$MjpegVideoViewKt.INSTANCE.m7126Boolean$arg0$call$setdisposed$$fun$anonymous$$arg1$callsynchronized$funclose$classMjpegVideoView();
            this.decoder.shutdownNow();
        }
    }
}
