package vea.raceremote.video;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.text.KeyboardActions;
import androidx.compose.foundation.text.KeyboardOptions;
import androidx.compose.material.ButtonKt;
import androidx.compose.material.MaterialTheme;
import androidx.compose.material.OutlinedTextFieldKt;
import androidx.compose.material.TextFieldColors;
import androidx.compose.material.TextKt;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.DisposableEffectResult;
import androidx.compose.runtime.DisposableEffectScope;
import androidx.compose.runtime.EffectsKt;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.ProvidableCompositionLocal;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.SkippableUpdater;
import androidx.compose.runtime.SnapshotStateKt;
import androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt;
import androidx.compose.runtime.State;
import androidx.compose.runtime.Updater;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.runtime.saveable.RememberSaveableKt;
import androidx.compose.runtime.saveable.Saver;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.draw.ClipKt;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.ui.layout.LayoutKt;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;
import androidx.compose.ui.platform.CompositionLocalsKt;
import androidx.compose.ui.platform.TestTagKt;
import androidx.compose.ui.platform.ViewConfiguration;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.input.VisualTransformation;
import androidx.compose.ui.unit.Density;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.unit.LayoutDirection;
import androidx.compose.ui.viewinterop.AndroidView_androidKt;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleOwner;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlin.text.StringsKt;
import okhttp3.OkHttpClient;

/* JADX INFO: compiled from: VideoPanel.kt */
/* JADX INFO: loaded from: classes11.dex */
@Metadata(d1 = {"\u0000\"\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a=\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\u0012\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00010\tH\u0007¢\u0006\u0002\u0010\n¨\u0006\u000b"}, d2 = {"VideoPanel", "", "carHost", "", "modifier", "Landroidx/compose/ui/Modifier;", "showSettings", "", "onActiveChanged", "Lkotlin/Function1;", "(Ljava/lang/String;Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class VideoPanelKt {
    public static final void VideoPanel(final String carHost, Modifier modifier, boolean showSettings, final Function1<? super Boolean, Unit> function1, Composer $composer, final int $changed, final int i) {
        Modifier modifier2;
        boolean showSettings2;
        Modifier.Companion modifier3;
        Object value$iv$iv;
        Object value$iv$iv2;
        Object value$iv$iv3;
        Modifier modifier4;
        Object value$iv$iv4;
        Intrinsics.checkNotNullParameter(carHost, "carHost");
        Intrinsics.checkNotNullParameter(function1, "onActiveChanged");
        Composer $composer2 = $composer.startRestartGroup(2031918687);
        ComposerKt.sourceInformation($composer2, "C(VideoPanel)P(!2,3)21@883L7,22@931L7,23@975L37,24@1045L47,24@1028L64,25@1112L46,26@1177L34,27@1227L27,28@1270L36,29@1311L544,40@1860L1214:VideoPanel.kt#udqiv4");
        int $dirty = $changed;
        if ((i & 1) != 0) {
            $dirty |= 6;
        } else if (($changed & 14) == 0) {
            $dirty |= $composer2.changed(carHost) ? 4 : 2;
        }
        int i2 = i & 2;
        if (i2 != 0) {
            $dirty |= 48;
            modifier2 = modifier;
        } else if (($changed & 112) == 0) {
            modifier2 = modifier;
            $dirty |= $composer2.changed(modifier2) ? 32 : 16;
        } else {
            modifier2 = modifier;
        }
        if (($changed & 896) == 0) {
            if ((i & 4) == 0) {
                showSettings2 = showSettings;
                int i3 = $composer2.changed(showSettings2) ? 256 : 128;
                $dirty |= i3;
            } else {
                showSettings2 = showSettings;
            }
            $dirty |= i3;
        } else {
            showSettings2 = showSettings;
        }
        if ((i & 8) != 0) {
            $dirty |= 3072;
        } else if (($changed & 7168) == 0) {
            $dirty |= $composer2.changed(function1) ? 2048 : 1024;
        }
        if (($dirty & 5851) == 1170 && $composer2.getSkipping()) {
            $composer2.skipToGroupEnd();
            modifier4 = modifier2;
            showSettings2 = showSettings2;
            $composer2 = $composer2;
        } else {
            $composer2.startDefaults();
            if (($changed & 1) == 0 || $composer2.getDefaultsInvalid()) {
                modifier3 = i2 != 0 ? Modifier.INSTANCE : modifier2;
                if ((i & 4) != 0) {
                    $dirty &= -897;
                    showSettings2 = LiveLiterals$VideoPanelKt.INSTANCE.m7188Boolean$paramshowSettings$funVideoPanel();
                }
            } else {
                $composer2.skipToGroupEnd();
                if ((i & 4) != 0) {
                    $dirty &= -897;
                }
                modifier3 = modifier2;
            }
            $composer2.endDefaults();
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(2031918687, $dirty, -1, "vea.raceremote.video.VideoPanel (VideoPanel.kt:20)");
            }
            ProvidableCompositionLocal<Context> localContext = AndroidCompositionLocals_androidKt.getLocalContext();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume = $composer2.consume(localContext);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            final Context context = (Context) objConsume;
            ProvidableCompositionLocal<LifecycleOwner> localLifecycleOwner = AndroidCompositionLocals_androidKt.getLocalLifecycleOwner();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume2 = $composer2.consume(localLifecycleOwner);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            Lifecycle lifecycle = ((LifecycleOwner) objConsume2).getLifecycle();
            Intrinsics.checkNotNullExpressionValue(lifecycle, "LocalLifecycleOwner.current.lifecycle");
            State activeCallback$delegate = SnapshotStateKt.rememberUpdatedState(function1, $composer2, ($dirty >> 9) & 14);
            Object[] objArr = new Object[0];
            int i4 = $dirty & 14;
            $composer2.startReplaceableGroup(1157296644);
            ComposerKt.sourceInformation($composer2, "C(remember)P(1):Composables.kt#9igjgp");
            boolean invalid$iv$iv = $composer2.changed(carHost);
            Object it$iv$iv = $composer2.rememberedValue();
            if (invalid$iv$iv || it$iv$iv == Composer.INSTANCE.getEmpty()) {
                value$iv$iv = (Function0) new Function0<MutableState<String>>() { // from class: vea.raceremote.video.VideoPanelKt$VideoPanel$url$2$1
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    /* JADX WARN: Can't rename method to resolve collision */
                    @Override // kotlin.jvm.functions.Function0
                    public final MutableState<String> invoke() {
                        return SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(LiveLiterals$VideoPanelKt.INSTANCE.m7192String$0$str$arg0$callmutableStateOf$fun$anonymous$$arg3$callrememberSaveable$valurl$delegate$funVideoPanel() + carHost + LiveLiterals$VideoPanelKt.INSTANCE.m7193String$2$str$arg0$callmutableStateOf$fun$anonymous$$arg3$callrememberSaveable$valurl$delegate$funVideoPanel(), null, 2, null);
                    }
                };
                $composer2.updateRememberedValue(value$iv$iv);
            } else {
                value$iv$iv = it$iv$iv;
            }
            $composer2.endReplaceableGroup();
            final MutableState url$delegate = (MutableState) RememberSaveableKt.m1317rememberSaveable(objArr, (Saver) null, (String) null, (Function0) value$iv$iv, $composer2, 8, 6);
            $composer2.startReplaceableGroup(-492369756);
            ComposerKt.sourceInformation($composer2, "C(remember):Composables.kt#9igjgp");
            Object it$iv$iv2 = $composer2.rememberedValue();
            if (it$iv$iv2 == Composer.INSTANCE.getEmpty()) {
                value$iv$iv2 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(LiveLiterals$VideoPanelKt.INSTANCE.m7195String$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valmessage$delegate$funVideoPanel(), null, 2, null);
                $composer2.updateRememberedValue(value$iv$iv2);
            } else {
                value$iv$iv2 = it$iv$iv2;
            }
            $composer2.endReplaceableGroup();
            MutableState message$delegate = (MutableState) value$iv$iv2;
            $composer2.startReplaceableGroup(-492369756);
            ComposerKt.sourceInformation($composer2, "C(remember):Composables.kt#9igjgp");
            Object value$iv$iv5 = $composer2.rememberedValue();
            if (value$iv$iv5 == Composer.INSTANCE.getEmpty()) {
                value$iv$iv5 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(Boolean.valueOf(LiveLiterals$VideoPanelKt.INSTANCE.m7185Boolean$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valactive$delegate$funVideoPanel()), null, 2, null);
                $composer2.updateRememberedValue(value$iv$iv5);
            }
            $composer2.endReplaceableGroup();
            final MutableState active$delegate = (MutableState) value$iv$iv5;
            $composer2.startReplaceableGroup(-492369756);
            ComposerKt.sourceInformation($composer2, "C(remember):Composables.kt#9igjgp");
            Object it$iv$iv3 = $composer2.rememberedValue();
            if (it$iv$iv3 == Composer.INSTANCE.getEmpty()) {
                value$iv$iv3 = new OkHttpClient();
                $composer2.updateRememberedValue(value$iv$iv3);
            } else {
                value$iv$iv3 = it$iv$iv3;
            }
            $composer2.endReplaceableGroup();
            final OkHttpClient http = (OkHttpClient) value$iv$iv3;
            $composer2.startReplaceableGroup(-492369756);
            ComposerKt.sourceInformation($composer2, "C(remember):Composables.kt#9igjgp");
            Object value$iv$iv6 = $composer2.rememberedValue();
            if (value$iv$iv6 == Composer.INSTANCE.getEmpty()) {
                value$iv$iv6 = new MjpegVideoView(context);
                $composer2.updateRememberedValue(value$iv$iv6);
            }
            $composer2.endReplaceableGroup();
            final MjpegVideoView view = (MjpegVideoView) value$iv$iv6;
            EffectsKt.DisposableEffect(view, lifecycle, new AnonymousClass1(view, lifecycle, message$delegate, active$delegate, activeCallback$delegate, http), $composer2, 72);
            int $changed$iv = ($dirty >> 3) & 14;
            $composer2.startReplaceableGroup(-483455358);
            ComposerKt.sourceInformation($composer2, "C(Column)P(2,3,1)77@3880L61,78@3946L133:Column.kt#2w3rfo");
            Arrangement.Vertical verticalArrangement$iv = Arrangement.INSTANCE.getTop();
            Alignment.Horizontal horizontalAlignment$iv = Alignment.INSTANCE.getStart();
            MeasurePolicy measurePolicy$iv = ColumnKt.columnMeasurePolicy(verticalArrangement$iv, horizontalAlignment$iv, $composer2, (($changed$iv >> 3) & 14) | (($changed$iv >> 3) & 112));
            int $changed$iv$iv = ($changed$iv << 3) & 112;
            $composer2.startReplaceableGroup(-1323940314);
            ComposerKt.sourceInformation($composer2, "C(Layout)P(!1,2)74@2915L7,75@2970L7,76@3029L7,77@3041L460:Layout.kt#80mrfh");
            ProvidableCompositionLocal<Density> localDensity = CompositionLocalsKt.getLocalDensity();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume3 = $composer2.consume(localDensity);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            Density density$iv$iv = (Density) objConsume3;
            ProvidableCompositionLocal<LayoutDirection> localLayoutDirection = CompositionLocalsKt.getLocalLayoutDirection();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume4 = $composer2.consume(localLayoutDirection);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            LayoutDirection layoutDirection$iv$iv = (LayoutDirection) objConsume4;
            ProvidableCompositionLocal<ViewConfiguration> localViewConfiguration = CompositionLocalsKt.getLocalViewConfiguration();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
            Object objConsume5 = $composer2.consume(localViewConfiguration);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ViewConfiguration viewConfiguration$iv$iv = (ViewConfiguration) objConsume5;
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            Function3<SkippableUpdater<ComposeUiNode>, Composer, Integer, Unit> function3MaterializerOf = LayoutKt.materializerOf(modifier3);
            modifier4 = modifier3;
            int $changed$iv$iv$iv = (($changed$iv$iv << 9) & 7168) | 6;
            if (!($composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer2.startReusableNode();
            if ($composer2.getInserting()) {
                $composer2.createNode(constructor);
            } else {
                $composer2.useNode();
            }
            $composer2.disableReusing();
            Composer $this$Layout_u24lambda_u2d0$iv$iv = Updater.m1304constructorimpl($composer2);
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, measurePolicy$iv, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, density$iv$iv, ComposeUiNode.INSTANCE.getSetDensity());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, layoutDirection$iv$iv, ComposeUiNode.INSTANCE.getSetLayoutDirection());
            Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv, viewConfiguration$iv$iv, ComposeUiNode.INSTANCE.getSetViewConfiguration());
            $composer2.enableReusing();
            function3MaterializerOf.invoke(SkippableUpdater.m1294boximpl(SkippableUpdater.m1295constructorimpl($composer2)), $composer2, Integer.valueOf(($changed$iv$iv$iv >> 3) & 112));
            $composer2.startReplaceableGroup(2058660585);
            $composer2.startReplaceableGroup(-1163856341);
            ComposerKt.sourceInformation($composer2, "C79@3994L9:Column.kt#2w3rfo");
            if ((($changed$iv$iv$iv >> 9) & 14 & 11) == 2 && $composer2.getSkipping()) {
                $composer2.skipToGroupEnd();
                showSettings2 = showSettings2;
                $composer2 = $composer2;
            } else {
                int i5 = (($changed$iv >> 6) & 112) | 6;
                ColumnScope $this$VideoPanel_u24lambda_u2414 = ColumnScopeInstance.INSTANCE;
                ComposerKt.sourceInformationMarkerStart($composer2, 941910729, "C55@2924L10,55@2854L89,56@2952L116:VideoPanel.kt#udqiv4");
                $composer2.startReplaceableGroup(941910729);
                ComposerKt.sourceInformation($composer2, "41@1905L940");
                if (showSettings2) {
                    Arrangement arrangement = Arrangement.INSTANCE;
                    int $this$dp$iv = LiveLiterals$VideoPanelKt.INSTANCE.m7191Int$$$this$call$getdp$$arg0$callspacedBy$arg1$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel();
                    Arrangement.Horizontal horizontalArrangement$iv = arrangement.m372spacedBy0680j_4(Dp.m4046constructorimpl($this$dp$iv));
                    $composer2.startReplaceableGroup(693286680);
                    ComposerKt.sourceInformation($composer2, "C(Row)P(2,1,3)78@3880L58,79@3943L130:Row.kt#2w3rfo");
                    Modifier modifier$iv = Modifier.INSTANCE;
                    Alignment.Vertical verticalAlignment$iv = Alignment.INSTANCE.getTop();
                    MeasurePolicy measurePolicy$iv2 = RowKt.rowMeasurePolicy(horizontalArrangement$iv, verticalAlignment$iv, $composer2, ((0 >> 3) & 14) | ((0 >> 3) & 112));
                    int $changed$iv$iv2 = (0 << 3) & 112;
                    $composer2.startReplaceableGroup(-1323940314);
                    ComposerKt.sourceInformation($composer2, "C(Layout)P(!1,2)74@2915L7,75@2970L7,76@3029L7,77@3041L460:Layout.kt#80mrfh");
                    ProvidableCompositionLocal<Density> localDensity2 = CompositionLocalsKt.getLocalDensity();
                    ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
                    Object objConsume6 = $composer2.consume(localDensity2);
                    ComposerKt.sourceInformationMarkerEnd($composer2);
                    Density density$iv$iv2 = (Density) objConsume6;
                    ProvidableCompositionLocal<LayoutDirection> localLayoutDirection2 = CompositionLocalsKt.getLocalLayoutDirection();
                    ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
                    Object objConsume7 = $composer2.consume(localLayoutDirection2);
                    ComposerKt.sourceInformationMarkerEnd($composer2);
                    LayoutDirection layoutDirection$iv$iv2 = (LayoutDirection) objConsume7;
                    ProvidableCompositionLocal<ViewConfiguration> localViewConfiguration2 = CompositionLocalsKt.getLocalViewConfiguration();
                    ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "C:CompositionLocal.kt#9igjgp");
                    Object objConsume8 = $composer2.consume(localViewConfiguration2);
                    ComposerKt.sourceInformationMarkerEnd($composer2);
                    ViewConfiguration viewConfiguration$iv$iv2 = (ViewConfiguration) objConsume8;
                    Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
                    Function3<SkippableUpdater<ComposeUiNode>, Composer, Integer, Unit> function3MaterializerOf2 = LayoutKt.materializerOf(modifier$iv);
                    int $changed$iv$iv$iv2 = (($changed$iv$iv2 << 9) & 7168) | 6;
                    if (!($composer2.getApplier() instanceof Applier)) {
                        ComposablesKt.invalidApplier();
                    }
                    $composer2.startReusableNode();
                    if ($composer2.getInserting()) {
                        $composer2.createNode(constructor2);
                    } else {
                        $composer2.useNode();
                    }
                    $composer2.disableReusing();
                    Composer $this$Layout_u24lambda_u2d0$iv$iv2 = Updater.m1304constructorimpl($composer2);
                    Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv2, measurePolicy$iv2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv2, density$iv$iv2, ComposeUiNode.INSTANCE.getSetDensity());
                    Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv2, layoutDirection$iv$iv2, ComposeUiNode.INSTANCE.getSetLayoutDirection());
                    Updater.m1311setimpl($this$Layout_u24lambda_u2d0$iv$iv2, viewConfiguration$iv$iv2, ComposeUiNode.INSTANCE.getSetViewConfiguration());
                    $composer2.enableReusing();
                    function3MaterializerOf2.invoke(SkippableUpdater.m1294boximpl(SkippableUpdater.m1295constructorimpl($composer2)), $composer2, Integer.valueOf(($changed$iv$iv$iv2 >> 3) & 112));
                    $composer2.startReplaceableGroup(2058660585);
                    $composer2.startReplaceableGroup(-678309503);
                    ComposerKt.sourceInformation($composer2, "C80@3988L9:Row.kt#2w3rfo");
                    if ((($changed$iv$iv$iv2 >> 9) & 14 & 11) == 2 && $composer2.getSkipping()) {
                        $composer2.skipToGroupEnd();
                    } else {
                        int i6 = ((0 >> 6) & 112) | 6;
                        RowScope $this$VideoPanel_u24lambda_u2414_u24lambda_u2413 = RowScopeInstance.INSTANCE;
                        ComposerKt.sourceInformationMarkerStart($composer2, 1222614594, "C42@1998L12,42@1975L180,44@2168L667:VideoPanel.kt#udqiv4");
                        String strVideoPanel$lambda$2 = VideoPanel$lambda$2(url$delegate);
                        boolean z = !VideoPanel$lambda$8(active$delegate);
                        Modifier modifierTestTag = TestTagKt.testTag(RowScope.weight$default($this$VideoPanel_u24lambda_u2414_u24lambda_u2413, Modifier.INSTANCE, LiveLiterals$VideoPanelKt.INSTANCE.m7190Float$arg0$callweight$$$this$calltestTag$valtmp2_modifier$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel(), false, 2, null), LiveLiterals$VideoPanelKt.INSTANCE.m7199String$arg0$calltestTag$valtmp2_modifier$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel());
                        $composer2.startReplaceableGroup(1157296644);
                        ComposerKt.sourceInformation($composer2, "C(remember)P(1):Composables.kt#9igjgp");
                        boolean invalid$iv$iv2 = $composer2.changed(url$delegate);
                        Object it$iv$iv4 = $composer2.rememberedValue();
                        if (invalid$iv$iv2 || it$iv$iv4 == Composer.INSTANCE.getEmpty()) {
                            value$iv$iv4 = (Function1) new Function1<String, Unit>() { // from class: vea.raceremote.video.VideoPanelKt$VideoPanel$2$1$1$1
                                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                {
                                    super(1);
                                }

                                @Override // kotlin.jvm.functions.Function1
                                public /* bridge */ /* synthetic */ Unit invoke(String str) {
                                    invoke2(str);
                                    return Unit.INSTANCE;
                                }

                                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                                public final void invoke2(String it) {
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    setValue(it);
                                }
                            };
                            $composer2.updateRememberedValue(value$iv$iv4);
                        } else {
                            value$iv$iv4 = it$iv$iv4;
                        }
                        $composer2.endReplaceableGroup();
                        OutlinedTextFieldKt.OutlinedTextField(strVideoPanel$lambda$2, (Function1<? super String, Unit>) value$iv$iv4, modifierTestTag, z, false, (TextStyle) null, (Function2<? super Composer, ? super Integer, Unit>) ComposableSingletons$VideoPanelKt.INSTANCE.m7016getLambda1$app_debug(), (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, false, (VisualTransformation) null, (KeyboardOptions) null, (KeyboardActions) null, LiveLiterals$VideoPanelKt.INSTANCE.m7187Boolean$arg14$callOutlinedTextField$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel(), 0, (MutableInteractionSource) null, (Shape) null, (TextFieldColors) null, $composer2, 1572864, 0, 507824);
                        ButtonKt.Button(new Function0<Unit>() { // from class: vea.raceremote.video.VideoPanelKt$VideoPanel$2$1$2
                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            {
                                super(0);
                            }

                            @Override // kotlin.jvm.functions.Function0
                            public /* bridge */ /* synthetic */ Unit invoke() {
                                invoke2();
                                return Unit.INSTANCE;
                            }

                            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                            public final void invoke2() {
                                Object obj = null;
                                if (!VideoPanelKt.VideoPanel$lambda$8(active$delegate)) {
                                    ConnectivityManager manager = (ConnectivityManager) context.getSystemService(ConnectivityManager.class);
                                    Object[] allNetworks = manager.getAllNetworks();
                                    Intrinsics.checkNotNullExpressionValue(allNetworks, "manager.allNetworks");
                                    Object[] $this$firstOrNull$iv = allNetworks;
                                    for (Object element$iv : $this$firstOrNull$iv) {
                                        Network it = (Network) element$iv;
                                        NetworkCapabilities networkCapabilities = manager.getNetworkCapabilities(it);
                                        if (networkCapabilities != null && networkCapabilities.hasTransport(1) == LiveLiterals$VideoPanelKt.INSTANCE.m7186Boolean$arg1$callEQEQ$fun$anonymous$$arg0$callfirstOrNull$valwifi$else$if$fun$anonymous$$arg0$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel()) {
                                            obj = element$iv;
                                            break;
                                        }
                                    }
                                    Network wifi = (Network) obj;
                                    OkHttpClient transport = http;
                                    if (wifi != null) {
                                        transport = transport.newBuilder().socketFactory(wifi.getSocketFactory()).build();
                                    }
                                    MjpegVideoView mjpegVideoView = view;
                                    String string = StringsKt.trim((CharSequence) VideoPanelKt.VideoPanel$lambda$2(url$delegate)).toString();
                                    Intrinsics.checkNotNullExpressionValue(transport, "transport");
                                    mjpegVideoView.start(string, transport);
                                    return;
                                }
                                MjpegVideoView.stop$default(view, null, 1, null);
                            }
                        }, TestTagKt.testTag(Modifier.INSTANCE, LiveLiterals$VideoPanelKt.INSTANCE.m7197String$arg0$calltestTag$arg1$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel()), false, null, null, null, null, null, null, ComposableLambdaKt.composableLambda($composer2, -1289436284, true, new Function3<RowScope, Composer, Integer, Unit>() { // from class: vea.raceremote.video.VideoPanelKt$VideoPanel$2$1$3
                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            {
                                super(3);
                            }

                            @Override // kotlin.jvm.functions.Function3
                            public /* bridge */ /* synthetic */ Unit invoke(RowScope rowScope, Composer composer, Integer num) {
                                invoke(rowScope, composer, num.intValue());
                                return Unit.INSTANCE;
                            }

                            public final void invoke(RowScope $this$Button, Composer $composer3, int $changed2) {
                                Intrinsics.checkNotNullParameter($this$Button, "$this$Button");
                                ComposerKt.sourceInformation($composer3, "C53@2788L45:VideoPanel.kt#udqiv4");
                                if (($changed2 & 81) == 16 && $composer3.getSkipping()) {
                                    $composer3.skipToGroupEnd();
                                    return;
                                }
                                if (ComposerKt.isTraceInProgress()) {
                                    ComposerKt.traceEventStart(-1289436284, $changed2, -1, "vea.raceremote.video.VideoPanel.<anonymous>.<anonymous>.<anonymous> (VideoPanel.kt:53)");
                                }
                                TextKt.m1249TextfLXpl1I(VideoPanelKt.VideoPanel$lambda$8(active$delegate) ? LiveLiterals$VideoPanelKt.INSTANCE.m7200String$branch$if$arg0$callText$fun$anonymous$$arg9$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel() : LiveLiterals$VideoPanelKt.INSTANCE.m7201String$else$if$arg0$callText$fun$anonymous$$arg9$callButton$fun$anonymous$$arg3$callRow$branch$if$fun$anonymous$$arg3$callColumn$funVideoPanel(), null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, null, $composer3, 0, 0, 65534);
                                if (ComposerKt.isTraceInProgress()) {
                                    ComposerKt.traceEventEnd();
                                }
                            }
                        }), $composer2, 805306368, 508);
                        ComposerKt.sourceInformationMarkerEnd($composer2);
                    }
                    $composer2.endReplaceableGroup();
                    $composer2.endReplaceableGroup();
                    $composer2.endNode();
                    $composer2.endReplaceableGroup();
                    $composer2.endReplaceableGroup();
                }
                $composer2.endReplaceableGroup();
                TextKt.m1249TextfLXpl1I(VideoPanel$lambda$5(message$delegate), TestTagKt.testTag(Modifier.INSTANCE, LiveLiterals$VideoPanelKt.INSTANCE.m7198String$arg0$calltestTag$arg1$callText$fun$anonymous$$arg3$callColumn$funVideoPanel()), 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, MaterialTheme.INSTANCE.getTypography($composer2, MaterialTheme.$stable).getCaption(), $composer2, 0, 0, 32764);
                AndroidView_androidKt.AndroidView(new Function1<Context, MjpegVideoView>() { // from class: vea.raceremote.video.VideoPanelKt$VideoPanel$2$2
                    {
                        super(1);
                    }

                    @Override // kotlin.jvm.functions.Function1
                    public final MjpegVideoView invoke(Context it) {
                        Intrinsics.checkNotNullParameter(it, "it");
                        return view;
                    }
                }, TestTagKt.testTag(ClipKt.clipToBounds(ColumnScope.weight$default($this$VideoPanel_u24lambda_u2414, SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), LiveLiterals$VideoPanelKt.INSTANCE.m7189Float$arg0$callweight$$$this$callclipToBounds$$$this$calltestTag$arg1$callAndroidView$fun$anonymous$$arg3$callColumn$funVideoPanel(), false, 2, null)), LiveLiterals$VideoPanelKt.INSTANCE.m7196String$arg0$calltestTag$arg1$callAndroidView$fun$anonymous$$arg3$callColumn$funVideoPanel()), null, $composer2, 0, 4);
                ComposerKt.sourceInformationMarkerEnd($composer2);
            }
            $composer2.endReplaceableGroup();
            $composer2.endReplaceableGroup();
            $composer2.endNode();
            $composer2.endReplaceableGroup();
            $composer2.endReplaceableGroup();
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup == null) {
            return;
        }
        final Modifier modifier5 = modifier4;
        final boolean z2 = showSettings2;
        scopeUpdateScopeEndRestartGroup.updateScope(new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.video.VideoPanelKt.VideoPanel.3
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                invoke(composer, num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(Composer composer, int i7) {
                VideoPanelKt.VideoPanel(carHost, modifier5, z2, function1, composer, $changed | 1, i);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Function1<Boolean, Unit> VideoPanel$lambda$0(State<? extends Function1<? super Boolean, Unit>> state) {
        Object thisObj$iv = state.getValue();
        return (Function1) thisObj$iv;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final String VideoPanel$lambda$2(MutableState<String> mutableState) {
        MutableState<String> $this$getValue$iv = mutableState;
        return $this$getValue$iv.getValue();
    }

    private static final String VideoPanel$lambda$5(MutableState<String> mutableState) {
        MutableState<String> $this$getValue$iv = mutableState;
        return $this$getValue$iv.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void VideoPanel$lambda$6(MutableState<String> mutableState, String value) {
        mutableState.setValue(value);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean VideoPanel$lambda$8(MutableState<Boolean> mutableState) {
        MutableState<Boolean> $this$getValue$iv = mutableState;
        return $this$getValue$iv.getValue().booleanValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void VideoPanel$lambda$9(MutableState<Boolean> mutableState, boolean value) {
        mutableState.setValue(Boolean.valueOf(value));
    }

    /* JADX INFO: renamed from: vea.raceremote.video.VideoPanelKt$VideoPanel$1, reason: invalid class name */
    /* JADX INFO: compiled from: VideoPanel.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    static final class AnonymousClass1 extends Lambda implements Function1<DisposableEffectScope, DisposableEffectResult> {
        final /* synthetic */ MutableState<Boolean> $active$delegate;
        final /* synthetic */ State<Function1<Boolean, Unit>> $activeCallback$delegate;
        final /* synthetic */ OkHttpClient $http;
        final /* synthetic */ Lifecycle $lifecycle;
        final /* synthetic */ MutableState<String> $message$delegate;
        final /* synthetic */ MjpegVideoView $view;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        AnonymousClass1(MjpegVideoView mjpegVideoView, Lifecycle lifecycle, MutableState<String> mutableState, MutableState<Boolean> mutableState2, State<? extends Function1<? super Boolean, Unit>> state, OkHttpClient okHttpClient) {
            super(1);
            this.$view = mjpegVideoView;
            this.$lifecycle = lifecycle;
            this.$message$delegate = mutableState;
            this.$active$delegate = mutableState2;
            this.$activeCallback$delegate = state;
            this.$http = okHttpClient;
        }

        @Override // kotlin.jvm.functions.Function1
        public final DisposableEffectResult invoke(DisposableEffectScope $this$DisposableEffect) {
            Intrinsics.checkNotNullParameter($this$DisposableEffect, "$this$DisposableEffect");
            MjpegVideoView mjpegVideoView = this.$view;
            final MutableState<String> mutableState = this.$message$delegate;
            final MutableState<Boolean> mutableState2 = this.$active$delegate;
            final State<Function1<Boolean, Unit>> state = this.$activeCallback$delegate;
            mjpegVideoView.setOnStatus(new Function2<String, Boolean, Unit>() { // from class: vea.raceremote.video.VideoPanelKt.VideoPanel.1.1
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                /* JADX WARN: Multi-variable type inference failed */
                {
                    super(2);
                }

                @Override // kotlin.jvm.functions.Function2
                public /* bridge */ /* synthetic */ Unit invoke(String str, Boolean bool) {
                    invoke(str, bool.booleanValue());
                    return Unit.INSTANCE;
                }

                public final void invoke(String status, boolean running) {
                    Intrinsics.checkNotNullParameter(status, "status");
                    VideoPanelKt.VideoPanel$lambda$6(mutableState, status);
                    VideoPanelKt.VideoPanel$lambda$9(mutableState2, running);
                    VideoPanelKt.VideoPanel$lambda$0(state).invoke(Boolean.valueOf(running));
                }
            });
            final MjpegVideoView mjpegVideoView2 = this.$view;
            final LifecycleEventObserver observer = new LifecycleEventObserver() { // from class: vea.raceremote.video.VideoPanelKt$VideoPanel$1$$ExternalSyntheticLambda0
                @Override // androidx.lifecycle.LifecycleEventObserver
                public final void onStateChanged(LifecycleOwner lifecycleOwner, Lifecycle.Event event) {
                    VideoPanelKt.AnonymousClass1.invoke$lambda$0(mjpegVideoView2, lifecycleOwner, event);
                }
            };
            addObserver(observer);
            final Lifecycle lifecycle = this.$lifecycle;
            final MjpegVideoView mjpegVideoView3 = this.$view;
            final OkHttpClient okHttpClient = this.$http;
            return new DisposableEffectResult() { // from class: vea.raceremote.video.VideoPanelKt$VideoPanel$1$invoke$$inlined$onDispose$1
                @Override // androidx.compose.runtime.DisposableEffectResult
                public void dispose() {
                    removeObserver(observer);
                    mjpegVideoView3.close();
                    dispatcher().executorService().shutdownNow();
                    connectionPool().evictAll();
                }
            };
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void invoke$lambda$0(MjpegVideoView $view, LifecycleOwner lifecycleOwner, Lifecycle.Event event) {
            Intrinsics.checkNotNullParameter($view, "$view");
            Intrinsics.checkNotNullParameter(lifecycleOwner, "<anonymous parameter 0>");
            Intrinsics.checkNotNullParameter(event, "event");
            if (event == Lifecycle.Event.ON_PAUSE || event == Lifecycle.Event.ON_STOP) {
                MjpegVideoView.stop$default($view, null, 1, null);
            }
        }
    }
}
