package vea.raceremote.control;

/* JADX INFO: compiled from: CarControlClient.kt */
/* JADX INFO: loaded from: classes4.dex */
@kotlin.Metadata(d1 = {"\u0000j\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B5\u0012\u0014\b\u0002\u0010\u0002\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00050\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u0012\u000e\b\u0002\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\t¢\u0006\u0002\u0010\u000bJ\u0006\u0010#\u001a\u00020\u0005J1\u0010$\u001a\u00020\u00052\u0006\u0010%\u001a\u00020\u00042\u0006\u0010&\u001a\u00020'2\b\b\u0002\u0010(\u001a\u00020\u001d2\n\b\u0002\u0010)\u001a\u0004\u0018\u00010\n¢\u0006\u0002\u0010*J\u0010\u0010+\u001a\u00020\u00052\b\b\u0002\u0010,\u001a\u00020\u0004J\u0010\u0010-\u001a\u00020\u00052\u0006\u0010.\u001a\u00020/H\u0002J\u0016\u00100\u001a\u00020\u00052\u0006\u0010\u001e\u001a\u0002012\u0006\u0010\u001c\u001a\u000201J\b\u00102\u001a\u00020\u0005H\u0002R\u0014\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0002\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00050\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u0012\u0010\r\u001a\u0004\u0018\u00010\nX\u0082\u000e¢\u0006\u0004\n\u0002\u0010\u000eR\u0014\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00110\u0010X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u0012\u0010\u0013\u001a\u0004\u0018\u00010\nX\u0082\u000e¢\u0006\u0004\n\u0002\u0010\u000eR\u000e\u0010\u0014\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0016\u001a\u0004\u0018\u00010\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R\u0017\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00110\u0019¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001bR\u000e\u0010\u001c\u001a\u00020\u001dX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u001dX\u0082\u000e¢\u0006\u0002\n\u0000R\u0016\u0010\u001f\u001a\n !*\u0004\u0018\u00010 0 X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000¨\u00063"}, d2 = {"Lvea/raceremote/control/CarControlClient;", "", "diagnostics", "Lkotlin/Function1;", "", "", "traceAllCommands", "", "clockMs", "Lkotlin/Function0;", "", "(Lkotlin/jvm/functions/Function1;ZLkotlin/jvm/functions/Function0;)V", "generation", "lastTickAt", "Ljava/lang/Long;", "mutableState", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Lvea/raceremote/control/CarConnectionState;", "opened", "pending", "sentAt", "sequence", "socket", "Lokhttp3/WebSocket;", "state", "Lkotlinx/coroutines/flow/StateFlow;", "getState", "()Lkotlinx/coroutines/flow/StateFlow;", "steering", "", "throttle", "timer", "Ljava/util/concurrent/ScheduledExecutorService;", "kotlin.jvm.PlatformType", "token", "close", "connect", "host", "httpClient", "Lokhttp3/OkHttpClient;", "port", "expectedChipId", "(Ljava/lang/String;Lokhttp3/OkHttpClient;ILjava/lang/Long;)V", "disconnect", "message", "send", "p", "Lvea/raceremote/control/ControlPacket;", "setInput", "", "tick", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class CarControlClient {
    public static final int $stable = 0;
    private final kotlin.jvm.functions.Function0<java.lang.Long> clockMs;
    private final kotlin.jvm.functions.Function1<java.lang.String, kotlin.Unit> diagnostics;
    private long generation;
    private java.lang.Long lastTickAt;
    private final kotlinx.coroutines.flow.MutableStateFlow<vea.raceremote.control.CarConnectionState> mutableState;
    private boolean opened;
    private java.lang.Long pending;
    private long sentAt;
    private long sequence;
    private okhttp3.WebSocket socket;
    private final kotlinx.coroutines.flow.StateFlow<vea.raceremote.control.CarConnectionState> state;
    private int steering;
    private int throttle;
    private final java.util.concurrent.ScheduledExecutorService timer;
    private long token;
    private final boolean traceAllCommands;




    /* JADX INFO: renamed from: $r8$lambda$wzkrbIx3i_VuZ7AmU7Z53E-PcM8, reason: not valid java name */
    public static /* synthetic */ void m5979$r8$lambda$wzkrbIx3i_VuZ7AmU7Z53EPcM8(vea.raceremote.control.CarControlClient r0) {
            _init_$lambda$1(r0)
            return
    }

    static {
            vea.raceremote.control.LiveLiterals$CarControlClientKt r0 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE
            int r0 = r0.m6040Int$classCarControlClient()
            vea.raceremote.control.CarControlClient.$stable = r0
            return
    }

    public CarControlClient() {
            r6 = this;
            r1 = 0
            r2 = 0
            r3 = 0
            r4 = 7
            r5 = 0
            r0 = r6
            r0.<init>(r1, r2, r3, r4, r5)
            return
    }

    public CarControlClient(kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> r10, boolean r11, kotlin.jvm.functions.Function0<java.lang.Long> r12) {
            r9 = this;
            java.lang.String r0 = "diagnostics"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r10, r0)
            java.lang.String r0 = "clockMs"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r12, r0)
            r9.<init>()
            r9.diagnostics = r10
            r9.traceAllCommands = r11
            r9.clockMs = r12
            vea.raceremote.control.CarConnectionState r0 = new vea.raceremote.control.CarConnectionState
            r2 = 0
            r3 = 0
            r4 = 0
            r5 = 0
            r6 = 0
            r7 = 31
            r8 = 0
            r1 = r0
            r1.<init>(r2, r3, r4, r5, r6, r7, r8)
            kotlinx.coroutines.flow.MutableStateFlow r0 = kotlinx.coroutines.flow.StateFlowKt.MutableStateFlow(r0)
            r9.mutableState = r0
            kotlinx.coroutines.flow.StateFlow r0 = kotlinx.coroutines.flow.FlowKt.asStateFlow(r0)
            r9.state = r0
            java.util.concurrent.ScheduledExecutorService r1 = java.util.concurrent.Executors.newSingleThreadScheduledExecutor()
            r9.timer = r1
            vea.raceremote.control.CarControlClient$$ExternalSyntheticLambda0 r2 = new vea.raceremote.control.CarControlClient$$ExternalSyntheticLambda0
            r2.<init>(r9)
            vea.raceremote.control.LiveLiterals$CarControlClientKt r0 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE
            long r3 = r0.m6053Long$arg1$callscheduleAtFixedRate$classCarControlClient()
            vea.raceremote.control.LiveLiterals$CarControlClientKt r0 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE
            long r5 = r0.m6054Long$arg2$callscheduleAtFixedRate$classCarControlClient()
            java.util.concurrent.TimeUnit r7 = java.util.concurrent.TimeUnit.MILLISECONDS
            r1.scheduleAtFixedRate(r2, r3, r5, r7)
            return
    }

    public /* synthetic */ CarControlClient(kotlin.jvm.functions.Function1 r1, boolean r2, kotlin.jvm.functions.Function0 r3, int r4, kotlin.jvm.internal.DefaultConstructorMarker r5) {
            r0 = this;
            r5 = r4 & 1
            if (r5 == 0) goto L8
            vea.raceremote.control.CarControlClient$1 r1 = vea.raceremote.control.CarControlClient.AnonymousClass1.INSTANCE
            kotlin.jvm.functions.Function1 r1 = (kotlin.jvm.functions.Function1) r1
        L8:
            r5 = r4 & 2
            if (r5 == 0) goto L12
            vea.raceremote.control.LiveLiterals$CarControlClientKt r2 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE
            boolean r2 = r2.m6003Boolean$paramtraceAllCommands$classCarControlClient()
        L12:
            r4 = r4 & 4
            if (r4 == 0) goto L1a
            vea.raceremote.control.CarControlClient$2 r3 = vea.raceremote.control.CarControlClient.AnonymousClass2.INSTANCE
            kotlin.jvm.functions.Function0 r3 = (kotlin.jvm.functions.Function0) r3
        L1a:
            r0.<init>(r1, r2, r3)
            return
    }

    private static final void _init_$lambda$1(vea.raceremote.control.CarControlClient r1) {
            java.lang.String r0 = "this$0"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r1, r0)
            monitor-enter(r1)
            r0 = 0
            r1.tick()     // Catch: java.lang.Throwable -> Le
            kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> Le
            monitor-exit(r1)
            return
        Le:
            r0 = move-exception
            monitor-exit(r1)
            throw r0
    }

    public static final /* synthetic */ kotlin.jvm.functions.Function0 access$getClockMs$p(vea.raceremote.control.CarControlClient r1) {
            kotlin.jvm.functions.Function0<java.lang.Long> r0 = r1.clockMs
            return r0
    }

    public static final /* synthetic */ kotlin.jvm.functions.Function1 access$getDiagnostics$p(vea.raceremote.control.CarControlClient r1) {
            kotlin.jvm.functions.Function1<java.lang.String, kotlin.Unit> r0 = r1.diagnostics
            return r0
    }

    public static final /* synthetic */ long access$getGeneration$p(vea.raceremote.control.CarControlClient r2) {
            long r0 = r2.generation
            return r0
    }

    public static final /* synthetic */ kotlinx.coroutines.flow.MutableStateFlow access$getMutableState$p(vea.raceremote.control.CarControlClient r1) {
            kotlinx.coroutines.flow.MutableStateFlow<vea.raceremote.control.CarConnectionState> r0 = r1.mutableState
            return r0
    }

    public static final /* synthetic */ java.lang.Long access$getPending$p(vea.raceremote.control.CarControlClient r1) {
            java.lang.Long r0 = r1.pending
            return r0
    }

    public static final /* synthetic */ long access$getSentAt$p(vea.raceremote.control.CarControlClient r2) {
            long r0 = r2.sentAt
            return r0
    }

    public static final /* synthetic */ long access$getSequence$p(vea.raceremote.control.CarControlClient r2) {
            long r0 = r2.sequence
            return r0
    }

    public static final /* synthetic */ long access$getToken$p(vea.raceremote.control.CarControlClient r2) {
            long r0 = r2.token
            return r0
    }

    public static final /* synthetic */ boolean access$getTraceAllCommands$p(vea.raceremote.control.CarControlClient r1) {
            boolean r0 = r1.traceAllCommands
            return r0
    }

    public static final /* synthetic */ void access$send(vea.raceremote.control.CarControlClient r0, vea.raceremote.control.ControlPacket r1) {
            r0.send(r1)
            return
    }

    public static final /* synthetic */ void access$setOpened$p(vea.raceremote.control.CarControlClient r0, boolean r1) {
            r0.opened = r1
            return
    }

    public static final /* synthetic */ void access$setPending$p(vea.raceremote.control.CarControlClient r0, java.lang.Long r1) {
            r0.pending = r1
            return
    }

    public static final /* synthetic */ void access$setSequence$p(vea.raceremote.control.CarControlClient r0, long r1) {
            r0.sequence = r1
            return
    }

    public static final /* synthetic */ void access$setToken$p(vea.raceremote.control.CarControlClient r0, long r1) {
            r0.token = r1
            return
    }

    public static /* synthetic */ void connect$default(vea.raceremote.control.CarControlClient r0, java.lang.String r1, okhttp3.OkHttpClient r2, int r3, java.lang.Long r4, int r5, java.lang.Object r6) {
            r6 = r5 & 4
            if (r6 == 0) goto La
            vea.raceremote.control.LiveLiterals$CarControlClientKt r3 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE
            int r3 = r3.m6041Int$paramport$funconnect$classCarControlClient()
        La:
            r5 = r5 & 8
            if (r5 == 0) goto Lf
            r4 = 0
        Lf:
            r0.connect(r1, r2, r3, r4)
            return
    }

    public static /* synthetic */ void disconnect$default(vea.raceremote.control.CarControlClient r0, java.lang.String r1, int r2, java.lang.Object r3) {
            r2 = r2 & 1
            if (r2 == 0) goto La
            vea.raceremote.control.LiveLiterals$CarControlClientKt r1 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE
            java.lang.String r1 = r1.m6109String$parammessage$fundisconnect$classCarControlClient()
        La:
            r0.disconnect(r1)
            return
    }

    private final void send(vea.raceremote.control.ControlPacket r7) {
            r6 = this;
            int r0 = r7.getKind()
            r1 = 1
            if (r0 != r1) goto L12
            kotlin.jvm.functions.Function1<java.lang.String, kotlin.Unit> r0 = r6.diagnostics
            vea.raceremote.control.LiveLiterals$CarControlClientKt r2 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE
            java.lang.String r2 = r2.m6105String$arg0$callinvoke$branch$if$funsend$classCarControlClient()
            r0.invoke(r2)
        L12:
            boolean r0 = r6.traceAllCommands
            if (r0 != 0) goto L25
            long r2 = r7.getSequence()
            vea.raceremote.control.LiveLiterals$CarControlClientKt r0 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE
            int r0 = r0.m6018Int$$this$calltoLong$arg1$calllessOrEqual$else$cond$if1$funsend$classCarControlClient()
            long r4 = (long) r0
            int r0 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r0 > 0) goto L57
        L25:
            kotlin.jvm.functions.Function1<java.lang.String, kotlin.Unit> r0 = r6.diagnostics
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            vea.raceremote.control.LiveLiterals$CarControlClientKt r3 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE
            java.lang.String r3 = r3.m6059String$0$str$arg0$callinvoke$branch$if1$funsend$classCarControlClient()
            java.lang.StringBuilder r2 = r2.append(r3)
            int r3 = r7.getKind()
            java.lang.StringBuilder r2 = r2.append(r3)
            vea.raceremote.control.LiveLiterals$CarControlClientKt r3 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE
            java.lang.String r3 = r3.m6072String$2$str$arg0$callinvoke$branch$if1$funsend$classCarControlClient()
            java.lang.StringBuilder r2 = r2.append(r3)
            long r3 = r7.getSequence()
            java.lang.StringBuilder r2 = r2.append(r3)
            java.lang.String r2 = r2.toString()
            r0.invoke(r2)
        L57:
            long r2 = r7.getSequence()
            java.lang.Long r0 = java.lang.Long.valueOf(r2)
            r6.pending = r0
            kotlin.jvm.functions.Function0<java.lang.Long> r0 = r6.clockMs
            java.lang.Object r0 = r0.invoke()
            java.lang.Number r0 = (java.lang.Number) r0
            long r2 = r0.longValue()
            r6.sentAt = r2
            okhttp3.WebSocket r0 = r6.socket
            r2 = 0
            if (r0 == 0) goto L8e
            byte[] r3 = r7.encode()
            int r4 = r3.length
            byte[] r3 = java.util.Arrays.copyOf(r3, r4)
            okio.ByteString r3 = okio.ByteString.of(r3)
            boolean r0 = r0.send(r3)
            vea.raceremote.control.LiveLiterals$CarControlClientKt r3 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE
            boolean r3 = r3.m5991Boolean$arg1$callEQEQ$$this$callnot$cond$if2$funsend$classCarControlClient()
            if (r0 != r3) goto L8e
            goto L8f
        L8e:
            r1 = r2
        L8f:
            if (r1 != 0) goto L9a
            vea.raceremote.control.LiveLiterals$CarControlClientKt r0 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE
            java.lang.String r0 = r0.m6098String$arg0$calldisconnect$branch$if2$funsend$classCarControlClient()
            r6.disconnect(r0)
        L9a:
            return
    }

    private final void tick() {
            r14 = this;
            okhttp3.WebSocket r0 = r14.socket
            if (r0 != 0) goto L5
            return
        L5:
            kotlin.jvm.functions.Function0<java.lang.Long> r0 = r14.clockMs
            java.lang.Object r0 = r0.invoke()
            java.lang.Number r0 = (java.lang.Number) r0
            long r0 = r0.longValue()
            boolean r2 = r14.traceAllCommands
            if (r2 == 0) goto L78
            java.lang.Long r2 = r14.lastTickAt
            if (r2 == 0) goto L78
            java.lang.Number r2 = (java.lang.Number) r2
            long r2 = r2.longValue()
            r4 = 0
            long r5 = r0 - r2
            vea.raceremote.control.LiveLiterals$CarControlClientKt r7 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE
            int r7 = r7.m6016Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient()
            long r7 = (long) r7
            int r5 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r5 < 0) goto L77
            kotlin.jvm.functions.Function1<java.lang.String, kotlin.Unit> r5 = r14.diagnostics
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            r6.<init>()
            vea.raceremote.control.LiveLiterals$CarControlClientKt r7 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE
            java.lang.String r7 = r7.m6055String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient()
            java.lang.StringBuilder r6 = r6.append(r7)
            long r7 = r0 - r2
            java.lang.StringBuilder r6 = r6.append(r7)
            vea.raceremote.control.LiveLiterals$CarControlClientKt r7 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE
            java.lang.String r7 = r7.m6070String$2$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient()
            java.lang.StringBuilder r6 = r6.append(r7)
            java.lang.Long r7 = r14.pending
            java.lang.StringBuilder r6 = r6.append(r7)
            vea.raceremote.control.LiveLiterals$CarControlClientKt r7 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE
            java.lang.String r7 = r7.m6077String$4$str$arg0$callinvoke$branch$if$fun$anonymous$$arg0$calllet$else$when$branch$if1$funtick$classCarControlClient()
            java.lang.StringBuilder r6 = r6.append(r7)
            okhttp3.WebSocket r7 = r14.socket
            if (r7 == 0) goto L6b
            long r7 = r7.queueSize()
            java.lang.Long r7 = java.lang.Long.valueOf(r7)
            goto L6c
        L6b:
            r7 = 0
        L6c:
            java.lang.StringBuilder r6 = r6.append(r7)
            java.lang.String r6 = r6.toString()
            r5.invoke(r6)
        L77:
        L78:
            java.lang.Long r2 = java.lang.Long.valueOf(r0)
            r14.lastTickAt = r2
            long r2 = r14.sentAt
            long r2 = r0 - r2
            java.lang.Long r4 = r14.pending
            if (r4 == 0) goto L8d
            r4 = 200(0xc8, double:9.9E-322)
            int r4 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r4 >= 0) goto La4
        L8d:
            long r4 = r14.token
            vea.raceremote.control.LiveLiterals$CarControlClientKt r6 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE
            long r6 = r6.m6052Long$arg1$callEQEQ$cond$else$cond$if2$funtick$classCarControlClient()
            int r4 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r4 != 0) goto Lae
            vea.raceremote.control.LiveLiterals$CarControlClientKt r4 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE
            int r4 = r4.m6013Int$$this$calltoLong$arg1$callgreaterOrEqual$branch$else$cond$if2$funtick$classCarControlClient()
            long r4 = (long) r4
            int r4 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r4 < 0) goto Lae
        La4:
            vea.raceremote.control.LiveLiterals$CarControlClientKt r4 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE
            java.lang.String r4 = r4.m6099String$arg0$calldisconnect$branch$if2$funtick$classCarControlClient()
            r14.disconnect(r4)
            return
        Lae:
            boolean r4 = r14.opened
            if (r4 == 0) goto Le9
            kotlinx.coroutines.flow.MutableStateFlow<vea.raceremote.control.CarConnectionState> r4 = r14.mutableState
            java.lang.Object r4 = r4.getValue()
            vea.raceremote.control.CarConnectionState r4 = (vea.raceremote.control.CarConnectionState) r4
            boolean r4 = r4.getConnected()
            if (r4 == 0) goto Le9
            java.lang.Long r4 = r14.pending
            if (r4 != 0) goto Le9
            long r4 = r14.sequence
            vea.raceremote.control.LiveLiterals$CarControlClientKt r6 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE
            int r6 = r6.m6025Int$arg0$callplus$$this$calland$arg0$call$setsequence$$branch$if3$funtick$classCarControlClient()
            long r6 = (long) r6
            long r4 = r4 + r6
            vea.raceremote.control.LiveLiterals$CarControlClientKt r6 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE
            long r6 = r6.m6047Long$arg0$calland$arg0$call$setsequence$$branch$if3$funtick$classCarControlClient()
            long r4 = r4 & r6
            r14.sequence = r4
            vea.raceremote.control.ControlPacket r4 = new vea.raceremote.control.ControlPacket
            r7 = 2
            long r8 = r14.token
            long r10 = r14.sequence
            int r12 = r14.throttle
            int r13 = r14.steering
            r6 = r4
            r6.<init>(r7, r8, r10, r12, r13)
            r14.send(r4)
        Le9:
            return
    }

    public final synchronized void close() {
            r2 = this;
            monitor-enter(r2)
            r0 = 1
            r1 = 0
            disconnect$default(r2, r1, r0, r1)     // Catch: java.lang.Throwable -> Ld
            java.util.concurrent.ScheduledExecutorService r0 = r2.timer     // Catch: java.lang.Throwable -> Ld
            r0.shutdownNow()     // Catch: java.lang.Throwable -> Ld
            monitor-exit(r2)
            return
        Ld:
            r0 = move-exception
            monitor-exit(r2)
            throw r0
    }

    public final synchronized void connect(java.lang.String r21, okhttp3.OkHttpClient r22, int r23, java.lang.Long r24) {
            r20 = this;
            r7 = r20
            r0 = r21
            r8 = r23
            monitor-enter(r20)
            java.lang.String r1 = "host"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r0, r1)     // Catch: java.lang.Throwable -> L266
            java.lang.String r1 = "httpClient"
            r9 = r22
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r9, r1)     // Catch: java.lang.Throwable -> L266
            r1 = 0
            r2 = 1
            disconnect$default(r7, r1, r2, r1)     // Catch: java.lang.Throwable -> L266
            r10 = r0
            java.lang.CharSequence r10 = (java.lang.CharSequence) r10     // Catch: java.lang.Throwable -> L266
            char[] r11 = new char[r2]     // Catch: java.lang.Throwable -> L266
            vea.raceremote.control.LiveLiterals$CarControlClientKt r1 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L266
            char r1 = r1.m6004Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$funconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L266
            r3 = 0
            r11[r3] = r1     // Catch: java.lang.Throwable -> L266
            r12 = 0
            r13 = 0
            r14 = 6
            r15 = 0
            java.util.List r1 = kotlin.text.StringsKt.split$default(r10, r11, r12, r13, r14, r15)     // Catch: java.lang.Throwable -> L266
            java.lang.Iterable r1 = (java.lang.Iterable) r1     // Catch: java.lang.Throwable -> L266
            r4 = 0
            java.util.ArrayList r5 = new java.util.ArrayList     // Catch: java.lang.Throwable -> L266
            r6 = 10
            int r10 = kotlin.collections.CollectionsKt.collectionSizeOrDefault(r1, r6)     // Catch: java.lang.Throwable -> L266
            r5.<init>(r10)     // Catch: java.lang.Throwable -> L266
            java.util.Collection r5 = (java.util.Collection) r5     // Catch: java.lang.Throwable -> L266
            r10 = r1
            r11 = 0
            java.util.Iterator r12 = r10.iterator()     // Catch: java.lang.Throwable -> L266
        L44:
            boolean r13 = r12.hasNext()     // Catch: java.lang.Throwable -> L266
            if (r13 == 0) goto L5b
            java.lang.Object r13 = r12.next()     // Catch: java.lang.Throwable -> L266
            r14 = r13
            java.lang.String r14 = (java.lang.String) r14     // Catch: java.lang.Throwable -> L266
            r15 = 0
            java.lang.Integer r2 = kotlin.text.StringsKt.toIntOrNull(r14)     // Catch: java.lang.Throwable -> L266
            r5.add(r2)     // Catch: java.lang.Throwable -> L266
            r2 = 1
            goto L44
        L5b:
            r2 = r5
            java.util.List r2 = (java.util.List) r2     // Catch: java.lang.Throwable -> L266
            r10 = r2
            int r1 = r10.size()     // Catch: java.lang.Throwable -> L266
            vea.raceremote.control.LiveLiterals$CarControlClientKt r2 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L266
            int r2 = r2.m6037Int$arg1$callEQEQ$cond$cond$vallocal$funconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L266
            if (r1 != r2) goto L14a
            r1 = r10
            java.lang.Iterable r1 = (java.lang.Iterable) r1     // Catch: java.lang.Throwable -> L266
            r2 = 0
            boolean r4 = r1 instanceof java.util.Collection     // Catch: java.lang.Throwable -> L266
            if (r4 == 0) goto L80
            r4 = r1
            java.util.Collection r4 = (java.util.Collection) r4     // Catch: java.lang.Throwable -> L266
            boolean r4 = r4.isEmpty()     // Catch: java.lang.Throwable -> L266
            if (r4 == 0) goto L80
            r1 = 1
            goto Lb7
        L80:
            java.util.Iterator r4 = r1.iterator()     // Catch: java.lang.Throwable -> L266
        L84:
            boolean r5 = r4.hasNext()     // Catch: java.lang.Throwable -> L266
            if (r5 == 0) goto Lb6
            java.lang.Object r5 = r4.next()     // Catch: java.lang.Throwable -> L266
            r11 = r5
            java.lang.Integer r11 = (java.lang.Integer) r11     // Catch: java.lang.Throwable -> L266
            r12 = 0
            if (r11 == 0) goto Lb1
            kotlin.ranges.IntRange r13 = new kotlin.ranges.IntRange     // Catch: java.lang.Throwable -> L266
            vea.raceremote.control.LiveLiterals$CarControlClientKt r14 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L266
            int r14 = r14.m6012Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$vallocal$funconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L266
            vea.raceremote.control.LiveLiterals$CarControlClientKt r15 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L266
            int r15 = r15.m6028Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$vallocal$funconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L266
            r13.<init>(r14, r15)     // Catch: java.lang.Throwable -> L266
            int r14 = r11.intValue()     // Catch: java.lang.Throwable -> L266
            boolean r13 = r13.contains(r14)     // Catch: java.lang.Throwable -> L266
            if (r13 == 0) goto Lb1
            r11 = 1
            goto Lb2
        Lb1:
            r11 = r3
        Lb2:
            if (r11 != 0) goto L84
            r1 = r3
            goto Lb7
        Lb6:
            r1 = 1
        Lb7:
            if (r1 == 0) goto L148
            java.lang.Object r1 = r10.get(r3)     // Catch: java.lang.Throwable -> L266
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch: java.lang.Throwable -> L266
            if (r1 != 0) goto Lc2
        Lc1:
            goto Lc9
        Lc2:
            int r1 = r1.intValue()     // Catch: java.lang.Throwable -> L266
            if (r1 == r6) goto L145
            goto Lc1
        Lc9:
            java.lang.Object r1 = r10.get(r3)     // Catch: java.lang.Throwable -> L266
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch: java.lang.Throwable -> L266
            if (r1 != 0) goto Ld2
        Ld1:
            goto Ldb
        Ld2:
            int r1 = r1.intValue()     // Catch: java.lang.Throwable -> L266
            r2 = 127(0x7f, float:1.78E-43)
            if (r1 == r2) goto L145
            goto Ld1
        Ldb:
            java.lang.Object r1 = r10.get(r3)     // Catch: java.lang.Throwable -> L266
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch: java.lang.Throwable -> L266
            if (r1 != 0) goto Le5
            r1 = 1
            goto L101
        Le5:
            int r1 = r1.intValue()     // Catch: java.lang.Throwable -> L266
            r2 = 192(0xc0, float:2.69E-43)
            if (r1 != r2) goto L100
            r1 = 1
            java.lang.Object r2 = r10.get(r1)     // Catch: java.lang.Throwable -> L266
            java.lang.Integer r2 = (java.lang.Integer) r2     // Catch: java.lang.Throwable -> L266
            if (r2 != 0) goto Lf7
        Lf6:
            goto L101
        Lf7:
            int r2 = r2.intValue()     // Catch: java.lang.Throwable -> L266
            r4 = 168(0xa8, float:2.35E-43)
            if (r2 == r4) goto L146
            goto Lf6
        L100:
            r1 = 1
        L101:
            vea.raceremote.control.LiveLiterals$CarControlClientKt r2 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L266
            int r2 = r2.m6024Int$arg0$callget$arg0$callEQEQ$cond$else$branch$vallocal$funconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L266
            java.lang.Object r2 = r10.get(r2)     // Catch: java.lang.Throwable -> L266
            java.lang.Integer r2 = (java.lang.Integer) r2     // Catch: java.lang.Throwable -> L266
            vea.raceremote.control.LiveLiterals$CarControlClientKt r4 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L266
            int r4 = r4.m6038Int$arg1$callEQEQ$cond$else$branch$vallocal$funconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L266
            if (r2 != 0) goto L116
        L115:
            goto L14b
        L116:
            int r2 = r2.intValue()     // Catch: java.lang.Throwable -> L266
            if (r2 != r4) goto L115
            vea.raceremote.control.LiveLiterals$CarControlClientKt r2 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L266
            int r2 = r2.m6011Int$$this$callrangeTo$$this$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L266
            vea.raceremote.control.LiveLiterals$CarControlClientKt r4 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L266
            int r4 = r4.m6027Int$arg0$callrangeTo$$this$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L266
            vea.raceremote.control.LiveLiterals$CarControlClientKt r5 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L266
            int r5 = r5.m6023Int$arg0$callget$arg0$callCHECK_NOT_NULL$arg0$callcontains$branch$else$branch$vallocal$funconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L266
            java.lang.Object r5 = r10.get(r5)     // Catch: java.lang.Throwable -> L266
            kotlin.jvm.internal.Intrinsics.checkNotNull(r5)     // Catch: java.lang.Throwable -> L266
            java.lang.Number r5 = (java.lang.Number) r5     // Catch: java.lang.Throwable -> L266
            int r5 = r5.intValue()     // Catch: java.lang.Throwable -> L266
            if (r2 > r5) goto L141
            if (r5 > r4) goto L141
            r2 = r1
            goto L142
        L141:
            r2 = r3
        L142:
            if (r2 == 0) goto L115
            goto L146
        L145:
            r1 = 1
        L146:
            r2 = r1
            goto L14c
        L148:
            r1 = 1
            goto L14b
        L14a:
            r1 = 1
        L14b:
            r2 = r3
        L14c:
            r11 = r2
            if (r11 == 0) goto L249
            vea.raceremote.control.LiveLiterals$CarControlClientKt r2 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L266
            int r2 = r2.m6010Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L266
            vea.raceremote.control.LiveLiterals$CarControlClientKt r4 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L266
            int r4 = r4.m6026Int$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$funconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L266
            if (r8 > r4) goto L161
            if (r2 > r8) goto L161
            r2 = r1
            goto L162
        L161:
            r2 = r3
        L162:
            if (r2 != 0) goto L166
            goto L249
        L166:
            if (r24 == 0) goto L1a1
            kotlin.ranges.LongRange r1 = new kotlin.ranges.LongRange     // Catch: java.lang.Throwable -> L266
            vea.raceremote.control.LiveLiterals$CarControlClientKt r2 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L266
            int r2 = r2.m6009Int$$this$callrangeTo$$this$callcontains$$this$callnot$branch$cond$if1$funconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L266
            long r2 = (long) r2     // Catch: java.lang.Throwable -> L266
            vea.raceremote.control.LiveLiterals$CarControlClientKt r4 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L266
            long r4 = r4.m6048Long$arg0$callrangeTo$$this$callcontains$$this$callnot$branch$cond$if1$funconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L266
            r1.<init>(r2, r4)     // Catch: java.lang.Throwable -> L266
            long r2 = r24.longValue()     // Catch: java.lang.Throwable -> L266
            boolean r1 = r1.contains(r2)     // Catch: java.lang.Throwable -> L266
            if (r1 != 0) goto L1a1
            kotlinx.coroutines.flow.MutableStateFlow<vea.raceremote.control.CarConnectionState> r1 = r7.mutableState     // Catch: java.lang.Throwable -> L266
            vea.raceremote.control.CarConnectionState r2 = new vea.raceremote.control.CarConnectionState     // Catch: java.lang.Throwable -> L266
            vea.raceremote.control.LiveLiterals$CarControlClientKt r3 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L266
            java.lang.String r13 = r3.m6087String$arg0$call$init$$arg0$call$setvalue$$branch$if1$funconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L266
            r14 = 0
            r15 = 0
            r16 = 0
            r17 = 0
            r18 = 30
            r19 = 0
            r12 = r2
            r12.<init>(r13, r14, r15, r16, r17, r18, r19)     // Catch: java.lang.Throwable -> L266
            r1.setValue(r2)     // Catch: java.lang.Throwable -> L266
            monitor-exit(r20)
            return
        L1a1:
            long r3 = r7.generation     // Catch: java.lang.Throwable -> L266
            kotlin.jvm.internal.Ref$ObjectRef r6 = new kotlin.jvm.internal.Ref$ObjectRef     // Catch: java.lang.Throwable -> L266
            r6.<init>()     // Catch: java.lang.Throwable -> L266
            kotlin.jvm.functions.Function0<java.lang.Long> r1 = r7.clockMs     // Catch: java.lang.Throwable -> L266
            java.lang.Object r1 = r1.invoke()     // Catch: java.lang.Throwable -> L266
            java.lang.Number r1 = (java.lang.Number) r1     // Catch: java.lang.Throwable -> L266
            long r1 = r1.longValue()     // Catch: java.lang.Throwable -> L266
            r7.sentAt = r1     // Catch: java.lang.Throwable -> L266
            kotlinx.coroutines.flow.MutableStateFlow<vea.raceremote.control.CarConnectionState> r1 = r7.mutableState     // Catch: java.lang.Throwable -> L266
            vea.raceremote.control.CarConnectionState r2 = new vea.raceremote.control.CarConnectionState     // Catch: java.lang.Throwable -> L266
            vea.raceremote.control.LiveLiterals$CarControlClientKt r5 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L266
            java.lang.String r13 = r5.m6089String$arg0$call$init$$arg0$call$setvalue$$funconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L266
            r14 = 0
            vea.raceremote.control.LiveLiterals$CarControlClientKt r5 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L266
            boolean r15 = r5.m5992Boolean$arg2$call$init$$arg0$call$setvalue$$funconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L266
            r16 = 0
            r17 = 0
            r18 = 26
            r19 = 0
            r12 = r2
            r12.<init>(r13, r14, r15, r16, r17, r18, r19)     // Catch: java.lang.Throwable -> L266
            r1.setValue(r2)     // Catch: java.lang.Throwable -> L266
            okhttp3.OkHttpClient$Builder r1 = r22.newBuilder()     // Catch: java.lang.Throwable -> L266
            vea.raceremote.control.ControlSocketFactory r2 = new vea.raceremote.control.ControlSocketFactory     // Catch: java.lang.Throwable -> L266
            javax.net.SocketFactory r5 = r22.socketFactory()     // Catch: java.lang.Throwable -> L266
            java.lang.String r12 = "httpClient.socketFactory()"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r5, r12)     // Catch: java.lang.Throwable -> L266
            r2.<init>(r5)     // Catch: java.lang.Throwable -> L266
            javax.net.SocketFactory r2 = (javax.net.SocketFactory) r2     // Catch: java.lang.Throwable -> L266
            okhttp3.OkHttpClient$Builder r1 = r1.socketFactory(r2)     // Catch: java.lang.Throwable -> L266
            okhttp3.OkHttpClient r1 = r1.build()     // Catch: java.lang.Throwable -> L266
            r12 = r1
            if (r24 != 0) goto L1fc
            vea.raceremote.control.LiveLiterals$CarControlClientKt r1 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L266
            java.lang.String r1 = r1.m6107String$branch$if$valpath$funconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L266
            goto L1fe
        L1fc:
            java.lang.String r1 = "/control/identity"
        L1fe:
            r13 = r1
            okhttp3.Request$Builder r1 = new okhttp3.Request$Builder     // Catch: java.lang.Throwable -> L266
            r1.<init>()     // Catch: java.lang.Throwable -> L266
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L266
            r2.<init>()     // Catch: java.lang.Throwable -> L266
            vea.raceremote.control.LiveLiterals$CarControlClientKt r5 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L266
            java.lang.String r5 = r5.m6063String$0$str$arg0$callurl$$this$callbuild$arg0$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L266
            java.lang.StringBuilder r2 = r2.append(r5)     // Catch: java.lang.Throwable -> L266
            java.lang.StringBuilder r2 = r2.append(r0)     // Catch: java.lang.Throwable -> L266
            vea.raceremote.control.LiveLiterals$CarControlClientKt r5 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L266
            java.lang.String r5 = r5.m6075String$2$str$arg0$callurl$$this$callbuild$arg0$callnewWebSocket$arg0$call$setsocket$$funconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L266
            java.lang.StringBuilder r2 = r2.append(r5)     // Catch: java.lang.Throwable -> L266
            java.lang.StringBuilder r2 = r2.append(r8)     // Catch: java.lang.Throwable -> L266
            java.lang.StringBuilder r2 = r2.append(r13)     // Catch: java.lang.Throwable -> L266
            java.lang.String r2 = r2.toString()     // Catch: java.lang.Throwable -> L266
            okhttp3.Request$Builder r1 = r1.url(r2)     // Catch: java.lang.Throwable -> L266
            okhttp3.Request r14 = r1.build()     // Catch: java.lang.Throwable -> L266
            vea.raceremote.control.CarControlClient$connect$1 r15 = new vea.raceremote.control.CarControlClient$connect$1     // Catch: java.lang.Throwable -> L266
            r1 = r15
            r2 = r20
            r5 = r24
            r1.<init>(r2, r3, r5, r6)     // Catch: java.lang.Throwable -> L266
            okhttp3.WebSocketListener r15 = (okhttp3.WebSocketListener) r15     // Catch: java.lang.Throwable -> L266
            okhttp3.WebSocket r1 = r12.newWebSocket(r14, r15)     // Catch: java.lang.Throwable -> L266
            r7.socket = r1     // Catch: java.lang.Throwable -> L266
            monitor-exit(r20)
            return
        L249:
            kotlinx.coroutines.flow.MutableStateFlow<vea.raceremote.control.CarConnectionState> r1 = r7.mutableState     // Catch: java.lang.Throwable -> L266
            vea.raceremote.control.CarConnectionState r2 = new vea.raceremote.control.CarConnectionState     // Catch: java.lang.Throwable -> L266
            vea.raceremote.control.LiveLiterals$CarControlClientKt r3 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L266
            java.lang.String r13 = r3.m6086String$arg0$call$init$$arg0$call$setvalue$$branch$if$funconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L266
            r14 = 0
            r15 = 0
            r16 = 0
            r17 = 0
            r18 = 30
            r19 = 0
            r12 = r2
            r12.<init>(r13, r14, r15, r16, r17, r18, r19)     // Catch: java.lang.Throwable -> L266
            r1.setValue(r2)     // Catch: java.lang.Throwable -> L266
            monitor-exit(r20)
            return
        L266:
            r0 = move-exception
            monitor-exit(r20)
            throw r0
    }

    public final synchronized void disconnect(java.lang.String r14) {
            r13 = this;
            monitor-enter(r13)
            java.lang.String r0 = "message"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r14, r0)     // Catch: java.lang.Throwable -> L111
            boolean r0 = r13.traceAllCommands     // Catch: java.lang.Throwable -> L111
            r1 = 0
            if (r0 == 0) goto L76
            okhttp3.WebSocket r0 = r13.socket     // Catch: java.lang.Throwable -> L111
            if (r0 == 0) goto L76
            kotlin.jvm.functions.Function1<java.lang.String, kotlin.Unit> r0 = r13.diagnostics     // Catch: java.lang.Throwable -> L111
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L111
            r2.<init>()     // Catch: java.lang.Throwable -> L111
            vea.raceremote.control.LiveLiterals$CarControlClientKt r3 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L111
            java.lang.String r3 = r3.m6057String$0$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L111
            java.lang.StringBuilder r2 = r2.append(r3)     // Catch: java.lang.Throwable -> L111
            long r3 = r13.sequence     // Catch: java.lang.Throwable -> L111
            java.lang.StringBuilder r2 = r2.append(r3)     // Catch: java.lang.Throwable -> L111
            vea.raceremote.control.LiveLiterals$CarControlClientKt r3 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L111
            java.lang.String r3 = r3.m6071String$2$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L111
            java.lang.StringBuilder r2 = r2.append(r3)     // Catch: java.lang.Throwable -> L111
            java.lang.Long r3 = r13.pending     // Catch: java.lang.Throwable -> L111
            java.lang.StringBuilder r2 = r2.append(r3)     // Catch: java.lang.Throwable -> L111
            vea.raceremote.control.LiveLiterals$CarControlClientKt r3 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L111
            java.lang.String r3 = r3.m6078String$4$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L111
            java.lang.StringBuilder r2 = r2.append(r3)     // Catch: java.lang.Throwable -> L111
            kotlin.jvm.functions.Function0<java.lang.Long> r3 = r13.clockMs     // Catch: java.lang.Throwable -> L111
            java.lang.Object r3 = r3.invoke()     // Catch: java.lang.Throwable -> L111
            java.lang.Number r3 = (java.lang.Number) r3     // Catch: java.lang.Throwable -> L111
            long r3 = r3.longValue()     // Catch: java.lang.Throwable -> L111
            long r5 = r13.sentAt     // Catch: java.lang.Throwable -> L111
            long r3 = r3 - r5
            java.lang.StringBuilder r2 = r2.append(r3)     // Catch: java.lang.Throwable -> L111
            vea.raceremote.control.LiveLiterals$CarControlClientKt r3 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L111
            java.lang.String r3 = r3.m6081String$6$str$arg0$callinvoke$branch$if$fundisconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L111
            java.lang.StringBuilder r2 = r2.append(r3)     // Catch: java.lang.Throwable -> L111
            okhttp3.WebSocket r3 = r13.socket     // Catch: java.lang.Throwable -> L111
            if (r3 == 0) goto L6a
            long r3 = r3.queueSize()     // Catch: java.lang.Throwable -> L111
            java.lang.Long r3 = java.lang.Long.valueOf(r3)     // Catch: java.lang.Throwable -> L111
            goto L6b
        L6a:
            r3 = r1
        L6b:
            java.lang.StringBuilder r2 = r2.append(r3)     // Catch: java.lang.Throwable -> L111
            java.lang.String r2 = r2.toString()     // Catch: java.lang.Throwable -> L111
            r0.invoke(r2)     // Catch: java.lang.Throwable -> L111
        L76:
            kotlin.jvm.functions.Function1<java.lang.String, kotlin.Unit> r0 = r13.diagnostics     // Catch: java.lang.Throwable -> L111
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L111
            r2.<init>()     // Catch: java.lang.Throwable -> L111
            vea.raceremote.control.LiveLiterals$CarControlClientKt r3 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L111
            java.lang.String r3 = r3.m6062String$0$str$arg0$callinvoke$fundisconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L111
            java.lang.StringBuilder r2 = r2.append(r3)     // Catch: java.lang.Throwable -> L111
            java.lang.StringBuilder r2 = r2.append(r14)     // Catch: java.lang.Throwable -> L111
            java.lang.String r2 = r2.toString()     // Catch: java.lang.Throwable -> L111
            r0.invoke(r2)     // Catch: java.lang.Throwable -> L111
            long r2 = r13.generation     // Catch: java.lang.Throwable -> L111
            r4 = 1
            long r2 = r2 + r4
            r13.generation = r2     // Catch: java.lang.Throwable -> L111
            okhttp3.WebSocket r0 = r13.socket     // Catch: java.lang.Throwable -> L111
            r13.socket = r1     // Catch: java.lang.Throwable -> L111
            long r2 = r13.token     // Catch: java.lang.Throwable -> L111
            vea.raceremote.control.LiveLiterals$CarControlClientKt r4 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L111
            long r4 = r4.m6049Long$arg1$callEQEQ$$this$callnot$cond$if1$fundisconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L111
            int r2 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r2 == 0) goto Lcb
            if (r0 == 0) goto Lcb
            vea.raceremote.control.ControlPacket r2 = new vea.raceremote.control.ControlPacket     // Catch: java.lang.Throwable -> L111
            r4 = 3
            long r5 = r13.token     // Catch: java.lang.Throwable -> L111
            long r7 = r13.sequence     // Catch: java.lang.Throwable -> L111
            r9 = 0
            r10 = 0
            r11 = 24
            r12 = 0
            r3 = r2
            r3.<init>(r4, r5, r7, r9, r10, r11, r12)     // Catch: java.lang.Throwable -> L111
            byte[] r2 = r2.encode()     // Catch: java.lang.Throwable -> L111
            int r3 = r2.length     // Catch: java.lang.Throwable -> L111
            byte[] r2 = java.util.Arrays.copyOf(r2, r3)     // Catch: java.lang.Throwable -> L111
            okio.ByteString r2 = okio.ByteString.of(r2)     // Catch: java.lang.Throwable -> L111
            r0.send(r2)     // Catch: java.lang.Throwable -> L111
        Lcb:
            if (r0 == 0) goto Ld0
            r0.cancel()     // Catch: java.lang.Throwable -> L111
        Ld0:
            vea.raceremote.control.LiveLiterals$CarControlClientKt r2 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L111
            long r2 = r2.m6046Long$arg0$call$settoken$$fundisconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L111
            r13.token = r2     // Catch: java.lang.Throwable -> L111
            vea.raceremote.control.LiveLiterals$CarControlClientKt r2 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L111
            long r2 = r2.m6045Long$arg0$call$setsequence$$fundisconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L111
            r13.sequence = r2     // Catch: java.lang.Throwable -> L111
            r13.pending = r1     // Catch: java.lang.Throwable -> L111
            vea.raceremote.control.LiveLiterals$CarControlClientKt r2 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L111
            int r2 = r2.m6021Int$arg0$call$setthrottle$$fundisconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L111
            r13.throttle = r2     // Catch: java.lang.Throwable -> L111
            vea.raceremote.control.LiveLiterals$CarControlClientKt r2 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L111
            int r2 = r2.m6020Int$arg0$call$setsteering$$fundisconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L111
            r13.steering = r2     // Catch: java.lang.Throwable -> L111
            vea.raceremote.control.LiveLiterals$CarControlClientKt r2 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L111
            boolean r2 = r2.m5989Boolean$arg0$call$setopened$$fundisconnect$classCarControlClient()     // Catch: java.lang.Throwable -> L111
            r13.opened = r2     // Catch: java.lang.Throwable -> L111
            r13.lastTickAt = r1     // Catch: java.lang.Throwable -> L111
            kotlinx.coroutines.flow.MutableStateFlow<vea.raceremote.control.CarConnectionState> r1 = r13.mutableState     // Catch: java.lang.Throwable -> L111
            vea.raceremote.control.CarConnectionState r10 = new vea.raceremote.control.CarConnectionState     // Catch: java.lang.Throwable -> L111
            r4 = 0
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 30
            r9 = 0
            r2 = r10
            r3 = r14
            r2.<init>(r3, r4, r5, r6, r7, r8, r9)     // Catch: java.lang.Throwable -> L111
            r1.setValue(r10)     // Catch: java.lang.Throwable -> L111
            monitor-exit(r13)
            return
        L111:
            r14 = move-exception
            monitor-exit(r13)
            throw r14
    }

    public final kotlinx.coroutines.flow.StateFlow<vea.raceremote.control.CarConnectionState> getState() {
            r1 = this;
            kotlinx.coroutines.flow.StateFlow<vea.raceremote.control.CarConnectionState> r0 = r1.state
            return r0
    }

    public final synchronized void setInput(float r4, float r5) {
            r3 = this;
            monitor-enter(r3)
            boolean r0 = java.lang.Float.isInfinite(r4)     // Catch: java.lang.Throwable -> L78
            r1 = 1
            r2 = 0
            if (r0 != 0) goto L11
            boolean r0 = java.lang.Float.isNaN(r4)     // Catch: java.lang.Throwable -> L78
            if (r0 != 0) goto L11
            r0 = r1
            goto L12
        L11:
            r0 = r2
        L12:
            if (r0 == 0) goto L6d
            boolean r0 = java.lang.Float.isInfinite(r5)     // Catch: java.lang.Throwable -> L78
            if (r0 != 0) goto L21
            boolean r0 = java.lang.Float.isNaN(r5)     // Catch: java.lang.Throwable -> L78
            if (r0 != 0) goto L21
            goto L22
        L21:
            r1 = r2
        L22:
            if (r1 != 0) goto L25
            goto L6d
        L25:
            kotlinx.coroutines.flow.MutableStateFlow<vea.raceremote.control.CarConnectionState> r0 = r3.mutableState     // Catch: java.lang.Throwable -> L78
            java.lang.Object r0 = r0.getValue()     // Catch: java.lang.Throwable -> L78
            vea.raceremote.control.CarConnectionState r0 = (vea.raceremote.control.CarConnectionState) r0     // Catch: java.lang.Throwable -> L78
            boolean r0 = r0.getConnected()     // Catch: java.lang.Throwable -> L78
            if (r0 != 0) goto L35
            monitor-exit(r3)
            return
        L35:
            vea.raceremote.control.LiveLiterals$CarControlClientKt r0 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L78
            float r0 = r0.m6006Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient()     // Catch: java.lang.Throwable -> L78
            vea.raceremote.control.LiveLiterals$CarControlClientKt r1 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L78
            float r1 = r1.m6008Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient()     // Catch: java.lang.Throwable -> L78
            float r0 = kotlin.ranges.RangesKt.coerceIn(r4, r0, r1)     // Catch: java.lang.Throwable -> L78
            vea.raceremote.control.LiveLiterals$CarControlClientKt r1 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L78
            int r1 = r1.m6034Int$arg0$calltimes$$this$calltoInt$arg0$call$setthrottle$$funsetInput$classCarControlClient()     // Catch: java.lang.Throwable -> L78
            float r1 = (float) r1     // Catch: java.lang.Throwable -> L78
            float r0 = r0 * r1
            int r0 = (int) r0     // Catch: java.lang.Throwable -> L78
            r3.throttle = r0     // Catch: java.lang.Throwable -> L78
            vea.raceremote.control.LiveLiterals$CarControlClientKt r0 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L78
            float r0 = r0.m6005Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient()     // Catch: java.lang.Throwable -> L78
            vea.raceremote.control.LiveLiterals$CarControlClientKt r1 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L78
            float r1 = r1.m6007Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient()     // Catch: java.lang.Throwable -> L78
            float r0 = kotlin.ranges.RangesKt.coerceIn(r5, r0, r1)     // Catch: java.lang.Throwable -> L78
            vea.raceremote.control.LiveLiterals$CarControlClientKt r1 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L78
            int r1 = r1.m6033Int$arg0$calltimes$$this$calltoInt$arg0$call$setsteering$$funsetInput$classCarControlClient()     // Catch: java.lang.Throwable -> L78
            float r1 = (float) r1     // Catch: java.lang.Throwable -> L78
            float r0 = r0 * r1
            int r0 = (int) r0     // Catch: java.lang.Throwable -> L78
            r3.steering = r0     // Catch: java.lang.Throwable -> L78
            monitor-exit(r3)
            return
        L6d:
            vea.raceremote.control.LiveLiterals$CarControlClientKt r0 = vea.raceremote.control.LiveLiterals$CarControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L78
            java.lang.String r0 = r0.m6095String$arg0$calldisconnect$branch$if$funsetInput$classCarControlClient()     // Catch: java.lang.Throwable -> L78
            r3.disconnect(r0)     // Catch: java.lang.Throwable -> L78
            monitor-exit(r3)
            return
        L78:
            r4 = move-exception
            monitor-exit(r3)
            throw r4
    }
}
