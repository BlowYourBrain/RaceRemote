package vea.raceremote.control;

/* JADX INFO: compiled from: CarControlConnection.kt */
/* JADX INFO: loaded from: classes4.dex */
@kotlin.Metadata(d1 = {"\u0000t\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u0007\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B=\u0012 \b\u0002\u0010\u0002\u001a\u001a\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0003\u0012\u0014\b\u0002\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\n0\t¢\u0006\u0002\u0010\u000bJ\u0006\u0010\u001f\u001a\u00020\nJ]\u0010 \u001a\u00020\n2\u0006\u0010!\u001a\u00020\u00042\u0006\u0010\"\u001a\u00020\u00052\u0012\u0010#\u001a\u000e\u0012\u0004\u0012\u00020$\u0012\u0004\u0012\u00020\n0\t2\n\b\u0002\u0010%\u001a\u0004\u0018\u00010\u00062\n\b\u0002\u0010&\u001a\u0004\u0018\u00010\u000f2\b\b\u0002\u0010'\u001a\u00020\u00062\n\b\u0002\u0010(\u001a\u0004\u0018\u00010\u0004¢\u0006\u0002\u0010)J\u0010\u0010*\u001a\u00020\n2\b\b\u0002\u0010+\u001a\u00020\u0004J\u0016\u0010,\u001a\u00020\n2\u0006\u0010-\u001a\u00020.2\u0006\u0010/\u001a\u00020.R\u000e\u0010\f\u001a\u00020\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\n0\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0010\u001a\u0004\u0018\u00010\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00140\u0013X\u0082\u0004¢\u0006\u0002\n\u0000R&\u0010\u0002\u001a\u001a\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00140\u0018¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u001aR\u0010\u0010\u001b\u001a\u0004\u0018\u00010\u001cX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u001d\u001a\u0004\u0018\u00010\u001eX\u0082\u000e¢\u0006\u0002\n\u0000¨\u00060"}, d2 = {"Lvea/raceremote/control/CarControlConnection;", "", "resolve", "Lkotlin/Function3;", "", "Lokhttp3/OkHttpClient;", "", "Lvea/raceremote/control/ControlEndpoint;", "diagnostics", "Lkotlin/Function1;", "", "(Lkotlin/jvm/functions/Function3;Lkotlin/jvm/functions/Function1;)V", "closed", "", "generation", "", "job", "Lkotlinx/coroutines/Job;", "mutableState", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Lvea/raceremote/control/CarConnectionState;", "scope", "Lkotlinx/coroutines/CoroutineScope;", "state", "Lkotlinx/coroutines/flow/StateFlow;", "getState", "()Lkotlinx/coroutines/flow/StateFlow;", "udp", "Lvea/raceremote/control/UdpControlClient;", "websocket", "Lvea/raceremote/control/CarControlClient;", "close", "connect", "host", "http", "bindUdp", "Ljava/net/DatagramSocket;", "expectedPort", "expectedChipId", "statusPort", "expectedTransport", "(Ljava/lang/String;Lokhttp3/OkHttpClient;Lkotlin/jvm/functions/Function1;Ljava/lang/Integer;Ljava/lang/Long;ILjava/lang/String;)V", "disconnect", "message", "setInput", "throttle", "", "steering", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class CarControlConnection {
    public static final int $stable = 0;
    private boolean closed;
    private final kotlin.jvm.functions.Function1<java.lang.String, kotlin.Unit> diagnostics;
    private long generation;
    private kotlinx.coroutines.Job job;
    private final kotlinx.coroutines.flow.MutableStateFlow<vea.raceremote.control.CarConnectionState> mutableState;
    private final kotlin.jvm.functions.Function3<java.lang.String, okhttp3.OkHttpClient, java.lang.Integer, vea.raceremote.control.ControlEndpoint> resolve;
    private final kotlinx.coroutines.CoroutineScope scope;
    private final kotlinx.coroutines.flow.StateFlow<vea.raceremote.control.CarConnectionState> state;
    private vea.raceremote.control.UdpControlClient udp;
    private vea.raceremote.control.CarControlClient websocket;

    /* JADX INFO: renamed from: vea.raceremote.control.CarControlConnection$1, reason: invalid class name */
    /* JADX INFO: compiled from: CarControlConnection.kt */
    @kotlin.Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    /* synthetic */ class AnonymousClass1 extends kotlin.jvm.internal.FunctionReferenceImpl implements kotlin.jvm.functions.Function3<java.lang.String, okhttp3.OkHttpClient, java.lang.Integer, vea.raceremote.control.ControlEndpoint> {
        AnonymousClass1(java.lang.Object r8) {
                r7 = this;
                r1 = 3
                java.lang.Class<vea.raceremote.control.ControlEndpointProbe> r3 = vea.raceremote.control.ControlEndpointProbe.class
                java.lang.String r4 = "load"
                java.lang.String r5 = "load(Ljava/lang/String;Lokhttp3/OkHttpClient;I)Lvea/raceremote/control/ControlEndpoint;"
                r6 = 0
                r0 = r7
                r2 = r8
                r0.<init>(r1, r2, r3, r4, r5, r6)
                return
        }

        @Override // kotlin.jvm.functions.Function3
        public /* bridge */ /* synthetic */ vea.raceremote.control.ControlEndpoint invoke(java.lang.String r4, okhttp3.OkHttpClient r5, java.lang.Integer r6) {
                r3 = this;
                r0 = r4
                java.lang.String r0 = (java.lang.String) r0
                r1 = r5
                okhttp3.OkHttpClient r1 = (okhttp3.OkHttpClient) r1
                r2 = r6
                java.lang.Number r2 = (java.lang.Number) r2
                int r2 = r2.intValue()
                vea.raceremote.control.ControlEndpoint r0 = r3.invoke(r0, r1, r2)
                return r0
        }

        public final vea.raceremote.control.ControlEndpoint invoke(java.lang.String r2, okhttp3.OkHttpClient r3, int r4) {
                r1 = this;
                java.lang.String r0 = "p0"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                java.lang.String r0 = "p1"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
                java.lang.Object r0 = r1.receiver
                vea.raceremote.control.ControlEndpointProbe r0 = (vea.raceremote.control.ControlEndpointProbe) r0
                vea.raceremote.control.ControlEndpoint r0 = r0.load(r2, r3, r4)
                return r0
        }
    }


    /* JADX INFO: renamed from: vea.raceremote.control.CarControlConnection$connect$2, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: CarControlConnection.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\u008a@"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {1, 8, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "vea.raceremote.control.CarControlConnection$connect$2", f = "CarControlConnection.kt", i = {0}, l = {88}, m = "invokeSuspend", n = {"$this$launch"}, s = {"L$0"})
    static final class C05262 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ kotlin.jvm.functions.Function1<java.net.DatagramSocket, kotlin.Unit> $bindUdp;
        final /* synthetic */ long $current;
        final /* synthetic */ java.lang.Long $expectedChipId;
        final /* synthetic */ java.lang.Integer $expectedPort;
        final /* synthetic */ java.lang.String $expectedTransport;
        final /* synthetic */ java.lang.String $host;
        final /* synthetic */ okhttp3.OkHttpClient $http;
        final /* synthetic */ int $statusPort;
        private /* synthetic */ java.lang.Object L$0;
        int label;
        final /* synthetic */ vea.raceremote.control.CarControlConnection this$0;

        /* JADX INFO: renamed from: vea.raceremote.control.CarControlConnection$connect$2$WhenMappings */
        /* JADX INFO: compiled from: CarControlConnection.kt */
        @kotlin.Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
        public /* synthetic */ class WhenMappings {
            public static final /* synthetic */ int[] $EnumSwitchMapping$0 = null;

            static {
                    vea.raceremote.control.UdpControlSession$Phase[] r0 = vea.raceremote.control.UdpControlSession.Phase.values()
                    int r0 = r0.length
                    int[] r0 = new int[r0]
                    vea.raceremote.control.UdpControlSession$Phase r1 = vea.raceremote.control.UdpControlSession.Phase.OPENING     // Catch: java.lang.NoSuchFieldError -> L11
                    int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L11
                    r2 = 1
                    r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L11
                    goto L12
                L11:
                    r1 = move-exception
                L12:
                    vea.raceremote.control.UdpControlSession$Phase r1 = vea.raceremote.control.UdpControlSession.Phase.ARMING     // Catch: java.lang.NoSuchFieldError -> L1c
                    int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L1c
                    r2 = 2
                    r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L1c
                    goto L1d
                L1c:
                    r1 = move-exception
                L1d:
                    vea.raceremote.control.UdpControlSession$Phase r1 = vea.raceremote.control.UdpControlSession.Phase.ACTIVE     // Catch: java.lang.NoSuchFieldError -> L27
                    int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L27
                    r2 = 3
                    r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L27
                    goto L28
                L27:
                    r1 = move-exception
                L28:
                    vea.raceremote.control.UdpControlSession$Phase r1 = vea.raceremote.control.UdpControlSession.Phase.CLOSED     // Catch: java.lang.NoSuchFieldError -> L32
                    int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L32
                    r2 = 4
                    r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L32
                    goto L33
                L32:
                    r1 = move-exception
                L33:
                    vea.raceremote.control.CarControlConnection.C05262.WhenMappings.$EnumSwitchMapping$0 = r0
                    return
            }
        }

        C05262(vea.raceremote.control.CarControlConnection r2, java.lang.String r3, okhttp3.OkHttpClient r4, int r5, long r6, java.lang.Long r8, java.lang.Integer r9, java.lang.String r10, kotlin.jvm.functions.Function1<? super java.net.DatagramSocket, kotlin.Unit> r11, kotlin.coroutines.Continuation<? super vea.raceremote.control.CarControlConnection.C05262> r12) {
                r1 = this;
                r1.this$0 = r2
                r1.$host = r3
                r1.$http = r4
                r1.$statusPort = r5
                r1.$current = r6
                r1.$expectedChipId = r8
                r1.$expectedPort = r9
                r1.$expectedTransport = r10
                r1.$bindUdp = r11
                r0 = 2
                r1.<init>(r0, r12)
                return
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object r14, kotlin.coroutines.Continuation<?> r15) {
                r13 = this;
                vea.raceremote.control.CarControlConnection$connect$2 r12 = new vea.raceremote.control.CarControlConnection$connect$2
                vea.raceremote.control.CarControlConnection r1 = r13.this$0
                java.lang.String r2 = r13.$host
                okhttp3.OkHttpClient r3 = r13.$http
                int r4 = r13.$statusPort
                long r5 = r13.$current
                java.lang.Long r7 = r13.$expectedChipId
                java.lang.Integer r8 = r13.$expectedPort
                java.lang.String r9 = r13.$expectedTransport
                kotlin.jvm.functions.Function1<java.net.DatagramSocket, kotlin.Unit> r10 = r13.$bindUdp
                r0 = r12
                r11 = r15
                r0.<init>(r1, r2, r3, r4, r5, r7, r8, r9, r10, r11)
                r12.L$0 = r14
                kotlin.coroutines.Continuation r12 = (kotlin.coroutines.Continuation) r12
                return r12
        }

        @Override // kotlin.jvm.functions.Function2
        public /* bridge */ /* synthetic */ java.lang.Object invoke(kotlinx.coroutines.CoroutineScope r2, kotlin.coroutines.Continuation<? super kotlin.Unit> r3) {
                r1 = this;
                kotlinx.coroutines.CoroutineScope r2 = (kotlinx.coroutines.CoroutineScope) r2
                kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3
                java.lang.Object r0 = r1.invoke2(r2, r3)
                return r0
        }

        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
        public final java.lang.Object invoke2(kotlinx.coroutines.CoroutineScope r3, kotlin.coroutines.Continuation<? super kotlin.Unit> r4) {
                r2 = this;
                kotlin.coroutines.Continuation r0 = r2.create(r3, r4)
                vea.raceremote.control.CarControlConnection$connect$2 r0 = (vea.raceremote.control.CarControlConnection.C05262) r0
                kotlin.Unit r1 = kotlin.Unit.INSTANCE
                java.lang.Object r0 = r0.invokeSuspend(r1)
                return r0
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object r24) {
                r23 = this;
                java.lang.Object r0 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
                r1 = r23
                int r2 = r1.label
                r4 = 1
                switch(r2) {
                    case 0: goto L21;
                    case 1: goto L14;
                    default: goto Lc;
                }
            Lc:
                java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
                java.lang.String r1 = "call to 'resume' before 'invoke' with coroutine"
                r0.<init>(r1)
                throw r0
            L14:
                r1 = r23
                r2 = r24
                java.lang.Object r5 = r1.L$0
                kotlinx.coroutines.CoroutineScope r5 = (kotlinx.coroutines.CoroutineScope) r5
                kotlin.ResultKt.throwOnFailure(r2)     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                goto L252
            L21:
                kotlin.ResultKt.throwOnFailure(r24)
                r1 = r23
                r2 = r24
                java.lang.Object r5 = r1.L$0
                kotlinx.coroutines.CoroutineScope r5 = (kotlinx.coroutines.CoroutineScope) r5
                vea.raceremote.control.CarControlConnection r6 = r1.this$0     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                kotlin.jvm.functions.Function3 r6 = vea.raceremote.control.CarControlConnection.access$getResolve$p(r6)     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                java.lang.String r7 = r1.$host     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                okhttp3.OkHttpClient r8 = r1.$http     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                int r9 = r1.$statusPort     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                java.lang.Integer r9 = kotlin.coroutines.jvm.internal.Boxing.boxInt(r9)     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                java.lang.Object r6 = r6.invoke(r7, r8, r9)     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                vea.raceremote.control.ControlEndpoint r6 = (vea.raceremote.control.ControlEndpoint) r6     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                vea.raceremote.control.CarControlConnection r7 = r1.this$0     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                long r8 = r1.$current     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                java.lang.Long r10 = r1.$expectedChipId     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                java.lang.Integer r11 = r1.$expectedPort     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                java.lang.String r12 = r1.$expectedTransport     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                java.lang.String r14 = r1.$host     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                kotlin.jvm.functions.Function1<java.net.DatagramSocket, kotlin.Unit> r15 = r1.$bindUdp     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                okhttp3.OkHttpClient r13 = r1.$http     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                monitor-enter(r7)     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                r22 = 0
                long r16 = vea.raceremote.control.CarControlConnection.access$getGeneration$p(r7)     // Catch: java.lang.Throwable -> L28e
                int r8 = (r8 > r16 ? 1 : (r8 == r16 ? 0 : -1))
                if (r8 != 0) goto L28a
                boolean r8 = vea.raceremote.control.CarControlConnection.access$getClosed$p(r7)     // Catch: java.lang.Throwable -> L28e
                if (r8 == 0) goto L66
                goto L28a
            L66:
                vea.raceremote.control.LiveLiterals$CarControlConnectionKt r8 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L28e
                int r8 = r8.m6127Int$$this$callrangeTo$$this$callcontains$arg0$callrequire$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection()     // Catch: java.lang.Throwable -> L28e
                vea.raceremote.control.LiveLiterals$CarControlConnectionKt r9 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L28e
                long r16 = r9.m6139Long$arg0$callrangeTo$$this$callcontains$arg0$callrequire$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection()     // Catch: java.lang.Throwable -> L28e
                long r18 = r6.getChipId()     // Catch: java.lang.Throwable -> L28e
                long r8 = (long) r8     // Catch: java.lang.Throwable -> L28e
                int r8 = (r8 > r18 ? 1 : (r8 == r18 ? 0 : -1))
                if (r8 > 0) goto L81
                int r8 = (r18 > r16 ? 1 : (r18 == r16 ? 0 : -1))
                if (r8 > 0) goto L81
                r8 = r4
                goto L82
            L81:
                r8 = 0
            L82:
                if (r8 == 0) goto L27e
                vea.raceremote.control.LiveLiterals$CarControlConnectionKt r8 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L28e
                int r8 = r8.m6128Int$$this$callrangeTo$$this$callcontains$arg0$callrequire1$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection()     // Catch: java.lang.Throwable -> L28e
                vea.raceremote.control.LiveLiterals$CarControlConnectionKt r9 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L28e
                int r9 = r9.m6130Int$arg0$callrangeTo$$this$callcontains$arg0$callrequire1$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection()     // Catch: java.lang.Throwable -> L28e
                int r3 = r6.getPort()     // Catch: java.lang.Throwable -> L28e
                if (r8 > r3) goto L9a
                if (r3 > r9) goto L9a
                r3 = r4
                goto L9b
            L9a:
                r3 = 0
            L9b:
                if (r3 == 0) goto L272
                if (r10 == 0) goto Lb8
                long r8 = r6.getChipId()     // Catch: java.lang.Throwable -> L28e
                long r16 = r10.longValue()     // Catch: java.lang.Throwable -> L28e
                int r3 = (r8 > r16 ? 1 : (r8 == r16 ? 0 : -1))
                if (r3 == 0) goto Lb8
                vea.raceremote.control.LiveLiterals$CarControlConnectionKt r0 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L28e
                java.lang.String r0 = r0.m6155String$arg0$calldisconnect$branch$if1$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection()     // Catch: java.lang.Throwable -> L28e
                r7.disconnect(r0)     // Catch: java.lang.Throwable -> L28e
                kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L28e
                monitor-exit(r7)     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                return r0
            Lb8:
                if (r11 == 0) goto Ld1
                int r3 = r6.getPort()     // Catch: java.lang.Throwable -> L28e
                int r8 = r11.intValue()     // Catch: java.lang.Throwable -> L28e
                if (r3 == r8) goto Ld1
                vea.raceremote.control.LiveLiterals$CarControlConnectionKt r0 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L28e
                java.lang.String r0 = r0.m6156String$arg0$calldisconnect$branch$if2$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection()     // Catch: java.lang.Throwable -> L28e
                r7.disconnect(r0)     // Catch: java.lang.Throwable -> L28e
                kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L28e
                monitor-exit(r7)     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                return r0
            Ld1:
                if (r12 == 0) goto Lea
                java.lang.String r3 = r6.getTransport()     // Catch: java.lang.Throwable -> L28e
                boolean r3 = kotlin.jvm.internal.Intrinsics.areEqual(r3, r12)     // Catch: java.lang.Throwable -> L28e
                if (r3 != 0) goto Lea
                vea.raceremote.control.LiveLiterals$CarControlConnectionKt r0 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L28e
                java.lang.String r0 = r0.m6157String$arg0$calldisconnect$branch$if3$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection()     // Catch: java.lang.Throwable -> L28e
                r7.disconnect(r0)     // Catch: java.lang.Throwable -> L28e
                kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L28e
                monitor-exit(r7)     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                return r0
            Lea:
                java.lang.String r3 = r6.getTransport()     // Catch: java.lang.Throwable -> L28e
                vea.raceremote.control.LiveLiterals$CarControlConnectionKt r8 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L28e
                java.lang.String r8 = r8.m6159String$arg1$callEQEQ$cond$when$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection()     // Catch: java.lang.Throwable -> L28e
                boolean r8 = kotlin.jvm.internal.Intrinsics.areEqual(r3, r8)     // Catch: java.lang.Throwable -> L28e
                if (r8 == 0) goto L12f
                int r3 = r6.getPort()     // Catch: java.lang.Throwable -> L28e
                r8 = 3334(0xd06, float:4.672E-42)
                if (r3 != r8) goto L104
                r3 = r4
                goto L105
            L104:
                r3 = 0
            L105:
                if (r3 == 0) goto L123
                vea.raceremote.control.UdpControlClient r3 = new vea.raceremote.control.UdpControlClient     // Catch: java.lang.Throwable -> L28e
                long r8 = r6.getChipId()     // Catch: java.lang.Throwable -> L28e
                kotlin.jvm.functions.Function1 r18 = vea.raceremote.control.CarControlConnection.access$getDiagnostics$p(r7)     // Catch: java.lang.Throwable -> L28e
                r19 = 0
                r20 = 16
                r21 = 0
                r13 = r3
                r10 = r15
                r15 = r8
                r17 = r10
                r13.<init>(r14, r15, r17, r18, r19, r20, r21)     // Catch: java.lang.Throwable -> L28e
                vea.raceremote.control.CarControlConnection.access$setUdp$p(r7, r3)     // Catch: java.lang.Throwable -> L28e
                goto L162
            L123:
                java.lang.String r0 = "Failed requirement."
                java.lang.IllegalArgumentException r3 = new java.lang.IllegalArgumentException     // Catch: java.lang.Throwable -> L28e
                java.lang.String r0 = r0.toString()     // Catch: java.lang.Throwable -> L28e
                r3.<init>(r0)     // Catch: java.lang.Throwable -> L28e
                throw r3     // Catch: java.lang.Throwable -> L28e
            L12f:
                vea.raceremote.control.LiveLiterals$CarControlConnectionKt r8 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L28e
                java.lang.String r8 = r8.m6160String$arg1$callEQEQ$cond1$when$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection()     // Catch: java.lang.Throwable -> L28e
                boolean r3 = kotlin.jvm.internal.Intrinsics.areEqual(r3, r8)     // Catch: java.lang.Throwable -> L28e
                if (r3 == 0) goto L265
                vea.raceremote.control.CarControlClient r3 = new vea.raceremote.control.CarControlClient     // Catch: java.lang.Throwable -> L28e
                kotlin.jvm.functions.Function1 r16 = vea.raceremote.control.CarControlConnection.access$getDiagnostics$p(r7)     // Catch: java.lang.Throwable -> L28e
                r17 = 0
                r18 = 0
                r19 = 6
                r20 = 0
                r15 = r3
                r15.<init>(r16, r17, r18, r19, r20)     // Catch: java.lang.Throwable -> L28e
                r8 = r3
                r9 = 0
                int r10 = r6.getPort()     // Catch: java.lang.Throwable -> L28e
                long r11 = r6.getChipId()     // Catch: java.lang.Throwable -> L28e
                java.lang.Long r11 = kotlin.coroutines.jvm.internal.Boxing.boxLong(r11)     // Catch: java.lang.Throwable -> L28e
                r8.connect(r14, r13, r10, r11)     // Catch: java.lang.Throwable -> L28e
                vea.raceremote.control.CarControlConnection.access$setWebsocket$p(r7, r3)     // Catch: java.lang.Throwable -> L28e
            L162:
                kotlin.Unit r3 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L28e
                monitor-exit(r7)     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
            L166:
                boolean r3 = kotlinx.coroutines.CoroutineScopeKt.isActive(r5)     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                if (r3 == 0) goto L2da
                vea.raceremote.control.CarControlConnection r3 = r1.this$0     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                long r6 = r1.$current     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                monitor-enter(r3)     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                r8 = 0
                long r9 = vea.raceremote.control.CarControlConnection.access$getGeneration$p(r3)     // Catch: java.lang.Throwable -> L262
                int r6 = (r6 > r9 ? 1 : (r6 == r9 ? 0 : -1))
                if (r6 != 0) goto L25e
                boolean r6 = vea.raceremote.control.CarControlConnection.access$getClosed$p(r3)     // Catch: java.lang.Throwable -> L262
                if (r6 == 0) goto L182
                goto L25e
            L182:
                vea.raceremote.control.CarControlClient r6 = vea.raceremote.control.CarControlConnection.access$getWebsocket$p(r3)     // Catch: java.lang.Throwable -> L262
                if (r6 == 0) goto L199
                kotlinx.coroutines.flow.StateFlow r6 = r6.getState()     // Catch: java.lang.Throwable -> L262
                if (r6 == 0) goto L199
                java.lang.Object r6 = r6.getValue()     // Catch: java.lang.Throwable -> L262
                vea.raceremote.control.CarConnectionState r6 = (vea.raceremote.control.CarConnectionState) r6     // Catch: java.lang.Throwable -> L262
                if (r6 != 0) goto L197
                goto L199
            L197:
                goto L21c
            L199:
                vea.raceremote.control.UdpControlClient r6 = vea.raceremote.control.CarControlConnection.access$getUdp$p(r3)     // Catch: java.lang.Throwable -> L262
                if (r6 == 0) goto L25a
                vea.raceremote.control.UdpControlSession$Snapshot r6 = r6.snapshot()     // Catch: java.lang.Throwable -> L262
                if (r6 == 0) goto L25a
                r7 = 0
                vea.raceremote.control.UdpControlSession$Phase r9 = r6.getPhase()     // Catch: java.lang.Throwable -> L262
                int[] r10 = vea.raceremote.control.CarControlConnection.C05262.WhenMappings.$EnumSwitchMapping$0     // Catch: java.lang.Throwable -> L262
                int r9 = r9.ordinal()     // Catch: java.lang.Throwable -> L262
                r9 = r10[r9]     // Catch: java.lang.Throwable -> L262
                if (r9 != r4) goto L1bb
                vea.raceremote.control.LiveLiterals$CarControlConnectionKt r10 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L262
                boolean r10 = r10.m6114Boolean$branch$when$cond$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection()     // Catch: java.lang.Throwable -> L262
                goto L1c1
            L1bb:
                r10 = 2
                if (r9 != r10) goto L1c0
                r10 = r4
                goto L1c1
            L1c0:
                r10 = 0
            L1c1:
                if (r10 == 0) goto L1de
                vea.raceremote.control.CarConnectionState r6 = new vea.raceremote.control.CarConnectionState     // Catch: java.lang.Throwable -> L262
                vea.raceremote.control.LiveLiterals$CarControlConnectionKt r9 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L262
                java.lang.String r12 = r9.m6150String$arg0$call$init$$branch$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection()     // Catch: java.lang.Throwable -> L262
                r13 = 0
                vea.raceremote.control.LiveLiterals$CarControlConnectionKt r9 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L262
                boolean r14 = r9.m6113Boolean$arg2$call$init$$branch$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection()     // Catch: java.lang.Throwable -> L262
                r15 = 0
                r16 = 0
                r17 = 26
                r18 = 0
                r11 = r6
                r11.<init>(r12, r13, r14, r15, r16, r17, r18)     // Catch: java.lang.Throwable -> L262
                goto L219
            L1de:
                r10 = 3
                if (r9 != r10) goto L202
                vea.raceremote.control.CarConnectionState r9 = new vea.raceremote.control.CarConnectionState     // Catch: java.lang.Throwable -> L262
                vea.raceremote.control.LiveLiterals$CarControlConnectionKt r10 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L262
                java.lang.String r12 = r10.m6151String$arg0$call$init$$branch1$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection()     // Catch: java.lang.Throwable -> L262
                vea.raceremote.control.LiveLiterals$CarControlConnectionKt r10 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L262
                boolean r13 = r10.m6111Boolean$arg1$call$init$$branch1$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection()     // Catch: java.lang.Throwable -> L262
                r14 = 0
                int r15 = r6.getAcknowledgedThrottle()     // Catch: java.lang.Throwable -> L262
                int r16 = r6.getAcknowledgedSteering()     // Catch: java.lang.Throwable -> L262
                r17 = 4
                r18 = 0
                r11 = r9
                r11.<init>(r12, r13, r14, r15, r16, r17, r18)     // Catch: java.lang.Throwable -> L262
                r6 = r9
                goto L219
            L202:
                r6 = 4
                if (r9 != r6) goto L254
                vea.raceremote.control.CarConnectionState r6 = new vea.raceremote.control.CarConnectionState     // Catch: java.lang.Throwable -> L262
                vea.raceremote.control.LiveLiterals$CarControlConnectionKt r9 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L262
                java.lang.String r11 = r9.m6152String$arg0$call$init$$branch2$when$fun$anonymous$$arg0$calllet$else$when$branch$when$valtmp5_elvis_lhs$valvalue$fun$anonymous$$arg1$callsynchronized$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection()     // Catch: java.lang.Throwable -> L262
                r12 = 0
                r13 = 0
                r14 = 0
                r15 = 0
                r16 = 30
                r17 = 0
                r10 = r6
                r10.<init>(r11, r12, r13, r14, r15, r16, r17)     // Catch: java.lang.Throwable -> L262
            L219:
                goto L197
            L21c:
                kotlinx.coroutines.flow.MutableStateFlow r7 = vea.raceremote.control.CarControlConnection.access$getMutableState$p(r3)     // Catch: java.lang.Throwable -> L262
                r7.setValue(r6)     // Catch: java.lang.Throwable -> L262
                boolean r7 = r6.getConnected()     // Catch: java.lang.Throwable -> L262
                if (r7 != 0) goto L23a
                boolean r7 = r6.getConnecting()     // Catch: java.lang.Throwable -> L262
                if (r7 != 0) goto L23a
                java.lang.String r0 = r6.getMessage()     // Catch: java.lang.Throwable -> L262
                r3.disconnect(r0)     // Catch: java.lang.Throwable -> L262
                kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L262
                monitor-exit(r3)     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                return r0
            L23a:
                kotlin.Unit r6 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L262
                monitor-exit(r3)     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                vea.raceremote.control.LiveLiterals$CarControlConnectionKt r3 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                long r6 = r3.m6138Long$arg0$calldelay$body$loop$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection()     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                r3 = r1
                kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                r1.L$0 = r5     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                r1.label = r4     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                java.lang.Object r3 = kotlinx.coroutines.DelayKt.delay(r6, r3)     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                if (r3 != r0) goto L252
                return r0
            L252:
                goto L166
            L254:
                kotlin.NoWhenBranchMatchedException r0 = new kotlin.NoWhenBranchMatchedException     // Catch: java.lang.Throwable -> L262
                r0.<init>()     // Catch: java.lang.Throwable -> L262
                throw r0     // Catch: java.lang.Throwable -> L262
            L25a:
                kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L262
                monitor-exit(r3)     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                return r0
            L25e:
                kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L262
                monitor-exit(r3)     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                return r0
            L262:
                r0 = move-exception
                monitor-exit(r3)     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                throw r0     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
            L265:
                vea.raceremote.control.LiveLiterals$CarControlConnectionKt r0 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L28e
                java.lang.String r0 = r0.m6158String$arg0$calldisconnect$else$when$fun$anonymous$$arg1$callsynchronized$try$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection()     // Catch: java.lang.Throwable -> L28e
                r7.disconnect(r0)     // Catch: java.lang.Throwable -> L28e
                kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L28e
                monitor-exit(r7)     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                return r0
            L272:
                java.lang.String r0 = "Failed requirement."
                java.lang.IllegalArgumentException r3 = new java.lang.IllegalArgumentException     // Catch: java.lang.Throwable -> L28e
                java.lang.String r0 = r0.toString()     // Catch: java.lang.Throwable -> L28e
                r3.<init>(r0)     // Catch: java.lang.Throwable -> L28e
                throw r3     // Catch: java.lang.Throwable -> L28e
            L27e:
                java.lang.String r0 = "Failed requirement."
                java.lang.IllegalArgumentException r3 = new java.lang.IllegalArgumentException     // Catch: java.lang.Throwable -> L28e
                java.lang.String r0 = r0.toString()     // Catch: java.lang.Throwable -> L28e
                r3.<init>(r0)     // Catch: java.lang.Throwable -> L28e
                throw r3     // Catch: java.lang.Throwable -> L28e
            L28a:
                kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L28e
                monitor-exit(r7)     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                return r0
            L28e:
                r0 = move-exception
                monitor-exit(r7)     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
                throw r0     // Catch: java.lang.Exception -> L291 java.util.concurrent.CancellationException -> L2e0
            L291:
                r0 = move-exception
                vea.raceremote.control.CarControlConnection r3 = r1.this$0
                long r4 = r1.$current
                monitor-enter(r3)
                r6 = 0
                long r7 = vea.raceremote.control.CarControlConnection.access$getGeneration$p(r3)     // Catch: java.lang.Throwable -> L2dd
                int r4 = (r4 > r7 ? 1 : (r4 == r7 ? 0 : -1))
                if (r4 != 0) goto L2d6
                boolean r4 = vea.raceremote.control.CarControlConnection.access$getClosed$p(r3)     // Catch: java.lang.Throwable -> L2dd
                if (r4 != 0) goto L2d6
                kotlin.jvm.functions.Function1 r4 = vea.raceremote.control.CarControlConnection.access$getDiagnostics$p(r3)     // Catch: java.lang.Throwable -> L2dd
                java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L2dd
                r5.<init>()     // Catch: java.lang.Throwable -> L2dd
                vea.raceremote.control.LiveLiterals$CarControlConnectionKt r7 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L2dd
                java.lang.String r7 = r7.m6140String$0$str$arg0$callinvoke$branch$if$fun$anonymous$$arg1$callsynchronized$catch1$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection()     // Catch: java.lang.Throwable -> L2dd
                java.lang.StringBuilder r5 = r5.append(r7)     // Catch: java.lang.Throwable -> L2dd
                java.lang.Class r7 = r0.getClass()     // Catch: java.lang.Throwable -> L2dd
                java.lang.String r7 = r7.getSimpleName()     // Catch: java.lang.Throwable -> L2dd
                java.lang.StringBuilder r5 = r5.append(r7)     // Catch: java.lang.Throwable -> L2dd
                java.lang.String r5 = r5.toString()     // Catch: java.lang.Throwable -> L2dd
                r4.invoke(r5)     // Catch: java.lang.Throwable -> L2dd
                vea.raceremote.control.LiveLiterals$CarControlConnectionKt r0 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L2dd
                java.lang.String r0 = r0.m6153String$arg0$calldisconnect$branch$if$fun$anonymous$$arg1$callsynchronized$catch1$fun$anonymous$$arg2$calllaunch$arg0$call$setjob$$funconnect$classCarControlConnection()     // Catch: java.lang.Throwable -> L2dd
                r3.disconnect(r0)     // Catch: java.lang.Throwable -> L2dd
            L2d6:
                kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L2dd
                monitor-exit(r3)
            L2da:
                kotlin.Unit r0 = kotlin.Unit.INSTANCE
                return r0
            L2dd:
                r0 = move-exception
                monitor-exit(r3)
                throw r0
            L2e0:
                r0 = move-exception
                throw r0
        }
    }

    static {
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r0 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE
            int r0 = r0.m6135Int$classCarControlConnection()
            vea.raceremote.control.CarControlConnection.$stable = r0
            return
    }

    public CarControlConnection() {
            r2 = this;
            r0 = 0
            r1 = 3
            r2.<init>(r0, r0, r1, r0)
            return
    }

    public CarControlConnection(kotlin.jvm.functions.Function3<? super java.lang.String, ? super okhttp3.OkHttpClient, ? super java.lang.Integer, vea.raceremote.control.ControlEndpoint> r10, kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> r11) {
            r9 = this;
            java.lang.String r0 = "resolve"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r10, r0)
            java.lang.String r0 = "diagnostics"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r11, r0)
            r9.<init>()
            r9.resolve = r10
            r9.diagnostics = r11
            vea.raceremote.control.CarConnectionState r0 = new vea.raceremote.control.CarConnectionState
            r2 = 0
            r3 = 0
            r4 = 0
            r5 = 0
            r6 = 0
            r7 = 31
            r8 = 0
            r1 = r0
            r1.<init>(r2, r3, r4, r5, r6, r7, r8)
            kotlinx.coroutines.flow.MutableStateFlow r0 = kotlinx.coroutines.flow.StateFlowKt.MutableStateFlow(r0)
            r9.mutableState = r0
            kotlinx.coroutines.flow.StateFlow r0 = kotlinx.coroutines.flow.FlowKt.asStateFlow(r0)
            r9.state = r0
            r0 = 0
            r1 = 1
            kotlinx.coroutines.CompletableJob r0 = kotlinx.coroutines.SupervisorKt.SupervisorJob$default(r0, r1, r0)
            kotlinx.coroutines.CoroutineDispatcher r1 = kotlinx.coroutines.Dispatchers.getIO()
            kotlin.coroutines.CoroutineContext r1 = (kotlin.coroutines.CoroutineContext) r1
            kotlin.coroutines.CoroutineContext r0 = r0.plus(r1)
            kotlinx.coroutines.CoroutineScope r0 = kotlinx.coroutines.CoroutineScopeKt.CoroutineScope(r0)
            r9.scope = r0
            return
    }

    public /* synthetic */ CarControlConnection(kotlin.jvm.functions.Function3 r1, kotlin.jvm.functions.Function1 r2, int r3, kotlin.jvm.internal.DefaultConstructorMarker r4) {
            r0 = this;
            r4 = r3 & 1
            if (r4 == 0) goto Ld
            vea.raceremote.control.CarControlConnection$1 r1 = new vea.raceremote.control.CarControlConnection$1
            vea.raceremote.control.ControlEndpointProbe r4 = vea.raceremote.control.ControlEndpointProbe.INSTANCE
            r1.<init>(r4)
            kotlin.jvm.functions.Function3 r1 = (kotlin.jvm.functions.Function3) r1
        Ld:
            r3 = r3 & 2
            if (r3 == 0) goto L15
            vea.raceremote.control.CarControlConnection$2 r2 = vea.raceremote.control.CarControlConnection.AnonymousClass2.INSTANCE
            kotlin.jvm.functions.Function1 r2 = (kotlin.jvm.functions.Function1) r2
        L15:
            r0.<init>(r1, r2)
            return
    }

    public static final /* synthetic */ boolean access$getClosed$p(vea.raceremote.control.CarControlConnection r1) {
            boolean r0 = r1.closed
            return r0
    }

    public static final /* synthetic */ kotlin.jvm.functions.Function1 access$getDiagnostics$p(vea.raceremote.control.CarControlConnection r1) {
            kotlin.jvm.functions.Function1<java.lang.String, kotlin.Unit> r0 = r1.diagnostics
            return r0
    }

    public static final /* synthetic */ long access$getGeneration$p(vea.raceremote.control.CarControlConnection r2) {
            long r0 = r2.generation
            return r0
    }

    public static final /* synthetic */ kotlinx.coroutines.flow.MutableStateFlow access$getMutableState$p(vea.raceremote.control.CarControlConnection r1) {
            kotlinx.coroutines.flow.MutableStateFlow<vea.raceremote.control.CarConnectionState> r0 = r1.mutableState
            return r0
    }

    public static final /* synthetic */ kotlin.jvm.functions.Function3 access$getResolve$p(vea.raceremote.control.CarControlConnection r1) {
            kotlin.jvm.functions.Function3<java.lang.String, okhttp3.OkHttpClient, java.lang.Integer, vea.raceremote.control.ControlEndpoint> r0 = r1.resolve
            return r0
    }

    public static final /* synthetic */ vea.raceremote.control.UdpControlClient access$getUdp$p(vea.raceremote.control.CarControlConnection r1) {
            vea.raceremote.control.UdpControlClient r0 = r1.udp
            return r0
    }

    public static final /* synthetic */ vea.raceremote.control.CarControlClient access$getWebsocket$p(vea.raceremote.control.CarControlConnection r1) {
            vea.raceremote.control.CarControlClient r0 = r1.websocket
            return r0
    }

    public static final /* synthetic */ void access$setUdp$p(vea.raceremote.control.CarControlConnection r0, vea.raceremote.control.UdpControlClient r1) {
            r0.udp = r1
            return
    }

    public static final /* synthetic */ void access$setWebsocket$p(vea.raceremote.control.CarControlConnection r0, vea.raceremote.control.CarControlClient r1) {
            r0.websocket = r1
            return
    }

    public static /* synthetic */ void connect$default(vea.raceremote.control.CarControlConnection r10, java.lang.String r11, okhttp3.OkHttpClient r12, kotlin.jvm.functions.Function1 r13, java.lang.Integer r14, java.lang.Long r15, int r16, java.lang.String r17, int r18, java.lang.Object r19) {
            r0 = r18 & 8
            r1 = 0
            if (r0 == 0) goto L7
            r6 = r1
            goto L8
        L7:
            r6 = r14
        L8:
            r0 = r18 & 16
            if (r0 == 0) goto Le
            r7 = r1
            goto Lf
        Le:
            r7 = r15
        Lf:
            r0 = r18 & 32
            if (r0 == 0) goto L1b
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r0 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE
            int r0 = r0.m6137Int$paramstatusPort$funconnect$classCarControlConnection()
            r8 = r0
            goto L1d
        L1b:
            r8 = r16
        L1d:
            r0 = r18 & 64
            if (r0 == 0) goto L23
            r9 = r1
            goto L25
        L23:
            r9 = r17
        L25:
            r2 = r10
            r3 = r11
            r4 = r12
            r5 = r13
            r2.connect(r3, r4, r5, r6, r7, r8, r9)
            return
    }

    public static /* synthetic */ void disconnect$default(vea.raceremote.control.CarControlConnection r0, java.lang.String r1, int r2, java.lang.Object r3) {
            r2 = r2 & 1
            if (r2 == 0) goto La
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r1 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE
            java.lang.String r1 = r1.m6161String$parammessage$fundisconnect$classCarControlConnection()
        La:
            r0.disconnect(r1)
            return
    }

    public final synchronized void close() {
            r3 = this;
            monitor-enter(r3)
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r0 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L15
            boolean r0 = r0.m6110Boolean$arg0$call$setclosed$$funclose$classCarControlConnection()     // Catch: java.lang.Throwable -> L15
            r3.closed = r0     // Catch: java.lang.Throwable -> L15
            r0 = 1
            r1 = 0
            disconnect$default(r3, r1, r0, r1)     // Catch: java.lang.Throwable -> L15
            kotlinx.coroutines.CoroutineScope r2 = r3.scope     // Catch: java.lang.Throwable -> L15
            kotlinx.coroutines.CoroutineScopeKt.cancel$default(r2, r1, r0, r1)     // Catch: java.lang.Throwable -> L15
            monitor-exit(r3)
            return
        L15:
            r0 = move-exception
            monitor-exit(r3)
            throw r0
    }

    public final synchronized void connect(java.lang.String r31, okhttp3.OkHttpClient r32, kotlin.jvm.functions.Function1<? super java.net.DatagramSocket, kotlin.Unit> r33, java.lang.Integer r34, java.lang.Long r35, int r36, java.lang.String r37) {
            r30 = this;
            r13 = r30
            r0 = r31
            r14 = r36
            monitor-enter(r30)
            java.lang.String r1 = "host"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r0, r1)     // Catch: java.lang.Throwable -> L1be
            java.lang.String r1 = "http"
            r15 = r32
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r15, r1)     // Catch: java.lang.Throwable -> L1be
            java.lang.String r1 = "bindUdp"
            r12 = r33
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r12, r1)     // Catch: java.lang.Throwable -> L1be
            boolean r1 = r13.closed     // Catch: java.lang.Throwable -> L1be
            if (r1 == 0) goto L20
            monitor-exit(r30)
            return
        L20:
            r1 = 0
            r2 = 1
            disconnect$default(r13, r1, r2, r1)     // Catch: java.lang.Throwable -> L1be
            r3 = r0
            java.lang.CharSequence r3 = (java.lang.CharSequence) r3     // Catch: java.lang.Throwable -> L1be
            char[] r4 = new char[r2]     // Catch: java.lang.Throwable -> L1be
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r1 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L1be
            char r1 = r1.m6121Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$funconnect$classCarControlConnection()     // Catch: java.lang.Throwable -> L1be
            r9 = 0
            r4[r9] = r1     // Catch: java.lang.Throwable -> L1be
            r5 = 0
            r6 = 0
            r7 = 6
            r8 = 0
            java.util.List r1 = kotlin.text.StringsKt.split$default(r3, r4, r5, r6, r7, r8)     // Catch: java.lang.Throwable -> L1be
            java.lang.Iterable r1 = (java.lang.Iterable) r1     // Catch: java.lang.Throwable -> L1be
            r3 = 0
            java.util.ArrayList r4 = new java.util.ArrayList     // Catch: java.lang.Throwable -> L1be
            r5 = 10
            int r6 = kotlin.collections.CollectionsKt.collectionSizeOrDefault(r1, r5)     // Catch: java.lang.Throwable -> L1be
            r4.<init>(r6)     // Catch: java.lang.Throwable -> L1be
            java.util.Collection r4 = (java.util.Collection) r4     // Catch: java.lang.Throwable -> L1be
            r6 = r1
            r7 = 0
            java.util.Iterator r8 = r6.iterator()     // Catch: java.lang.Throwable -> L1be
        L51:
            boolean r10 = r8.hasNext()     // Catch: java.lang.Throwable -> L1be
            if (r10 == 0) goto L69
            java.lang.Object r10 = r8.next()     // Catch: java.lang.Throwable -> L1be
            r11 = r10
            java.lang.String r11 = (java.lang.String) r11     // Catch: java.lang.Throwable -> L1be
            r16 = 0
            java.lang.Integer r2 = kotlin.text.StringsKt.toIntOrNull(r11)     // Catch: java.lang.Throwable -> L1be
            r4.add(r2)     // Catch: java.lang.Throwable -> L1be
            r2 = 1
            goto L51
        L69:
            r2 = r4
            java.util.List r2 = (java.util.List) r2     // Catch: java.lang.Throwable -> L1be
            r11 = r2
            int r1 = r11.size()     // Catch: java.lang.Throwable -> L1be
            r2 = 4
            if (r1 != r2) goto L1a2
            r1 = r11
            java.lang.Iterable r1 = (java.lang.Iterable) r1     // Catch: java.lang.Throwable -> L1be
            r2 = 0
            boolean r3 = r1 instanceof java.util.Collection     // Catch: java.lang.Throwable -> L1be
            if (r3 == 0) goto L89
            r3 = r1
            java.util.Collection r3 = (java.util.Collection) r3     // Catch: java.lang.Throwable -> L1be
            boolean r3 = r3.isEmpty()     // Catch: java.lang.Throwable -> L1be
            if (r3 == 0) goto L89
            r1 = r9
            goto Lb7
        L89:
            java.util.Iterator r3 = r1.iterator()     // Catch: java.lang.Throwable -> L1be
        L8d:
            boolean r4 = r3.hasNext()     // Catch: java.lang.Throwable -> L1be
            if (r4 == 0) goto Lb6
            java.lang.Object r4 = r3.next()     // Catch: java.lang.Throwable -> L1be
            r6 = r4
            java.lang.Integer r6 = (java.lang.Integer) r6     // Catch: java.lang.Throwable -> L1be
            r7 = 0
            if (r6 == 0) goto Lb1
            kotlin.ranges.IntRange r8 = new kotlin.ranges.IntRange     // Catch: java.lang.Throwable -> L1be
            r10 = 255(0xff, float:3.57E-43)
            r8.<init>(r9, r10)     // Catch: java.lang.Throwable -> L1be
            int r10 = r6.intValue()     // Catch: java.lang.Throwable -> L1be
            boolean r8 = r8.contains(r10)     // Catch: java.lang.Throwable -> L1be
            if (r8 != 0) goto Laf
            goto Lb1
        Laf:
            r6 = r9
            goto Lb2
        Lb1:
            r6 = 1
        Lb2:
            if (r6 == 0) goto L8d
            r1 = 1
            goto Lb7
        Lb6:
            r1 = r9
        Lb7:
            if (r1 != 0) goto L1a2
            java.lang.Object r1 = r11.get(r9)     // Catch: java.lang.Throwable -> L1be
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch: java.lang.Throwable -> L1be
            if (r1 != 0) goto Lc2
        Lc1:
            goto Lc9
        Lc2:
            int r1 = r1.intValue()     // Catch: java.lang.Throwable -> L1be
            if (r1 == r5) goto L12e
            goto Lc1
        Lc9:
            java.lang.Object r1 = r11.get(r9)     // Catch: java.lang.Throwable -> L1be
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch: java.lang.Throwable -> L1be
            if (r1 != 0) goto Ld2
        Ld1:
            goto Ldb
        Ld2:
            int r1 = r1.intValue()     // Catch: java.lang.Throwable -> L1be
            r2 = 127(0x7f, float:1.78E-43)
            if (r1 == r2) goto L12e
            goto Ld1
        Ldb:
            java.lang.Object r1 = r11.get(r9)     // Catch: java.lang.Throwable -> L1be
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch: java.lang.Throwable -> L1be
            if (r1 != 0) goto Le4
        Le3:
            goto L101
        Le4:
            int r1 = r1.intValue()     // Catch: java.lang.Throwable -> L1be
            r2 = 192(0xc0, float:2.69E-43)
            if (r1 != r2) goto Le3
            r1 = 1
            java.lang.Object r2 = r11.get(r1)     // Catch: java.lang.Throwable -> L1be
            java.lang.Integer r2 = (java.lang.Integer) r2     // Catch: java.lang.Throwable -> L1be
            if (r2 != 0) goto Lf6
            goto Le3
        Lf6:
            int r1 = r2.intValue()     // Catch: java.lang.Throwable -> L1be
            r2 = 168(0xa8, float:2.35E-43)
            if (r1 == r2) goto Lff
            goto Le3
        Lff:
            r1 = 1
            goto L12f
        L101:
            java.lang.Object r1 = r11.get(r9)     // Catch: java.lang.Throwable -> L1be
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch: java.lang.Throwable -> L1be
            if (r1 != 0) goto L10a
            goto L144
        L10a:
            int r1 = r1.intValue()     // Catch: java.lang.Throwable -> L1be
            r2 = 172(0xac, float:2.41E-43)
            if (r1 != r2) goto L144
            r1 = 1
            java.lang.Object r2 = r11.get(r1)     // Catch: java.lang.Throwable -> L1be
            kotlin.jvm.internal.Intrinsics.checkNotNull(r2)     // Catch: java.lang.Throwable -> L1be
            java.lang.Number r2 = (java.lang.Number) r2     // Catch: java.lang.Throwable -> L1be
            int r2 = r2.intValue()     // Catch: java.lang.Throwable -> L1be
            r3 = 16
            if (r3 > r2) goto L12a
            r3 = 32
            if (r2 >= r3) goto L12a
            r2 = r1
            goto L12b
        L12a:
            r2 = r9
        L12b:
            if (r2 == 0) goto L144
            goto L12f
        L12e:
            r1 = 1
        L12f:
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r2 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L1be
            int r2 = r2.m6126Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if1$funconnect$classCarControlConnection()     // Catch: java.lang.Throwable -> L1be
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r3 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L1be
            int r3 = r3.m6129Int$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if1$funconnect$classCarControlConnection()     // Catch: java.lang.Throwable -> L1be
            if (r14 > r3) goto L141
            if (r2 > r14) goto L141
            r2 = r1
            goto L142
        L141:
            r2 = r9
        L142:
            if (r2 != 0) goto L147
        L144:
            r19 = r11
            goto L1a4
        L147:
            long r6 = r13.generation     // Catch: java.lang.Throwable -> L1be
            kotlinx.coroutines.flow.MutableStateFlow<vea.raceremote.control.CarConnectionState> r1 = r13.mutableState     // Catch: java.lang.Throwable -> L1be
            vea.raceremote.control.CarConnectionState r2 = new vea.raceremote.control.CarConnectionState     // Catch: java.lang.Throwable -> L1be
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r3 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L1be
            java.lang.String r17 = r3.m6149String$arg0$call$init$$arg0$call$setvalue$$funconnect$classCarControlConnection()     // Catch: java.lang.Throwable -> L1be
            r18 = 0
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r3 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L1be
            boolean r19 = r3.m6112Boolean$arg2$call$init$$arg0$call$setvalue$$funconnect$classCarControlConnection()     // Catch: java.lang.Throwable -> L1be
            r20 = 0
            r21 = 0
            r22 = 26
            r23 = 0
            r16 = r2
            r16.<init>(r17, r18, r19, r20, r21, r22, r23)     // Catch: java.lang.Throwable -> L1be
            r1.setValue(r2)     // Catch: java.lang.Throwable -> L1be
            kotlinx.coroutines.CoroutineScope r10 = r13.scope     // Catch: java.lang.Throwable -> L1be
            r25 = 0
            r26 = 0
            vea.raceremote.control.CarControlConnection$connect$2 r16 = new vea.raceremote.control.CarControlConnection$connect$2     // Catch: java.lang.Throwable -> L1be
            r17 = 0
            r1 = r16
            r2 = r30
            r3 = r31
            r4 = r32
            r5 = r36
            r8 = r35
            r9 = r34
            r18 = r10
            r10 = r37
            r19 = r11
            r11 = r33
            r12 = r17
            r1.<init>(r2, r3, r4, r5, r6, r8, r9, r10, r11, r12)     // Catch: java.lang.Throwable -> L1be
            r27 = r16
            kotlin.jvm.functions.Function2 r27 = (kotlin.jvm.functions.Function2) r27     // Catch: java.lang.Throwable -> L1be
            r28 = 3
            r29 = 0
            r24 = r18
            kotlinx.coroutines.Job r1 = kotlinx.coroutines.BuildersKt.launch$default(r24, r25, r26, r27, r28, r29)     // Catch: java.lang.Throwable -> L1be
            r13.job = r1     // Catch: java.lang.Throwable -> L1be
            monitor-exit(r30)
            return
        L1a2:
            r19 = r11
        L1a4:
            kotlinx.coroutines.flow.MutableStateFlow<vea.raceremote.control.CarConnectionState> r1 = r13.mutableState     // Catch: java.lang.Throwable -> L1be
            vea.raceremote.control.CarConnectionState r10 = new vea.raceremote.control.CarConnectionState     // Catch: java.lang.Throwable -> L1be
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r2 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L1be
            java.lang.String r3 = r2.m6148String$arg0$call$init$$arg0$call$setvalue$$branch$if1$funconnect$classCarControlConnection()     // Catch: java.lang.Throwable -> L1be
            r4 = 0
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 30
            r9 = 0
            r2 = r10
            r2.<init>(r3, r4, r5, r6, r7, r8, r9)     // Catch: java.lang.Throwable -> L1be
            r1.setValue(r10)     // Catch: java.lang.Throwable -> L1be
            monitor-exit(r30)
            return
        L1be:
            r0 = move-exception
            monitor-exit(r30)
            throw r0
    }

    public final synchronized void disconnect(java.lang.String r11) {
            r10 = this;
            monitor-enter(r10)
            java.lang.String r0 = "message"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r11, r0)     // Catch: java.lang.Throwable -> L3f
            long r0 = r10.generation     // Catch: java.lang.Throwable -> L3f
            r2 = 1
            long r0 = r0 + r2
            r10.generation = r0     // Catch: java.lang.Throwable -> L3f
            kotlinx.coroutines.flow.MutableStateFlow<vea.raceremote.control.CarConnectionState> r0 = r10.mutableState     // Catch: java.lang.Throwable -> L3f
            vea.raceremote.control.CarConnectionState r9 = new vea.raceremote.control.CarConnectionState     // Catch: java.lang.Throwable -> L3f
            r3 = 0
            r4 = 0
            r5 = 0
            r6 = 0
            r7 = 30
            r8 = 0
            r1 = r9
            r2 = r11
            r1.<init>(r2, r3, r4, r5, r6, r7, r8)     // Catch: java.lang.Throwable -> L3f
            r0.setValue(r9)     // Catch: java.lang.Throwable -> L3f
            kotlinx.coroutines.Job r0 = r10.job     // Catch: java.lang.Throwable -> L3f
            r1 = 0
            if (r0 == 0) goto L29
            r2 = 1
            kotlinx.coroutines.Job.DefaultImpls.cancel$default(r0, r1, r2, r1)     // Catch: java.lang.Throwable -> L3f
        L29:
            r10.job = r1     // Catch: java.lang.Throwable -> L3f
            vea.raceremote.control.UdpControlClient r0 = r10.udp     // Catch: java.lang.Throwable -> L3f
            if (r0 == 0) goto L32
            r0.close()     // Catch: java.lang.Throwable -> L3f
        L32:
            r10.udp = r1     // Catch: java.lang.Throwable -> L3f
            vea.raceremote.control.CarControlClient r0 = r10.websocket     // Catch: java.lang.Throwable -> L3f
            if (r0 == 0) goto L3b
            r0.close()     // Catch: java.lang.Throwable -> L3f
        L3b:
            r10.websocket = r1     // Catch: java.lang.Throwable -> L3f
            monitor-exit(r10)
            return
        L3f:
            r11 = move-exception
            monitor-exit(r10)
            throw r11
    }

    public final kotlinx.coroutines.flow.StateFlow<vea.raceremote.control.CarConnectionState> getState() {
            r1 = this;
            kotlinx.coroutines.flow.StateFlow<vea.raceremote.control.CarConnectionState> r0 = r1.state
            return r0
    }

    public final synchronized void setInput(float r5, float r6) {
            r4 = this;
            monitor-enter(r4)
            boolean r0 = java.lang.Float.isInfinite(r5)     // Catch: java.lang.Throwable -> L82
            r1 = 1
            r2 = 0
            if (r0 != 0) goto L11
            boolean r0 = java.lang.Float.isNaN(r5)     // Catch: java.lang.Throwable -> L82
            if (r0 != 0) goto L11
            r0 = r1
            goto L12
        L11:
            r0 = r2
        L12:
            if (r0 == 0) goto L77
            boolean r0 = java.lang.Float.isInfinite(r6)     // Catch: java.lang.Throwable -> L82
            if (r0 != 0) goto L21
            boolean r0 = java.lang.Float.isNaN(r6)     // Catch: java.lang.Throwable -> L82
            if (r0 != 0) goto L21
            goto L22
        L21:
            r1 = r2
        L22:
            if (r1 != 0) goto L25
            goto L77
        L25:
            kotlinx.coroutines.flow.MutableStateFlow<vea.raceremote.control.CarConnectionState> r0 = r4.mutableState     // Catch: java.lang.Throwable -> L82
            java.lang.Object r0 = r0.getValue()     // Catch: java.lang.Throwable -> L82
            vea.raceremote.control.CarConnectionState r0 = (vea.raceremote.control.CarConnectionState) r0     // Catch: java.lang.Throwable -> L82
            boolean r0 = r0.getConnected()     // Catch: java.lang.Throwable -> L82
            if (r0 != 0) goto L35
            monitor-exit(r4)
            return
        L35:
            vea.raceremote.control.UdpControlClient r0 = r4.udp     // Catch: java.lang.Throwable -> L82
            if (r0 == 0) goto L6e
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r1 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L82
            float r1 = r1.m6122Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$callinput$else$when$funsetInput$classCarControlConnection()     // Catch: java.lang.Throwable -> L82
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r2 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L82
            float r2 = r2.m6124Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg0$callinput$else$when$funsetInput$classCarControlConnection()     // Catch: java.lang.Throwable -> L82
            float r1 = kotlin.ranges.RangesKt.coerceIn(r5, r1, r2)     // Catch: java.lang.Throwable -> L82
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r2 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L82
            int r2 = r2.m6133Int$arg0$calltimes$$this$calltoInt$arg0$callinput$else$when$funsetInput$classCarControlConnection()     // Catch: java.lang.Throwable -> L82
            float r2 = (float) r2     // Catch: java.lang.Throwable -> L82
            float r1 = r1 * r2
            int r1 = (int) r1     // Catch: java.lang.Throwable -> L82
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r2 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L82
            float r2 = r2.m6123Float$arg0$callcoerceIn$$this$calltimes$$this$calltoInt$arg1$callinput$else$when$funsetInput$classCarControlConnection()     // Catch: java.lang.Throwable -> L82
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r3 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L82
            float r3 = r3.m6125Float$arg1$callcoerceIn$$this$calltimes$$this$calltoInt$arg1$callinput$else$when$funsetInput$classCarControlConnection()     // Catch: java.lang.Throwable -> L82
            float r2 = kotlin.ranges.RangesKt.coerceIn(r6, r2, r3)     // Catch: java.lang.Throwable -> L82
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r3 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L82
            int r3 = r3.m6134Int$arg0$calltimes$$this$calltoInt$arg1$callinput$else$when$funsetInput$classCarControlConnection()     // Catch: java.lang.Throwable -> L82
            float r3 = (float) r3     // Catch: java.lang.Throwable -> L82
            float r2 = r2 * r3
            int r2 = (int) r2     // Catch: java.lang.Throwable -> L82
            r0.input(r1, r2)     // Catch: java.lang.Throwable -> L82
        L6e:
            vea.raceremote.control.CarControlClient r0 = r4.websocket     // Catch: java.lang.Throwable -> L82
            if (r0 == 0) goto L75
            r0.setInput(r5, r6)     // Catch: java.lang.Throwable -> L82
        L75:
            monitor-exit(r4)
            return
        L77:
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r0 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE     // Catch: java.lang.Throwable -> L82
            java.lang.String r0 = r0.m6154String$arg0$calldisconnect$branch$if$funsetInput$classCarControlConnection()     // Catch: java.lang.Throwable -> L82
            r4.disconnect(r0)     // Catch: java.lang.Throwable -> L82
            monitor-exit(r4)
            return
        L82:
            r5 = move-exception
            monitor-exit(r4)
            throw r5
    }
}
