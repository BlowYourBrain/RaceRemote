package vea.raceremote.control;

/* JADX INFO: compiled from: CarControlScreen.kt */
/* JADX INFO: loaded from: classes4.dex */
@kotlin.Metadata(d1 = {"\u0000&\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\u001aD\u0010\u0000\u001a\u00020\u00012+\b\u0002\u0010\u0002\u001a%\u0012\u0004\u0012\u00020\u0004\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00010\u0005\u0012\u0004\u0012\u00020\u00010\u0003¢\u0006\u0002\b\u00072\b\b\u0002\u0010\b\u001a\u00020\tH\u0007¢\u0006\u0002\u0010\n¨\u0006\u000b"}, d2 = {"CarControlScreen", "", "carPicker", "Lkotlin/Function2;", "", "Lkotlin/Function1;", "Lvea/raceremote/control/DiscoveredCar;", "Landroidx/compose/runtime/Composable;", "statusPort", "", "(Lkotlin/jvm/functions/Function4;ILandroidx/compose/runtime/Composer;II)V", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class CarControlScreenKt {

    /* JADX INFO: renamed from: vea.raceremote.control.CarControlScreenKt$CarControlScreen$1, reason: invalid class name */
    /* JADX INFO: compiled from: CarControlScreen.kt */
    @kotlin.Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "vea.raceremote.control.CarControlScreenKt$CarControlScreen$1", f = "CarControlScreen.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ androidx.compose.runtime.State<vea.raceremote.control.CarConnectionState> $state$delegate;
        final /* synthetic */ androidx.compose.runtime.MutableState<java.lang.Boolean> $videoActive$delegate;
        final /* synthetic */ android.net.wifi.WifiManager.WifiLock $wifiLock;
        int label;

        AnonymousClass1(android.net.wifi.WifiManager.WifiLock r2, androidx.compose.runtime.State<vea.raceremote.control.CarConnectionState> r3, androidx.compose.runtime.MutableState<java.lang.Boolean> r4, kotlin.coroutines.Continuation<? super vea.raceremote.control.CarControlScreenKt.AnonymousClass1> r5) {
                r1 = this;
                r1.$wifiLock = r2
                r1.$state$delegate = r3
                r1.$videoActive$delegate = r4
                r0 = 2
                r1.<init>(r0, r5)
                return
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object r5, kotlin.coroutines.Continuation<?> r6) {
                r4 = this;
                vea.raceremote.control.CarControlScreenKt$CarControlScreen$1 r0 = new vea.raceremote.control.CarControlScreenKt$CarControlScreen$1
                android.net.wifi.WifiManager$WifiLock r1 = r4.$wifiLock
                androidx.compose.runtime.State<vea.raceremote.control.CarConnectionState> r2 = r4.$state$delegate
                androidx.compose.runtime.MutableState<java.lang.Boolean> r3 = r4.$videoActive$delegate
                r0.<init>(r1, r2, r3, r6)
                kotlin.coroutines.Continuation r0 = (kotlin.coroutines.Continuation) r0
                return r0
        }

        @Override // kotlin.jvm.functions.Function2
        public /* bridge */ /* synthetic */ java.lang.Object invoke(kotlinx.coroutines.CoroutineScope r2, kotlin.coroutines.Continuation<? super kotlin.Unit> r3) {
                r1 = this;
                kotlinx.coroutines.CoroutineScope r2 = (kotlinx.coroutines.CoroutineScope) r2
                kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3
                java.lang.Object r0 = r1.invoke2(r2, r3)
                return r0
        }

        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
        public final java.lang.Object invoke2(kotlinx.coroutines.CoroutineScope r3, kotlin.coroutines.Continuation<? super kotlin.Unit> r4) {
                r2 = this;
                kotlin.coroutines.Continuation r0 = r2.create(r3, r4)
                vea.raceremote.control.CarControlScreenKt$CarControlScreen$1 r0 = (vea.raceremote.control.CarControlScreenKt.AnonymousClass1) r0
                kotlin.Unit r1 = kotlin.Unit.INSTANCE
                java.lang.Object r0 = r0.invokeSuspend(r1)
                return r0
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object r3) {
                r2 = this;
                kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
                int r0 = r2.label
                switch(r0) {
                    case 0: goto L10;
                    default: goto L8;
                }
            L8:
                java.lang.IllegalStateException r3 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r3.<init>(r0)
                throw r3
            L10:
                kotlin.ResultKt.throwOnFailure(r3)
                r0 = r2
                androidx.compose.runtime.State<vea.raceremote.control.CarConnectionState> r1 = r0.$state$delegate
                vea.raceremote.control.CarConnectionState r1 = vea.raceremote.control.CarControlScreenKt.access$CarControlScreen$lambda$1(r1)
                boolean r1 = r1.getConnected()
                if (r1 != 0) goto L43
                androidx.compose.runtime.State<vea.raceremote.control.CarConnectionState> r1 = r0.$state$delegate
                vea.raceremote.control.CarConnectionState r1 = vea.raceremote.control.CarControlScreenKt.access$CarControlScreen$lambda$1(r1)
                boolean r1 = r1.getConnecting()
                if (r1 != 0) goto L43
                androidx.compose.runtime.MutableState<java.lang.Boolean> r1 = r0.$videoActive$delegate
                boolean r1 = vea.raceremote.control.CarControlScreenKt.access$CarControlScreen$lambda$19(r1)
                if (r1 == 0) goto L35
                goto L43
            L35:
                android.net.wifi.WifiManager$WifiLock r1 = r0.$wifiLock
                boolean r1 = r1.isHeld()
                if (r1 == 0) goto L50
                android.net.wifi.WifiManager$WifiLock r1 = r0.$wifiLock
                r1.release()
                goto L50
            L43:
                android.net.wifi.WifiManager$WifiLock r1 = r0.$wifiLock
                boolean r1 = r1.isHeld()
                if (r1 != 0) goto L50
                android.net.wifi.WifiManager$WifiLock r1 = r0.$wifiLock
                r1.acquire()
            L50:
                kotlin.Unit r1 = kotlin.Unit.INSTANCE
                return r1
        }
    }

    /* JADX INFO: renamed from: vea.raceremote.control.CarControlScreenKt$CarControlScreen$2, reason: invalid class name */
    /* JADX INFO: compiled from: CarControlScreen.kt */
    @kotlin.Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    static final class AnonymousClass2 extends kotlin.jvm.internal.Lambda implements kotlin.jvm.functions.Function1<androidx.compose.runtime.DisposableEffectScope, androidx.compose.runtime.DisposableEffectResult> {
        final /* synthetic */ vea.raceremote.control.CarControlConnection $client;
        final /* synthetic */ android.content.Context $context;
        final /* synthetic */ okhttp3.OkHttpClient $http;
        final /* synthetic */ androidx.lifecycle.Lifecycle $lifecycle;
        final /* synthetic */ androidx.compose.runtime.MutableState<java.lang.Float> $steering$delegate;
        final /* synthetic */ androidx.compose.runtime.MutableState<java.lang.Float> $throttle$delegate;
        final /* synthetic */ android.net.wifi.WifiManager.WifiLock $wifiLock;

        public static /* synthetic */ void $r8$lambda$ee1UTPUCNr98yljsiVoY9gpratg(vea.raceremote.control.CarControlConnection r0, android.net.wifi.WifiManager.WifiLock r1, androidx.compose.runtime.MutableState r2, androidx.compose.runtime.MutableState r3, androidx.lifecycle.LifecycleOwner r4, androidx.lifecycle.Lifecycle.Event r5) {
                invoke$lambda$0(r0, r1, r2, r3, r4, r5)
                return
        }

        AnonymousClass2(androidx.lifecycle.Lifecycle r2, android.content.Context r3, vea.raceremote.control.CarControlConnection r4, android.net.wifi.WifiManager.WifiLock r5, androidx.compose.runtime.MutableState<java.lang.Float> r6, androidx.compose.runtime.MutableState<java.lang.Float> r7, okhttp3.OkHttpClient r8) {
                r1 = this;
                r1.$lifecycle = r2
                r1.$context = r3
                r1.$client = r4
                r1.$wifiLock = r5
                r1.$throttle$delegate = r6
                r1.$steering$delegate = r7
                r1.$http = r8
                r0 = 1
                r1.<init>(r0)
                return
        }

        private static final void invoke$lambda$0(vea.raceremote.control.CarControlConnection r1, android.net.wifi.WifiManager.WifiLock r2, androidx.compose.runtime.MutableState r3, androidx.compose.runtime.MutableState r4, androidx.lifecycle.LifecycleOwner r5, androidx.lifecycle.Lifecycle.Event r6) {
                java.lang.String r0 = "$client"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r1, r0)
                java.lang.String r0 = "$throttle$delegate"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
                java.lang.String r0 = "$steering$delegate"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
                java.lang.String r0 = "<anonymous parameter 0>"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
                java.lang.String r5 = "event"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r6, r5)
                androidx.lifecycle.Lifecycle$Event r5 = androidx.lifecycle.Lifecycle.Event.ON_PAUSE
                if (r6 == r5) goto L21
                androidx.lifecycle.Lifecycle$Event r5 = androidx.lifecycle.Lifecycle.Event.ON_STOP
                if (r6 != r5) goto L45
            L21:
                vea.raceremote.control.LiveLiterals$CarControlScreenKt r5 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
                float r5 = r5.m6182Float$arg0$call$setthrottle$$branch$if$fun$anonymous$$valobserver$fun$anonymous$$arg2$callDisposableEffect$funCarControlScreen()
                vea.raceremote.control.CarControlScreenKt.access$CarControlScreen$lambda$12(r3, r5)
                vea.raceremote.control.LiveLiterals$CarControlScreenKt r5 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
                float r5 = r5.m6174Float$arg0$call$setsteering$$branch$if$fun$anonymous$$valobserver$fun$anonymous$$arg2$callDisposableEffect$funCarControlScreen()
                vea.raceremote.control.CarControlScreenKt.access$CarControlScreen$lambda$15(r4, r5)
                vea.raceremote.control.LiveLiterals$CarControlScreenKt r5 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
                java.lang.String r5 = r5.m6231String$arg0$calldisconnect$branch$if$fun$anonymous$$valobserver$fun$anonymous$$arg2$callDisposableEffect$funCarControlScreen()
                r1.disconnect(r5)
                boolean r5 = r2.isHeld()
                if (r5 == 0) goto L45
                r2.release()
            L45:
                return
        }

        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
        public final androidx.compose.runtime.DisposableEffectResult invoke2(androidx.compose.runtime.DisposableEffectScope r13) {
                r12 = this;
                java.lang.String r0 = "$this$DisposableEffect"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r13, r0)
                vea.raceremote.control.CarControlConnection r0 = r12.$client
                android.net.wifi.WifiManager$WifiLock r1 = r12.$wifiLock
                androidx.compose.runtime.MutableState<java.lang.Float> r2 = r12.$throttle$delegate
                androidx.compose.runtime.MutableState<java.lang.Float> r3 = r12.$steering$delegate
                vea.raceremote.control.CarControlScreenKt$CarControlScreen$2$$ExternalSyntheticLambda0 r4 = new vea.raceremote.control.CarControlScreenKt$CarControlScreen$2$$ExternalSyntheticLambda0
                r4.<init>(r0, r1, r2, r3)
                r0 = r4
                androidx.lifecycle.Lifecycle r1 = r12.$lifecycle
                r2 = r0
                androidx.lifecycle.LifecycleObserver r2 = (androidx.lifecycle.LifecycleObserver) r2
                r1.addObserver(r2)
                android.content.Context r1 = r12.$context
                boolean r2 = r1 instanceof android.app.Activity
                if (r2 == 0) goto L24
                android.app.Activity r1 = (android.app.Activity) r1
                goto L25
            L24:
                r1 = 0
            L25:
                if (r1 == 0) goto L32
                android.view.Window r1 = r1.getWindow()
                if (r1 == 0) goto L32
                r2 = 128(0x80, float:1.8E-43)
                r1.addFlags(r2)
            L32:
                androidx.lifecycle.Lifecycle r6 = r12.$lifecycle
                vea.raceremote.control.CarControlConnection r8 = r12.$client
                android.net.wifi.WifiManager$WifiLock r9 = r12.$wifiLock
                okhttp3.OkHttpClient r10 = r12.$http
                android.content.Context r11 = r12.$context
                r1 = r13
                r2 = 0
                vea.raceremote.control.CarControlScreenKt$CarControlScreen$2$invoke$$inlined$onDispose$1 r3 = new vea.raceremote.control.CarControlScreenKt$CarControlScreen$2$invoke$$inlined$onDispose$1
                r5 = r3
                r7 = r0
                r5.<init>(r6, r7, r8, r9, r10, r11)
                androidx.compose.runtime.DisposableEffectResult r3 = (androidx.compose.runtime.DisposableEffectResult) r3
                return r3
        }

        @Override // kotlin.jvm.functions.Function1
        public /* bridge */ /* synthetic */ androidx.compose.runtime.DisposableEffectResult invoke(androidx.compose.runtime.DisposableEffectScope r2) {
                r1 = this;
                r0 = r2
                androidx.compose.runtime.DisposableEffectScope r0 = (androidx.compose.runtime.DisposableEffectScope) r0
                androidx.compose.runtime.DisposableEffectResult r0 = r1.invoke2(r0)
                return r0
        }
    }


    public static final void CarControlScreen(kotlin.jvm.functions.Function4<? super java.lang.Boolean, ? super kotlin.jvm.functions.Function1<? super vea.raceremote.control.DiscoveredCar, kotlin.Unit>, ? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit> r142, int r143, androidx.compose.runtime.Composer r144, int r145, int r146) {
            r0 = r145
            r1 = r146
            r2 = -465823741(0xffffffffe43c1803, float:-1.3878872E22)
            r3 = r144
            androidx.compose.runtime.Composer r2 = r3.startRestartGroup(r2)
            java.lang.String r3 = "C(CarControlScreen)27@1007L7,28@1055L7,29@1090L96,30@1217L16,31@1250L50,32@1324L41,33@1392L48,34@1470L50,35@1541L31,36@1593L31,37@1646L42,38@1712L34,39@1766L34,40@1816L112,41@1948L233,46@2186L244,51@2435L864,68@3336L58,68@3304L90,69@3462L13,69@3399L5030:CarControlScreen.kt#597736"
            androidx.compose.runtime.ComposerKt.sourceInformation(r2, r3)
            r3 = r145
            r4 = r1 & 1
            if (r4 == 0) goto L1d
            r3 = r3 | 6
            r5 = r142
            goto L30
        L1d:
            r5 = r0 & 14
            if (r5 != 0) goto L2e
            r5 = r142
            boolean r6 = r2.changed(r5)
            if (r6 == 0) goto L2b
            r6 = 4
            goto L2c
        L2b:
            r6 = 2
        L2c:
            r3 = r3 | r6
            goto L30
        L2e:
            r5 = r142
        L30:
            r6 = r0 & 112(0x70, float:1.57E-43)
            if (r6 != 0) goto L49
            r6 = r1 & 2
            if (r6 != 0) goto L43
            r6 = r143
            boolean r7 = r2.changed(r6)
            if (r7 == 0) goto L45
            r7 = 32
            goto L47
        L43:
            r6 = r143
        L45:
            r7 = 16
        L47:
            r3 = r3 | r7
            goto L4b
        L49:
            r6 = r143
        L4b:
            r7 = r3 & 91
            r8 = 18
            if (r7 != r8) goto L5f
            boolean r7 = r2.getSkipping()
            if (r7 != 0) goto L58
            goto L5f
        L58:
            r2.skipToGroupEnd()
            r93 = r2
            goto L140e
        L5f:
            r2.startDefaults()
            r7 = r0 & 1
            if (r7 == 0) goto L7b
            boolean r7 = r2.getDefaultsInvalid()
            if (r7 == 0) goto L6d
            goto L7b
        L6d:
            r2.skipToGroupEnd()
            r4 = r1 & 2
            if (r4 == 0) goto L76
            r3 = r3 & (-113(0xffffffffffffff8f, float:NaN))
        L76:
            r15 = r3
            r11 = r5
            r24 = r6
            goto L9a
        L7b:
            if (r4 == 0) goto L84
            vea.raceremote.control.ComposableSingletons$CarControlScreenKt r4 = vea.raceremote.control.ComposableSingletons$CarControlScreenKt.INSTANCE
            kotlin.jvm.functions.Function4 r4 = r4.m5980getLambda1$app_debug()
            goto L85
        L84:
            r4 = r5
        L85:
            r5 = r1 & 2
            if (r5 == 0) goto L96
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r5 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            int r5 = r5.m6213Int$paramstatusPort$funCarControlScreen()
            r3 = r3 & (-113(0xffffffffffffff8f, float:NaN))
            r15 = r3
            r11 = r4
            r24 = r5
            goto L9a
        L96:
            r15 = r3
            r11 = r4
            r24 = r6
        L9a:
            r2.endDefaults()
            boolean r3 = androidx.compose.runtime.ComposerKt.isTraceInProgress()
            if (r3 == 0) goto Lac
            r3 = -465823741(0xffffffffe43c1803, float:-1.3878872E22)
            r4 = -1
            java.lang.String r5 = "vea.raceremote.control.CarControlScreen (CarControlScreen.kt:23)"
            androidx.compose.runtime.ComposerKt.traceEventStart(r3, r15, r4, r5)
        Lac:
            androidx.compose.runtime.ProvidableCompositionLocal r3 = androidx.compose.ui.platform.AndroidCompositionLocals_androidKt.getLocalContext()
            androidx.compose.runtime.CompositionLocal r3 = (androidx.compose.runtime.CompositionLocal) r3
            r4 = 0
            r5 = 0
            r14 = 2023513938(0x789c5f52, float:2.5372864E34)
            java.lang.String r13 = "C:CompositionLocal.kt#9igjgp"
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(r2, r14, r13)
            java.lang.Object r6 = r2.consume(r3)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(r2)
            r25 = r6
            android.content.Context r25 = (android.content.Context) r25
            androidx.compose.runtime.ProvidableCompositionLocal r3 = androidx.compose.ui.platform.AndroidCompositionLocals_androidKt.getLocalLifecycleOwner()
            androidx.compose.runtime.CompositionLocal r3 = (androidx.compose.runtime.CompositionLocal) r3
            r4 = 0
            r5 = 0
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(r2, r14, r13)
            java.lang.Object r6 = r2.consume(r3)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(r2)
            androidx.lifecycle.LifecycleOwner r6 = (androidx.lifecycle.LifecycleOwner) r6
            androidx.lifecycle.Lifecycle r3 = r6.getLifecycle()
            java.lang.String r4 = "LocalLifecycleOwner.current.lifecycle"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r3, r4)
            r12 = r3
            r9 = 0
            r3 = r9
            r4 = 0
            r8 = -492369756(0xffffffffe2a708a4, float:-1.5406144E21)
            r2.startReplaceableGroup(r8)
            java.lang.String r7 = "C(remember):Composables.kt#9igjgp"
            androidx.compose.runtime.ComposerKt.sourceInformation(r2, r7)
            r5 = 0
            r6 = r2
            r16 = 0
            java.lang.Object r8 = r6.rememberedValue()
            r17 = 0
            androidx.compose.runtime.Composer$Companion r18 = androidx.compose.runtime.Composer.Companion
            java.lang.Object r14 = r18.getEmpty()
            r10 = 0
            r18 = r5
            r5 = 1
            if (r8 != r14) goto L11d
            r14 = 0
            vea.raceremote.control.CarControlConnection r9 = new vea.raceremote.control.CarControlConnection
            vea.raceremote.control.CarControlScreenKt$CarControlScreen$client$1$1 r20 = vea.raceremote.control.CarControlScreenKt$CarControlScreen$client$1$1.INSTANCE
            r21 = r3
            r3 = r20
            kotlin.jvm.functions.Function1 r3 = (kotlin.jvm.functions.Function1) r3
            r9.<init>(r10, r3, r5, r10)
            r3 = r9
            r6.updateRememberedValue(r3)
            goto L120
        L11d:
            r21 = r3
            r3 = r8
        L120:
            r2.endReplaceableGroup()
            r14 = r3
            vea.raceremote.control.CarControlConnection r14 = (vea.raceremote.control.CarControlConnection) r14
            kotlinx.coroutines.flow.StateFlow r3 = r14.getState()
            r4 = 8
            androidx.compose.runtime.State r9 = androidx.compose.runtime.SnapshotStateKt.collectAsState(r3, r10, r2, r4, r5)
            r8 = 0
            java.lang.Object[] r3 = new java.lang.Object[r8]
            r4 = 0
            r6 = 0
            vea.raceremote.control.CarControlScreenKt$CarControlScreen$host$2 r16 = vea.raceremote.control.CarControlScreenKt$CarControlScreen$host$2.INSTANCE
            kotlin.jvm.functions.Function0 r16 = (kotlin.jvm.functions.Function0) r16
            r17 = 3080(0xc08, float:4.316E-42)
            r18 = 6
            r5 = r6
            r6 = r16
            r10 = r7
            r7 = r2
            r16 = r8
            r8 = r17
            r142 = r9
            r0 = r16
            r9 = r18
            java.lang.Object r3 = androidx.compose.runtime.saveable.RememberSaveableKt.m1317rememberSaveable(r3, r4, r5, r6, r7, r8, r9)
            r35 = r3
            androidx.compose.runtime.MutableState r35 = (androidx.compose.runtime.MutableState) r35
            java.lang.Object[] r3 = new java.lang.Object[r0]
            r5 = 0
            vea.raceremote.control.CarControlScreenKt$CarControlScreen$controlPort$2 r6 = vea.raceremote.control.CarControlScreenKt$CarControlScreen$controlPort$2.INSTANCE
            kotlin.jvm.functions.Function0 r6 = (kotlin.jvm.functions.Function0) r6
            r8 = 3080(0xc08, float:4.316E-42)
            r9 = 6
            java.lang.Object r3 = androidx.compose.runtime.saveable.RememberSaveableKt.m1317rememberSaveable(r3, r4, r5, r6, r7, r8, r9)
            r36 = r3
            androidx.compose.runtime.MutableState r36 = (androidx.compose.runtime.MutableState) r36
            java.lang.Object[] r3 = new java.lang.Object[r0]
            vea.raceremote.control.CarControlScreenKt$CarControlScreen$selectedChipId$2 r6 = vea.raceremote.control.CarControlScreenKt$CarControlScreen$selectedChipId$2.INSTANCE
            kotlin.jvm.functions.Function0 r6 = (kotlin.jvm.functions.Function0) r6
            java.lang.Object r3 = androidx.compose.runtime.saveable.RememberSaveableKt.m1317rememberSaveable(r3, r4, r5, r6, r7, r8, r9)
            r37 = r3
            androidx.compose.runtime.MutableState r37 = (androidx.compose.runtime.MutableState) r37
            java.lang.Object[] r3 = new java.lang.Object[r0]
            vea.raceremote.control.CarControlScreenKt$CarControlScreen$selectedTransport$2 r6 = vea.raceremote.control.CarControlScreenKt$CarControlScreen$selectedTransport$2.INSTANCE
            kotlin.jvm.functions.Function0 r6 = (kotlin.jvm.functions.Function0) r6
            java.lang.Object r3 = androidx.compose.runtime.saveable.RememberSaveableKt.m1317rememberSaveable(r3, r4, r5, r6, r7, r8, r9)
            r38 = r3
            androidx.compose.runtime.MutableState r38 = (androidx.compose.runtime.MutableState) r38
            r3 = r0
            r4 = 0
            r9 = -492369756(0xffffffffe2a708a4, float:-1.5406144E21)
            r2.startReplaceableGroup(r9)
            androidx.compose.runtime.ComposerKt.sourceInformation(r2, r10)
            r5 = 0
            r6 = r2
            r7 = 0
            java.lang.Object r8 = r6.rememberedValue()
            r16 = 0
            androidx.compose.runtime.Composer$Companion r17 = androidx.compose.runtime.Composer.Companion
            java.lang.Object r9 = r17.getEmpty()
            if (r8 != r9) goto L1bb
            r9 = 0
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r17 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            float r17 = r17.m6190Float$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valthrottle$delegate$funCarControlScreen()
            java.lang.Float r0 = java.lang.Float.valueOf(r17)
            r17 = r3
            r18 = r4
            r3 = 2
            r4 = 0
            androidx.compose.runtime.MutableState r0 = androidx.compose.runtime.SnapshotStateKt.mutableStateOf$default(r0, r4, r3, r4)
            r6.updateRememberedValue(r0)
            goto L1c0
        L1bb:
            r17 = r3
            r18 = r4
            r0 = r8
        L1c0:
            r2.endReplaceableGroup()
            androidx.compose.runtime.MutableState r0 = (androidx.compose.runtime.MutableState) r0
            r3 = 0
            r4 = r3
            r3 = 0
            r9 = -492369756(0xffffffffe2a708a4, float:-1.5406144E21)
            r2.startReplaceableGroup(r9)
            androidx.compose.runtime.ComposerKt.sourceInformation(r2, r10)
            r5 = 0
            r6 = r2
            r7 = 0
            java.lang.Object r8 = r6.rememberedValue()
            r16 = 0
            androidx.compose.runtime.Composer$Companion r17 = androidx.compose.runtime.Composer.Companion
            java.lang.Object r9 = r17.getEmpty()
            if (r8 != r9) goto L201
            r9 = 0
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r17 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            float r17 = r17.m6189Float$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valsteering$delegate$funCarControlScreen()
            r18 = r3
            java.lang.Float r3 = java.lang.Float.valueOf(r17)
            r17 = r4
            r19 = r5
            r4 = 2
            r5 = 0
            androidx.compose.runtime.MutableState r3 = androidx.compose.runtime.SnapshotStateKt.mutableStateOf$default(r3, r5, r4, r5)
            r6.updateRememberedValue(r3)
            goto L208
        L201:
            r18 = r3
            r17 = r4
            r19 = r5
            r3 = r8
        L208:
            r2.endReplaceableGroup()
            r9 = r3
            androidx.compose.runtime.MutableState r9 = (androidx.compose.runtime.MutableState) r9
            r3 = 0
            java.lang.Object[] r4 = new java.lang.Object[r3]
            r5 = 0
            r6 = 0
            vea.raceremote.control.CarControlScreenKt$CarControlScreen$showVideo$2 r3 = vea.raceremote.control.CarControlScreenKt$CarControlScreen$showVideo$2.INSTANCE
            r7 = r3
            kotlin.jvm.functions.Function0 r7 = (kotlin.jvm.functions.Function0) r7
            r8 = 3080(0xc08, float:4.316E-42)
            r16 = 6
            r3 = r4
            r4 = r5
            r5 = r6
            r6 = r7
            r7 = r2
            r40 = r9
            r1 = -492369756(0xffffffffe2a708a4, float:-1.5406144E21)
            r9 = r16
            java.lang.Object r3 = androidx.compose.runtime.saveable.RememberSaveableKt.m1317rememberSaveable(r3, r4, r5, r6, r7, r8, r9)
            r9 = r3
            androidx.compose.runtime.MutableState r9 = (androidx.compose.runtime.MutableState) r9
            r3 = 0
            r4 = r3
            r3 = 0
            r2.startReplaceableGroup(r1)
            androidx.compose.runtime.ComposerKt.sourceInformation(r2, r10)
            r5 = 0
            r6 = r2
            r7 = 0
            java.lang.Object r8 = r6.rememberedValue()
            r16 = 0
            androidx.compose.runtime.Composer$Companion r17 = androidx.compose.runtime.Composer.Companion
            java.lang.Object r1 = r17.getEmpty()
            if (r8 != r1) goto L268
            r1 = 0
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r17 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            boolean r17 = r17.m6163Boolean$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valvideoActive$delegate$funCarControlScreen()
            r18 = r1
            java.lang.Boolean r1 = java.lang.Boolean.valueOf(r17)
            r17 = r3
            r19 = r4
            r3 = 2
            r4 = 0
            androidx.compose.runtime.MutableState r1 = androidx.compose.runtime.SnapshotStateKt.mutableStateOf$default(r1, r4, r3, r4)
            r6.updateRememberedValue(r1)
            goto L26d
        L268:
            r17 = r3
            r19 = r4
            r1 = r8
        L26d:
            r2.endReplaceableGroup()
            androidx.compose.runtime.MutableState r1 = (androidx.compose.runtime.MutableState) r1
            r3 = 0
            r4 = r3
            r3 = 0
            r5 = -492369756(0xffffffffe2a708a4, float:-1.5406144E21)
            r2.startReplaceableGroup(r5)
            androidx.compose.runtime.ComposerKt.sourceInformation(r2, r10)
            r5 = 0
            r6 = r2
            r7 = 0
            java.lang.Object r8 = r6.rememberedValue()
            r16 = 0
            androidx.compose.runtime.Composer$Companion r17 = androidx.compose.runtime.Composer.Companion
            r18 = r3
            java.lang.Object r3 = r17.getEmpty()
            if (r8 != r3) goto L2b0
            r3 = 0
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r17 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            boolean r17 = r17.m6162Boolean$arg0$callmutableStateOf$fun$anonymous$$arg0$callremember$valdriving$delegate$funCarControlScreen()
            r19 = r3
            java.lang.Boolean r3 = java.lang.Boolean.valueOf(r17)
            r17 = r4
            r20 = r5
            r4 = 2
            r5 = 0
            androidx.compose.runtime.MutableState r3 = androidx.compose.runtime.SnapshotStateKt.mutableStateOf$default(r3, r5, r4, r5)
            r6.updateRememberedValue(r3)
            goto L2b5
        L2b0:
            r17 = r4
            r20 = r5
            r3 = r8
        L2b5:
            r2.endReplaceableGroup()
            r8 = r3
            androidx.compose.runtime.MutableState r8 = (androidx.compose.runtime.MutableState) r8
            r3 = 0
            r4 = r3
            r3 = 0
            r5 = -492369756(0xffffffffe2a708a4, float:-1.5406144E21)
            r2.startReplaceableGroup(r5)
            androidx.compose.runtime.ComposerKt.sourceInformation(r2, r10)
            r5 = 0
            r6 = r2
            r7 = 0
            r16 = r3
            java.lang.Object r3 = r6.rememberedValue()
            r17 = 0
            androidx.compose.runtime.Composer$Companion r18 = androidx.compose.runtime.Composer.Companion
            r19 = r4
            java.lang.Object r4 = r18.getEmpty()
            if (r3 != r4) goto L30e
            r4 = 0
            r18 = r3
            okhttp3.OkHttpClient$Builder r3 = new okhttp3.OkHttpClient$Builder
            r3.<init>()
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r20 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            r22 = r4
            r21 = r5
            long r4 = r20.m6214Long$arg0$callconnectTimeout$$this$callreadTimeout$$this$callbuild$fun$anonymous$$arg0$callremember$valhttp$funCarControlScreen()
            r20 = r7
            java.util.concurrent.TimeUnit r7 = java.util.concurrent.TimeUnit.SECONDS
            okhttp3.OkHttpClient$Builder r3 = r3.connectTimeout(r4, r7)
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r4 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            long r4 = r4.m6215Long$arg0$callreadTimeout$$this$callbuild$fun$anonymous$$arg0$callremember$valhttp$funCarControlScreen()
            java.util.concurrent.TimeUnit r7 = java.util.concurrent.TimeUnit.SECONDS
            okhttp3.OkHttpClient$Builder r3 = r3.readTimeout(r4, r7)
            okhttp3.OkHttpClient r3 = r3.build()
            r6.updateRememberedValue(r3)
            goto L314
        L30e:
            r18 = r3
            r21 = r5
            r20 = r7
        L314:
            r2.endReplaceableGroup()
            r41 = r3
            okhttp3.OkHttpClient r41 = (okhttp3.OkHttpClient) r41
            r3 = 0
            r4 = r3
            r3 = 0
            r5 = -492369756(0xffffffffe2a708a4, float:-1.5406144E21)
            r2.startReplaceableGroup(r5)
            androidx.compose.runtime.ComposerKt.sourceInformation(r2, r10)
            r5 = 0
            r6 = r2
            r7 = 0
            java.lang.Object r10 = r6.rememberedValue()
            r16 = 0
            androidx.compose.runtime.Composer$Companion r17 = androidx.compose.runtime.Composer.Companion
            r18 = r3
            java.lang.Object r3 = r17.getEmpty()
            if (r10 != r3) goto L36d
            r3 = 0
            r17 = r3
            android.content.Context r3 = r25.getApplicationContext()
            r19 = r4
            java.lang.Class<android.net.wifi.WifiManager> r4 = android.net.wifi.WifiManager.class
            java.lang.Object r3 = r3.getSystemService(r4)
            android.net.wifi.WifiManager r3 = (android.net.wifi.WifiManager) r3
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r4 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            java.lang.String r4 = r4.m6244String$arg1$callcreateWifiLock$$$this$callapply$fun$anonymous$$arg0$callremember$valwifiLock$funCarControlScreen()
            r20 = r5
            r5 = 4
            android.net.wifi.WifiManager$WifiLock r3 = r3.createWifiLock(r5, r4)
            r4 = r3
            r5 = 0
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r21 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            r22 = r5
            boolean r5 = r21.m6165Boolean$arg0$callsetReferenceCounted$fun$anonymous$$arg0$callapply$fun$anonymous$$arg0$callremember$valwifiLock$funCarControlScreen()
            r4.setReferenceCounted(r5)
            r6.updateRememberedValue(r3)
            goto L372
        L36d:
            r19 = r4
            r20 = r5
            r3 = r10
        L372:
            r2.endReplaceableGroup()
            r10 = r3
            android.net.wifi.WifiManager$WifiLock r10 = (android.net.wifi.WifiManager.WifiLock) r10
            vea.raceremote.control.CarConnectionState r3 = CarControlScreen$lambda$1(r142)
            boolean r3 = r3.getConnected()
            java.lang.Boolean r3 = java.lang.Boolean.valueOf(r3)
            vea.raceremote.control.CarConnectionState r4 = CarControlScreen$lambda$1(r142)
            boolean r4 = r4.getConnecting()
            java.lang.Boolean r4 = java.lang.Boolean.valueOf(r4)
            boolean r5 = CarControlScreen$lambda$19(r1)
            java.lang.Boolean r5 = java.lang.Boolean.valueOf(r5)
            vea.raceremote.control.CarControlScreenKt$CarControlScreen$1 r6 = new vea.raceremote.control.CarControlScreenKt$CarControlScreen$1
            r7 = r142
            r142 = r8
            r8 = 0
            r6.<init>(r10, r7, r1, r8)
            kotlin.jvm.functions.Function2 r6 = (kotlin.jvm.functions.Function2) r6
            r8 = 4096(0x1000, float:5.74E-42)
            r34 = r7
            r7 = r2
            r42 = r142
            androidx.compose.runtime.EffectsKt.LaunchedEffect(r3, r4, r5, r6, r7, r8)
            vea.raceremote.control.CarControlScreenKt$CarControlScreen$2 r3 = new vea.raceremote.control.CarControlScreenKt$CarControlScreen$2
            r16 = r3
            r17 = r12
            r18 = r25
            r19 = r14
            r20 = r10
            r21 = r0
            r22 = r40
            r23 = r41
            r16.<init>(r17, r18, r19, r20, r21, r22, r23)
            kotlin.jvm.functions.Function1 r3 = (kotlin.jvm.functions.Function1) r3
            r4 = 72
            androidx.compose.runtime.EffectsKt.DisposableEffect(r12, r14, r3, r2, r4)
            vea.raceremote.control.CarConnectionState r3 = CarControlScreen$lambda$1(r34)
            boolean r3 = r3.getConnected()
            java.lang.Boolean r3 = java.lang.Boolean.valueOf(r3)
            r4 = 432(0x1b0, float:6.05E-43)
            r5 = 0
            r6 = 1618982084(0x607fb4c4, float:7.370227E19)
            r2.startReplaceableGroup(r6)
            java.lang.String r6 = "C(remember)P(1,2,3):Composables.kt#9igjgp"
            androidx.compose.runtime.ComposerKt.sourceInformation(r2, r6)
            r6 = r34
            boolean r7 = r2.changed(r6)
            boolean r8 = r2.changed(r0)
            r7 = r7 | r8
            r8 = r40
            boolean r16 = r2.changed(r8)
            r7 = r7 | r16
            r142 = r2
            r16 = 0
            r17 = r4
            java.lang.Object r4 = r142.rememberedValue()
            r18 = 0
            if (r7 != 0) goto L418
            androidx.compose.runtime.Composer$Companion r19 = androidx.compose.runtime.Composer.Companion
            r20 = r5
            java.lang.Object r5 = r19.getEmpty()
            if (r4 != r5) goto L413
            goto L41a
        L413:
            r5 = r142
            r19 = r4
            goto L42e
        L418:
            r20 = r5
        L41a:
            r5 = 0
            r19 = r4
            vea.raceremote.control.CarControlScreenKt$CarControlScreen$3$1 r4 = new vea.raceremote.control.CarControlScreenKt$CarControlScreen$3$1
            r21 = r5
            r5 = 0
            r4.<init>(r6, r0, r8, r5)
            kotlin.jvm.functions.Function2 r4 = (kotlin.jvm.functions.Function2) r4
            r5 = r142
            r5.updateRememberedValue(r4)
        L42e:
            r2.endReplaceableGroup()
            kotlin.jvm.functions.Function2 r4 = (kotlin.jvm.functions.Function2) r4
            r5 = 64
            androidx.compose.runtime.EffectsKt.LaunchedEffect(r3, r4, r2, r5)
            androidx.compose.ui.Modifier$Companion r3 = androidx.compose.ui.Modifier.Companion
            androidx.compose.ui.Modifier r3 = (androidx.compose.ui.Modifier) r3
            r4 = 0
            r5 = 0
            r7 = 1
            androidx.compose.ui.Modifier r3 = androidx.compose.foundation.layout.SizeKt.fillMaxSize$default(r3, r4, r7, r5)
            androidx.compose.foundation.layout.WindowInsets$Companion r5 = androidx.compose.foundation.layout.WindowInsets.Companion
            r4 = 8
            androidx.compose.foundation.layout.WindowInsets r4 = androidx.compose.foundation.layout.WindowInsets_androidKt.getDisplayCutout(r5, r2, r4)
            androidx.compose.ui.Modifier r3 = androidx.compose.foundation.layout.WindowInsetsPaddingKt.windowInsetsPadding(r3, r4)
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r4 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            int r4 = r4.m6201Int$$$this$call$getdp$$arg0$callpadding$arg0$callColumn$funCarControlScreen()
            r5 = 0
            float r7 = (float) r4
            float r4 = androidx.compose.ui.unit.Dp.m4046constructorimpl(r7)
            androidx.compose.ui.Modifier r3 = androidx.compose.foundation.layout.PaddingKt.m427padding3ABfNKs(r3, r4)
            r4 = 0
            r5 = 0
            r7 = -483455358(0xffffffffe32f0e82, float:-3.2292256E21)
            r2.startReplaceableGroup(r7)
            java.lang.String r7 = "C(Column)P(2,3,1)77@3880L61,78@3946L133:Column.kt#2w3rfo"
            androidx.compose.runtime.ComposerKt.sourceInformation(r2, r7)
            androidx.compose.foundation.layout.Arrangement r16 = androidx.compose.foundation.layout.Arrangement.INSTANCE
            r40 = r5
            androidx.compose.foundation.layout.Arrangement$Vertical r5 = r16.getTop()
            androidx.compose.ui.Alignment$Companion r16 = androidx.compose.ui.Alignment.Companion
            r43 = r1
            androidx.compose.ui.Alignment$Horizontal r1 = r16.getStart()
            int r16 = r4 >> 3
            r16 = r16 & 14
            int r17 = r4 >> 3
            r17 = r17 & 112(0x70, float:1.57E-43)
            r18 = r12
            r12 = r16 | r17
            androidx.compose.ui.layout.MeasurePolicy r12 = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(r5, r1, r2, r12)
            int r16 = r4 << 3
            r16 = r16 & 112(0x70, float:1.57E-43)
            r44 = r16
            r45 = 0
            r46 = r1
            r1 = -1323940314(0xffffffffb1164626, float:-2.1867748E-9)
            r2.startReplaceableGroup(r1)
            java.lang.String r1 = "C(Layout)P(!1,2)74@2915L7,75@2970L7,76@3029L7,77@3041L460:Layout.kt#80mrfh"
            androidx.compose.runtime.ComposerKt.sourceInformation(r2, r1)
            androidx.compose.runtime.ProvidableCompositionLocal r16 = androidx.compose.ui.platform.CompositionLocalsKt.getLocalDensity()
            r48 = r5
            r5 = r16
            androidx.compose.runtime.CompositionLocal r5 = (androidx.compose.runtime.CompositionLocal) r5
            r16 = 6
            r17 = 0
            r49 = r9
            r9 = 2023513938(0x789c5f52, float:2.5372864E34)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(r2, r9, r13)
            java.lang.Object r9 = r2.consume(r5)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(r2)
            r5 = r9
            androidx.compose.ui.unit.Density r5 = (androidx.compose.ui.unit.Density) r5
            androidx.compose.runtime.ProvidableCompositionLocal r9 = androidx.compose.ui.platform.CompositionLocalsKt.getLocalLayoutDirection()
            androidx.compose.runtime.CompositionLocal r9 = (androidx.compose.runtime.CompositionLocal) r9
            r16 = 6
            r17 = 0
            r50 = r7
            r7 = 2023513938(0x789c5f52, float:2.5372864E34)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(r2, r7, r13)
            java.lang.Object r7 = r2.consume(r9)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(r2)
            androidx.compose.ui.unit.LayoutDirection r7 = (androidx.compose.ui.unit.LayoutDirection) r7
            androidx.compose.runtime.ProvidableCompositionLocal r9 = androidx.compose.ui.platform.CompositionLocalsKt.getLocalViewConfiguration()
            androidx.compose.runtime.CompositionLocal r9 = (androidx.compose.runtime.CompositionLocal) r9
            r16 = 6
            r17 = 0
            r51 = r10
            r10 = 2023513938(0x789c5f52, float:2.5372864E34)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(r2, r10, r13)
            java.lang.Object r10 = r2.consume(r9)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(r2)
            r9 = r10
            androidx.compose.ui.platform.ViewConfiguration r9 = (androidx.compose.ui.platform.ViewConfiguration) r9
            androidx.compose.ui.node.ComposeUiNode$Companion r10 = androidx.compose.ui.node.ComposeUiNode.Companion
            kotlin.jvm.functions.Function0 r10 = r10.getConstructor()
            kotlin.jvm.functions.Function3 r16 = androidx.compose.ui.layout.LayoutKt.materializerOf(r3)
            r52 = r3
            int r3 = r44 << 9
            r3 = r3 & 7168(0x1c00, float:1.0045E-41)
            r3 = r3 | 6
            r53 = r16
            r54 = 0
            r55 = r11
            androidx.compose.runtime.Applier r11 = r2.getApplier()
            boolean r11 = r11 instanceof androidx.compose.runtime.Applier
            if (r11 != 0) goto L51e
            androidx.compose.runtime.ComposablesKt.invalidApplier()
        L51e:
            r2.startReusableNode()
            boolean r11 = r2.getInserting()
            if (r11 == 0) goto L52b
            r2.createNode(r10)
            goto L52e
        L52b:
            r2.useNode()
        L52e:
            r2.disableReusing()
            androidx.compose.runtime.Composer r11 = androidx.compose.runtime.Updater.m1304constructorimpl(r2)
            r16 = 0
            androidx.compose.ui.node.ComposeUiNode$Companion r17 = androidx.compose.ui.node.ComposeUiNode.Companion
            r56 = r10
            kotlin.jvm.functions.Function2 r10 = r17.getSetMeasurePolicy()
            androidx.compose.runtime.Updater.m1311setimpl(r11, r12, r10)
            androidx.compose.ui.node.ComposeUiNode$Companion r10 = androidx.compose.ui.node.ComposeUiNode.Companion
            kotlin.jvm.functions.Function2 r10 = r10.getSetDensity()
            androidx.compose.runtime.Updater.m1311setimpl(r11, r5, r10)
            androidx.compose.ui.node.ComposeUiNode$Companion r10 = androidx.compose.ui.node.ComposeUiNode.Companion
            kotlin.jvm.functions.Function2 r10 = r10.getSetLayoutDirection()
            androidx.compose.runtime.Updater.m1311setimpl(r11, r7, r10)
            androidx.compose.ui.node.ComposeUiNode$Companion r10 = androidx.compose.ui.node.ComposeUiNode.Companion
            kotlin.jvm.functions.Function2 r10 = r10.getSetViewConfiguration()
            androidx.compose.runtime.Updater.m1311setimpl(r11, r9, r10)
            r2.enableReusing()
            androidx.compose.runtime.Composer r10 = androidx.compose.runtime.SkippableUpdater.m1295constructorimpl(r2)
            androidx.compose.runtime.SkippableUpdater r10 = androidx.compose.runtime.SkippableUpdater.m1294boximpl(r10)
            int r11 = r3 >> 3
            r11 = r11 & 112(0x70, float:1.57E-43)
            java.lang.Integer r11 = java.lang.Integer.valueOf(r11)
            r57 = r5
            r5 = r53
            r5.invoke(r10, r2, r11)
            r10 = 2058660585(0x7ab4aae9, float:4.6903995E35)
            r2.startReplaceableGroup(r10)
            int r11 = r3 >> 9
            r11 = r11 & 14
            r53 = r2
            r58 = 0
            r10 = -1163856341(0xffffffffbaa0f62b, float:-0.0012280395)
            r60 = r3
            r3 = r53
            r3.startReplaceableGroup(r10)
            java.lang.String r10 = "C79@3994L9:Column.kt#2w3rfo"
            androidx.compose.runtime.ComposerKt.sourceInformation(r3, r10)
            r10 = r11 & 11
            r61 = r5
            r5 = 2
            if (r10 != r5) goto L5c1
            boolean r5 = r3.getSkipping()
            if (r5 != 0) goto L5a3
            goto L5c1
        L5a3:
            r3.skipToGroupEnd()
            r93 = r2
            r33 = r3
            r88 = r4
            r89 = r7
            r90 = r9
            r92 = r11
            r143 = r12
            r12 = r14
            r32 = r15
            r30 = r18
            r67 = r42
            r64 = r43
            r3 = r49
            goto L13ed
        L5c1:
            androidx.compose.foundation.layout.ColumnScopeInstance r5 = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE
            int r10 = r4 >> 6
            r10 = r10 & 112(0x70, float:1.57E-43)
            r10 = r10 | 6
            r62 = r5
            androidx.compose.foundation.layout.ColumnScope r62 = (androidx.compose.foundation.layout.ColumnScope) r62
            r5 = r3
            r87 = 0
            r88 = r4
            r4 = 73840847(0x466b8cf, float:2.712123E-36)
            r89 = r7
            java.lang.String r7 = "C70@3503L2357,109@6352L2071:CarControlScreen.kt#597736"
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(r5, r4, r7)
            androidx.compose.ui.Modifier$Companion r4 = androidx.compose.ui.Modifier.Companion
            androidx.compose.ui.Modifier r4 = (androidx.compose.ui.Modifier) r4
            r90 = r9
            r91 = r10
            r7 = 0
            r9 = 0
            r10 = 1
            androidx.compose.ui.Modifier r4 = androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(r4, r7, r10, r9)
            androidx.compose.foundation.layout.Arrangement r7 = androidx.compose.foundation.layout.Arrangement.INSTANCE
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r9 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            int r9 = r9.m6202Int$$$this$call$getdp$$arg0$callspacedBy$arg1$callRow$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            r10 = 0
            r16 = r10
            float r10 = (float) r9
            float r9 = androidx.compose.ui.unit.Dp.m4046constructorimpl(r10)
            androidx.compose.foundation.layout.Arrangement$HorizontalOrVertical r7 = r7.m372spacedBy0680j_4(r9)
            androidx.compose.foundation.layout.Arrangement$Horizontal r7 = (androidx.compose.foundation.layout.Arrangement.Horizontal) r7
            r9 = 6
            r10 = 0
            r63 = r10
            r10 = 693286680(0x2952b718, float:4.6788176E-14)
            r5.startReplaceableGroup(r10)
            java.lang.String r10 = "C(Row)P(2,1,3)78@3880L58,79@3943L130:Row.kt#2w3rfo"
            androidx.compose.runtime.ComposerKt.sourceInformation(r5, r10)
            androidx.compose.ui.Alignment$Companion r10 = androidx.compose.ui.Alignment.Companion
            androidx.compose.ui.Alignment$Vertical r10 = r10.getTop()
            int r16 = r9 >> 3
            r16 = r16 & 14
            int r17 = r9 >> 3
            r17 = r17 & 112(0x70, float:1.57E-43)
            r92 = r11
            r11 = r16 | r17
            androidx.compose.ui.layout.MeasurePolicy r11 = androidx.compose.foundation.layout.RowKt.rowMeasurePolicy(r7, r10, r5, r11)
            int r16 = r9 << 3
            r16 = r16 & 112(0x70, float:1.57E-43)
            r64 = r16
            r65 = 0
            r66 = r7
            r7 = -1323940314(0xffffffffb1164626, float:-2.1867748E-9)
            r5.startReplaceableGroup(r7)
            androidx.compose.runtime.ComposerKt.sourceInformation(r5, r1)
            androidx.compose.runtime.ProvidableCompositionLocal r7 = androidx.compose.ui.platform.CompositionLocalsKt.getLocalDensity()
            androidx.compose.runtime.CompositionLocal r7 = (androidx.compose.runtime.CompositionLocal) r7
            r16 = 6
            r17 = 0
            r67 = r10
            r10 = 2023513938(0x789c5f52, float:2.5372864E34)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(r5, r10, r13)
            java.lang.Object r10 = r5.consume(r7)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(r5)
            r7 = r10
            androidx.compose.ui.unit.Density r7 = (androidx.compose.ui.unit.Density) r7
            androidx.compose.runtime.ProvidableCompositionLocal r10 = androidx.compose.ui.platform.CompositionLocalsKt.getLocalLayoutDirection()
            androidx.compose.runtime.CompositionLocal r10 = (androidx.compose.runtime.CompositionLocal) r10
            r16 = 6
            r17 = 0
            r19 = r12
            r12 = 2023513938(0x789c5f52, float:2.5372864E34)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(r5, r12, r13)
            java.lang.Object r12 = r5.consume(r10)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(r5)
            r10 = r12
            androidx.compose.ui.unit.LayoutDirection r10 = (androidx.compose.ui.unit.LayoutDirection) r10
            androidx.compose.runtime.ProvidableCompositionLocal r12 = androidx.compose.ui.platform.CompositionLocalsKt.getLocalViewConfiguration()
            androidx.compose.runtime.CompositionLocal r12 = (androidx.compose.runtime.CompositionLocal) r12
            r16 = 6
            r17 = 0
            r93 = r2
            r2 = 2023513938(0x789c5f52, float:2.5372864E34)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(r5, r2, r13)
            java.lang.Object r20 = r5.consume(r12)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(r5)
            r12 = r20
            androidx.compose.ui.platform.ViewConfiguration r12 = (androidx.compose.ui.platform.ViewConfiguration) r12
            androidx.compose.ui.node.ComposeUiNode$Companion r16 = androidx.compose.ui.node.ComposeUiNode.Companion
            kotlin.jvm.functions.Function0 r16 = r16.getConstructor()
            kotlin.jvm.functions.Function3 r17 = androidx.compose.ui.layout.LayoutKt.materializerOf(r4)
            int r2 = r64 << 9
            r2 = r2 & 7168(0x1c00, float:1.0045E-41)
            r2 = r2 | 6
            r68 = r17
            r69 = r16
            r70 = 0
            r71 = r4
            androidx.compose.runtime.Applier r4 = r5.getApplier()
            boolean r4 = r4 instanceof androidx.compose.runtime.Applier
            if (r4 != 0) goto L6b2
            androidx.compose.runtime.ComposablesKt.invalidApplier()
        L6b2:
            r5.startReusableNode()
            boolean r4 = r5.getInserting()
            if (r4 == 0) goto L6c1
            r4 = r69
            r5.createNode(r4)
            goto L6c6
        L6c1:
            r4 = r69
            r5.useNode()
        L6c6:
            r5.disableReusing()
            r69 = r4
            androidx.compose.runtime.Composer r4 = androidx.compose.runtime.Updater.m1304constructorimpl(r5)
            r16 = 0
            androidx.compose.ui.node.ComposeUiNode$Companion r17 = androidx.compose.ui.node.ComposeUiNode.Companion
            r20 = r13
            kotlin.jvm.functions.Function2 r13 = r17.getSetMeasurePolicy()
            androidx.compose.runtime.Updater.m1311setimpl(r4, r11, r13)
            androidx.compose.ui.node.ComposeUiNode$Companion r13 = androidx.compose.ui.node.ComposeUiNode.Companion
            kotlin.jvm.functions.Function2 r13 = r13.getSetDensity()
            androidx.compose.runtime.Updater.m1311setimpl(r4, r7, r13)
            androidx.compose.ui.node.ComposeUiNode$Companion r13 = androidx.compose.ui.node.ComposeUiNode.Companion
            kotlin.jvm.functions.Function2 r13 = r13.getSetLayoutDirection()
            androidx.compose.runtime.Updater.m1311setimpl(r4, r10, r13)
            androidx.compose.ui.node.ComposeUiNode$Companion r13 = androidx.compose.ui.node.ComposeUiNode.Companion
            kotlin.jvm.functions.Function2 r13 = r13.getSetViewConfiguration()
            androidx.compose.runtime.Updater.m1311setimpl(r4, r12, r13)
            r5.enableReusing()
            androidx.compose.runtime.Composer r4 = androidx.compose.runtime.SkippableUpdater.m1295constructorimpl(r5)
            androidx.compose.runtime.SkippableUpdater r4 = androidx.compose.runtime.SkippableUpdater.m1294boximpl(r4)
            int r13 = r2 >> 3
            r13 = r13 & 112(0x70, float:1.57E-43)
            java.lang.Integer r13 = java.lang.Integer.valueOf(r13)
            r72 = r7
            r7 = r68
            r7.invoke(r4, r5, r13)
            r4 = 2058660585(0x7ab4aae9, float:4.6903995E35)
            r5.startReplaceableGroup(r4)
            int r4 = r2 >> 9
            r4 = r4 & 14
            r13 = r5
            r68 = 0
            r73 = r2
            r2 = -678309503(0xffffffffd791d181, float:-3.20658E14)
            r13.startReplaceableGroup(r2)
            java.lang.String r2 = "C80@3988L9:Row.kt#2w3rfo"
            androidx.compose.runtime.ComposerKt.sourceInformation(r13, r2)
            r2 = r4 & 11
            r74 = r4
            r4 = 2
            if (r2 != r4) goto L75c
            boolean r2 = r13.getSkipping()
            if (r2 != 0) goto L73a
            goto L75c
        L73a:
            r13.skipToGroupEnd()
            r33 = r3
            r83 = r7
            r94 = r8
            r26 = r9
            r27 = r10
            r28 = r12
            r29 = r13
            r12 = r14
            r32 = r15
            r30 = r18
            r143 = r19
            r7 = r20
            r13 = r42
            r3 = r49
            r19 = r11
            goto Lc1f
        L75c:
            androidx.compose.foundation.layout.RowScopeInstance r2 = androidx.compose.foundation.layout.RowScopeInstance.INSTANCE
            int r4 = r9 >> 6
            r4 = r4 & 112(0x70, float:1.57E-43)
            r4 = r4 | 6
            r75 = r2
            androidx.compose.foundation.layout.RowScope r75 = (androidx.compose.foundation.layout.RowScope) r75
            r2 = r13
            r81 = 0
            r82 = r4
            r4 = -1441395888(0xffffffffaa160b50, float:-1.3326601E-13)
            r83 = r7
            java.lang.String r7 = "C91@5199L231,96@5641L6,96@5596L58,95@5443L229:CarControlScreen.kt#597736"
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(r2, r4, r7)
            boolean r4 = CarControlScreen$lambda$22(r42)
            if (r4 != 0) goto L8cd
            r4 = -1441395874(0xffffffffaa160b5e, float:-1.332662E-13)
            r2.startReplaceableGroup(r4)
            java.lang.String r4 = "72@3627L332,74@3972L272,79@4257L800"
            androidx.compose.runtime.ComposerKt.sourceInformation(r2, r4)
            java.lang.String r94 = CarControlScreen$lambda$2(r35)
            vea.raceremote.control.CarConnectionState r4 = CarControlScreen$lambda$1(r6)
            boolean r4 = r4.getConnected()
            if (r4 != 0) goto L7a3
            vea.raceremote.control.CarConnectionState r4 = CarControlScreen$lambda$1(r6)
            boolean r4 = r4.getConnecting()
            if (r4 != 0) goto L7a3
            r97 = 1
            goto L7a5
        L7a3:
            r97 = 0
        L7a5:
            androidx.compose.ui.Modifier$Companion r4 = androidx.compose.ui.Modifier.Companion
            r76 = r4
            androidx.compose.ui.Modifier r76 = (androidx.compose.ui.Modifier) r76
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r4 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            float r77 = r4.m6196Float$arg0$callweight$$$this$calltestTag$valtmp2_modifier$branch$if$fun$anonymous$$arg3$callRow$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            r78 = 0
            r79 = 2
            r80 = 0
            androidx.compose.ui.Modifier r4 = androidx.compose.foundation.layout.RowScope.weight$default(r75, r76, r77, r78, r79, r80)
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r7 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            java.lang.String r7 = r7.m6240String$arg0$calltestTag$valtmp2_modifier$branch$if$fun$anonymous$$arg3$callRow$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            androidx.compose.ui.Modifier r96 = androidx.compose.ui.platform.TestTagKt.testTag(r4, r7)
            vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$1$1 r4 = new vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$1$1
            r26 = r4
            r27 = r14
            r28 = r0
            r29 = r8
            r30 = r35
            r31 = r36
            r32 = r37
            r33 = r38
            r26.<init>(r27, r28, r29, r30, r31, r32, r33)
            r95 = r4
            kotlin.jvm.functions.Function1 r95 = (kotlin.jvm.functions.Function1) r95
            r98 = 0
            r99 = 0
            vea.raceremote.control.ComposableSingletons$CarControlScreenKt r4 = vea.raceremote.control.ComposableSingletons$CarControlScreenKt.INSTANCE
            kotlin.jvm.functions.Function2 r100 = r4.m5981getLambda2$app_debug()
            r101 = 0
            r102 = 0
            r103 = 0
            r104 = 0
            r105 = 0
            r106 = 0
            r107 = 0
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r4 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            boolean r108 = r4.m6169Boolean$arg14$callOutlinedTextField$branch$if$fun$anonymous$$arg3$callRow$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            r109 = 0
            r110 = 0
            r111 = 0
            r112 = 0
            r114 = 1572864(0x180000, float:2.204052E-39)
            r115 = 0
            r116 = 507824(0x7bfb0, float:7.11613E-40)
            r113 = r2
            androidx.compose.material.OutlinedTextFieldKt.OutlinedTextField(r94, r95, r96, r97, r98, r99, r100, r101, r102, r103, r104, r105, r106, r107, r108, r109, r110, r111, r112, r113, r114, r115, r116)
            vea.raceremote.control.CarConnectionState r4 = CarControlScreen$lambda$1(r6)
            boolean r4 = r4.getConnected()
            if (r4 != 0) goto L826
            vea.raceremote.control.CarConnectionState r4 = CarControlScreen$lambda$1(r6)
            boolean r4 = r4.getConnecting()
            if (r4 != 0) goto L826
            r4 = 1
            goto L827
        L826:
            r4 = 0
        L827:
            java.lang.Boolean r4 = java.lang.Boolean.valueOf(r4)
            vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$1$2 r7 = new vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$1$2
            r26 = r7
            r27 = r14
            r28 = r0
            r29 = r8
            r30 = r35
            r31 = r36
            r32 = r37
            r33 = r38
            r26.<init>(r27, r28, r29, r30, r31, r32, r33)
            r26 = r9
            int r9 = r15 << 6
            r9 = r9 & 896(0x380, float:1.256E-42)
            java.lang.Integer r9 = java.lang.Integer.valueOf(r9)
            r27 = r10
            r10 = r55
            r10.invoke(r4, r7, r2, r9)
            vea.raceremote.control.CarConnectionState r4 = CarControlScreen$lambda$1(r6)
            boolean r4 = r4.getConnected()
            if (r4 != 0) goto L868
            vea.raceremote.control.CarConnectionState r4 = CarControlScreen$lambda$1(r6)
            boolean r4 = r4.getConnecting()
            if (r4 != 0) goto L868
            r96 = 1
            goto L86a
        L868:
            r96 = 0
        L86a:
            androidx.compose.ui.Modifier$Companion r4 = androidx.compose.ui.Modifier.Companion
            androidx.compose.ui.Modifier r4 = (androidx.compose.ui.Modifier) r4
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r7 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            java.lang.String r7 = r7.m6242String$arg0$calltestTag$valtmp4_modifier$branch$if$fun$anonymous$$arg3$callRow$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            androidx.compose.ui.Modifier r95 = androidx.compose.ui.platform.TestTagKt.testTag(r4, r7)
            vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$1$3 r4 = new vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$1$3
            r28 = r12
            r7 = r18
            r9 = r19
            r12 = r4
            r30 = r7
            r29 = r13
            r7 = r20
            r13 = r51
            r143 = r9
            r31 = r14
            r9 = 2023513938(0x789c5f52, float:2.5372864E34)
            r14 = r25
            r32 = r15
            r15 = r41
            r16 = r31
            r17 = r24
            r18 = r0
            r19 = r8
            r20 = r35
            r21 = r37
            r22 = r36
            r23 = r38
            r12.<init>(r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23)
            r94 = r4
            kotlin.jvm.functions.Function0 r94 = (kotlin.jvm.functions.Function0) r94
            r97 = 0
            r98 = 0
            r99 = 0
            r100 = 0
            r101 = 0
            r102 = 0
            vea.raceremote.control.ComposableSingletons$CarControlScreenKt r4 = vea.raceremote.control.ComposableSingletons$CarControlScreenKt.INSTANCE
            kotlin.jvm.functions.Function3 r103 = r4.m5982getLambda3$app_debug()
            r105 = 805306368(0x30000000, float:4.656613E-10)
            r106 = 504(0x1f8, float:7.06E-43)
            r104 = r2
            androidx.compose.material.ButtonKt.Button(r94, r95, r96, r97, r98, r99, r100, r101, r102, r103, r104, r105, r106)
            r2.endReplaceableGroup()
            goto L942
        L8cd:
            r26 = r9
            r27 = r10
            r28 = r12
            r29 = r13
            r31 = r14
            r32 = r15
            r30 = r18
            r143 = r19
            r7 = r20
            r10 = r55
            r9 = 2023513938(0x789c5f52, float:2.5372864E34)
            r4 = -1441394410(0xffffffffaa161116, float:-1.3328604E-13)
            r2.startReplaceableGroup(r4)
            java.lang.String r4 = "89@5095L77"
            androidx.compose.runtime.ComposerKt.sourceInformation(r2, r4)
            vea.raceremote.control.CarConnectionState r4 = CarControlScreen$lambda$1(r6)
            java.lang.String r94 = r4.getMessage()
            androidx.compose.ui.Modifier$Companion r4 = androidx.compose.ui.Modifier.Companion
            r13 = r4
            androidx.compose.ui.Modifier r13 = (androidx.compose.ui.Modifier) r13
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r4 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            float r14 = r4.m6195Float$arg0$callweight$$$this$calltestTag$arg1$callText$else$if$fun$anonymous$$arg3$callRow$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            r15 = 0
            r16 = 2
            r17 = 0
            r12 = r75
            androidx.compose.ui.Modifier r4 = androidx.compose.foundation.layout.RowScope.weight$default(r12, r13, r14, r15, r16, r17)
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r12 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            java.lang.String r12 = r12.m6236String$arg0$calltestTag$arg1$callText$else$if$fun$anonymous$$arg3$callRow$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            androidx.compose.ui.Modifier r95 = androidx.compose.ui.platform.TestTagKt.testTag(r4, r12)
            r96 = 0
            r98 = 0
            r100 = 0
            r101 = 0
            r102 = 0
            r103 = 0
            r105 = 0
            r106 = 0
            r107 = 0
            r109 = 0
            r110 = 0
            r111 = 0
            r112 = 0
            r113 = 0
            r115 = 0
            r116 = 0
            r117 = 65532(0xfffc, float:9.183E-41)
            r114 = r2
            androidx.compose.material.TextKt.m1249TextfLXpl1I(r94, r95, r96, r98, r100, r101, r102, r103, r105, r106, r107, r109, r110, r111, r112, r113, r114, r115, r116, r117)
            r2.endReplaceableGroup()
        L942:
            vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$1$4 r4 = new vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$1$4
            r12 = r31
            r13 = r42
            r4.<init>(r12, r0, r8, r13)
            r94 = r4
            kotlin.jvm.functions.Function0 r94 = (kotlin.jvm.functions.Function0) r94
            androidx.compose.ui.Modifier$Companion r4 = androidx.compose.ui.Modifier.Companion
            androidx.compose.ui.Modifier r4 = (androidx.compose.ui.Modifier) r4
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r14 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            java.lang.String r14 = r14.m6233String$arg0$calltestTag$arg1$callButton$fun$anonymous$$arg3$callRow$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            androidx.compose.ui.Modifier r95 = androidx.compose.ui.platform.TestTagKt.testTag(r4, r14)
            r96 = 0
            r97 = 0
            r98 = 0
            r99 = 0
            r100 = 0
            r101 = 0
            r102 = 0
            vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$1$5 r4 = new vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$1$5
            r4.<init>(r13)
            r14 = -1877589683(0xffffffff9016414d, float:-2.963259E-29)
            r15 = 1
            androidx.compose.runtime.internal.ComposableLambda r4 = androidx.compose.runtime.internal.ComposableLambdaKt.composableLambda(r2, r14, r15, r4)
            r103 = r4
            kotlin.jvm.functions.Function3 r103 = (kotlin.jvm.functions.Function3) r103
            r105 = 805306368(0x30000000, float:4.656613E-10)
            r106 = 508(0x1fc, float:7.12E-43)
            r104 = r2
            androidx.compose.material.ButtonKt.Button(r94, r95, r96, r97, r98, r99, r100, r101, r102, r103, r104, r105, r106)
            vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$1$6 r4 = new vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$1$6
            r4.<init>(r12, r0, r8)
            kotlin.jvm.functions.Function0 r4 = (kotlin.jvm.functions.Function0) r4
            androidx.compose.ui.Modifier$Companion r14 = androidx.compose.ui.Modifier.Companion
            androidx.compose.ui.Modifier r14 = (androidx.compose.ui.Modifier) r14
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r15 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            java.lang.String r15 = r15.m6234String$arg0$calltestTag$arg1$callButton1$fun$anonymous$$arg3$callRow$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            androidx.compose.ui.Modifier r14 = androidx.compose.ui.platform.TestTagKt.testTag(r14, r15)
            r16 = 0
            r17 = 0
            r18 = 0
            r19 = 0
            androidx.compose.material.ButtonDefaults r94 = androidx.compose.material.ButtonDefaults.INSTANCE
            androidx.compose.material.MaterialTheme r9 = androidx.compose.material.MaterialTheme.INSTANCE
            int r15 = androidx.compose.material.MaterialTheme.$stable
            androidx.compose.material.Colors r9 = r9.getColors(r2, r15)
            long r95 = r9.m975getError0d7_KjU()
            r97 = 0
            r99 = 0
            r101 = 0
            int r9 = androidx.compose.material.ButtonDefaults.$stable
            int r104 = r9 << 12
            r105 = 14
            r103 = r2
            androidx.compose.material.ButtonColors r101 = r94.m931buttonColorsro_MJ88(r95, r97, r99, r101, r103, r104, r105)
            r102 = 0
            vea.raceremote.control.ComposableSingletons$CarControlScreenKt r9 = vea.raceremote.control.ComposableSingletons$CarControlScreenKt.INSTANCE
            kotlin.jvm.functions.Function3 r103 = r9.m5983getLambda4$app_debug()
            r105 = 805306368(0x30000000, float:4.656613E-10)
            r106 = 380(0x17c, float:5.32E-43)
            r94 = r4
            r95 = r14
            r4 = 0
            r96 = r4
            r97 = r16
            r98 = r17
            r99 = r18
            r100 = r19
            r104 = r2
            androidx.compose.material.ButtonKt.Button(r94, r95, r96, r97, r98, r99, r100, r101, r102, r103, r104, r105, r106)
            r4 = 73843029(0x466c155, float:2.7125144E-36)
            r5.startReplaceableGroup(r4)
            java.lang.String r4 = "97@5699L151"
            androidx.compose.runtime.ComposerKt.sourceInformation(r5, r4)
            boolean r4 = CarControlScreen$lambda$22(r13)
            if (r4 != 0) goto Lc0d
            r4 = 0
            r9 = 0
            r14 = -483455358(0xffffffffe32f0e82, float:-3.2292256E21)
            r2.startReplaceableGroup(r14)
            r14 = r50
            androidx.compose.runtime.ComposerKt.sourceInformation(r2, r14)
            androidx.compose.ui.Modifier$Companion r15 = androidx.compose.ui.Modifier.Companion
            androidx.compose.ui.Modifier r15 = (androidx.compose.ui.Modifier) r15
            androidx.compose.foundation.layout.Arrangement r16 = androidx.compose.foundation.layout.Arrangement.INSTANCE
            r17 = r9
            androidx.compose.foundation.layout.Arrangement$Vertical r9 = r16.getTop()
            androidx.compose.ui.Alignment$Companion r16 = androidx.compose.ui.Alignment.Companion
            r55 = r10
            androidx.compose.ui.Alignment$Horizontal r10 = r16.getStart()
            int r16 = r4 >> 3
            r16 = r16 & 14
            int r18 = r4 >> 3
            r18 = r18 & 112(0x70, float:1.57E-43)
            r19 = r11
            r11 = r16 | r18
            androidx.compose.ui.layout.MeasurePolicy r11 = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(r9, r10, r2, r11)
            int r16 = r4 << 3
            r16 = r16 & 112(0x70, float:1.57E-43)
            r18 = 0
            r21 = r9
            r9 = -1323940314(0xffffffffb1164626, float:-2.1867748E-9)
            r2.startReplaceableGroup(r9)
            androidx.compose.runtime.ComposerKt.sourceInformation(r2, r1)
            androidx.compose.runtime.ProvidableCompositionLocal r9 = androidx.compose.ui.platform.CompositionLocalsKt.getLocalDensity()
            androidx.compose.runtime.CompositionLocal r9 = (androidx.compose.runtime.CompositionLocal) r9
            r22 = 6
            r23 = 0
            r31 = r10
            r10 = 2023513938(0x789c5f52, float:2.5372864E34)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(r2, r10, r7)
            java.lang.Object r10 = r2.consume(r9)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(r2)
            r9 = r10
            androidx.compose.ui.unit.Density r9 = (androidx.compose.ui.unit.Density) r9
            androidx.compose.runtime.ProvidableCompositionLocal r10 = androidx.compose.ui.platform.CompositionLocalsKt.getLocalLayoutDirection()
            androidx.compose.runtime.CompositionLocal r10 = (androidx.compose.runtime.CompositionLocal) r10
            r22 = 6
            r23 = 0
            r33 = r3
            r3 = 2023513938(0x789c5f52, float:2.5372864E34)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(r2, r3, r7)
            java.lang.Object r3 = r2.consume(r10)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(r2)
            androidx.compose.ui.unit.LayoutDirection r3 = (androidx.compose.ui.unit.LayoutDirection) r3
            androidx.compose.runtime.ProvidableCompositionLocal r10 = androidx.compose.ui.platform.CompositionLocalsKt.getLocalViewConfiguration()
            androidx.compose.runtime.CompositionLocal r10 = (androidx.compose.runtime.CompositionLocal) r10
            r22 = 6
            r23 = 0
            r14 = 2023513938(0x789c5f52, float:2.5372864E34)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(r2, r14, r7)
            java.lang.Object r14 = r2.consume(r10)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(r2)
            r10 = r14
            androidx.compose.ui.platform.ViewConfiguration r10 = (androidx.compose.ui.platform.ViewConfiguration) r10
            androidx.compose.ui.node.ComposeUiNode$Companion r14 = androidx.compose.ui.node.ComposeUiNode.Companion
            kotlin.jvm.functions.Function0 r14 = r14.getConstructor()
            kotlin.jvm.functions.Function3 r22 = androidx.compose.ui.layout.LayoutKt.materializerOf(r15)
            r23 = r15
            int r15 = r16 << 9
            r15 = r15 & 7168(0x1c00, float:1.0045E-41)
            r15 = r15 | 6
            r42 = r22
            r22 = 0
            r94 = r8
            androidx.compose.runtime.Applier r8 = r2.getApplier()
            boolean r8 = r8 instanceof androidx.compose.runtime.Applier
            if (r8 != 0) goto Laab
            androidx.compose.runtime.ComposablesKt.invalidApplier()
        Laab:
            r2.startReusableNode()
            boolean r8 = r2.getInserting()
            if (r8 == 0) goto Lab8
            r2.createNode(r14)
            goto Labb
        Lab8:
            r2.useNode()
        Labb:
            r2.disableReusing()
            androidx.compose.runtime.Composer r8 = androidx.compose.runtime.Updater.m1304constructorimpl(r2)
            r76 = 0
            androidx.compose.ui.node.ComposeUiNode$Companion r77 = androidx.compose.ui.node.ComposeUiNode.Companion
            r78 = r14
            kotlin.jvm.functions.Function2 r14 = r77.getSetMeasurePolicy()
            androidx.compose.runtime.Updater.m1311setimpl(r8, r11, r14)
            androidx.compose.ui.node.ComposeUiNode$Companion r14 = androidx.compose.ui.node.ComposeUiNode.Companion
            kotlin.jvm.functions.Function2 r14 = r14.getSetDensity()
            androidx.compose.runtime.Updater.m1311setimpl(r8, r9, r14)
            androidx.compose.ui.node.ComposeUiNode$Companion r14 = androidx.compose.ui.node.ComposeUiNode.Companion
            kotlin.jvm.functions.Function2 r14 = r14.getSetLayoutDirection()
            androidx.compose.runtime.Updater.m1311setimpl(r8, r3, r14)
            androidx.compose.ui.node.ComposeUiNode$Companion r14 = androidx.compose.ui.node.ComposeUiNode.Companion
            kotlin.jvm.functions.Function2 r14 = r14.getSetViewConfiguration()
            androidx.compose.runtime.Updater.m1311setimpl(r8, r10, r14)
            r2.enableReusing()
            androidx.compose.runtime.Composer r8 = androidx.compose.runtime.SkippableUpdater.m1295constructorimpl(r2)
            androidx.compose.runtime.SkippableUpdater r8 = androidx.compose.runtime.SkippableUpdater.m1294boximpl(r8)
            int r14 = r15 >> 3
            r14 = r14 & 112(0x70, float:1.57E-43)
            java.lang.Integer r14 = java.lang.Integer.valueOf(r14)
            r76 = r3
            r3 = r42
            r3.invoke(r8, r2, r14)
            r8 = 2058660585(0x7ab4aae9, float:4.6903995E35)
            r2.startReplaceableGroup(r8)
            int r8 = r15 >> 9
            r8 = r8 & 14
            r14 = r2
            r42 = 0
            r77 = r3
            r3 = -1163856341(0xffffffffbaa0f62b, float:-0.0012280395)
            r14.startReplaceableGroup(r3)
            java.lang.String r3 = "C79@3994L9:Column.kt#2w3rfo"
            androidx.compose.runtime.ComposerKt.sourceInformation(r14, r3)
            r3 = r8 & 11
            r79 = r8
            r8 = 2
            if (r3 != r8) goto Lb38
            boolean r3 = r14.getSkipping()
            if (r3 != 0) goto Lb2d
            goto Lb38
        Lb2d:
            r14.skipToGroupEnd()
            r86 = r4
            r104 = r9
            r3 = r49
            goto Lbfb
        Lb38:
            androidx.compose.foundation.layout.ColumnScopeInstance r3 = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE
            int r8 = r4 >> 6
            r8 = r8 & 112(0x70, float:1.57E-43)
            r8 = r8 | 6
            androidx.compose.foundation.layout.ColumnScope r3 = (androidx.compose.foundation.layout.ColumnScope) r3
            r80 = r14
            r115 = r80
            r84 = 0
            r85 = r3
            r3 = -130139074(0xfffffffff83e3c3e, float:-1.5433723E34)
            r86 = r4
            java.lang.String r4 = "C98@5724L13,99@5774L18,99@5754L82:CarControlScreen.kt#597736"
            r119 = r8
            r8 = r80
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(r8, r3, r4)
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r3 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            java.lang.String r95 = r3.m6224String$arg0$callText$fun$anonymous$$arg3$callColumn$branch$if1$fun$anonymous$$arg3$callRow$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            r96 = 0
            r97 = 0
            r99 = 0
            r101 = 0
            r102 = 0
            r103 = 0
            r104 = 0
            r106 = 0
            r107 = 0
            r108 = 0
            r110 = 0
            r111 = 0
            r112 = 0
            r113 = 0
            r114 = 0
            r116 = 0
            r117 = 0
            r118 = 65534(0xfffe, float:9.1833E-41)
            androidx.compose.material.TextKt.m1249TextfLXpl1I(r95, r96, r97, r99, r101, r102, r103, r104, r106, r107, r108, r110, r111, r112, r113, r114, r115, r116, r117, r118)
            boolean r95 = CarControlScreen$lambda$16(r49)
            r3 = 0
            r4 = 0
            r80 = r3
            r3 = 1157296644(0x44faf204, float:2007.563)
            r8.startReplaceableGroup(r3)
            java.lang.String r3 = "C(remember)P(1):Composables.kt#9igjgp"
            androidx.compose.runtime.ComposerKt.sourceInformation(r8, r3)
            r3 = r49
            boolean r49 = r8.changed(r3)
            r96 = r8
            r97 = 0
            r98 = r4
            java.lang.Object r4 = r96.rememberedValue()
            r99 = 0
            if (r49 != 0) goto Lbbd
            androidx.compose.runtime.Composer$Companion r100 = androidx.compose.runtime.Composer.Companion
            r104 = r9
            java.lang.Object r9 = r100.getEmpty()
            if (r4 != r9) goto Lbb8
            goto Lbbf
        Lbb8:
            r100 = r4
            r9 = r96
            goto Lbd0
        Lbbd:
            r104 = r9
        Lbbf:
            r9 = 0
            r100 = r4
            vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$1$7$1$1 r4 = new vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$1$7$1$1
            r4.<init>(r3)
            kotlin.jvm.functions.Function1 r4 = (kotlin.jvm.functions.Function1) r4
            r9 = r96
            r9.updateRememberedValue(r4)
        Lbd0:
            r8.endReplaceableGroup()
            r96 = r4
            kotlin.jvm.functions.Function1 r96 = (kotlin.jvm.functions.Function1) r96
            androidx.compose.ui.Modifier$Companion r4 = androidx.compose.ui.Modifier.Companion
            androidx.compose.ui.Modifier r4 = (androidx.compose.ui.Modifier) r4
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r9 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            java.lang.String r9 = r9.m6239String$arg0$calltestTag$arg2$callCheckbox$fun$anonymous$$arg3$callColumn$branch$if1$fun$anonymous$$arg3$callRow$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            androidx.compose.ui.Modifier r97 = androidx.compose.ui.platform.TestTagKt.testTag(r4, r9)
            r98 = 0
            r99 = 0
            r100 = 0
            r102 = 0
            r103 = 56
            r101 = r8
            androidx.compose.material.CheckboxKt.Checkbox(r95, r96, r97, r98, r99, r100, r101, r102, r103)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(r8)
        Lbfb:
            r14.endReplaceableGroup()
            r2.endReplaceableGroup()
            r2.endNode()
            r2.endReplaceableGroup()
            r2.endReplaceableGroup()
            goto Lc17
        Lc0d:
            r33 = r3
            r94 = r8
            r55 = r10
            r19 = r11
            r3 = r49
        Lc17:
            r5.endReplaceableGroup()
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(r2)
        Lc1f:
            r29.endReplaceableGroup()
            r5.endReplaceableGroup()
            r5.endNode()
            r5.endReplaceableGroup()
            r5.endReplaceableGroup()
            r2 = 73843213(0x466c20d, float:2.7125474E-36)
            r5.startReplaceableGroup(r2)
            java.lang.String r2 = "103@5897L201,105@6111L58,106@6182L108,107@6303L30"
            androidx.compose.runtime.ComposerKt.sourceInformation(r5, r2)
            boolean r2 = CarControlScreen$lambda$22(r13)
            if (r2 != 0) goto Ld5c
            java.lang.Long r2 = CarControlScreen$lambda$6(r37)
            if (r2 == 0) goto Lc8f
            java.lang.Number r2 = (java.lang.Number) r2
            long r8 = r2.longValue()
            r2 = 0
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r10 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            java.lang.String r10 = r10.m6217String$0$str$fun$anonymous$$arg0$calllet$else$when$valtmp1_elvis_lhs$arg0$callText$branch$if$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            java.lang.StringBuilder r4 = r4.append(r10)
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r10 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            int r10 = r10.m6212Int$arg0$calltoString$$$this$callpadStart$1$str$fun$anonymous$$arg0$calllet$else$when$valtmp1_elvis_lhs$arg0$callText$branch$if$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            int r10 = kotlin.text.CharsKt.checkRadix(r10)
            java.lang.String r10 = java.lang.Long.toString(r8, r10)
            java.lang.String r11 = "toString(this, checkRadix(radix))"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r10, r11)
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r11 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            int r11 = r11.m6211Int$arg0$callpadStart$1$str$fun$anonymous$$arg0$calllet$else$when$valtmp1_elvis_lhs$arg0$callText$branch$if$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r14 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            char r14 = r14.m6170Char$arg1$callpadStart$1$str$fun$anonymous$$arg0$calllet$else$when$valtmp1_elvis_lhs$arg0$callText$branch$if$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            java.lang.String r10 = kotlin.text.StringsKt.padStart(r10, r11, r14)
            java.lang.StringBuilder r4 = r4.append(r10)
            java.lang.String r2 = r4.toString()
            if (r2 != 0) goto Lc8c
            goto Lc8f
        Lc8c:
            r63 = r2
            goto Lc97
        Lc8f:
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r2 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            java.lang.String r2 = r2.m6246String$branch$when$arg0$callText$branch$if$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            r63 = r2
        Lc97:
            androidx.compose.ui.Modifier$Companion r2 = androidx.compose.ui.Modifier.Companion
            androidx.compose.ui.Modifier r2 = (androidx.compose.ui.Modifier) r2
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r4 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            java.lang.String r4 = r4.m6235String$arg0$calltestTag$arg1$callText$branch$if$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            androidx.compose.ui.Modifier r64 = androidx.compose.ui.platform.TestTagKt.testTag(r2, r4)
            r65 = 0
            r67 = 0
            r69 = 0
            r70 = 0
            r71 = 0
            r72 = 0
            r74 = 0
            r75 = 0
            r76 = 0
            r78 = 0
            r79 = 0
            r80 = 0
            r81 = 0
            r82 = 0
            r84 = 0
            r85 = 0
            r86 = 65532(0xfffc, float:9.183E-41)
            r83 = r5
            androidx.compose.material.TextKt.m1249TextfLXpl1I(r63, r64, r65, r67, r69, r70, r71, r72, r74, r75, r76, r78, r79, r80, r81, r82, r83, r84, r85, r86)
            vea.raceremote.control.CarConnectionState r2 = CarControlScreen$lambda$1(r6)
            java.lang.String r63 = r2.getMessage()
            androidx.compose.ui.Modifier$Companion r2 = androidx.compose.ui.Modifier.Companion
            androidx.compose.ui.Modifier r2 = (androidx.compose.ui.Modifier) r2
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r4 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            java.lang.String r4 = r4.m6237String$arg0$calltestTag$arg1$callText1$branch$if$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            androidx.compose.ui.Modifier r64 = androidx.compose.ui.platform.TestTagKt.testTag(r2, r4)
            androidx.compose.material.TextKt.m1249TextfLXpl1I(r63, r64, r65, r67, r69, r70, r71, r72, r74, r75, r76, r78, r79, r80, r81, r82, r83, r84, r85, r86)
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r4 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            java.lang.String r4 = r4.m6216String$0$str$arg0$callText2$branch$if$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            java.lang.StringBuilder r2 = r2.append(r4)
            vea.raceremote.control.CarConnectionState r4 = CarControlScreen$lambda$1(r6)
            int r4 = r4.getThrottle()
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r8 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            int r8 = r8.m6208Int$arg0$calldiv$1$str$arg0$callText2$branch$if$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            int r4 = r4 / r8
            java.lang.StringBuilder r2 = r2.append(r4)
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r4 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            java.lang.String r4 = r4.m6218String$2$str$arg0$callText2$branch$if$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            java.lang.StringBuilder r2 = r2.append(r4)
            vea.raceremote.control.CarConnectionState r4 = CarControlScreen$lambda$1(r6)
            int r4 = r4.getSteering()
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r8 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            int r8 = r8.m6209Int$arg0$calldiv$3$str$arg0$callText2$branch$if$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            int r4 = r4 / r8
            java.lang.StringBuilder r2 = r2.append(r4)
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r4 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            java.lang.String r4 = r4.m6219String$4$str$arg0$callText2$branch$if$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            java.lang.StringBuilder r2 = r2.append(r4)
            java.lang.String r63 = r2.toString()
            androidx.compose.ui.Modifier$Companion r2 = androidx.compose.ui.Modifier.Companion
            androidx.compose.ui.Modifier r2 = (androidx.compose.ui.Modifier) r2
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r4 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            java.lang.String r4 = r4.m6238String$arg0$calltestTag$arg1$callText2$branch$if$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            androidx.compose.ui.Modifier r64 = androidx.compose.ui.platform.TestTagKt.testTag(r2, r4)
            androidx.compose.material.TextKt.m1249TextfLXpl1I(r63, r64, r65, r67, r69, r70, r71, r72, r74, r75, r76, r78, r79, r80, r81, r82, r83, r84, r85, r86)
            androidx.compose.ui.Modifier$Companion r2 = androidx.compose.ui.Modifier.Companion
            androidx.compose.ui.Modifier r2 = (androidx.compose.ui.Modifier) r2
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r4 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            int r4 = r4.m6200Int$$$this$call$getdp$$arg0$callheight$arg0$callSpacer$branch$if$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            r8 = 0
            float r9 = (float) r4
            float r4 = androidx.compose.ui.unit.Dp.m4046constructorimpl(r9)
            androidx.compose.ui.Modifier r2 = androidx.compose.foundation.layout.SizeKt.m454height3ABfNKs(r2, r4)
            r4 = 0
            androidx.compose.foundation.layout.SpacerKt.Spacer(r2, r5, r4)
        Ld5c:
            r5.endReplaceableGroup()
            androidx.compose.ui.Modifier$Companion r2 = androidx.compose.ui.Modifier.Companion
            androidx.compose.ui.Modifier r2 = (androidx.compose.ui.Modifier) r2
            r4 = 0
            r8 = 0
            r9 = 1
            androidx.compose.ui.Modifier r63 = androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(r2, r4, r9, r8)
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r2 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            float r64 = r2.m6197Float$arg0$callweight$arg0$callRow1$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            r65 = 0
            r66 = 2
            r67 = 0
            androidx.compose.ui.Modifier r2 = androidx.compose.foundation.layout.ColumnScope.weight$default(r62, r63, r64, r65, r66, r67)
            androidx.compose.foundation.layout.Arrangement r4 = androidx.compose.foundation.layout.Arrangement.INSTANCE
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r8 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            int r8 = r8.m6203Int$$$this$call$getdp$$arg0$callspacedBy$arg1$callRow1$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            r9 = 0
            float r10 = (float) r8
            float r8 = androidx.compose.ui.unit.Dp.m4046constructorimpl(r10)
            androidx.compose.foundation.layout.Arrangement$HorizontalOrVertical r4 = r4.m372spacedBy0680j_4(r8)
            androidx.compose.foundation.layout.Arrangement$Horizontal r4 = (androidx.compose.foundation.layout.Arrangement.Horizontal) r4
            r8 = 0
            r9 = 0
            r10 = 693286680(0x2952b718, float:4.6788176E-14)
            r5.startReplaceableGroup(r10)
            java.lang.String r10 = "C(Row)P(2,1,3)78@3880L58,79@3943L130:Row.kt#2w3rfo"
            androidx.compose.runtime.ComposerKt.sourceInformation(r5, r10)
            androidx.compose.ui.Alignment$Companion r10 = androidx.compose.ui.Alignment.Companion
            androidx.compose.ui.Alignment$Vertical r10 = r10.getTop()
            int r11 = r8 >> 3
            r11 = r11 & 14
            int r14 = r8 >> 3
            r14 = r14 & 112(0x70, float:1.57E-43)
            r11 = r11 | r14
            androidx.compose.ui.layout.MeasurePolicy r11 = androidx.compose.foundation.layout.RowKt.rowMeasurePolicy(r4, r10, r5, r11)
            int r14 = r8 << 3
            r14 = r14 & 112(0x70, float:1.57E-43)
            r15 = 0
            r16 = r4
            r4 = -1323940314(0xffffffffb1164626, float:-2.1867748E-9)
            r5.startReplaceableGroup(r4)
            androidx.compose.runtime.ComposerKt.sourceInformation(r5, r1)
            androidx.compose.runtime.ProvidableCompositionLocal r4 = androidx.compose.ui.platform.CompositionLocalsKt.getLocalDensity()
            androidx.compose.runtime.CompositionLocal r4 = (androidx.compose.runtime.CompositionLocal) r4
            r17 = 6
            r18 = 0
            r19 = r9
            r9 = 2023513938(0x789c5f52, float:2.5372864E34)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(r5, r9, r7)
            java.lang.Object r9 = r5.consume(r4)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(r5)
            r4 = r9
            androidx.compose.ui.unit.Density r4 = (androidx.compose.ui.unit.Density) r4
            androidx.compose.runtime.ProvidableCompositionLocal r9 = androidx.compose.ui.platform.CompositionLocalsKt.getLocalLayoutDirection()
            androidx.compose.runtime.CompositionLocal r9 = (androidx.compose.runtime.CompositionLocal) r9
            r17 = 6
            r18 = 0
            r21 = r10
            r10 = 2023513938(0x789c5f52, float:2.5372864E34)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(r5, r10, r7)
            java.lang.Object r10 = r5.consume(r9)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(r5)
            r9 = r10
            androidx.compose.ui.unit.LayoutDirection r9 = (androidx.compose.ui.unit.LayoutDirection) r9
            androidx.compose.runtime.ProvidableCompositionLocal r10 = androidx.compose.ui.platform.CompositionLocalsKt.getLocalViewConfiguration()
            androidx.compose.runtime.CompositionLocal r10 = (androidx.compose.runtime.CompositionLocal) r10
            r17 = 6
            r18 = 0
            r22 = r15
            r15 = 2023513938(0x789c5f52, float:2.5372864E34)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(r5, r15, r7)
            java.lang.Object r15 = r5.consume(r10)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(r5)
            r10 = r15
            androidx.compose.ui.platform.ViewConfiguration r10 = (androidx.compose.ui.platform.ViewConfiguration) r10
            androidx.compose.ui.node.ComposeUiNode$Companion r15 = androidx.compose.ui.node.ComposeUiNode.Companion
            kotlin.jvm.functions.Function0 r15 = r15.getConstructor()
            kotlin.jvm.functions.Function3 r17 = androidx.compose.ui.layout.LayoutKt.materializerOf(r2)
            r18 = r2
            int r2 = r14 << 9
            r2 = r2 & 7168(0x1c00, float:1.0045E-41)
            r2 = r2 | 6
            r23 = r17
            r17 = 0
            r26 = r14
            androidx.compose.runtime.Applier r14 = r5.getApplier()
            boolean r14 = r14 instanceof androidx.compose.runtime.Applier
            if (r14 != 0) goto Le37
            androidx.compose.runtime.ComposablesKt.invalidApplier()
        Le37:
            r5.startReusableNode()
            boolean r14 = r5.getInserting()
            if (r14 == 0) goto Le44
            r5.createNode(r15)
            goto Le47
        Le44:
            r5.useNode()
        Le47:
            r5.disableReusing()
            androidx.compose.runtime.Composer r14 = androidx.compose.runtime.Updater.m1304constructorimpl(r5)
            r27 = 0
            androidx.compose.ui.node.ComposeUiNode$Companion r28 = androidx.compose.ui.node.ComposeUiNode.Companion
            r29 = r15
            kotlin.jvm.functions.Function2 r15 = r28.getSetMeasurePolicy()
            androidx.compose.runtime.Updater.m1311setimpl(r14, r11, r15)
            androidx.compose.ui.node.ComposeUiNode$Companion r15 = androidx.compose.ui.node.ComposeUiNode.Companion
            kotlin.jvm.functions.Function2 r15 = r15.getSetDensity()
            androidx.compose.runtime.Updater.m1311setimpl(r14, r4, r15)
            androidx.compose.ui.node.ComposeUiNode$Companion r15 = androidx.compose.ui.node.ComposeUiNode.Companion
            kotlin.jvm.functions.Function2 r15 = r15.getSetLayoutDirection()
            androidx.compose.runtime.Updater.m1311setimpl(r14, r9, r15)
            androidx.compose.ui.node.ComposeUiNode$Companion r15 = androidx.compose.ui.node.ComposeUiNode.Companion
            kotlin.jvm.functions.Function2 r15 = r15.getSetViewConfiguration()
            androidx.compose.runtime.Updater.m1311setimpl(r14, r10, r15)
            r5.enableReusing()
            androidx.compose.runtime.Composer r14 = androidx.compose.runtime.SkippableUpdater.m1295constructorimpl(r5)
            androidx.compose.runtime.SkippableUpdater r14 = androidx.compose.runtime.SkippableUpdater.m1294boximpl(r14)
            int r15 = r2 >> 3
            r15 = r15 & 112(0x70, float:1.57E-43)
            java.lang.Integer r15 = java.lang.Integer.valueOf(r15)
            r27 = r4
            r4 = r23
            r4.invoke(r14, r5, r15)
            r14 = 2058660585(0x7ab4aae9, float:4.6903995E35)
            r5.startReplaceableGroup(r14)
            int r14 = r2 >> 9
            r14 = r14 & 14
            r15 = r5
            r23 = 0
            r28 = r2
            r2 = -678309503(0xffffffffd791d181, float:-3.20658E14)
            r15.startReplaceableGroup(r2)
            java.lang.String r2 = "C80@3988L9:Row.kt#2w3rfo"
            androidx.compose.runtime.ComposerKt.sourceInformation(r15, r2)
            r2 = r14 & 11
            r31 = r4
            r4 = 2
            if (r2 != r4) goto Led0
            boolean r2 = r15.getSkipping()
            if (r2 != 0) goto Leb9
            goto Led0
        Leb9:
            r15.skipToGroupEnd()
            r66 = r5
            r49 = r8
            r73 = r9
            r74 = r10
            r75 = r11
            r67 = r13
            r76 = r14
            r64 = r43
            r8 = r94
            goto L13d6
        Led0:
            androidx.compose.foundation.layout.RowScopeInstance r2 = androidx.compose.foundation.layout.RowScopeInstance.INSTANCE
            int r4 = r8 >> 6
            r4 = r4 & 112(0x70, float:1.57E-43)
            r4 = r4 | 6
            r63 = r2
            androidx.compose.foundation.layout.RowScope r63 = (androidx.compose.foundation.layout.RowScope) r63
            r2 = r15
            r39 = 0
            r42 = r4
            r4 = -1441393028(0xffffffffaa16167c, float:-1.3330477E-13)
            r49 = r8
            java.lang.String r8 = "C:CarControlScreen.kt#597736"
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(r2, r4, r8)
            r2.startReplaceableGroup(r4)
            java.lang.String r4 = "110@6472L173"
            androidx.compose.runtime.ComposerKt.sourceInformation(r2, r4)
            boolean r4 = CarControlScreen$lambda$22(r13)
            if (r4 == 0) goto Lf46
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r4 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            java.lang.String r64 = r4.m6220String$arg0$callDrivingPad$branch$if$fun$anonymous$$arg3$callRow1$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r4 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            boolean r65 = r4.m6166Boolean$arg1$callDrivingPad$branch$if$fun$anonymous$$arg3$callRow1$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            float r66 = CarControlScreen$lambda$11(r0)
            vea.raceremote.control.CarConnectionState r4 = CarControlScreen$lambda$1(r6)
            boolean r67 = r4.getConnected()
            androidx.compose.ui.Modifier$Companion r4 = androidx.compose.ui.Modifier.Companion
            androidx.compose.ui.Modifier r4 = (androidx.compose.ui.Modifier) r4
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r8 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            int r8 = r8.m6204Int$$$this$call$getdp$$arg0$callwidth$$$this$callfillMaxHeight$arg4$callDrivingPad$branch$if$fun$anonymous$$arg3$callRow1$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            r68 = 0
            r73 = r9
            float r9 = (float) r8
            float r8 = androidx.compose.ui.unit.Dp.m4046constructorimpl(r9)
            androidx.compose.ui.Modifier r4 = androidx.compose.foundation.layout.SizeKt.m473width3ABfNKs(r4, r8)
            r74 = r10
            r8 = 0
            r9 = 0
            r10 = 1
            androidx.compose.ui.Modifier r68 = androidx.compose.foundation.layout.SizeKt.fillMaxHeight$default(r4, r8, r10, r9)
            vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$3$1 r4 = new vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$3$1
            r8 = r94
            r4.<init>(r12, r0, r8)
            r69 = r4
            kotlin.jvm.functions.Function1 r69 = (kotlin.jvm.functions.Function1) r69
            r71 = 0
            r72 = 0
            r70 = r2
            vea.raceremote.control.DrivingPadKt.DrivingPad(r64, r65, r66, r67, r68, r69, r70, r71, r72)
            goto Lf4c
        Lf46:
            r73 = r9
            r74 = r10
            r8 = r94
        Lf4c:
            r2.endReplaceableGroup()
            boolean r4 = CarControlScreen$lambda$16(r3)
            if (r4 == 0) goto L1029
            r4 = -1441399488(0xffffffffaa15fd40, float:-1.3321722E-13)
            r2.startReplaceableGroup(r4)
            java.lang.String r4 = ""
            androidx.compose.runtime.ComposerKt.sourceInformation(r2, r4)
            java.lang.String r4 = CarControlScreen$lambda$2(r35)
            java.lang.CharSequence r4 = (java.lang.CharSequence) r4
            java.lang.CharSequence r4 = kotlin.text.StringsKt.trim(r4)
            java.lang.String r4 = r4.toString()
            int r9 = CarControlScreen$lambda$4(r36)
            java.lang.Integer r9 = java.lang.Integer.valueOf(r9)
            java.lang.Object r4 = r2.joinKey(r4, r9)
            java.lang.Long r9 = CarControlScreen$lambda$6(r37)
            java.lang.Object r4 = r2.joinKey(r4, r9)
            java.lang.String r9 = CarControlScreen$lambda$8(r38)
            java.lang.Object r4 = r2.joinKey(r4, r9)
            r9 = -1441392814(0xffffffffaa161752, float:-1.3330767E-13)
            r2.startMovableGroup(r9, r4)
            java.lang.String r4 = "116@7026L20,116@6919L127"
            androidx.compose.runtime.ComposerKt.sourceInformation(r2, r4)
            java.lang.String r4 = CarControlScreen$lambda$2(r35)
            java.lang.CharSequence r4 = (java.lang.CharSequence) r4
            java.lang.CharSequence r4 = kotlin.text.StringsKt.trim(r4)
            java.lang.String r4 = r4.toString()
            androidx.compose.ui.Modifier$Companion r9 = androidx.compose.ui.Modifier.Companion
            r64 = r9
            androidx.compose.ui.Modifier r64 = (androidx.compose.ui.Modifier) r64
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r9 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            float r65 = r9.m6194Float$arg0$callweight$$$this$callfillMaxHeight$arg1$callVideoPanel$fun$anonymous$$arg1$callkey$branch$if1$fun$anonymous$$arg3$callRow1$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            r66 = 0
            r67 = 2
            r68 = 0
            androidx.compose.ui.Modifier r9 = androidx.compose.foundation.layout.RowScope.weight$default(r63, r64, r65, r66, r67, r68)
            r75 = r11
            r76 = r14
            r10 = 0
            r11 = 0
            r14 = 1
            androidx.compose.ui.Modifier r65 = androidx.compose.foundation.layout.SizeKt.fillMaxHeight$default(r9, r10, r14, r11)
            boolean r9 = CarControlScreen$lambda$22(r13)
            r66 = r9 ^ 1
            r9 = 6
            r10 = 0
            r11 = 1157296644(0x44faf204, float:2007.563)
            r2.startReplaceableGroup(r11)
            java.lang.String r11 = "C(remember)P(1):Composables.kt#9igjgp"
            androidx.compose.runtime.ComposerKt.sourceInformation(r2, r11)
            r11 = r43
            boolean r14 = r2.changed(r11)
            r43 = r2
            r64 = 0
            r67 = r9
            java.lang.Object r9 = r43.rememberedValue()
            r68 = 0
            if (r14 != 0) goto Lffb
            androidx.compose.runtime.Composer$Companion r69 = androidx.compose.runtime.Composer.Companion
            r70 = r10
            java.lang.Object r10 = r69.getEmpty()
            if (r9 != r10) goto Lff6
            goto Lffd
        Lff6:
            r69 = r9
            r10 = r43
            goto L100e
        Lffb:
            r70 = r10
        Lffd:
            r10 = 0
            r69 = r9
            vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$3$2$1 r9 = new vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$3$2$1
            r9.<init>(r11)
            kotlin.jvm.functions.Function1 r9 = (kotlin.jvm.functions.Function1) r9
            r10 = r43
            r10.updateRememberedValue(r9)
        L100e:
            r2.endReplaceableGroup()
            r67 = r9
            kotlin.jvm.functions.Function1 r67 = (kotlin.jvm.functions.Function1) r67
            r69 = 0
            r70 = 0
            r64 = r4
            r68 = r2
            vea.raceremote.video.VideoPanelKt.VideoPanel(r64, r65, r66, r67, r68, r69, r70)
            r2.endMovableGroup()
            r2.endReplaceableGroup()
            goto L1090
        L1029:
            r75 = r11
            r76 = r14
            r11 = r43
            boolean r4 = CarControlScreen$lambda$22(r13)
            if (r4 == 0) goto L1087
            r4 = -1441392396(0xffffffffaa1618f4, float:-1.3331334E-13)
            r2.startReplaceableGroup(r4)
            java.lang.String r4 = "118@7091L92"
            androidx.compose.runtime.ComposerKt.sourceInformation(r2, r4)
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r4 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            java.lang.String r95 = r4.m6223String$arg0$callText$branch1$if1$fun$anonymous$$arg3$callRow1$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            androidx.compose.ui.Modifier$Companion r4 = androidx.compose.ui.Modifier.Companion
            r65 = r4
            androidx.compose.ui.Modifier r65 = (androidx.compose.ui.Modifier) r65
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r4 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            float r66 = r4.m6198Float$arg0$callweight$arg1$callText$branch1$if1$fun$anonymous$$arg3$callRow1$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            r67 = 0
            r68 = 2
            r69 = 0
            r64 = r63
            androidx.compose.ui.Modifier r96 = androidx.compose.foundation.layout.RowScope.weight$default(r64, r65, r66, r67, r68, r69)
            r97 = 0
            r99 = 0
            r101 = 0
            r102 = 0
            r103 = 0
            r104 = 0
            r106 = 0
            r107 = 0
            r108 = 0
            r110 = 0
            r111 = 0
            r112 = 0
            r113 = 0
            r114 = 0
            r116 = 0
            r117 = 0
            r118 = 65532(0xfffc, float:9.183E-41)
            r115 = r2
            androidx.compose.material.TextKt.m1249TextfLXpl1I(r95, r96, r97, r99, r101, r102, r103, r104, r106, r107, r108, r110, r111, r112, r113, r114, r115, r116, r117, r118)
            goto L108d
        L1087:
            r4 = -1441392304(0xffffffffaa161950, float:-1.3331458E-13)
            r2.startReplaceableGroup(r4)
        L108d:
            r2.endReplaceableGroup()
        L1090:
            boolean r4 = CarControlScreen$lambda$22(r13)
            if (r4 == 0) goto L10f1
            r1 = -1441392278(0xffffffffaa16196a, float:-1.3331494E-13)
            r2.startReplaceableGroup(r1)
            java.lang.String r1 = "119@7209L175"
            androidx.compose.runtime.ComposerKt.sourceInformation(r2, r1)
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r1 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            java.lang.String r64 = r1.m6221String$arg0$callDrivingPad$branch$if2$fun$anonymous$$arg3$callRow1$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r1 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            boolean r65 = r1.m6167Boolean$arg1$callDrivingPad$branch$if2$fun$anonymous$$arg3$callRow1$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            float r66 = CarControlScreen$lambda$14(r8)
            vea.raceremote.control.CarConnectionState r1 = CarControlScreen$lambda$1(r6)
            boolean r67 = r1.getConnected()
            androidx.compose.ui.Modifier$Companion r1 = androidx.compose.ui.Modifier.Companion
            androidx.compose.ui.Modifier r1 = (androidx.compose.ui.Modifier) r1
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r4 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            int r4 = r4.m6205Int$$$this$call$getdp$$arg0$callwidth$$$this$callfillMaxHeight$arg4$callDrivingPad$branch$if2$fun$anonymous$$arg3$callRow1$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            r7 = 0
            float r9 = (float) r4
            float r4 = androidx.compose.ui.unit.Dp.m4046constructorimpl(r9)
            androidx.compose.ui.Modifier r1 = androidx.compose.foundation.layout.SizeKt.m473width3ABfNKs(r1, r4)
            r4 = 0
            r7 = 0
            r9 = 1
            androidx.compose.ui.Modifier r68 = androidx.compose.foundation.layout.SizeKt.fillMaxHeight$default(r1, r4, r9, r7)
            vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$3$3 r1 = new vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$3$3
            r1.<init>(r12, r8, r0)
            r69 = r1
            kotlin.jvm.functions.Function1 r69 = (kotlin.jvm.functions.Function1) r69
            r71 = 0
            r72 = 0
            r70 = r2
            vea.raceremote.control.DrivingPadKt.DrivingPad(r64, r65, r66, r67, r68, r69, r70, r71, r72)
            r2.endReplaceableGroup()
            r66 = r5
            r64 = r11
            r67 = r13
            goto L13d1
        L10f1:
            r4 = -1441392085(0xffffffffaa161a2b, float:-1.3331755E-13)
            r2.startReplaceableGroup(r4)
            java.lang.String r4 = "122@7402L1011"
            androidx.compose.runtime.ComposerKt.sourceInformation(r2, r4)
            boolean r4 = CarControlScreen$lambda$16(r3)
            if (r4 == 0) goto L1117
            androidx.compose.ui.Modifier$Companion r4 = androidx.compose.ui.Modifier.Companion
            androidx.compose.ui.Modifier r4 = (androidx.compose.ui.Modifier) r4
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r9 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            int r9 = r9.m6206Int$$$this$call$getdp$$arg0$callwidth$branch$if$arg0$callColumn$else$if2$fun$anonymous$$arg3$callRow1$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            r10 = 0
            float r14 = (float) r9
            float r9 = androidx.compose.ui.unit.Dp.m4046constructorimpl(r14)
            androidx.compose.ui.Modifier r4 = androidx.compose.foundation.layout.SizeKt.m473width3ABfNKs(r4, r9)
            goto L1122
        L1117:
            androidx.compose.ui.Modifier$Companion r4 = androidx.compose.ui.Modifier.Companion
            androidx.compose.ui.Modifier r4 = (androidx.compose.ui.Modifier) r4
            r9 = 0
            r10 = 0
            r14 = 1
            androidx.compose.ui.Modifier r4 = androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(r4, r9, r14, r10)
        L1122:
            r9 = 0
            r10 = 0
            r14 = -483455358(0xffffffffe32f0e82, float:-3.2292256E21)
            r2.startReplaceableGroup(r14)
            r14 = r50
            androidx.compose.runtime.ComposerKt.sourceInformation(r2, r14)
            androidx.compose.foundation.layout.Arrangement r14 = androidx.compose.foundation.layout.Arrangement.INSTANCE
            androidx.compose.foundation.layout.Arrangement$Vertical r14 = r14.getTop()
            androidx.compose.ui.Alignment$Companion r34 = androidx.compose.ui.Alignment.Companion
            r43 = r10
            androidx.compose.ui.Alignment$Horizontal r10 = r34.getStart()
            int r34 = r9 >> 3
            r34 = r34 & 14
            int r50 = r9 >> 3
            r50 = r50 & 112(0x70, float:1.57E-43)
            r64 = r11
            r11 = r34 | r50
            androidx.compose.ui.layout.MeasurePolicy r11 = androidx.compose.foundation.layout.ColumnKt.columnMeasurePolicy(r14, r10, r2, r11)
            int r34 = r9 << 3
            r34 = r34 & 112(0x70, float:1.57E-43)
            r50 = 0
            r65 = r10
            r10 = -1323940314(0xffffffffb1164626, float:-2.1867748E-9)
            r2.startReplaceableGroup(r10)
            androidx.compose.runtime.ComposerKt.sourceInformation(r2, r1)
            androidx.compose.runtime.ProvidableCompositionLocal r1 = androidx.compose.ui.platform.CompositionLocalsKt.getLocalDensity()
            androidx.compose.runtime.CompositionLocal r1 = (androidx.compose.runtime.CompositionLocal) r1
            r10 = 6
            r47 = 0
            r66 = r10
            r10 = 2023513938(0x789c5f52, float:2.5372864E34)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(r2, r10, r7)
            java.lang.Object r10 = r2.consume(r1)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(r2)
            r1 = r10
            androidx.compose.ui.unit.Density r1 = (androidx.compose.ui.unit.Density) r1
            androidx.compose.runtime.ProvidableCompositionLocal r10 = androidx.compose.ui.platform.CompositionLocalsKt.getLocalLayoutDirection()
            androidx.compose.runtime.CompositionLocal r10 = (androidx.compose.runtime.CompositionLocal) r10
            r47 = 6
            r66 = 0
            r67 = r13
            r13 = 2023513938(0x789c5f52, float:2.5372864E34)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(r2, r13, r7)
            java.lang.Object r13 = r2.consume(r10)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(r2)
            r10 = r13
            androidx.compose.ui.unit.LayoutDirection r10 = (androidx.compose.ui.unit.LayoutDirection) r10
            androidx.compose.runtime.ProvidableCompositionLocal r13 = androidx.compose.ui.platform.CompositionLocalsKt.getLocalViewConfiguration()
            androidx.compose.runtime.CompositionLocal r13 = (androidx.compose.runtime.CompositionLocal) r13
            r47 = 6
            r66 = 0
            r68 = r14
            r14 = 2023513938(0x789c5f52, float:2.5372864E34)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(r2, r14, r7)
            java.lang.Object r7 = r2.consume(r13)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(r2)
            androidx.compose.ui.platform.ViewConfiguration r7 = (androidx.compose.ui.platform.ViewConfiguration) r7
            androidx.compose.ui.node.ComposeUiNode$Companion r13 = androidx.compose.ui.node.ComposeUiNode.Companion
            kotlin.jvm.functions.Function0 r13 = r13.getConstructor()
            kotlin.jvm.functions.Function3 r14 = androidx.compose.ui.layout.LayoutKt.materializerOf(r4)
            r20 = r4
            int r4 = r34 << 9
            r4 = r4 & 7168(0x1c00, float:1.0045E-41)
            r4 = r4 | 6
            r47 = 0
            r66 = r5
            androidx.compose.runtime.Applier r5 = r2.getApplier()
            boolean r5 = r5 instanceof androidx.compose.runtime.Applier
            if (r5 != 0) goto L11d3
            androidx.compose.runtime.ComposablesKt.invalidApplier()
        L11d3:
            r2.startReusableNode()
            boolean r5 = r2.getInserting()
            if (r5 == 0) goto L11e0
            r2.createNode(r13)
            goto L11e3
        L11e0:
            r2.useNode()
        L11e3:
            r2.disableReusing()
            androidx.compose.runtime.Composer r5 = androidx.compose.runtime.Updater.m1304constructorimpl(r2)
            r69 = 0
            androidx.compose.ui.node.ComposeUiNode$Companion r70 = androidx.compose.ui.node.ComposeUiNode.Companion
            r71 = r13
            kotlin.jvm.functions.Function2 r13 = r70.getSetMeasurePolicy()
            androidx.compose.runtime.Updater.m1311setimpl(r5, r11, r13)
            androidx.compose.ui.node.ComposeUiNode$Companion r13 = androidx.compose.ui.node.ComposeUiNode.Companion
            kotlin.jvm.functions.Function2 r13 = r13.getSetDensity()
            androidx.compose.runtime.Updater.m1311setimpl(r5, r1, r13)
            androidx.compose.ui.node.ComposeUiNode$Companion r13 = androidx.compose.ui.node.ComposeUiNode.Companion
            kotlin.jvm.functions.Function2 r13 = r13.getSetLayoutDirection()
            androidx.compose.runtime.Updater.m1311setimpl(r5, r10, r13)
            androidx.compose.ui.node.ComposeUiNode$Companion r13 = androidx.compose.ui.node.ComposeUiNode.Companion
            kotlin.jvm.functions.Function2 r13 = r13.getSetViewConfiguration()
            androidx.compose.runtime.Updater.m1311setimpl(r5, r7, r13)
            r2.enableReusing()
            androidx.compose.runtime.Composer r5 = androidx.compose.runtime.SkippableUpdater.m1295constructorimpl(r2)
            androidx.compose.runtime.SkippableUpdater r5 = androidx.compose.runtime.SkippableUpdater.m1294boximpl(r5)
            int r13 = r4 >> 3
            r13 = r13 & 112(0x70, float:1.57E-43)
            java.lang.Integer r13 = java.lang.Integer.valueOf(r13)
            r14.invoke(r5, r2, r13)
            r5 = 2058660585(0x7ab4aae9, float:4.6903995E35)
            r2.startReplaceableGroup(r5)
            int r5 = r4 >> 9
            r5 = r5 & 14
            r13 = r2
            r59 = 0
            r69 = r1
            r1 = -1163856341(0xffffffffbaa0f62b, float:-0.0012280395)
            r13.startReplaceableGroup(r1)
            java.lang.String r1 = "C79@3994L9:Column.kt#2w3rfo"
            androidx.compose.runtime.ComposerKt.sourceInformation(r13, r1)
            r1 = r5 & 11
            r53 = r4
            r4 = 2
            if (r1 != r4) goto L125c
            boolean r1 = r13.getSkipping()
            if (r1 != 0) goto L1251
            goto L125c
        L1251:
            r13.skipToGroupEnd()
            r78 = r5
            r144 = r7
            r79 = r9
            goto L13bc
        L125c:
            androidx.compose.foundation.layout.ColumnScopeInstance r1 = androidx.compose.foundation.layout.ColumnScopeInstance.INSTANCE
            int r4 = r9 >> 6
            r4 = r4 & 112(0x70, float:1.57E-43)
            r4 = r4 | 6
            androidx.compose.foundation.layout.ColumnScope r1 = (androidx.compose.foundation.layout.ColumnScope) r1
            r144 = r13
            r138 = r144
            r114 = r144
            r70 = 0
            r72 = r1
            r1 = -130137303(0xfffffffff83e4329, float:-1.5435915E34)
            r77 = r4
            java.lang.String r4 = "C123@7495L35,124@7547L321,127@7885L43,128@7945L321:CarControlScreen.kt#597736"
            r78 = r5
            r5 = r144
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(r5, r1, r4)
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r1 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            java.lang.String r94 = r1.m6225String$arg0$callText$fun$anonymous$$arg3$callColumn$else$if2$fun$anonymous$$arg3$callRow1$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            r95 = 0
            r96 = 0
            r98 = 0
            r100 = 0
            r101 = 0
            r102 = 0
            r103 = 0
            r105 = 0
            r106 = 0
            r107 = 0
            r109 = 0
            r110 = 0
            r111 = 0
            r112 = 0
            r113 = 0
            r115 = 0
            r116 = 0
            r117 = 65534(0xfffe, float:9.1833E-41)
            androidx.compose.material.TextKt.m1249TextfLXpl1I(r94, r95, r96, r98, r100, r101, r102, r103, r105, r106, r107, r109, r110, r111, r112, r113, r114, r115, r116, r117)
            float r94 = CarControlScreen$lambda$11(r0)
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r1 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            float r1 = r1.m6171Float$$$this$callrangeTo$valtmp1_valueRange$fun$anonymous$$arg3$callColumn$else$if2$fun$anonymous$$arg3$callRow1$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r4 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            float r4 = r4.m6191Float$arg0$callrangeTo$valtmp1_valueRange$fun$anonymous$$arg3$callColumn$else$if2$fun$anonymous$$arg3$callRow1$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            kotlin.ranges.ClosedFloatingPointRange r98 = kotlin.ranges.RangesKt.rangeTo(r1, r4)
            vea.raceremote.control.CarConnectionState r1 = CarControlScreen$lambda$1(r6)
            boolean r97 = r1.getConnected()
            androidx.compose.ui.Modifier$Companion r1 = androidx.compose.ui.Modifier.Companion
            androidx.compose.ui.Modifier r1 = (androidx.compose.ui.Modifier) r1
            r144 = r7
            r79 = r9
            r4 = 0
            r7 = 0
            r9 = 1
            androidx.compose.ui.Modifier r1 = androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(r1, r4, r9, r7)
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r4 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            java.lang.String r4 = r4.m6241String$arg0$calltestTag$valtmp3_modifier$fun$anonymous$$arg3$callColumn$else$if2$fun$anonymous$$arg3$callRow1$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            androidx.compose.ui.Modifier r96 = androidx.compose.ui.platform.TestTagKt.testTag(r1, r4)
            vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$3$4$1 r1 = new vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$3$4$1
            r1.<init>(r12, r0, r8)
            r95 = r1
            kotlin.jvm.functions.Function1 r95 = (kotlin.jvm.functions.Function1) r95
            r99 = 0
            vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$3$4$2 r1 = new vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$3$4$2
            r1.<init>(r12, r0, r8)
            r100 = r1
            kotlin.jvm.functions.Function0 r100 = (kotlin.jvm.functions.Function0) r100
            r104 = 0
            r105 = 416(0x1a0, float:5.83E-43)
            r103 = r5
            androidx.compose.material.SliderKt.Slider(r94, r95, r96, r97, r98, r99, r100, r101, r102, r103, r104, r105)
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r1 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            java.lang.String r118 = r1.m6229String$arg0$callText1$fun$anonymous$$arg3$callColumn$else$if2$fun$anonymous$$arg3$callRow1$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            r119 = 0
            r120 = 0
            r122 = 0
            r124 = 0
            r125 = 0
            r126 = 0
            r127 = 0
            r129 = 0
            r130 = 0
            r131 = 0
            r133 = 0
            r134 = 0
            r135 = 0
            r136 = 0
            r137 = 0
            r139 = 0
            r140 = 0
            r141 = 65534(0xfffe, float:9.1833E-41)
            androidx.compose.material.TextKt.m1249TextfLXpl1I(r118, r119, r120, r122, r124, r125, r126, r127, r129, r130, r131, r133, r134, r135, r136, r137, r138, r139, r140, r141)
            float r94 = CarControlScreen$lambda$14(r8)
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r1 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            float r1 = r1.m6172Float$$$this$callrangeTo$valtmp5_valueRange$fun$anonymous$$arg3$callColumn$else$if2$fun$anonymous$$arg3$callRow1$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r4 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            float r4 = r4.m6192Float$arg0$callrangeTo$valtmp5_valueRange$fun$anonymous$$arg3$callColumn$else$if2$fun$anonymous$$arg3$callRow1$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            kotlin.ranges.ClosedFloatingPointRange r98 = kotlin.ranges.RangesKt.rangeTo(r1, r4)
            vea.raceremote.control.CarConnectionState r1 = CarControlScreen$lambda$1(r6)
            boolean r97 = r1.getConnected()
            androidx.compose.ui.Modifier$Companion r1 = androidx.compose.ui.Modifier.Companion
            androidx.compose.ui.Modifier r1 = (androidx.compose.ui.Modifier) r1
            r4 = 0
            r7 = 0
            r9 = 1
            androidx.compose.ui.Modifier r1 = androidx.compose.foundation.layout.SizeKt.fillMaxWidth$default(r1, r4, r9, r7)
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r4 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            java.lang.String r4 = r4.m6243String$arg0$calltestTag$valtmp7_modifier$fun$anonymous$$arg3$callColumn$else$if2$fun$anonymous$$arg3$callRow1$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            androidx.compose.ui.Modifier r96 = androidx.compose.ui.platform.TestTagKt.testTag(r1, r4)
            vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$3$4$3 r1 = new vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$3$4$3
            r1.<init>(r12, r8, r0)
            r95 = r1
            kotlin.jvm.functions.Function1 r95 = (kotlin.jvm.functions.Function1) r95
            vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$3$4$4 r1 = new vea.raceremote.control.CarControlScreenKt$CarControlScreen$4$3$4$4
            r1.<init>(r12, r8, r0)
            r100 = r1
            kotlin.jvm.functions.Function0 r100 = (kotlin.jvm.functions.Function0) r100
            androidx.compose.material.SliderKt.Slider(r94, r95, r96, r97, r98, r99, r100, r101, r102, r103, r104, r105)
            r1 = -1441391204(0xffffffffaa161d9c, float:-1.3332949E-13)
            r2.startReplaceableGroup(r1)
            java.lang.String r1 = "131@8299L100"
            androidx.compose.runtime.ComposerKt.sourceInformation(r2, r1)
            boolean r1 = CarControlScreen$lambda$16(r3)
            if (r1 != 0) goto L13b4
            vea.raceremote.control.LiveLiterals$CarControlScreenKt r1 = vea.raceremote.control.LiveLiterals$CarControlScreenKt.INSTANCE
            java.lang.String r94 = r1.m6222String$arg0$callText$branch$if$fun$anonymous$$arg3$callColumn$else$if2$fun$anonymous$$arg3$callRow1$fun$anonymous$$arg3$callColumn$funCarControlScreen()
            r95 = 0
            r96 = 0
            r98 = 0
            r100 = 0
            r101 = 0
            r102 = 0
            r103 = 0
            r105 = 0
            r106 = 0
            r107 = 0
            r109 = 0
            r110 = 0
            r111 = 0
            r112 = 0
            r113 = 0
            r115 = 0
            r116 = 0
            r117 = 65534(0xfffe, float:9.1833E-41)
            r114 = r5
            androidx.compose.material.TextKt.m1249TextfLXpl1I(r94, r95, r96, r98, r100, r101, r102, r103, r105, r106, r107, r109, r110, r111, r112, r113, r114, r115, r116, r117)
        L13b4:
            r2.endReplaceableGroup()
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(r5)
        L13bc:
            r13.endReplaceableGroup()
            r2.endReplaceableGroup()
            r2.endNode()
            r2.endReplaceableGroup()
            r2.endReplaceableGroup()
            r2.endReplaceableGroup()
        L13d1:
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(r2)
        L13d6:
            r15.endReplaceableGroup()
            r66.endReplaceableGroup()
            r66.endNode()
            r66.endReplaceableGroup()
            r66.endReplaceableGroup()
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(r66)
        L13ed:
            r33.endReplaceableGroup()
            r93.endReplaceableGroup()
            r93.endNode()
            r93.endReplaceableGroup()
            r93.endReplaceableGroup()
            boolean r1 = androidx.compose.runtime.ComposerKt.isTraceInProgress()
            if (r1 == 0) goto L1408
            androidx.compose.runtime.ComposerKt.traceEventEnd()
        L1408:
            r6 = r24
            r3 = r32
            r5 = r55
        L140e:
            androidx.compose.runtime.ScopeUpdateScope r0 = r93.endRestartGroup()
            if (r0 != 0) goto L1417
            r2 = r145
            goto L1425
        L1417:
            vea.raceremote.control.CarControlScreenKt$CarControlScreen$5 r1 = new vea.raceremote.control.CarControlScreenKt$CarControlScreen$5
            r2 = r145
            r4 = r146
            r1.<init>(r5, r6, r2, r4)
            kotlin.jvm.functions.Function2 r1 = (kotlin.jvm.functions.Function2) r1
            r0.updateScope(r1)
        L1425:
            return
    }

    private static final vea.raceremote.control.CarConnectionState CarControlScreen$lambda$1(androidx.compose.runtime.State<vea.raceremote.control.CarConnectionState> r4) {
            r0 = 0
            r1 = 0
            r2 = r4
            r3 = 0
            java.lang.Object r0 = r2.getValue()
            vea.raceremote.control.CarConnectionState r0 = (vea.raceremote.control.CarConnectionState) r0
            return r0
    }

    private static final float CarControlScreen$lambda$11(androidx.compose.runtime.MutableState<java.lang.Float> r4) {
            r0 = r4
            androidx.compose.runtime.State r0 = (androidx.compose.runtime.State) r0
            r1 = 0
            r2 = 0
            r3 = 0
            java.lang.Object r0 = r0.getValue()
            java.lang.Number r0 = (java.lang.Number) r0
            float r0 = r0.floatValue()
            return r0
    }

    private static final void CarControlScreen$lambda$12(androidx.compose.runtime.MutableState<java.lang.Float> r5, float r6) {
            r0 = 0
            r1 = 0
            java.lang.Float r2 = java.lang.Float.valueOf(r6)
            r3 = r5
            r4 = 0
            r3.setValue(r2)
            return
    }

    private static final float CarControlScreen$lambda$14(androidx.compose.runtime.MutableState<java.lang.Float> r4) {
            r0 = r4
            androidx.compose.runtime.State r0 = (androidx.compose.runtime.State) r0
            r1 = 0
            r2 = 0
            r3 = 0
            java.lang.Object r0 = r0.getValue()
            java.lang.Number r0 = (java.lang.Number) r0
            float r0 = r0.floatValue()
            return r0
    }

    private static final void CarControlScreen$lambda$15(androidx.compose.runtime.MutableState<java.lang.Float> r5, float r6) {
            r0 = 0
            r1 = 0
            java.lang.Float r2 = java.lang.Float.valueOf(r6)
            r3 = r5
            r4 = 0
            r3.setValue(r2)
            return
    }

    private static final boolean CarControlScreen$lambda$16(androidx.compose.runtime.MutableState<java.lang.Boolean> r4) {
            r0 = r4
            androidx.compose.runtime.State r0 = (androidx.compose.runtime.State) r0
            r1 = 0
            r2 = 0
            r3 = 0
            java.lang.Object r0 = r0.getValue()
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            boolean r0 = r0.booleanValue()
            return r0
    }

    private static final void CarControlScreen$lambda$17(androidx.compose.runtime.MutableState<java.lang.Boolean> r5, boolean r6) {
            r0 = 0
            r1 = 0
            java.lang.Boolean r2 = java.lang.Boolean.valueOf(r6)
            r3 = r5
            r4 = 0
            r3.setValue(r2)
            return
    }

    private static final boolean CarControlScreen$lambda$19(androidx.compose.runtime.MutableState<java.lang.Boolean> r4) {
            r0 = r4
            androidx.compose.runtime.State r0 = (androidx.compose.runtime.State) r0
            r1 = 0
            r2 = 0
            r3 = 0
            java.lang.Object r0 = r0.getValue()
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            boolean r0 = r0.booleanValue()
            return r0
    }

    private static final java.lang.String CarControlScreen$lambda$2(androidx.compose.runtime.MutableState<java.lang.String> r4) {
            r0 = r4
            androidx.compose.runtime.State r0 = (androidx.compose.runtime.State) r0
            r1 = 0
            r2 = 0
            r3 = 0
            java.lang.Object r0 = r0.getValue()
            java.lang.String r0 = (java.lang.String) r0
            return r0
    }

    private static final void CarControlScreen$lambda$20(androidx.compose.runtime.MutableState<java.lang.Boolean> r5, boolean r6) {
            r0 = 0
            r1 = 0
            java.lang.Boolean r2 = java.lang.Boolean.valueOf(r6)
            r3 = r5
            r4 = 0
            r3.setValue(r2)
            return
    }

    private static final boolean CarControlScreen$lambda$22(androidx.compose.runtime.MutableState<java.lang.Boolean> r4) {
            r0 = r4
            androidx.compose.runtime.State r0 = (androidx.compose.runtime.State) r0
            r1 = 0
            r2 = 0
            r3 = 0
            java.lang.Object r0 = r0.getValue()
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            boolean r0 = r0.booleanValue()
            return r0
    }

    private static final void CarControlScreen$lambda$23(androidx.compose.runtime.MutableState<java.lang.Boolean> r5, boolean r6) {
            r0 = 0
            r1 = 0
            java.lang.Boolean r2 = java.lang.Boolean.valueOf(r6)
            r3 = r5
            r4 = 0
            r3.setValue(r2)
            return
    }

    private static final void CarControlScreen$lambda$3(androidx.compose.runtime.MutableState<java.lang.String> r4, java.lang.String r5) {
            r0 = 0
            r1 = 0
            r2 = r4
            r3 = 0
            r2.setValue(r5)
            return
    }

    private static final int CarControlScreen$lambda$4(androidx.compose.runtime.MutableState<java.lang.Integer> r4) {
            r0 = r4
            androidx.compose.runtime.State r0 = (androidx.compose.runtime.State) r0
            r1 = 0
            r2 = 0
            r3 = 0
            java.lang.Object r0 = r0.getValue()
            java.lang.Number r0 = (java.lang.Number) r0
            int r0 = r0.intValue()
            return r0
    }

    private static final void CarControlScreen$lambda$5(androidx.compose.runtime.MutableState<java.lang.Integer> r5, int r6) {
            r0 = 0
            r1 = 0
            java.lang.Integer r2 = java.lang.Integer.valueOf(r6)
            r3 = r5
            r4 = 0
            r3.setValue(r2)
            return
    }

    private static final java.lang.Long CarControlScreen$lambda$6(androidx.compose.runtime.MutableState<java.lang.Long> r4) {
            r0 = r4
            androidx.compose.runtime.State r0 = (androidx.compose.runtime.State) r0
            r1 = 0
            r2 = 0
            r3 = 0
            java.lang.Object r0 = r0.getValue()
            java.lang.Long r0 = (java.lang.Long) r0
            return r0
    }

    private static final void CarControlScreen$lambda$7(androidx.compose.runtime.MutableState<java.lang.Long> r4, java.lang.Long r5) {
            r0 = 0
            r1 = 0
            r2 = r4
            r3 = 0
            r2.setValue(r5)
            return
    }

    private static final java.lang.String CarControlScreen$lambda$8(androidx.compose.runtime.MutableState<java.lang.String> r4) {
            r0 = r4
            androidx.compose.runtime.State r0 = (androidx.compose.runtime.State) r0
            r1 = 0
            r2 = 0
            r3 = 0
            java.lang.Object r0 = r0.getValue()
            java.lang.String r0 = (java.lang.String) r0
            return r0
    }

    private static final void CarControlScreen$lambda$9(androidx.compose.runtime.MutableState<java.lang.String> r4, java.lang.String r5) {
            r0 = 0
            r1 = 0
            r2 = r4
            r3 = 0
            r2.setValue(r5)
            return
    }

    public static final /* synthetic */ vea.raceremote.control.CarConnectionState access$CarControlScreen$lambda$1(androidx.compose.runtime.State r1) {
            vea.raceremote.control.CarConnectionState r0 = CarControlScreen$lambda$1(r1)
            return r0
    }

    public static final /* synthetic */ float access$CarControlScreen$lambda$11(androidx.compose.runtime.MutableState r1) {
            float r0 = CarControlScreen$lambda$11(r1)
            return r0
    }

    public static final /* synthetic */ void access$CarControlScreen$lambda$12(androidx.compose.runtime.MutableState r0, float r1) {
            CarControlScreen$lambda$12(r0, r1)
            return
    }

    public static final /* synthetic */ float access$CarControlScreen$lambda$14(androidx.compose.runtime.MutableState r1) {
            float r0 = CarControlScreen$lambda$14(r1)
            return r0
    }

    public static final /* synthetic */ void access$CarControlScreen$lambda$15(androidx.compose.runtime.MutableState r0, float r1) {
            CarControlScreen$lambda$15(r0, r1)
            return
    }

    public static final /* synthetic */ void access$CarControlScreen$lambda$17(androidx.compose.runtime.MutableState r0, boolean r1) {
            CarControlScreen$lambda$17(r0, r1)
            return
    }

    public static final /* synthetic */ boolean access$CarControlScreen$lambda$19(androidx.compose.runtime.MutableState r1) {
            boolean r0 = CarControlScreen$lambda$19(r1)
            return r0
    }

    public static final /* synthetic */ java.lang.String access$CarControlScreen$lambda$2(androidx.compose.runtime.MutableState r1) {
            java.lang.String r0 = CarControlScreen$lambda$2(r1)
            return r0
    }

    public static final /* synthetic */ void access$CarControlScreen$lambda$20(androidx.compose.runtime.MutableState r0, boolean r1) {
            CarControlScreen$lambda$20(r0, r1)
            return
    }

    public static final /* synthetic */ boolean access$CarControlScreen$lambda$22(androidx.compose.runtime.MutableState r1) {
            boolean r0 = CarControlScreen$lambda$22(r1)
            return r0
    }

    public static final /* synthetic */ void access$CarControlScreen$lambda$23(androidx.compose.runtime.MutableState r0, boolean r1) {
            CarControlScreen$lambda$23(r0, r1)
            return
    }

    public static final /* synthetic */ void access$CarControlScreen$lambda$3(androidx.compose.runtime.MutableState r0, java.lang.String r1) {
            CarControlScreen$lambda$3(r0, r1)
            return
    }

    public static final /* synthetic */ int access$CarControlScreen$lambda$4(androidx.compose.runtime.MutableState r1) {
            int r0 = CarControlScreen$lambda$4(r1)
            return r0
    }

    public static final /* synthetic */ void access$CarControlScreen$lambda$5(androidx.compose.runtime.MutableState r0, int r1) {
            CarControlScreen$lambda$5(r0, r1)
            return
    }

    public static final /* synthetic */ java.lang.Long access$CarControlScreen$lambda$6(androidx.compose.runtime.MutableState r1) {
            java.lang.Long r0 = CarControlScreen$lambda$6(r1)
            return r0
    }

    public static final /* synthetic */ void access$CarControlScreen$lambda$7(androidx.compose.runtime.MutableState r0, java.lang.Long r1) {
            CarControlScreen$lambda$7(r0, r1)
            return
    }

    public static final /* synthetic */ java.lang.String access$CarControlScreen$lambda$8(androidx.compose.runtime.MutableState r1) {
            java.lang.String r0 = CarControlScreen$lambda$8(r1)
            return r0
    }

    public static final /* synthetic */ void access$CarControlScreen$lambda$9(androidx.compose.runtime.MutableState r0, java.lang.String r1) {
            CarControlScreen$lambda$9(r0, r1)
            return
    }
}
