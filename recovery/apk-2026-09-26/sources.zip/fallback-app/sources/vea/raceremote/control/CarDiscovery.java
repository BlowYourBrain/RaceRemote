package vea.raceremote.control;

/* JADX INFO: compiled from: CarDiscovery.kt */
/* JADX INFO: loaded from: classes4.dex */
@kotlin.Metadata(d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u0000 \u001a2\u00020\u0001:\u0001\u001aB\u0005¢\u0006\u0002\u0010\u0002J\u0006\u0010\u0011\u001a\u00020\u0012J\u0006\u0010\u0013\u001a\u00020\u0012J,\u0010\u0014\u001a\u00020\u00122\u000e\b\u0002\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00170\u00162\u0014\b\u0002\u0010\u0018\u001a\u000e\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\u00120\u0019R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\b\u001a\u0004\u0018\u00010\tX\u0082\u000e¢\u0006\u0002\n\u0000R\u0017\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00070\u000b¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0016\u0010\u000e\u001a\n \u0010*\u0004\u0018\u00010\u000f0\u000fX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001b"}, d2 = {"Lvea/raceremote/control/CarDiscovery;", "", "()V", "generation", "", "mutableState", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Lvea/raceremote/control/DiscoveryState;", "socket", "Ljava/net/DatagramSocket;", "state", "Lkotlinx/coroutines/flow/StateFlow;", "getState", "()Lkotlinx/coroutines/flow/StateFlow;", "worker", "Ljava/util/concurrent/ExecutorService;", "kotlin.jvm.PlatformType", "cancel", "", "close", "search", "targets", "", "Ljava/net/InetAddress;", "configure", "Lkotlin/Function1;", "Companion", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class CarDiscovery {
    public static final int $stable = 0;
    public static final vea.raceremote.control.CarDiscovery.Companion Companion = null;
    private long generation;
    private final kotlinx.coroutines.flow.MutableStateFlow<vea.raceremote.control.DiscoveryState> mutableState;
    private java.net.DatagramSocket socket;
    private final kotlinx.coroutines.flow.StateFlow<vea.raceremote.control.DiscoveryState> state;
    private final java.util.concurrent.ExecutorService worker;

    /* JADX INFO: compiled from: CarDiscovery.kt */
    @kotlin.Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004J\u0010\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u0005H\u0002¨\u0006\t"}, d2 = {"Lvea/raceremote/control/CarDiscovery$Companion;", "", "()V", "broadcastTargets", "", "Ljava/net/InetAddress;", "localAddress", "", "address", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        public static final /* synthetic */ boolean access$localAddress(vea.raceremote.control.CarDiscovery.Companion r1, java.net.InetAddress r2) {
                boolean r0 = r1.localAddress(r2)
                return r0
        }

        private final boolean localAddress(java.net.InetAddress r2) {
                r1 = this;
                boolean r0 = r2 instanceof java.net.Inet4Address
                if (r0 == 0) goto L18
                r0 = r2
                java.net.Inet4Address r0 = (java.net.Inet4Address) r0
                boolean r0 = r0.isSiteLocalAddress()
                if (r0 != 0) goto L16
                r0 = r2
                java.net.Inet4Address r0 = (java.net.Inet4Address) r0
                boolean r0 = r0.isLoopbackAddress()
                if (r0 == 0) goto L18
            L16:
                r0 = 1
                goto L19
            L18:
                r0 = 0
            L19:
                return r0
        }

        public final java.util.List<java.net.InetAddress> broadcastTargets() {
                r16 = this;
                kotlin.Result$Companion r0 = kotlin.Result.Companion     // Catch: java.lang.Throwable -> Lf4
                r0 = r16
                vea.raceremote.control.CarDiscovery$Companion r0 = (vea.raceremote.control.CarDiscovery.Companion) r0     // Catch: java.lang.Throwable -> Lf4
                r1 = 0
                java.util.Enumeration r2 = java.net.NetworkInterface.getNetworkInterfaces()     // Catch: java.lang.Throwable -> Lf4
                java.util.ArrayList r2 = java.util.Collections.list(r2)     // Catch: java.lang.Throwable -> Lf4
                java.lang.String r3 = "list(NetworkInterface.getNetworkInterfaces())"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, r3)     // Catch: java.lang.Throwable -> Lf4
                java.lang.Iterable r2 = (java.lang.Iterable) r2     // Catch: java.lang.Throwable -> Lf4
                r3 = 0
                java.util.ArrayList r4 = new java.util.ArrayList     // Catch: java.lang.Throwable -> Lf4
                r4.<init>()     // Catch: java.lang.Throwable -> Lf4
                java.util.Collection r4 = (java.util.Collection) r4     // Catch: java.lang.Throwable -> Lf4
                r5 = r2
                r6 = 0
                java.util.Iterator r7 = r5.iterator()     // Catch: java.lang.Throwable -> Lf4
            L24:
                boolean r8 = r7.hasNext()     // Catch: java.lang.Throwable -> Lf4
                if (r8 == 0) goto L47
                java.lang.Object r8 = r7.next()     // Catch: java.lang.Throwable -> Lf4
                r9 = r8
                java.net.NetworkInterface r9 = (java.net.NetworkInterface) r9     // Catch: java.lang.Throwable -> Lf4
                r10 = 0
                boolean r11 = r9.isUp()     // Catch: java.lang.Throwable -> Lf4
                if (r11 == 0) goto L40
                boolean r11 = r9.isLoopback()     // Catch: java.lang.Throwable -> Lf4
                if (r11 != 0) goto L40
                r11 = 1
                goto L41
            L40:
                r11 = 0
            L41:
                if (r11 == 0) goto L24
                r4.add(r8)     // Catch: java.lang.Throwable -> Lf4
                goto L24
            L47:
                java.util.List r4 = (java.util.List) r4     // Catch: java.lang.Throwable -> Lf4
                java.lang.Iterable r4 = (java.lang.Iterable) r4     // Catch: java.lang.Throwable -> Lf4
                r2 = r4
                r3 = 0
                java.util.ArrayList r4 = new java.util.ArrayList     // Catch: java.lang.Throwable -> Lf4
                r4.<init>()     // Catch: java.lang.Throwable -> Lf4
                java.util.Collection r4 = (java.util.Collection) r4     // Catch: java.lang.Throwable -> Lf4
                r5 = r2
                r6 = 0
                java.util.Iterator r7 = r5.iterator()     // Catch: java.lang.Throwable -> Lf4
            L5c:
                boolean r8 = r7.hasNext()     // Catch: java.lang.Throwable -> Lf4
                if (r8 == 0) goto L7a
                java.lang.Object r8 = r7.next()     // Catch: java.lang.Throwable -> Lf4
                r9 = r8
                java.net.NetworkInterface r9 = (java.net.NetworkInterface) r9     // Catch: java.lang.Throwable -> Lf4
                r10 = 0
                java.util.List r11 = r9.getInterfaceAddresses()     // Catch: java.lang.Throwable -> Lf4
                java.lang.String r12 = "it.interfaceAddresses"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r11, r12)     // Catch: java.lang.Throwable -> Lf4
                java.lang.Iterable r11 = (java.lang.Iterable) r11     // Catch: java.lang.Throwable -> Lf4
                r9 = r11
                kotlin.collections.CollectionsKt.addAll(r4, r9)     // Catch: java.lang.Throwable -> Lf4
                goto L5c
            L7a:
                java.util.List r4 = (java.util.List) r4     // Catch: java.lang.Throwable -> Lf4
                java.lang.Iterable r4 = (java.lang.Iterable) r4     // Catch: java.lang.Throwable -> Lf4
                r2 = r4
                r3 = 0
                java.util.ArrayList r4 = new java.util.ArrayList     // Catch: java.lang.Throwable -> Lf4
                r4.<init>()     // Catch: java.lang.Throwable -> Lf4
                java.util.Collection r4 = (java.util.Collection) r4     // Catch: java.lang.Throwable -> Lf4
                r5 = r2
                r6 = 0
                java.util.Iterator r7 = r5.iterator()     // Catch: java.lang.Throwable -> Lf4
            L8f:
                boolean r8 = r7.hasNext()     // Catch: java.lang.Throwable -> Lf4
                if (r8 == 0) goto Lb0
                java.lang.Object r8 = r7.next()     // Catch: java.lang.Throwable -> Lf4
                r9 = r8
                java.net.InterfaceAddress r9 = (java.net.InterfaceAddress) r9     // Catch: java.lang.Throwable -> Lf4
                r10 = 0
                java.net.InetAddress r11 = r9.getAddress()     // Catch: java.lang.Throwable -> Lf4
                java.lang.String r12 = "it.address"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r11, r12)     // Catch: java.lang.Throwable -> Lf4
                boolean r11 = r0.localAddress(r11)     // Catch: java.lang.Throwable -> Lf4
                if (r11 == 0) goto L8f
                r4.add(r8)     // Catch: java.lang.Throwable -> Lf4
                goto L8f
            Lb0:
                java.util.List r4 = (java.util.List) r4     // Catch: java.lang.Throwable -> Lf4
                java.lang.Iterable r4 = (java.lang.Iterable) r4     // Catch: java.lang.Throwable -> Lf4
                r2 = r4
                r3 = 0
                java.util.ArrayList r4 = new java.util.ArrayList     // Catch: java.lang.Throwable -> Lf4
                r4.<init>()     // Catch: java.lang.Throwable -> Lf4
                java.util.Collection r4 = (java.util.Collection) r4     // Catch: java.lang.Throwable -> Lf4
                r5 = r2
                r6 = 0
                r7 = r5
                r8 = 0
                java.util.Iterator r9 = r7.iterator()     // Catch: java.lang.Throwable -> Lf4
            Lc7:
                boolean r10 = r9.hasNext()     // Catch: java.lang.Throwable -> Lf4
                if (r10 == 0) goto Le4
                java.lang.Object r10 = r9.next()     // Catch: java.lang.Throwable -> Lf4
                r11 = r10
                r12 = 0
                r13 = r11
                java.net.InterfaceAddress r13 = (java.net.InterfaceAddress) r13     // Catch: java.lang.Throwable -> Lf4
                r14 = 0
                java.net.InetAddress r15 = r13.getBroadcast()     // Catch: java.lang.Throwable -> Lf4
                if (r15 == 0) goto Le2
                r13 = r15
                r14 = 0
                r4.add(r13)     // Catch: java.lang.Throwable -> Lf4
            Le2:
                goto Lc7
            Le4:
                java.util.List r4 = (java.util.List) r4     // Catch: java.lang.Throwable -> Lf4
                java.lang.Iterable r4 = (java.lang.Iterable) r4     // Catch: java.lang.Throwable -> Lf4
                java.util.List r2 = kotlin.collections.CollectionsKt.distinct(r4)     // Catch: java.lang.Throwable -> Lf4
                java.lang.Object r0 = kotlin.Result.m4399constructorimpl(r2)     // Catch: java.lang.Throwable -> Lf4
                goto Lff
            Lf4:
                r0 = move-exception
                kotlin.Result$Companion r1 = kotlin.Result.Companion
                java.lang.Object r0 = kotlin.ResultKt.createFailure(r0)
                java.lang.Object r0 = kotlin.Result.m4399constructorimpl(r0)
            Lff:
                java.util.List r1 = kotlin.collections.CollectionsKt.emptyList()
                boolean r2 = kotlin.Result.m4405isFailureimpl(r0)
                if (r2 == 0) goto L10a
                r0 = r1
            L10a:
                java.util.List r0 = (java.util.List) r0
                return r0
        }
    }


    public static /* synthetic */ void $r8$lambda$r_c9c0fSiI6Pp8Snz5WH_Do7MGg(vea.raceremote.control.CarDiscovery r0, kotlin.jvm.functions.Function1 r1, java.util.List r2, long r3) {
            search$lambda$8(r0, r1, r2, r3)
            return
    }

    static {
            vea.raceremote.control.CarDiscovery$Companion r0 = new vea.raceremote.control.CarDiscovery$Companion
            r1 = 0
            r0.<init>(r1)
            vea.raceremote.control.CarDiscovery.Companion = r0
            vea.raceremote.control.LiveLiterals$CarDiscoveryKt r0 = vea.raceremote.control.LiveLiterals$CarDiscoveryKt.INSTANCE
            int r0 = r0.m6270Int$classCarDiscovery()
            vea.raceremote.control.CarDiscovery.$stable = r0
            return
    }

    public CarDiscovery() {
            r7 = this;
            r7.<init>()
            java.util.concurrent.ExecutorService r0 = java.util.concurrent.Executors.newSingleThreadExecutor()
            r7.worker = r0
            vea.raceremote.control.DiscoveryState r0 = new vea.raceremote.control.DiscoveryState
            r2 = 0
            r3 = 0
            r4 = 0
            r5 = 7
            r6 = 0
            r1 = r0
            r1.<init>(r2, r3, r4, r5, r6)
            kotlinx.coroutines.flow.MutableStateFlow r0 = kotlinx.coroutines.flow.StateFlowKt.MutableStateFlow(r0)
            r7.mutableState = r0
            kotlinx.coroutines.flow.StateFlow r0 = kotlinx.coroutines.flow.FlowKt.asStateFlow(r0)
            r7.state = r0
            return
    }

    public static /* synthetic */ void search$default(vea.raceremote.control.CarDiscovery r0, java.util.List r1, kotlin.jvm.functions.Function1 r2, int r3, java.lang.Object r4) {
            r4 = r3 & 1
            if (r4 == 0) goto La
            vea.raceremote.control.CarDiscovery$Companion r1 = vea.raceremote.control.CarDiscovery.Companion
            java.util.List r1 = r1.broadcastTargets()
        La:
            r3 = r3 & 2
            if (r3 == 0) goto L12
            vea.raceremote.control.CarDiscovery$search$1 r2 = vea.raceremote.control.CarDiscovery.AnonymousClass1.INSTANCE
            kotlin.jvm.functions.Function1 r2 = (kotlin.jvm.functions.Function1) r2
        L12:
            r0.search(r1, r2)
            return
    }

    private static final void search$lambda$8(vea.raceremote.control.CarDiscovery r26, kotlin.jvm.functions.Function1 r27, java.util.List r28, long r29) {
            r1 = r26
            r2 = r27
            java.lang.String r0 = "this$0"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r1, r0)
            java.lang.String r0 = "$configure"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.String r0 = "$targets"
            r3 = r28
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            java.util.LinkedHashMap r0 = new java.util.LinkedHashMap
            r0.<init>()
            r4 = r0
            r5 = 0
            java.net.DatagramSocket r0 = new java.net.DatagramSocket     // Catch: java.lang.Throwable -> L32b java.lang.Exception -> L32d
            r0.<init>()     // Catch: java.lang.Throwable -> L32b java.lang.Exception -> L32d
            r6 = r0
            java.io.Closeable r6 = (java.io.Closeable) r6     // Catch: java.lang.Throwable -> L32b java.lang.Exception -> L32d
            r0 = r6
            java.net.DatagramSocket r0 = (java.net.DatagramSocket) r0     // Catch: java.lang.Throwable -> L321
            r7 = r0
            r8 = 0
            monitor-enter(r26)     // Catch: java.lang.Throwable -> L321
            r0 = 0
            long r9 = r1.generation     // Catch: java.lang.Throwable -> L319
            int r9 = (r9 > r29 ? 1 : (r9 == r29 ? 0 : -1))
            if (r9 == 0) goto L49
            monitor-exit(r26)     // Catch: java.lang.Throwable -> L44
            kotlin.io.CloseableKt.closeFinally(r6, r5)     // Catch: java.lang.Throwable -> L32b java.lang.Exception -> L32d
            monitor-enter(r26)
            r0 = 0
            long r6 = r1.generation
            int r6 = (r6 > r29 ? 1 : (r6 == r29 ? 0 : -1))
            if (r6 != 0) goto L40
            r1.socket = r5
        L40:
            kotlin.Unit r0 = kotlin.Unit.INSTANCE
            monitor-exit(r26)
            return
        L44:
            r0 = move-exception
            r2 = r0
            r5 = r6
            goto L324
        L49:
            r1.socket = r7     // Catch: java.lang.Throwable -> L319
            kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L319
            monitor-exit(r26)     // Catch: java.lang.Throwable -> L321
            r2.invoke(r7)     // Catch: java.lang.Throwable -> L321
            vea.raceremote.control.LiveLiterals$CarDiscoveryKt r0 = vea.raceremote.control.LiveLiterals$CarDiscoveryKt.INSTANCE     // Catch: java.lang.Throwable -> L321
            boolean r0 = r0.m6252Boolean$arg0$callsetBroadcast$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery()     // Catch: java.lang.Throwable -> L321
            r7.setBroadcast(r0)     // Catch: java.lang.Throwable -> L321
            vea.raceremote.control.LiveLiterals$CarDiscoveryKt r0 = vea.raceremote.control.LiveLiterals$CarDiscoveryKt.INSTANCE     // Catch: java.lang.Throwable -> L321
            int r0 = r0.m6263Int$arg0$callsetSoTimeout$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery()     // Catch: java.lang.Throwable -> L321
            r7.setSoTimeout(r0)     // Catch: java.lang.Throwable -> L321
            r9 = 0
        L66:
            java.security.SecureRandom r0 = new java.security.SecureRandom     // Catch: java.lang.Throwable -> L321
            r0.<init>()     // Catch: java.lang.Throwable -> L321
            int r0 = r0.nextInt()     // Catch: java.lang.Throwable -> L321
            long r11 = (long) r0     // Catch: java.lang.Throwable -> L321
            vea.raceremote.control.LiveLiterals$CarDiscoveryKt r0 = vea.raceremote.control.LiveLiterals$CarDiscoveryKt.INSTANCE     // Catch: java.lang.Throwable -> L321
            long r13 = r0.m6272Long$arg0$calland$setnonce$body$loop$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery()     // Catch: java.lang.Throwable -> L321
            long r9 = r11 & r13
            vea.raceremote.control.LiveLiterals$CarDiscoveryKt r0 = vea.raceremote.control.LiveLiterals$CarDiscoveryKt.INSTANCE     // Catch: java.lang.Throwable -> L321
            long r11 = r0.m6273Long$arg1$callEQEQ$cond$loop$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery()     // Catch: java.lang.Throwable -> L321
            int r0 = (r9 > r11 ? 1 : (r9 == r11 ? 0 : -1))
            if (r0 == 0) goto L30f
            r0 = 2
            byte[][] r0 = new byte[r0][]     // Catch: java.lang.Throwable -> L321
            vea.raceremote.control.DiscoveryPacket r15 = vea.raceremote.control.DiscoveryPacket.INSTANCE     // Catch: java.lang.Throwable -> L321
            r18 = 0
            r19 = 2
            r20 = 0
            r16 = r9
            byte[] r11 = vea.raceremote.control.DiscoveryPacket.query$default(r15, r16, r18, r19, r20)     // Catch: java.lang.Throwable -> L321
            r12 = 0
            r0[r12] = r11     // Catch: java.lang.Throwable -> L321
            vea.raceremote.control.DiscoveryPacket r11 = vea.raceremote.control.DiscoveryPacket.INSTANCE     // Catch: java.lang.Throwable -> L321
            vea.raceremote.control.LiveLiterals$CarDiscoveryKt r12 = vea.raceremote.control.LiveLiterals$CarDiscoveryKt.INSTANCE     // Catch: java.lang.Throwable -> L321
            int r12 = r12.m6268Int$arg1$callquery$1$vararg$arg0$calllistOf$valqueries$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery()     // Catch: java.lang.Throwable -> L321
            byte[] r11 = r11.query(r9, r12)     // Catch: java.lang.Throwable -> L321
            r12 = 1
            r0[r12] = r11     // Catch: java.lang.Throwable -> L321
            java.lang.Object[] r0 = (java.lang.Object[]) r0     // Catch: java.lang.Throwable -> L321
            java.util.List r0 = kotlin.collections.CollectionsKt.listOf(r0)     // Catch: java.lang.Throwable -> L321
            r11 = r0
            long r12 = java.lang.System.nanoTime()     // Catch: java.lang.Throwable -> L321
            vea.raceremote.control.LiveLiterals$CarDiscoveryKt r0 = vea.raceremote.control.LiveLiterals$CarDiscoveryKt.INSTANCE     // Catch: java.lang.Throwable -> L321
            long r14 = r0.m6274Long$vallastSend$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery()     // Catch: java.lang.Throwable -> L321
        Lb6:
            long r16 = java.lang.System.nanoTime()     // Catch: java.lang.Throwable -> L321
            long r16 = r16 - r12
            r18 = 3000000000(0xb2d05e00, double:1.4821969375E-314)
            int r0 = (r16 > r18 ? 1 : (r16 == r18 ? 0 : -1))
            if (r0 >= 0) goto L2af
            monitor-enter(r26)     // Catch: java.lang.Throwable -> L321
            r0 = 0
            r16 = r6
            long r5 = r1.generation     // Catch: java.lang.Throwable -> L2a4
            int r5 = (r5 > r29 ? 1 : (r5 == r29 ? 0 : -1))
            if (r5 == 0) goto Le7
            monitor-exit(r26)     // Catch: java.lang.Throwable -> Le2
            r5 = r16
            r6 = 0
            kotlin.io.CloseableKt.closeFinally(r5, r6)     // Catch: java.lang.Throwable -> L32b java.lang.Exception -> L32d
            monitor-enter(r26)
            r0 = 0
            long r7 = r1.generation
            int r5 = (r7 > r29 ? 1 : (r7 == r29 ? 0 : -1))
            if (r5 != 0) goto L40
            r1.socket = r6
            goto L40
        Le2:
            r0 = move-exception
            r5 = r16
            goto L323
        Le7:
            r5 = r16
            kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L29c
            monitor-exit(r26)     // Catch: java.lang.Throwable -> L31f
            long r18 = java.lang.System.nanoTime()     // Catch: java.lang.Throwable -> L31f
            long r18 = r18 - r12
            vea.raceremote.control.LiveLiterals$CarDiscoveryKt r0 = vea.raceremote.control.LiveLiterals$CarDiscoveryKt.INSTANCE     // Catch: java.lang.Throwable -> L31f
            int r0 = r0.m6262Int$arg0$calldiv$valelapsed$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery()     // Catch: java.lang.Throwable -> L31f
            long r2 = (long) r0     // Catch: java.lang.Throwable -> L31f
            long r18 = r18 / r2
            r2 = r18
            long r18 = r2 - r14
            vea.raceremote.control.LiveLiterals$CarDiscoveryKt r0 = vea.raceremote.control.LiveLiterals$CarDiscoveryKt.INSTANCE     // Catch: java.lang.Throwable -> L31f
            int r0 = r0.m6260Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery()     // Catch: java.lang.Throwable -> L31f
            r20 = r12
            long r12 = (long) r0     // Catch: java.lang.Throwable -> L31f
            int r0 = (r18 > r12 ? 1 : (r18 == r12 ? 0 : -1))
            if (r0 < 0) goto L179
            java.util.Iterator r12 = r28.iterator()     // Catch: java.lang.Throwable -> L31f
        L110:
            boolean r0 = r12.hasNext()     // Catch: java.lang.Throwable -> L31f
            if (r0 == 0) goto L172
            java.lang.Object r0 = r12.next()     // Catch: java.lang.Throwable -> L31f
            java.net.InetAddress r0 = (java.net.InetAddress) r0     // Catch: java.lang.Throwable -> L31f
            r13 = r0
            java.util.Iterator r16 = r11.iterator()     // Catch: java.lang.Throwable -> L31f
        L121:
            boolean r0 = r16.hasNext()     // Catch: java.lang.Throwable -> L31f
            if (r0 == 0) goto L16d
            java.lang.Object r0 = r16.next()     // Catch: java.lang.Throwable -> L31f
            byte[] r0 = (byte[]) r0     // Catch: java.lang.Throwable -> L31f
            r18 = r0
            kotlin.Result$Companion r0 = kotlin.Result.Companion     // Catch: java.lang.Throwable -> L158
            r0 = r26
            r19 = 0
            java.net.DatagramPacket r6 = new java.net.DatagramPacket     // Catch: java.lang.Throwable -> L158
            r22 = r8
            r8 = r18
            r18 = r0
            int r0 = r8.length     // Catch: java.lang.Throwable -> L154
            r23 = r11
            r11 = 3333(0xd05, float:4.67E-42)
            r6.<init>(r8, r0, r13, r11)     // Catch: java.lang.Throwable -> L152
            r7.send(r6)     // Catch: java.lang.Throwable -> L152
            kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L152
            kotlin.Result.m4399constructorimpl(r0)     // Catch: java.lang.Throwable -> L152
            r8 = r22
            r11 = r23
            goto L121
        L152:
            r0 = move-exception
            goto L15f
        L154:
            r0 = move-exception
            r23 = r11
            goto L15f
        L158:
            r0 = move-exception
            r22 = r8
            r23 = r11
            r8 = r18
        L15f:
            kotlin.Result$Companion r6 = kotlin.Result.Companion     // Catch: java.lang.Throwable -> L31f
            java.lang.Object r0 = kotlin.ResultKt.createFailure(r0)     // Catch: java.lang.Throwable -> L31f
            kotlin.Result.m4399constructorimpl(r0)     // Catch: java.lang.Throwable -> L31f
            r8 = r22
            r11 = r23
            goto L121
        L16d:
            r22 = r8
            r23 = r11
            goto L110
        L172:
            r22 = r8
            r23 = r11
            r11 = r2
            r14 = r11
            goto L17d
        L179:
            r22 = r8
            r23 = r11
        L17d:
            java.net.DatagramPacket r0 = new java.net.DatagramPacket     // Catch: java.lang.Throwable -> L31f
            vea.raceremote.control.LiveLiterals$CarDiscoveryKt r6 = vea.raceremote.control.LiveLiterals$CarDiscoveryKt.INSTANCE     // Catch: java.lang.Throwable -> L31f
            int r6 = r6.m6261Int$arg0$call$init$$arg0$call$init$$valpacket$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery()     // Catch: java.lang.Throwable -> L31f
            byte[] r6 = new byte[r6]     // Catch: java.lang.Throwable -> L31f
            vea.raceremote.control.LiveLiterals$CarDiscoveryKt r8 = vea.raceremote.control.LiveLiterals$CarDiscoveryKt.INSTANCE     // Catch: java.lang.Throwable -> L31f
            int r8 = r8.m6266Int$arg1$call$init$$valpacket$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery()     // Catch: java.lang.Throwable -> L31f
            r0.<init>(r6, r8)     // Catch: java.lang.Throwable -> L31f
            r6 = r0
            r7.receive(r6)     // Catch: java.net.SocketTimeoutException -> L289 java.lang.Throwable -> L31f
            int r0 = r6.getPort()     // Catch: java.lang.Throwable -> L31f
            r8 = 3333(0xd05, float:4.67E-42)
            if (r0 != r8) goto L286
            vea.raceremote.control.CarDiscovery$Companion r0 = vea.raceremote.control.CarDiscovery.Companion     // Catch: java.lang.Throwable -> L31f
            java.net.InetAddress r8 = r6.getAddress()     // Catch: java.lang.Throwable -> L31f
            java.lang.String r11 = "packet.address"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r11)     // Catch: java.lang.Throwable -> L31f
            boolean r0 = vea.raceremote.control.CarDiscovery.Companion.access$localAddress(r0, r8)     // Catch: java.lang.Throwable -> L31f
            if (r0 != 0) goto L1af
            goto L28e
        L1af:
            vea.raceremote.control.DiscoveryPacket r0 = vea.raceremote.control.DiscoveryPacket.INSTANCE     // Catch: java.lang.Throwable -> L31f
            byte[] r8 = r6.getData()     // Catch: java.lang.Throwable -> L31f
            java.lang.String r11 = "packet.data"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r11)     // Catch: java.lang.Throwable -> L31f
            int r11 = r6.getLength()     // Catch: java.lang.Throwable -> L31f
            byte[] r8 = java.util.Arrays.copyOf(r8, r11)     // Catch: java.lang.Throwable -> L31f
            java.lang.String r11 = "copyOf(this, newSize)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r11)     // Catch: java.lang.Throwable -> L31f
            java.net.InetAddress r11 = r6.getAddress()     // Catch: java.lang.Throwable -> L31f
            java.lang.String r11 = r11.getHostAddress()     // Catch: java.lang.Throwable -> L31f
            if (r11 != 0) goto L1d3
        L1d1:
            goto L28e
        L1d3:
            java.lang.String r12 = "packet.address.hostAddress ?: continue"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r11, r12)     // Catch: java.lang.Throwable -> L31f
            vea.raceremote.control.DiscoveredCar r0 = r0.reply(r8, r9, r11)     // Catch: java.lang.Throwable -> L31f
            if (r0 != 0) goto L1df
            goto L1d1
        L1df:
            r8 = r0
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L31f
            r0.<init>()     // Catch: java.lang.Throwable -> L31f
            long r11 = r8.getChipId()     // Catch: java.lang.Throwable -> L31f
            java.lang.StringBuilder r0 = r0.append(r11)     // Catch: java.lang.Throwable -> L31f
            vea.raceremote.control.LiveLiterals$CarDiscoveryKt r11 = vea.raceremote.control.LiveLiterals$CarDiscoveryKt.INSTANCE     // Catch: java.lang.Throwable -> L31f
            java.lang.String r11 = r11.m6277String$1$str$valkey$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery()     // Catch: java.lang.Throwable -> L31f
            java.lang.StringBuilder r0 = r0.append(r11)     // Catch: java.lang.Throwable -> L31f
            java.lang.String r11 = r8.getHost()     // Catch: java.lang.Throwable -> L31f
            java.lang.StringBuilder r0 = r0.append(r11)     // Catch: java.lang.Throwable -> L31f
            java.lang.String r0 = r0.toString()     // Catch: java.lang.Throwable -> L31f
            r11 = r0
            java.lang.Object r0 = r4.get(r11)     // Catch: java.lang.Throwable -> L31f
            vea.raceremote.control.DiscoveredCar r0 = (vea.raceremote.control.DiscoveredCar) r0     // Catch: java.lang.Throwable -> L31f
            if (r0 == 0) goto L211
            int r0 = r0.getDiscoveryVersion()     // Catch: java.lang.Throwable -> L31f
            goto L217
        L211:
            vea.raceremote.control.LiveLiterals$CarDiscoveryKt r0 = vea.raceremote.control.LiveLiterals$CarDiscoveryKt.INSTANCE     // Catch: java.lang.Throwable -> L31f
            int r0 = r0.m6269Int$branch$when$arg0$callgreater$cond$if2$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery()     // Catch: java.lang.Throwable -> L31f
        L217:
            int r12 = r8.getDiscoveryVersion()     // Catch: java.lang.Throwable -> L31f
            if (r0 > r12) goto L283
            r0 = r4
            java.util.Map r0 = (java.util.Map) r0     // Catch: java.lang.Throwable -> L31f
            r0.put(r11, r8)     // Catch: java.lang.Throwable -> L31f
            int r0 = r4.size()     // Catch: java.lang.Throwable -> L31f
            vea.raceremote.control.LiveLiterals$CarDiscoveryKt r12 = vea.raceremote.control.LiveLiterals$CarDiscoveryKt.INSTANCE     // Catch: java.lang.Throwable -> L31f
            int r12 = r12.m6267Int$arg1$callgreater$cond$if3$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery()     // Catch: java.lang.Throwable -> L31f
            if (r0 <= r12) goto L241
            java.util.Set r0 = r4.keySet()     // Catch: java.lang.Throwable -> L31f
            java.lang.String r12 = "found.keys"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r12)     // Catch: java.lang.Throwable -> L31f
            java.lang.Iterable r0 = (java.lang.Iterable) r0     // Catch: java.lang.Throwable -> L31f
            java.lang.Object r0 = kotlin.collections.CollectionsKt.first(r0)     // Catch: java.lang.Throwable -> L31f
            r4.remove(r0)     // Catch: java.lang.Throwable -> L31f
        L241:
            monitor-enter(r26)     // Catch: java.lang.Throwable -> L31f
            r0 = 0
            long r12 = r1.generation     // Catch: java.lang.Throwable -> L27e
            int r12 = (r12 > r29 ? 1 : (r12 == r29 ? 0 : -1))
            if (r12 != 0) goto L273
            kotlinx.coroutines.flow.MutableStateFlow<vea.raceremote.control.DiscoveryState> r12 = r1.mutableState     // Catch: java.lang.Throwable -> L27e
            vea.raceremote.control.DiscoveryState r13 = new vea.raceremote.control.DiscoveryState     // Catch: java.lang.Throwable -> L27e
            vea.raceremote.control.LiveLiterals$CarDiscoveryKt r16 = vea.raceremote.control.LiveLiterals$CarDiscoveryKt.INSTANCE     // Catch: java.lang.Throwable -> L27e
            r18 = r0
            boolean r0 = r16.m6249Boolean$arg0$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery()     // Catch: java.lang.Throwable -> L27e
            r24 = r2
            java.util.Collection r2 = r4.values()     // Catch: java.lang.Throwable -> L27c
            java.lang.String r3 = "found.values"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, r3)     // Catch: java.lang.Throwable -> L27c
            java.lang.Iterable r2 = (java.lang.Iterable) r2     // Catch: java.lang.Throwable -> L27c
            java.util.List r2 = kotlin.collections.CollectionsKt.toList(r2)     // Catch: java.lang.Throwable -> L27c
            vea.raceremote.control.LiveLiterals$CarDiscoveryKt r3 = vea.raceremote.control.LiveLiterals$CarDiscoveryKt.INSTANCE     // Catch: java.lang.Throwable -> L27c
            java.lang.String r3 = r3.m6284String$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$body$loop1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery()     // Catch: java.lang.Throwable -> L27c
            r13.<init>(r0, r2, r3)     // Catch: java.lang.Throwable -> L27c
            r12.setValue(r13)     // Catch: java.lang.Throwable -> L27c
            goto L277
        L273:
            r18 = r0
            r24 = r2
        L277:
            kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L27c
            monitor-exit(r26)     // Catch: java.lang.Throwable -> L31f
            goto L28e
        L27c:
            r0 = move-exception
            goto L281
        L27e:
            r0 = move-exception
            r24 = r2
        L281:
            monitor-exit(r26)     // Catch: java.lang.Throwable -> L31f
            throw r0     // Catch: java.lang.Throwable -> L31f
        L283:
            r24 = r2
            goto L28e
        L286:
            r24 = r2
            goto L28e
        L289:
            r0 = move-exception
            r24 = r2
            r2 = r0
            r0 = r2
        L28e:
            r2 = r27
            r3 = r28
            r6 = r5
            r12 = r20
            r8 = r22
            r11 = r23
            r5 = 0
            goto Lb6
        L29c:
            r0 = move-exception
            r22 = r8
            r23 = r11
            r20 = r12
            goto L2ad
        L2a4:
            r0 = move-exception
            r22 = r8
            r23 = r11
            r20 = r12
            r5 = r16
        L2ad:
            monitor-exit(r26)     // Catch: java.lang.Throwable -> L31f
            throw r0     // Catch: java.lang.Throwable -> L31f
        L2af:
            r5 = r6
            r22 = r8
            r23 = r11
            r20 = r12
            monitor-enter(r26)     // Catch: java.lang.Throwable -> L31f
            r0 = 0
            long r2 = r1.generation     // Catch: java.lang.Throwable -> L30c
            int r2 = (r2 > r29 ? 1 : (r2 == r29 ? 0 : -1))
            if (r2 != 0) goto L2f0
            kotlinx.coroutines.flow.MutableStateFlow<vea.raceremote.control.DiscoveryState> r2 = r1.mutableState     // Catch: java.lang.Throwable -> L30c
            vea.raceremote.control.DiscoveryState r3 = new vea.raceremote.control.DiscoveryState     // Catch: java.lang.Throwable -> L30c
            vea.raceremote.control.LiveLiterals$CarDiscoveryKt r6 = vea.raceremote.control.LiveLiterals$CarDiscoveryKt.INSTANCE     // Catch: java.lang.Throwable -> L30c
            boolean r6 = r6.m6250Boolean$arg0$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery()     // Catch: java.lang.Throwable -> L30c
            java.util.Collection r8 = r4.values()     // Catch: java.lang.Throwable -> L30c
            java.lang.String r11 = "found.values"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r11)     // Catch: java.lang.Throwable -> L30c
            java.lang.Iterable r8 = (java.lang.Iterable) r8     // Catch: java.lang.Throwable -> L30c
            java.util.List r8 = kotlin.collections.CollectionsKt.toList(r8)     // Catch: java.lang.Throwable -> L30c
            boolean r11 = r4.isEmpty()     // Catch: java.lang.Throwable -> L30c
            if (r11 == 0) goto L2e4
            vea.raceremote.control.LiveLiterals$CarDiscoveryKt r11 = vea.raceremote.control.LiveLiterals$CarDiscoveryKt.INSTANCE     // Catch: java.lang.Throwable -> L30c
            java.lang.String r11 = r11.m6287String$branch$if$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery()     // Catch: java.lang.Throwable -> L30c
            goto L2ea
        L2e4:
            vea.raceremote.control.LiveLiterals$CarDiscoveryKt r11 = vea.raceremote.control.LiveLiterals$CarDiscoveryKt.INSTANCE     // Catch: java.lang.Throwable -> L30c
            java.lang.String r11 = r11.m6288String$else$if$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized1$fun$anonymous$$arg0$calluse$try$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery()     // Catch: java.lang.Throwable -> L30c
        L2ea:
            r3.<init>(r6, r8, r11)     // Catch: java.lang.Throwable -> L30c
            r2.setValue(r3)     // Catch: java.lang.Throwable -> L30c
        L2f0:
            kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L30c
            monitor-exit(r26)     // Catch: java.lang.Throwable -> L31f
            kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L31f
            r2 = 0
            kotlin.io.CloseableKt.closeFinally(r5, r2)     // Catch: java.lang.Throwable -> L32b java.lang.Exception -> L32d
            monitor-enter(r26)
            r0 = 0
            long r2 = r1.generation     // Catch: java.lang.Throwable -> L309
            int r2 = (r2 > r29 ? 1 : (r2 == r29 ? 0 : -1))
            if (r2 != 0) goto L306
            r2 = 0
            r1.socket = r2     // Catch: java.lang.Throwable -> L309
        L306:
            kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L309
            goto L36d
        L309:
            r0 = move-exception
            monitor-exit(r26)
            throw r0
        L30c:
            r0 = move-exception
            monitor-exit(r26)     // Catch: java.lang.Throwable -> L31f
            throw r0     // Catch: java.lang.Throwable -> L31f
        L30f:
            r5 = r6
            r22 = r8
            r2 = r27
            r3 = r28
            r5 = 0
            goto L66
        L319:
            r0 = move-exception
            r5 = r6
            r22 = r8
            monitor-exit(r26)     // Catch: java.lang.Throwable -> L31f
            throw r0     // Catch: java.lang.Throwable -> L31f
        L31f:
            r0 = move-exception
            goto L323
        L321:
            r0 = move-exception
            r5 = r6
        L323:
            r2 = r0
        L324:
            throw r2     // Catch: java.lang.Throwable -> L325
        L325:
            r0 = move-exception
            r3 = r0
            kotlin.io.CloseableKt.closeFinally(r5, r2)     // Catch: java.lang.Throwable -> L32b java.lang.Exception -> L32d
            throw r3     // Catch: java.lang.Throwable -> L32b java.lang.Exception -> L32d
        L32b:
            r0 = move-exception
            goto L375
        L32d:
            r0 = move-exception
            r2 = r0
            monitor-enter(r26)     // Catch: java.lang.Throwable -> L32b
            r0 = 0
            long r5 = r1.generation     // Catch: java.lang.Throwable -> L372
            int r3 = (r5 > r29 ? 1 : (r5 == r29 ? 0 : -1))
            if (r3 != 0) goto L35c
            kotlinx.coroutines.flow.MutableStateFlow<vea.raceremote.control.DiscoveryState> r3 = r1.mutableState     // Catch: java.lang.Throwable -> L372
            vea.raceremote.control.DiscoveryState r5 = new vea.raceremote.control.DiscoveryState     // Catch: java.lang.Throwable -> L372
            vea.raceremote.control.LiveLiterals$CarDiscoveryKt r6 = vea.raceremote.control.LiveLiterals$CarDiscoveryKt.INSTANCE     // Catch: java.lang.Throwable -> L372
            boolean r6 = r6.m6248Boolean$arg0$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized$catch$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery()     // Catch: java.lang.Throwable -> L372
            java.util.Collection r7 = r4.values()     // Catch: java.lang.Throwable -> L372
            java.lang.String r8 = "found.values"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r7, r8)     // Catch: java.lang.Throwable -> L372
            java.lang.Iterable r7 = (java.lang.Iterable) r7     // Catch: java.lang.Throwable -> L372
            java.util.List r7 = kotlin.collections.CollectionsKt.toList(r7)     // Catch: java.lang.Throwable -> L372
            vea.raceremote.control.LiveLiterals$CarDiscoveryKt r8 = vea.raceremote.control.LiveLiterals$CarDiscoveryKt.INSTANCE     // Catch: java.lang.Throwable -> L372
            java.lang.String r8 = r8.m6283String$arg2$call$init$$arg0$call$setvalue$$branch$if$fun$anonymous$$arg1$callsynchronized$catch$fun$anonymous$$arg0$callexecute$funsearch$classCarDiscovery()     // Catch: java.lang.Throwable -> L372
            r5.<init>(r6, r7, r8)     // Catch: java.lang.Throwable -> L372
            r3.setValue(r5)     // Catch: java.lang.Throwable -> L372
        L35c:
            kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L372
            monitor-exit(r26)     // Catch: java.lang.Throwable -> L32b
            monitor-enter(r26)
            r0 = 0
            long r2 = r1.generation     // Catch: java.lang.Throwable -> L36f
            int r2 = (r2 > r29 ? 1 : (r2 == r29 ? 0 : -1))
            if (r2 != 0) goto L36b
            r2 = 0
            r1.socket = r2     // Catch: java.lang.Throwable -> L36f
        L36b:
            kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L36f
        L36d:
            monitor-exit(r26)
            return
        L36f:
            r0 = move-exception
            monitor-exit(r26)
            throw r0
        L372:
            r0 = move-exception
            monitor-exit(r26)     // Catch: java.lang.Throwable -> L32b
            throw r0     // Catch: java.lang.Throwable -> L32b
        L375:
            monitor-enter(r26)
            r2 = 0
            long r5 = r1.generation     // Catch: java.lang.Throwable -> L384
            int r3 = (r5 > r29 ? 1 : (r5 == r29 ? 0 : -1))
            if (r3 != 0) goto L380
            r3 = 0
            r1.socket = r3     // Catch: java.lang.Throwable -> L384
        L380:
            kotlin.Unit r2 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L384
            monitor-exit(r26)
            throw r0
        L384:
            r0 = move-exception
            monitor-exit(r26)
            throw r0
    }

    public final synchronized void cancel() {
            r8 = this;
            monitor-enter(r8)
            long r0 = r8.generation     // Catch: java.lang.Throwable -> L24
            r2 = 1
            long r0 = r0 + r2
            r8.generation = r0     // Catch: java.lang.Throwable -> L24
            java.net.DatagramSocket r0 = r8.socket     // Catch: java.lang.Throwable -> L24
            if (r0 == 0) goto Lf
            r0.close()     // Catch: java.lang.Throwable -> L24
        Lf:
            r0 = 0
            r8.socket = r0     // Catch: java.lang.Throwable -> L24
            kotlinx.coroutines.flow.MutableStateFlow<vea.raceremote.control.DiscoveryState> r0 = r8.mutableState     // Catch: java.lang.Throwable -> L24
            vea.raceremote.control.DiscoveryState r7 = new vea.raceremote.control.DiscoveryState     // Catch: java.lang.Throwable -> L24
            r2 = 0
            r3 = 0
            r4 = 0
            r5 = 7
            r6 = 0
            r1 = r7
            r1.<init>(r2, r3, r4, r5, r6)     // Catch: java.lang.Throwable -> L24
            r0.setValue(r7)     // Catch: java.lang.Throwable -> L24
            monitor-exit(r8)
            return
        L24:
            r0 = move-exception
            monitor-exit(r8)
            throw r0
    }

    public final synchronized void close() {
            r1 = this;
            monitor-enter(r1)
            r1.cancel()     // Catch: java.lang.Throwable -> Lb
            java.util.concurrent.ExecutorService r0 = r1.worker     // Catch: java.lang.Throwable -> Lb
            r0.shutdownNow()     // Catch: java.lang.Throwable -> Lb
            monitor-exit(r1)
            return
        Lb:
            r0 = move-exception
            monitor-exit(r1)
            throw r0
    }

    public final kotlinx.coroutines.flow.StateFlow<vea.raceremote.control.DiscoveryState> getState() {
            r1 = this;
            kotlinx.coroutines.flow.StateFlow<vea.raceremote.control.DiscoveryState> r0 = r1.state
            return r0
    }

    public final synchronized void search(java.util.List<? extends java.net.InetAddress> r13, kotlin.jvm.functions.Function1<? super java.net.DatagramSocket, kotlin.Unit> r14) {
            r12 = this;
            monitor-enter(r12)
            java.lang.String r0 = "targets"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r13, r0)     // Catch: java.lang.Throwable -> L57
            java.lang.String r0 = "configure"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r14, r0)     // Catch: java.lang.Throwable -> L57
            r12.cancel()     // Catch: java.lang.Throwable -> L57
            boolean r0 = r13.isEmpty()     // Catch: java.lang.Throwable -> L57
            if (r0 == 0) goto L2b
            kotlinx.coroutines.flow.MutableStateFlow<vea.raceremote.control.DiscoveryState> r0 = r12.mutableState     // Catch: java.lang.Throwable -> L57
            vea.raceremote.control.DiscoveryState r7 = new vea.raceremote.control.DiscoveryState     // Catch: java.lang.Throwable -> L57
            r2 = 0
            r3 = 0
            vea.raceremote.control.LiveLiterals$CarDiscoveryKt r1 = vea.raceremote.control.LiveLiterals$CarDiscoveryKt.INSTANCE     // Catch: java.lang.Throwable -> L57
            java.lang.String r4 = r1.m6285String$arg2$call$init$$arg0$call$setvalue$$branch$if$funsearch$classCarDiscovery()     // Catch: java.lang.Throwable -> L57
            r5 = 3
            r6 = 0
            r1 = r7
            r1.<init>(r2, r3, r4, r5, r6)     // Catch: java.lang.Throwable -> L57
            r0.setValue(r7)     // Catch: java.lang.Throwable -> L57
            monitor-exit(r12)
            return
        L2b:
            long r4 = r12.generation     // Catch: java.lang.Throwable -> L57
            kotlinx.coroutines.flow.MutableStateFlow<vea.raceremote.control.DiscoveryState> r0 = r12.mutableState     // Catch: java.lang.Throwable -> L57
            vea.raceremote.control.DiscoveryState r1 = new vea.raceremote.control.DiscoveryState     // Catch: java.lang.Throwable -> L57
            vea.raceremote.control.LiveLiterals$CarDiscoveryKt r2 = vea.raceremote.control.LiveLiterals$CarDiscoveryKt.INSTANCE     // Catch: java.lang.Throwable -> L57
            boolean r7 = r2.m6251Boolean$arg0$call$init$$arg0$call$setvalue$$funsearch$classCarDiscovery()     // Catch: java.lang.Throwable -> L57
            r8 = 0
            vea.raceremote.control.LiveLiterals$CarDiscoveryKt r2 = vea.raceremote.control.LiveLiterals$CarDiscoveryKt.INSTANCE     // Catch: java.lang.Throwable -> L57
            java.lang.String r9 = r2.m6286String$arg2$call$init$$arg0$call$setvalue$$funsearch$classCarDiscovery()     // Catch: java.lang.Throwable -> L57
            r10 = 2
            r11 = 0
            r6 = r1
            r6.<init>(r7, r8, r9, r10, r11)     // Catch: java.lang.Throwable -> L57
            r0.setValue(r1)     // Catch: java.lang.Throwable -> L57
            java.util.concurrent.ExecutorService r6 = r12.worker     // Catch: java.lang.Throwable -> L57
            vea.raceremote.control.CarDiscovery$$ExternalSyntheticLambda0 r7 = new vea.raceremote.control.CarDiscovery$$ExternalSyntheticLambda0     // Catch: java.lang.Throwable -> L57
            r0 = r7
            r1 = r12
            r2 = r14
            r3 = r13
            r0.<init>(r1, r2, r3, r4)     // Catch: java.lang.Throwable -> L57
            r6.execute(r7)     // Catch: java.lang.Throwable -> L57
            monitor-exit(r12)
            return
        L57:
            r13 = move-exception
            monitor-exit(r12)
            throw r13
    }
}
