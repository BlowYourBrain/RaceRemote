package vea.raceremote.control;

/* JADX INFO: compiled from: CarControlConnection.kt */
/* JADX INFO: loaded from: classes4.dex */
@kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0002\b\f\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0087\b\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bJ\t\u0010\u000f\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0010\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0007HÆ\u0003J'\u0010\u0012\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0007HÆ\u0001J\u0013\u0010\u0013\u001a\u00020\u00142\b\u0010\u0015\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0016\u001a\u00020\u0005HÖ\u0001J\t\u0010\u0017\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000e¨\u0006\u0018"}, d2 = {"Lvea/raceremote/control/ControlEndpoint;", "", "transport", "", "port", "", "chipId", "", "(Ljava/lang/String;IJ)V", "getChipId", "()J", "getPort", "()I", "getTransport", "()Ljava/lang/String;", "component1", "component2", "component3", "copy", "equals", "", "other", "hashCode", "toString", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class ControlEndpoint {
    public static final int $stable = 0;
    private final long chipId;
    private final int port;
    private final java.lang.String transport;

    static {
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r0 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE
            int r0 = r0.m6136Int$classControlEndpoint()
            vea.raceremote.control.ControlEndpoint.$stable = r0
            return
    }

    public ControlEndpoint(java.lang.String r2, int r3, long r4) {
            r1 = this;
            java.lang.String r0 = "transport"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            r1.<init>()
            r1.transport = r2
            r1.port = r3
            r1.chipId = r4
            return
    }

    public static /* synthetic */ vea.raceremote.control.ControlEndpoint copy$default(vea.raceremote.control.ControlEndpoint r0, java.lang.String r1, int r2, long r3, int r5, java.lang.Object r6) {
            r6 = r5 & 1
            if (r6 == 0) goto L6
            java.lang.String r1 = r0.transport
        L6:
            r6 = r5 & 2
            if (r6 == 0) goto Lc
            int r2 = r0.port
        Lc:
            r5 = r5 & 4
            if (r5 == 0) goto L12
            long r3 = r0.chipId
        L12:
            vea.raceremote.control.ControlEndpoint r0 = r0.copy(r1, r2, r3)
            return r0
    }

    public final java.lang.String component1() {
            r1 = this;
            java.lang.String r0 = r1.transport
            return r0
    }

    public final int component2() {
            r1 = this;
            int r0 = r1.port
            return r0
    }

    public final long component3() {
            r2 = this;
            long r0 = r2.chipId
            return r0
    }

    public final vea.raceremote.control.ControlEndpoint copy(java.lang.String r2, int r3, long r4) {
            r1 = this;
            java.lang.String r0 = "transport"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            vea.raceremote.control.ControlEndpoint r0 = new vea.raceremote.control.ControlEndpoint
            r0.<init>(r2, r3, r4)
            return r0
    }

    public boolean equals(java.lang.Object r6) {
            r5 = this;
            if (r5 != r6) goto L9
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r0 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE
            boolean r0 = r0.m6115Boolean$branch$when$funequals$classControlEndpoint()
            return r0
        L9:
            boolean r0 = r6 instanceof vea.raceremote.control.ControlEndpoint
            if (r0 != 0) goto L14
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r0 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE
            boolean r0 = r0.m6116Boolean$branch$when1$funequals$classControlEndpoint()
            return r0
        L14:
            r0 = r6
            vea.raceremote.control.ControlEndpoint r0 = (vea.raceremote.control.ControlEndpoint) r0
            java.lang.String r1 = r5.transport
            java.lang.String r2 = r0.transport
            boolean r1 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r2)
            if (r1 != 0) goto L28
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r0 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE
            boolean r0 = r0.m6117Boolean$branch$when2$funequals$classControlEndpoint()
            return r0
        L28:
            int r1 = r5.port
            int r2 = r0.port
            if (r1 == r2) goto L35
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r0 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE
            boolean r0 = r0.m6118Boolean$branch$when3$funequals$classControlEndpoint()
            return r0
        L35:
            long r1 = r5.chipId
            long r3 = r0.chipId
            int r0 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r0 == 0) goto L44
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r0 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE
            boolean r0 = r0.m6119Boolean$branch$when4$funequals$classControlEndpoint()
            return r0
        L44:
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r0 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE
            boolean r0 = r0.m6120Boolean$funequals$classControlEndpoint()
            return r0
    }

    public final long getChipId() {
            r2 = this;
            long r0 = r2.chipId
            return r0
    }

    public final int getPort() {
            r1 = this;
            int r0 = r1.port
            return r0
    }

    public final java.lang.String getTransport() {
            r1 = this;
            java.lang.String r0 = r1.transport
            return r0
    }

    public int hashCode() {
            r4 = this;
            java.lang.String r0 = r4.transport
            int r0 = r0.hashCode()
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r1 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE
            int r1 = r1.m6131Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classControlEndpoint()
            int r1 = r1 * r0
            int r2 = r4.port
            int r2 = java.lang.Integer.hashCode(r2)
            int r1 = r1 + r2
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r0 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE
            int r0 = r0.m6132Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classControlEndpoint()
            int r0 = r0 * r1
            long r2 = r4.chipId
            int r2 = java.lang.Long.hashCode(r2)
            int r0 = r0 + r2
            return r0
    }

    public java.lang.String toString() {
            r3 = this;
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r1 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE
            java.lang.String r1 = r1.m6141String$0$str$funtoString$classControlEndpoint()
            java.lang.StringBuilder r0 = r0.append(r1)
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r1 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE
            java.lang.String r1 = r1.m6142String$1$str$funtoString$classControlEndpoint()
            java.lang.StringBuilder r0 = r0.append(r1)
            java.lang.String r1 = r3.transport
            java.lang.StringBuilder r0 = r0.append(r1)
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r1 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE
            java.lang.String r1 = r1.m6143String$3$str$funtoString$classControlEndpoint()
            java.lang.StringBuilder r0 = r0.append(r1)
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r1 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE
            java.lang.String r1 = r1.m6144String$4$str$funtoString$classControlEndpoint()
            java.lang.StringBuilder r0 = r0.append(r1)
            int r1 = r3.port
            java.lang.StringBuilder r0 = r0.append(r1)
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r1 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE
            java.lang.String r1 = r1.m6145String$6$str$funtoString$classControlEndpoint()
            java.lang.StringBuilder r0 = r0.append(r1)
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r1 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE
            java.lang.String r1 = r1.m6146String$7$str$funtoString$classControlEndpoint()
            java.lang.StringBuilder r0 = r0.append(r1)
            long r1 = r3.chipId
            java.lang.StringBuilder r0 = r0.append(r1)
            vea.raceremote.control.LiveLiterals$CarControlConnectionKt r1 = vea.raceremote.control.LiveLiterals$CarControlConnectionKt.INSTANCE
            java.lang.String r1 = r1.m6147String$9$str$funtoString$classControlEndpoint()
            java.lang.StringBuilder r0 = r0.append(r1)
            java.lang.String r0 = r0.toString()
            return r0
    }
}
