package vea.raceremote.control;

/* JADX INFO: compiled from: ControlEndpointProbe.kt */
/* JADX INFO: loaded from: classes4.dex */
@kotlin.Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u001e\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n¨\u0006\u000b"}, d2 = {"Lvea/raceremote/control/ControlEndpointProbe;", "", "()V", "load", "Lvea/raceremote/control/ControlEndpoint;", "host", "", "http", "Lokhttp3/OkHttpClient;", "port", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class ControlEndpointProbe {
    public static final int $stable = 0;
    public static final vea.raceremote.control.ControlEndpointProbe INSTANCE = null;

    static {
            vea.raceremote.control.ControlEndpointProbe r0 = new vea.raceremote.control.ControlEndpointProbe
            r0.<init>()
            vea.raceremote.control.ControlEndpointProbe.INSTANCE = r0
            vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt r0 = vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt.INSTANCE
            int r0 = r0.m6315Int$classControlEndpointProbe()
            vea.raceremote.control.ControlEndpointProbe.$stable = r0
            return
    }

    private ControlEndpointProbe() {
            r0 = this;
            r0.<init>()
            return
    }

    public final vea.raceremote.control.ControlEndpoint load(java.lang.String r13, okhttp3.OkHttpClient r14, int r15) {
            r12 = this;
            java.lang.String r0 = "host"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r13, r0)
            java.lang.String r0 = "http"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r14, r0)
            okhttp3.OkHttpClient$Builder r0 = r14.newBuilder()
            vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt r1 = vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt.INSTANCE
            boolean r1 = r1.m6310Boolean$arg0$callfollowRedirects$$this$callfollowSslRedirects$$this$callconnectTimeout$$this$callreadTimeout$$this$callcallTimeout$$this$callbuild$valbounded$funload$classControlEndpointProbe()
            okhttp3.OkHttpClient$Builder r0 = r0.followRedirects(r1)
            vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt r1 = vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt.INSTANCE
            boolean r1 = r1.m6311Boolean$arg0$callfollowSslRedirects$$this$callconnectTimeout$$this$callreadTimeout$$this$callcallTimeout$$this$callbuild$valbounded$funload$classControlEndpointProbe()
            okhttp3.OkHttpClient$Builder r0 = r0.followSslRedirects(r1)
            vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt r1 = vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt.INSTANCE
            long r1 = r1.m6317Long$arg0$callconnectTimeout$$this$callreadTimeout$$this$callcallTimeout$$this$callbuild$valbounded$funload$classControlEndpointProbe()
            java.util.concurrent.TimeUnit r3 = java.util.concurrent.TimeUnit.SECONDS
            okhttp3.OkHttpClient$Builder r0 = r0.connectTimeout(r1, r3)
            vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt r1 = vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt.INSTANCE
            long r1 = r1.m6318Long$arg0$callreadTimeout$$this$callcallTimeout$$this$callbuild$valbounded$funload$classControlEndpointProbe()
            java.util.concurrent.TimeUnit r3 = java.util.concurrent.TimeUnit.SECONDS
            okhttp3.OkHttpClient$Builder r0 = r0.readTimeout(r1, r3)
            vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt r1 = vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt.INSTANCE
            long r1 = r1.m6316Long$arg0$callcallTimeout$$this$callbuild$valbounded$funload$classControlEndpointProbe()
            java.util.concurrent.TimeUnit r3 = java.util.concurrent.TimeUnit.SECONDS
            okhttp3.OkHttpClient$Builder r0 = r0.callTimeout(r1, r3)
            okhttp3.OkHttpClient r0 = r0.build()
            okhttp3.Request$Builder r1 = new okhttp3.Request$Builder
            r1.<init>()
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt r3 = vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt.INSTANCE
            java.lang.String r3 = r3.m6320String$0$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$funload$classControlEndpointProbe()
            java.lang.StringBuilder r2 = r2.append(r3)
            java.lang.StringBuilder r2 = r2.append(r13)
            vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt r3 = vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt.INSTANCE
            java.lang.String r3 = r3.m6321String$2$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$funload$classControlEndpointProbe()
            java.lang.StringBuilder r2 = r2.append(r3)
            java.lang.StringBuilder r2 = r2.append(r15)
            vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt r3 = vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt.INSTANCE
            java.lang.String r3 = r3.m6322String$4$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$funload$classControlEndpointProbe()
            java.lang.StringBuilder r2 = r2.append(r3)
            java.lang.String r2 = r2.toString()
            okhttp3.Request$Builder r1 = r1.url(r2)
            okhttp3.Request r1 = r1.build()
            okhttp3.Call r1 = r0.newCall(r1)
            okhttp3.Response r1 = r1.execute()
            java.io.Closeable r1 = (java.io.Closeable) r1
            r2 = r1
            okhttp3.Response r2 = (okhttp3.Response) r2     // Catch: java.lang.Throwable -> L16b
            r3 = 0
            int r4 = r2.code()     // Catch: java.lang.Throwable -> L16b
            vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt r5 = vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt.INSTANCE     // Catch: java.lang.Throwable -> L16b
            int r5 = r5.m6313Int$arg1$callEQEQ$arg0$callcheck$fun$anonymous$$arg0$calluse$funload$classControlEndpointProbe()     // Catch: java.lang.Throwable -> L16b
            r6 = 0
            r7 = 1
            if (r4 != r5) goto La5
            r4 = r7
            goto La6
        La5:
            r4 = r6
        La6:
            java.lang.String r5 = "Check failed."
            if (r4 == 0) goto L161
            okhttp3.ResponseBody r4 = r2.body()     // Catch: java.lang.Throwable -> L16b
            if (r4 == 0) goto L155
            java.lang.String r8 = "requireNotNull(response.body())"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r4, r8)     // Catch: java.lang.Throwable -> L16b
            okio.BufferedSource r8 = r4.source()     // Catch: java.lang.Throwable -> L16b
            vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt r9 = vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt.INSTANCE     // Catch: java.lang.Throwable -> L16b
            long r9 = r9.m6319Long$arg0$callrequest$$this$callnot$arg0$callcheck1$fun$anonymous$$arg0$calluse$funload$classControlEndpointProbe()     // Catch: java.lang.Throwable -> L16b
            boolean r9 = r8.request(r9)     // Catch: java.lang.Throwable -> L16b
            r9 = r9 ^ r7
            if (r9 == 0) goto L144
            org.json.JSONObject r9 = new org.json.JSONObject     // Catch: java.lang.Throwable -> L16b
            java.lang.String r10 = r8.readUtf8()     // Catch: java.lang.Throwable -> L16b
            r9.<init>(r10)     // Catch: java.lang.Throwable -> L16b
            vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt r10 = vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt.INSTANCE     // Catch: java.lang.Throwable -> L16b
            java.lang.String r10 = r10.m6324String$arg0$callgetInt$arg0$callEQEQ$arg0$callcheck2$fun$anonymous$$arg0$calluse$funload$classControlEndpointProbe()     // Catch: java.lang.Throwable -> L16b
            int r10 = r9.getInt(r10)     // Catch: java.lang.Throwable -> L16b
            vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt r11 = vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt.INSTANCE     // Catch: java.lang.Throwable -> L16b
            int r11 = r11.m6314Int$arg1$callEQEQ$arg0$callcheck2$fun$anonymous$$arg0$calluse$funload$classControlEndpointProbe()     // Catch: java.lang.Throwable -> L16b
            if (r10 != r11) goto Le2
            r6 = r7
        Le2:
            if (r6 == 0) goto L13a
            vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt r6 = vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt.INSTANCE     // Catch: java.lang.Throwable -> L16b
            java.lang.String r6 = r6.m6323String$arg0$callgetBoolean$arg0$callcheck3$fun$anonymous$$arg0$calluse$funload$classControlEndpointProbe()     // Catch: java.lang.Throwable -> L16b
            boolean r6 = r9.getBoolean(r6)     // Catch: java.lang.Throwable -> L16b
            if (r6 == 0) goto L130
            vea.raceremote.control.ControlEndpoint r5 = new vea.raceremote.control.ControlEndpoint     // Catch: java.lang.Throwable -> L16b
            vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt r6 = vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt.INSTANCE     // Catch: java.lang.Throwable -> L16b
            java.lang.String r6 = r6.m6327String$arg0$callgetString$arg0$call$init$$fun$anonymous$$arg0$calluse$funload$classControlEndpointProbe()     // Catch: java.lang.Throwable -> L16b
            java.lang.String r6 = r9.getString(r6)     // Catch: java.lang.Throwable -> L16b
            java.lang.String r7 = "value.getString(\"controlTransport\")"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r6, r7)     // Catch: java.lang.Throwable -> L16b
            vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt r7 = vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt.INSTANCE     // Catch: java.lang.Throwable -> L16b
            java.lang.String r7 = r7.m6325String$arg0$callgetInt$arg1$call$init$$fun$anonymous$$arg0$calluse$funload$classControlEndpointProbe()     // Catch: java.lang.Throwable -> L16b
            int r7 = r9.getInt(r7)     // Catch: java.lang.Throwable -> L16b
            vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt r10 = vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt.INSTANCE     // Catch: java.lang.Throwable -> L16b
            java.lang.String r10 = r10.m6326String$arg0$callgetString$$$this$calltoLong$arg2$call$init$$fun$anonymous$$arg0$calluse$funload$classControlEndpointProbe()     // Catch: java.lang.Throwable -> L16b
            java.lang.String r10 = r9.getString(r10)     // Catch: java.lang.Throwable -> L16b
            java.lang.String r11 = "value.getString(\"chipId\")"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r10, r11)     // Catch: java.lang.Throwable -> L16b
            vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt r11 = vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt.INSTANCE     // Catch: java.lang.Throwable -> L16b
            int r11 = r11.m6312Int$arg0$calltoLong$arg2$call$init$$fun$anonymous$$arg0$calluse$funload$classControlEndpointProbe()     // Catch: java.lang.Throwable -> L16b
            int r11 = kotlin.text.CharsKt.checkRadix(r11)     // Catch: java.lang.Throwable -> L16b
            long r10 = java.lang.Long.parseLong(r10, r11)     // Catch: java.lang.Throwable -> L16b
            r5.<init>(r6, r7, r10)     // Catch: java.lang.Throwable -> L16b
            r2 = 0
            kotlin.io.CloseableKt.closeFinally(r1, r2)
            return r5
        L130:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException     // Catch: java.lang.Throwable -> L16b
            java.lang.String r5 = r5.toString()     // Catch: java.lang.Throwable -> L16b
            r6.<init>(r5)     // Catch: java.lang.Throwable -> L16b
            throw r6     // Catch: java.lang.Throwable -> L16b
        L13a:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException     // Catch: java.lang.Throwable -> L16b
            java.lang.String r5 = r5.toString()     // Catch: java.lang.Throwable -> L16b
            r6.<init>(r5)     // Catch: java.lang.Throwable -> L16b
            throw r6     // Catch: java.lang.Throwable -> L16b
        L144:
            r5 = 0
            vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt r6 = vea.raceremote.control.LiveLiterals$ControlEndpointProbeKt.INSTANCE     // Catch: java.lang.Throwable -> L16b
            java.lang.String r6 = r6.m6328String$fun$anonymous$$arg1$callcheck1$fun$anonymous$$arg0$calluse$funload$classControlEndpointProbe()     // Catch: java.lang.Throwable -> L16b
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException     // Catch: java.lang.Throwable -> L16b
            java.lang.String r6 = r6.toString()     // Catch: java.lang.Throwable -> L16b
            r5.<init>(r6)     // Catch: java.lang.Throwable -> L16b
            throw r5     // Catch: java.lang.Throwable -> L16b
        L155:
            java.lang.String r4 = "Required value was null."
            java.lang.IllegalArgumentException r5 = new java.lang.IllegalArgumentException     // Catch: java.lang.Throwable -> L16b
            java.lang.String r4 = r4.toString()     // Catch: java.lang.Throwable -> L16b
            r5.<init>(r4)     // Catch: java.lang.Throwable -> L16b
            throw r5     // Catch: java.lang.Throwable -> L16b
        L161:
            java.lang.IllegalStateException r4 = new java.lang.IllegalStateException     // Catch: java.lang.Throwable -> L16b
            java.lang.String r5 = r5.toString()     // Catch: java.lang.Throwable -> L16b
            r4.<init>(r5)     // Catch: java.lang.Throwable -> L16b
            throw r4     // Catch: java.lang.Throwable -> L16b
        L16b:
            r2 = move-exception
            throw r2     // Catch: java.lang.Throwable -> L16d
        L16d:
            r3 = move-exception
            kotlin.io.CloseableKt.closeFinally(r1, r2)
            throw r3
    }
}
