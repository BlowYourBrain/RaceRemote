package vea.raceremote.control;

/* JADX INFO: compiled from: DiscoveryPacket.kt */
/* JADX INFO: loaded from: classes4.dex */
@kotlin.Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u001b\b\u0087\b\u0018\u00002\u00020\u0001B9\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\b\b\u0002\u0010\n\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u000b\u001a\u00020\u0005¢\u0006\u0002\u0010\fJ\t\u0010\u0019\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001a\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001b\u001a\u00020\u0007HÆ\u0003J\t\u0010\u001c\u001a\u00020\tHÆ\u0003J\t\u0010\u001d\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001e\u001a\u00020\u0005HÆ\u0003JE\u0010\u001f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\n\u001a\u00020\u00032\b\b\u0002\u0010\u000b\u001a\u00020\u0005HÆ\u0001J\u0013\u0010 \u001a\u00020\t2\b\u0010!\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\"\u001a\u00020\u0005HÖ\u0001J\t\u0010#\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u000b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\u0015\u001a\u00020\u00038F¢\u0006\u0006\u001a\u0004\b\u0016\u0010\u0014R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0012R\u0011\u0010\n\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0014¨\u0006$"}, d2 = {"Lvea/raceremote/control/DiscoveredCar;", "", "host", "", "port", "", "chipId", "", "busy", "", "transport", "discoveryVersion", "(Ljava/lang/String;IJZLjava/lang/String;I)V", "getBusy", "()Z", "getChipId", "()J", "getDiscoveryVersion", "()I", "getHost", "()Ljava/lang/String;", "name", "getName", "getPort", "getTransport", "component1", "component2", "component3", "component4", "component5", "component6", "copy", "equals", "other", "hashCode", "toString", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class DiscoveredCar {
    public static final int $stable = 0;
    private final boolean busy;
    private final long chipId;
    private final int discoveryVersion;
    private final java.lang.String host;
    private final int port;
    private final java.lang.String transport;

    static {
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r0 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r0 = r0.m6460Int$classDiscoveredCar()
            vea.raceremote.control.DiscoveredCar.$stable = r0
            return
    }

    public DiscoveredCar(java.lang.String r2, int r3, long r4, boolean r6, java.lang.String r7, int r8) {
            r1 = this;
            java.lang.String r0 = "host"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.String r0 = "transport"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r7, r0)
            r1.<init>()
            r1.host = r2
            r1.port = r3
            r1.chipId = r4
            r1.busy = r6
            r1.transport = r7
            r1.discoveryVersion = r8
            return
    }

    public /* synthetic */ DiscoveredCar(java.lang.String r10, int r11, long r12, boolean r14, java.lang.String r15, int r16, int r17, kotlin.jvm.internal.DefaultConstructorMarker r18) {
            r9 = this;
            r0 = r17 & 16
            if (r0 == 0) goto Lc
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r0 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            java.lang.String r0 = r0.m6486String$paramtransport$classDiscoveredCar()
            r7 = r0
            goto Ld
        Lc:
            r7 = r15
        Ld:
            r0 = r17 & 32
            if (r0 == 0) goto L19
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r0 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r0 = r0.m6462Int$paramdiscoveryVersion$classDiscoveredCar()
            r8 = r0
            goto L1b
        L19:
            r8 = r16
        L1b:
            r1 = r9
            r2 = r10
            r3 = r11
            r4 = r12
            r6 = r14
            r1.<init>(r2, r3, r4, r6, r7, r8)
            return
    }

    public static /* synthetic */ vea.raceremote.control.DiscoveredCar copy$default(vea.raceremote.control.DiscoveredCar r5, java.lang.String r6, int r7, long r8, boolean r10, java.lang.String r11, int r12, int r13, java.lang.Object r14) {
            r14 = r13 & 1
            if (r14 == 0) goto L6
            java.lang.String r6 = r5.host
        L6:
            r14 = r13 & 2
            if (r14 == 0) goto Lc
            int r7 = r5.port
        Lc:
            r14 = r7
            r7 = r13 & 4
            if (r7 == 0) goto L13
            long r8 = r5.chipId
        L13:
            r0 = r8
            r7 = r13 & 8
            if (r7 == 0) goto L1a
            boolean r10 = r5.busy
        L1a:
            r2 = r10
            r7 = r13 & 16
            if (r7 == 0) goto L21
            java.lang.String r11 = r5.transport
        L21:
            r3 = r11
            r7 = r13 & 32
            if (r7 == 0) goto L28
            int r12 = r5.discoveryVersion
        L28:
            r4 = r12
            r7 = r5
            r8 = r6
            r9 = r14
            r10 = r0
            r12 = r2
            r13 = r3
            r14 = r4
            vea.raceremote.control.DiscoveredCar r5 = r7.copy(r8, r9, r10, r12, r13, r14)
            return r5
    }

    public final java.lang.String component1() {
            r1 = this;
            java.lang.String r0 = r1.host
            return r0
    }

    public final int component2() {
            r1 = this;
            int r0 = r1.port
            return r0
    }

    public final long component3() {
            r2 = this;
            long r0 = r2.chipId
            return r0
    }

    public final boolean component4() {
            r1 = this;
            boolean r0 = r1.busy
            return r0
    }

    public final java.lang.String component5() {
            r1 = this;
            java.lang.String r0 = r1.transport
            return r0
    }

    public final int component6() {
            r1 = this;
            int r0 = r1.discoveryVersion
            return r0
    }

    public final vea.raceremote.control.DiscoveredCar copy(java.lang.String r12, int r13, long r14, boolean r16, java.lang.String r17, int r18) {
            r11 = this;
            java.lang.String r0 = "host"
            r9 = r12
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r12, r0)
            java.lang.String r0 = "transport"
            r10 = r17
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r10, r0)
            vea.raceremote.control.DiscoveredCar r0 = new vea.raceremote.control.DiscoveredCar
            r1 = r0
            r2 = r12
            r3 = r13
            r4 = r14
            r6 = r16
            r7 = r17
            r8 = r18
            r1.<init>(r2, r3, r4, r6, r7, r8)
            return r0
    }

    public boolean equals(java.lang.Object r6) {
            r5 = this;
            if (r5 != r6) goto L9
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r0 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            boolean r0 = r0.m6404Boolean$branch$when$funequals$classDiscoveredCar()
            return r0
        L9:
            boolean r0 = r6 instanceof vea.raceremote.control.DiscoveredCar
            if (r0 != 0) goto L14
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r0 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            boolean r0 = r0.m6405Boolean$branch$when1$funequals$classDiscoveredCar()
            return r0
        L14:
            r0 = r6
            vea.raceremote.control.DiscoveredCar r0 = (vea.raceremote.control.DiscoveredCar) r0
            java.lang.String r1 = r5.host
            java.lang.String r2 = r0.host
            boolean r1 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r2)
            if (r1 != 0) goto L28
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r0 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            boolean r0 = r0.m6406Boolean$branch$when2$funequals$classDiscoveredCar()
            return r0
        L28:
            int r1 = r5.port
            int r2 = r0.port
            if (r1 == r2) goto L35
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r0 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            boolean r0 = r0.m6407Boolean$branch$when3$funequals$classDiscoveredCar()
            return r0
        L35:
            long r1 = r5.chipId
            long r3 = r0.chipId
            int r1 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r1 == 0) goto L44
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r0 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            boolean r0 = r0.m6408Boolean$branch$when4$funequals$classDiscoveredCar()
            return r0
        L44:
            boolean r1 = r5.busy
            boolean r2 = r0.busy
            if (r1 == r2) goto L51
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r0 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            boolean r0 = r0.m6409Boolean$branch$when5$funequals$classDiscoveredCar()
            return r0
        L51:
            java.lang.String r1 = r5.transport
            java.lang.String r2 = r0.transport
            boolean r1 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r2)
            if (r1 != 0) goto L62
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r0 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            boolean r0 = r0.m6410Boolean$branch$when6$funequals$classDiscoveredCar()
            return r0
        L62:
            int r1 = r5.discoveryVersion
            int r0 = r0.discoveryVersion
            if (r1 == r0) goto L6f
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r0 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            boolean r0 = r0.m6411Boolean$branch$when7$funequals$classDiscoveredCar()
            return r0
        L6f:
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r0 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            boolean r0 = r0.m6412Boolean$funequals$classDiscoveredCar()
            return r0
    }

    public final boolean getBusy() {
            r1 = this;
            boolean r0 = r1.busy
            return r0
    }

    public final long getChipId() {
            r2 = this;
            long r0 = r2.chipId
            return r0
    }

    public final int getDiscoveryVersion() {
            r1 = this;
            int r0 = r1.discoveryVersion
            return r0
    }

    public final java.lang.String getHost() {
            r1 = this;
            java.lang.String r0 = r1.host
            return r0
    }

    public final java.lang.String getName() {
            r4 = this;
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            java.lang.String r1 = r1.m6468String$0$str$fun$getname$$get$valname$classDiscoveredCar()
            java.lang.StringBuilder r0 = r0.append(r1)
            long r1 = r4.chipId
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r3 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r3 = r3.m6453Int$arg0$callushr$$$this$calltoString$1$str$fun$getname$$get$valname$classDiscoveredCar()
            long r1 = r1 >>> r3
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r3 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r3 = r3.m6452Int$arg0$calltoString$1$str$fun$getname$$get$valname$classDiscoveredCar()
            int r3 = kotlin.text.CharsKt.checkRadix(r3)
            java.lang.String r1 = java.lang.Long.toString(r1, r3)
            java.lang.String r2 = "toString(this, checkRadix(radix))"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            java.lang.StringBuilder r0 = r0.append(r1)
            java.lang.String r0 = r0.toString()
            return r0
    }

    public final int getPort() {
            r1 = this;
            int r0 = r1.port
            return r0
    }

    public final java.lang.String getTransport() {
            r1 = this;
            java.lang.String r0 = r1.transport
            return r0
    }

    public int hashCode() {
            r4 = this;
            java.lang.String r0 = r4.host
            int r0 = r0.hashCode()
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r1 = r1.m6447Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classDiscoveredCar()
            int r1 = r1 * r0
            int r2 = r4.port
            int r2 = java.lang.Integer.hashCode(r2)
            int r1 = r1 + r2
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r0 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r0 = r0.m6448Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classDiscoveredCar()
            int r0 = r0 * r1
            long r2 = r4.chipId
            int r2 = java.lang.Long.hashCode(r2)
            int r0 = r0 + r2
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r1 = r1.m6449Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classDiscoveredCar()
            int r1 = r1 * r0
            boolean r2 = r4.busy
            if (r2 == 0) goto L2e
            r2 = 1
        L2e:
            int r1 = r1 + r2
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r0 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r0 = r0.m6450Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classDiscoveredCar()
            int r0 = r0 * r1
            java.lang.String r2 = r4.transport
            int r2 = r2.hashCode()
            int r0 = r0 + r2
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r1 = r1.m6451Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classDiscoveredCar()
            int r1 = r1 * r0
            int r2 = r4.discoveryVersion
            int r2 = java.lang.Integer.hashCode(r2)
            int r1 = r1 + r2
            return r1
    }

    public java.lang.String toString() {
            r3 = this;
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            java.lang.String r1 = r1.m6469String$0$str$funtoString$classDiscoveredCar()
            java.lang.StringBuilder r0 = r0.append(r1)
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            java.lang.String r1 = r1.m6470String$1$str$funtoString$classDiscoveredCar()
            java.lang.StringBuilder r0 = r0.append(r1)
            java.lang.String r1 = r3.host
            java.lang.StringBuilder r0 = r0.append(r1)
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            java.lang.String r1 = r1.m6477String$3$str$funtoString$classDiscoveredCar()
            java.lang.StringBuilder r0 = r0.append(r1)
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            java.lang.String r1 = r1.m6478String$4$str$funtoString$classDiscoveredCar()
            java.lang.StringBuilder r0 = r0.append(r1)
            int r1 = r3.port
            java.lang.StringBuilder r0 = r0.append(r1)
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            java.lang.String r1 = r1.m6479String$6$str$funtoString$classDiscoveredCar()
            java.lang.StringBuilder r0 = r0.append(r1)
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            java.lang.String r1 = r1.m6480String$7$str$funtoString$classDiscoveredCar()
            java.lang.StringBuilder r0 = r0.append(r1)
            long r1 = r3.chipId
            java.lang.StringBuilder r0 = r0.append(r1)
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            java.lang.String r1 = r1.m6481String$9$str$funtoString$classDiscoveredCar()
            java.lang.StringBuilder r0 = r0.append(r1)
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            java.lang.String r1 = r1.m6471String$10$str$funtoString$classDiscoveredCar()
            java.lang.StringBuilder r0 = r0.append(r1)
            boolean r1 = r3.busy
            java.lang.StringBuilder r0 = r0.append(r1)
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            java.lang.String r1 = r1.m6472String$12$str$funtoString$classDiscoveredCar()
            java.lang.StringBuilder r0 = r0.append(r1)
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            java.lang.String r1 = r1.m6473String$13$str$funtoString$classDiscoveredCar()
            java.lang.StringBuilder r0 = r0.append(r1)
            java.lang.String r1 = r3.transport
            java.lang.StringBuilder r0 = r0.append(r1)
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            java.lang.String r1 = r1.m6474String$15$str$funtoString$classDiscoveredCar()
            java.lang.StringBuilder r0 = r0.append(r1)
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            java.lang.String r1 = r1.m6475String$16$str$funtoString$classDiscoveredCar()
            java.lang.StringBuilder r0 = r0.append(r1)
            int r1 = r3.discoveryVersion
            java.lang.StringBuilder r0 = r0.append(r1)
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            java.lang.String r1 = r1.m6476String$18$str$funtoString$classDiscoveredCar()
            java.lang.StringBuilder r0 = r0.append(r1)
            java.lang.String r0 = r0.toString()
            return r0
    }
}
