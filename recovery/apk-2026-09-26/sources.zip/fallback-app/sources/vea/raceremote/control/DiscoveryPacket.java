package vea.raceremote.control;

/* JADX INFO: compiled from: DiscoveryPacket.kt */
/* JADX INFO: loaded from: classes4.dex */
@kotlin.Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0018\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\u0004J \u0010\n\u001a\u0004\u0018\u00010\u000b2\u0006\u0010\f\u001a\u00020\u00062\u0006\u0010\r\u001a\u00020\b2\u0006\u0010\u000e\u001a\u00020\u000fR\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0010"}, d2 = {"Lvea/raceremote/control/DiscoveryPacket;", "", "()V", "PORT", "", "query", "", "nonce", "", "version", "reply", "Lvea/raceremote/control/DiscoveredCar;", "bytes", "expectedNonce", "host", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class DiscoveryPacket {
    public static final int $stable = 0;
    public static final vea.raceremote.control.DiscoveryPacket INSTANCE = null;
    public static final int PORT = 3333;

    static {
            vea.raceremote.control.DiscoveryPacket r0 = new vea.raceremote.control.DiscoveryPacket
            r0.<init>()
            vea.raceremote.control.DiscoveryPacket.INSTANCE = r0
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r0 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r0 = r0.m6461Int$classDiscoveryPacket()
            vea.raceremote.control.DiscoveryPacket.$stable = r0
            return
    }

    private DiscoveryPacket() {
            r0 = this;
            r0.<init>()
            return
    }

    public static /* synthetic */ byte[] query$default(vea.raceremote.control.DiscoveryPacket r0, long r1, int r3, int r4, java.lang.Object r5) {
            r4 = r4 & 2
            if (r4 == 0) goto La
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r3 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r3 = r3.m6463Int$paramversion$funquery$classDiscoveryPacket()
        La:
            byte[] r0 = r0.query(r1, r3)
            return r0
    }

    private static final long reply$number(byte[] r17, int r18, int r19) {
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r0 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r0 = r0.m6424Int$$$this$calluntil$$$this$callfold$funnumber$funreply$classDiscoveryPacket()
            r1 = r19
            kotlin.ranges.IntRange r0 = kotlin.ranges.RangesKt.until(r0, r1)
            java.lang.Iterable r0 = (java.lang.Iterable) r0
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r2 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            long r2 = r2.m6465Long$arg0$callfold$funnumber$funreply$classDiscoveryPacket()
            r4 = 0
            r5 = r2
            java.util.Iterator r7 = r0.iterator()
        L1a:
            boolean r8 = r7.hasNext()
            if (r8 == 0) goto L41
            r8 = r7
            kotlin.collections.IntIterator r8 = (kotlin.collections.IntIterator) r8
            int r8 = r8.nextInt()
            r9 = r5
            r11 = r8
            r12 = 0
            int r13 = r18 + r11
            r13 = r17[r13]
            long r13 = (long) r13
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r15 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            long r15 = r15.m6464Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$funreply$classDiscoveryPacket()
            long r13 = r13 & r15
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r15 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r15 = r15.m6429Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funnumber$funreply$classDiscoveryPacket()
            int r15 = r15 * r11
            long r13 = r13 << r15
            long r9 = r9 | r13
            r5 = r9
            goto L1a
        L41:
            return r5
    }

    public final byte[] query(long r11, int r13) {
            r10 = this;
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r0 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r0 = r0.m6428Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$funquery$classDiscoveryPacket()
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            long r1 = r1.m6467Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$funquery$classDiscoveryPacket()
            int r1 = (r11 > r1 ? 1 : (r11 == r1 ? 0 : -1))
            r2 = 1
            r3 = 0
            if (r1 > 0) goto L19
            long r0 = (long) r0
            int r0 = (r0 > r11 ? 1 : (r0 == r11 ? 0 : -1))
            if (r0 > 0) goto L19
            r0 = r2
            goto L1a
        L19:
            r0 = r3
        L1a:
            if (r0 == 0) goto L33
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r0 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r0 = r0.m6427Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funquery$classDiscoveryPacket()
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r1 = r1.m6445Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funquery$classDiscoveryPacket()
            if (r13 > r1) goto L2e
            if (r0 > r13) goto L2e
            r0 = r2
            goto L2f
        L2e:
            r0 = r3
        L2f:
            if (r0 == 0) goto L33
            r0 = r2
            goto L34
        L33:
            r0 = r3
        L34:
            if (r0 == 0) goto Lc8
            r0 = 12
            byte[] r0 = new byte[r0]
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            byte r1 = r1.m6413Byte$0$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket()
            r0[r3] = r1
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            byte r1 = r1.m6414Byte$1$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket()
            r0[r2] = r1
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            byte r1 = r1.m6417Byte$2$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket()
            r2 = 2
            r0[r2] = r1
            r1 = 3
            byte r2 = (byte) r13
            r0[r1] = r2
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            byte r1 = r1.m6418Byte$4$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket()
            r2 = 4
            r0[r2] = r1
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            byte r1 = r1.m6419Byte$5$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket()
            r2 = 5
            r0[r2] = r1
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            byte r1 = r1.m6420Byte$6$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket()
            r2 = 6
            r0[r2] = r1
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            byte r1 = r1.m6421Byte$7$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket()
            r2 = 7
            r0[r2] = r1
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            byte r1 = r1.m6422Byte$8$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket()
            r2 = 8
            r0[r2] = r1
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            byte r1 = r1.m6423Byte$9$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket()
            r2 = 9
            r0[r2] = r1
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            byte r1 = r1.m6415Byte$10$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket()
            r2 = 10
            r0[r2] = r1
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r1 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            byte r1 = r1.m6416Byte$11$vararg$arg0$callbyteArrayOf$$$this$callalso$funquery$classDiscoveryPacket()
            r2 = 11
            r0[r2] = r1
            r1 = r0
            r2 = 0
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r4 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r4 = r4.m6446Int$arg0$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket()
        Lab:
            if (r3 >= r4) goto Lc6
            r5 = r3
            r6 = 0
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r7 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r7 = r7.m6425Int$$this$callplus$arg0$callset$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket()
            int r7 = r7 + r5
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r8 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r8 = r8.m6430Int$$this$calltimes$arg0$callushr$$this$calltoByte$arg1$callset$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$callalso$funquery$classDiscoveryPacket()
            int r8 = r8 * r5
            long r8 = r11 >>> r8
            int r8 = (int) r8
            byte r8 = (byte) r8
            r1[r7] = r8
            int r3 = r3 + 1
            goto Lab
        Lc6:
            return r0
        Lc8:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "Failed requirement."
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
    }

    public final vea.raceremote.control.DiscoveredCar reply(byte[] r18, long r19, java.lang.String r21) {
            r17 = this;
            r0 = r18
            java.lang.String r1 = "bytes"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r0, r1)
            java.lang.String r1 = "host"
            r10 = r21
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r10, r1)
            int r1 = r0.length
            r2 = 24
            r3 = 0
            if (r1 != r2) goto L15c
            r1 = 0
            r2 = r0[r1]
            r4 = 82
            if (r2 != r4) goto L15c
            r2 = 1
            r5 = r0[r2]
            if (r5 != r4) goto L15c
            r4 = 2
            r5 = r0[r4]
            r6 = 68
            if (r5 != r6) goto L15c
            r5 = 3
            r6 = r0[r5]
            if (r2 > r6) goto L30
            if (r6 >= r5) goto L30
            r5 = r2
            goto L31
        L30:
            r5 = r1
        L31:
            if (r5 == 0) goto L15c
            r5 = 4
            r5 = r0[r5]
            if (r5 != r4) goto L15c
            r5 = 5
            r5 = r0[r5]
            if (r5 != 0) goto L15c
            r5 = 20
            r5 = r0[r5]
            if (r5 != r2) goto L15c
            r5 = 21
            r5 = r0[r5]
            if (r5 < 0) goto L4d
            if (r5 >= r4) goto L4d
            r4 = r2
            goto L4e
        L4d:
            r4 = r1
        L4e:
            if (r4 == 0) goto L15c
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r4 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r4 = r4.m6436Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$funreply$classDiscoveryPacket()
            r4 = r0[r4]
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r5 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r5 = r5.m6431Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$funreply$classDiscoveryPacket()
            byte r5 = (byte) r5
            if (r4 == r5) goto L63
            goto L15c
        L63:
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r4 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r4 = r4.m6441Int$arg0$callget$$this$calltoInt$valversion$funreply$classDiscoveryPacket()
            r11 = r0[r4]
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r4 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r4 = r4.m6454Int$arg1$callEQEQ$cond$cond$when$valtransport$funreply$classDiscoveryPacket()
            if (r11 != r4) goto L8c
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r4 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r4 = r4.m6438Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond$when$valtransport$funreply$classDiscoveryPacket()
            r4 = r0[r4]
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r5 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r5 = r5.m6433Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond$when$valtransport$funreply$classDiscoveryPacket()
            byte r5 = (byte) r5
            if (r4 != r5) goto L8c
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r4 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            java.lang.String r4 = r4.m6483String$branch$when$valtransport$funreply$classDiscoveryPacket()
            goto Lcb
        L8c:
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r4 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r4 = r4.m6455Int$arg1$callEQEQ$cond$cond1$when$valtransport$funreply$classDiscoveryPacket()
            if (r11 != r4) goto Lac
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r4 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r4 = r4.m6439Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond1$when$valtransport$funreply$classDiscoveryPacket()
            r4 = r0[r4]
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r5 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r5 = r5.m6434Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond1$when$valtransport$funreply$classDiscoveryPacket()
            byte r5 = (byte) r5
            if (r4 != r5) goto Lac
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r4 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            java.lang.String r4 = r4.m6484String$branch1$when$valtransport$funreply$classDiscoveryPacket()
            goto Lcb
        Lac:
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r4 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r4 = r4.m6456Int$arg1$callEQEQ$cond$cond2$when$valtransport$funreply$classDiscoveryPacket()
            if (r11 != r4) goto L15b
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r4 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r4 = r4.m6440Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$branch$cond2$when$valtransport$funreply$classDiscoveryPacket()
            r4 = r0[r4]
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r5 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r5 = r5.m6435Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$branch$cond2$when$valtransport$funreply$classDiscoveryPacket()
            byte r5 = (byte) r5
            if (r4 != r5) goto L15b
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r4 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            java.lang.String r4 = r4.m6485String$branch2$when$valtransport$funreply$classDiscoveryPacket()
        Lcb:
            r12 = r4
            r4 = 0
            int r4 = (r19 > r4 ? 1 : (r19 == r4 ? 0 : -1))
            if (r4 == 0) goto L15a
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r4 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r4 = r4.m6443Int$arg0$callnumber$arg0$callEQEQ$$this$callnot$else$cond$if1$funreply$classDiscoveryPacket()
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r5 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r5 = r5.m6458Int$arg1$callnumber$arg0$callEQEQ$$this$callnot$else$cond$if1$funreply$classDiscoveryPacket()
            long r4 = reply$number(r0, r4, r5)
            int r4 = (r4 > r19 ? 1 : (r4 == r19 ? 0 : -1))
            if (r4 == 0) goto Le8
            goto L15a
        Le8:
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r4 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r4 = r4.m6442Int$arg0$callnumber$$this$calltoInt$valport$funreply$classDiscoveryPacket()
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r5 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r5 = r5.m6457Int$arg1$callnumber$$this$calltoInt$valport$funreply$classDiscoveryPacket()
            long r4 = reply$number(r0, r4, r5)
            int r13 = (int) r4
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r4 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r4 = r4.m6444Int$arg0$callnumber$valchipId$funreply$classDiscoveryPacket()
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r5 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r5 = r5.m6459Int$arg1$callnumber$valchipId$funreply$classDiscoveryPacket()
            long r14 = reply$number(r0, r4, r5)
            if (r13 == 0) goto L159
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r4 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r4 = r4.m6426Int$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if2$funreply$classDiscoveryPacket()
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r5 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            long r5 = r5.m6466Long$arg0$callrangeTo$$this$callcontains$$this$callnot$else$cond$if2$funreply$classDiscoveryPacket()
            int r5 = (r14 > r5 ? 1 : (r14 == r5 ? 0 : -1))
            if (r5 > 0) goto L122
            long r4 = (long) r4
            int r4 = (r4 > r14 ? 1 : (r4 == r14 ? 0 : -1))
            if (r4 > 0) goto L122
            r4 = r2
            goto L123
        L122:
            r4 = r1
        L123:
            if (r4 != 0) goto L126
            goto L159
        L126:
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r4 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            java.lang.String r4 = r4.m6482String$arg1$callEQEQ$cond$cond$if3$funreply$classDiscoveryPacket()
            boolean r4 = kotlin.jvm.internal.Intrinsics.areEqual(r12, r4)
            if (r4 == 0) goto L137
            r4 = 3334(0xd06, float:4.672E-42)
            if (r13 == r4) goto L137
            return r3
        L137:
            vea.raceremote.control.DiscoveredCar r16 = new vea.raceremote.control.DiscoveredCar
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r3 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r3 = r3.m6437Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$arg3$call$init$$funreply$classDiscoveryPacket()
            r3 = r0[r3]
            vea.raceremote.control.LiveLiterals$DiscoveryPacketKt r4 = vea.raceremote.control.LiveLiterals$DiscoveryPacketKt.INSTANCE
            int r4 = r4.m6432Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$arg3$call$init$$funreply$classDiscoveryPacket()
            byte r4 = (byte) r4
            if (r3 != r4) goto L14c
            r7 = r2
            goto L14d
        L14c:
            r7 = r1
        L14d:
            r2 = r16
            r3 = r21
            r4 = r13
            r5 = r14
            r8 = r12
            r9 = r11
            r2.<init>(r3, r4, r5, r7, r8, r9)
            return r16
        L159:
            return r3
        L15a:
            return r3
        L15b:
            return r3
        L15c:
            return r3
    }
}
