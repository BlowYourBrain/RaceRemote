package vea.raceremote.control;

/* JADX INFO: compiled from: DrivingPad.kt */
/* JADX INFO: loaded from: classes4.dex */
@kotlin.Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "vea.raceremote.control.DrivingPadKt$DrivingPad$1$2$1", f = "DrivingPad.kt", i = {}, l = {48}, m = "invokeSuspend", n = {}, s = {})
final class DrivingPadKt$DrivingPad$1$2$1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<androidx.compose.ui.input.pointer.PointerInputScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
    final /* synthetic */ androidx.compose.runtime.State<kotlin.jvm.functions.Function1<java.lang.Float, kotlin.Unit>> $change$delegate;
    final /* synthetic */ boolean $enabled;
    final /* synthetic */ boolean $vertical;
    private /* synthetic */ java.lang.Object L$0;
    int label;

    /* JADX INFO: renamed from: vea.raceremote.control.DrivingPadKt$DrivingPad$1$2$1$1, reason: invalid class name */
    /* JADX INFO: compiled from: DrivingPad.kt */
    @kotlin.Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "vea.raceremote.control.DrivingPadKt$DrivingPad$1$2$1$1", f = "DrivingPad.kt", i = {0, 1, 1, 1, 1, 1, 2}, l = {50, 58, 74}, m = "invokeSuspend", n = {"$this$awaitPointerEventScope", "$this$awaitPointerEventScope", "down", "origin", "travel", "deadZone", "$this$awaitPointerEventScope"}, s = {"L$0", "L$0", "L$1", "J$0", "F$0", "F$1", "L$0"})
    static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.RestrictedSuspendLambda implements kotlin.jvm.functions.Function2<androidx.compose.ui.input.pointer.AwaitPointerEventScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ androidx.compose.runtime.State<kotlin.jvm.functions.Function1<java.lang.Float, kotlin.Unit>> $change$delegate;
        final /* synthetic */ boolean $vertical;
        float F$0;
        float F$1;
        long J$0;
        private /* synthetic */ java.lang.Object L$0;
        java.lang.Object L$1;
        int label;

        AnonymousClass1(boolean r2, androidx.compose.runtime.State<? extends kotlin.jvm.functions.Function1<? super java.lang.Float, kotlin.Unit>> r3, kotlin.coroutines.Continuation<? super vea.raceremote.control.DrivingPadKt$DrivingPad$1$2$1.AnonymousClass1> r4) {
                r1 = this;
                r1.$vertical = r2
                r1.$change$delegate = r3
                r0 = 2
                r1.<init>(r0, r4)
                return
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object r4, kotlin.coroutines.Continuation<?> r5) {
                r3 = this;
                vea.raceremote.control.DrivingPadKt$DrivingPad$1$2$1$1 r0 = new vea.raceremote.control.DrivingPadKt$DrivingPad$1$2$1$1
                boolean r1 = r3.$vertical
                androidx.compose.runtime.State<kotlin.jvm.functions.Function1<java.lang.Float, kotlin.Unit>> r2 = r3.$change$delegate
                r0.<init>(r1, r2, r5)
                r0.L$0 = r4
                kotlin.coroutines.Continuation r0 = (kotlin.coroutines.Continuation) r0
                return r0
        }

        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
        public final java.lang.Object invoke2(androidx.compose.ui.input.pointer.AwaitPointerEventScope r3, kotlin.coroutines.Continuation<? super kotlin.Unit> r4) {
                r2 = this;
                kotlin.coroutines.Continuation r0 = r2.create(r3, r4)
                vea.raceremote.control.DrivingPadKt$DrivingPad$1$2$1$1 r0 = (vea.raceremote.control.DrivingPadKt$DrivingPad$1$2$1.AnonymousClass1) r0
                kotlin.Unit r1 = kotlin.Unit.INSTANCE
                java.lang.Object r0 = r0.invokeSuspend(r1)
                return r0
        }

        @Override // kotlin.jvm.functions.Function2
        public /* bridge */ /* synthetic */ java.lang.Object invoke(androidx.compose.ui.input.pointer.AwaitPointerEventScope r2, kotlin.coroutines.Continuation<? super kotlin.Unit> r3) {
                r1 = this;
                androidx.compose.ui.input.pointer.AwaitPointerEventScope r2 = (androidx.compose.ui.input.pointer.AwaitPointerEventScope) r2
                kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3
                java.lang.Object r0 = r1.invoke2(r2, r3)
                return r0
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object r19) {
                r18 = this;
                java.lang.Object r0 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
                r1 = r18
                int r2 = r1.label
                r3 = 1
                r4 = 0
                r5 = 0
                switch(r2) {
                    case 0: goto L53;
                    case 1: goto L45;
                    case 2: goto L25;
                    case 3: goto L16;
                    default: goto Le;
                }
            Le:
                java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
                java.lang.String r1 = "call to 'resume' before 'invoke' with coroutine"
                r0.<init>(r1)
                throw r0
            L16:
                r1 = r18
                r2 = r19
                java.lang.Object r6 = r1.L$0
                androidx.compose.ui.input.pointer.AwaitPointerEventScope r6 = (androidx.compose.ui.input.pointer.AwaitPointerEventScope) r6
                kotlin.ResultKt.throwOnFailure(r2)
                r4 = r5
                r5 = r3
                goto L25e
            L25:
                r1 = r18
                r2 = r19
                float r6 = r1.F$1
                float r7 = r1.F$0
                long r8 = r1.J$0
                java.lang.Object r10 = r1.L$1
                androidx.compose.ui.input.pointer.PointerInputChange r10 = (androidx.compose.ui.input.pointer.PointerInputChange) r10
                java.lang.Object r11 = r1.L$0
                androidx.compose.ui.input.pointer.AwaitPointerEventScope r11 = (androidx.compose.ui.input.pointer.AwaitPointerEventScope) r11
                kotlin.ResultKt.throwOnFailure(r2)     // Catch: java.lang.Throwable -> L42
                r12 = r11
                r11 = r10
                r9 = r8
                r8 = r7
                r7 = r6
                r6 = r2
                goto L109
            L42:
                r0 = move-exception
                goto L272
            L45:
                r1 = r18
                r2 = r19
                java.lang.Object r6 = r1.L$0
                androidx.compose.ui.input.pointer.AwaitPointerEventScope r6 = (androidx.compose.ui.input.pointer.AwaitPointerEventScope) r6
                kotlin.ResultKt.throwOnFailure(r2)
                r7 = r6
                r6 = r2
                goto L75
            L53:
                kotlin.ResultKt.throwOnFailure(r19)
                r1 = r18
                r2 = r19
                java.lang.Object r6 = r1.L$0
                androidx.compose.ui.input.pointer.AwaitPointerEventScope r6 = (androidx.compose.ui.input.pointer.AwaitPointerEventScope) r6
            L5e:
                r7 = r1
                kotlin.coroutines.Continuation r7 = (kotlin.coroutines.Continuation) r7
                r1.L$0 = r6
                r1.L$1 = r5
                r1.label = r3
                java.lang.Object r7 = androidx.compose.foundation.gestures.TapGestureDetectorKt.awaitFirstDown$default(r6, r4, r7, r3, r5)
                if (r7 != r0) goto L6f
                return r0
            L6f:
                r17 = r6
                r6 = r2
                r2 = r7
                r7 = r17
            L75:
                androidx.compose.ui.input.pointer.PointerInputChange r2 = (androidx.compose.ui.input.pointer.PointerInputChange) r2
                r2.consume()
                long r8 = r2.m3029getPositionF1C5BW0()
                boolean r10 = r1.$vertical
                if (r10 == 0) goto L8b
                long r10 = r7.mo2945getSizeYbymL2g()
                int r10 = androidx.compose.ui.unit.IntSize.m4205getHeightimpl(r10)
                goto L93
            L8b:
                long r10 = r7.mo2945getSizeYbymL2g()
                int r10 = androidx.compose.ui.unit.IntSize.m4206getWidthimpl(r10)
            L93:
                float r10 = (float) r10
                vea.raceremote.control.LiveLiterals$DrivingPadKt r11 = vea.raceremote.control.LiveLiterals$DrivingPadKt.INSTANCE
                float r11 = r11.m6496Float$arg0$calldiv$$this$callminus$$$this$callcoerceAtLeast$valtravel$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad()
                float r10 = r10 / r11
                vea.raceremote.control.LiveLiterals$DrivingPadKt r11 = vea.raceremote.control.LiveLiterals$DrivingPadKt.INSTANCE
                int r11 = r11.m6503Int$$$this$call$getdp$$$$this$calltoPx$arg0$callminus$$$this$callcoerceAtLeast$valtravel$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad()
                r12 = 0
                float r13 = (float) r11
                float r11 = androidx.compose.ui.unit.Dp.m4046constructorimpl(r13)
                float r11 = r7.mo322toPx0680j_4(r11)
                float r10 = r10 - r11
                vea.raceremote.control.LiveLiterals$DrivingPadKt r11 = vea.raceremote.control.LiveLiterals$DrivingPadKt.INSTANCE
                float r11 = r11.m6489Float$arg0$callcoerceAtLeast$valtravel$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad()
                float r10 = kotlin.ranges.RangesKt.coerceAtLeast(r10, r11)
                androidx.compose.ui.platform.ViewConfiguration r11 = r7.getViewConfiguration()
                float r11 = r11.getTouchSlop()
                vea.raceremote.control.LiveLiterals$DrivingPadKt r12 = vea.raceremote.control.LiveLiterals$DrivingPadKt.INSTANCE
                int r12 = r12.m6510Int$arg0$calldiv$arg0$callcoerceAtMost$valdeadZone$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad()
                float r12 = (float) r12
                float r12 = r10 / r12
                float r11 = kotlin.ranges.RangesKt.coerceAtMost(r11, r12)
                androidx.compose.runtime.State<kotlin.jvm.functions.Function1<java.lang.Float, kotlin.Unit>> r12 = r1.$change$delegate     // Catch: java.lang.Throwable -> L270
                kotlin.jvm.functions.Function1 r12 = vea.raceremote.control.DrivingPadKt.access$DrivingPad$lambda$0(r12)     // Catch: java.lang.Throwable -> L270
                vea.raceremote.control.LiveLiterals$DrivingPadKt r13 = vea.raceremote.control.LiveLiterals$DrivingPadKt.INSTANCE     // Catch: java.lang.Throwable -> L270
                float r13 = r13.m6498Float$arg0$callinvoke$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad()     // Catch: java.lang.Throwable -> L270
                java.lang.Float r13 = kotlin.coroutines.jvm.internal.Boxing.boxFloat(r13)     // Catch: java.lang.Throwable -> L270
                r12.invoke(r13)     // Catch: java.lang.Throwable -> L270
                r17 = r10
                r10 = r2
                r2 = r6
                r6 = r11
                r11 = r7
                r7 = r17
            Le7:
                r12 = r1
                kotlin.coroutines.Continuation r12 = (kotlin.coroutines.Continuation) r12     // Catch: java.lang.Throwable -> L42
                r1.L$0 = r11     // Catch: java.lang.Throwable -> L42
                r1.L$1 = r10     // Catch: java.lang.Throwable -> L42
                r1.J$0 = r8     // Catch: java.lang.Throwable -> L42
                r1.F$0 = r7     // Catch: java.lang.Throwable -> L42
                r1.F$1 = r6     // Catch: java.lang.Throwable -> L42
                r13 = 2
                r1.label = r13     // Catch: java.lang.Throwable -> L42
                java.lang.Object r12 = androidx.compose.ui.input.pointer.AwaitPointerEventScope.awaitPointerEvent$default(r11, r5, r12, r3, r5)     // Catch: java.lang.Throwable -> L42
                if (r12 != r0) goto Lff
                return r0
            Lff:
                r17 = r6
                r6 = r2
                r2 = r12
                r12 = r11
                r11 = r10
                r9 = r8
                r8 = r7
                r7 = r17
            L109:
                androidx.compose.ui.input.pointer.PointerEvent r2 = (androidx.compose.ui.input.pointer.PointerEvent) r2     // Catch: java.lang.Throwable -> L26a
                java.util.List r13 = r2.getChanges()     // Catch: java.lang.Throwable -> L26a
                java.lang.Iterable r13 = (java.lang.Iterable) r13     // Catch: java.lang.Throwable -> L26a
                r2 = r13
                r13 = 0
                java.util.Iterator r14 = r2.iterator()     // Catch: java.lang.Throwable -> L26a
            L117:
                boolean r2 = r14.hasNext()     // Catch: java.lang.Throwable -> L26a
                if (r2 == 0) goto L13d
                java.lang.Object r2 = r14.next()     // Catch: java.lang.Throwable -> L26a
                r15 = r2
                androidx.compose.ui.input.pointer.PointerInputChange r15 = (androidx.compose.ui.input.pointer.PointerInputChange) r15     // Catch: java.lang.Throwable -> L26a
                r16 = 0
                long r3 = r15.m3028getIdJ3iCeTQ()     // Catch: java.lang.Throwable -> L26a
                r18 = r6
                long r5 = r11.m3028getIdJ3iCeTQ()     // Catch: java.lang.Throwable -> L266
                boolean r3 = androidx.compose.ui.input.pointer.PointerId.m3014equalsimpl0(r3, r5)     // Catch: java.lang.Throwable -> L266
                if (r3 == 0) goto L137
                goto L140
            L137:
                r3 = 1
                r4 = 0
                r5 = 0
                r6 = r18
                goto L117
            L13d:
                r18 = r6
                r2 = 0
            L140:
                androidx.compose.ui.input.pointer.PointerInputChange r2 = (androidx.compose.ui.input.pointer.PointerInputChange) r2     // Catch: java.lang.Throwable -> L266
                if (r2 != 0) goto L146
                goto L1fe
            L146:
                boolean r3 = r2.getPressed()     // Catch: java.lang.Throwable -> L266
                if (r3 == 0) goto L1fe
                boolean r3 = r2.isConsumed()     // Catch: java.lang.Throwable -> L266
                if (r3 != 0) goto L1fe
                long r3 = r12.mo2945getSizeYbymL2g()     // Catch: java.lang.Throwable -> L266
                int r3 = androidx.compose.ui.unit.IntSize.m4206getWidthimpl(r3)     // Catch: java.lang.Throwable -> L266
                float r3 = (float) r3     // Catch: java.lang.Throwable -> L266
                long r4 = r2.m3029getPositionF1C5BW0()     // Catch: java.lang.Throwable -> L266
                float r4 = androidx.compose.ui.geometry.Offset.m1425getXimpl(r4)     // Catch: java.lang.Throwable -> L266
                r5 = 0
                int r5 = (r5 > r4 ? 1 : (r5 == r4 ? 0 : -1))
                if (r5 > 0) goto L16e
                int r3 = (r4 > r3 ? 1 : (r4 == r3 ? 0 : -1))
                if (r3 > 0) goto L16e
                r3 = 1
                goto L16f
            L16e:
                r3 = 0
            L16f:
                if (r3 == 0) goto L1fe
                vea.raceremote.control.LiveLiterals$DrivingPadKt r3 = vea.raceremote.control.LiveLiterals$DrivingPadKt.INSTANCE     // Catch: java.lang.Throwable -> L266
                float r3 = r3.m6487Float$$$this$callrangeTo$$this$callcontains$$this$callnot$else$cond$if$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad()     // Catch: java.lang.Throwable -> L266
                long r4 = r12.mo2945getSizeYbymL2g()     // Catch: java.lang.Throwable -> L266
                int r4 = androidx.compose.ui.unit.IntSize.m4205getHeightimpl(r4)     // Catch: java.lang.Throwable -> L266
                float r4 = (float) r4     // Catch: java.lang.Throwable -> L266
                long r5 = r2.m3029getPositionF1C5BW0()     // Catch: java.lang.Throwable -> L266
                float r5 = androidx.compose.ui.geometry.Offset.m1426getYimpl(r5)     // Catch: java.lang.Throwable -> L266
                int r3 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1))
                if (r3 > 0) goto L192
                int r3 = (r5 > r4 ? 1 : (r5 == r4 ? 0 : -1))
                if (r3 > 0) goto L192
                r3 = 1
                goto L193
            L192:
                r3 = 0
            L193:
                if (r3 != 0) goto L196
                goto L1fe
            L196:
                boolean r3 = r1.$vertical     // Catch: java.lang.Throwable -> L266
                if (r3 == 0) goto L1a8
                float r3 = androidx.compose.ui.geometry.Offset.m1426getYimpl(r9)     // Catch: java.lang.Throwable -> L266
                long r4 = r2.m3029getPositionF1C5BW0()     // Catch: java.lang.Throwable -> L266
                float r4 = androidx.compose.ui.geometry.Offset.m1426getYimpl(r4)     // Catch: java.lang.Throwable -> L266
                float r3 = r3 - r4
                goto L1b5
            L1a8:
                long r3 = r2.m3029getPositionF1C5BW0()     // Catch: java.lang.Throwable -> L266
                float r3 = androidx.compose.ui.geometry.Offset.m1425getXimpl(r3)     // Catch: java.lang.Throwable -> L266
                float r4 = androidx.compose.ui.geometry.Offset.m1425getXimpl(r9)     // Catch: java.lang.Throwable -> L266
                float r3 = r3 - r4
            L1b5:
                float r4 = java.lang.Math.abs(r3)     // Catch: java.lang.Throwable -> L266
                int r4 = (r4 > r7 ? 1 : (r4 == r7 ? 0 : -1))
                if (r4 > 0) goto L1c4
                vea.raceremote.control.LiveLiterals$DrivingPadKt r4 = vea.raceremote.control.LiveLiterals$DrivingPadKt.INSTANCE     // Catch: java.lang.Throwable -> L266
                float r4 = r4.m6502Float$branch$if$valamount$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad()     // Catch: java.lang.Throwable -> L266
                goto L1e1
            L1c4:
                float r4 = java.lang.Math.signum(r3)     // Catch: java.lang.Throwable -> L266
                float r5 = java.lang.Math.abs(r3)     // Catch: java.lang.Throwable -> L266
                float r5 = r5 - r7
                float r3 = r8 - r7
                float r5 = r5 / r3
                vea.raceremote.control.LiveLiterals$DrivingPadKt r3 = vea.raceremote.control.LiveLiterals$DrivingPadKt.INSTANCE     // Catch: java.lang.Throwable -> L266
                float r3 = r3.m6491Float$arg0$callcoerceIn$arg0$calltimes$else$if$valamount$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad()     // Catch: java.lang.Throwable -> L266
                vea.raceremote.control.LiveLiterals$DrivingPadKt r6 = vea.raceremote.control.LiveLiterals$DrivingPadKt.INSTANCE     // Catch: java.lang.Throwable -> L266
                float r6 = r6.m6501Float$arg1$callcoerceIn$arg0$calltimes$else$if$valamount$body$loop$try$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad()     // Catch: java.lang.Throwable -> L266
                float r3 = kotlin.ranges.RangesKt.coerceIn(r5, r3, r6)     // Catch: java.lang.Throwable -> L266
                float r4 = r4 * r3
            L1e1:
                r3 = r4
                r2.consume()     // Catch: java.lang.Throwable -> L266
                androidx.compose.runtime.State<kotlin.jvm.functions.Function1<java.lang.Float, kotlin.Unit>> r4 = r1.$change$delegate     // Catch: java.lang.Throwable -> L266
                kotlin.jvm.functions.Function1 r4 = vea.raceremote.control.DrivingPadKt.access$DrivingPad$lambda$0(r4)     // Catch: java.lang.Throwable -> L266
                java.lang.Float r5 = kotlin.coroutines.jvm.internal.Boxing.boxFloat(r3)     // Catch: java.lang.Throwable -> L266
                r4.invoke(r5)     // Catch: java.lang.Throwable -> L266
                r2 = r18
                r6 = r7
                r7 = r8
                r8 = r9
                r10 = r11
                r11 = r12
                r3 = 1
                r4 = 0
                r5 = 0
                goto Le7
            L1fe:
                androidx.compose.runtime.State<kotlin.jvm.functions.Function1<java.lang.Float, kotlin.Unit>> r2 = r1.$change$delegate
                kotlin.jvm.functions.Function1 r2 = vea.raceremote.control.DrivingPadKt.access$DrivingPad$lambda$0(r2)
                vea.raceremote.control.LiveLiterals$DrivingPadKt r3 = vea.raceremote.control.LiveLiterals$DrivingPadKt.INSTANCE
                float r3 = r3.m6497Float$arg0$callinvoke$finally$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad()
                java.lang.Float r3 = kotlin.coroutines.jvm.internal.Boxing.boxFloat(r3)
                r2.invoke(r3)
                r2 = r18
                r6 = r12
            L214:
                androidx.compose.ui.input.pointer.PointerEvent r3 = r6.getCurrentEvent()
                java.util.List r3 = r3.getChanges()
                java.lang.Iterable r3 = (java.lang.Iterable) r3
                r4 = 0
                boolean r5 = r3 instanceof java.util.Collection
                if (r5 == 0) goto L22e
                r5 = r3
                java.util.Collection r5 = (java.util.Collection) r5
                boolean r5 = r5.isEmpty()
                if (r5 == 0) goto L22e
                r3 = 0
                goto L249
            L22e:
                java.util.Iterator r5 = r3.iterator()
            L232:
                boolean r3 = r5.hasNext()
                if (r3 == 0) goto L248
                java.lang.Object r3 = r5.next()
                r7 = r3
                androidx.compose.ui.input.pointer.PointerInputChange r7 = (androidx.compose.ui.input.pointer.PointerInputChange) r7
                r8 = 0
                boolean r7 = r7.getPressed()
                if (r7 == 0) goto L232
                r3 = 1
                goto L249
            L248:
                r3 = 0
            L249:
                if (r3 == 0) goto L25f
                r3 = r1
                kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3
                r1.L$0 = r6
                r4 = 0
                r1.L$1 = r4
                r5 = 3
                r1.label = r5
                r5 = 1
                java.lang.Object r3 = androidx.compose.ui.input.pointer.AwaitPointerEventScope.awaitPointerEvent$default(r6, r4, r3, r5, r4)
                if (r3 != r0) goto L25e
                return r0
            L25e:
                goto L214
            L25f:
                r4 = 0
                r5 = 1
                r3 = r5
                r5 = r4
                r4 = 0
                goto L5e
            L266:
                r0 = move-exception
                r2 = r18
                goto L272
            L26a:
                r0 = move-exception
                r18 = r6
                r2 = r18
                goto L272
            L270:
                r0 = move-exception
                r2 = r6
            L272:
                androidx.compose.runtime.State<kotlin.jvm.functions.Function1<java.lang.Float, kotlin.Unit>> r3 = r1.$change$delegate
                kotlin.jvm.functions.Function1 r3 = vea.raceremote.control.DrivingPadKt.access$DrivingPad$lambda$0(r3)
                vea.raceremote.control.LiveLiterals$DrivingPadKt r4 = vea.raceremote.control.LiveLiterals$DrivingPadKt.INSTANCE
                float r4 = r4.m6497Float$arg0$callinvoke$finally$body$loop$fun$anonymous$$arg0$callawaitPointerEventScope$fun$anonymous$$arg2$callpointerInput$arg0$callCanvas$fun$anonymous$$arg3$callColumn$funDrivingPad()
                java.lang.Float r4 = kotlin.coroutines.jvm.internal.Boxing.boxFloat(r4)
                r3.invoke(r4)
                throw r0
        }
    }

    DrivingPadKt$DrivingPad$1$2$1(boolean r2, boolean r3, androidx.compose.runtime.State<? extends kotlin.jvm.functions.Function1<? super java.lang.Float, kotlin.Unit>> r4, kotlin.coroutines.Continuation<? super vea.raceremote.control.DrivingPadKt$DrivingPad$1$2$1> r5) {
            r1 = this;
            r1.$enabled = r2
            r1.$vertical = r3
            r1.$change$delegate = r4
            r0 = 2
            r1.<init>(r0, r5)
            return
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object r5, kotlin.coroutines.Continuation<?> r6) {
            r4 = this;
            vea.raceremote.control.DrivingPadKt$DrivingPad$1$2$1 r0 = new vea.raceremote.control.DrivingPadKt$DrivingPad$1$2$1
            boolean r1 = r4.$enabled
            boolean r2 = r4.$vertical
            androidx.compose.runtime.State<kotlin.jvm.functions.Function1<java.lang.Float, kotlin.Unit>> r3 = r4.$change$delegate
            r0.<init>(r1, r2, r3, r6)
            r0.L$0 = r5
            kotlin.coroutines.Continuation r0 = (kotlin.coroutines.Continuation) r0
            return r0
    }

    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
    public final java.lang.Object invoke2(androidx.compose.ui.input.pointer.PointerInputScope r3, kotlin.coroutines.Continuation<? super kotlin.Unit> r4) {
            r2 = this;
            kotlin.coroutines.Continuation r0 = r2.create(r3, r4)
            vea.raceremote.control.DrivingPadKt$DrivingPad$1$2$1 r0 = (vea.raceremote.control.DrivingPadKt$DrivingPad$1$2$1) r0
            kotlin.Unit r1 = kotlin.Unit.INSTANCE
            java.lang.Object r0 = r0.invokeSuspend(r1)
            return r0
    }

    @Override // kotlin.jvm.functions.Function2
    public /* bridge */ /* synthetic */ java.lang.Object invoke(androidx.compose.ui.input.pointer.PointerInputScope r2, kotlin.coroutines.Continuation<? super kotlin.Unit> r3) {
            r1 = this;
            androidx.compose.ui.input.pointer.PointerInputScope r2 = (androidx.compose.ui.input.pointer.PointerInputScope) r2
            kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3
            java.lang.Object r0 = r1.invoke2(r2, r3)
            return r0
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object invokeSuspend(java.lang.Object r8) {
            r7 = this;
            java.lang.Object r0 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
            int r1 = r7.label
            switch(r1) {
                case 0: goto L16;
                case 1: goto L11;
                default: goto L9;
            }
        L9:
            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r8.<init>(r0)
            throw r8
        L11:
            r0 = r7
            kotlin.ResultKt.throwOnFailure(r8)
            goto L3f
        L16:
            kotlin.ResultKt.throwOnFailure(r8)
            r1 = r7
            java.lang.Object r2 = r1.L$0
            androidx.compose.ui.input.pointer.PointerInputScope r2 = (androidx.compose.ui.input.pointer.PointerInputScope) r2
            boolean r3 = r1.$enabled
            if (r3 != 0) goto L25
            kotlin.Unit r0 = kotlin.Unit.INSTANCE
            return r0
        L25:
            vea.raceremote.control.DrivingPadKt$DrivingPad$1$2$1$1 r3 = new vea.raceremote.control.DrivingPadKt$DrivingPad$1$2$1$1
            boolean r4 = r1.$vertical
            androidx.compose.runtime.State<kotlin.jvm.functions.Function1<java.lang.Float, kotlin.Unit>> r5 = r1.$change$delegate
            r6 = 0
            r3.<init>(r4, r5, r6)
            kotlin.jvm.functions.Function2 r3 = (kotlin.jvm.functions.Function2) r3
            r4 = r1
            kotlin.coroutines.Continuation r4 = (kotlin.coroutines.Continuation) r4
            r5 = 1
            r1.label = r5
            java.lang.Object r2 = r2.awaitPointerEventScope(r3, r4)
            if (r2 != r0) goto L3e
            return r0
        L3e:
            r0 = r1
        L3f:
            kotlin.Unit r1 = kotlin.Unit.INSTANCE
            return r1
    }
}
