package vea.raceremote.control;

/* JADX INFO: compiled from: UdpControlClient.kt */
/* JADX INFO: loaded from: classes4.dex */
@kotlin.Metadata(d1 = {"\u0000^\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001BO\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007\u0012\u0014\b\u0002\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\t0\u0007\u0012\u000e\b\u0002\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\u00050\f¢\u0006\u0002\u0010\rJ\b\u0010\u0019\u001a\u00020\tH\u0016J\u0016\u0010\u001a\u001a\u00020\t2\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u001cJ\b\u0010\u001e\u001a\u00020\tH\u0002J\u0006\u0010\u001f\u001a\u00020 R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\u00050\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\t0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0016\u001a\u0004\u0018\u00010\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0018X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006!"}, d2 = {"Lvea/raceremote/control/UdpControlClient;", "Ljava/io/Closeable;", "host", "", "chipId", "", "bindSocket", "Lkotlin/Function1;", "Ljava/net/DatagramSocket;", "", "diagnostics", "clockMs", "Lkotlin/Function0;", "(Ljava/lang/String;JLkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;)V", "address", "Ljava/net/InetAddress;", "closing", "Ljava/util/concurrent/atomic/AtomicBoolean;", "lock", "", "session", "Lvea/raceremote/control/UdpControlSession;", "socket", "worker", "Ljava/lang/Thread;", "close", "input", "throttle", "", "steering", "run", "snapshot", "Lvea/raceremote/control/UdpControlSession$Snapshot;", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class UdpControlClient implements java.io.Closeable {
    public static final int $stable = 0;
    private final java.net.InetAddress address;
    private final kotlin.jvm.functions.Function1<java.net.DatagramSocket, kotlin.Unit> bindSocket;
    private final kotlin.jvm.functions.Function0<java.lang.Long> clockMs;
    private final java.util.concurrent.atomic.AtomicBoolean closing;
    private final kotlin.jvm.functions.Function1<java.lang.String, kotlin.Unit> diagnostics;
    private final java.lang.Object lock;
    private final vea.raceremote.control.UdpControlSession session;
    private volatile java.net.DatagramSocket socket;
    private final java.lang.Thread worker;



    /* JADX INFO: renamed from: $r8$lambda$mTlEKf43U1jvZ6X-4CgNJAaHe64, reason: not valid java name */
    public static /* synthetic */ void m6779$r8$lambda$mTlEKf43U1jvZ6X4CgNJAaHe64(vea.raceremote.control.UdpControlClient r0) {
            _init_$lambda$3(r0)
            return
    }

    static {
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r0 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE
            int r0 = r0.m6559Int$classUdpControlClient()
            vea.raceremote.control.UdpControlClient.$stable = r0
            return
    }

    public UdpControlClient(java.lang.String r21, long r22, kotlin.jvm.functions.Function1<? super java.net.DatagramSocket, kotlin.Unit> r24, kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> r25, kotlin.jvm.functions.Function0<java.lang.Long> r26) {
            r20 = this;
            r0 = r20
            r1 = r21
            r2 = r24
            r3 = r25
            r4 = r26
            java.lang.String r5 = "host"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r1, r5)
            java.lang.String r5 = "bindSocket"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r5)
            java.lang.String r5 = "diagnostics"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r5)
            java.lang.String r5 = "clockMs"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r5)
            r20.<init>()
            r0.bindSocket = r2
            r0.diagnostics = r3
            r0.clockMs = r4
            java.util.concurrent.atomic.AtomicBoolean r5 = new java.util.concurrent.atomic.AtomicBoolean
            r6 = 0
            r5.<init>(r6)
            r0.closing = r5
            java.lang.Object r5 = new java.lang.Object
            r5.<init>()
            r0.lock = r5
            r7 = r1
            java.lang.CharSequence r7 = (java.lang.CharSequence) r7
            r5 = 1
            char[] r8 = new char[r5]
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r9 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE
            char r9 = r9.m6545Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$classUdpControlClient()
            r8[r6] = r9
            r9 = 0
            r10 = 0
            r11 = 6
            r12 = 0
            java.util.List r7 = kotlin.text.StringsKt.split$default(r7, r8, r9, r10, r11, r12)
            java.lang.Iterable r7 = (java.lang.Iterable) r7
            r8 = 0
            java.util.ArrayList r9 = new java.util.ArrayList
            r10 = 10
            int r11 = kotlin.collections.CollectionsKt.collectionSizeOrDefault(r7, r10)
            r9.<init>(r11)
            java.util.Collection r9 = (java.util.Collection) r9
            r11 = r7
            r12 = 0
            java.util.Iterator r13 = r11.iterator()
        L63:
            boolean r14 = r13.hasNext()
            if (r14 == 0) goto L7a
            java.lang.Object r14 = r13.next()
            r15 = r14
            java.lang.String r15 = (java.lang.String) r15
            r16 = 0
            java.lang.Integer r15 = kotlin.text.StringsKt.toIntOrNull(r15)
            r9.add(r15)
            goto L63
        L7a:
            java.util.List r9 = (java.util.List) r9
            r7 = r9
            int r8 = r7.size()
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r9 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE
            int r9 = r9.m6556Int$arg1$callEQEQ$cond$cond$arg0$callrequire$classUdpControlClient()
            if (r8 != r9) goto L169
            r8 = r7
            java.lang.Iterable r8 = (java.lang.Iterable) r8
            r9 = 0
            boolean r11 = r8 instanceof java.util.Collection
            if (r11 == 0) goto L9d
            r11 = r8
            java.util.Collection r11 = (java.util.Collection) r11
            boolean r11 = r11.isEmpty()
            if (r11 == 0) goto L9d
            goto Ld8
        L9d:
            java.util.Iterator r11 = r8.iterator()
        La1:
            boolean r12 = r11.hasNext()
            if (r12 == 0) goto Ld7
            java.lang.Object r12 = r11.next()
            r13 = r12
            java.lang.Integer r13 = (java.lang.Integer) r13
            r14 = 0
            if (r13 == 0) goto Lce
            kotlin.ranges.IntRange r15 = new kotlin.ranges.IntRange
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r16 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE
            int r5 = r16.m6547Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$arg0$callrequire$classUdpControlClient()
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r16 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE
            int r10 = r16.m6554Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$arg0$callrequire$classUdpControlClient()
            r15.<init>(r5, r10)
            int r5 = r13.intValue()
            boolean r5 = r15.contains(r5)
            if (r5 == 0) goto Lce
            r5 = 1
            goto Lcf
        Lce:
            r5 = r6
        Lcf:
            if (r5 != 0) goto Ld3
            r5 = r6
            goto Ld8
        Ld3:
            r5 = 1
            r10 = 10
            goto La1
        Ld7:
            r5 = 1
        Ld8:
            if (r5 == 0) goto L169
            java.lang.Object r5 = r7.get(r6)
            java.lang.Integer r5 = (java.lang.Integer) r5
            if (r5 != 0) goto Le3
            goto Leb
        Le3:
            int r5 = r5.intValue()
            r8 = 10
            if (r5 == r8) goto L166
        Leb:
            java.lang.Object r5 = r7.get(r6)
            java.lang.Integer r5 = (java.lang.Integer) r5
            if (r5 != 0) goto Lf4
            goto Lfc
        Lf4:
            int r5 = r5.intValue()
            r8 = 127(0x7f, float:1.78E-43)
            if (r5 == r8) goto L166
        Lfc:
            java.lang.Object r5 = r7.get(r6)
            java.lang.Integer r5 = (java.lang.Integer) r5
            if (r5 != 0) goto L106
            r5 = 1
            goto L122
        L106:
            int r5 = r5.intValue()
            r8 = 192(0xc0, float:2.69E-43)
            if (r5 != r8) goto L121
            r5 = 1
            java.lang.Object r8 = r7.get(r5)
            java.lang.Integer r8 = (java.lang.Integer) r8
            if (r8 != 0) goto L118
            goto L120
        L118:
            int r8 = r8.intValue()
            r9 = 168(0xa8, float:2.35E-43)
            if (r8 == r9) goto L167
        L120:
            goto L122
        L121:
            r5 = 1
        L122:
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r8 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE
            int r8 = r8.m6551Int$arg0$callget$arg0$callEQEQ$cond$else$branch$arg0$callrequire$classUdpControlClient()
            java.lang.Object r8 = r7.get(r8)
            java.lang.Integer r8 = (java.lang.Integer) r8
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r9 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE
            int r9 = r9.m6557Int$arg1$callEQEQ$cond$else$branch$arg0$callrequire$classUdpControlClient()
            if (r8 != 0) goto L137
            goto L169
        L137:
            int r8 = r8.intValue()
            if (r8 != r9) goto L169
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r8 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE
            int r8 = r8.m6546Int$$this$callrangeTo$$this$callcontains$branch$else$branch$arg0$callrequire$classUdpControlClient()
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r9 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE
            int r9 = r9.m6553Int$arg0$callrangeTo$$this$callcontains$branch$else$branch$arg0$callrequire$classUdpControlClient()
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r10 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE
            int r10 = r10.m6550Int$arg0$callget$arg0$callCHECK_NOT_NULL$arg0$callcontains$branch$else$branch$arg0$callrequire$classUdpControlClient()
            java.lang.Object r10 = r7.get(r10)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r10)
            java.lang.Number r10 = (java.lang.Number) r10
            int r10 = r10.intValue()
            if (r8 > r10) goto L162
            if (r10 > r9) goto L162
            r8 = r5
            goto L163
        L162:
            r8 = r6
        L163:
            if (r8 == 0) goto L169
            goto L167
        L166:
            r5 = 1
        L167:
            r6 = r5
            goto L16a
        L169:
        L16a:
            if (r6 == 0) goto L1cf
            java.net.InetAddress r5 = java.net.InetAddress.getByName(r21)
            java.lang.String r6 = "getByName(host)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r5, r6)
            r0.address = r5
            r5 = 0
            java.security.SecureRandom r8 = new java.security.SecureRandom
            r8.<init>()
        L17e:
            int r9 = r8.nextInt()
            long r9 = (long) r9
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r11 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE
            long r11 = r11.m6560Long$arg0$calland$setattempt$body$loop$classUdpControlClient()
            long r5 = r9 & r11
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r9 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE
            long r9 = r9.m6563Long$arg1$callEQEQ$cond$loop$classUdpControlClient()
            int r9 = (r5 > r9 ? 1 : (r5 == r9 ? 0 : -1))
            if (r9 == 0) goto L17e
            vea.raceremote.control.UdpControlSession r9 = new vea.raceremote.control.UdpControlSession
            kotlin.jvm.functions.Function0<java.lang.Long> r10 = r0.clockMs
            java.lang.Object r10 = r10.invoke()
            java.lang.Number r10 = (java.lang.Number) r10
            long r18 = r10.longValue()
            r13 = r9
            r14 = r22
            r16 = r5
            r13.<init>(r14, r16, r18)
            r0.session = r9
            java.lang.Thread r9 = new java.lang.Thread
            vea.raceremote.control.UdpControlClient$$ExternalSyntheticLambda0 r10 = new vea.raceremote.control.UdpControlClient$$ExternalSyntheticLambda0
            r10.<init>(r0)
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r11 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE
            java.lang.String r11 = r11.m6572String$arg1$call$init$$$$this$callapply$setworker$classUdpControlClient()
            r9.<init>(r10, r11)
            r10 = r9
            r11 = 0
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r12 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE
            boolean r12 = r12.m6544Boolean$arg0$callsetDaemon$fun$anonymous$$arg0$callapply$setworker$classUdpControlClient()
            r10.setDaemon(r12)
            r10.start()
            r0.worker = r9
            return
        L1cf:
            r5 = 0
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r6 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE
            java.lang.String r5 = r6.m6573String$fun$anonymous$$arg1$callrequire$classUdpControlClient()
            java.lang.IllegalArgumentException r6 = new java.lang.IllegalArgumentException
            java.lang.String r5 = r5.toString()
            r6.<init>(r5)
            throw r6
    }

    public /* synthetic */ UdpControlClient(java.lang.String r8, long r9, kotlin.jvm.functions.Function1 r11, kotlin.jvm.functions.Function1 r12, kotlin.jvm.functions.Function0 r13, int r14, kotlin.jvm.internal.DefaultConstructorMarker r15) {
            r7 = this;
            r15 = r14 & 8
            if (r15 == 0) goto La
            vea.raceremote.control.UdpControlClient$1 r12 = vea.raceremote.control.UdpControlClient.AnonymousClass1.INSTANCE
            kotlin.jvm.functions.Function1 r12 = (kotlin.jvm.functions.Function1) r12
            r5 = r12
            goto Lb
        La:
            r5 = r12
        Lb:
            r12 = r14 & 16
            if (r12 == 0) goto L16
            vea.raceremote.control.UdpControlClient$2 r12 = vea.raceremote.control.UdpControlClient.AnonymousClass2.INSTANCE
            r13 = r12
            kotlin.jvm.functions.Function0 r13 = (kotlin.jvm.functions.Function0) r13
            r6 = r13
            goto L17
        L16:
            r6 = r13
        L17:
            r0 = r7
            r1 = r8
            r2 = r9
            r4 = r11
            r0.<init>(r1, r2, r4, r5, r6)
            return
    }

    private static final void _init_$lambda$3(vea.raceremote.control.UdpControlClient r1) {
            java.lang.String r0 = "this$0"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r1, r0)
            r1.run()
            return
    }

    private final void run() {
            r14 = this;
            r0 = 1
            r1 = 0
            java.net.DatagramSocket r2 = new java.net.DatagramSocket     // Catch: java.lang.Throwable -> L15e java.lang.Exception -> L161
            r2.<init>()     // Catch: java.lang.Throwable -> L15e java.lang.Exception -> L161
            java.io.Closeable r2 = (java.io.Closeable) r2     // Catch: java.lang.Throwable -> L15e java.lang.Exception -> L161
            r3 = r2
            java.net.DatagramSocket r3 = (java.net.DatagramSocket) r3     // Catch: java.lang.Throwable -> L157
            r4 = 0
            r14.socket = r3     // Catch: java.lang.Throwable -> L157
            kotlin.jvm.functions.Function1<java.net.DatagramSocket, kotlin.Unit> r5 = r14.bindSocket     // Catch: java.lang.Throwable -> L157
            r5.invoke(r3)     // Catch: java.lang.Throwable -> L157
            java.net.InetAddress r5 = r14.address     // Catch: java.lang.Throwable -> L157
            r6 = 3334(0xd06, float:4.672E-42)
            r3.connect(r5, r6)     // Catch: java.lang.Throwable -> L157
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r5 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L157
            int r5 = r5.m6555Int$arg0$callsetSoTimeout$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient()     // Catch: java.lang.Throwable -> L157
            r3.setSoTimeout(r5)     // Catch: java.lang.Throwable -> L157
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r5 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L157
            int r5 = r5.m6548Int$arg0$call$init$$valbuffer$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient()     // Catch: java.lang.Throwable -> L157
            byte[] r5 = new byte[r5]     // Catch: java.lang.Throwable -> L157
        L2d:
            java.lang.Object r6 = r14.lock     // Catch: java.lang.Throwable -> L157
            monitor-enter(r6)     // Catch: java.lang.Throwable -> L157
            r7 = 0
            java.util.concurrent.atomic.AtomicBoolean r8 = r14.closing     // Catch: java.lang.Throwable -> L154
            boolean r8 = r8.get()     // Catch: java.lang.Throwable -> L154
            if (r8 == 0) goto L3f
            vea.raceremote.control.UdpControlSession r8 = r14.session     // Catch: java.lang.Throwable -> L154
            vea.raceremote.control.UdpControlSession.stop$default(r8, r1, r0, r1)     // Catch: java.lang.Throwable -> L154
        L3f:
            vea.raceremote.control.UdpControlSession r8 = r14.session     // Catch: java.lang.Throwable -> L154
            kotlin.jvm.functions.Function0<java.lang.Long> r9 = r14.clockMs     // Catch: java.lang.Throwable -> L154
            java.lang.Object r9 = r9.invoke()     // Catch: java.lang.Throwable -> L154
            java.lang.Number r9 = (java.lang.Number) r9     // Catch: java.lang.Throwable -> L154
            long r9 = r9.longValue()     // Catch: java.lang.Throwable -> L154
            vea.raceremote.control.UdpControlPacket r8 = r8.next(r9)     // Catch: java.lang.Throwable -> L154
            monitor-exit(r6)     // Catch: java.lang.Throwable -> L157
            r6 = r8
            if (r6 == 0) goto La6
            byte[] r7 = r6.encode()     // Catch: java.lang.Throwable -> L157
            java.net.DatagramPacket r8 = new java.net.DatagramPacket     // Catch: java.lang.Throwable -> L157
            int r9 = r7.length     // Catch: java.lang.Throwable -> L157
            r8.<init>(r7, r9)     // Catch: java.lang.Throwable -> L157
            r3.send(r8)     // Catch: java.lang.Throwable -> L157
            kotlin.jvm.functions.Function1<java.lang.String, kotlin.Unit> r8 = r14.diagnostics     // Catch: java.lang.Throwable -> L157
            java.lang.StringBuilder r9 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L157
            r9.<init>()     // Catch: java.lang.Throwable -> L157
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r10 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L157
            java.lang.String r10 = r10.m6564String$0$str$arg0$callinvoke$branch$if$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient()     // Catch: java.lang.Throwable -> L157
            java.lang.StringBuilder r9 = r9.append(r10)     // Catch: java.lang.Throwable -> L157
            int r10 = r6.getKind()     // Catch: java.lang.Throwable -> L157
            java.lang.StringBuilder r9 = r9.append(r10)     // Catch: java.lang.Throwable -> L157
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r10 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L157
            java.lang.String r10 = r10.m6569String$2$str$arg0$callinvoke$branch$if$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient()     // Catch: java.lang.Throwable -> L157
            java.lang.StringBuilder r9 = r9.append(r10)     // Catch: java.lang.Throwable -> L157
            long r10 = r6.getSequence()     // Catch: java.lang.Throwable -> L157
            java.lang.StringBuilder r9 = r9.append(r10)     // Catch: java.lang.Throwable -> L157
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r10 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L157
            java.lang.String r10 = r10.m6571String$4$str$arg0$callinvoke$branch$if$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient()     // Catch: java.lang.Throwable -> L157
            java.lang.StringBuilder r9 = r9.append(r10)     // Catch: java.lang.Throwable -> L157
            long r10 = r6.getBasis()     // Catch: java.lang.Throwable -> L157
            java.lang.StringBuilder r9 = r9.append(r10)     // Catch: java.lang.Throwable -> L157
            java.lang.String r9 = r9.toString()     // Catch: java.lang.Throwable -> L157
            r8.invoke(r9)     // Catch: java.lang.Throwable -> L157
        La6:
            vea.raceremote.control.UdpControlSession$Snapshot r7 = r14.snapshot()     // Catch: java.lang.Throwable -> L157
            vea.raceremote.control.UdpControlSession$Phase r7 = r7.getPhase()     // Catch: java.lang.Throwable -> L157
            vea.raceremote.control.UdpControlSession$Phase r8 = vea.raceremote.control.UdpControlSession.Phase.CLOSED     // Catch: java.lang.Throwable -> L157
            if (r7 == r8) goto L135
        Lb3:
            java.net.DatagramPacket r7 = new java.net.DatagramPacket     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            int r8 = r5.length     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            r7.<init>(r5, r8)     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            r3.receive(r7)     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            vea.raceremote.control.UdpControlPacket$Companion r8 = vea.raceremote.control.UdpControlPacket.Companion     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            byte[] r9 = r7.getData()     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            java.lang.String r10 = "datagram.data"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r9, r10)     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            int r10 = r7.getLength()     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            byte[] r9 = java.util.Arrays.copyOf(r9, r10)     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            java.lang.String r10 = "copyOf(this, newSize)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r9, r10)     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            vea.raceremote.control.UdpControlPacket r8 = r8.decode(r9)     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            java.lang.Object r9 = r14.lock     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            monitor-enter(r9)     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            r10 = 0
            if (r8 == 0) goto Lf7
            vea.raceremote.control.UdpControlSession r11 = r14.session     // Catch: java.lang.Throwable -> Lf4
            kotlin.jvm.functions.Function0<java.lang.Long> r12 = r14.clockMs     // Catch: java.lang.Throwable -> Lf4
            java.lang.Object r12 = r12.invoke()     // Catch: java.lang.Throwable -> Lf4
            java.lang.Number r12 = (java.lang.Number) r12     // Catch: java.lang.Throwable -> Lf4
            long r12 = r12.longValue()     // Catch: java.lang.Throwable -> Lf4
            boolean r11 = r11.receive(r8, r12)     // Catch: java.lang.Throwable -> Lf4
            if (r11 == 0) goto Lf7
            r11 = r0
            goto Lf8
        Lf4:
            r10 = move-exception
            monitor-exit(r9)     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            throw r10     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
        Lf7:
            r11 = 0
        Lf8:
            monitor-exit(r9)     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            r9 = r11
            kotlin.jvm.functions.Function1<java.lang.String, kotlin.Unit> r10 = r14.diagnostics     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            java.lang.StringBuilder r11 = new java.lang.StringBuilder     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            r11.<init>()     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r12 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            java.lang.String r12 = r12.m6567String$0$str$arg0$callinvoke$try$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient()     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            java.lang.StringBuilder r11 = r11.append(r12)     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            if (r8 == 0) goto L116
            long r12 = r8.getSequence()     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            java.lang.Long r12 = java.lang.Long.valueOf(r12)     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            goto L117
        L116:
            r12 = r1
        L117:
            java.lang.StringBuilder r11 = r11.append(r12)     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r12 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            java.lang.String r12 = r12.m6570String$2$str$arg0$callinvoke$try$body$loop$fun$anonymous$$arg0$calluse$try$funrun$classUdpControlClient()     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            java.lang.StringBuilder r11 = r11.append(r12)     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            java.lang.StringBuilder r11 = r11.append(r9)     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            java.lang.String r11 = r11.toString()     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            r10.invoke(r11)     // Catch: java.net.SocketTimeoutException -> L132 java.lang.Throwable -> L157
            goto L2d
        L132:
            r7 = move-exception
            goto L2d
        L135:
            kotlin.Unit r3 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L157
            kotlin.io.CloseableKt.closeFinally(r2, r1)     // Catch: java.lang.Throwable -> L15e java.lang.Exception -> L161
            r14.socket = r1
            java.lang.Object r2 = r14.lock
            monitor-enter(r2)
            r3 = 0
            vea.raceremote.control.UdpControlSession r4 = r14.session     // Catch: java.lang.Throwable -> L151
            vea.raceremote.control.UdpControlSession.stop$default(r4, r1, r0, r1)     // Catch: java.lang.Throwable -> L151
            kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L151
            monitor-exit(r2)
            kotlin.jvm.functions.Function1<java.lang.String, kotlin.Unit> r0 = r14.diagnostics
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            goto L1c7
        L151:
            r0 = move-exception
            monitor-exit(r2)
            throw r0
        L154:
            r7 = move-exception
            monitor-exit(r6)     // Catch: java.lang.Throwable -> L157
            throw r7     // Catch: java.lang.Throwable -> L157
        L157:
            r3 = move-exception
            throw r3     // Catch: java.lang.Throwable -> L159
        L159:
            r4 = move-exception
            kotlin.io.CloseableKt.closeFinally(r2, r3)     // Catch: java.lang.Throwable -> L15e java.lang.Exception -> L161
            throw r4     // Catch: java.lang.Throwable -> L15e java.lang.Exception -> L161
        L15e:
            r2 = move-exception
            goto L1ec
        L161:
            r2 = move-exception
            java.lang.Object r3 = r14.lock     // Catch: java.lang.Throwable -> L15e
            monitor-enter(r3)     // Catch: java.lang.Throwable -> L15e
            r4 = 0
            vea.raceremote.control.UdpControlSession r5 = r14.session     // Catch: java.lang.Throwable -> L1e9
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L1e9
            r6.<init>()     // Catch: java.lang.Throwable -> L1e9
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r7 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L1e9
            java.lang.String r7 = r7.m6568String$0$str$arg0$callstop$fun$anonymous$$arg1$callsynchronized$catch$funrun$classUdpControlClient()     // Catch: java.lang.Throwable -> L1e9
            java.lang.StringBuilder r6 = r6.append(r7)     // Catch: java.lang.Throwable -> L1e9
            java.lang.Class r7 = r2.getClass()     // Catch: java.lang.Throwable -> L1e9
            java.lang.String r7 = r7.getSimpleName()     // Catch: java.lang.Throwable -> L1e9
            java.lang.StringBuilder r6 = r6.append(r7)     // Catch: java.lang.Throwable -> L1e9
            java.lang.String r6 = r6.toString()     // Catch: java.lang.Throwable -> L1e9
            r5.stop(r6)     // Catch: java.lang.Throwable -> L1e9
            kotlin.Unit r4 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L1e9
            monitor-exit(r3)     // Catch: java.lang.Throwable -> L15e
            kotlin.jvm.functions.Function1<java.lang.String, kotlin.Unit> r3 = r14.diagnostics     // Catch: java.lang.Throwable -> L15e
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L15e
            r4.<init>()     // Catch: java.lang.Throwable -> L15e
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r5 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L15e
            java.lang.String r5 = r5.m6565String$0$str$arg0$callinvoke$catch$funrun$classUdpControlClient()     // Catch: java.lang.Throwable -> L15e
            java.lang.StringBuilder r4 = r4.append(r5)     // Catch: java.lang.Throwable -> L15e
            java.lang.Class r5 = r2.getClass()     // Catch: java.lang.Throwable -> L15e
            java.lang.String r5 = r5.getSimpleName()     // Catch: java.lang.Throwable -> L15e
            java.lang.StringBuilder r4 = r4.append(r5)     // Catch: java.lang.Throwable -> L15e
            java.lang.String r4 = r4.toString()     // Catch: java.lang.Throwable -> L15e
            r3.invoke(r4)     // Catch: java.lang.Throwable -> L15e
            r14.socket = r1
            java.lang.Object r2 = r14.lock
            monitor-enter(r2)
            r3 = 0
            vea.raceremote.control.UdpControlSession r4 = r14.session     // Catch: java.lang.Throwable -> L1e6
            vea.raceremote.control.UdpControlSession.stop$default(r4, r1, r0, r1)     // Catch: java.lang.Throwable -> L1e6
            kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L1e6
            monitor-exit(r2)
            kotlin.jvm.functions.Function1<java.lang.String, kotlin.Unit> r0 = r14.diagnostics
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
        L1c7:
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r2 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE
            java.lang.String r2 = r2.m6566String$0$str$arg0$callinvoke$finally$funrun$classUdpControlClient()
            java.lang.StringBuilder r1 = r1.append(r2)
            vea.raceremote.control.UdpControlSession$Snapshot r2 = r14.snapshot()
            java.lang.String r2 = r2.getReason()
            java.lang.StringBuilder r1 = r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.invoke(r1)
            return
        L1e6:
            r0 = move-exception
            monitor-exit(r2)
            throw r0
        L1e9:
            r4 = move-exception
            monitor-exit(r3)     // Catch: java.lang.Throwable -> L15e
            throw r4     // Catch: java.lang.Throwable -> L15e
        L1ec:
            r14.socket = r1
            java.lang.Object r3 = r14.lock
            monitor-enter(r3)
            r4 = 0
            vea.raceremote.control.UdpControlSession r5 = r14.session     // Catch: java.lang.Throwable -> L21f
            vea.raceremote.control.UdpControlSession.stop$default(r5, r1, r0, r1)     // Catch: java.lang.Throwable -> L21f
            kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L21f
            monitor-exit(r3)
            kotlin.jvm.functions.Function1<java.lang.String, kotlin.Unit> r0 = r14.diagnostics
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r3 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE
            java.lang.String r3 = r3.m6566String$0$str$arg0$callinvoke$finally$funrun$classUdpControlClient()
            java.lang.StringBuilder r1 = r1.append(r3)
            vea.raceremote.control.UdpControlSession$Snapshot r3 = r14.snapshot()
            java.lang.String r3 = r3.getReason()
            java.lang.StringBuilder r1 = r1.append(r3)
            java.lang.String r1 = r1.toString()
            r0.invoke(r1)
            throw r2
        L21f:
            r0 = move-exception
            monitor-exit(r3)
            throw r0
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
            r5 = this;
            java.util.concurrent.atomic.AtomicBoolean r0 = r5.closing
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r1 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE
            boolean r1 = r1.m6543Boolean$arg0$callset$funclose$classUdpControlClient()
            r0.set(r1)
            java.lang.Object r0 = r5.lock
            monitor-enter(r0)
            r1 = 0
            vea.raceremote.control.UdpControlSession r2 = r5.session     // Catch: java.lang.Throwable -> L55
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r3 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L55
            int r3 = r3.m6552Int$arg0$callinput$fun$anonymous$$arg1$callsynchronized$funclose$classUdpControlClient()     // Catch: java.lang.Throwable -> L55
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r4 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE     // Catch: java.lang.Throwable -> L55
            int r4 = r4.m6558Int$arg1$callinput$fun$anonymous$$arg1$callsynchronized$funclose$classUdpControlClient()     // Catch: java.lang.Throwable -> L55
            r2.input(r3, r4)     // Catch: java.lang.Throwable -> L55
            kotlin.Unit r1 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L55
            monitor-exit(r0)
            java.lang.Thread r0 = java.lang.Thread.currentThread()
            java.lang.Thread r1 = r5.worker
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r0, r1)
            if (r0 != 0) goto L54
            java.lang.Thread r0 = r5.worker
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r1 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE
            long r1 = r1.m6561Long$arg0$calljoin$branch$if$funclose$classUdpControlClient()
            r0.join(r1)
            java.lang.Thread r0 = r5.worker
            boolean r0 = r0.isAlive()
            if (r0 == 0) goto L49
            java.net.DatagramSocket r0 = r5.socket
            if (r0 == 0) goto L49
            r0.close()
        L49:
            java.lang.Thread r0 = r5.worker
            vea.raceremote.control.LiveLiterals$UdpControlClientKt r1 = vea.raceremote.control.LiveLiterals$UdpControlClientKt.INSTANCE
            long r1 = r1.m6562Long$arg0$calljoin1$branch$if$funclose$classUdpControlClient()
            r0.join(r1)
        L54:
            return
        L55:
            r1 = move-exception
            monitor-exit(r0)
            throw r1
    }

    public final void input(int r4, int r5) {
            r3 = this;
            java.lang.Object r0 = r3.lock
            monitor-enter(r0)
            r1 = 0
            java.util.concurrent.atomic.AtomicBoolean r2 = r3.closing     // Catch: java.lang.Throwable -> L16
            boolean r2 = r2.get()     // Catch: java.lang.Throwable -> L16
            if (r2 != 0) goto L11
            vea.raceremote.control.UdpControlSession r2 = r3.session     // Catch: java.lang.Throwable -> L16
            r2.input(r4, r5)     // Catch: java.lang.Throwable -> L16
        L11:
            kotlin.Unit r1 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L16
            monitor-exit(r0)
            return
        L16:
            r1 = move-exception
            monitor-exit(r0)
            throw r1
    }

    public final vea.raceremote.control.UdpControlSession.Snapshot snapshot() {
            r3 = this;
            java.lang.Object r0 = r3.lock
            monitor-enter(r0)
            r1 = 0
            vea.raceremote.control.UdpControlSession r2 = r3.session     // Catch: java.lang.Throwable -> Lc
            vea.raceremote.control.UdpControlSession$Snapshot r2 = r2.snapshot()     // Catch: java.lang.Throwable -> Lc
            monitor-exit(r0)
            return r2
        Lc:
            r1 = move-exception
            monitor-exit(r0)
            throw r1
    }
}
