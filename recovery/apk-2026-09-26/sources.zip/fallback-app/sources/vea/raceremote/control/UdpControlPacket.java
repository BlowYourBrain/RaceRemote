package vea.raceremote.control;

/* JADX INFO: compiled from: UdpControlPacket.kt */
/* JADX INFO: loaded from: classes4.dex */
@kotlin.Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0002\b\u001b\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\b\u0087\b\u0018\u0000 (2\u00020\u0001:\u0001(BG\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\u0003\u0012\u0006\u0010\t\u001a\u00020\u0003\u0012\u0006\u0010\n\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u000b\u001a\u00020\u0005¢\u0006\u0002\u0010\fJ\t\u0010\u0017\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0018\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0019\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001a\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001b\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001c\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001d\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001e\u001a\u00020\u0005HÆ\u0003JY\u0010\u001f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00052\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\u00032\b\b\u0002\u0010\n\u001a\u00020\u00052\b\b\u0002\u0010\u000b\u001a\u00020\u0005HÆ\u0001J\u0006\u0010 \u001a\u00020!J\u0013\u0010\"\u001a\u00020#2\b\u0010$\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010%\u001a\u00020\u0003HÖ\u0001J\t\u0010&\u001a\u00020'HÖ\u0001R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u000b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000eR\u0011\u0010\n\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000eR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u000eR\u0011\u0010\t\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0012R\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0012R\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u000e¨\u0006)"}, d2 = {"Lvea/raceremote/control/UdpControlPacket;", "", "kind", "", "attempt", "", "token", "sequence", "throttle", "steering", "chipId", "basis", "(IJJJIIJJ)V", "getAttempt", "()J", "getBasis", "getChipId", "getKind", "()I", "getSequence", "getSteering", "getThrottle", "getToken", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "copy", "encode", "", "equals", "", "other", "hashCode", "toString", "", "Companion", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class UdpControlPacket {
    public static final int $stable = 0;
    public static final int ACK = 129;
    public static final int ARM = 1;
    public static final vea.raceremote.control.UdpControlPacket.Companion Companion = null;
    public static final int DRIVE = 2;
    public static final int HELLO = 128;
    public static final int OPEN = 0;
    public static final int PORT = 3334;
    public static final int SIZE = 32;
    public static final int STOP = 3;
    private final long attempt;
    private final long basis;
    private final long chipId;
    private final int kind;
    private final long sequence;
    private final int steering;
    private final int throttle;
    private final long token;

    /* JADX INFO: compiled from: UdpControlPacket.kt */
    @kotlin.Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0012\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\f\u001a\u0004\u0018\u00010\r2\u0006\u0010\u000e\u001a\u00020\u000fR\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0010"}, d2 = {"Lvea/raceremote/control/UdpControlPacket$Companion;", "", "()V", "ACK", "", "ARM", "DRIVE", "HELLO", "OPEN", "PORT", "SIZE", "STOP", "decode", "Lvea/raceremote/control/UdpControlPacket;", "bytes", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        private static final long decode$get(byte[] r17, int r18, int r19) {
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r0 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                int r0 = r0.m6588Int$$$this$calluntil$$$this$callfold$funget$fundecode$classCompanion$classUdpControlPacket()
                r1 = r19
                kotlin.ranges.IntRange r0 = kotlin.ranges.RangesKt.until(r0, r1)
                java.lang.Iterable r0 = (java.lang.Iterable) r0
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r2 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                long r2 = r2.m6652Long$arg0$callfold$funget$fundecode$classCompanion$classUdpControlPacket()
                r4 = 0
                r5 = r2
                java.util.Iterator r7 = r0.iterator()
            L1a:
                boolean r8 = r7.hasNext()
                if (r8 == 0) goto L41
                r8 = r7
                kotlin.collections.IntIterator r8 = (kotlin.collections.IntIterator) r8
                int r8 = r8.nextInt()
                r9 = r5
                r11 = r8
                r12 = 0
                int r13 = r18 + r11
                r13 = r17[r13]
                long r13 = (long) r13
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r15 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                long r15 = r15.m6651Long$arg0$calland$$this$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funget$fundecode$classCompanion$classUdpControlPacket()
                long r13 = r13 & r15
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r15 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                int r15 = r15.m6600Int$$this$calltimes$arg0$callshl$arg0$callor$fun$anonymous$$arg1$callfold$funget$fundecode$classCompanion$classUdpControlPacket()
                int r15 = r15 * r11
                long r13 = r13 << r15
                long r9 = r9 | r13
                r5 = r9
                goto L1a
            L41:
                return r5
        }

        public final vea.raceremote.control.UdpControlPacket decode(byte[] r21) {
                r20 = this;
                r0 = r21
                java.lang.String r1 = "bytes"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r0, r1)
                int r1 = r0.length
                r2 = 32
                r3 = 0
                if (r1 != r2) goto L120
                r1 = 0
                r2 = r0[r1]
                r4 = 82
                if (r2 != r4) goto L120
                r2 = 1
                r4 = r0[r2]
                r5 = 85
                if (r4 != r5) goto L120
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r4 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                int r4 = r4.m6605Int$arg0$callget$$this$calltoInt$arg0$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classUdpControlPacket()
                r4 = r0[r4]
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r5 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                int r5 = r5.m6602Int$$this$calltoByte$$this$calltoInt$arg1$callEQEQ$$this$callnot$else$cond$if$fundecode$classCompanion$classUdpControlPacket()
                byte r5 = (byte) r5
                if (r4 == r5) goto L2e
                goto L120
            L2e:
                vea.raceremote.control.UdpControlPacket r4 = new vea.raceremote.control.UdpControlPacket
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r5 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                int r5 = r5.m6604Int$arg0$callget$$this$calltoInt$$this$calland$arg0$call$init$$valp$fundecode$classCompanion$classUdpControlPacket()
                r5 = r0[r5]
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r6 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                int r6 = r6.m6603Int$arg0$calland$arg0$call$init$$valp$fundecode$classCompanion$classUdpControlPacket()
                r7 = r5 & r6
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r5 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                int r5 = r5.m6608Int$arg0$callget$arg1$call$init$$valp$fundecode$classCompanion$classUdpControlPacket()
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r6 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                int r6 = r6.m6638Int$arg1$callget$arg1$call$init$$valp$fundecode$classCompanion$classUdpControlPacket()
                long r8 = decode$get(r0, r5, r6)
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r5 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                int r5 = r5.m6609Int$arg0$callget$arg2$call$init$$valp$fundecode$classCompanion$classUdpControlPacket()
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r6 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                int r6 = r6.m6639Int$arg1$callget$arg2$call$init$$valp$fundecode$classCompanion$classUdpControlPacket()
                long r10 = decode$get(r0, r5, r6)
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r5 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                int r5 = r5.m6610Int$arg0$callget$arg3$call$init$$valp$fundecode$classCompanion$classUdpControlPacket()
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r6 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                int r6 = r6.m6640Int$arg1$callget$arg3$call$init$$valp$fundecode$classCompanion$classUdpControlPacket()
                long r12 = decode$get(r0, r5, r6)
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r5 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                int r5 = r5.m6606Int$arg0$callget$$this$calltoShort$$this$calltoInt$arg4$call$init$$valp$fundecode$classCompanion$classUdpControlPacket()
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r6 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                int r6 = r6.m6636Int$arg1$callget$$this$calltoShort$$this$calltoInt$arg4$call$init$$valp$fundecode$classCompanion$classUdpControlPacket()
                long r5 = decode$get(r0, r5, r6)
                int r5 = (int) r5
                short r14 = (short) r5
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r5 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                int r5 = r5.m6607Int$arg0$callget$$this$calltoShort$$this$calltoInt$arg5$call$init$$valp$fundecode$classCompanion$classUdpControlPacket()
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r6 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                int r6 = r6.m6637Int$arg1$callget$$this$calltoShort$$this$calltoInt$arg5$call$init$$valp$fundecode$classCompanion$classUdpControlPacket()
                long r5 = decode$get(r0, r5, r6)
                int r5 = (int) r5
                short r15 = (short) r5
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r5 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                int r5 = r5.m6611Int$arg0$callget$arg6$call$init$$valp$fundecode$classCompanion$classUdpControlPacket()
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r6 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                int r6 = r6.m6641Int$arg1$callget$arg6$call$init$$valp$fundecode$classCompanion$classUdpControlPacket()
                long r16 = decode$get(r0, r5, r6)
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r5 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                int r5 = r5.m6612Int$arg0$callget$arg7$call$init$$valp$fundecode$classCompanion$classUdpControlPacket()
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r6 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                int r6 = r6.m6642Int$arg1$callget$arg7$call$init$$valp$fundecode$classCompanion$classUdpControlPacket()
                long r18 = decode$get(r0, r5, r6)
                r6 = r4
                r6.<init>(r7, r8, r10, r12, r14, r15, r16, r18)
                r5 = r4
                r6 = 0
                long r7 = r5.getAttempt()
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r9 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                long r9 = r9.m6659Long$arg1$callEQEQ$$this$callnot$cond$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket()
                int r7 = (r7 > r9 ? 1 : (r7 == r9 ? 0 : -1))
                if (r7 == 0) goto L11a
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r7 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                int r7 = r7.m6595Int$$this$callrangeTo$$this$callcontains$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket()
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r8 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                long r8 = r8.m6658Long$arg0$callrangeTo$$this$callcontains$branch$cond$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket()
                long r10 = r5.getChipId()
                long r12 = (long) r7
                int r7 = (r12 > r10 ? 1 : (r12 == r10 ? 0 : -1))
                if (r7 > 0) goto Le3
                int r7 = (r10 > r8 ? 1 : (r10 == r8 ? 0 : -1))
                if (r7 > 0) goto Le3
                r7 = r2
                goto Le4
            Le3:
                r7 = r1
            Le4:
                if (r7 == 0) goto L11a
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r7 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                int r7 = r7.m6596Int$$this$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket()
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r8 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                int r8 = r8.m6621Int$arg0$callrangeTo$$this$callcontains$branch$cond$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket()
                int r9 = r5.getThrottle()
                if (r7 > r9) goto Lfc
                if (r9 > r8) goto Lfc
                r7 = r2
                goto Lfd
            Lfc:
                r7 = r1
            Lfd:
                if (r7 == 0) goto L11a
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r7 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                int r7 = r7.m6597Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket()
                vea.raceremote.control.LiveLiterals$UdpControlPacketKt r8 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
                int r8 = r8.m6622Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$calltakeIf$fundecode$classCompanion$classUdpControlPacket()
                int r9 = r5.getSteering()
                if (r7 > r9) goto L115
                if (r9 > r8) goto L115
                r7 = r2
                goto L116
            L115:
                r7 = r1
            L116:
                if (r7 == 0) goto L11a
                r1 = r2
                goto L11b
            L11a:
            L11b:
                if (r1 == 0) goto L11f
                r3 = r4
            L11f:
                return r3
            L120:
                return r3
        }
    }

    static {
            vea.raceremote.control.UdpControlPacket$Companion r0 = new vea.raceremote.control.UdpControlPacket$Companion
            r1 = 0
            r0.<init>(r1)
            vea.raceremote.control.UdpControlPacket.Companion = r0
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r0 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r0 = r0.m6650Int$classUdpControlPacket()
            vea.raceremote.control.UdpControlPacket.$stable = r0
            return
    }

    public UdpControlPacket(int r1, long r2, long r4, long r6, int r8, int r9, long r10, long r12) {
            r0 = this;
            r0.<init>()
            r0.kind = r1
            r0.attempt = r2
            r0.token = r4
            r0.sequence = r6
            r0.throttle = r8
            r0.steering = r9
            r0.chipId = r10
            r0.basis = r12
            return
    }

    public /* synthetic */ UdpControlPacket(int r17, long r18, long r20, long r22, int r24, int r25, long r26, long r28, int r30, kotlin.jvm.internal.DefaultConstructorMarker r31) {
            r16 = this;
            r0 = r30
            r0 = r0 & 128(0x80, float:1.8E-43)
            if (r0 == 0) goto Le
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r0 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            long r0 = r0.m6660Long$parambasis$classUdpControlPacket()
            r14 = r0
            goto L10
        Le:
            r14 = r28
        L10:
            r2 = r16
            r3 = r17
            r4 = r18
            r6 = r20
            r8 = r22
            r10 = r24
            r11 = r25
            r12 = r26
            r2.<init>(r3, r4, r6, r8, r10, r11, r12, r14)
            return
    }

    public static /* synthetic */ vea.raceremote.control.UdpControlPacket copy$default(vea.raceremote.control.UdpControlPacket r15, int r16, long r17, long r19, long r21, int r23, int r24, long r25, long r27, int r29, java.lang.Object r30) {
            r0 = r15
            r1 = r29
            r2 = r1 & 1
            if (r2 == 0) goto La
            int r2 = r0.kind
            goto Lc
        La:
            r2 = r16
        Lc:
            r3 = r1 & 2
            if (r3 == 0) goto L13
            long r3 = r0.attempt
            goto L15
        L13:
            r3 = r17
        L15:
            r5 = r1 & 4
            if (r5 == 0) goto L1c
            long r5 = r0.token
            goto L1e
        L1c:
            r5 = r19
        L1e:
            r7 = r1 & 8
            if (r7 == 0) goto L25
            long r7 = r0.sequence
            goto L27
        L25:
            r7 = r21
        L27:
            r9 = r1 & 16
            if (r9 == 0) goto L2e
            int r9 = r0.throttle
            goto L30
        L2e:
            r9 = r23
        L30:
            r10 = r1 & 32
            if (r10 == 0) goto L37
            int r10 = r0.steering
            goto L39
        L37:
            r10 = r24
        L39:
            r11 = r1 & 64
            if (r11 == 0) goto L40
            long r11 = r0.chipId
            goto L42
        L40:
            r11 = r25
        L42:
            r1 = r1 & 128(0x80, float:1.8E-43)
            if (r1 == 0) goto L49
            long r13 = r0.basis
            goto L4b
        L49:
            r13 = r27
        L4b:
            r16 = r2
            r17 = r3
            r19 = r5
            r21 = r7
            r23 = r9
            r24 = r10
            r25 = r11
            r27 = r13
            vea.raceremote.control.UdpControlPacket r0 = r15.copy(r16, r17, r19, r21, r23, r24, r25, r27)
            return r0
    }

    private static final void encode$lambda$1$put(byte[] r6, int r7, int r8, long r9) {
            r0 = 0
        L1:
            if (r0 >= r8) goto L17
            r1 = r0
            r2 = 0
            int r3 = r7 + r1
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r4 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r4 = r4.m6601Int$$this$calltimes$arg0$callushr$$this$calltoByte$arg1$callset$fun$anonymous$$arg1$callrepeat$funput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()
            int r4 = r4 * r1
            long r4 = r9 >>> r4
            int r4 = (int) r4
            byte r4 = (byte) r4
            r6[r3] = r4
            int r0 = r0 + 1
            goto L1
        L17:
            return
    }

    public final int component1() {
            r1 = this;
            int r0 = r1.kind
            return r0
    }

    public final long component2() {
            r2 = this;
            long r0 = r2.attempt
            return r0
    }

    public final long component3() {
            r2 = this;
            long r0 = r2.token
            return r0
    }

    public final long component4() {
            r2 = this;
            long r0 = r2.sequence
            return r0
    }

    public final int component5() {
            r1 = this;
            int r0 = r1.throttle
            return r0
    }

    public final int component6() {
            r1 = this;
            int r0 = r1.steering
            return r0
    }

    public final long component7() {
            r2 = this;
            long r0 = r2.chipId
            return r0
    }

    public final long component8() {
            r2 = this;
            long r0 = r2.basis
            return r0
    }

    public final vea.raceremote.control.UdpControlPacket copy(int r16, long r17, long r19, long r21, int r23, int r24, long r25, long r27) {
            r15 = this;
            vea.raceremote.control.UdpControlPacket r14 = new vea.raceremote.control.UdpControlPacket
            r0 = r14
            r1 = r16
            r2 = r17
            r4 = r19
            r6 = r21
            r8 = r23
            r9 = r24
            r10 = r25
            r12 = r27
            r0.<init>(r1, r2, r4, r6, r8, r9, r10, r12)
            return r14
    }

    public final byte[] encode() {
            r11 = this;
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r0 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r0 = r0.m6599Int$$this$callrangeTo$$this$callcontains$cond$cond$cond$arg0$callrequire$funencode$classUdpControlPacket()
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r1 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r1 = r1.m6624Int$arg0$callrangeTo$$this$callcontains$cond$cond$cond$arg0$callrequire$funencode$classUdpControlPacket()
            int r2 = r11.kind
            r3 = 1
            r4 = 0
            if (r0 > r2) goto L16
            if (r2 > r1) goto L16
            r0 = r3
            goto L17
        L16:
            r0 = r4
        L17:
            if (r0 == 0) goto L6f
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r0 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r0 = r0.m6594Int$$this$callrangeTo$$this$callcontains$branch$cond$cond$arg0$callrequire$funencode$classUdpControlPacket()
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r1 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            long r1 = r1.m6657Long$arg0$callrangeTo$$this$callcontains$branch$cond$cond$arg0$callrequire$funencode$classUdpControlPacket()
            long r5 = r11.attempt
            long r7 = (long) r0
            int r0 = (r7 > r5 ? 1 : (r7 == r5 ? 0 : -1))
            if (r0 > 0) goto L32
            int r0 = (r5 > r1 ? 1 : (r5 == r1 ? 0 : -1))
            if (r0 > 0) goto L32
            r0 = r3
            goto L33
        L32:
            r0 = r4
        L33:
            if (r0 == 0) goto L6f
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r0 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r0 = r0.m6592Int$$this$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire$funencode$classUdpControlPacket()
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r1 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            long r1 = r1.m6656Long$arg0$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire$funencode$classUdpControlPacket()
            long r5 = r11.token
            long r7 = (long) r0
            int r0 = (r7 > r5 ? 1 : (r7 == r5 ? 0 : -1))
            if (r0 > 0) goto L4e
            int r0 = (r5 > r1 ? 1 : (r5 == r1 ? 0 : -1))
            if (r0 > 0) goto L4e
            r0 = r3
            goto L4f
        L4e:
            r0 = r4
        L4f:
            if (r0 == 0) goto L6f
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r0 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r0 = r0.m6590Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funencode$classUdpControlPacket()
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r1 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            long r1 = r1.m6654Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funencode$classUdpControlPacket()
            long r5 = r11.sequence
            long r7 = (long) r0
            int r0 = (r7 > r5 ? 1 : (r7 == r5 ? 0 : -1))
            if (r0 > 0) goto L6a
            int r0 = (r5 > r1 ? 1 : (r5 == r1 ? 0 : -1))
            if (r0 > 0) goto L6a
            r0 = r3
            goto L6b
        L6a:
            r0 = r4
        L6b:
            if (r0 == 0) goto L6f
            r0 = r3
            goto L70
        L6f:
            r0 = r4
        L70:
            java.lang.String r1 = "Failed requirement."
            if (r0 == 0) goto L1a8
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r0 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r0 = r0.m6598Int$$this$callrangeTo$$this$callcontains$cond$cond$arg0$callrequire1$funencode$classUdpControlPacket()
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r2 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r2 = r2.m6623Int$arg0$callrangeTo$$this$callcontains$cond$cond$arg0$callrequire1$funencode$classUdpControlPacket()
            int r5 = r11.throttle
            if (r0 > r5) goto L88
            if (r5 > r2) goto L88
            r0 = r3
            goto L89
        L88:
            r0 = r4
        L89:
            if (r0 == 0) goto Lc0
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r0 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r0 = r0.m6593Int$$this$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire1$funencode$classUdpControlPacket()
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r2 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r2 = r2.m6620Int$arg0$callrangeTo$$this$callcontains$branch$cond$arg0$callrequire1$funencode$classUdpControlPacket()
            int r5 = r11.steering
            if (r0 > r5) goto L9f
            if (r5 > r2) goto L9f
            r0 = r3
            goto La0
        L9f:
            r0 = r4
        La0:
            if (r0 == 0) goto Lc0
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r0 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r0 = r0.m6591Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classUdpControlPacket()
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r2 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            long r5 = r2.m6655Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire1$funencode$classUdpControlPacket()
            long r7 = r11.chipId
            long r9 = (long) r0
            int r0 = (r9 > r7 ? 1 : (r9 == r7 ? 0 : -1))
            if (r0 > 0) goto Lbb
            int r0 = (r7 > r5 ? 1 : (r7 == r5 ? 0 : -1))
            if (r0 > 0) goto Lbb
            r0 = r3
            goto Lbc
        Lbb:
            r0 = r4
        Lbc:
            if (r0 == 0) goto Lc0
            r0 = r3
            goto Lc1
        Lc0:
            r0 = r4
        Lc1:
            if (r0 == 0) goto L19e
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r0 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r0 = r0.m6589Int$$this$callrangeTo$$this$callcontains$arg0$callrequire2$funencode$classUdpControlPacket()
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r2 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            long r5 = r2.m6653Long$arg0$callrangeTo$$this$callcontains$arg0$callrequire2$funencode$classUdpControlPacket()
            long r7 = r11.basis
            long r9 = (long) r0
            int r0 = (r9 > r7 ? 1 : (r9 == r7 ? 0 : -1))
            if (r0 > 0) goto Ldb
            int r0 = (r7 > r5 ? 1 : (r7 == r5 ? 0 : -1))
            if (r0 > 0) goto Ldb
            goto Ldc
        Ldb:
            r3 = r4
        Ldc:
            if (r3 == 0) goto L194
            r0 = 32
            byte[] r0 = new byte[r0]
            r1 = r0
            r2 = 0
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r3 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r3 = r3.m6625Int$arg0$callset$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r4 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            byte r4 = r4.m6585Byte$arg1$callset$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()
            r1[r3] = r4
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r3 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r3 = r3.m6626Int$arg0$callset1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r4 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            byte r4 = r4.m6586Byte$arg1$callset1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()
            r1[r3] = r4
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r3 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r3 = r3.m6627Int$arg0$callset2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r4 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            byte r4 = r4.m6587Byte$arg1$callset2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()
            r1[r3] = r4
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r3 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r3 = r3.m6628Int$arg0$callset3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()
            int r4 = r11.kind
            byte r4 = (byte) r4
            r1[r3] = r4
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r3 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r3 = r3.m6613Int$arg0$callput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r4 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r4 = r4.m6643Int$arg1$callput$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()
            long r5 = r11.attempt
            encode$lambda$1$put(r1, r3, r4, r5)
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r3 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r3 = r3.m6614Int$arg0$callput1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r4 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r4 = r4.m6644Int$arg1$callput1$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()
            long r5 = r11.token
            encode$lambda$1$put(r1, r3, r4, r5)
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r3 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r3 = r3.m6615Int$arg0$callput2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r4 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r4 = r4.m6645Int$arg1$callput2$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()
            long r5 = r11.sequence
            encode$lambda$1$put(r1, r3, r4, r5)
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r3 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r3 = r3.m6616Int$arg0$callput3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r4 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r4 = r4.m6646Int$arg1$callput3$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()
            int r5 = r11.throttle
            long r5 = (long) r5
            encode$lambda$1$put(r1, r3, r4, r5)
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r3 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r3 = r3.m6617Int$arg0$callput4$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r4 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r4 = r4.m6647Int$arg1$callput4$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()
            int r5 = r11.steering
            long r5 = (long) r5
            encode$lambda$1$put(r1, r3, r4, r5)
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r3 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r3 = r3.m6618Int$arg0$callput5$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r4 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r4 = r4.m6648Int$arg1$callput5$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()
            long r5 = r11.basis
            encode$lambda$1$put(r1, r3, r4, r5)
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r3 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r3 = r3.m6619Int$arg0$callput6$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r4 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r4 = r4.m6649Int$arg1$callput6$fun$anonymous$$arg0$callalso$funencode$classUdpControlPacket()
            long r5 = r11.chipId
            encode$lambda$1$put(r1, r3, r4, r5)
            return r0
        L194:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L19e:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L1a8:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
    }

    public boolean equals(java.lang.Object r6) {
            r5 = this;
            if (r5 != r6) goto L9
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r0 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            boolean r0 = r0.m6574Boolean$branch$when$funequals$classUdpControlPacket()
            return r0
        L9:
            boolean r0 = r6 instanceof vea.raceremote.control.UdpControlPacket
            if (r0 != 0) goto L14
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r0 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            boolean r0 = r0.m6575Boolean$branch$when1$funequals$classUdpControlPacket()
            return r0
        L14:
            r0 = r6
            vea.raceremote.control.UdpControlPacket r0 = (vea.raceremote.control.UdpControlPacket) r0
            int r1 = r5.kind
            int r2 = r0.kind
            if (r1 == r2) goto L24
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r0 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            boolean r0 = r0.m6576Boolean$branch$when2$funequals$classUdpControlPacket()
            return r0
        L24:
            long r1 = r5.attempt
            long r3 = r0.attempt
            int r1 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r1 == 0) goto L33
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r0 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            boolean r0 = r0.m6577Boolean$branch$when3$funequals$classUdpControlPacket()
            return r0
        L33:
            long r1 = r5.token
            long r3 = r0.token
            int r1 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r1 == 0) goto L42
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r0 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            boolean r0 = r0.m6578Boolean$branch$when4$funequals$classUdpControlPacket()
            return r0
        L42:
            long r1 = r5.sequence
            long r3 = r0.sequence
            int r1 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r1 == 0) goto L51
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r0 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            boolean r0 = r0.m6579Boolean$branch$when5$funequals$classUdpControlPacket()
            return r0
        L51:
            int r1 = r5.throttle
            int r2 = r0.throttle
            if (r1 == r2) goto L5e
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r0 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            boolean r0 = r0.m6580Boolean$branch$when6$funequals$classUdpControlPacket()
            return r0
        L5e:
            int r1 = r5.steering
            int r2 = r0.steering
            if (r1 == r2) goto L6b
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r0 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            boolean r0 = r0.m6581Boolean$branch$when7$funequals$classUdpControlPacket()
            return r0
        L6b:
            long r1 = r5.chipId
            long r3 = r0.chipId
            int r1 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r1 == 0) goto L7a
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r0 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            boolean r0 = r0.m6582Boolean$branch$when8$funequals$classUdpControlPacket()
            return r0
        L7a:
            long r1 = r5.basis
            long r3 = r0.basis
            int r0 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r0 == 0) goto L89
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r0 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            boolean r0 = r0.m6583Boolean$branch$when9$funequals$classUdpControlPacket()
            return r0
        L89:
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r0 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            boolean r0 = r0.m6584Boolean$funequals$classUdpControlPacket()
            return r0
    }

    public final long getAttempt() {
            r2 = this;
            long r0 = r2.attempt
            return r0
    }

    public final long getBasis() {
            r2 = this;
            long r0 = r2.basis
            return r0
    }

    public final long getChipId() {
            r2 = this;
            long r0 = r2.chipId
            return r0
    }

    public final int getKind() {
            r1 = this;
            int r0 = r1.kind
            return r0
    }

    public final long getSequence() {
            r2 = this;
            long r0 = r2.sequence
            return r0
    }

    public final int getSteering() {
            r1 = this;
            int r0 = r1.steering
            return r0
    }

    public final int getThrottle() {
            r1 = this;
            int r0 = r1.throttle
            return r0
    }

    public final long getToken() {
            r2 = this;
            long r0 = r2.token
            return r0
    }

    public int hashCode() {
            r4 = this;
            int r0 = r4.kind
            int r0 = java.lang.Integer.hashCode(r0)
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r1 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r1 = r1.m6629Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classUdpControlPacket()
            int r1 = r1 * r0
            long r2 = r4.attempt
            int r2 = java.lang.Long.hashCode(r2)
            int r1 = r1 + r2
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r0 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r0 = r0.m6630Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classUdpControlPacket()
            int r0 = r0 * r1
            long r2 = r4.token
            int r2 = java.lang.Long.hashCode(r2)
            int r0 = r0 + r2
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r1 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r1 = r1.m6631Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classUdpControlPacket()
            int r1 = r1 * r0
            long r2 = r4.sequence
            int r2 = java.lang.Long.hashCode(r2)
            int r1 = r1 + r2
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r0 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r0 = r0.m6632Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classUdpControlPacket()
            int r0 = r0 * r1
            int r2 = r4.throttle
            int r2 = java.lang.Integer.hashCode(r2)
            int r0 = r0 + r2
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r1 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r1 = r1.m6633Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classUdpControlPacket()
            int r1 = r1 * r0
            int r2 = r4.steering
            int r2 = java.lang.Integer.hashCode(r2)
            int r1 = r1 + r2
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r0 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r0 = r0.m6634Int$arg0$calltimes$$this$callplus$setresult5$funhashCode$classUdpControlPacket()
            int r0 = r0 * r1
            long r2 = r4.chipId
            int r2 = java.lang.Long.hashCode(r2)
            int r0 = r0 + r2
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r1 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            int r1 = r1.m6635Int$arg0$calltimes$$this$callplus$setresult6$funhashCode$classUdpControlPacket()
            int r1 = r1 * r0
            long r2 = r4.basis
            int r2 = java.lang.Long.hashCode(r2)
            int r1 = r1 + r2
            return r1
    }

    public java.lang.String toString() {
            r4 = this;
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r1 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            java.lang.String r1 = r1.m6661String$0$str$funtoString$classUdpControlPacket()
            java.lang.StringBuilder r1 = r0.append(r1)
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r2 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            java.lang.String r2 = r2.m6662String$1$str$funtoString$classUdpControlPacket()
            java.lang.StringBuilder r1 = r1.append(r2)
            int r2 = r4.kind
            java.lang.StringBuilder r1 = r1.append(r2)
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r2 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            java.lang.String r2 = r2.m6673String$3$str$funtoString$classUdpControlPacket()
            java.lang.StringBuilder r1 = r1.append(r2)
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r2 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            java.lang.String r2 = r2.m6674String$4$str$funtoString$classUdpControlPacket()
            java.lang.StringBuilder r1 = r1.append(r2)
            long r2 = r4.attempt
            java.lang.StringBuilder r1 = r1.append(r2)
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r2 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            java.lang.String r2 = r2.m6675String$6$str$funtoString$classUdpControlPacket()
            java.lang.StringBuilder r1 = r1.append(r2)
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r2 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            java.lang.String r2 = r2.m6676String$7$str$funtoString$classUdpControlPacket()
            java.lang.StringBuilder r1 = r1.append(r2)
            long r2 = r4.token
            java.lang.StringBuilder r1 = r1.append(r2)
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r2 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            java.lang.String r2 = r2.m6677String$9$str$funtoString$classUdpControlPacket()
            java.lang.StringBuilder r1 = r1.append(r2)
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r2 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            java.lang.String r2 = r2.m6663String$10$str$funtoString$classUdpControlPacket()
            java.lang.StringBuilder r1 = r1.append(r2)
            long r2 = r4.sequence
            java.lang.StringBuilder r1 = r1.append(r2)
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r2 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            java.lang.String r2 = r2.m6664String$12$str$funtoString$classUdpControlPacket()
            java.lang.StringBuilder r1 = r1.append(r2)
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r2 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            java.lang.String r2 = r2.m6665String$13$str$funtoString$classUdpControlPacket()
            java.lang.StringBuilder r1 = r1.append(r2)
            int r2 = r4.throttle
            java.lang.StringBuilder r1 = r1.append(r2)
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r2 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            java.lang.String r2 = r2.m6666String$15$str$funtoString$classUdpControlPacket()
            java.lang.StringBuilder r1 = r1.append(r2)
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r2 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            java.lang.String r2 = r2.m6667String$16$str$funtoString$classUdpControlPacket()
            java.lang.StringBuilder r1 = r1.append(r2)
            int r2 = r4.steering
            java.lang.StringBuilder r1 = r1.append(r2)
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r2 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            java.lang.String r2 = r2.m6668String$18$str$funtoString$classUdpControlPacket()
            java.lang.StringBuilder r1 = r1.append(r2)
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r2 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            java.lang.String r2 = r2.m6669String$19$str$funtoString$classUdpControlPacket()
            java.lang.StringBuilder r1 = r1.append(r2)
            long r2 = r4.chipId
            java.lang.StringBuilder r1 = r1.append(r2)
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r2 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            java.lang.String r2 = r2.m6670String$21$str$funtoString$classUdpControlPacket()
            java.lang.StringBuilder r1 = r1.append(r2)
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r2 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            java.lang.String r2 = r2.m6671String$22$str$funtoString$classUdpControlPacket()
            r1.append(r2)
            long r1 = r4.basis
            java.lang.StringBuilder r1 = r0.append(r1)
            vea.raceremote.control.LiveLiterals$UdpControlPacketKt r2 = vea.raceremote.control.LiveLiterals$UdpControlPacketKt.INSTANCE
            java.lang.String r2 = r2.m6672String$24$str$funtoString$classUdpControlPacket()
            r1.append(r2)
            java.lang.String r0 = r0.toString()
            return r0
    }
}
