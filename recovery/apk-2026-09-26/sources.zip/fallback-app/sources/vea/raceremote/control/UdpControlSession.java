package vea.raceremote.control;

/* JADX INFO: compiled from: UdpControlSession.kt */
/* JADX INFO: loaded from: classes4.dex */
@kotlin.Metadata(d1 = {"\u0000T\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\r\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0007\u0018\u00002\u00020\u0001:\u0003456B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003¢\u0006\u0002\u0010\u0006J\u0010\u0010#\u001a\u00020$2\u0006\u0010%\u001a\u00020\u0003H\u0002J\u0016\u0010&\u001a\u00020$2\u0006\u0010!\u001a\u00020\b2\u0006\u0010\u001e\u001a\u00020\bJ\u0010\u0010'\u001a\u0004\u0018\u00010 2\u0006\u0010%\u001a\u00020\u0003J6\u0010(\u001a\u00020 2\u0006\u0010)\u001a\u00020\b2\u0006\u0010*\u001a\u00020\u00032\b\b\u0002\u0010+\u001a\u00020\b2\b\b\u0002\u0010,\u001a\u00020\b2\b\b\u0002\u0010-\u001a\u00020\u0003H\u0002J\u0016\u0010.\u001a\u00020/2\u0006\u00100\u001a\u00020 2\u0006\u0010%\u001a\u00020\u0003J\u0006\u00101\u001a\u000202J\u0010\u00103\u001a\u00020$2\b\b\u0002\u0010\u001b\u001a\u00020\u001cR\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0012\u0010\u000b\u001a\u0004\u0018\u00010\u0003X\u0082\u000e¢\u0006\u0004\n\u0002\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000eR\u000e\u0010\u0010\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000R\u0012\u0010\u0013\u001a\u0004\u0018\u00010\u0003X\u0082\u000e¢\u0006\u0004\n\u0002\u0010\fR\u000e\u0010\u0014\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0018\u0010\u0015\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00170\u0016X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0018R\u000e\u0010\u0019\u001a\u00020\u001aX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u001cX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u001f\u001a\u0004\u0018\u00010 X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000¨\u00067"}, d2 = {"Lvea/raceremote/control/UdpControlSession;", "", "chipId", "", "attempt", "openedAt", "(JJJ)V", "acknowledgedSteering", "", "acknowledgedThrottle", "acknowledgements", "armStarted", "Ljava/lang/Long;", "getAttempt", "()J", "getChipId", "confirmedAt", "helloAt", "lastAck", "lastSent", "maxRttMs", "pending", "", "Lvea/raceremote/control/UdpControlSession$Sent;", "[Lvea/raceremote/control/UdpControlSession$Sent;", "phase", "Lvea/raceremote/control/UdpControlSession$Phase;", "reason", "", "sequence", "steering", "stopping", "Lvea/raceremote/control/UdpControlPacket;", "throttle", "token", "expire", "", "now", "input", "next", "packet", "kind", "seq", "t", "s", "basis", "receive", "", "p", "snapshot", "Lvea/raceremote/control/UdpControlSession$Snapshot;", "stop", "Phase", "Sent", "Snapshot", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class UdpControlSession {
    public static final int $stable = 0;
    private int acknowledgedSteering;
    private int acknowledgedThrottle;
    private int acknowledgements;
    private java.lang.Long armStarted;
    private final long attempt;
    private final long chipId;
    private long confirmedAt;
    private long helloAt;
    private long lastAck;
    private java.lang.Long lastSent;
    private long maxRttMs;
    private final long openedAt;
    private final vea.raceremote.control.UdpControlSession.Sent[] pending;
    private vea.raceremote.control.UdpControlSession.Phase phase;
    private java.lang.String reason;
    private long sequence;
    private int steering;
    private vea.raceremote.control.UdpControlPacket stopping;
    private int throttle;
    private long token;

    /* JADX INFO: compiled from: UdpControlSession.kt */
    @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0006\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006¨\u0006\u0007"}, d2 = {"Lvea/raceremote/control/UdpControlSession$Phase;", "", "(Ljava/lang/String;I)V", "OPENING", "ARMING", "ACTIVE", "CLOSED", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final enum Phase extends java.lang.Enum<vea.raceremote.control.UdpControlSession.Phase> {
        private static final /* synthetic */ vea.raceremote.control.UdpControlSession.Phase[] $VALUES = null;
        public static final vea.raceremote.control.UdpControlSession.Phase ACTIVE = null;
        public static final vea.raceremote.control.UdpControlSession.Phase ARMING = null;
        public static final vea.raceremote.control.UdpControlSession.Phase CLOSED = null;
        public static final vea.raceremote.control.UdpControlSession.Phase OPENING = null;

        private static final /* synthetic */ vea.raceremote.control.UdpControlSession.Phase[] $values() {
                r0 = 4
                vea.raceremote.control.UdpControlSession$Phase[] r0 = new vea.raceremote.control.UdpControlSession.Phase[r0]
                r1 = 0
                vea.raceremote.control.UdpControlSession$Phase r2 = vea.raceremote.control.UdpControlSession.Phase.OPENING
                r0[r1] = r2
                r1 = 1
                vea.raceremote.control.UdpControlSession$Phase r2 = vea.raceremote.control.UdpControlSession.Phase.ARMING
                r0[r1] = r2
                r1 = 2
                vea.raceremote.control.UdpControlSession$Phase r2 = vea.raceremote.control.UdpControlSession.Phase.ACTIVE
                r0[r1] = r2
                r1 = 3
                vea.raceremote.control.UdpControlSession$Phase r2 = vea.raceremote.control.UdpControlSession.Phase.CLOSED
                r0[r1] = r2
                return r0
        }

        static {
                vea.raceremote.control.UdpControlSession$Phase r0 = new vea.raceremote.control.UdpControlSession$Phase
                java.lang.String r1 = "OPENING"
                r2 = 0
                r0.<init>(r1, r2)
                vea.raceremote.control.UdpControlSession.Phase.OPENING = r0
                vea.raceremote.control.UdpControlSession$Phase r0 = new vea.raceremote.control.UdpControlSession$Phase
                java.lang.String r1 = "ARMING"
                r2 = 1
                r0.<init>(r1, r2)
                vea.raceremote.control.UdpControlSession.Phase.ARMING = r0
                vea.raceremote.control.UdpControlSession$Phase r0 = new vea.raceremote.control.UdpControlSession$Phase
                java.lang.String r1 = "ACTIVE"
                r2 = 2
                r0.<init>(r1, r2)
                vea.raceremote.control.UdpControlSession.Phase.ACTIVE = r0
                vea.raceremote.control.UdpControlSession$Phase r0 = new vea.raceremote.control.UdpControlSession$Phase
                java.lang.String r1 = "CLOSED"
                r2 = 3
                r0.<init>(r1, r2)
                vea.raceremote.control.UdpControlSession.Phase.CLOSED = r0
                vea.raceremote.control.UdpControlSession$Phase[] r0 = $values()
                vea.raceremote.control.UdpControlSession.Phase.$VALUES = r0
                return
        }

        private Phase(java.lang.String r1, int r2) {
                r0 = this;
                r0.<init>(r1, r2)
                return
        }

        public static vea.raceremote.control.UdpControlSession.Phase valueOf(java.lang.String r1) {
                java.lang.Class<vea.raceremote.control.UdpControlSession$Phase> r0 = vea.raceremote.control.UdpControlSession.Phase.class
                java.lang.Enum r0 = java.lang.Enum.valueOf(r0, r1)
                vea.raceremote.control.UdpControlSession$Phase r0 = (vea.raceremote.control.UdpControlSession.Phase) r0
                return r0
        }

        public static vea.raceremote.control.UdpControlSession.Phase[] values() {
                vea.raceremote.control.UdpControlSession$Phase[] r0 = vea.raceremote.control.UdpControlSession.Phase.$VALUES
                java.lang.Object r0 = r0.clone()
                vea.raceremote.control.UdpControlSession$Phase[] r0 = (vea.raceremote.control.UdpControlSession.Phase[]) r0
                return r0
        }
    }

    /* JADX INFO: compiled from: UdpControlSession.kt */
    @kotlin.Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0082\b\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\t\u0010\u000b\u001a\u00020\u0003HÆ\u0003J\t\u0010\f\u001a\u00020\u0005HÆ\u0003J\u001d\u0010\r\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u000e\u001a\u00020\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0011\u001a\u00020\u0012HÖ\u0001J\t\u0010\u0013\u001a\u00020\u0014HÖ\u0001R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u0015"}, d2 = {"Lvea/raceremote/control/UdpControlSession$Sent;", "", "packet", "Lvea/raceremote/control/UdpControlPacket;", "at", "", "(Lvea/raceremote/control/UdpControlPacket;J)V", "getAt", "()J", "getPacket", "()Lvea/raceremote/control/UdpControlPacket;", "component1", "component2", "copy", "equals", "", "other", "hashCode", "", "toString", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
    private static final class Sent {
        private final long at;
        private final vea.raceremote.control.UdpControlPacket packet;

        public Sent(vea.raceremote.control.UdpControlPacket r2, long r3) {
                r1 = this;
                java.lang.String r0 = "packet"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                r1.<init>()
                r1.packet = r2
                r1.at = r3
                return
        }

        public static /* synthetic */ vea.raceremote.control.UdpControlSession.Sent copy$default(vea.raceremote.control.UdpControlSession.Sent r0, vea.raceremote.control.UdpControlPacket r1, long r2, int r4, java.lang.Object r5) {
                r5 = r4 & 1
                if (r5 == 0) goto L6
                vea.raceremote.control.UdpControlPacket r1 = r0.packet
            L6:
                r4 = r4 & 2
                if (r4 == 0) goto Lc
                long r2 = r0.at
            Lc:
                vea.raceremote.control.UdpControlSession$Sent r0 = r0.copy(r1, r2)
                return r0
        }

        public final vea.raceremote.control.UdpControlPacket component1() {
                r1 = this;
                vea.raceremote.control.UdpControlPacket r0 = r1.packet
                return r0
        }

        public final long component2() {
                r2 = this;
                long r0 = r2.at
                return r0
        }

        public final vea.raceremote.control.UdpControlSession.Sent copy(vea.raceremote.control.UdpControlPacket r2, long r3) {
                r1 = this;
                java.lang.String r0 = "packet"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                vea.raceremote.control.UdpControlSession$Sent r0 = new vea.raceremote.control.UdpControlSession$Sent
                r0.<init>(r2, r3)
                return r0
        }

        public boolean equals(java.lang.Object r6) {
                r5 = this;
                if (r5 != r6) goto L9
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                boolean r0 = r0.m6685Boolean$branch$when$funequals$classSent$classUdpControlSession()
                return r0
            L9:
                boolean r0 = r6 instanceof vea.raceremote.control.UdpControlSession.Sent
                if (r0 != 0) goto L14
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                boolean r0 = r0.m6688Boolean$branch$when1$funequals$classSent$classUdpControlSession()
                return r0
            L14:
                r0 = r6
                vea.raceremote.control.UdpControlSession$Sent r0 = (vea.raceremote.control.UdpControlSession.Sent) r0
                vea.raceremote.control.UdpControlPacket r1 = r5.packet
                vea.raceremote.control.UdpControlPacket r2 = r0.packet
                boolean r1 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r2)
                if (r1 != 0) goto L28
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                boolean r0 = r0.m6691Boolean$branch$when2$funequals$classSent$classUdpControlSession()
                return r0
            L28:
                long r1 = r5.at
                long r3 = r0.at
                int r0 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
                if (r0 == 0) goto L37
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                boolean r0 = r0.m6693Boolean$branch$when3$funequals$classSent$classUdpControlSession()
                return r0
            L37:
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                boolean r0 = r0.m6701Boolean$funequals$classSent$classUdpControlSession()
                return r0
        }

        public final long getAt() {
                r2 = this;
                long r0 = r2.at
                return r0
        }

        public final vea.raceremote.control.UdpControlPacket getPacket() {
                r1 = this;
                vea.raceremote.control.UdpControlPacket r0 = r1.packet
                return r0
        }

        public int hashCode() {
                r4 = this;
                vea.raceremote.control.UdpControlPacket r0 = r4.packet
                int r0 = r0.hashCode()
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r1 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                int r1 = r1.m6722Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classSent$classUdpControlSession()
                int r1 = r1 * r0
                long r2 = r4.at
                int r2 = java.lang.Long.hashCode(r2)
                int r1 = r1 + r2
                return r1
        }

        public java.lang.String toString() {
                r3 = this;
                java.lang.StringBuilder r0 = new java.lang.StringBuilder
                r0.<init>()
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r1 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                java.lang.String r1 = r1.m6750String$0$str$funtoString$classSent$classUdpControlSession()
                java.lang.StringBuilder r0 = r0.append(r1)
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r1 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                java.lang.String r1 = r1.m6752String$1$str$funtoString$classSent$classUdpControlSession()
                java.lang.StringBuilder r0 = r0.append(r1)
                vea.raceremote.control.UdpControlPacket r1 = r3.packet
                java.lang.StringBuilder r0 = r0.append(r1)
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r1 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                java.lang.String r1 = r1.m6766String$3$str$funtoString$classSent$classUdpControlSession()
                java.lang.StringBuilder r0 = r0.append(r1)
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r1 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                java.lang.String r1 = r1.m6768String$4$str$funtoString$classSent$classUdpControlSession()
                java.lang.StringBuilder r0 = r0.append(r1)
                long r1 = r3.at
                java.lang.StringBuilder r0 = r0.append(r1)
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r1 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                java.lang.String r1 = r1.m6770String$6$str$funtoString$classSent$classUdpControlSession()
                java.lang.StringBuilder r0 = r0.append(r1)
                java.lang.String r0 = r0.toString()
                return r0
        }
    }

    /* JADX INFO: compiled from: UdpControlSession.kt */
    @kotlin.Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0002\b\u001e\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0087\b\u0018\u00002\u00020\u0001BM\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\u0007\u0012\u0006\u0010\u000b\u001a\u00020\u0007\u0012\u0006\u0010\f\u001a\u00020\t\u0012\u0006\u0010\r\u001a\u00020\u0007\u0012\u0006\u0010\u000e\u001a\u00020\u0007¢\u0006\u0002\u0010\u000fJ\t\u0010\u001d\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001e\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001f\u001a\u00020\u0007HÆ\u0003J\t\u0010 \u001a\u00020\tHÆ\u0003J\t\u0010!\u001a\u00020\u0007HÆ\u0003J\t\u0010\"\u001a\u00020\u0007HÆ\u0003J\t\u0010#\u001a\u00020\tHÆ\u0003J\t\u0010$\u001a\u00020\u0007HÆ\u0003J\t\u0010%\u001a\u00020\u0007HÆ\u0003Jc\u0010&\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\n\u001a\u00020\u00072\b\b\u0002\u0010\u000b\u001a\u00020\u00072\b\b\u0002\u0010\f\u001a\u00020\t2\b\b\u0002\u0010\r\u001a\u00020\u00072\b\b\u0002\u0010\u000e\u001a\u00020\u0007HÆ\u0001J\u0013\u0010'\u001a\u00020(2\b\u0010)\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010*\u001a\u00020\u0007HÖ\u0001J\t\u0010+\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u000e\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\r\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0011R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0011R\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0011\u0010\f\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0015R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u001aR\u0011\u0010\u000b\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0011R\u0011\u0010\n\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0011¨\u0006,"}, d2 = {"Lvea/raceremote/control/UdpControlSession$Snapshot;", "", "phase", "Lvea/raceremote/control/UdpControlSession$Phase;", "reason", "", "acknowledgements", "", "lastAck", "", "throttle", "steering", "maxRttMs", "acknowledgedThrottle", "acknowledgedSteering", "(Lvea/raceremote/control/UdpControlSession$Phase;Ljava/lang/String;IJIIJII)V", "getAcknowledgedSteering", "()I", "getAcknowledgedThrottle", "getAcknowledgements", "getLastAck", "()J", "getMaxRttMs", "getPhase", "()Lvea/raceremote/control/UdpControlSession$Phase;", "getReason", "()Ljava/lang/String;", "getSteering", "getThrottle", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "equals", "", "other", "hashCode", "toString", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class Snapshot {
        public static final int $stable = 0;
        private final int acknowledgedSteering;
        private final int acknowledgedThrottle;
        private final int acknowledgements;
        private final long lastAck;
        private final long maxRttMs;
        private final vea.raceremote.control.UdpControlSession.Phase phase;
        private final java.lang.String reason;
        private final int steering;
        private final int throttle;

        static {
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                int r0 = r0.m6734Int$classSnapshot$classUdpControlSession()
                vea.raceremote.control.UdpControlSession.Snapshot.$stable = r0
                return
        }

        public Snapshot(vea.raceremote.control.UdpControlSession.Phase r2, java.lang.String r3, int r4, long r5, int r7, int r8, long r9, int r11, int r12) {
                r1 = this;
                java.lang.String r0 = "phase"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                java.lang.String r0 = "reason"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
                r1.<init>()
                r1.phase = r2
                r1.reason = r3
                r1.acknowledgements = r4
                r1.lastAck = r5
                r1.throttle = r7
                r1.steering = r8
                r1.maxRttMs = r9
                r1.acknowledgedThrottle = r11
                r1.acknowledgedSteering = r12
                return
        }

        public static /* synthetic */ vea.raceremote.control.UdpControlSession.Snapshot copy$default(vea.raceremote.control.UdpControlSession.Snapshot r12, vea.raceremote.control.UdpControlSession.Phase r13, java.lang.String r14, int r15, long r16, int r18, int r19, long r20, int r22, int r23, int r24, java.lang.Object r25) {
                r0 = r12
                r1 = r24
                r2 = r1 & 1
                if (r2 == 0) goto La
                vea.raceremote.control.UdpControlSession$Phase r2 = r0.phase
                goto Lb
            La:
                r2 = r13
            Lb:
                r3 = r1 & 2
                if (r3 == 0) goto L12
                java.lang.String r3 = r0.reason
                goto L13
            L12:
                r3 = r14
            L13:
                r4 = r1 & 4
                if (r4 == 0) goto L1a
                int r4 = r0.acknowledgements
                goto L1b
            L1a:
                r4 = r15
            L1b:
                r5 = r1 & 8
                if (r5 == 0) goto L22
                long r5 = r0.lastAck
                goto L24
            L22:
                r5 = r16
            L24:
                r7 = r1 & 16
                if (r7 == 0) goto L2b
                int r7 = r0.throttle
                goto L2d
            L2b:
                r7 = r18
            L2d:
                r8 = r1 & 32
                if (r8 == 0) goto L34
                int r8 = r0.steering
                goto L36
            L34:
                r8 = r19
            L36:
                r9 = r1 & 64
                if (r9 == 0) goto L3d
                long r9 = r0.maxRttMs
                goto L3f
            L3d:
                r9 = r20
            L3f:
                r11 = r1 & 128(0x80, float:1.8E-43)
                if (r11 == 0) goto L46
                int r11 = r0.acknowledgedThrottle
                goto L48
            L46:
                r11 = r22
            L48:
                r1 = r1 & 256(0x100, float:3.59E-43)
                if (r1 == 0) goto L4f
                int r1 = r0.acknowledgedSteering
                goto L51
            L4f:
                r1 = r23
            L51:
                r13 = r2
                r14 = r3
                r15 = r4
                r16 = r5
                r18 = r7
                r19 = r8
                r20 = r9
                r22 = r11
                r23 = r1
                vea.raceremote.control.UdpControlSession$Snapshot r0 = r12.copy(r13, r14, r15, r16, r18, r19, r20, r22, r23)
                return r0
        }

        public final vea.raceremote.control.UdpControlSession.Phase component1() {
                r1 = this;
                vea.raceremote.control.UdpControlSession$Phase r0 = r1.phase
                return r0
        }

        public final java.lang.String component2() {
                r1 = this;
                java.lang.String r0 = r1.reason
                return r0
        }

        public final int component3() {
                r1 = this;
                int r0 = r1.acknowledgements
                return r0
        }

        public final long component4() {
                r2 = this;
                long r0 = r2.lastAck
                return r0
        }

        public final int component5() {
                r1 = this;
                int r0 = r1.throttle
                return r0
        }

        public final int component6() {
                r1 = this;
                int r0 = r1.steering
                return r0
        }

        public final long component7() {
                r2 = this;
                long r0 = r2.maxRttMs
                return r0
        }

        public final int component8() {
                r1 = this;
                int r0 = r1.acknowledgedThrottle
                return r0
        }

        public final int component9() {
                r1 = this;
                int r0 = r1.acknowledgedSteering
                return r0
        }

        public final vea.raceremote.control.UdpControlSession.Snapshot copy(vea.raceremote.control.UdpControlSession.Phase r16, java.lang.String r17, int r18, long r19, int r21, int r22, long r23, int r25, int r26) {
                r15 = this;
                java.lang.String r0 = "phase"
                r13 = r16
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r13, r0)
                java.lang.String r0 = "reason"
                r14 = r17
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r14, r0)
                vea.raceremote.control.UdpControlSession$Snapshot r0 = new vea.raceremote.control.UdpControlSession$Snapshot
                r1 = r0
                r2 = r16
                r3 = r17
                r4 = r18
                r5 = r19
                r7 = r21
                r8 = r22
                r9 = r23
                r11 = r25
                r12 = r26
                r1.<init>(r2, r3, r4, r5, r7, r8, r9, r11, r12)
                return r0
        }

        public boolean equals(java.lang.Object r6) {
                r5 = this;
                if (r5 != r6) goto L9
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                boolean r0 = r0.m6686Boolean$branch$when$funequals$classSnapshot$classUdpControlSession()
                return r0
            L9:
                boolean r0 = r6 instanceof vea.raceremote.control.UdpControlSession.Snapshot
                if (r0 != 0) goto L14
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                boolean r0 = r0.m6689Boolean$branch$when1$funequals$classSnapshot$classUdpControlSession()
                return r0
            L14:
                r0 = r6
                vea.raceremote.control.UdpControlSession$Snapshot r0 = (vea.raceremote.control.UdpControlSession.Snapshot) r0
                vea.raceremote.control.UdpControlSession$Phase r1 = r5.phase
                vea.raceremote.control.UdpControlSession$Phase r2 = r0.phase
                if (r1 == r2) goto L24
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                boolean r0 = r0.m6692Boolean$branch$when2$funequals$classSnapshot$classUdpControlSession()
                return r0
            L24:
                java.lang.String r1 = r5.reason
                java.lang.String r2 = r0.reason
                boolean r1 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r2)
                if (r1 != 0) goto L35
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                boolean r0 = r0.m6694Boolean$branch$when3$funequals$classSnapshot$classUdpControlSession()
                return r0
            L35:
                int r1 = r5.acknowledgements
                int r2 = r0.acknowledgements
                if (r1 == r2) goto L42
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                boolean r0 = r0.m6695Boolean$branch$when4$funequals$classSnapshot$classUdpControlSession()
                return r0
            L42:
                long r1 = r5.lastAck
                long r3 = r0.lastAck
                int r1 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
                if (r1 == 0) goto L51
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                boolean r0 = r0.m6696Boolean$branch$when5$funequals$classSnapshot$classUdpControlSession()
                return r0
            L51:
                int r1 = r5.throttle
                int r2 = r0.throttle
                if (r1 == r2) goto L5e
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                boolean r0 = r0.m6697Boolean$branch$when6$funequals$classSnapshot$classUdpControlSession()
                return r0
            L5e:
                int r1 = r5.steering
                int r2 = r0.steering
                if (r1 == r2) goto L6b
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                boolean r0 = r0.m6698Boolean$branch$when7$funequals$classSnapshot$classUdpControlSession()
                return r0
            L6b:
                long r1 = r5.maxRttMs
                long r3 = r0.maxRttMs
                int r1 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
                if (r1 == 0) goto L7a
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                boolean r0 = r0.m6699Boolean$branch$when8$funequals$classSnapshot$classUdpControlSession()
                return r0
            L7a:
                int r1 = r5.acknowledgedThrottle
                int r2 = r0.acknowledgedThrottle
                if (r1 == r2) goto L87
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                boolean r0 = r0.m6700Boolean$branch$when9$funequals$classSnapshot$classUdpControlSession()
                return r0
            L87:
                int r1 = r5.acknowledgedSteering
                int r0 = r0.acknowledgedSteering
                if (r1 == r0) goto L94
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                boolean r0 = r0.m6690Boolean$branch$when10$funequals$classSnapshot$classUdpControlSession()
                return r0
            L94:
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                boolean r0 = r0.m6702Boolean$funequals$classSnapshot$classUdpControlSession()
                return r0
        }

        public final int getAcknowledgedSteering() {
                r1 = this;
                int r0 = r1.acknowledgedSteering
                return r0
        }

        public final int getAcknowledgedThrottle() {
                r1 = this;
                int r0 = r1.acknowledgedThrottle
                return r0
        }

        public final int getAcknowledgements() {
                r1 = this;
                int r0 = r1.acknowledgements
                return r0
        }

        public final long getLastAck() {
                r2 = this;
                long r0 = r2.lastAck
                return r0
        }

        public final long getMaxRttMs() {
                r2 = this;
                long r0 = r2.maxRttMs
                return r0
        }

        public final vea.raceremote.control.UdpControlSession.Phase getPhase() {
                r1 = this;
                vea.raceremote.control.UdpControlSession$Phase r0 = r1.phase
                return r0
        }

        public final java.lang.String getReason() {
                r1 = this;
                java.lang.String r0 = r1.reason
                return r0
        }

        public final int getSteering() {
                r1 = this;
                int r0 = r1.steering
                return r0
        }

        public final int getThrottle() {
                r1 = this;
                int r0 = r1.throttle
                return r0
        }

        public int hashCode() {
                r4 = this;
                vea.raceremote.control.UdpControlSession$Phase r0 = r4.phase
                int r0 = r0.hashCode()
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r1 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                int r1 = r1.m6723Int$arg0$calltimes$$this$callplus$setresult$funhashCode$classSnapshot$classUdpControlSession()
                int r1 = r1 * r0
                java.lang.String r2 = r4.reason
                int r2 = r2.hashCode()
                int r1 = r1 + r2
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                int r0 = r0.m6724Int$arg0$calltimes$$this$callplus$setresult1$funhashCode$classSnapshot$classUdpControlSession()
                int r0 = r0 * r1
                int r2 = r4.acknowledgements
                int r2 = java.lang.Integer.hashCode(r2)
                int r0 = r0 + r2
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r1 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                int r1 = r1.m6725Int$arg0$calltimes$$this$callplus$setresult2$funhashCode$classSnapshot$classUdpControlSession()
                int r1 = r1 * r0
                long r2 = r4.lastAck
                int r2 = java.lang.Long.hashCode(r2)
                int r1 = r1 + r2
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                int r0 = r0.m6726Int$arg0$calltimes$$this$callplus$setresult3$funhashCode$classSnapshot$classUdpControlSession()
                int r0 = r0 * r1
                int r2 = r4.throttle
                int r2 = java.lang.Integer.hashCode(r2)
                int r0 = r0 + r2
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r1 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                int r1 = r1.m6727Int$arg0$calltimes$$this$callplus$setresult4$funhashCode$classSnapshot$classUdpControlSession()
                int r1 = r1 * r0
                int r2 = r4.steering
                int r2 = java.lang.Integer.hashCode(r2)
                int r1 = r1 + r2
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                int r0 = r0.m6728Int$arg0$calltimes$$this$callplus$setresult5$funhashCode$classSnapshot$classUdpControlSession()
                int r0 = r0 * r1
                long r2 = r4.maxRttMs
                int r2 = java.lang.Long.hashCode(r2)
                int r0 = r0 + r2
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r1 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                int r1 = r1.m6729Int$arg0$calltimes$$this$callplus$setresult6$funhashCode$classSnapshot$classUdpControlSession()
                int r1 = r1 * r0
                int r2 = r4.acknowledgedThrottle
                int r2 = java.lang.Integer.hashCode(r2)
                int r1 = r1 + r2
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                int r0 = r0.m6730Int$arg0$calltimes$$this$callplus$setresult7$funhashCode$classSnapshot$classUdpControlSession()
                int r0 = r0 * r1
                int r2 = r4.acknowledgedSteering
                int r2 = java.lang.Integer.hashCode(r2)
                int r0 = r0 + r2
                return r0
        }

        public java.lang.String toString() {
                r4 = this;
                java.lang.StringBuilder r0 = new java.lang.StringBuilder
                r0.<init>()
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r1 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                java.lang.String r1 = r1.m6751String$0$str$funtoString$classSnapshot$classUdpControlSession()
                java.lang.StringBuilder r1 = r0.append(r1)
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r2 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                java.lang.String r2 = r2.m6753String$1$str$funtoString$classSnapshot$classUdpControlSession()
                java.lang.StringBuilder r1 = r1.append(r2)
                vea.raceremote.control.UdpControlSession$Phase r2 = r4.phase
                java.lang.StringBuilder r1 = r1.append(r2)
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r2 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                java.lang.String r2 = r2.m6767String$3$str$funtoString$classSnapshot$classUdpControlSession()
                java.lang.StringBuilder r1 = r1.append(r2)
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r2 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                java.lang.String r2 = r2.m6769String$4$str$funtoString$classSnapshot$classUdpControlSession()
                java.lang.StringBuilder r1 = r1.append(r2)
                java.lang.String r2 = r4.reason
                java.lang.StringBuilder r1 = r1.append(r2)
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r2 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                java.lang.String r2 = r2.m6771String$6$str$funtoString$classSnapshot$classUdpControlSession()
                java.lang.StringBuilder r1 = r1.append(r2)
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r2 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                java.lang.String r2 = r2.m6772String$7$str$funtoString$classSnapshot$classUdpControlSession()
                java.lang.StringBuilder r1 = r1.append(r2)
                int r2 = r4.acknowledgements
                java.lang.StringBuilder r1 = r1.append(r2)
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r2 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                java.lang.String r2 = r2.m6773String$9$str$funtoString$classSnapshot$classUdpControlSession()
                java.lang.StringBuilder r1 = r1.append(r2)
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r2 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                java.lang.String r2 = r2.m6754String$10$str$funtoString$classSnapshot$classUdpControlSession()
                java.lang.StringBuilder r1 = r1.append(r2)
                long r2 = r4.lastAck
                java.lang.StringBuilder r1 = r1.append(r2)
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r2 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                java.lang.String r2 = r2.m6755String$12$str$funtoString$classSnapshot$classUdpControlSession()
                java.lang.StringBuilder r1 = r1.append(r2)
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r2 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                java.lang.String r2 = r2.m6756String$13$str$funtoString$classSnapshot$classUdpControlSession()
                java.lang.StringBuilder r1 = r1.append(r2)
                int r2 = r4.throttle
                java.lang.StringBuilder r1 = r1.append(r2)
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r2 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                java.lang.String r2 = r2.m6757String$15$str$funtoString$classSnapshot$classUdpControlSession()
                java.lang.StringBuilder r1 = r1.append(r2)
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r2 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                java.lang.String r2 = r2.m6758String$16$str$funtoString$classSnapshot$classUdpControlSession()
                java.lang.StringBuilder r1 = r1.append(r2)
                int r2 = r4.steering
                java.lang.StringBuilder r1 = r1.append(r2)
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r2 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                java.lang.String r2 = r2.m6759String$18$str$funtoString$classSnapshot$classUdpControlSession()
                java.lang.StringBuilder r1 = r1.append(r2)
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r2 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                java.lang.String r2 = r2.m6760String$19$str$funtoString$classSnapshot$classUdpControlSession()
                java.lang.StringBuilder r1 = r1.append(r2)
                long r2 = r4.maxRttMs
                java.lang.StringBuilder r1 = r1.append(r2)
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r2 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                java.lang.String r2 = r2.m6761String$21$str$funtoString$classSnapshot$classUdpControlSession()
                java.lang.StringBuilder r1 = r1.append(r2)
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r2 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                java.lang.String r2 = r2.m6762String$22$str$funtoString$classSnapshot$classUdpControlSession()
                r1.append(r2)
                int r1 = r4.acknowledgedThrottle
                java.lang.StringBuilder r1 = r0.append(r1)
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r2 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                java.lang.String r2 = r2.m6763String$24$str$funtoString$classSnapshot$classUdpControlSession()
                java.lang.StringBuilder r1 = r1.append(r2)
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r2 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                java.lang.String r2 = r2.m6764String$25$str$funtoString$classSnapshot$classUdpControlSession()
                java.lang.StringBuilder r1 = r1.append(r2)
                int r2 = r4.acknowledgedSteering
                java.lang.StringBuilder r1 = r1.append(r2)
                vea.raceremote.control.LiveLiterals$UdpControlSessionKt r2 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
                java.lang.String r2 = r2.m6765String$27$str$funtoString$classSnapshot$classUdpControlSession()
                r1.append(r2)
                java.lang.String r0 = r0.toString()
                return r0
        }
    }

    /* JADX INFO: compiled from: UdpControlSession.kt */
    @kotlin.Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0 = null;

        static {
                vea.raceremote.control.UdpControlSession$Phase[] r0 = vea.raceremote.control.UdpControlSession.Phase.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                vea.raceremote.control.UdpControlSession$Phase r1 = vea.raceremote.control.UdpControlSession.Phase.OPENING     // Catch: java.lang.NoSuchFieldError -> L11
                int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L11
                r2 = 1
                r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L11
                goto L12
            L11:
                r1 = move-exception
            L12:
                vea.raceremote.control.UdpControlSession$Phase r1 = vea.raceremote.control.UdpControlSession.Phase.ARMING     // Catch: java.lang.NoSuchFieldError -> L1c
                int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L1c
                r2 = 2
                r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L1c
                goto L1d
            L1c:
                r1 = move-exception
            L1d:
                vea.raceremote.control.UdpControlSession$Phase r1 = vea.raceremote.control.UdpControlSession.Phase.ACTIVE     // Catch: java.lang.NoSuchFieldError -> L27
                int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L27
                r2 = 3
                r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L27
                goto L28
            L27:
                r1 = move-exception
            L28:
                vea.raceremote.control.UdpControlSession$Phase r1 = vea.raceremote.control.UdpControlSession.Phase.CLOSED     // Catch: java.lang.NoSuchFieldError -> L32
                int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L32
                r2 = 4
                r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L32
                goto L33
            L32:
                r1 = move-exception
            L33:
                vea.raceremote.control.UdpControlSession.WhenMappings.$EnumSwitchMapping$0 = r0
                return
        }
    }

    static {
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            int r0 = r0.m6735Int$classUdpControlSession()
            vea.raceremote.control.UdpControlSession.$stable = r0
            return
    }

    public UdpControlSession(long r8, long r10, long r12) {
            r7 = this;
            r7.<init>()
            r7.chipId = r8
            r7.attempt = r10
            r7.openedAt = r12
            r0 = 64
            vea.raceremote.control.UdpControlSession$Sent[] r0 = new vea.raceremote.control.UdpControlSession.Sent[r0]
            r7.pending = r0
            vea.raceremote.control.UdpControlSession$Phase r0 = vea.raceremote.control.UdpControlSession.Phase.OPENING
            r7.phase = r0
            java.lang.String r0 = "Connecting"
            r7.reason = r0
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            int r0 = r0.m6706Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$classUdpControlSession()
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r1 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            long r1 = r1.m6743Long$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$classUdpControlSession()
            long r3 = (long) r0
            int r0 = (r3 > r8 ? 1 : (r3 == r8 ? 0 : -1))
            r3 = 1
            r4 = 0
            if (r0 > 0) goto L30
            int r0 = (r8 > r1 ? 1 : (r8 == r1 ? 0 : -1))
            if (r0 > 0) goto L30
            r0 = r3
            goto L31
        L30:
            r0 = r4
        L31:
            if (r0 == 0) goto L4e
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            int r0 = r0.m6704Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$classUdpControlSession()
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r1 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            long r1 = r1.m6742Long$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$classUdpControlSession()
            long r5 = (long) r0
            int r0 = (r5 > r10 ? 1 : (r5 == r10 ? 0 : -1))
            if (r0 > 0) goto L4a
            int r0 = (r10 > r1 ? 1 : (r10 == r1 ? 0 : -1))
            if (r0 > 0) goto L4a
            r0 = r3
            goto L4b
        L4a:
            r0 = r4
        L4b:
            if (r0 == 0) goto L4e
            goto L4f
        L4e:
            r3 = r4
        L4f:
            if (r3 == 0) goto L52
            return
        L52:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "Failed requirement."
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
    }

    private final void expire(long r5) {
            r4 = this;
            vea.raceremote.control.UdpControlSession$Phase r0 = r4.phase
            int[] r1 = vea.raceremote.control.UdpControlSession.WhenMappings.$EnumSwitchMapping$0
            int r0 = r0.ordinal()
            r0 = r1[r0]
            switch(r0) {
                case 1: goto L4a;
                case 2: goto L28;
                case 3: goto Lf;
                case 4: goto Le;
                default: goto Ld;
            }
        Ld:
            goto L62
        Le:
            goto L62
        Lf:
            long r0 = r4.confirmedAt
            long r0 = r5 - r0
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r2 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            int r2 = r2.m6710Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch2$when$funexpire$classUdpControlSession()
            long r2 = (long) r2
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r0 < 0) goto L62
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            java.lang.String r0 = r0.m6777String$arg0$callstop$branch$if$branch2$when$funexpire$classUdpControlSession()
            r4.stop(r0)
            goto L62
        L28:
            java.lang.Long r0 = r4.armStarted
            if (r0 == 0) goto L31
            long r0 = r0.longValue()
            goto L33
        L31:
            long r0 = r4.helloAt
        L33:
            long r0 = r5 - r0
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r2 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            int r2 = r2.m6709Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch1$when$funexpire$classUdpControlSession()
            long r2 = (long) r2
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r0 < 0) goto L62
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            java.lang.String r0 = r0.m6776String$arg0$callstop$branch$if$branch1$when$funexpire$classUdpControlSession()
            r4.stop(r0)
            goto L62
        L4a:
            long r0 = r4.openedAt
            long r0 = r5 - r0
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r2 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            int r2 = r2.m6708Int$$this$calltoLong$arg1$callgreaterOrEqual$cond$if$branch$when$funexpire$classUdpControlSession()
            long r2 = (long) r2
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r0 < 0) goto L62
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            java.lang.String r0 = r0.m6775String$arg0$callstop$branch$if$branch$when$funexpire$classUdpControlSession()
            r4.stop(r0)
        L62:
            return
    }

    private final vea.raceremote.control.UdpControlPacket packet(int r17, long r18, int r20, int r21, long r22) {
            r16 = this;
            r0 = r16
            vea.raceremote.control.UdpControlPacket r15 = new vea.raceremote.control.UdpControlPacket
            long r3 = r0.attempt
            long r5 = r0.token
            long r11 = r0.chipId
            r1 = r15
            r2 = r17
            r7 = r18
            r9 = r20
            r10 = r21
            r13 = r22
            r1.<init>(r2, r3, r5, r7, r9, r10, r11, r13)
            return r15
    }

    static /* synthetic */ vea.raceremote.control.UdpControlPacket packet$default(vea.raceremote.control.UdpControlSession r9, int r10, long r11, int r13, int r14, long r15, int r17, java.lang.Object r18) {
            r0 = r17 & 4
            if (r0 == 0) goto Lc
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            int r0 = r0.m6738Int$paramt$funpacket$classUdpControlSession()
            r5 = r0
            goto Ld
        Lc:
            r5 = r13
        Ld:
            r0 = r17 & 8
            if (r0 == 0) goto L19
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            int r0 = r0.m6737Int$params$funpacket$classUdpControlSession()
            r6 = r0
            goto L1a
        L19:
            r6 = r14
        L1a:
            r0 = r17 & 16
            if (r0 == 0) goto L26
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            long r0 = r0.m6749Long$parambasis$funpacket$classUdpControlSession()
            r7 = r0
            goto L27
        L26:
            r7 = r15
        L27:
            r1 = r9
            r2 = r10
            r3 = r11
            vea.raceremote.control.UdpControlPacket r0 = r1.packet(r2, r3, r5, r6, r7)
            return r0
    }

    public static /* synthetic */ void stop$default(vea.raceremote.control.UdpControlSession r0, java.lang.String r1, int r2, java.lang.Object r3) {
            r2 = r2 & 1
            if (r2 == 0) goto La
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r1 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            java.lang.String r1 = r1.m6778String$paramreason$funstop$classUdpControlSession()
        La:
            r0.stop(r1)
            return
    }

    public final long getAttempt() {
            r2 = this;
            long r0 = r2.attempt
            return r0
    }

    public final long getChipId() {
            r2 = this;
            long r0 = r2.chipId
            return r0
    }

    public final void input(int r5, int r6) {
            r4 = this;
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            int r0 = r0.m6707Int$$this$callrangeTo$$this$callcontains$cond$arg0$callrequire$funinput$classUdpControlSession()
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r1 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            int r1 = r1.m6717Int$arg0$callrangeTo$$this$callcontains$cond$arg0$callrequire$funinput$classUdpControlSession()
            r2 = 1
            r3 = 0
            if (r5 > r1) goto L14
            if (r0 > r5) goto L14
            r0 = r2
            goto L15
        L14:
            r0 = r3
        L15:
            if (r0 == 0) goto L2d
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            int r0 = r0.m6705Int$$this$callrangeTo$$this$callcontains$branch$arg0$callrequire$funinput$classUdpControlSession()
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r1 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            int r1 = r1.m6716Int$arg0$callrangeTo$$this$callcontains$branch$arg0$callrequire$funinput$classUdpControlSession()
            if (r6 > r1) goto L29
            if (r0 > r6) goto L29
            r0 = r2
            goto L2a
        L29:
            r0 = r3
        L2a:
            if (r0 == 0) goto L2d
            goto L2e
        L2d:
            r2 = r3
        L2e:
            if (r2 == 0) goto L3b
            vea.raceremote.control.UdpControlSession$Phase r0 = r4.phase
            vea.raceremote.control.UdpControlSession$Phase r1 = vea.raceremote.control.UdpControlSession.Phase.ACTIVE
            if (r0 != r1) goto L3a
            r4.throttle = r5
            r4.steering = r6
        L3a:
            return
        L3b:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "Failed requirement."
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
    }

    public final vea.raceremote.control.UdpControlPacket next(long r15) {
            r14 = this;
            r10 = r14
            r11 = r15
            r14.expire(r15)
            vea.raceremote.control.UdpControlSession$Phase r0 = r10.phase
            vea.raceremote.control.UdpControlSession$Phase r1 = vea.raceremote.control.UdpControlSession.Phase.CLOSED
            r2 = 0
            if (r0 != r1) goto L13
            vea.raceremote.control.UdpControlPacket r0 = r10.stopping
            r1 = r0
            r3 = 0
            r10.stopping = r2
            return r0
        L13:
            vea.raceremote.control.UdpControlSession$Phase r0 = r10.phase
            int[] r1 = vea.raceremote.control.UdpControlSession.WhenMappings.$EnumSwitchMapping$0
            int r0 = r0.ordinal()
            r0 = r1[r0]
            switch(r0) {
                case 1: goto L2e;
                case 2: goto L27;
                default: goto L20;
            }
        L20:
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            int r0 = r0.m6736Int$else$when$valinterval$funnext$classUdpControlSession()
            goto L34
        L27:
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            int r0 = r0.m6733Int$branch1$when$valinterval$funnext$classUdpControlSession()
            goto L34
        L2e:
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            int r0 = r0.m6732Int$branch$when$valinterval$funnext$classUdpControlSession()
        L34:
            r13 = r0
            java.lang.Long r0 = r10.lastSent
            r1 = 0
            if (r0 == 0) goto L55
            java.lang.Number r0 = (java.lang.Number) r0
            long r3 = r0.longValue()
            r0 = 0
            long r5 = r11 - r3
            long r7 = (long) r13
            int r5 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            r6 = 1
            if (r5 >= 0) goto L4b
            r0 = r6
            goto L4c
        L4b:
            r0 = r1
        L4c:
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r3 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            boolean r3 = r3.m6678Boolean$arg1$callEQEQ$cond$if1$funnext$classUdpControlSession()
            if (r0 != r3) goto L55
            r1 = r6
        L55:
            if (r1 == 0) goto L58
            return r2
        L58:
            vea.raceremote.control.UdpControlSession$Phase r0 = r10.phase
            int[] r1 = vea.raceremote.control.UdpControlSession.WhenMappings.$EnumSwitchMapping$0
            int r0 = r0.ordinal()
            r0 = r1[r0]
            switch(r0) {
                case 1: goto Ld3;
                case 2: goto La3;
                case 3: goto L6c;
                case 4: goto L6b;
                default: goto L65;
            }
        L65:
            kotlin.NoWhenBranchMatchedException r0 = new kotlin.NoWhenBranchMatchedException
            r0.<init>()
            throw r0
        L6b:
            return r2
        L6c:
            long r0 = r10.sequence
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r2 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            int r2 = r2.m6715Int$arg0$callplus$$this$calland$arg0$call$setsequence$$branch2$when$valp$funnext$classUdpControlSession()
            long r2 = (long) r2
            long r0 = r0 + r2
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r2 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            long r2 = r2.m6740Long$arg0$calland$arg0$call$setsequence$$branch2$when$valp$funnext$classUdpControlSession()
            long r2 = r2 & r0
            r10.sequence = r2
            r1 = 2
            int r4 = r10.throttle
            int r5 = r10.steering
            long r6 = r10.lastAck
            r0 = r14
            vea.raceremote.control.UdpControlPacket r0 = r0.packet(r1, r2, r4, r5, r6)
            r1 = r0
            r2 = 0
            vea.raceremote.control.UdpControlSession$Sent[] r3 = r10.pending
            long r4 = r10.sequence
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r6 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            int r6 = r6.m6719Int$arg0$callrem$$this$calltoInt$arg0$callset$fun$anonymous$$arg0$callalso$branch2$when$valp$funnext$classUdpControlSession()
            long r6 = (long) r6
            long r4 = r4 % r6
            int r4 = (int) r4
            vea.raceremote.control.UdpControlSession$Sent r5 = new vea.raceremote.control.UdpControlSession$Sent
            r5.<init>(r1, r11)
            r3[r4] = r5
            goto Le6
        La3:
            r1 = 1
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            long r2 = r0.m6747Long$arg1$callpacket$$$this$callalso$branch1$when$valp$funnext$classUdpControlSession()
            r4 = 0
            r5 = 0
            r6 = 0
            r8 = 28
            r9 = 0
            r0 = r14
            vea.raceremote.control.UdpControlPacket r0 = packet$default(r0, r1, r2, r4, r5, r6, r8, r9)
            r1 = r0
            r2 = 0
            java.lang.Long r3 = r10.armStarted
            if (r3 != 0) goto Ld1
            java.lang.Long r3 = java.lang.Long.valueOf(r15)
            r10.armStarted = r3
            vea.raceremote.control.UdpControlSession$Sent[] r3 = r10.pending
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r4 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            int r4 = r4.m6721Int$arg0$callset$branch$if$fun$anonymous$$arg0$callalso$branch1$when$valp$funnext$classUdpControlSession()
            vea.raceremote.control.UdpControlSession$Sent r5 = new vea.raceremote.control.UdpControlSession$Sent
            r5.<init>(r1, r11)
            r3[r4] = r5
        Ld1:
            goto Le6
        Ld3:
            r1 = 0
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            long r2 = r0.m6748Long$arg1$callpacket$branch$when$valp$funnext$classUdpControlSession()
            r4 = 0
            r5 = 0
            r6 = 0
            r8 = 28
            r9 = 0
            r0 = r14
            vea.raceremote.control.UdpControlPacket r0 = packet$default(r0, r1, r2, r4, r5, r6, r8, r9)
        Le6:
            java.lang.Long r1 = java.lang.Long.valueOf(r15)
            r10.lastSent = r1
            return r0
    }

    public final boolean receive(vea.raceremote.control.UdpControlPacket r11, long r12) {
            r10 = this;
            java.lang.String r0 = "p"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r11, r0)
            r10.expire(r12)
            vea.raceremote.control.UdpControlSession$Phase r0 = r10.phase
            vea.raceremote.control.UdpControlSession$Phase r1 = vea.raceremote.control.UdpControlSession.Phase.CLOSED
            if (r0 == r1) goto L191
            long r0 = r11.getChipId()
            long r2 = r10.chipId
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r0 != 0) goto L191
            long r0 = r11.getAttempt()
            long r2 = r10.attempt
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r0 != 0) goto L191
            long r0 = r11.getBasis()
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r2 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            long r2 = r2.m6746Long$arg1$callEQEQ$$this$callnot$else$cond$if$funreceive$classUdpControlSession()
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r0 == 0) goto L32
            goto L191
        L32:
            vea.raceremote.control.UdpControlSession$Phase r0 = r10.phase
            vea.raceremote.control.UdpControlSession$Phase r1 = vea.raceremote.control.UdpControlSession.Phase.OPENING
            r2 = 0
            if (r0 != r1) goto L82
            int r0 = r11.getKind()
            r1 = 128(0x80, float:1.8E-43)
            if (r0 != r1) goto L7b
            long r0 = r11.getToken()
            r3 = 0
            int r0 = (r0 > r3 ? 1 : (r0 == r3 ? 0 : -1))
            if (r0 == 0) goto L7b
            long r0 = r11.getSequence()
            int r0 = (r0 > r3 ? 1 : (r0 == r3 ? 0 : -1))
            if (r0 != 0) goto L7b
            int r0 = r11.getThrottle()
            if (r0 != 0) goto L7b
            int r0 = r11.getSteering()
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r1 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            int r1 = r1.m6731Int$arg1$callEQEQ$$this$callnot$else$cond$if$branch$if1$funreceive$classUdpControlSession()
            if (r0 == r1) goto L66
            goto L7b
        L66:
            long r0 = r11.getToken()
            r10.token = r0
            r10.helloAt = r12
            r10.lastSent = r2
            vea.raceremote.control.UdpControlSession$Phase r0 = vea.raceremote.control.UdpControlSession.Phase.ARMING
            r10.phase = r0
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            boolean r0 = r0.m6681Boolean$branch$if1$funreceive$classUdpControlSession()
            return r0
        L7b:
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            boolean r0 = r0.m6679Boolean$branch$if$branch$if1$funreceive$classUdpControlSession()
            return r0
        L82:
            int r0 = r11.getKind()
            r1 = 129(0x81, float:1.81E-43)
            if (r0 != r1) goto L18a
            long r0 = r11.getToken()
            long r3 = r10.token
            int r0 = (r0 > r3 ? 1 : (r0 == r3 ? 0 : -1))
            if (r0 == 0) goto L96
            goto L18a
        L96:
            vea.raceremote.control.UdpControlSession$Sent[] r0 = r10.pending
            long r3 = r11.getSequence()
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r1 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            int r1 = r1.m6718Int$arg0$callrem$$this$calltoInt$arg0$callget$valtmp0_elvis_lhs$valsent$funreceive$classUdpControlSession()
            long r5 = (long) r1
            long r3 = r3 % r5
            int r1 = (int) r3
            r0 = r0[r1]
            if (r0 != 0) goto Lb0
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            boolean r0 = r0.m6687Boolean$branch$when$valsent$funreceive$classUdpControlSession()
            return r0
        Lb0:
            long r3 = r11.getSequence()
            long r5 = r10.lastAck
            long r3 = r3 - r5
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r1 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            long r5 = r1.m6741Long$arg0$calland$valdistance$funreceive$classUdpControlSession()
            long r3 = r3 & r5
            vea.raceremote.control.UdpControlPacket r1 = r0.getPacket()
            long r5 = r1.getSequence()
            long r7 = r11.getSequence()
            int r1 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r1 != 0) goto L183
            r5 = 1
            int r1 = (r5 > r3 ? 1 : (r5 == r3 ? 0 : -1))
            r5 = 1
            r6 = 0
            if (r1 > 0) goto Le0
            r7 = 2147483648(0x80000000, double:1.0609978955E-314)
            int r1 = (r3 > r7 ? 1 : (r3 == r7 ? 0 : -1))
            if (r1 >= 0) goto Le0
            r6 = r5
        Le0:
            if (r6 == 0) goto L183
            long r6 = r0.getAt()
            long r6 = r12 - r6
            r8 = 200(0xc8, double:9.9E-322)
            int r1 = (r6 > r8 ? 1 : (r6 == r8 ? 0 : -1))
            if (r1 >= 0) goto L183
            int r1 = r11.getThrottle()
            vea.raceremote.control.UdpControlPacket r6 = r0.getPacket()
            int r6 = r6.getThrottle()
            if (r1 != r6) goto L183
            int r1 = r11.getSteering()
            vea.raceremote.control.UdpControlPacket r6 = r0.getPacket()
            int r6 = r6.getSteering()
            if (r1 == r6) goto L10b
            goto L183
        L10b:
            vea.raceremote.control.UdpControlSession$Phase r1 = r10.phase
            vea.raceremote.control.UdpControlSession$Phase r6 = vea.raceremote.control.UdpControlSession.Phase.ARMING
            if (r1 != r6) goto L126
            long r6 = r11.getSequence()
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r1 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            long r8 = r1.m6744Long$arg1$callEQEQ$$this$callnot$branch$cond$if4$funreceive$classUdpControlSession()
            int r1 = (r6 > r8 ? 1 : (r6 == r8 ? 0 : -1))
            if (r1 == 0) goto L126
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r1 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            boolean r1 = r1.m6684Boolean$branch$if4$funreceive$classUdpControlSession()
            return r1
        L126:
            long r6 = r11.getSequence()
            r10.lastAck = r6
            long r6 = r0.getAt()
            r10.confirmedAt = r6
            int r1 = r10.acknowledgements
            int r1 = r1 + r5
            r10.acknowledgements = r1
            int r1 = r11.getThrottle()
            r10.acknowledgedThrottle = r1
            int r1 = r11.getSteering()
            r10.acknowledgedSteering = r1
            long r5 = r10.maxRttMs
            long r7 = r0.getAt()
            long r7 = r12 - r7
            long r5 = java.lang.Math.max(r5, r7)
            r10.maxRttMs = r5
            vea.raceremote.control.UdpControlSession$Sent[] r1 = r10.pending
            long r5 = r11.getSequence()
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r7 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            int r7 = r7.m6720Int$arg0$callrem$$this$calltoInt$arg0$callset$funreceive$classUdpControlSession()
            long r7 = (long) r7
            long r5 = r5 % r7
            int r5 = (int) r5
            r1[r5] = r2
            vea.raceremote.control.UdpControlSession$Phase r1 = r10.phase
            vea.raceremote.control.UdpControlSession$Phase r2 = vea.raceremote.control.UdpControlSession.Phase.ARMING
            if (r1 != r2) goto L17c
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r1 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            long r1 = r1.m6739Long$arg0$call$setsequence$$branch$if5$funreceive$classUdpControlSession()
            r10.sequence = r1
            vea.raceremote.control.UdpControlSession$Phase r1 = vea.raceremote.control.UdpControlSession.Phase.ACTIVE
            r10.phase = r1
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r1 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            java.lang.String r1 = r1.m6774String$arg0$call$setreason$$branch$if5$funreceive$classUdpControlSession()
            r10.reason = r1
        L17c:
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r1 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            boolean r1 = r1.m6703Boolean$funreceive$classUdpControlSession()
            return r1
        L183:
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r1 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            boolean r1 = r1.m6683Boolean$branch$if3$funreceive$classUdpControlSession()
            return r1
        L18a:
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            boolean r0 = r0.m6682Boolean$branch$if2$funreceive$classUdpControlSession()
            return r0
        L191:
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            boolean r0 = r0.m6680Boolean$branch$if$funreceive$classUdpControlSession()
            return r0
    }

    public final vea.raceremote.control.UdpControlSession.Snapshot snapshot() {
            r13 = this;
            vea.raceremote.control.UdpControlSession$Snapshot r12 = new vea.raceremote.control.UdpControlSession$Snapshot
            vea.raceremote.control.UdpControlSession$Phase r1 = r13.phase
            java.lang.String r2 = r13.reason
            int r3 = r13.acknowledgements
            long r4 = r13.lastAck
            int r6 = r13.throttle
            int r7 = r13.steering
            long r8 = r13.maxRttMs
            int r10 = r13.acknowledgedThrottle
            int r11 = r13.acknowledgedSteering
            r0 = r12
            r0.<init>(r1, r2, r3, r4, r6, r7, r8, r10, r11)
            return r12
    }

    public final void stop(java.lang.String r12) {
            r11 = this;
            java.lang.String r0 = "reason"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r12, r0)
            vea.raceremote.control.UdpControlSession$Phase r0 = r11.phase
            vea.raceremote.control.UdpControlSession$Phase r1 = vea.raceremote.control.UdpControlSession.Phase.CLOSED
            if (r0 != r1) goto Lc
            return
        Lc:
            long r0 = r11.token
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r2 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            long r2 = r2.m6745Long$arg1$callEQEQ$$this$callnot$cond$if1$funstop$classUdpControlSession()
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r0 == 0) goto L29
            r2 = 3
            long r3 = r11.sequence
            r5 = 0
            r6 = 0
            r7 = 0
            r9 = 28
            r10 = 0
            r1 = r11
            vea.raceremote.control.UdpControlPacket r0 = packet$default(r1, r2, r3, r5, r6, r7, r9, r10)
            r11.stopping = r0
        L29:
            vea.raceremote.control.UdpControlSession$Phase r0 = vea.raceremote.control.UdpControlSession.Phase.CLOSED
            r11.phase = r0
            r11.reason = r12
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            int r0 = r0.m6714Int$arg0$call$setthrottle$$funstop$classUdpControlSession()
            r11.throttle = r0
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            int r0 = r0.m6713Int$arg0$call$setsteering$$funstop$classUdpControlSession()
            r11.steering = r0
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            int r0 = r0.m6712Int$arg0$call$setacknowledgedThrottle$$funstop$classUdpControlSession()
            r11.acknowledgedThrottle = r0
            vea.raceremote.control.LiveLiterals$UdpControlSessionKt r0 = vea.raceremote.control.LiveLiterals$UdpControlSessionKt.INSTANCE
            int r0 = r0.m6711Int$arg0$call$setacknowledgedSteering$$funstop$classUdpControlSession()
            r11.acknowledgedSteering = r0
            vea.raceremote.control.UdpControlSession$Sent[] r1 = r11.pending
            r2 = 0
            r3 = 0
            r4 = 0
            r5 = 6
            r6 = 0
            kotlin.collections.ArraysKt.fill$default(r1, r2, r3, r4, r5, r6)
            return
    }
}
