package vea.raceremote.utils;

/* JADX INFO: compiled from: ComposeUtils.kt */
/* JADX INFO: loaded from: classes8.dex */
@kotlin.Metadata(d1 = {"\u00008\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\u001a\u001d\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\u0007ø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b\u0004\u0010\u0005\u001a8\u0010\u0006\u001a\u00020\u0007*\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\n2\u0017\u0010\u000b\u001a\u0013\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u00070\f¢\u0006\u0002\b\u000eH\u0086@ø\u0001\u0001¢\u0006\u0002\u0010\u000f\u001a\u0014\u0010\u0010\u001a\u00020\u0003*\u00020\u0011H\u0007ø\u0001\u0001¢\u0006\u0002\u0010\u0012\u0082\u0002\u000b\n\u0005\b¡\u001e0\u0001\n\u0002\b\u0019¨\u0006\u0013"}, d2 = {"dpToSp", "Landroidx/compose/ui/unit/TextUnit;", "dp", "Landroidx/compose/ui/unit/Dp;", "dpToSp-8Feqmps", "(FLandroidx/compose/runtime/Composer;I)J", "awaitPointerEventInfinitely", "", "Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;", "pass", "Landroidx/compose/ui/input/pointer/PointerEventPass;", "block", "Lkotlin/Function1;", "Landroidx/compose/ui/input/pointer/PointerEvent;", "Lkotlin/ExtensionFunctionType;", "(Landroidx/compose/ui/input/pointer/AwaitPointerEventScope;Landroidx/compose/ui/input/pointer/PointerEventPass;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "pxToDp", "", "(ILandroidx/compose/runtime/Composer;I)F", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class ComposeUtilsKt {

    /* JADX INFO: renamed from: vea.raceremote.utils.ComposeUtilsKt$awaitPointerEventInfinitely$1, reason: invalid class name */
    /* JADX INFO: compiled from: ComposeUtils.kt */
    @kotlin.Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "vea.raceremote.utils.ComposeUtilsKt", f = "ComposeUtils.kt", i = {0, 0, 0}, l = {22}, m = "awaitPointerEventInfinitely", n = {"$this$awaitPointerEventInfinitely", "pass", "block"}, s = {"L$0", "L$1", "L$2"})
    static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.ContinuationImpl {
        java.lang.Object L$0;
        java.lang.Object L$1;
        java.lang.Object L$2;
        int label;
        /* synthetic */ java.lang.Object result;

        AnonymousClass1(kotlin.coroutines.Continuation<? super vea.raceremote.utils.ComposeUtilsKt.AnonymousClass1> r1) {
                r0 = this;
                r0.<init>(r1)
                return
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object r3) {
                r2 = this;
                r2.result = r3
                int r0 = r2.label
                r1 = -2147483648(0xffffffff80000000, float:-0.0)
                r0 = r0 | r1
                r2.label = r0
                r0 = 0
                r1 = r2
                kotlin.coroutines.Continuation r1 = (kotlin.coroutines.Continuation) r1
                java.lang.Object r0 = vea.raceremote.utils.ComposeUtilsKt.awaitPointerEventInfinitely(r0, r0, r0, r1)
                return r0
        }
    }

    public static final java.lang.Object awaitPointerEventInfinitely(androidx.compose.ui.input.pointer.AwaitPointerEventScope r5, androidx.compose.ui.input.pointer.PointerEventPass r6, kotlin.jvm.functions.Function1<? super androidx.compose.ui.input.pointer.PointerEvent, kotlin.Unit> r7, kotlin.coroutines.Continuation<? super kotlin.Unit> r8) {
            boolean r0 = r8 instanceof vea.raceremote.utils.ComposeUtilsKt.AnonymousClass1
            if (r0 == 0) goto L14
            r0 = r8
            vea.raceremote.utils.ComposeUtilsKt$awaitPointerEventInfinitely$1 r0 = (vea.raceremote.utils.ComposeUtilsKt.AnonymousClass1) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r1 = r1 & r2
            if (r1 == 0) goto L14
            int r8 = r0.label
            int r8 = r8 - r2
            r0.label = r8
            goto L19
        L14:
            vea.raceremote.utils.ComposeUtilsKt$awaitPointerEventInfinitely$1 r0 = new vea.raceremote.utils.ComposeUtilsKt$awaitPointerEventInfinitely$1
            r0.<init>(r8)
        L19:
            r8 = r0
            java.lang.Object r0 = r8.result
            java.lang.Object r1 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
            int r2 = r8.label
            switch(r2) {
                case 0: goto L3f;
                case 1: goto L2d;
                default: goto L25;
            }
        L25:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
            r5.<init>(r6)
            throw r5
        L2d:
            java.lang.Object r5 = r8.L$2
            kotlin.jvm.functions.Function1 r5 = (kotlin.jvm.functions.Function1) r5
            java.lang.Object r6 = r8.L$1
            androidx.compose.ui.input.pointer.PointerEventPass r6 = (androidx.compose.ui.input.pointer.PointerEventPass) r6
            java.lang.Object r7 = r8.L$0
            androidx.compose.ui.input.pointer.AwaitPointerEventScope r7 = (androidx.compose.ui.input.pointer.AwaitPointerEventScope) r7
            kotlin.ResultKt.throwOnFailure(r0)
            r2 = r1
            r1 = r0
            goto L5a
        L3f:
            kotlin.ResultKt.throwOnFailure(r0)
            r4 = r7
            r7 = r5
            r5 = r4
        L45:
            r8.L$0 = r7
            r8.L$1 = r6
            r8.L$2 = r5
            r2 = 1
            r8.label = r2
            java.lang.Object r2 = r7.awaitPointerEvent(r6, r8)
            if (r2 != r1) goto L56
            return r1
        L56:
            r4 = r1
            r1 = r0
            r0 = r2
            r2 = r4
        L5a:
            androidx.compose.ui.input.pointer.PointerEvent r0 = (androidx.compose.ui.input.pointer.PointerEvent) r0
            r3 = 0
            r5.invoke(r0)
            r0 = r1
            r1 = r2
            goto L45
    }

    public static /* synthetic */ java.lang.Object awaitPointerEventInfinitely$default(androidx.compose.ui.input.pointer.AwaitPointerEventScope r0, androidx.compose.ui.input.pointer.PointerEventPass r1, kotlin.jvm.functions.Function1 r2, kotlin.coroutines.Continuation r3, int r4, java.lang.Object r5) {
            r4 = r4 & 1
            if (r4 == 0) goto L6
            androidx.compose.ui.input.pointer.PointerEventPass r1 = androidx.compose.ui.input.pointer.PointerEventPass.Main
        L6:
            java.lang.Object r0 = awaitPointerEventInfinitely(r0, r1, r2, r3)
            return r0
    }

    /* JADX INFO: renamed from: dpToSp-8Feqmps, reason: not valid java name */
    public static final long m6983dpToSp8Feqmps(float r5, androidx.compose.runtime.Composer r6, int r7) {
            r0 = 86741224(0x52b90e8, float:8.0669964E-36)
            r6.startReplaceableGroup(r0)
            java.lang.String r1 = "C(dpToSp)P(0:c#ui.unit.Dp)*11@420L7:ComposeUtils.kt#ue36q2"
            androidx.compose.runtime.ComposerKt.sourceInformation(r6, r1)
            boolean r1 = androidx.compose.runtime.ComposerKt.isTraceInProgress()
            if (r1 == 0) goto L17
            r1 = -1
            java.lang.String r2 = "vea.raceremote.utils.dpToSp (ComposeUtils.kt:11)"
            androidx.compose.runtime.ComposerKt.traceEventStart(r0, r7, r1, r2)
        L17:
            androidx.compose.runtime.ProvidableCompositionLocal r0 = androidx.compose.ui.platform.CompositionLocalsKt.getLocalDensity()
            androidx.compose.runtime.CompositionLocal r0 = (androidx.compose.runtime.CompositionLocal) r0
            r1 = 0
            r2 = 0
            r3 = 2023513938(0x789c5f52, float:2.5372864E34)
            java.lang.String r4 = "C:CompositionLocal.kt#9igjgp"
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(r6, r3, r4)
            java.lang.Object r3 = r6.consume(r0)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(r6)
            r0 = r3
            androidx.compose.ui.unit.Density r0 = (androidx.compose.ui.unit.Density) r0
            r1 = 0
            long r0 = r0.mo324toSp0xMU5do(r5)
            boolean r2 = androidx.compose.runtime.ComposerKt.isTraceInProgress()
            if (r2 == 0) goto L3f
            androidx.compose.runtime.ComposerKt.traceEventEnd()
        L3f:
            r6.endReplaceableGroup()
            return r0
    }

    public static final float pxToDp(int r6, androidx.compose.runtime.Composer r7, int r8) {
            r0 = 1267577849(0x4b8db3f9, float:1.8573298E7)
            r7.startReplaceableGroup(r0)
            java.lang.String r1 = "C(pxToDp)*14@500L7:ComposeUtils.kt#ue36q2"
            androidx.compose.runtime.ComposerKt.sourceInformation(r7, r1)
            boolean r1 = androidx.compose.runtime.ComposerKt.isTraceInProgress()
            if (r1 == 0) goto L17
            r1 = -1
            java.lang.String r2 = "vea.raceremote.utils.pxToDp (ComposeUtils.kt:14)"
            androidx.compose.runtime.ComposerKt.traceEventStart(r0, r8, r1, r2)
        L17:
            float r0 = (float) r6
            androidx.compose.runtime.ProvidableCompositionLocal r1 = androidx.compose.ui.platform.CompositionLocalsKt.getLocalDensity()
            androidx.compose.runtime.CompositionLocal r1 = (androidx.compose.runtime.CompositionLocal) r1
            r2 = 0
            r3 = 0
            r4 = 2023513938(0x789c5f52, float:2.5372864E34)
            java.lang.String r5 = "C:CompositionLocal.kt#9igjgp"
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(r7, r4, r5)
            java.lang.Object r4 = r7.consume(r1)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(r7)
            androidx.compose.ui.unit.Density r4 = (androidx.compose.ui.unit.Density) r4
            float r1 = r4.getDensity()
            float r0 = r0 / r1
            r1 = 0
            float r0 = androidx.compose.ui.unit.Dp.m4046constructorimpl(r0)
            boolean r1 = androidx.compose.runtime.ComposerKt.isTraceInProgress()
            if (r1 == 0) goto L44
            androidx.compose.runtime.ComposerKt.traceEventEnd()
        L44:
            r7.endReplaceableGroup()
            return r0
    }
}
