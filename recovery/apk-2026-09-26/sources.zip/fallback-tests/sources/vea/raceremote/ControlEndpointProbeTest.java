package vea.raceremote;

/* JADX INFO: compiled from: ControlEndpointProbeTest.kt */
/* JADX INFO: loaded from: classes4.dex */
@kotlin.Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0007¨\u0006\u0005"}, d2 = {"Lvea/raceremote/ControlEndpointProbeTest;", "", "()V", "realJsonProbeRejectsRedirectOversizeAndInvalidStatus", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class ControlEndpointProbeTest {
    public static final int $stable = 0;

    static {
            vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt r0 = vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt.INSTANCE
            int r0 = r0.m622Int$classControlEndpointProbeTest()
            vea.raceremote.ControlEndpointProbeTest.$stable = r0
            return
    }

    public ControlEndpointProbeTest() {
            r0 = this;
            r0.<init>()
            return
    }

    @org.junit.Test
    public final void realJsonProbeRejectsRedirectOversizeAndInvalidStatus() {
            r13 = this;
            okhttp3.mockwebserver.MockWebServer r0 = new okhttp3.mockwebserver.MockWebServer
            r0.<init>()
            vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt r1 = vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt.INSTANCE
            java.lang.String r1 = r1.m633String$valvalid$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest()
            okhttp3.mockwebserver.MockResponse r2 = new okhttp3.mockwebserver.MockResponse
            r2.<init>()
            okhttp3.mockwebserver.MockResponse r2 = r2.setBody(r1)
            r0.enqueue(r2)
            okhttp3.mockwebserver.MockResponse r2 = new okhttp3.mockwebserver.MockResponse
            r2.<init>()
            vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt r3 = vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt.INSTANCE
            int r3 = r3.m621Int$arg0$callsetResponseCode$$this$callsetHeader$arg0$callenqueue1$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest()
            okhttp3.mockwebserver.MockResponse r2 = r2.setResponseCode(r3)
            vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt r3 = vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt.INSTANCE
            java.lang.String r3 = r3.m630String$arg0$callsetHeader$arg0$callenqueue1$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest()
            vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt r4 = vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt.INSTANCE
            java.lang.String r4 = r4.m632String$arg1$callsetHeader$arg0$callenqueue1$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest()
            okhttp3.mockwebserver.MockResponse r2 = r2.setHeader(r3, r4)
            r0.enqueue(r2)
            okhttp3.mockwebserver.MockResponse r2 = new okhttp3.mockwebserver.MockResponse
            r2.<init>()
            vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt r3 = vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt.INSTANCE
            java.lang.String r3 = r3.m624String$$$this$callrepeat$arg0$callsetBody$arg0$callenqueue2$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest()
            java.lang.CharSequence r3 = (java.lang.CharSequence) r3
            vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt r4 = vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt.INSTANCE
            int r4 = r4.m619Int$arg0$callrepeat$arg0$callsetBody$arg0$callenqueue2$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest()
            java.lang.String r3 = kotlin.text.StringsKt.repeat(r3, r4)
            okhttp3.mockwebserver.MockResponse r2 = r2.setBody(r3)
            r0.enqueue(r2)
            okhttp3.mockwebserver.MockResponse r8 = new okhttp3.mockwebserver.MockResponse
            r8.<init>()
            vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt r2 = vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt.INSTANCE
            java.lang.String r3 = r2.m628String$arg0$callreplace$arg0$callsetBody$arg0$callenqueue3$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest()
            vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt r2 = vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt.INSTANCE
            java.lang.String r4 = r2.m631String$arg1$callreplace$arg0$callsetBody$arg0$callenqueue3$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest()
            r5 = 0
            r6 = 4
            r7 = 0
            r2 = r1
            java.lang.String r2 = kotlin.text.StringsKt.replace$default(r2, r3, r4, r5, r6, r7)
            okhttp3.mockwebserver.MockResponse r2 = r8.setBody(r2)
            r0.enqueue(r2)
            okhttp3.mockwebserver.MockResponse r2 = new okhttp3.mockwebserver.MockResponse
            r2.<init>()
            vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt r3 = vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt.INSTANCE
            java.lang.String r3 = r3.m629String$arg0$callsetBody$arg0$callenqueue4$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest()
            okhttp3.mockwebserver.MockResponse r2 = r2.setBody(r3)
            r0.enqueue(r2)
            r0.start()
            okhttp3.OkHttpClient r2 = new okhttp3.OkHttpClient
            r2.<init>()
            vea.raceremote.control.ControlEndpointProbe r3 = vea.raceremote.control.ControlEndpointProbe.INSTANCE     // Catch: java.lang.Throwable -> L123
            vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt r4 = vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt.INSTANCE     // Catch: java.lang.Throwable -> L123
            java.lang.String r4 = r4.m627String$arg0$callload$valendpoint$try$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest()     // Catch: java.lang.Throwable -> L123
            int r5 = r0.getPort()     // Catch: java.lang.Throwable -> L123
            vea.raceremote.control.ControlEndpoint r3 = r3.load(r4, r2, r5)     // Catch: java.lang.Throwable -> L123
            vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt r4 = vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt.INSTANCE     // Catch: java.lang.Throwable -> L123
            java.lang.String r4 = r4.m625String$arg0$callassertEquals$try$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest()     // Catch: java.lang.Throwable -> L123
            java.lang.String r5 = r3.getTransport()     // Catch: java.lang.Throwable -> L123
            org.junit.Assert.assertEquals(r4, r5)     // Catch: java.lang.Throwable -> L123
            vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt r4 = vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt.INSTANCE     // Catch: java.lang.Throwable -> L123
            long r4 = r4.m623Long$arg0$callassertEquals1$try$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest()     // Catch: java.lang.Throwable -> L123
            long r6 = r3.getChipId()     // Catch: java.lang.Throwable -> L123
            org.junit.Assert.assertEquals(r4, r6)     // Catch: java.lang.Throwable -> L123
            vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt r4 = vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt.INSTANCE     // Catch: java.lang.Throwable -> L123
            int r4 = r4.m620Int$arg0$callrepeat$try$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest()     // Catch: java.lang.Throwable -> L123
            r5 = 0
        Lc3:
            if (r5 >= r4) goto Lf8
            r6 = r5
            r7 = 0
            kotlin.Result$Companion r8 = kotlin.Result.Companion     // Catch: java.lang.Throwable -> Le2
            r8 = r13
            vea.raceremote.ControlEndpointProbeTest r8 = (vea.raceremote.ControlEndpointProbeTest) r8     // Catch: java.lang.Throwable -> Le2
            r9 = 0
            vea.raceremote.control.ControlEndpointProbe r10 = vea.raceremote.control.ControlEndpointProbe.INSTANCE     // Catch: java.lang.Throwable -> Le2
            vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt r11 = vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le2
            java.lang.String r11 = r11.m626String$arg0$callload$fun$anonymous$$arg0$callrunCatching$$this$call$getisFailure$$arg0$callassertTrue$fun$anonymous$$arg1$callrepeat$try$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest()     // Catch: java.lang.Throwable -> Le2
            int r12 = r0.getPort()     // Catch: java.lang.Throwable -> Le2
            vea.raceremote.control.ControlEndpoint r10 = r10.load(r11, r2, r12)     // Catch: java.lang.Throwable -> Le2
            java.lang.Object r8 = kotlin.Result.constructor-impl(r10)     // Catch: java.lang.Throwable -> Le2
            goto Led
        Le2:
            r8 = move-exception
            kotlin.Result$Companion r9 = kotlin.Result.Companion     // Catch: java.lang.Throwable -> L123
            java.lang.Object r8 = kotlin.ResultKt.createFailure(r8)     // Catch: java.lang.Throwable -> L123
            java.lang.Object r8 = kotlin.Result.constructor-impl(r8)     // Catch: java.lang.Throwable -> L123
        Led:
            boolean r8 = kotlin.Result.isFailure-impl(r8)     // Catch: java.lang.Throwable -> L123
            org.junit.Assert.assertTrue(r8)     // Catch: java.lang.Throwable -> L123
            int r5 = r5 + 1
            goto Lc3
        Lf8:
            vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt r4 = vea.raceremote.LiveLiterals$ControlEndpointProbeTestKt.INSTANCE     // Catch: java.lang.Throwable -> L123
            int r4 = r4.m618Int$arg0$callassertEquals2$try$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest()     // Catch: java.lang.Throwable -> L123
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)     // Catch: java.lang.Throwable -> L123
            int r5 = r0.getRequestCount()     // Catch: java.lang.Throwable -> L123
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)     // Catch: java.lang.Throwable -> L123
            org.junit.Assert.assertEquals(r4, r5)     // Catch: java.lang.Throwable -> L123
            r0.shutdown()
            okhttp3.Dispatcher r3 = r2.dispatcher()
            java.util.concurrent.ExecutorService r3 = r3.executorService()
            r3.shutdown()
            okhttp3.ConnectionPool r3 = r2.connectionPool()
            r3.evictAll()
            return
        L123:
            r3 = move-exception
            r0.shutdown()
            okhttp3.Dispatcher r4 = r2.dispatcher()
            java.util.concurrent.ExecutorService r4 = r4.executorService()
            r4.shutdown()
            okhttp3.ConnectionPool r4 = r2.connectionPool()
            r4.evictAll()
            throw r3
    }
}
