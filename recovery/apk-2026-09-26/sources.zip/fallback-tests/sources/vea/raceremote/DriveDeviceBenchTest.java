package vea.raceremote;

/* JADX INFO: compiled from: DriveDeviceBenchTest.kt */
/* JADX INFO: loaded from: classes4.dex */
@kotlin.Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0007J\b\u0010\u0005\u001a\u00020\u0004H\u0007J\u0010\u0010\u0006\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\bH\u0002J\b\u0010\t\u001a\u00020\u0004H\u0007J\b\u0010\n\u001a\u00020\u0004H\u0007¨\u0006\u000b"}, d2 = {"Lvea/raceremote/DriveDeviceBenchTest;", "", "()V", "nativeClientDrivePlan", "", "neutralLinkComparison", "runBench", "scenario", "", "silentSocketTimesOut", "udpDiscoveryLatency", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class DriveDeviceBenchTest {
    public static final int $stable = 0;











    public static /* synthetic */ void $r8$lambda$zgftcqAi_nzep1E9jtAqRwAApv0(vea.raceremote.app.MainActivity r0) {
            runBench$lambda$7(r0)
            return
    }

    static {
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r0 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            int r0 = r0.m717Int$classDriveDeviceBenchTest()
            vea.raceremote.DriveDeviceBenchTest.$stable = r0
            return
    }

    public DriveDeviceBenchTest() {
            r0 = this;
            r0.<init>()
            return
    }

    public static final /* synthetic */ void access$runBench$record(java.util.List r0, long r1, java.lang.String r3, java.lang.Object r4) {
            runBench$record(r0, r1, r3, r4)
            return
    }

    public static final /* synthetic */ boolean access$runBench$zero(org.json.JSONObject r1) {
            boolean r0 = runBench$zero(r1)
            return r0
    }

    private final void runBench(java.lang.String r67) {
            r66 = this;
            r1 = r67
            android.os.Bundle r2 = androidx.test.platform.app.InstrumentationRegistry.getArguments()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r3 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r3 = r3.m780String$arg0$callassumeTrue$funrunBench$classDriveDeviceBenchTest()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r4 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r4 = r4.m823String$arg0$callgetString$arg0$callEQEQ$arg1$callassumeTrue$funrunBench$classDriveDeviceBenchTest()
            java.lang.String r4 = r2.getString(r4)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r5 = r5.m884String$arg1$callEQEQ$arg1$callassumeTrue$funrunBench$classDriveDeviceBenchTest()
            boolean r4 = kotlin.jvm.internal.Intrinsics.areEqual(r4, r5)
            org.junit.Assume.assumeTrue(r3, r4)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r3 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r3 = r3.m828String$arg0$callgetString$arg0$callrequireNotNull$valhost$funrunBench$classDriveDeviceBenchTest()
            java.lang.String r3 = r2.getString(r3)
            if (r3 == 0) goto L1419
            java.lang.String r4 = "requireNotNull(args.getString(\"driveBenchHost\"))"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r3, r4)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r4 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r4 = r4.m827String$arg0$callgetString$arg0$callrequireNotNull$valcarId$funrunBench$classDriveDeviceBenchTest()
            java.lang.String r4 = r2.getString(r4)
            if (r4 == 0) goto L140b
            java.lang.String r5 = "requireNotNull(args.getString(\"driveBenchCarId\"))"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r4, r5)
            r5 = r3
            java.lang.CharSequence r5 = (java.lang.CharSequence) r5
            r14 = 1
            char[] r6 = new char[r14]
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            char r7 = r7.m654Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$funrunBench$classDriveDeviceBenchTest()
            r15 = 0
            r6[r15] = r7
            r7 = 0
            r8 = 0
            r9 = 6
            r10 = 0
            java.util.List r5 = kotlin.text.StringsKt.split$default(r5, r6, r7, r8, r9, r10)
            java.lang.Iterable r5 = (java.lang.Iterable) r5
            r6 = 0
            java.util.ArrayList r7 = new java.util.ArrayList
            r8 = 10
            int r9 = kotlin.collections.CollectionsKt.collectionSizeOrDefault(r5, r8)
            r7.<init>(r9)
            java.util.Collection r7 = (java.util.Collection) r7
            r9 = r5
            r10 = 0
            java.util.Iterator r11 = r9.iterator()
        L72:
            boolean r12 = r11.hasNext()
            if (r12 == 0) goto L89
            java.lang.Object r12 = r11.next()
            r13 = r12
            java.lang.String r13 = (java.lang.String) r13
            r16 = 0
            java.lang.Integer r13 = kotlin.text.StringsKt.toIntOrNull(r13)
            r7.add(r13)
            goto L72
        L89:
            java.util.List r7 = (java.util.List) r7
            r13 = r7
            int r5 = r13.size()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            int r6 = r6.m701Int$arg1$callEQEQ$cond$cond$arg0$callrequire$funrunBench$classDriveDeviceBenchTest()
            if (r5 != r6) goto L162
            r5 = r13
            java.lang.Iterable r5 = (java.lang.Iterable) r5
            r6 = 0
            boolean r7 = r5 instanceof java.util.Collection
            if (r7 == 0) goto Lac
            r7 = r5
            java.util.Collection r7 = (java.util.Collection) r7
            boolean r7 = r7.isEmpty()
            if (r7 == 0) goto Lac
            goto Le7
        Lac:
            java.util.Iterator r7 = r5.iterator()
        Lb0:
            boolean r9 = r7.hasNext()
            if (r9 == 0) goto Le6
            java.lang.Object r9 = r7.next()
            r10 = r9
            java.lang.Integer r10 = (java.lang.Integer) r10
            r11 = 0
            if (r10 == 0) goto Ldd
            kotlin.ranges.IntRange r12 = new kotlin.ranges.IntRange
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r16 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            int r14 = r16.m666Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$arg0$callrequire$funrunBench$classDriveDeviceBenchTest()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r16 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            int r8 = r16.m689Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$arg0$callrequire$funrunBench$classDriveDeviceBenchTest()
            r12.<init>(r14, r8)
            int r8 = r10.intValue()
            boolean r8 = r12.contains(r8)
            if (r8 == 0) goto Ldd
            r8 = 1
            goto Lde
        Ldd:
            r8 = r15
        Lde:
            if (r8 != 0) goto Le2
            r14 = r15
            goto Le7
        Le2:
            r8 = 10
            r14 = 1
            goto Lb0
        Le6:
            r14 = 1
        Le7:
            if (r14 == 0) goto L162
            java.lang.Object r5 = r13.get(r15)
            java.lang.Integer r5 = (java.lang.Integer) r5
            if (r5 != 0) goto Lf2
            goto Lfa
        Lf2:
            int r5 = r5.intValue()
            r6 = 10
            if (r5 == r6) goto L160
        Lfa:
            java.lang.Object r5 = r13.get(r15)
            java.lang.Integer r5 = (java.lang.Integer) r5
            if (r5 != 0) goto L103
            goto L11d
        L103:
            int r5 = r5.intValue()
            r6 = 192(0xc0, float:2.69E-43)
            if (r5 != r6) goto L11d
            r5 = 1
            java.lang.Object r6 = r13.get(r5)
            java.lang.Integer r6 = (java.lang.Integer) r6
            if (r6 != 0) goto L115
            goto L11d
        L115:
            int r5 = r6.intValue()
            r6 = 168(0xa8, float:2.35E-43)
            if (r5 == r6) goto L160
        L11d:
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            int r5 = r5.m678Int$arg0$callget$arg0$callEQEQ$cond$else$branch$arg0$callrequire$funrunBench$classDriveDeviceBenchTest()
            java.lang.Object r5 = r13.get(r5)
            java.lang.Integer r5 = (java.lang.Integer) r5
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            int r6 = r6.m702Int$arg1$callEQEQ$cond$else$branch$arg0$callrequire$funrunBench$classDriveDeviceBenchTest()
            if (r5 != 0) goto L132
            goto L162
        L132:
            int r5 = r5.intValue()
            if (r5 != r6) goto L162
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            int r5 = r5.m665Int$$this$callrangeTo$$this$callcontains$branch$else$branch$arg0$callrequire$funrunBench$classDriveDeviceBenchTest()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            int r6 = r6.m688Int$arg0$callrangeTo$$this$callcontains$branch$else$branch$arg0$callrequire$funrunBench$classDriveDeviceBenchTest()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            int r7 = r7.m677Int$arg0$callget$arg0$callCHECK_NOT_NULL$arg0$callcontains$branch$else$branch$arg0$callrequire$funrunBench$classDriveDeviceBenchTest()
            java.lang.Object r7 = r13.get(r7)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r7)
            java.lang.Number r7 = (java.lang.Number) r7
            int r7 = r7.intValue()
            if (r5 > r7) goto L15d
            if (r7 > r6) goto L15d
            r5 = 1
            goto L15e
        L15d:
            r5 = r15
        L15e:
            if (r5 == 0) goto L162
        L160:
            r5 = 1
            goto L163
        L162:
            r5 = r15
        L163:
            if (r5 == 0) goto L13f8
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r5 = r5.m882String$arg0$callstartsWith$cond$arg0$callrequire1$funrunBench$classDriveDeviceBenchTest()
            r14 = 2
            r12 = 0
            boolean r5 = kotlin.text.StringsKt.startsWith$default(r4, r5, r15, r14, r12)
            if (r5 == 0) goto L181
            int r5 = r4.length()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            int r6 = r6.m712Int$arg1$calllessOrEqual$branch$arg0$callrequire1$funrunBench$classDriveDeviceBenchTest()
            if (r5 > r6) goto L181
            r5 = 1
            goto L182
        L181:
            r5 = r15
        L182:
            if (r5 == 0) goto L13ea
            android.app.Instrumentation r5 = androidx.test.platform.app.InstrumentationRegistry.getInstrumentation()
            android.content.Context r11 = r5.getTargetContext()
            long r9 = android.os.SystemClock.elapsedRealtime()
            java.util.ArrayList r5 = new java.util.ArrayList
            r5.<init>()
            java.util.List r5 = (java.util.List) r5
            java.util.List r8 = java.util.Collections.synchronizedList(r5)
            java.lang.Class<android.net.ConnectivityManager> r5 = android.net.ConnectivityManager.class
            java.lang.Object r5 = r11.getSystemService(r5)
            r7 = r5
            android.net.ConnectivityManager r7 = (android.net.ConnectivityManager) r7
            android.net.Network[] r5 = r7.getAllNetworks()
            java.lang.String r6 = "manager.allNetworks"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r5, r6)
            java.lang.Object[] r5 = (java.lang.Object[]) r5
            r6 = 0
            int r14 = r5.length
        L1b1:
            if (r15 >= r14) goto L1e2
            r19 = r5[r15]
            r12 = r19
            android.net.Network r12 = (android.net.Network) r12
            r21 = 0
            r22 = r5
            android.net.NetworkCapabilities r5 = r7.getNetworkCapabilities(r12)
            if (r5 == 0) goto L1d4
            r23 = r6
            r6 = 1
            boolean r5 = r5.hasTransport(r6)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            boolean r6 = r6.m649Boolean$arg1$callEQEQ$fun$anonymous$$arg0$callfirstOrNull$valwifi$funrunBench$classDriveDeviceBenchTest()
            if (r5 != r6) goto L1d6
            r5 = 1
            goto L1d7
        L1d4:
            r23 = r6
        L1d6:
            r5 = 0
        L1d7:
            if (r5 == 0) goto L1da
            goto L1e8
        L1da:
            int r15 = r15 + 1
            r5 = r22
            r6 = r23
            r12 = 0
            goto L1b1
        L1e2:
            r22 = r5
            r23 = r6
            r19 = 0
        L1e8:
            r14 = r19
            android.net.Network r14 = (android.net.Network) r14
            okhttp3.OkHttpClient$Builder r5 = new okhttp3.OkHttpClient$Builder
            r5.<init>()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            r12 = r7
            long r6 = r6.m724Long$arg0$callconnectTimeout$$this$callreadTimeout$$this$callcallTimeout$valbuilder$funrunBench$classDriveDeviceBenchTest()
            java.util.concurrent.TimeUnit r15 = java.util.concurrent.TimeUnit.SECONDS
            okhttp3.OkHttpClient$Builder r5 = r5.connectTimeout(r6, r15)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            long r6 = r6.m729Long$arg0$callreadTimeout$$this$callcallTimeout$valbuilder$funrunBench$classDriveDeviceBenchTest()
            java.util.concurrent.TimeUnit r15 = java.util.concurrent.TimeUnit.SECONDS
            okhttp3.OkHttpClient$Builder r5 = r5.readTimeout(r6, r15)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            long r6 = r6.m723Long$arg0$callcallTimeout$valbuilder$funrunBench$classDriveDeviceBenchTest()
            java.util.concurrent.TimeUnit r15 = java.util.concurrent.TimeUnit.SECONDS
            okhttp3.OkHttpClient$Builder r5 = r5.callTimeout(r6, r15)
            r15 = r5
            if (r14 == 0) goto L220
            javax.net.SocketFactory r5 = r14.getSocketFactory()
            r15.socketFactory(r5)
        L220:
            okhttp3.OkHttpClient r7 = r15.build()
            android.content.Context r5 = r11.getApplicationContext()
            java.lang.Class<android.net.wifi.WifiManager> r6 = android.net.wifi.WifiManager.class
            java.lang.Object r5 = r5.getSystemService(r6)
            android.net.wifi.WifiManager r5 = (android.net.wifi.WifiManager) r5
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r6 = r6.m892String$arg1$callcreateWifiLock$$$this$callapply$valwifiLock$funrunBench$classDriveDeviceBenchTest()
            r19 = r12
            r12 = 4
            android.net.wifi.WifiManager$WifiLock r5 = r5.createWifiLock(r12, r6)
            r6 = r5
            r21 = 0
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r22 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            boolean r12 = r22.m647Boolean$arg0$callsetReferenceCounted$fun$anonymous$$arg0$callapply$valwifiLock$funrunBench$classDriveDeviceBenchTest()
            r6.setReferenceCounted(r12)
            r21 = r5
            vea.raceremote.control.CarControlClient r5 = new vea.raceremote.control.CarControlClient
            vea.raceremote.DriveDeviceBenchTest$runBench$client$1 r6 = new vea.raceremote.DriveDeviceBenchTest$runBench$client$1
            r6.<init>(r8, r9)
            r25 = r6
            kotlin.jvm.functions.Function1 r25 = (kotlin.jvm.functions.Function1) r25
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            boolean r26 = r6.m648Boolean$arg1$call$init$$valclient$funrunBench$classDriveDeviceBenchTest()
            r27 = 0
            r28 = 4
            r29 = 0
            r24 = r5
            r24.<init>(r25, r26, r27, r28, r29)
            r12 = r5
            r22 = 0
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            long r24 = r5.m742Long$valrawToken$funrunBench$classDriveDeviceBenchTest()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            boolean r26 = r5.m653Boolean$valcomplete$funrunBench$classDriveDeviceBenchTest()
            r5 = 0
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L126e
            java.lang.String r6 = r6.m826String$arg0$callgetString$arg0$callEQEQ$cond$if$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L126e
            java.lang.String r6 = r2.getString(r6)     // Catch: java.lang.Throwable -> L126e
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r27 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L126e
            r28 = r5
            java.lang.String r5 = r27.m887String$arg1$callEQEQ$cond$if$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L1259
            boolean r5 = kotlin.jvm.internal.Intrinsics.areEqual(r6, r5)     // Catch: java.lang.Throwable -> L1259
            if (r5 == 0) goto L317
            java.lang.Class<vea.raceremote.app.MainActivity> r5 = vea.raceremote.app.MainActivity.class
            androidx.test.core.app.ActivityScenario r5 = androidx.test.core.app.ActivityScenario.launch(r5)     // Catch: java.lang.Throwable -> L301
            vea.raceremote.DriveDeviceBenchTest$$ExternalSyntheticLambda0 r6 = new vea.raceremote.DriveDeviceBenchTest$$ExternalSyntheticLambda0     // Catch: java.lang.Throwable -> L2e9
            r6.<init>()     // Catch: java.lang.Throwable -> L2e9
            r5.onActivity(r6)     // Catch: java.lang.Throwable -> L2e9
            androidx.lifecycle.Lifecycle$State r6 = androidx.lifecycle.Lifecycle.State.RESUMED     // Catch: java.lang.Throwable -> L2e9
            r27 = r13
            androidx.lifecycle.Lifecycle$State r13 = r5.getState()     // Catch: java.lang.Throwable -> L2d1
            org.junit.Assert.assertEquals(r6, r13)     // Catch: java.lang.Throwable -> L2d1
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L2d1
            java.lang.String r6 = r6.m773String$arg0$callassertTrue$branch$if$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L2d1
            java.lang.Class<android.os.PowerManager> r13 = android.os.PowerManager.class
            java.lang.Object r13 = r11.getSystemService(r13)     // Catch: java.lang.Throwable -> L2d1
            android.os.PowerManager r13 = (android.os.PowerManager) r13     // Catch: java.lang.Throwable -> L2d1
            boolean r13 = r13.isInteractive()     // Catch: java.lang.Throwable -> L2d1
            org.junit.Assert.assertTrue(r6, r13)     // Catch: java.lang.Throwable -> L2d1
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L2d1
            java.lang.String r6 = r6.m860String$arg0$callrecord$branch$if$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L2d1
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r13 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L2d1
            java.lang.String r13 = r13.m894String$arg1$callrecord$branch$if$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L2d1
            runBench$record(r8, r9, r6, r13)     // Catch: java.lang.Throwable -> L2d1
            r28 = r5
            goto L319
        L2d1:
            r0 = move-exception
            r28 = r5
            r33 = r11
            r39 = r14
            r29 = r15
            r18 = r27
            r5 = r0
            r14 = r1
            r15 = r2
            r11 = r4
            r1 = r7
            r4 = r12
            r2 = r22
            r12 = r9
            r10 = r3
            r3 = r8
            goto L1284
        L2e9:
            r0 = move-exception
            r28 = r5
            r33 = r11
            r18 = r13
            r39 = r14
            r29 = r15
            r5 = r0
            r14 = r1
            r15 = r2
            r11 = r4
            r1 = r7
            r4 = r12
            r2 = r22
            r12 = r9
            r10 = r3
            r3 = r8
            goto L1284
        L301:
            r0 = move-exception
            r5 = r0
            r33 = r11
            r18 = r13
            r39 = r14
            r29 = r15
            r14 = r1
            r15 = r2
            r11 = r4
            r1 = r7
            r4 = r12
            r2 = r22
            r12 = r9
            r10 = r3
            r3 = r8
            goto L1284
        L317:
            r27 = r13
        L319:
            r21.acquire()     // Catch: java.lang.Throwable -> L1244
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L1244
            java.lang.String r13 = r5.m883String$arg0$callstatus$valinitial$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L1244
            r5 = r7
            r6 = r3
            r29 = r15
            r15 = r7
            r7 = r4
            r30 = r8
            r31 = r9
            r33 = r11
            r11 = r13
            org.json.JSONObject r5 = runBench$status(r5, r6, r7, r8, r9, r11)     // Catch: java.lang.Throwable -> L1230
            r13 = r5
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L1230
            java.lang.String r5 = r5.m772String$arg0$callassertFalse$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L1230
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L1230
            java.lang.String r6 = r6.m795String$arg0$callgetBoolean$arg1$callassertFalse$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L1230
            boolean r6 = r13.getBoolean(r6)     // Catch: java.lang.Throwable -> L1230
            org.junit.Assert.assertFalse(r5, r6)     // Catch: java.lang.Throwable -> L1230
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L1230
            java.lang.String r5 = r5.m778String$arg0$callassertTrue$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L1230
            boolean r6 = runBench$zero(r13)     // Catch: java.lang.Throwable -> L1230
            org.junit.Assert.assertTrue(r5, r6)     // Catch: java.lang.Throwable -> L1230
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L1230
            java.lang.String r5 = r5.m888String$arg1$callEQEQ$cond$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L1230
            boolean r5 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r5)     // Catch: java.lang.Throwable -> L1230
            if (r5 == 0) goto L676
            java.net.InetAddress r5 = java.net.InetAddress.getByName(r3)     // Catch: java.lang.Throwable -> L661
            java.security.SecureRandom r6 = new java.security.SecureRandom     // Catch: java.lang.Throwable -> L661
            r6.<init>()     // Catch: java.lang.Throwable -> L661
            int r6 = r6.nextInt()     // Catch: java.lang.Throwable -> L661
            long r6 = (long) r6     // Catch: java.lang.Throwable -> L661
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r8 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L661
            long r8 = r8.m722Long$arg0$calland$$this$callplus$valfirstNonce$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L661
            long r6 = r6 & r8
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r8 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L661
            int r8 = r8.m685Int$arg0$callplus$valfirstNonce$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L661
            long r8 = (long) r8     // Catch: java.lang.Throwable -> L661
            long r6 = r6 + r8
            r8 = 0
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r9 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L661
            int r9 = r9.m719Int$valmissed$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L661
            r8 = r9
            java.net.DatagramSocket r9 = new java.net.DatagramSocket     // Catch: java.lang.Throwable -> L661
            r9.<init>()     // Catch: java.lang.Throwable -> L661
            java.io.Closeable r9 = (java.io.Closeable) r9     // Catch: java.lang.Throwable -> L661
            r10 = r9
            java.net.DatagramSocket r10 = (java.net.DatagramSocket) r10     // Catch: java.lang.Throwable -> L634
            r11 = 0
            if (r14 == 0) goto L3ab
            r14.bindSocket(r10)     // Catch: java.lang.Throwable -> L398
            kotlin.Unit r34 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L398
            goto L3ab
        L398:
            r0 = move-exception
            r1 = r0
            r41 = r2
            r35 = r5
            r46 = r6
            r5 = r8
            r40 = r13
            r39 = r14
            r8 = r30
            r13 = r31
            goto L648
        L3ab:
            r34 = r8
            r8 = 3333(0xd05, float:4.67E-42)
            r10.connect(r5, r8)     // Catch: java.lang.Throwable -> L621
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r8 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L621
            int r8 = r8.m691Int$arg0$callrepeat$fun$anonymous$$arg0$calluse$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L621
            r35 = r5
            r36 = r11
            r5 = r34
            r11 = 0
        L3bf:
            if (r11 >= r8) goto L5c4
            r34 = r11
            r37 = 0
            r38 = r8
            r40 = r13
            r39 = r14
            r8 = r34
            long r13 = (long) r8
            long r13 = r13 + r6
            vea.raceremote.control.DiscoveryPacket r41 = vea.raceremote.control.DiscoveryPacket.INSTANCE     // Catch: java.lang.Throwable -> L5b8
            r44 = 0
            r45 = 2
            r46 = 0
            r42 = r13
            byte[] r34 = vea.raceremote.control.DiscoveryPacket.query$default(r41, r42, r44, r45, r46)     // Catch: java.lang.Throwable -> L5b8
            r41 = r34
            long r42 = android.os.SystemClock.elapsedRealtimeNanos()     // Catch: java.lang.Throwable -> L5b8
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r34 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L5b8
            long r44 = r34.m727Long$arg0$callplus$valdeadline$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$calluse$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L5b8
            long r44 = r42 + r44
            r46 = r6
            java.net.DatagramPacket r6 = new java.net.DatagramPacket     // Catch: java.lang.Throwable -> L5ae
            r7 = r41
            r41 = r2
            int r2 = r7.length     // Catch: java.lang.Throwable -> L5a6
            r6.<init>(r7, r2)     // Catch: java.lang.Throwable -> L5a6
            r10.send(r6)     // Catch: java.lang.Throwable -> L5a6
            r2 = 0
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L5a6
            int r6 = r6.m718Int$valignored$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$calluse$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L5a6
        L401:
            long r48 = android.os.SystemClock.elapsedRealtimeNanos()     // Catch: java.lang.Throwable -> L5a6
            int r34 = (r48 > r44 ? 1 : (r48 == r44 ? 0 : -1))
            if (r34 >= 0) goto L4c8
            long r48 = android.os.SystemClock.elapsedRealtimeNanos()     // Catch: java.lang.Throwable -> L4c0
            long r48 = r44 - r48
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r34 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L4c0
            r50 = r2
            int r2 = r34.m670Int$$this$calltoLong$arg1$calllessOrEqual$cond$if$body$loop$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$calluse$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L4c0
            long r1 = (long) r2     // Catch: java.lang.Throwable -> L4c0
            int r1 = (r48 > r1 ? 1 : (r48 == r1 ? 0 : -1))
            if (r1 <= 0) goto L4bb
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r1 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L4c0
            long r1 = r1.m726Long$arg0$callplus$$this$calldiv$$this$calltoInt$$$this$callcoerceAtLeast$arg0$callsetSoTimeout$body$loop$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$calluse$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L4c0
            long r1 = r48 + r1
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r34 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L4c0
            long r51 = r34.m725Long$arg0$calldiv$$this$calltoInt$$$this$callcoerceAtLeast$arg0$callsetSoTimeout$body$loop$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$calluse$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L4c0
            long r1 = r1 / r51
            int r1 = (int) r1     // Catch: java.lang.Throwable -> L4c0
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L4c0
            int r2 = r2.m673Int$arg0$callcoerceAtLeast$arg0$callsetSoTimeout$body$loop$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$calluse$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L4c0
            int r1 = kotlin.ranges.RangesKt.coerceAtLeast(r1, r2)     // Catch: java.lang.Throwable -> L4c0
            r10.setSoTimeout(r1)     // Catch: java.lang.Throwable -> L4c0
            java.net.DatagramPacket r1 = new java.net.DatagramPacket     // Catch: java.lang.Throwable -> L4c0
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L4c0
            int r2 = r2.m671Int$arg0$call$init$$arg0$call$init$$valpacket$body$loop$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$calluse$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L4c0
            byte[] r2 = new byte[r2]     // Catch: java.lang.Throwable -> L4c0
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r34 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L4c0
            r51 = r7
            int r7 = r34.m693Int$arg1$call$init$$valpacket$body$loop$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$calluse$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L4c0
            r1.<init>(r2, r7)     // Catch: java.lang.Throwable -> L4c0
            r10.receive(r1)     // Catch: java.net.SocketTimeoutException -> L4b6 java.lang.Throwable -> L4c0
            long r52 = android.os.SystemClock.elapsedRealtimeNanos()     // Catch: java.net.SocketTimeoutException -> L4b6 java.lang.Throwable -> L4c0
            vea.raceremote.control.DiscoveryPacket r2 = vea.raceremote.control.DiscoveryPacket.INSTANCE     // Catch: java.net.SocketTimeoutException -> L4b6 java.lang.Throwable -> L4c0
            byte[] r7 = r1.getData()     // Catch: java.net.SocketTimeoutException -> L4b6 java.lang.Throwable -> L4c0
            r54 = r10
            java.lang.String r10 = "packet.data"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r7, r10)     // Catch: java.net.SocketTimeoutException -> L4b3 java.lang.Throwable -> L4c0
            int r10 = r1.getLength()     // Catch: java.net.SocketTimeoutException -> L4b3 java.lang.Throwable -> L4c0
            byte[] r7 = java.util.Arrays.copyOf(r7, r10)     // Catch: java.net.SocketTimeoutException -> L4b3 java.lang.Throwable -> L4c0
            java.lang.String r10 = "copyOf(this, newSize)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r7, r10)     // Catch: java.net.SocketTimeoutException -> L4b3 java.lang.Throwable -> L4c0
            vea.raceremote.control.DiscoveredCar r2 = r2.reply(r7, r13, r3)     // Catch: java.net.SocketTimeoutException -> L4b3 java.lang.Throwable -> L4c0
            if (r2 != 0) goto L483
            int r6 = r6 + 1
            r1 = r67
            r2 = r50
            r7 = r51
            r10 = r54
            goto L401
        L483:
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.net.SocketTimeoutException -> L4b3 java.lang.Throwable -> L4c0
            java.lang.String r7 = r7.m767String$arg0$callassertEquals$try$body$loop$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$calluse$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.net.SocketTimeoutException -> L4b3 java.lang.Throwable -> L4c0
            java.lang.String r10 = r2.getName()     // Catch: java.net.SocketTimeoutException -> L4b3 java.lang.Throwable -> L4c0
            org.junit.Assert.assertEquals(r7, r4, r10)     // Catch: java.net.SocketTimeoutException -> L4b3 java.lang.Throwable -> L4c0
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.net.SocketTimeoutException -> L4b3 java.lang.Throwable -> L4c0
            java.lang.String r7 = r7.m771String$arg0$callassertFalse$try$body$loop$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$calluse$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.net.SocketTimeoutException -> L4b3 java.lang.Throwable -> L4c0
            boolean r10 = r2.getBusy()     // Catch: java.net.SocketTimeoutException -> L4b3 java.lang.Throwable -> L4c0
            org.junit.Assert.assertFalse(r7, r10)     // Catch: java.net.SocketTimeoutException -> L4b3 java.lang.Throwable -> L4c0
            long r55 = r52 - r42
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.net.SocketTimeoutException -> L4b3 java.lang.Throwable -> L4c0
            int r7 = r7.m676Int$arg0$calldiv$setrttUs$try$body$loop$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$calluse$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.net.SocketTimeoutException -> L4b3 java.lang.Throwable -> L4c0
            r10 = r1
            r34 = r2
            long r1 = (long) r7
            long r55 = r55 / r1
            java.lang.Long r1 = java.lang.Long.valueOf(r55)     // Catch: java.net.SocketTimeoutException -> L4b1 java.lang.Throwable -> L4c0
            r2 = r1
            goto L4d0
        L4b1:
            r0 = move-exception
            goto L4ce
        L4b3:
            r0 = move-exception
            r10 = r1
            goto L4ce
        L4b6:
            r0 = move-exception
            r54 = r10
            r10 = r1
            goto L4ce
        L4bb:
            r51 = r7
            r54 = r10
            goto L4ce
        L4c0:
            r0 = move-exception
            r1 = r0
            r8 = r30
            r13 = r31
            goto L648
        L4c8:
            r50 = r2
            r51 = r7
            r54 = r10
        L4ce:
            r2 = r50
        L4d0:
            if (r2 == 0) goto L4e5
            long r48 = r2.longValue()     // Catch: java.lang.Throwable -> L4c0
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r1 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L4c0
            int r1 = r1.m669Int$$this$calltoLong$arg1$callless$branch$valtimely$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$calluse$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L4c0
            r52 = r13
            long r13 = (long) r1
            int r1 = (r48 > r13 ? 1 : (r48 == r13 ? 0 : -1))
            if (r1 >= 0) goto L4e7
            r1 = 1
            goto L4e8
        L4e5:
            r52 = r13
        L4e7:
            r1 = 0
        L4e8:
            if (r1 != 0) goto L4ec
            int r5 = r5 + 1
        L4ec:
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L59c
            java.lang.String r7 = r7.m869String$arg0$callrecord$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$calluse$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L59c
            org.json.JSONObject r10 = new org.json.JSONObject     // Catch: java.lang.Throwable -> L59c
            r10.<init>()     // Catch: java.lang.Throwable -> L59c
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r13 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L59c
            java.lang.String r13 = r13.m837String$arg0$callput$$this$callput$$this$callput$$this$callput$arg1$callrecord$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$calluse$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L59c
            org.json.JSONObject r10 = r10.put(r13, r8)     // Catch: java.lang.Throwable -> L59c
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r13 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L59c
            java.lang.String r13 = r13.m841String$arg0$callput$$this$callput$$this$callput$arg1$callrecord$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$calluse$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L59c
            if (r2 != 0) goto L50c
            java.lang.Object r14 = org.json.JSONObject.NULL     // Catch: java.lang.Throwable -> L4c0
            goto L50d
        L50c:
            r14 = r2
        L50d:
            org.json.JSONObject r10 = r10.put(r13, r14)     // Catch: java.lang.Throwable -> L59c
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r13 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L59c
            java.lang.String r13 = r13.m848String$arg0$callput$$this$callput$arg1$callrecord$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$calluse$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L59c
            org.json.JSONObject r10 = r10.put(r13, r1)     // Catch: java.lang.Throwable -> L59c
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r13 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L59c
            java.lang.String r13 = r13.m855String$arg0$callput$arg1$callrecord$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$calluse$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L59c
            org.json.JSONObject r10 = r10.put(r13, r6)     // Catch: java.lang.Throwable -> L59c
            java.lang.String r13 = "JSONObject().put(\"index\"…ignoredPackets\", ignored)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r10, r13)     // Catch: java.lang.Throwable -> L59c
            r13 = r31
            r64 = r30
            r30 = r8
            r8 = r64
            runBench$record(r8, r13, r7, r10)     // Catch: java.lang.Throwable -> L596
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L596
            int r7 = r7.m663Int$$this$callminus$valremainingUs$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$calluse$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L596
            r31 = r1
            r10 = r2
            long r1 = (long) r7     // Catch: java.lang.Throwable -> L596
            long r48 = android.os.SystemClock.elapsedRealtimeNanos()     // Catch: java.lang.Throwable -> L596
            long r48 = r48 - r42
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L596
            int r7 = r7.m674Int$arg0$calldiv$arg0$callminus$valremainingUs$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$calluse$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L596
            r34 = r5
            r32 = r6
            long r5 = (long) r7
            long r48 = r48 / r5
            long r1 = r1 - r48
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L590
            int r5 = r5.m668Int$$this$calltoLong$arg1$callgreater$cond$if1$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$calluse$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L590
            long r5 = (long) r5     // Catch: java.lang.Throwable -> L590
            int r5 = (r1 > r5 ? 1 : (r1 == r5 ? 0 : -1))
            if (r5 <= 0) goto L575
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L590
            int r5 = r5.m679Int$arg0$callplus$$this$calldiv$arg0$callsleep$branch$if1$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$calluse$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L590
            long r5 = (long) r5     // Catch: java.lang.Throwable -> L590
            long r5 = r5 + r1
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L590
            int r7 = r7.m675Int$arg0$calldiv$arg0$callsleep$branch$if1$fun$anonymous$$arg1$callrepeat$fun$anonymous$$arg0$calluse$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L590
            r48 = r1
            long r1 = (long) r7     // Catch: java.lang.Throwable -> L590
            long r5 = r5 / r1
            android.os.SystemClock.sleep(r5)     // Catch: java.lang.Throwable -> L590
            goto L577
        L575:
            r48 = r1
        L577:
            int r11 = r11 + 1
            r1 = r67
            r30 = r8
            r31 = r13
            r5 = r34
            r8 = r38
            r14 = r39
            r13 = r40
            r2 = r41
            r6 = r46
            r10 = r54
            goto L3bf
        L590:
            r0 = move-exception
            r1 = r0
            r5 = r34
            goto L648
        L596:
            r0 = move-exception
            r34 = r5
            r1 = r0
            goto L648
        L59c:
            r0 = move-exception
            r34 = r5
            r8 = r30
            r13 = r31
            r1 = r0
            goto L648
        L5a6:
            r0 = move-exception
            r8 = r30
            r13 = r31
            r1 = r0
            goto L648
        L5ae:
            r0 = move-exception
            r41 = r2
            r8 = r30
            r13 = r31
            r1 = r0
            goto L648
        L5b8:
            r0 = move-exception
            r41 = r2
            r46 = r6
            r8 = r30
            r13 = r31
            r1 = r0
            goto L648
        L5c4:
            r41 = r2
            r46 = r6
            r54 = r10
            r40 = r13
            r39 = r14
            r8 = r30
            r13 = r31
            kotlin.Unit r1 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L61e
            r1 = 0
            kotlin.io.CloseableKt.closeFinally(r9, r1)     // Catch: java.lang.Throwable -> L64f
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r1 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L64f
            java.lang.String r1 = r1.m861String$arg0$callrecord$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L64f
            org.json.JSONObject r2 = new org.json.JSONObject     // Catch: java.lang.Throwable -> L64f
            r2.<init>()     // Catch: java.lang.Throwable -> L64f
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L64f
            java.lang.String r6 = r6.m847String$arg0$callput$$this$callput$arg1$callrecord$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L64f
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L64f
            int r7 = r7.m714Int$arg1$callput$$this$callput$arg1$callrecord$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L64f
            org.json.JSONObject r2 = r2.put(r6, r7)     // Catch: java.lang.Throwable -> L64f
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L64f
            java.lang.String r6 = r6.m854String$arg0$callput$arg1$callrecord$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L64f
            org.json.JSONObject r2 = r2.put(r6, r5)     // Catch: java.lang.Throwable -> L64f
            java.lang.String r6 = "JSONObject().put(\"sample…\"missedDeadline\", missed)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, r6)     // Catch: java.lang.Throwable -> L64f
            runBench$record(r8, r13, r1, r2)     // Catch: java.lang.Throwable -> L64f
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r1 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L64f
            java.lang.String r1 = r1.m763String$arg0$callassertEquals$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L64f
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L64f
            int r2 = r2.m705Int$arg1$callassertEquals$branch$if1$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L64f
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)     // Catch: java.lang.Throwable -> L64f
            java.lang.Integer r6 = java.lang.Integer.valueOf(r5)     // Catch: java.lang.Throwable -> L64f
            org.junit.Assert.assertEquals(r1, r2, r6)     // Catch: java.lang.Throwable -> L64f
            goto L680
        L61e:
            r0 = move-exception
            r1 = r0
            goto L648
        L621:
            r0 = move-exception
            r41 = r2
            r35 = r5
            r46 = r6
            r40 = r13
            r39 = r14
            r8 = r30
            r13 = r31
            r1 = r0
            r5 = r34
            goto L648
        L634:
            r0 = move-exception
            r41 = r2
            r35 = r5
            r46 = r6
            r34 = r8
            r40 = r13
            r39 = r14
            r8 = r30
            r13 = r31
            r1 = r0
            r5 = r34
        L648:
            throw r1     // Catch: java.lang.Throwable -> L649
        L649:
            r0 = move-exception
            r2 = r0
            kotlin.io.CloseableKt.closeFinally(r9, r1)     // Catch: java.lang.Throwable -> L64f
            throw r2     // Catch: java.lang.Throwable -> L64f
        L64f:
            r0 = move-exception
            r5 = r0
            r10 = r3
            r11 = r4
            r3 = r8
            r4 = r12
            r12 = r13
            r1 = r15
            r2 = r22
            r18 = r27
            r15 = r41
            r14 = r67
            goto L1284
        L661:
            r0 = move-exception
            r39 = r14
            r14 = r67
            r5 = r0
            r10 = r3
            r11 = r4
            r4 = r12
            r1 = r15
            r18 = r27
            r3 = r30
            r12 = r31
            r15 = r2
            r2 = r22
            goto L1284
        L676:
            r41 = r2
            r40 = r13
            r39 = r14
            r8 = r30
            r13 = r31
        L680:
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r1 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L121e
            java.lang.String r1 = r1.m889String$arg1$callEQEQ$cond$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L121e
            r2 = r67
            boolean r1 = kotlin.jvm.internal.Intrinsics.areEqual(r2, r1)     // Catch: java.lang.Throwable -> L1211
            if (r1 == 0) goto Lc6f
            r1 = 0
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lc59
            boolean r5 = r5.m652Boolean$valallSurvived$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lc59
            r1 = r5
            r5 = 6
            java.lang.Boolean[] r5 = new java.lang.Boolean[r5]     // Catch: java.lang.Throwable -> Lc59
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lc59
            boolean r6 = r6.m641Boolean$0$vararg$arg0$calllistOf$$$this$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lc59
            java.lang.Boolean r6 = java.lang.Boolean.valueOf(r6)     // Catch: java.lang.Throwable -> Lc59
            r18 = 0
            r5[r18] = r6     // Catch: java.lang.Throwable -> Lc59
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lc59
            boolean r6 = r6.m642Boolean$1$vararg$arg0$calllistOf$$$this$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lc59
            java.lang.Boolean r6 = java.lang.Boolean.valueOf(r6)     // Catch: java.lang.Throwable -> Lc59
            r7 = 1
            r5[r7] = r6     // Catch: java.lang.Throwable -> Lc59
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lc59
            boolean r6 = r6.m643Boolean$2$vararg$arg0$calllistOf$$$this$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lc59
            java.lang.Boolean r6 = java.lang.Boolean.valueOf(r6)     // Catch: java.lang.Throwable -> Lc59
            r7 = 2
            r5[r7] = r6     // Catch: java.lang.Throwable -> Lc59
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lc59
            boolean r6 = r6.m644Boolean$3$vararg$arg0$calllistOf$$$this$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lc59
            java.lang.Boolean r6 = java.lang.Boolean.valueOf(r6)     // Catch: java.lang.Throwable -> Lc59
            r7 = 3
            r5[r7] = r6     // Catch: java.lang.Throwable -> Lc59
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lc59
            boolean r6 = r6.m645Boolean$4$vararg$arg0$calllistOf$$$this$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lc59
            java.lang.Boolean r6 = java.lang.Boolean.valueOf(r6)     // Catch: java.lang.Throwable -> Lc59
            r7 = 4
            r5[r7] = r6     // Catch: java.lang.Throwable -> Lc59
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lc59
            boolean r6 = r6.m646Boolean$5$vararg$arg0$calllistOf$$$this$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lc59
            java.lang.Boolean r6 = java.lang.Boolean.valueOf(r6)     // Catch: java.lang.Throwable -> Lc59
            r7 = 5
            r5[r7] = r6     // Catch: java.lang.Throwable -> Lc59
            java.util.List r5 = kotlin.collections.CollectionsKt.listOf(r5)     // Catch: java.lang.Throwable -> Lc59
            java.lang.Iterable r5 = (java.lang.Iterable) r5     // Catch: java.lang.Throwable -> Lc59
            r23 = r5
            r30 = 0
            r5 = 0
            java.util.Iterator r31 = r23.iterator()     // Catch: java.lang.Throwable -> Lc59
        L6f7:
            boolean r6 = r31.hasNext()     // Catch: java.lang.Throwable -> Lc59
            if (r6 == 0) goto Lc2f
            java.lang.Object r6 = r31.next()     // Catch: java.lang.Throwable -> Lc1b
            r32 = r6
            int r34 = r5 + 1
            if (r5 >= 0) goto L71c
            kotlin.collections.CollectionsKt.throwIndexOverflow()     // Catch: java.lang.Throwable -> L70b
            goto L71c
        L70b:
            r0 = move-exception
            r5 = r0
            r10 = r3
            r11 = r4
            r3 = r8
            r4 = r12
            r12 = r13
            r1 = r15
            r18 = r27
            r15 = r41
            r14 = r2
            r2 = r22
            goto L1284
        L71c:
            r6 = r32
            java.lang.Boolean r6 = (java.lang.Boolean) r6     // Catch: java.lang.Throwable -> Lc1b
            boolean r6 = r6.booleanValue()     // Catch: java.lang.Throwable -> Lc1b
            r11 = r6
            r35 = r5
            r36 = 0
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lc1b
            int r5 = r5.m686Int$arg0$callplus$valtrial$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lc1b
            int r10 = r35 + r5
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lc1b
            java.lang.String r5 = r5.m868String$arg0$callrecord$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lc1b
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> Lc1b
            r6.<init>()     // Catch: java.lang.Throwable -> Lc1b
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lc1b
            java.lang.String r7 = r7.m752String$0$str$arg1$callrecord$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lc1b
            java.lang.StringBuilder r6 = r6.append(r7)     // Catch: java.lang.Throwable -> Lc1b
            java.lang.StringBuilder r6 = r6.append(r10)     // Catch: java.lang.Throwable -> Lc1b
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lc1b
            java.lang.String r7 = r7.m760String$2$str$arg1$callrecord$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lc1b
            java.lang.StringBuilder r6 = r6.append(r7)     // Catch: java.lang.Throwable -> Lc1b
            java.lang.StringBuilder r6 = r6.append(r11)     // Catch: java.lang.Throwable -> Lc1b
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lc1b
            java.lang.String r7 = r7.m762String$4$str$arg1$callrecord$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lc1b
            java.lang.StringBuilder r6 = r6.append(r7)     // Catch: java.lang.Throwable -> Lc1b
            java.lang.String r6 = r6.toString()     // Catch: java.lang.Throwable -> Lc1b
            runBench$record(r8, r13, r5, r6)     // Catch: java.lang.Throwable -> Lc1b
            java.lang.String r5 = "http"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r15, r5)     // Catch: java.lang.Throwable -> Lc1b
            r9 = 0
            r37 = 0
            r38 = 12
            r42 = 0
            r5 = r12
            r6 = r3
            r7 = r15
            r43 = r8
            r8 = r9
            r9 = r37
            r57 = r10
            r10 = r38
            r2 = r11
            r11 = r42
            vea.raceremote.control.CarControlClient.connect$default(r5, r6, r7, r8, r9, r10, r11)     // Catch: java.lang.Throwable -> Lc06
            long r5 = android.os.SystemClock.elapsedRealtime()     // Catch: java.lang.Throwable -> Lc06
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lc06
            int r7 = r7.m683Int$arg0$callplus$valarmDeadline$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lc06
            long r7 = (long) r7     // Catch: java.lang.Throwable -> Lc06
            long r5 = r5 + r7
            r37 = r5
        L795:
            kotlinx.coroutines.flow.StateFlow r5 = r12.getState()     // Catch: java.lang.Throwable -> Lc06
            java.lang.Object r5 = r5.getValue()     // Catch: java.lang.Throwable -> Lc06
            vea.raceremote.control.CarConnectionState r5 = (vea.raceremote.control.CarConnectionState) r5     // Catch: java.lang.Throwable -> Lc06
            boolean r5 = r5.getConnecting()     // Catch: java.lang.Throwable -> Lc06
            if (r5 == 0) goto L7ca
            long r5 = android.os.SystemClock.elapsedRealtime()     // Catch: java.lang.Throwable -> L7b7
            int r5 = (r5 > r37 ? 1 : (r5 == r37 ? 0 : -1))
            if (r5 >= 0) goto L7ca
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L7b7
            long r5 = r5.m731Long$arg0$callsleep$body$loop$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L7b7
            android.os.SystemClock.sleep(r5)     // Catch: java.lang.Throwable -> L7b7
            goto L795
        L7b7:
            r0 = move-exception
            r5 = r0
            r10 = r3
            r11 = r4
            r4 = r12
            r12 = r13
            r1 = r15
            r2 = r22
            r18 = r27
            r15 = r41
            r3 = r43
            r14 = r67
            goto L1284
        L7ca:
            kotlinx.coroutines.flow.StateFlow r5 = r12.getState()     // Catch: java.lang.Throwable -> Lc06
            java.lang.Object r5 = r5.getValue()     // Catch: java.lang.Throwable -> Lc06
            vea.raceremote.control.CarConnectionState r5 = (vea.raceremote.control.CarConnectionState) r5     // Catch: java.lang.Throwable -> Lc06
            boolean r5 = r5.getConnected()     // Catch: java.lang.Throwable -> Lc06
            r11 = r5
            long r5 = android.os.SystemClock.elapsedRealtime()     // Catch: java.lang.Throwable -> Lc06
            r44 = r5
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lc06
            int r5 = r5.m681Int$arg0$callplus$valactiveDeadline$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lc06
            long r5 = (long) r5     // Catch: java.lang.Throwable -> Lc06
            long r46 = r44 + r5
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lc06
            int r5 = r5.m720Int$valpollCount$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lc06
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lc06
            int r6 = r6.m721Int$valpollErrors$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lc06
            r7 = r44
            r9 = r5
            r10 = r6
            r48 = r7
        L7fa:
            kotlinx.coroutines.flow.StateFlow r5 = r12.getState()     // Catch: java.lang.Throwable -> Lc06
            java.lang.Object r5 = r5.getValue()     // Catch: java.lang.Throwable -> Lc06
            vea.raceremote.control.CarConnectionState r5 = (vea.raceremote.control.CarConnectionState) r5     // Catch: java.lang.Throwable -> Lc06
            boolean r5 = r5.getConnected()     // Catch: java.lang.Throwable -> Lc06
            if (r5 == 0) goto L983
            long r5 = android.os.SystemClock.elapsedRealtime()     // Catch: java.lang.Throwable -> L970
            int r5 = (r5 > r46 ? 1 : (r5 == r46 ? 0 : -1))
            if (r5 >= 0) goto L983
            if (r2 == 0) goto L947
            long r5 = android.os.SystemClock.elapsedRealtime()     // Catch: java.lang.Throwable -> L970
            int r5 = (r5 > r48 ? 1 : (r5 == r48 ? 0 : -1))
            if (r5 < 0) goto L947
        L81d:
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L8cd java.io.IOException -> L8e0
            r5.<init>()     // Catch: java.lang.Throwable -> L8cd java.io.IOException -> L8e0
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L8cd java.io.IOException -> L8e0
            java.lang.String r6 = r6.m746String$0$str$arg0$callstatus$valvalue$try$branch$if$body$loop1$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L8cd java.io.IOException -> L8e0
            java.lang.StringBuilder r5 = r5.append(r6)     // Catch: java.lang.Throwable -> L8cd java.io.IOException -> L8e0
            r8 = r57
            java.lang.StringBuilder r5 = r5.append(r8)     // Catch: java.io.IOException -> L8be java.lang.Throwable -> L8cd
            java.lang.String r42 = r5.toString()     // Catch: java.io.IOException -> L8be java.lang.Throwable -> L8cd
            r5 = r15
            r6 = r3
            r7 = r4
            r50 = r4
            r4 = r8
            r8 = r43
            r51 = r3
            r3 = r9
            r52 = r15
            r15 = r10
            r9 = r13
            r53 = r2
            r2 = r11
            r11 = r42
            org.json.JSONObject r5 = runBench$status(r5, r6, r7, r8, r9, r11)     // Catch: java.lang.Throwable -> L8a5 java.io.IOException -> L8bb
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L8a5 java.io.IOException -> L8bb
            java.lang.String r6 = r6.m768String$arg0$callassertEquals$try$branch$if$body$loop1$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L8a5 java.io.IOException -> L8bb
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L8a5 java.io.IOException -> L8bb
            int r7 = r7.m708Int$arg1$callassertEquals$try$branch$if$body$loop1$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L8a5 java.io.IOException -> L8bb
            java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch: java.lang.Throwable -> L8a5 java.io.IOException -> L8bb
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r8 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L8a5 java.io.IOException -> L8bb
            java.lang.String r8 = r8.m811String$arg0$callgetInt$arg2$callassertEquals$try$branch$if$body$loop1$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L8a5 java.io.IOException -> L8bb
            int r8 = r5.getInt(r8)     // Catch: java.lang.Throwable -> L8a5 java.io.IOException -> L8bb
            java.lang.Integer r8 = java.lang.Integer.valueOf(r8)     // Catch: java.lang.Throwable -> L8a5 java.io.IOException -> L8bb
            org.junit.Assert.assertEquals(r6, r7, r8)     // Catch: java.lang.Throwable -> L8a5 java.io.IOException -> L8bb
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L8a5 java.io.IOException -> L8bb
            java.lang.String r6 = r6.m769String$arg0$callassertEquals1$try$branch$if$body$loop1$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L8a5 java.io.IOException -> L8bb
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L8a5 java.io.IOException -> L8bb
            int r7 = r7.m709Int$arg1$callassertEquals1$try$branch$if$body$loop1$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L8a5 java.io.IOException -> L8bb
            java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch: java.lang.Throwable -> L8a5 java.io.IOException -> L8bb
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r8 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L8a5 java.io.IOException -> L8bb
            java.lang.String r8 = r8.m812String$arg0$callgetInt$arg2$callassertEquals1$try$branch$if$body$loop1$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L8a5 java.io.IOException -> L8bb
            int r8 = r5.getInt(r8)     // Catch: java.lang.Throwable -> L8a5 java.io.IOException -> L8bb
            java.lang.Integer r8 = java.lang.Integer.valueOf(r8)     // Catch: java.lang.Throwable -> L8a5 java.io.IOException -> L8bb
            org.junit.Assert.assertEquals(r6, r7, r8)     // Catch: java.lang.Throwable -> L8a5 java.io.IOException -> L8bb
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L8a5 java.io.IOException -> L8bb
            java.lang.String r6 = r6.m777String$arg0$callassertTrue$try$branch$if$body$loop1$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L8a5 java.io.IOException -> L8bb
            boolean r7 = runBench$zero(r5)     // Catch: java.lang.Throwable -> L8a5 java.io.IOException -> L8bb
            org.junit.Assert.assertTrue(r6, r7)     // Catch: java.lang.Throwable -> L8a5 java.io.IOException -> L8bb
            int r9 = r3 + 1
            r10 = r15
            r11 = r43
            goto L922
        L8a5:
            r0 = move-exception
            r5 = r0
            r4 = r12
            r12 = r13
            r2 = r22
            r18 = r27
            r15 = r41
            r3 = r43
            r11 = r50
            r10 = r51
            r1 = r52
            r14 = r67
            goto L1284
        L8bb:
            r0 = move-exception
            r5 = r0
            goto L8ef
        L8be:
            r0 = move-exception
            r53 = r2
            r51 = r3
            r50 = r4
            r4 = r8
            r3 = r9
            r2 = r11
            r52 = r15
            r15 = r10
            r5 = r0
            goto L8ef
        L8cd:
            r0 = move-exception
            r5 = r0
            r10 = r3
            r11 = r4
            r4 = r12
            r12 = r13
            r1 = r15
            r2 = r22
            r18 = r27
            r15 = r41
            r3 = r43
            r14 = r67
            goto L1284
        L8e0:
            r0 = move-exception
            r53 = r2
            r51 = r3
            r50 = r4
            r3 = r9
            r2 = r11
            r52 = r15
            r4 = r57
            r15 = r10
            r5 = r0
        L8ef:
            int r10 = r15 + 1
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L931
            java.lang.String r6 = r6.m864String$arg0$callrecord$catch$branch$if$body$loop1$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L931
            java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L931
            r7.<init>()     // Catch: java.lang.Throwable -> L931
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r8 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L931
            java.lang.String r8 = r8.m751String$0$str$arg1$callrecord$catch$branch$if$body$loop1$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L931
            java.lang.StringBuilder r7 = r7.append(r8)     // Catch: java.lang.Throwable -> L931
            java.lang.StringBuilder r7 = r7.append(r4)     // Catch: java.lang.Throwable -> L931
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r8 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L931
            java.lang.String r8 = r8.m759String$2$str$arg1$callrecord$catch$branch$if$body$loop1$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L931
            java.lang.StringBuilder r7 = r7.append(r8)     // Catch: java.lang.Throwable -> L931
            java.lang.StringBuilder r7 = r7.append(r5)     // Catch: java.lang.Throwable -> L931
            java.lang.String r7 = r7.toString()     // Catch: java.lang.Throwable -> L931
            r11 = r43
            runBench$record(r11, r13, r6, r7)     // Catch: java.lang.Throwable -> L9ae
            r9 = r3
        L922:
            long r5 = android.os.SystemClock.elapsedRealtime()     // Catch: java.lang.Throwable -> L9ae
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r3 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L9ae
            int r3 = r3.m680Int$arg0$callplus$setnextPoll$branch$if$body$loop1$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L9ae
            long r7 = (long) r3     // Catch: java.lang.Throwable -> L9ae
            long r5 = r5 + r7
            r48 = r5
            goto L958
        L931:
            r0 = move-exception
            r5 = r0
            r4 = r12
            r12 = r13
            r2 = r22
            r18 = r27
            r15 = r41
            r3 = r43
            r11 = r50
            r10 = r51
            r1 = r52
            r14 = r67
            goto L1284
        L947:
            r53 = r2
            r51 = r3
            r50 = r4
            r3 = r9
            r2 = r11
            r52 = r15
            r11 = r43
            r4 = r57
            r15 = r10
            r9 = r3
            r10 = r15
        L958:
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r3 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L9ae
            long r5 = r3.m733Long$arg0$callsleep$body$loop1$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L9ae
            android.os.SystemClock.sleep(r5)     // Catch: java.lang.Throwable -> L9ae
            r57 = r4
            r43 = r11
            r4 = r50
            r3 = r51
            r15 = r52
            r11 = r2
            r2 = r53
            goto L7fa
        L970:
            r0 = move-exception
            r5 = r0
            r10 = r3
            r11 = r4
            r4 = r12
            r12 = r13
            r1 = r15
            r2 = r22
            r18 = r27
            r15 = r41
            r3 = r43
            r14 = r67
            goto L1284
        L983:
            r53 = r2
            r51 = r3
            r50 = r4
            r3 = r9
            r2 = r11
            r52 = r15
            r11 = r43
            r4 = r57
            r15 = r10
            if (r2 == 0) goto L9c3
            kotlinx.coroutines.flow.StateFlow r5 = r12.getState()     // Catch: java.lang.Throwable -> L9ae
            java.lang.Object r5 = r5.getValue()     // Catch: java.lang.Throwable -> L9ae
            vea.raceremote.control.CarConnectionState r5 = (vea.raceremote.control.CarConnectionState) r5     // Catch: java.lang.Throwable -> L9ae
            boolean r5 = r5.getConnected()     // Catch: java.lang.Throwable -> L9ae
            if (r5 == 0) goto L9c3
            long r5 = android.os.SystemClock.elapsedRealtime()     // Catch: java.lang.Throwable -> L9ae
            int r5 = (r5 > r46 ? 1 : (r5 == r46 ? 0 : -1))
            if (r5 < 0) goto L9c3
            r5 = 1
            goto L9c5
        L9ae:
            r0 = move-exception
            r5 = r0
            r3 = r11
            r4 = r12
            r12 = r13
            r2 = r22
            r18 = r27
            r15 = r41
            r11 = r50
            r10 = r51
            r1 = r52
            r14 = r67
            goto L1284
        L9c3:
            r5 = r18
        L9c5:
            r10 = r5
            if (r1 == 0) goto L9cc
            if (r10 == 0) goto L9cc
            r5 = 1
            goto L9ce
        L9cc:
            r5 = r18
        L9ce:
            r1 = r5
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lbf1
            java.lang.String r5 = r5.m874String$arg0$callrecord1$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lbf1
            org.json.JSONObject r6 = new org.json.JSONObject     // Catch: java.lang.Throwable -> Lbf1
            r6.<init>()     // Catch: java.lang.Throwable -> Lbf1
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lbf1
            java.lang.String r7 = r7.m830String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$callput$$this$callput$$this$callput$$this$callput$$this$callput$arg1$callrecord1$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lbf1
            org.json.JSONObject r6 = r6.put(r7, r4)     // Catch: java.lang.Throwable -> Lbf1
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lbf1
            java.lang.String r7 = r7.m831String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$callput$$this$callput$$this$callput$$this$callput$arg1$callrecord1$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lbf1
            r9 = r53
            org.json.JSONObject r6 = r6.put(r7, r9)     // Catch: java.lang.Throwable -> Lbf1
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lbf1
            java.lang.String r7 = r7.m832String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$callput$$this$callput$$this$callput$arg1$callrecord1$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lbf1
            org.json.JSONObject r6 = r6.put(r7, r2)     // Catch: java.lang.Throwable -> Lbf1
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lbf1
            java.lang.String r7 = r7.m833String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$callput$$this$callput$arg1$callrecord1$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lbf1
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r8 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lbf1
            int r8 = r8.m713Int$arg1$callput$$this$callput$$this$callput$$this$callput$$this$callput$$this$callput$arg1$callrecord1$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lbf1
            org.json.JSONObject r6 = r6.put(r7, r8)     // Catch: java.lang.Throwable -> Lbf1
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lbf1
            java.lang.String r7 = r7.m835String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$callput$arg1$callrecord1$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lbf1
            long r42 = android.os.SystemClock.elapsedRealtime()     // Catch: java.lang.Throwable -> Lbf1
            r54 = r1
            r53 = r2
            long r1 = r42 - r44
            org.json.JSONObject r1 = r6.put(r7, r1)     // Catch: java.lang.Throwable -> Lbf1
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lbf1
            java.lang.String r2 = r2.m838String$arg0$callput$$this$callput$$this$callput$$this$callput$arg1$callrecord1$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lbf1
            org.json.JSONObject r1 = r1.put(r2, r10)     // Catch: java.lang.Throwable -> Lbf1
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lbf1
            java.lang.String r2 = r2.m843String$arg0$callput$$this$callput$$this$callput$arg1$callrecord1$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lbf1
            org.json.JSONObject r1 = r1.put(r2, r3)     // Catch: java.lang.Throwable -> Lbf1
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lbf1
            java.lang.String r2 = r2.m850String$arg0$callput$$this$callput$arg1$callrecord1$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lbf1
            org.json.JSONObject r1 = r1.put(r2, r15)     // Catch: java.lang.Throwable -> Lbf1
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lbf1
            java.lang.String r2 = r2.m857String$arg0$callput$arg1$callrecord1$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lbf1
            kotlinx.coroutines.flow.StateFlow r6 = r12.getState()     // Catch: java.lang.Throwable -> Lbf1
            java.lang.Object r6 = r6.getValue()     // Catch: java.lang.Throwable -> Lbf1
            vea.raceremote.control.CarConnectionState r6 = (vea.raceremote.control.CarConnectionState) r6     // Catch: java.lang.Throwable -> Lbf1
            java.lang.String r6 = r6.toString()     // Catch: java.lang.Throwable -> Lbf1
            org.json.JSONObject r1 = r1.put(r2, r6)     // Catch: java.lang.Throwable -> Lbf1
            java.lang.String r2 = "JSONObject().put(\"trial\"…t.state.value.toString())"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)     // Catch: java.lang.Throwable -> Lbf1
            runBench$record(r11, r13, r5, r1)     // Catch: java.lang.Throwable -> Lbf1
            r1 = 0
            r2 = 1
            vea.raceremote.control.CarControlClient.disconnect$default(r12, r1, r2, r1)     // Catch: java.lang.Throwable -> Lbf1
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> Lbf1
            r2.<init>()     // Catch: java.lang.Throwable -> Lbf1
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lbf1
            java.lang.String r5 = r5.m745String$0$str$arg0$callawaitStatus$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lbf1
            java.lang.StringBuilder r2 = r2.append(r5)     // Catch: java.lang.Throwable -> Lbf1
            java.lang.StringBuilder r2 = r2.append(r4)     // Catch: java.lang.Throwable -> Lbf1
            java.lang.String r2 = r2.toString()     // Catch: java.lang.Throwable -> Lbf1
            vea.raceremote.DriveDeviceBenchTest$runBench$5$1 r5 = vea.raceremote.DriveDeviceBenchTest$runBench$5$1.INSTANCE     // Catch: java.lang.Throwable -> Lbf1
            r20 = r5
            kotlin.jvm.functions.Function1 r20 = (kotlin.jvm.functions.Function1) r20     // Catch: java.lang.Throwable -> Lbf1
            r5 = r12
            r6 = r52
            r7 = r51
            r8 = r50
            r42 = r9
            r9 = r11
            r43 = r3
            r55 = r10
            r3 = r11
            r10 = r13
            r56 = r13
            r14 = r1
            r1 = r12
            r12 = r2
            r2 = r27
            r27 = r40
            r58 = r56
            r13 = r20
            runBench$awaitStatus(r5, r6, r7, r8, r9, r10, r12, r13)     // Catch: java.lang.Throwable -> Lbdc
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lbdc
            java.lang.String r5 = r5.m825String$arg0$callgetString$arg0$callEQEQ$cond$if$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lbdc
            r13 = r41
            java.lang.String r5 = r13.getString(r5)     // Catch: java.lang.Throwable -> Lbc8
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lbc8
            java.lang.String r6 = r6.m886String$arg1$callEQEQ$cond$if$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lbc8
            boolean r5 = kotlin.jvm.internal.Intrinsics.areEqual(r5, r6)     // Catch: java.lang.Throwable -> Lbc8
            if (r5 == 0) goto Lb8f
            okhttp3.Request$Builder r5 = new okhttp3.Request$Builder     // Catch: java.lang.Throwable -> Lbc8
            r5.<init>()     // Catch: java.lang.Throwable -> Lbc8
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> Lbc8
            r6.<init>()     // Catch: java.lang.Throwable -> Lbc8
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lbc8
            java.lang.String r7 = r7.m748String$0$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$valtrace$branch$if$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lbc8
            java.lang.StringBuilder r6 = r6.append(r7)     // Catch: java.lang.Throwable -> Lbc8
            r12 = r51
            java.lang.StringBuilder r6 = r6.append(r12)     // Catch: java.lang.Throwable -> Lb7c
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lb7c
            java.lang.String r7 = r7.m756String$2$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$valtrace$branch$if$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lb7c
            java.lang.StringBuilder r6 = r6.append(r7)     // Catch: java.lang.Throwable -> Lb7c
            java.lang.String r6 = r6.toString()     // Catch: java.lang.Throwable -> Lb7c
            okhttp3.Request$Builder r5 = r5.url(r6)     // Catch: java.lang.Throwable -> Lb7c
            okhttp3.Request r5 = r5.build()     // Catch: java.lang.Throwable -> Lb7c
            r11 = r52
            okhttp3.Call r5 = r11.newCall(r5)     // Catch: java.lang.Throwable -> Lb6a
            okhttp3.Response r5 = r5.execute()     // Catch: java.lang.Throwable -> Lb6a
            java.io.Closeable r5 = (java.io.Closeable) r5     // Catch: java.lang.Throwable -> Lb6a
            r6 = r5
            okhttp3.Response r6 = (okhttp3.Response) r6     // Catch: java.lang.Throwable -> Lb5f
            r7 = 0
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r8 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lb5f
            java.lang.String r8 = r8.m765String$arg0$callassertEquals$fun$anonymous$$arg0$calluse$valtrace$branch$if$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lb5f
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r9 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lb5f
            int r9 = r9.m707Int$arg1$callassertEquals$fun$anonymous$$arg0$calluse$valtrace$branch$if$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lb5f
            java.lang.Integer r9 = java.lang.Integer.valueOf(r9)     // Catch: java.lang.Throwable -> Lb5f
            int r10 = r6.code()     // Catch: java.lang.Throwable -> Lb5f
            java.lang.Integer r10 = java.lang.Integer.valueOf(r10)     // Catch: java.lang.Throwable -> Lb5f
            org.junit.Assert.assertEquals(r8, r9, r10)     // Catch: java.lang.Throwable -> Lb5f
            org.json.JSONObject r8 = new org.json.JSONObject     // Catch: java.lang.Throwable -> Lb5f
            okhttp3.ResponseBody r9 = r6.body()     // Catch: java.lang.Throwable -> Lb5f
            if (r9 == 0) goto Lb4e
            java.lang.String r9 = r9.string()     // Catch: java.lang.Throwable -> Lb5f
            r8.<init>(r9)     // Catch: java.lang.Throwable -> Lb5f
            kotlin.io.CloseableKt.closeFinally(r5, r14)     // Catch: java.lang.Throwable -> Lb6a
            r5 = r8
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lb6a
            java.lang.String r6 = r6.m859String$arg0$callrecord$branch$if$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lb6a
            org.json.JSONObject r7 = new org.json.JSONObject     // Catch: java.lang.Throwable -> Lb6a
            r7.<init>()     // Catch: java.lang.Throwable -> Lb6a
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r8 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lb6a
            java.lang.String r8 = r8.m846String$arg0$callput$$this$callput$arg1$callrecord$branch$if$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lb6a
            org.json.JSONObject r7 = r7.put(r8, r4)     // Catch: java.lang.Throwable -> Lb6a
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r8 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lb6a
            java.lang.String r8 = r8.m853String$arg0$callput$arg1$callrecord$branch$if$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lb6a
            org.json.JSONObject r7 = r7.put(r8, r5)     // Catch: java.lang.Throwable -> Lb6a
            java.lang.String r8 = "JSONObject().put(\"trial\"…rial).put(\"value\", trace)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r7, r8)     // Catch: java.lang.Throwable -> Lb6a
            r9 = r58
            runBench$record(r3, r9, r6, r7)     // Catch: java.lang.Throwable -> Lbb4
            goto Lb95
        Lb4e:
            r9 = r58
            java.lang.String r8 = "Required value was null."
            java.lang.IllegalArgumentException r14 = new java.lang.IllegalArgumentException     // Catch: java.lang.Throwable -> Lb5c
            java.lang.String r8 = r8.toString()     // Catch: java.lang.Throwable -> Lb5c
            r14.<init>(r8)     // Catch: java.lang.Throwable -> Lb5c
            throw r14     // Catch: java.lang.Throwable -> Lb5c
        Lb5c:
            r0 = move-exception
            r6 = r0
            goto Lb63
        Lb5f:
            r0 = move-exception
            r9 = r58
            r6 = r0
        Lb63:
            throw r6     // Catch: java.lang.Throwable -> Lb64
        Lb64:
            r0 = move-exception
            r7 = r0
            kotlin.io.CloseableKt.closeFinally(r5, r6)     // Catch: java.lang.Throwable -> Lbb4
            throw r7     // Catch: java.lang.Throwable -> Lbb4
        Lb6a:
            r0 = move-exception
            r14 = r67
            r5 = r0
            r4 = r1
            r18 = r2
            r1 = r11
            r10 = r12
            r15 = r13
            r2 = r22
            r11 = r50
            r12 = r58
            goto L1284
        Lb7c:
            r0 = move-exception
            r14 = r67
            r5 = r0
            r4 = r1
            r18 = r2
            r10 = r12
            r15 = r13
            r2 = r22
            r11 = r50
            r1 = r52
            r12 = r58
            goto L1284
        Lb8f:
            r12 = r51
            r11 = r52
            r9 = r58
        Lb95:
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lbb4
            long r5 = r5.m734Long$arg0$callsleep$fun$anonymous$$arg0$callforEachIndexed$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lbb4
            android.os.SystemClock.sleep(r5)     // Catch: java.lang.Throwable -> Lbb4
            r8 = r3
            r15 = r11
            r3 = r12
            r41 = r13
            r40 = r27
            r5 = r34
            r4 = r50
            r12 = r1
            r27 = r2
            r13 = r9
            r1 = r54
            r2 = r67
            goto L6f7
        Lbb4:
            r0 = move-exception
            r14 = r67
            r5 = r0
            r4 = r1
            r18 = r2
            r1 = r11
            r15 = r13
            r2 = r22
            r11 = r50
            r64 = r9
            r10 = r12
            r12 = r64
            goto L1284
        Lbc8:
            r0 = move-exception
            r14 = r67
            r5 = r0
            r4 = r1
            r18 = r2
            r15 = r13
            r2 = r22
            r11 = r50
            r10 = r51
            r1 = r52
            r12 = r58
            goto L1284
        Lbdc:
            r0 = move-exception
            r14 = r67
            r5 = r0
            r4 = r1
            r18 = r2
            r2 = r22
            r15 = r41
            r11 = r50
            r10 = r51
            r1 = r52
            r12 = r58
            goto L1284
        Lbf1:
            r0 = move-exception
            r3 = r11
            r5 = r0
            r4 = r12
            r12 = r13
            r2 = r22
            r18 = r27
            r15 = r41
            r11 = r50
            r10 = r51
            r1 = r52
            r14 = r67
            goto L1284
        Lc06:
            r0 = move-exception
            r1 = r12
            r12 = r3
            r3 = r43
            r5 = r0
            r11 = r4
            r10 = r12
            r12 = r13
            r2 = r22
            r18 = r27
            r14 = r67
            r4 = r1
            r1 = r15
            r15 = r41
            goto L1284
        Lc1b:
            r0 = move-exception
            r1 = r12
            r12 = r3
            r3 = r8
            r5 = r0
            r11 = r4
            r10 = r12
            r12 = r13
            r2 = r22
            r18 = r27
            r14 = r67
            r4 = r1
            r1 = r15
            r15 = r41
            goto L1284
        Lc2f:
            r50 = r4
            r4 = r12
            r9 = r13
            r11 = r15
            r2 = r27
            r27 = r40
            r13 = r41
            r12 = r3
            r3 = r8
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lc46
            java.lang.String r5 = r5.m774String$arg0$callassertTrue$branch$if2$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lc46
            org.junit.Assert.assertTrue(r5, r1)     // Catch: java.lang.Throwable -> Lc46
            goto Lc7c
        Lc46:
            r0 = move-exception
            r14 = r67
            r5 = r0
            r18 = r2
            r1 = r11
            r15 = r13
            r2 = r22
            r11 = r50
            r64 = r9
            r10 = r12
            r12 = r64
            goto L1284
        Lc59:
            r0 = move-exception
            r50 = r4
            r4 = r12
            r12 = r3
            r3 = r8
            r5 = r0
            r10 = r12
            r12 = r13
            r1 = r15
            r2 = r22
            r18 = r27
            r15 = r41
            r11 = r50
            r14 = r67
            goto L1284
        Lc6f:
            r50 = r4
            r4 = r12
            r9 = r13
            r11 = r15
            r2 = r27
            r27 = r40
            r13 = r41
            r12 = r3
            r3 = r8
        Lc7c:
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r1 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L11fe
            java.lang.String r1 = r1.m890String$arg1$callEQEQ$cond$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L11fe
            r14 = r67
            boolean r1 = kotlin.jvm.internal.Intrinsics.areEqual(r14, r1)     // Catch: java.lang.Throwable -> L11fc
            if (r1 == 0) goto Le9f
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r1 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le8e
            java.lang.String r1 = r1.m862String$arg0$callrecord$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le8e
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le8e
            java.lang.String r5 = r5.m895String$arg1$callrecord$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le8e
            runBench$record(r3, r9, r1, r5)     // Catch: java.lang.Throwable -> Le8e
            java.lang.String r1 = "http"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r11, r1)     // Catch: java.lang.Throwable -> Le8e
            r8 = 0
            r1 = 0
            r15 = 12
            r18 = 0
            r5 = r4
            r6 = r12
            r7 = r11
            r60 = r9
            r9 = r1
            r10 = r15
            r1 = r11
            r11 = r18
            vea.raceremote.control.CarControlClient.connect$default(r5, r6, r7, r8, r9, r10, r11)     // Catch: java.lang.Throwable -> Le80
            long r5 = android.os.SystemClock.elapsedRealtime()     // Catch: java.lang.Throwable -> Le80
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le80
            int r7 = r7.m682Int$arg0$callplus$valarmDeadline$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le80
            long r7 = (long) r7     // Catch: java.lang.Throwable -> Le80
            long r5 = r5 + r7
            r30 = r5
        Lcbf:
            kotlinx.coroutines.flow.StateFlow r5 = r4.getState()     // Catch: java.lang.Throwable -> Le80
            java.lang.Object r5 = r5.getValue()     // Catch: java.lang.Throwable -> Le80
            vea.raceremote.control.CarConnectionState r5 = (vea.raceremote.control.CarConnectionState) r5     // Catch: java.lang.Throwable -> Le80
            boolean r5 = r5.getConnected()     // Catch: java.lang.Throwable -> Le80
            if (r5 != 0) goto Lcef
            long r5 = android.os.SystemClock.elapsedRealtime()     // Catch: java.lang.Throwable -> Lce1
            int r5 = (r5 > r30 ? 1 : (r5 == r30 ? 0 : -1))
            if (r5 >= 0) goto Lcef
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lce1
            long r5 = r5.m730Long$arg0$callsleep$body$loop$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lce1
            android.os.SystemClock.sleep(r5)     // Catch: java.lang.Throwable -> Lce1
            goto Lcbf
        Lce1:
            r0 = move-exception
            r5 = r0
            r18 = r2
            r10 = r12
            r15 = r13
            r2 = r22
            r11 = r50
            r12 = r60
            goto L1284
        Lcef:
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> Le80
            r5.<init>()     // Catch: java.lang.Throwable -> Le80
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le80
            java.lang.String r6 = r6.m744String$0$str$arg0$callassertTrue$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le80
            java.lang.StringBuilder r5 = r5.append(r6)     // Catch: java.lang.Throwable -> Le80
            kotlinx.coroutines.flow.StateFlow r6 = r4.getState()     // Catch: java.lang.Throwable -> Le80
            java.lang.Object r6 = r6.getValue()     // Catch: java.lang.Throwable -> Le80
            java.lang.StringBuilder r5 = r5.append(r6)     // Catch: java.lang.Throwable -> Le80
            java.lang.String r5 = r5.toString()     // Catch: java.lang.Throwable -> Le80
            kotlinx.coroutines.flow.StateFlow r6 = r4.getState()     // Catch: java.lang.Throwable -> Le80
            java.lang.Object r6 = r6.getValue()     // Catch: java.lang.Throwable -> Le80
            vea.raceremote.control.CarConnectionState r6 = (vea.raceremote.control.CarConnectionState) r6     // Catch: java.lang.Throwable -> Le80
            boolean r6 = r6.getConnected()     // Catch: java.lang.Throwable -> Le80
            org.junit.Assert.assertTrue(r5, r6)     // Catch: java.lang.Throwable -> Le80
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le80
            float r5 = r5.m655Float$arg0$callsetInput$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le80
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le80
            float r6 = r6.m659Float$arg1$callsetInput$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le80
            r4.setInput(r5, r6)     // Catch: java.lang.Throwable -> Le80
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le80
            java.lang.String r5 = r5.m873String$arg0$callrecord1$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le80
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le80
            java.lang.String r6 = r6.m897String$arg1$callrecord1$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le80
            r10 = r60
            runBench$record(r3, r10, r5, r6)     // Catch: java.lang.Throwable -> Le70
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le70
            java.lang.String r15 = r5.m781String$arg0$callawaitStatus$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le70
            vea.raceremote.DriveDeviceBenchTest$runBench$6 r5 = vea.raceremote.DriveDeviceBenchTest.AnonymousClass6.INSTANCE     // Catch: java.lang.Throwable -> Le70
            r18 = r5
            kotlin.jvm.functions.Function1 r18 = (kotlin.jvm.functions.Function1) r18     // Catch: java.lang.Throwable -> Le70
            r5 = r4
            r6 = r1
            r7 = r12
            r8 = r50
            r9 = r3
            r58 = r10
            r51 = r12
            r12 = r15
            r15 = r13
            r13 = r18
            runBench$awaitStatus(r5, r6, r7, r8, r9, r10, r12, r13)     // Catch: java.lang.Throwable -> Le62
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le62
            float r5 = r5.m656Float$arg0$callsetInput1$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le62
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le62
            float r6 = r6.m660Float$arg1$callsetInput1$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le62
            r4.setInput(r5, r6)     // Catch: java.lang.Throwable -> Le62
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le62
            java.lang.String r5 = r5.m875String$arg0$callrecord2$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le62
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le62
            java.lang.String r6 = r6.m898String$arg1$callrecord2$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le62
            r12 = r58
            runBench$record(r3, r12, r5, r6)     // Catch: java.lang.Throwable -> Le56
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le56
            java.lang.String r18 = r5.m784String$arg0$callawaitStatus1$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le56
            vea.raceremote.DriveDeviceBenchTest$runBench$7 r5 = vea.raceremote.DriveDeviceBenchTest.AnonymousClass7.INSTANCE     // Catch: java.lang.Throwable -> Le56
            r23 = r5
            kotlin.jvm.functions.Function1 r23 = (kotlin.jvm.functions.Function1) r23     // Catch: java.lang.Throwable -> Le56
            r5 = r4
            r6 = r1
            r7 = r51
            r8 = r50
            r9 = r3
            r10 = r12
            r58 = r12
            r12 = r18
            r13 = r23
            runBench$awaitStatus(r5, r6, r7, r8, r9, r10, r12, r13)     // Catch: java.lang.Throwable -> Le62
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le62
            java.lang.String r12 = r5.m786String$arg0$callawaitStatus2$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le62
            vea.raceremote.DriveDeviceBenchTest$runBench$8 r5 = vea.raceremote.DriveDeviceBenchTest.AnonymousClass8.INSTANCE     // Catch: java.lang.Throwable -> Le62
            r13 = r5
            kotlin.jvm.functions.Function1 r13 = (kotlin.jvm.functions.Function1) r13     // Catch: java.lang.Throwable -> Le62
            r5 = r4
            r6 = r1
            r7 = r51
            r8 = r50
            r9 = r3
            r10 = r58
            runBench$awaitStatus(r5, r6, r7, r8, r9, r10, r12, r13)     // Catch: java.lang.Throwable -> Le62
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le62
            float r5 = r5.m657Float$arg0$callsetInput2$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le62
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le62
            float r6 = r6.m661Float$arg1$callsetInput2$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le62
            r4.setInput(r5, r6)     // Catch: java.lang.Throwable -> Le62
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le62
            java.lang.String r5 = r5.m876String$arg0$callrecord3$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le62
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le62
            java.lang.String r6 = r6.m899String$arg1$callrecord3$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le62
            r12 = r58
            runBench$record(r3, r12, r5, r6)     // Catch: java.lang.Throwable -> Le56
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le56
            java.lang.String r18 = r5.m787String$arg0$callawaitStatus3$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le56
            vea.raceremote.DriveDeviceBenchTest$runBench$9 r5 = vea.raceremote.DriveDeviceBenchTest.AnonymousClass9.INSTANCE     // Catch: java.lang.Throwable -> Le56
            r23 = r5
            kotlin.jvm.functions.Function1 r23 = (kotlin.jvm.functions.Function1) r23     // Catch: java.lang.Throwable -> Le56
            r5 = r4
            r6 = r1
            r7 = r51
            r8 = r50
            r9 = r3
            r10 = r12
            r58 = r12
            r12 = r18
            r13 = r23
            runBench$awaitStatus(r5, r6, r7, r8, r9, r10, r12, r13)     // Catch: java.lang.Throwable -> Le62
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le62
            float r5 = r5.m658Float$arg0$callsetInput3$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le62
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le62
            float r6 = r6.m662Float$arg1$callsetInput3$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le62
            r4.setInput(r5, r6)     // Catch: java.lang.Throwable -> Le62
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le62
            java.lang.String r12 = r5.m788String$arg0$callawaitStatus4$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le62
            vea.raceremote.DriveDeviceBenchTest$runBench$10 r5 = vea.raceremote.DriveDeviceBenchTest.AnonymousClass10.INSTANCE     // Catch: java.lang.Throwable -> Le62
            r13 = r5
            kotlin.jvm.functions.Function1 r13 = (kotlin.jvm.functions.Function1) r13     // Catch: java.lang.Throwable -> Le62
            r5 = r4
            r6 = r1
            r7 = r51
            r8 = r50
            r9 = r3
            r10 = r58
            runBench$awaitStatus(r5, r6, r7, r8, r9, r10, r12, r13)     // Catch: java.lang.Throwable -> Le62
            r5 = 0
            r6 = 1
            vea.raceremote.control.CarControlClient.disconnect$default(r4, r5, r6, r5)     // Catch: java.lang.Throwable -> Le62
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le62
            java.lang.String r5 = r5.m877String$arg0$callrecord4$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le62
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le62
            java.lang.String r6 = r6.m900String$arg1$callrecord4$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le62
            r12 = r58
            runBench$record(r3, r12, r5, r6)     // Catch: java.lang.Throwable -> Le56
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Le56
            java.lang.String r17 = r5.m789String$arg0$callawaitStatus5$branch$if3$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Le56
            vea.raceremote.DriveDeviceBenchTest$runBench$11 r5 = vea.raceremote.DriveDeviceBenchTest.AnonymousClass11.INSTANCE     // Catch: java.lang.Throwable -> Le56
            r18 = r5
            kotlin.jvm.functions.Function1 r18 = (kotlin.jvm.functions.Function1) r18     // Catch: java.lang.Throwable -> Le56
            r5 = r4
            r6 = r1
            r7 = r51
            r8 = r50
            r9 = r3
            r10 = r12
            r62 = r12
            r12 = r17
            r13 = r18
            runBench$awaitStatus(r5, r6, r7, r8, r9, r10, r12, r13)     // Catch: java.lang.Throwable -> Le48
            goto Lea5
        Le48:
            r0 = move-exception
            r5 = r0
            r18 = r2
            r2 = r22
            r11 = r50
            r10 = r51
            r12 = r62
            goto L1284
        Le56:
            r0 = move-exception
            r5 = r0
            r18 = r2
            r2 = r22
            r11 = r50
            r10 = r51
            goto L1284
        Le62:
            r0 = move-exception
            r5 = r0
            r18 = r2
            r2 = r22
            r11 = r50
            r10 = r51
            r12 = r58
            goto L1284
        Le70:
            r0 = move-exception
            r15 = r13
            r5 = r0
            r18 = r2
            r2 = r22
            r64 = r10
            r10 = r12
            r12 = r64
            r11 = r50
            goto L1284
        Le80:
            r0 = move-exception
            r15 = r13
            r5 = r0
            r18 = r2
            r10 = r12
            r2 = r22
            r11 = r50
            r12 = r60
            goto L1284
        Le8e:
            r0 = move-exception
            r1 = r11
            r15 = r13
            r5 = r0
            r18 = r2
            r2 = r22
            r11 = r50
            r64 = r9
            r10 = r12
            r12 = r64
            goto L1284
        Le9f:
            r62 = r9
            r1 = r11
            r51 = r12
            r15 = r13
        Lea5:
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L11ee
            java.lang.String r5 = r5.m891String$arg1$callEQEQ$cond$if4$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L11ee
            boolean r5 = kotlin.jvm.internal.Intrinsics.areEqual(r14, r5)     // Catch: java.lang.Throwable -> L11ee
            if (r5 == 0) goto L1080
            java.util.concurrent.LinkedBlockingQueue r5 = new java.util.concurrent.LinkedBlockingQueue     // Catch: java.lang.Throwable -> L1072
            r5.<init>()     // Catch: java.lang.Throwable -> L1072
            r13 = r5
            okhttp3.OkHttpClient$Builder r5 = r1.newBuilder()     // Catch: java.lang.Throwable -> L1072
            vea.raceremote.control.ControlSocketFactory r6 = new vea.raceremote.control.ControlSocketFactory     // Catch: java.lang.Throwable -> L1072
            javax.net.SocketFactory r7 = r1.socketFactory()     // Catch: java.lang.Throwable -> L1072
            java.lang.String r8 = "http.socketFactory()"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r7, r8)     // Catch: java.lang.Throwable -> L1072
            r6.<init>(r7)     // Catch: java.lang.Throwable -> L1072
            javax.net.SocketFactory r6 = (javax.net.SocketFactory) r6     // Catch: java.lang.Throwable -> L1072
            okhttp3.OkHttpClient$Builder r5 = r5.socketFactory(r6)     // Catch: java.lang.Throwable -> L1072
            okhttp3.OkHttpClient r5 = r5.build()     // Catch: java.lang.Throwable -> L1072
            okhttp3.Request$Builder r6 = new okhttp3.Request$Builder     // Catch: java.lang.Throwable -> L1072
            r6.<init>()     // Catch: java.lang.Throwable -> L1072
            java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L1072
            r7.<init>()     // Catch: java.lang.Throwable -> L1072
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r8 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L1072
            java.lang.String r8 = r8.m749String$0$str$arg0$callurl$$this$callbuild$arg0$callnewWebSocket$setraw$branch$if4$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L1072
            java.lang.StringBuilder r7 = r7.append(r8)     // Catch: java.lang.Throwable -> L1072
            r12 = r51
            java.lang.StringBuilder r7 = r7.append(r12)     // Catch: java.lang.Throwable -> L1065
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r8 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L1065
            java.lang.String r8 = r8.m757String$2$str$arg0$callurl$$this$callbuild$arg0$callnewWebSocket$setraw$branch$if4$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L1065
            java.lang.StringBuilder r7 = r7.append(r8)     // Catch: java.lang.Throwable -> L1065
            java.lang.String r7 = r7.toString()     // Catch: java.lang.Throwable -> L1065
            okhttp3.Request$Builder r6 = r6.url(r7)     // Catch: java.lang.Throwable -> L1065
            okhttp3.Request r6 = r6.build()     // Catch: java.lang.Throwable -> L1065
            vea.raceremote.DriveDeviceBenchTest$runBench$12 r7 = new vea.raceremote.DriveDeviceBenchTest$runBench$12     // Catch: java.lang.Throwable -> L1065
            r10 = r62
            r7.<init>(r13, r3, r10)     // Catch: java.lang.Throwable -> L1056
            okhttp3.WebSocketListener r7 = (okhttp3.WebSocketListener) r7     // Catch: java.lang.Throwable -> L1056
            okhttp3.WebSocket r5 = r5.newWebSocket(r6, r7)     // Catch: java.lang.Throwable -> L1056
            r9 = r5
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L1045
            long r5 = r5.m738Long$arg1$callpacket$valhello$branch$if4$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L1045
            r7 = 128(0x80, float:1.8E-43)
            vea.raceremote.control.ControlPacket r5 = runBench$packet(r13, r7, r5)     // Catch: java.lang.Throwable -> L1045
            r17 = r5
            long r5 = r17.getToken()     // Catch: java.lang.Throwable -> L1045
            r7 = r5
            if (r9 == 0) goto L1020
            vea.raceremote.control.ControlPacket r5 = new vea.raceremote.control.ControlPacket     // Catch: java.lang.Throwable -> L100b
            r41 = 1
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L100b
            long r44 = r6.m739Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$arg0$callassertTrue$branch$if4$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L100b
            r46 = 0
            r47 = 0
            r48 = 24
            r49 = 0
            r40 = r5
            r42 = r7
            r40.<init>(r41, r42, r44, r46, r47, r48, r49)     // Catch: java.lang.Throwable -> L100b
            byte[] r5 = r5.encode()     // Catch: java.lang.Throwable -> L100b
            int r6 = r5.length     // Catch: java.lang.Throwable -> L100b
            byte[] r5 = java.util.Arrays.copyOf(r5, r6)     // Catch: java.lang.Throwable -> L100b
            okio.ByteString r5 = okio.ByteString.of(r5)     // Catch: java.lang.Throwable -> L100b
            boolean r5 = r9.send(r5)     // Catch: java.lang.Throwable -> L100b
            org.junit.Assert.assertTrue(r5)     // Catch: java.lang.Throwable -> L100b
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L100b
            long r5 = r5.m736Long$arg1$callpacket$$this$call$gettoken$$arg1$callassertEquals$branch$if4$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L100b
            r18 = r2
            r2 = 129(0x81, float:1.81E-43)
            vea.raceremote.control.ControlPacket r5 = runBench$packet(r13, r2, r5)     // Catch: java.lang.Throwable -> Lff8
            long r5 = r5.getToken()     // Catch: java.lang.Throwable -> Lff8
            org.junit.Assert.assertEquals(r7, r5)     // Catch: java.lang.Throwable -> Lff8
            vea.raceremote.control.ControlPacket r5 = new vea.raceremote.control.ControlPacket     // Catch: java.lang.Throwable -> Lff8
            r41 = 2
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lff8
            long r44 = r6.m740Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$arg0$callassertTrue1$branch$if4$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lff8
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lff8
            int r46 = r6.m715Int$arg3$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$arg0$callassertTrue1$branch$if4$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lff8
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lff8
            int r47 = r6.m716Int$arg4$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$arg0$callassertTrue1$branch$if4$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lff8
            r40 = r5
            r42 = r7
            r40.<init>(r41, r42, r44, r46, r47)     // Catch: java.lang.Throwable -> Lff8
            byte[] r5 = r5.encode()     // Catch: java.lang.Throwable -> Lff8
            int r6 = r5.length     // Catch: java.lang.Throwable -> Lff8
            byte[] r5 = java.util.Arrays.copyOf(r5, r6)     // Catch: java.lang.Throwable -> Lff8
            okio.ByteString r5 = okio.ByteString.of(r5)     // Catch: java.lang.Throwable -> Lff8
            boolean r5 = r9.send(r5)     // Catch: java.lang.Throwable -> Lff8
            org.junit.Assert.assertTrue(r5)     // Catch: java.lang.Throwable -> Lff8
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lff8
            long r5 = r5.m737Long$arg1$callpacket$$this$call$gettoken$$arg1$callassertEquals1$branch$if4$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lff8
            vea.raceremote.control.ControlPacket r2 = runBench$packet(r13, r2, r5)     // Catch: java.lang.Throwable -> Lff8
            long r5 = r2.getToken()     // Catch: java.lang.Throwable -> Lff8
            org.junit.Assert.assertEquals(r7, r5)     // Catch: java.lang.Throwable -> Lff8
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lff8
            java.lang.String r2 = r2.m863String$arg0$callrecord$branch$if4$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lff8
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lff8
            java.lang.String r5 = r5.m896String$arg1$callrecord$branch$if4$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lff8
            runBench$record(r3, r10, r2, r5)     // Catch: java.lang.Throwable -> Lff8
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lff8
            java.lang.String r2 = r2.m782String$arg0$callawaitStatus$branch$if4$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> Lff8
            vea.raceremote.DriveDeviceBenchTest$runBench$13 r5 = vea.raceremote.DriveDeviceBenchTest.AnonymousClass13.INSTANCE     // Catch: java.lang.Throwable -> Lff8
            r22 = r5
            kotlin.jvm.functions.Function1 r22 = (kotlin.jvm.functions.Function1) r22     // Catch: java.lang.Throwable -> Lff8
            r5 = r4
            r6 = r1
            r23 = r7
            r7 = r12
            r8 = r50
            r30 = r9
            r9 = r3
            r31 = r10
            r51 = r12
            r12 = r2
            r2 = r13
            r13 = r22
            runBench$awaitStatus(r5, r6, r7, r8, r9, r10, r12, r13)     // Catch: java.lang.Throwable -> L1037
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L1037
            java.lang.String r12 = r5.m785String$arg0$callawaitStatus1$branch$if4$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L1037
            vea.raceremote.DriveDeviceBenchTest$runBench$14 r5 = vea.raceremote.DriveDeviceBenchTest.AnonymousClass14.INSTANCE     // Catch: java.lang.Throwable -> L1037
            r13 = r5
            kotlin.jvm.functions.Function1 r13 = (kotlin.jvm.functions.Function1) r13     // Catch: java.lang.Throwable -> L1037
            r5 = r4
            r6 = r1
            r7 = r51
            r8 = r50
            r9 = r3
            r10 = r31
            runBench$awaitStatus(r5, r6, r7, r8, r9, r10, r12, r13)     // Catch: java.lang.Throwable -> L1037
            r24 = r23
            r2 = r30
            goto L1086
        Lff8:
            r0 = move-exception
            r23 = r7
            r30 = r9
            r5 = r0
            r24 = r23
            r2 = r30
            r64 = r10
            r10 = r12
            r12 = r64
            r11 = r50
            goto L1284
        L100b:
            r0 = move-exception
            r18 = r2
            r23 = r7
            r30 = r9
            r5 = r0
            r24 = r23
            r2 = r30
            r64 = r10
            r10 = r12
            r12 = r64
            r11 = r50
            goto L1284
        L1020:
            r18 = r2
            r23 = r7
            r30 = r9
            r31 = r10
            r51 = r12
            r2 = r13
            java.lang.String r5 = "Required value was null."
            java.lang.IllegalArgumentException r6 = new java.lang.IllegalArgumentException     // Catch: java.lang.Throwable -> L1037
            java.lang.String r5 = r5.toString()     // Catch: java.lang.Throwable -> L1037
            r6.<init>(r5)     // Catch: java.lang.Throwable -> L1037
            throw r6     // Catch: java.lang.Throwable -> L1037
        L1037:
            r0 = move-exception
            r5 = r0
            r24 = r23
            r2 = r30
            r12 = r31
            r11 = r50
            r10 = r51
            goto L1284
        L1045:
            r0 = move-exception
            r18 = r2
            r30 = r9
            r5 = r0
            r2 = r30
            r64 = r10
            r10 = r12
            r12 = r64
            r11 = r50
            goto L1284
        L1056:
            r0 = move-exception
            r18 = r2
            r5 = r0
            r2 = r22
            r64 = r10
            r10 = r12
            r12 = r64
            r11 = r50
            goto L1284
        L1065:
            r0 = move-exception
            r18 = r2
            r5 = r0
            r10 = r12
            r2 = r22
            r11 = r50
            r12 = r62
            goto L1284
        L1072:
            r0 = move-exception
            r18 = r2
            r5 = r0
            r2 = r22
            r11 = r50
            r10 = r51
            r12 = r62
            goto L1284
        L1080:
            r18 = r2
            r31 = r62
            r2 = r22
        L1086:
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L11e2
            boolean r5 = r5.m651Boolean$setcomplete$try$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L11e2
            r17 = r5
            r4.close()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            long r5 = r5.m735Long$arg1$callEQEQ$$this$callnot$cond$if$finally$funrunBench$classDriveDeviceBenchTest()
            int r5 = (r24 > r5 ? 1 : (r24 == r5 ? 0 : -1))
            if (r5 == 0) goto L10ca
            if (r2 == 0) goto L10ca
            vea.raceremote.control.ControlPacket r5 = new vea.raceremote.control.ControlPacket
            r41 = 3
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            long r44 = r6.m741Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$else$when$branch$if$finally$funrunBench$classDriveDeviceBenchTest()
            r46 = 0
            r47 = 0
            r48 = 24
            r49 = 0
            r40 = r5
            r42 = r24
            r40.<init>(r41, r42, r44, r46, r47, r48, r49)
            byte[] r5 = r5.encode()
            int r6 = r5.length
            byte[] r5 = java.util.Arrays.copyOf(r5, r6)
            okio.ByteString r5 = okio.ByteString.of(r5)
            boolean r5 = r2.send(r5)
            java.lang.Boolean.valueOf(r5)
        L10ca:
            if (r2 == 0) goto L10d1
            r2.cancel()
            kotlin.Unit r5 = kotlin.Unit.INSTANCE
        L10d1:
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L10ee
            java.lang.String r12 = r5.m783String$arg0$callawaitStatus$try$finally$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L10ee
            vea.raceremote.DriveDeviceBenchTest$runBench$15 r5 = vea.raceremote.DriveDeviceBenchTest.AnonymousClass15.INSTANCE     // Catch: java.lang.Throwable -> L10ee
            r13 = r5
            kotlin.jvm.functions.Function1 r13 = (kotlin.jvm.functions.Function1) r13     // Catch: java.lang.Throwable -> L10ee
            r5 = r4
            r6 = r1
            r7 = r51
            r8 = r50
            r9 = r3
            r10 = r31
            runBench$awaitStatus(r5, r6, r7, r8, r9, r10, r12, r13)     // Catch: java.lang.Throwable -> L10ee
            r5 = r17
            r12 = r31
            goto L1107
        L10ee:
            r0 = move-exception
            r5 = r0
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r6 = r6.m865String$arg0$callrecord$catch$finally$funrunBench$classDriveDeviceBenchTest()
            java.lang.String r7 = r5.toString()
            r12 = r31
            runBench$record(r3, r12, r6, r7)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            boolean r17 = r6.m650Boolean$setcomplete$catch$finally$funrunBench$classDriveDeviceBenchTest()
            r5 = r17
        L1107:
            boolean r6 = r21.isHeld()
            if (r6 == 0) goto L1110
            r21.release()
        L1110:
            if (r28 == 0) goto L1117
            r28.close()
            kotlin.Unit r6 = kotlin.Unit.INSTANCE
        L1117:
            org.json.JSONObject r6 = new org.json.JSONObject
            r6.<init>()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r7 = r7.m834String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$callput$$this$callput$valreport$finally$funrunBench$classDriveDeviceBenchTest()
            org.json.JSONObject r6 = r6.put(r7, r5)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r7 = r7.m836String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$callput$valreport$finally$funrunBench$classDriveDeviceBenchTest()
            org.json.JSONObject r6 = r6.put(r7, r14)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r7 = r7.m839String$arg0$callput$$this$callput$$this$callput$$this$callput$valreport$finally$funrunBench$classDriveDeviceBenchTest()
            r10 = r51
            org.json.JSONObject r6 = r6.put(r7, r10)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r7 = r7.m844String$arg0$callput$$this$callput$$this$callput$valreport$finally$funrunBench$classDriveDeviceBenchTest()
            r11 = r50
            org.json.JSONObject r6 = r6.put(r7, r11)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r7 = r7.m851String$arg0$callput$$this$callput$valreport$finally$funrunBench$classDriveDeviceBenchTest()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r8 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r8 = r8.m893String$arg1$callput$$this$callput$valreport$finally$funrunBench$classDriveDeviceBenchTest()
            org.json.JSONObject r6 = r6.put(r7, r8)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r7 = r7.m858String$arg0$callput$valreport$finally$funrunBench$classDriveDeviceBenchTest()
            java.lang.String r8 = "events"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r3, r8)
            monitor-enter(r3)
            r8 = 0
            org.json.JSONArray r9 = new org.json.JSONArray     // Catch: java.lang.Throwable -> L11dc
            r17 = r3
            java.lang.Iterable r17 = (java.lang.Iterable) r17     // Catch: java.lang.Throwable -> L11dc
            java.util.List r17 = kotlin.collections.CollectionsKt.toList(r17)     // Catch: java.lang.Throwable -> L11dc
            r22 = r2
            r2 = r17
            java.util.Collection r2 = (java.util.Collection) r2     // Catch: java.lang.Throwable -> L11d9
            r9.<init>(r2)     // Catch: java.lang.Throwable -> L11d9
            monitor-exit(r3)
            org.json.JSONObject r2 = r6.put(r7, r9)
            java.io.File r6 = new java.io.File
            java.io.File r7 = r33.getFilesDir()
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r9 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r9 = r9.m750String$0$str$arg1$call$init$$$$this$callwriteText$finally$funrunBench$classDriveDeviceBenchTest()
            java.lang.StringBuilder r8 = r8.append(r9)
            java.lang.StringBuilder r8 = r8.append(r14)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r9 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r9 = r9.m758String$2$str$arg1$call$init$$$$this$callwriteText$finally$funrunBench$classDriveDeviceBenchTest()
            java.lang.StringBuilder r8 = r8.append(r9)
            java.lang.String r8 = r8.toString()
            r6.<init>(r7, r8)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            int r7 = r7.m692Int$arg0$calltoString$arg0$callwriteText$finally$funrunBench$classDriveDeviceBenchTest()
            java.lang.String r7 = r2.toString(r7)
            java.lang.String r8 = "report.toString(2)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r7, r8)
            r8 = 2
            r9 = 0
            kotlin.io.FilesKt.writeText$default(r6, r7, r9, r8, r9)
            okhttp3.Dispatcher r6 = r1.dispatcher()
            java.util.concurrent.ExecutorService r6 = r6.executorService()
            r6.shutdownNow()
            okhttp3.ConnectionPool r6 = r1.connectionPool()
            r6.evictAll()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r2 = r2.m775String$arg0$callassertTrue$funrunBench$classDriveDeviceBenchTest()
            org.junit.Assert.assertTrue(r2, r5)
            return
        L11d9:
            r0 = move-exception
            r2 = r0
            goto L11e0
        L11dc:
            r0 = move-exception
            r22 = r2
            r2 = r0
        L11e0:
            monitor-exit(r3)
            throw r2
        L11e2:
            r0 = move-exception
            r22 = r2
            r12 = r31
            r11 = r50
            r10 = r51
            r5 = r0
            goto L1284
        L11ee:
            r0 = move-exception
            r18 = r2
            r11 = r50
            r10 = r51
            r12 = r62
            r5 = r0
            r2 = r22
            goto L1284
        L11fc:
            r0 = move-exception
            goto L1201
        L11fe:
            r0 = move-exception
            r14 = r67
        L1201:
            r18 = r2
            r1 = r11
            r15 = r13
            r11 = r50
            r64 = r9
            r10 = r12
            r12 = r64
            r5 = r0
            r2 = r22
            goto L1284
        L1211:
            r0 = move-exception
            r10 = r3
            r11 = r4
            r3 = r8
            r4 = r12
            r12 = r13
            r1 = r15
            r18 = r27
            r15 = r41
            r14 = r2
            goto L122b
        L121e:
            r0 = move-exception
            r10 = r3
            r11 = r4
            r3 = r8
            r4 = r12
            r12 = r13
            r1 = r15
            r18 = r27
            r15 = r41
            r14 = r67
        L122b:
            r5 = r0
            r2 = r22
            goto L1284
        L1230:
            r0 = move-exception
            r10 = r3
            r11 = r4
            r4 = r12
            r39 = r14
            r18 = r27
            r3 = r30
            r12 = r31
            r14 = r1
            r1 = r15
            r15 = r2
            r5 = r0
            r2 = r22
            goto L1284
        L1244:
            r0 = move-exception
            r33 = r11
            r39 = r14
            r29 = r15
            r18 = r27
            r14 = r1
            r15 = r2
            r11 = r4
            r1 = r7
            r4 = r12
            r12 = r9
            r10 = r3
            r3 = r8
            r5 = r0
            r2 = r22
            goto L1284
        L1259:
            r0 = move-exception
            r33 = r11
            r18 = r13
            r39 = r14
            r29 = r15
            r14 = r1
            r15 = r2
            r11 = r4
            r1 = r7
            r4 = r12
            r12 = r9
            r10 = r3
            r3 = r8
            r5 = r0
            r2 = r22
            goto L1284
        L126e:
            r0 = move-exception
            r28 = r5
            r33 = r11
            r18 = r13
            r39 = r14
            r29 = r15
            r14 = r1
            r15 = r2
            r11 = r4
            r1 = r7
            r4 = r12
            r12 = r9
            r10 = r3
            r3 = r8
            r5 = r0
            r2 = r22
        L1284:
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L1293
            java.lang.String r6 = r6.m866String$arg0$callrecord$catch$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L1293
            java.lang.String r7 = r5.toString()     // Catch: java.lang.Throwable -> L1293
            runBench$record(r3, r12, r6, r7)     // Catch: java.lang.Throwable -> L1293
            throw r5     // Catch: java.lang.Throwable -> L1293
        L1293:
            r0 = move-exception
            r17 = r0
            r4.close()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            long r5 = r5.m735Long$arg1$callEQEQ$$this$callnot$cond$if$finally$funrunBench$classDriveDeviceBenchTest()
            int r5 = (r24 > r5 ? 1 : (r24 == r5 ? 0 : -1))
            if (r5 == 0) goto L12d2
            if (r2 == 0) goto L12d2
            vea.raceremote.control.ControlPacket r5 = new vea.raceremote.control.ControlPacket
            r41 = 3
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            long r44 = r6.m741Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$else$when$branch$if$finally$funrunBench$classDriveDeviceBenchTest()
            r46 = 0
            r47 = 0
            r48 = 24
            r49 = 0
            r40 = r5
            r42 = r24
            r40.<init>(r41, r42, r44, r46, r47, r48, r49)
            byte[] r5 = r5.encode()
            int r6 = r5.length
            byte[] r5 = java.util.Arrays.copyOf(r5, r6)
            okio.ByteString r5 = okio.ByteString.of(r5)
            boolean r5 = r2.send(r5)
            java.lang.Boolean.valueOf(r5)
        L12d2:
            if (r2 == 0) goto L12d9
            r2.cancel()
            kotlin.Unit r5 = kotlin.Unit.INSTANCE
        L12d9:
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L1304
            java.lang.String r22 = r5.m783String$arg0$callawaitStatus$try$finally$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L1304
            vea.raceremote.DriveDeviceBenchTest$runBench$15 r5 = vea.raceremote.DriveDeviceBenchTest.AnonymousClass15.INSTANCE     // Catch: java.lang.Throwable -> L1304
            r23 = r5
            kotlin.jvm.functions.Function1 r23 = (kotlin.jvm.functions.Function1) r23     // Catch: java.lang.Throwable -> L1304
            r5 = r4
            r6 = r1
            r7 = r10
            r8 = r11
            r9 = r3
            r27 = r2
            r30 = r4
            r2 = r10
            r4 = r11
            r10 = r12
            r52 = r1
            r51 = r2
            r1 = r12
            r12 = r22
            r13 = r23
            runBench$awaitStatus(r5, r6, r7, r8, r9, r10, r12, r13)     // Catch: java.lang.Throwable -> L1301
            r5 = r26
            goto L1325
        L1301:
            r0 = move-exception
            r5 = r0
            goto L1310
        L1304:
            r0 = move-exception
            r52 = r1
            r27 = r2
            r30 = r4
            r51 = r10
            r4 = r11
            r1 = r12
            r5 = r0
        L1310:
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r6 = r6.m865String$arg0$callrecord$catch$finally$funrunBench$classDriveDeviceBenchTest()
            java.lang.String r7 = r5.toString()
            runBench$record(r3, r1, r6, r7)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            boolean r26 = r6.m650Boolean$setcomplete$catch$finally$funrunBench$classDriveDeviceBenchTest()
            r5 = r26
        L1325:
            boolean r6 = r21.isHeld()
            if (r6 == 0) goto L132e
            r21.release()
        L132e:
            if (r28 == 0) goto L1335
            r28.close()
            kotlin.Unit r6 = kotlin.Unit.INSTANCE
        L1335:
            org.json.JSONObject r6 = new org.json.JSONObject
            r6.<init>()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r7 = r7.m834String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$callput$$this$callput$valreport$finally$funrunBench$classDriveDeviceBenchTest()
            org.json.JSONObject r6 = r6.put(r7, r5)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r7 = r7.m836String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$callput$valreport$finally$funrunBench$classDriveDeviceBenchTest()
            org.json.JSONObject r6 = r6.put(r7, r14)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r7 = r7.m839String$arg0$callput$$this$callput$$this$callput$$this$callput$valreport$finally$funrunBench$classDriveDeviceBenchTest()
            r8 = r51
            org.json.JSONObject r6 = r6.put(r7, r8)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r7 = r7.m844String$arg0$callput$$this$callput$$this$callput$valreport$finally$funrunBench$classDriveDeviceBenchTest()
            org.json.JSONObject r6 = r6.put(r7, r4)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r7 = r7.m851String$arg0$callput$$this$callput$valreport$finally$funrunBench$classDriveDeviceBenchTest()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r9 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r9 = r9.m893String$arg1$callput$$this$callput$valreport$finally$funrunBench$classDriveDeviceBenchTest()
            org.json.JSONObject r6 = r6.put(r7, r9)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r7 = r7.m858String$arg0$callput$valreport$finally$funrunBench$classDriveDeviceBenchTest()
            java.lang.String r9 = "events"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r3, r9)
            monitor-enter(r3)
            r9 = 0
            org.json.JSONArray r10 = new org.json.JSONArray     // Catch: java.lang.Throwable -> L13e6
            r11 = r3
            java.lang.Iterable r11 = (java.lang.Iterable) r11     // Catch: java.lang.Throwable -> L13e6
            java.util.List r11 = kotlin.collections.CollectionsKt.toList(r11)     // Catch: java.lang.Throwable -> L13e6
            java.util.Collection r11 = (java.util.Collection) r11     // Catch: java.lang.Throwable -> L13e6
            r10.<init>(r11)     // Catch: java.lang.Throwable -> L13e6
            monitor-exit(r3)
            org.json.JSONObject r6 = r6.put(r7, r10)
            java.io.File r7 = new java.io.File
            java.io.File r9 = r33.getFilesDir()
            java.lang.StringBuilder r10 = new java.lang.StringBuilder
            r10.<init>()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r11 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r11 = r11.m750String$0$str$arg1$call$init$$$$this$callwriteText$finally$funrunBench$classDriveDeviceBenchTest()
            java.lang.StringBuilder r10 = r10.append(r11)
            java.lang.StringBuilder r10 = r10.append(r14)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r11 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r11 = r11.m758String$2$str$arg1$call$init$$$$this$callwriteText$finally$funrunBench$classDriveDeviceBenchTest()
            java.lang.StringBuilder r10 = r10.append(r11)
            java.lang.String r10 = r10.toString()
            r7.<init>(r9, r10)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r9 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            int r9 = r9.m692Int$arg0$calltoString$arg0$callwriteText$finally$funrunBench$classDriveDeviceBenchTest()
            java.lang.String r9 = r6.toString(r9)
            java.lang.String r10 = "report.toString(2)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r9, r10)
            r10 = 2
            r11 = 0
            kotlin.io.FilesKt.writeText$default(r7, r9, r11, r10, r11)
            okhttp3.Dispatcher r7 = r52.dispatcher()
            java.util.concurrent.ExecutorService r7 = r7.executorService()
            r7.shutdownNow()
            okhttp3.ConnectionPool r7 = r52.connectionPool()
            r7.evictAll()
            throw r17
        L13e6:
            r0 = move-exception
            r6 = r0
            monitor-exit(r3)
            throw r6
        L13ea:
            r14 = r1
            r15 = r2
            java.lang.String r1 = "Failed requirement."
            java.lang.IllegalArgumentException r2 = new java.lang.IllegalArgumentException
            java.lang.String r1 = r1.toString()
            r2.<init>(r1)
            throw r2
        L13f8:
            r14 = r1
            r15 = r2
            r1 = 0
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r1 = r2.m901String$fun$anonymous$$arg1$callrequire$funrunBench$classDriveDeviceBenchTest()
            java.lang.IllegalArgumentException r2 = new java.lang.IllegalArgumentException
            java.lang.String r1 = r1.toString()
            r2.<init>(r1)
            throw r2
        L140b:
            r14 = r1
            r15 = r2
            java.lang.String r1 = "Required value was null."
            java.lang.IllegalArgumentException r2 = new java.lang.IllegalArgumentException
            java.lang.String r1 = r1.toString()
            r2.<init>(r1)
            throw r2
        L1419:
            r14 = r1
            r15 = r2
            java.lang.String r1 = "Required value was null."
            java.lang.IllegalArgumentException r2 = new java.lang.IllegalArgumentException
            java.lang.String r1 = r1.toString()
            r2.<init>(r1)
            throw r2
    }

    private static final org.json.JSONObject runBench$awaitStatus(vea.raceremote.control.CarControlClient r5, okhttp3.OkHttpClient r6, java.lang.String r7, java.lang.String r8, java.util.List<org.json.JSONObject> r9, long r10, java.lang.String r12, kotlin.jvm.functions.Function1<? super org.json.JSONObject, java.lang.Boolean> r13) {
            long r0 = android.os.SystemClock.elapsedRealtime()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            int r2 = r2.m684Int$arg0$callplus$valdeadline$funawaitStatus$funrunBench$classDriveDeviceBenchTest()
            long r2 = (long) r2
            long r0 = r0 + r2
        Lc:
            org.json.JSONObject r2 = runBench$status(r6, r7, r8, r9, r10, r12)
            java.lang.Object r3 = r13.invoke(r2)
            java.lang.Boolean r3 = (java.lang.Boolean) r3
            boolean r3 = r3.booleanValue()
            if (r3 == 0) goto L1d
            return r2
        L1d:
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r3 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            long r3 = r3.m732Long$arg0$callsleep$body$loop$funawaitStatus$funrunBench$classDriveDeviceBenchTest()
            android.os.SystemClock.sleep(r3)
            long r2 = android.os.SystemClock.elapsedRealtime()
            int r2 = (r2 > r0 ? 1 : (r2 == r0 ? 0 : -1))
            if (r2 >= 0) goto L2f
            goto Lc
        L2f:
            java.lang.AssertionError r2 = new java.lang.AssertionError
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r4 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r4 = r4.m743String$0$str$arg0$call$init$$funawaitStatus$funrunBench$classDriveDeviceBenchTest()
            java.lang.StringBuilder r3 = r3.append(r4)
            java.lang.StringBuilder r3 = r3.append(r12)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r4 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r4 = r4.m754String$2$str$arg0$call$init$$funawaitStatus$funrunBench$classDriveDeviceBenchTest()
            java.lang.StringBuilder r3 = r3.append(r4)
            kotlinx.coroutines.flow.StateFlow r4 = r5.getState()
            java.lang.Object r4 = r4.getValue()
            java.lang.StringBuilder r3 = r3.append(r4)
            java.lang.String r3 = r3.toString()
            r2.<init>(r3)
            throw r2
    }

    private static final void runBench$lambda$7(vea.raceremote.app.MainActivity r2) {
            android.view.Window r0 = r2.getWindow()
            r1 = 128(0x80, float:1.8E-43)
            r0.addFlags(r1)
            return
    }

    private static final vea.raceremote.control.ControlPacket runBench$packet(java.util.concurrent.LinkedBlockingQueue<vea.raceremote.control.ControlPacket> r3, int r4, long r5) {
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r0 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            long r0 = r0.m728Long$arg0$callpoll$arg0$callrequireNotNull$valp$funpacket$branch$if4$try$funrunBench$classDriveDeviceBenchTest()
            java.util.concurrent.TimeUnit r2 = java.util.concurrent.TimeUnit.SECONDS
            java.lang.Object r0 = r3.poll(r0, r2)
            if (r0 == 0) goto L27
            vea.raceremote.control.ControlPacket r0 = (vea.raceremote.control.ControlPacket) r0
            java.lang.Integer r1 = java.lang.Integer.valueOf(r4)
            int r2 = r0.getKind()
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            org.junit.Assert.assertEquals(r1, r2)
            long r1 = r0.getSequence()
            org.junit.Assert.assertEquals(r5, r1)
            return r0
        L27:
            r0 = 0
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r2 = r2.m753String$0$str$fun$anonymous$$arg1$callrequireNotNull$valp$funpacket$branch$if4$try$funrunBench$classDriveDeviceBenchTest()
            java.lang.StringBuilder r1 = r1.append(r2)
            java.lang.StringBuilder r1 = r1.append(r4)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r2 = r2.m761String$2$str$fun$anonymous$$arg1$callrequireNotNull$valp$funpacket$branch$if4$try$funrunBench$classDriveDeviceBenchTest()
            java.lang.StringBuilder r1 = r1.append(r2)
            java.lang.StringBuilder r1 = r1.append(r5)
            java.lang.String r0 = r1.toString()
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r0 = r0.toString()
            r1.<init>(r0)
            throw r1
    }

    private static final void runBench$record(java.util.List<org.json.JSONObject> r4, long r5, java.lang.String r7, java.lang.Object r8) {
            org.json.JSONObject r0 = new org.json.JSONObject
            r0.<init>()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r1 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r1 = r1.m840String$arg0$callput$$this$callput$$this$callput$arg0$calladd$funrecord$funrunBench$classDriveDeviceBenchTest()
            long r2 = android.os.SystemClock.elapsedRealtime()
            long r2 = r2 - r5
            org.json.JSONObject r0 = r0.put(r1, r2)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r1 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r1 = r1.m845String$arg0$callput$$this$callput$arg0$calladd$funrecord$funrunBench$classDriveDeviceBenchTest()
            org.json.JSONObject r0 = r0.put(r1, r7)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r1 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r1 = r1.m852String$arg0$callput$arg0$calladd$funrecord$funrunBench$classDriveDeviceBenchTest()
            org.json.JSONObject r0 = r0.put(r1, r8)
            r4.add(r0)
            return
    }

    private static final org.json.JSONObject runBench$status(okhttp3.OkHttpClient r18, java.lang.String r19, java.lang.String r20, java.util.List<org.json.JSONObject> r21, long r22, java.lang.String r24) {
            long r1 = android.os.SystemClock.elapsedRealtime()
            okhttp3.Request$Builder r0 = new okhttp3.Request$Builder
            r0.<init>()
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r4 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r4 = r4.m747String$0$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$valjson$funstatus$funrunBench$classDriveDeviceBenchTest()
            java.lang.StringBuilder r3 = r3.append(r4)
            r4 = r19
            java.lang.StringBuilder r3 = r3.append(r4)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r5 = r5.m755String$2$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$valjson$funstatus$funrunBench$classDriveDeviceBenchTest()
            java.lang.StringBuilder r3 = r3.append(r5)
            java.lang.String r3 = r3.toString()
            okhttp3.Request$Builder r0 = r0.url(r3)
            okhttp3.Request r0 = r0.build()
            r3 = r18
            okhttp3.Call r0 = r3.newCall(r0)
            okhttp3.Response r0 = r0.execute()
            r5 = r0
            java.io.Closeable r5 = (java.io.Closeable) r5
            r0 = r5
            okhttp3.Response r0 = (okhttp3.Response) r0     // Catch: java.lang.Throwable -> L181
            r6 = 0
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L181
            java.lang.String r7 = r7.m764String$arg0$callassertEquals$fun$anonymous$$arg0$calluse$valjson$funstatus$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L181
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r8 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L181
            int r8 = r8.m706Int$arg1$callassertEquals$fun$anonymous$$arg0$calluse$valjson$funstatus$funrunBench$classDriveDeviceBenchTest()     // Catch: java.lang.Throwable -> L181
            java.lang.Integer r8 = java.lang.Integer.valueOf(r8)     // Catch: java.lang.Throwable -> L181
            int r9 = r0.code()     // Catch: java.lang.Throwable -> L181
            java.lang.Integer r9 = java.lang.Integer.valueOf(r9)     // Catch: java.lang.Throwable -> L181
            org.junit.Assert.assertEquals(r7, r8, r9)     // Catch: java.lang.Throwable -> L181
            org.json.JSONObject r7 = new org.json.JSONObject     // Catch: java.lang.Throwable -> L181
            okhttp3.ResponseBody r8 = r0.body()     // Catch: java.lang.Throwable -> L181
            if (r8 == 0) goto L16b
            java.lang.String r8 = r8.string()     // Catch: java.lang.Throwable -> L181
            r7.<init>(r8)     // Catch: java.lang.Throwable -> L181
            r0 = 0
            kotlin.io.CloseableKt.closeFinally(r5, r0)
            r0 = r7
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r5 = r5.m872String$arg0$callrecord$funstatus$funrunBench$classDriveDeviceBenchTest()
            org.json.JSONObject r6 = new org.json.JSONObject
            r6.<init>()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r7 = r7.m842String$arg0$callput$$this$callput$$this$callput$arg1$callrecord$funstatus$funrunBench$classDriveDeviceBenchTest()
            r8 = r24
            org.json.JSONObject r6 = r6.put(r7, r8)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r7 = r7.m849String$arg0$callput$$this$callput$arg1$callrecord$funstatus$funrunBench$classDriveDeviceBenchTest()
            long r9 = android.os.SystemClock.elapsedRealtime()
            long r9 = r9 - r1
            org.json.JSONObject r6 = r6.put(r7, r9)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r7 = r7.m856String$arg0$callput$arg1$callrecord$funstatus$funrunBench$classDriveDeviceBenchTest()
            org.json.JSONObject r6 = r6.put(r7, r0)
            java.lang.String r7 = "JSONObject().put(\"phase\"…efore).put(\"value\", json)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r6, r7)
            r7 = r21
            r9 = r22
            runBench$record(r7, r9, r5, r6)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r5 = r5.m766String$arg0$callassertEquals$funstatus$funrunBench$classDriveDeviceBenchTest()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r6 = r6.m829String$arg0$callgetString$arg2$callassertEquals$funstatus$funrunBench$classDriveDeviceBenchTest()
            java.lang.String r6 = r0.getString(r6)
            r11 = r20
            org.junit.Assert.assertEquals(r5, r11, r6)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            int r5 = r5.m672Int$arg0$callassertEquals1$funstatus$funrunBench$classDriveDeviceBenchTest()
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r6 = r6.m810String$arg0$callgetInt$arg1$callassertEquals1$funstatus$funrunBench$classDriveDeviceBenchTest()
            int r6 = r0.getInt(r6)
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)
            org.junit.Assert.assertEquals(r5, r6)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r5 = r5.m770String$arg0$callassertFalse$funstatus$funrunBench$classDriveDeviceBenchTest()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r6 = r6.m794String$arg0$callgetBoolean$arg1$callassertFalse$funstatus$funrunBench$classDriveDeviceBenchTest()
            boolean r6 = r0.getBoolean(r6)
            org.junit.Assert.assertFalse(r5, r6)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r5 = r5.m822String$arg0$callgetJSONObject$valp$funstatus$funrunBench$classDriveDeviceBenchTest()
            org.json.JSONObject r5 = r0.getJSONObject(r5)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r6 = r6.m814String$arg0$callgetInt$valfi$funstatus$funrunBench$classDriveDeviceBenchTest()
            int r6 = r5.getInt(r6)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r12 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r12 = r12.m813String$arg0$callgetInt$valbi$funstatus$funrunBench$classDriveDeviceBenchTest()
            int r12 = r5.getInt(r12)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r13 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r13 = r13.m776String$arg0$callassertTrue$funstatus$funrunBench$classDriveDeviceBenchTest()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r14 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            int r14 = r14.m667Int$$this$callrangeTo$$this$callcontains$cond$arg1$callassertTrue$funstatus$funrunBench$classDriveDeviceBenchTest()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r15 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            int r15 = r15.m690Int$arg0$callrangeTo$$this$callcontains$cond$arg1$callassertTrue$funstatus$funrunBench$classDriveDeviceBenchTest()
            r16 = 1
            r17 = 0
            if (r6 > r15) goto L12e
            if (r14 > r6) goto L12e
            r14 = r16
            goto L130
        L12e:
            r14 = r17
        L130:
            if (r14 == 0) goto L14c
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r14 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            int r14 = r14.m664Int$$this$callrangeTo$$this$callcontains$branch$arg1$callassertTrue$funstatus$funrunBench$classDriveDeviceBenchTest()
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r15 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            int r15 = r15.m687Int$arg0$callrangeTo$$this$callcontains$branch$arg1$callassertTrue$funstatus$funrunBench$classDriveDeviceBenchTest()
            if (r12 > r15) goto L145
            if (r14 > r12) goto L145
            r14 = r16
            goto L147
        L145:
            r14 = r17
        L147:
            if (r14 == 0) goto L14c
            r14 = r16
            goto L14e
        L14c:
            r14 = r17
        L14e:
            org.junit.Assert.assertTrue(r13, r14)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r13 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r13 = r13.m779String$arg0$callassertTrue1$funstatus$funrunBench$classDriveDeviceBenchTest()
            if (r6 == 0) goto L165
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r14 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            int r14 = r14.m704Int$arg1$callEQEQ$else$arg1$callassertTrue1$funstatus$funrunBench$classDriveDeviceBenchTest()
            if (r12 != r14) goto L162
            goto L165
        L162:
            r14 = r17
            goto L167
        L165:
            r14 = r16
        L167:
            org.junit.Assert.assertTrue(r13, r14)
            return r0
        L16b:
            r11 = r20
            r7 = r21
            r9 = r22
            r8 = r24
            java.lang.String r12 = "Required value was null."
            java.lang.IllegalArgumentException r13 = new java.lang.IllegalArgumentException     // Catch: java.lang.Throwable -> L17f
            java.lang.String r12 = r12.toString()     // Catch: java.lang.Throwable -> L17f
            r13.<init>(r12)     // Catch: java.lang.Throwable -> L17f
            throw r13     // Catch: java.lang.Throwable -> L17f
        L17f:
            r0 = move-exception
            goto L18a
        L181:
            r0 = move-exception
            r11 = r20
            r7 = r21
            r9 = r22
            r8 = r24
        L18a:
            r6 = r0
            throw r6     // Catch: java.lang.Throwable -> L18c
        L18c:
            r0 = move-exception
            r12 = r0
            kotlin.io.CloseableKt.closeFinally(r5, r6)
            throw r12
    }

    private static final boolean runBench$zero(org.json.JSONObject r4) {
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r0 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r0 = r0.m815String$arg0$callgetJSONObject$$$this$calllet$funzero$funrunBench$classDriveDeviceBenchTest()
            org.json.JSONObject r0 = r4.getJSONObject(r0)
            r1 = 0
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r2 = r2.m807String$arg0$callgetInt$arg0$callEQEQ$cond$fun$anonymous$$arg0$calllet$funzero$funrunBench$classDriveDeviceBenchTest()
            int r2 = r0.getInt(r2)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r3 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            int r3 = r3.m703Int$arg1$callEQEQ$cond$fun$anonymous$$arg0$calllet$funzero$funrunBench$classDriveDeviceBenchTest()
            if (r2 != r3) goto L31
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r2 = r2.m804String$arg0$callgetInt$arg0$callEQEQ$branch$fun$anonymous$$arg0$calllet$funzero$funrunBench$classDriveDeviceBenchTest()
            int r2 = r0.getInt(r2)
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r3 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            int r3 = r3.m698Int$arg1$callEQEQ$branch$fun$anonymous$$arg0$calllet$funzero$funrunBench$classDriveDeviceBenchTest()
            if (r2 != r3) goto L31
            r2 = 1
            goto L32
        L31:
            r2 = 0
        L32:
            return r2
    }

    @org.junit.Test
    public final void nativeClientDrivePlan() {
            r1 = this;
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r0 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r0 = r0.m878String$arg0$callrunBench$funnativeClientDrivePlan$classDriveDeviceBenchTest()
            r1.runBench(r0)
            return
    }

    @org.junit.Test
    public final void neutralLinkComparison() {
            r1 = this;
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r0 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r0 = r0.m879String$arg0$callrunBench$funneutralLinkComparison$classDriveDeviceBenchTest()
            r1.runBench(r0)
            return
    }

    @org.junit.Test
    public final void silentSocketTimesOut() {
            r1 = this;
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r0 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r0 = r0.m880String$arg0$callrunBench$funsilentSocketTimesOut$classDriveDeviceBenchTest()
            r1.runBench(r0)
            return
    }

    @org.junit.Test
    public final void udpDiscoveryLatency() {
            r1 = this;
            vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt r0 = vea.raceremote.LiveLiterals$DriveDeviceBenchTestKt.INSTANCE
            java.lang.String r0 = r0.m881String$arg0$callrunBench$funudpDiscoveryLatency$classDriveDeviceBenchTest()
            r1.runBench(r0)
            return
    }
}
