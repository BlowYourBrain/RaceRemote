package vea.raceremote;

/* JADX INFO: compiled from: UdpControlDeviceBenchTest.kt */
/* JADX INFO: loaded from: classes4.dex */
@kotlin.Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0002J\b\u0010\u0007\u001a\u00020\u0004H\u0007J\b\u0010\b\u001a\u00020\u0004H\u0007J\b\u0010\t\u001a\u00020\u0004H\u0007J\b\u0010\n\u001a\u00020\u0004H\u0007J\b\u0010\u000b\u001a\u00020\u0004H\u0007¨\u0006\f"}, d2 = {"Lvea/raceremote/UdpControlDeviceBenchTest;", "", "()V", "bench", "", "scenario", "", "driveAndStop", "silenceExpiresOnBoard", "sixNeutralSessions", "sustainedNeutralSession", "wifiLockComparison", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class UdpControlDeviceBenchTest {
    public static final int $stable = 0;



    /* JADX INFO: renamed from: vea.raceremote.UdpControlDeviceBenchTest$bench$5, reason: invalid class name */
    /* JADX INFO: compiled from: UdpControlDeviceBenchTest.kt */
    @kotlin.Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    /* synthetic */ class AnonymousClass5 extends kotlin.jvm.internal.FunctionReferenceImpl implements kotlin.jvm.functions.Function1<org.json.JSONObject, java.lang.Boolean> {
        public static final vea.raceremote.UdpControlDeviceBenchTest.AnonymousClass5 INSTANCE = null;

        static {
                vea.raceremote.UdpControlDeviceBenchTest$bench$5 r0 = new vea.raceremote.UdpControlDeviceBenchTest$bench$5
                r0.<init>()
                vea.raceremote.UdpControlDeviceBenchTest.AnonymousClass5.INSTANCE = r0
                return
        }

        AnonymousClass5() {
                r6 = this;
                r1 = 1
                java.lang.Class<kotlin.jvm.internal.Intrinsics$Kotlin> r2 = kotlin.jvm.internal.Intrinsics.Kotlin.class
                java.lang.String r3 = "neutral"
                java.lang.String r4 = "bench$neutral(Lorg/json/JSONObject;)Z"
                r5 = 0
                r0 = r6
                r0.<init>(r1, r2, r3, r4, r5)
                return
        }

        public final java.lang.Boolean invoke(org.json.JSONObject r2) {
                r1 = this;
                java.lang.String r0 = "p0"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                boolean r0 = vea.raceremote.UdpControlDeviceBenchTest.access$bench$neutral(r2)
                java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
                return r0
        }

        public /* bridge */ /* synthetic */ java.lang.Object invoke(java.lang.Object r2) {
                r1 = this;
                r0 = r2
                org.json.JSONObject r0 = (org.json.JSONObject) r0
                java.lang.Boolean r0 = r1.invoke(r0)
                return r0
        }
    }

    public static /* synthetic */ void $r8$lambda$YNYEhGhmBvf1aurxU96YJTAkQII(vea.raceremote.app.MainActivity r0) {
            bench$lambda$6(r0)
            return
    }

    static {
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r0 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            int r0 = r0.m1112Int$classUdpControlDeviceBenchTest()
            vea.raceremote.UdpControlDeviceBenchTest.$stable = r0
            return
    }

    public UdpControlDeviceBenchTest() {
            r0 = this;
            r0.<init>()
            return
    }

    public static final /* synthetic */ boolean access$bench$neutral(org.json.JSONObject r1) {
            boolean r0 = bench$neutral(r1)
            return r0
    }

    public static final /* synthetic */ void access$bench$record(java.util.List r0, long r1, java.lang.String r3, java.lang.Object r4) {
            bench$record(r0, r1, r3, r4)
            return
    }

    private final void bench(java.lang.String r79) {
            r78 = this;
            r1 = r79
            java.lang.String r2 = "report.toString(2)"
            java.lang.String r3 = "events"
            java.lang.String r4 = "JSONObject().put(\"trial\"…rial).put(\"trace\", trace)"
            android.os.Bundle r13 = androidx.test.platform.app.InstrumentationRegistry.getArguments()
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r5 = r5.m1178String$arg0$callgetString$arg0$callEQEQ$arg0$callassumeTrue$funbench$classUdpControlDeviceBenchTest()
            java.lang.String r5 = r13.getString(r5)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r6 = r6.m1224String$arg1$callEQEQ$arg0$callassumeTrue$funbench$classUdpControlDeviceBenchTest()
            boolean r5 = kotlin.jvm.internal.Intrinsics.areEqual(r5, r6)
            org.junit.Assume.assumeTrue(r5)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r5 = r5.m1181String$arg0$callgetString$arg0$callrequireNotNull$valhost$funbench$classUdpControlDeviceBenchTest()
            java.lang.String r5 = r13.getString(r5)
            java.lang.String r14 = "Required value was null."
            if (r5 == 0) goto L12c2
            java.lang.String r6 = "requireNotNull(args.getString(\"driveBenchHost\"))"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r5, r6)
            r12 = r5
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r5 = r5.m1180String$arg0$callgetString$arg0$callrequireNotNull$valexpectedCar$funbench$classUdpControlDeviceBenchTest()
            java.lang.String r5 = r13.getString(r5)
            if (r5 == 0) goto L12b5
            java.lang.String r6 = "requireNotNull(args.getString(\"driveBenchCarId\"))"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r5, r6)
            r15 = r5
            r5 = r12
            java.lang.CharSequence r5 = (java.lang.CharSequence) r5
            r11 = 1
            char[] r6 = new char[r11]
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            char r7 = r7.m1062Char$0$vararg$arg0$callsplit$$$this$callmap$valoctets$funbench$classUdpControlDeviceBenchTest()
            r10 = 0
            r6[r10] = r7
            r7 = 0
            r8 = 0
            r9 = 6
            r16 = 0
            r11 = r10
            r10 = r16
            java.util.List r5 = kotlin.text.StringsKt.split$default(r5, r6, r7, r8, r9, r10)
            java.lang.Iterable r5 = (java.lang.Iterable) r5
            r6 = 0
            java.util.ArrayList r7 = new java.util.ArrayList
            r8 = 10
            int r9 = kotlin.collections.CollectionsKt.collectionSizeOrDefault(r5, r8)
            r7.<init>(r9)
            java.util.Collection r7 = (java.util.Collection) r7
            r9 = r5
            r10 = 0
            java.util.Iterator r16 = r9.iterator()
        L7a:
            boolean r18 = r16.hasNext()
            if (r18 == 0) goto L94
            java.lang.Object r18 = r16.next()
            r19 = r18
            java.lang.String r19 = (java.lang.String) r19
            r20 = 0
            java.lang.Integer r8 = kotlin.text.StringsKt.toIntOrNull(r19)
            r7.add(r8)
            r8 = 10
            goto L7a
        L94:
            java.util.List r7 = (java.util.List) r7
            r10 = r7
            int r5 = r10.size()
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            int r6 = r6.m1097Int$arg1$callEQEQ$cond$cond$arg0$callrequire$funbench$classUdpControlDeviceBenchTest()
            if (r5 != r6) goto L17f
            r5 = r10
            java.lang.Iterable r5 = (java.lang.Iterable) r5
            r6 = 0
            boolean r7 = r5 instanceof java.util.Collection
            if (r7 == 0) goto Lb8
            r7 = r5
            java.util.Collection r7 = (java.util.Collection) r7
            boolean r7 = r7.isEmpty()
            if (r7 == 0) goto Lb8
            r5 = 1
            goto L102
        Lb8:
            java.util.Iterator r7 = r5.iterator()
        Lbc:
            boolean r8 = r7.hasNext()
            if (r8 == 0) goto Lfd
            java.lang.Object r8 = r7.next()
            r9 = r8
            java.lang.Integer r9 = (java.lang.Integer) r9
            r16 = 0
            if (r9 == 0) goto Lee
            kotlin.ranges.IntRange r11 = new kotlin.ranges.IntRange
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r19 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            r20 = r5
            int r5 = r19.m1066Int$$this$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$arg0$callrequire$funbench$classUdpControlDeviceBenchTest()
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r19 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            r22 = r6
            int r6 = r19.m1087Int$arg0$callrangeTo$$this$callcontains$branch$fun$anonymous$$arg0$callall$branch$cond$arg0$callrequire$funbench$classUdpControlDeviceBenchTest()
            r11.<init>(r5, r6)
            int r5 = r9.intValue()
            boolean r5 = r11.contains(r5)
            if (r5 == 0) goto Lf2
            r5 = 1
            goto Lf3
        Lee:
            r20 = r5
            r22 = r6
        Lf2:
            r5 = 0
        Lf3:
            if (r5 != 0) goto Lf7
            r5 = 0
            goto L102
        Lf7:
            r5 = r20
            r6 = r22
            r11 = 0
            goto Lbc
        Lfd:
            r20 = r5
            r22 = r6
            r5 = 1
        L102:
            if (r5 == 0) goto L17e
            r11 = 0
            java.lang.Object r5 = r10.get(r11)
            java.lang.Integer r5 = (java.lang.Integer) r5
            if (r5 != 0) goto L10e
            goto L116
        L10e:
            int r5 = r5.intValue()
            r6 = 10
            if (r5 == r6) goto L17c
        L116:
            java.lang.Object r5 = r10.get(r11)
            java.lang.Integer r5 = (java.lang.Integer) r5
            if (r5 != 0) goto L11f
            goto L139
        L11f:
            int r5 = r5.intValue()
            r6 = 192(0xc0, float:2.69E-43)
            if (r5 != r6) goto L139
            r5 = 1
            java.lang.Object r6 = r10.get(r5)
            java.lang.Integer r6 = (java.lang.Integer) r6
            if (r6 != 0) goto L131
            goto L139
        L131:
            int r5 = r6.intValue()
            r6 = 168(0xa8, float:2.35E-43)
            if (r5 == r6) goto L17c
        L139:
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            int r5 = r5.m1079Int$arg0$callget$arg0$callEQEQ$cond$else$branch$arg0$callrequire$funbench$classUdpControlDeviceBenchTest()
            java.lang.Object r5 = r10.get(r5)
            java.lang.Integer r5 = (java.lang.Integer) r5
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            int r6 = r6.m1099Int$arg1$callEQEQ$cond$else$branch$arg0$callrequire$funbench$classUdpControlDeviceBenchTest()
            if (r5 != 0) goto L14e
            goto L17f
        L14e:
            int r5 = r5.intValue()
            if (r5 != r6) goto L17f
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            int r5 = r5.m1065Int$$this$callrangeTo$$this$callcontains$branch$else$branch$arg0$callrequire$funbench$classUdpControlDeviceBenchTest()
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            int r6 = r6.m1086Int$arg0$callrangeTo$$this$callcontains$branch$else$branch$arg0$callrequire$funbench$classUdpControlDeviceBenchTest()
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            int r7 = r7.m1078Int$arg0$callget$arg0$callCHECK_NOT_NULL$arg0$callcontains$branch$else$branch$arg0$callrequire$funbench$classUdpControlDeviceBenchTest()
            java.lang.Object r7 = r10.get(r7)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r7)
            java.lang.Number r7 = (java.lang.Number) r7
            int r7 = r7.intValue()
            if (r5 > r7) goto L179
            if (r7 > r6) goto L179
            r5 = 1
            goto L17a
        L179:
            r5 = r11
        L17a:
            if (r5 == 0) goto L17f
        L17c:
            r5 = 1
            goto L180
        L17e:
            r11 = 0
        L17f:
            r5 = r11
        L180:
            java.lang.String r16 = "Failed requirement."
            if (r5 == 0) goto L12aa
            android.app.Instrumentation r5 = androidx.test.platform.app.InstrumentationRegistry.getInstrumentation()
            android.content.Context r9 = r5.getTargetContext()
            java.lang.Class<android.net.ConnectivityManager> r5 = android.net.ConnectivityManager.class
            java.lang.Object r5 = r9.getSystemService(r5)
            r8 = r5
            android.net.ConnectivityManager r8 = (android.net.ConnectivityManager) r8
            android.net.Network[] r5 = r8.getAllNetworks()
            java.lang.String r6 = "cm.allNetworks"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r5, r6)
            java.lang.Object[] r5 = (java.lang.Object[]) r5
            r6 = 0
            int r7 = r5.length
        L1a2:
            r26 = r2
            if (r11 >= r7) goto L1d4
            r19 = r5[r11]
            r2 = r19
            android.net.Network r2 = (android.net.Network) r2
            r20 = 0
            r21 = r5
            android.net.NetworkCapabilities r5 = r8.getNetworkCapabilities(r2)
            if (r5 == 0) goto L1c7
            r22 = r2
            r2 = 1
            boolean r5 = r5.hasTransport(r2)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r17 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            boolean r2 = r17.m1056Boolean$arg1$callEQEQ$fun$anonymous$$arg0$callfirstOrNull$arg0$callrequireNotNull$valwifi$funbench$classUdpControlDeviceBenchTest()
            if (r5 != r2) goto L1c9
            r2 = 1
            goto L1ca
        L1c7:
            r22 = r2
        L1c9:
            r2 = 0
        L1ca:
            if (r2 == 0) goto L1cd
            goto L1d8
        L1cd:
            int r11 = r11 + 1
            r5 = r21
            r2 = r26
            goto L1a2
        L1d4:
            r21 = r5
            r19 = 0
        L1d8:
            if (r19 == 0) goto L129d
            r2 = r19
            android.net.Network r2 = (android.net.Network) r2
            okhttp3.OkHttpClient$Builder r5 = new okhttp3.OkHttpClient$Builder
            r5.<init>()
            javax.net.SocketFactory r6 = r2.getSocketFactory()
            okhttp3.OkHttpClient$Builder r5 = r5.socketFactory(r6)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            long r6 = r6.m1118Long$arg0$callconnectTimeout$$this$callreadTimeout$$this$callcallTimeout$$this$callbuild$valhttp$funbench$classUdpControlDeviceBenchTest()
            java.util.concurrent.TimeUnit r11 = java.util.concurrent.TimeUnit.SECONDS
            okhttp3.OkHttpClient$Builder r5 = r5.connectTimeout(r6, r11)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            long r6 = r6.m1119Long$arg0$callreadTimeout$$this$callcallTimeout$$this$callbuild$valhttp$funbench$classUdpControlDeviceBenchTest()
            java.util.concurrent.TimeUnit r11 = java.util.concurrent.TimeUnit.SECONDS
            okhttp3.OkHttpClient$Builder r5 = r5.readTimeout(r6, r11)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            long r6 = r6.m1117Long$arg0$callcallTimeout$$this$callbuild$valhttp$funbench$classUdpControlDeviceBenchTest()
            java.util.concurrent.TimeUnit r11 = java.util.concurrent.TimeUnit.SECONDS
            okhttp3.OkHttpClient$Builder r5 = r5.callTimeout(r6, r11)
            okhttp3.OkHttpClient r5 = r5.build()
            r11 = r5
            java.util.ArrayList r5 = new java.util.ArrayList
            r5.<init>()
            java.util.List r5 = (java.util.List) r5
            java.util.List r7 = java.util.Collections.synchronizedList(r5)
            long r5 = android.os.SystemClock.elapsedRealtime()
            r17 = r8
            android.content.Context r8 = r9.getApplicationContext()
            r19 = r10
            java.lang.Class<android.net.wifi.WifiManager> r10 = android.net.wifi.WifiManager.class
            java.lang.Object r8 = r8.getSystemService(r10)
            r10 = r8
            android.net.wifi.WifiManager r10 = (android.net.wifi.WifiManager) r10
            r8 = 0
            r8 = 4
            r20 = 0
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r21 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            r48 = r3
            java.lang.String r3 = r21.m1235String$arg1$callcreateWifiLock$valwifiLock$funbench$classUdpControlDeviceBenchTest()
            android.net.wifi.WifiManager$WifiLock r3 = r10.createWifiLock(r8, r3)
            r20 = 0
            kotlin.jvm.internal.Ref$ObjectRef r21 = new kotlin.jvm.internal.Ref$ObjectRef
            r21.<init>()
            r49 = r21
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r21 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            r27 = r14
            boolean r14 = r21.m1060Boolean$valcomplete$funbench$classUdpControlDeviceBenchTest()
            r50 = r14
            java.lang.Class<vea.raceremote.app.MainActivity> r21 = vea.raceremote.app.MainActivity.class
            androidx.test.core.app.ActivityScenario r21 = androidx.test.core.app.ActivityScenario.launch(r21)     // Catch: java.lang.Throwable -> L11a0
            r51 = r21
            vea.raceremote.UdpControlDeviceBenchTest$$ExternalSyntheticLambda0 r14 = new vea.raceremote.UdpControlDeviceBenchTest$$ExternalSyntheticLambda0     // Catch: java.lang.Throwable -> L117f
            r14.<init>()     // Catch: java.lang.Throwable -> L117f
            r28 = r4
            r4 = r51
            r4.onActivity(r14)     // Catch: java.lang.Throwable -> L115e
            androidx.lifecycle.Lifecycle$State r14 = androidx.lifecycle.Lifecycle.State.RESUMED     // Catch: java.lang.Throwable -> L115e
            r21 = r8
            androidx.lifecycle.Lifecycle$State r8 = r4.getState()     // Catch: java.lang.Throwable -> L113a
            org.junit.Assert.assertEquals(r14, r8)     // Catch: java.lang.Throwable -> L113a
            java.lang.Class<android.os.PowerManager> r8 = android.os.PowerManager.class
            java.lang.Object r8 = r9.getSystemService(r8)     // Catch: java.lang.Throwable -> L113a
            android.os.PowerManager r8 = (android.os.PowerManager) r8     // Catch: java.lang.Throwable -> L113a
            boolean r8 = r8.isInteractive()     // Catch: java.lang.Throwable -> L113a
            org.junit.Assert.assertTrue(r8)     // Catch: java.lang.Throwable -> L113a
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r8 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L113a
            java.lang.String r8 = r8.m1221String$arg0$callrecord$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L113a
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r14 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L113a
            java.lang.String r14 = r14.m1238String$arg1$callrecord$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L113a
            bench$record(r7, r5, r8, r14)     // Catch: java.lang.Throwable -> L113a
            r3.acquire()     // Catch: java.lang.Throwable -> L113a
            r52 = r5
            r5 = r11
            r6 = r12
            r14 = r7
            r7 = r15
            r51 = r17
            r24 = r21
            r8 = r13
            r54 = r9
            r9 = r14
            r23 = r3
            r3 = r10
            r56 = r11
            r55 = r19
            r29 = 1
            r30 = 0
            r10 = r52
            org.json.JSONObject r5 = bench$status(r5, r6, r7, r8, r9, r10)     // Catch: java.lang.Throwable -> L111f
            r10 = r5
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L111f
            java.lang.String r5 = r5.m1148String$arg0$callassertTrue1$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L111f
            boolean r6 = bench$neutral(r10)     // Catch: java.lang.Throwable -> L111f
            org.junit.Assert.assertTrue(r5, r6)     // Catch: java.lang.Throwable -> L111f
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L111f
            java.lang.String r5 = r5.m1157String$arg0$callgetBoolean$arg0$callassertTrue2$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L111f
            boolean r5 = r10.getBoolean(r5)     // Catch: java.lang.Throwable -> L111f
            org.junit.Assert.assertTrue(r5)     // Catch: java.lang.Throwable -> L111f
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L111f
            java.lang.String r5 = r5.m1177String$arg0$callgetString$$$this$calltoLong$valwarmupMs$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L111f
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L111f
            java.lang.String r6 = r6.m1236String$arg1$callgetString$$$this$calltoLong$valwarmupMs$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L111f
            java.lang.String r5 = r13.getString(r5, r6)     // Catch: java.lang.Throwable -> L111f
            java.lang.String r6 = "args.getString(\"udpBenchWarmupMs\", \"0\")"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r5, r6)     // Catch: java.lang.Throwable -> L111f
            long r5 = java.lang.Long.parseLong(r5)     // Catch: java.lang.Throwable -> L111f
            r57 = r5
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L111f
            int r5 = r5.m1063Int$$this$callrangeTo$$$this$callcontains$arg0$callrequire$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L111f
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L111f
            int r6 = r6.m1084Int$arg0$callrangeTo$$$this$callcontains$arg0$callrequire$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L111f
            long r6 = (long) r6     // Catch: java.lang.Throwable -> L111f
            int r6 = (r57 > r6 ? 1 : (r57 == r6 ? 0 : -1))
            if (r6 > 0) goto L306
            long r5 = (long) r5     // Catch: java.lang.Throwable -> L111f
            int r5 = (r5 > r57 ? 1 : (r5 == r57 ? 0 : -1))
            if (r5 > 0) goto L306
            r11 = r29
            goto L308
        L306:
            r11 = r30
        L308:
            if (r11 == 0) goto L10f8
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L111f
            int r5 = r5.m1068Int$$this$calltoLong$arg1$callgreater$cond$if$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L111f
            long r5 = (long) r5
            int r5 = (r57 > r5 ? 1 : (r57 == r5 ? 0 : -1))
            if (r5 <= 0) goto L3a6
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L38b
            java.lang.String r5 = r5.m1210String$arg0$callrecord$branch$if$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L38b
            java.lang.Long r6 = java.lang.Long.valueOf(r57)     // Catch: java.lang.Throwable -> L38b
            r8 = r52
            bench$record(r14, r8, r5, r6)     // Catch: java.lang.Throwable -> L371
            android.os.SystemClock.sleep(r57)     // Catch: java.lang.Throwable -> L371
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L371
            java.lang.String r5 = r5.m1222String$arg0$callrecord1$branch$if$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L371
            java.lang.Long r6 = java.lang.Long.valueOf(r57)     // Catch: java.lang.Throwable -> L371
            bench$record(r14, r8, r5, r6)     // Catch: java.lang.Throwable -> L371
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L371
            java.lang.String r11 = r5.m1146String$arg0$callassertTrue$branch$if$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L371
            r5 = r56
            r6 = r12
            r7 = r15
            r52 = r8
            r8 = r13
            r9 = r14
            r59 = r4
            r4 = r10
            r18 = r15
            r15 = r11
            r10 = r52
            org.json.JSONObject r5 = bench$status(r5, r6, r7, r8, r9, r10)     // Catch: java.lang.Throwable -> L357
            boolean r5 = bench$neutral(r5)     // Catch: java.lang.Throwable -> L357
            org.junit.Assert.assertTrue(r15, r5)     // Catch: java.lang.Throwable -> L357
            goto L3ab
        L357:
            r0 = move-exception
            r21 = r2
            r4 = r12
            r7 = r18
            r8 = r24
            r9 = r26
            r10 = r48
            r11 = r52
            r15 = r56
            r20 = r59
            r2 = r0
            r53 = r3
            r3 = r1
            r1 = r49
            goto L11bc
        L371:
            r0 = move-exception
            r59 = r4
            r21 = r2
            r53 = r3
            r4 = r12
            r7 = r15
            r10 = r48
            r15 = r56
            r20 = r59
            r2 = r0
            r3 = r1
            r11 = r8
            r8 = r24
            r9 = r26
            r1 = r49
            goto L11bc
        L38b:
            r0 = move-exception
            r59 = r4
            r21 = r2
            r4 = r12
            r7 = r15
            r8 = r24
            r9 = r26
            r10 = r48
            r11 = r52
            r15 = r56
            r20 = r59
            r2 = r0
            r53 = r3
            r3 = r1
            r1 = r49
            goto L11bc
        L3a6:
            r59 = r4
            r4 = r10
            r18 = r15
        L3ab:
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L10de
            java.lang.String r5 = r5.m1176String$arg0$callgetString$$$this$calltoLong$valchip$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L10de
            java.lang.String r5 = r4.getString(r5)     // Catch: java.lang.Throwable -> L10de
            java.lang.String r6 = "initial.getString(\"chipId\")"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r5, r6)     // Catch: java.lang.Throwable -> L10de
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L10de
            int r6 = r6.m1090Int$arg0$calltoLong$valchip$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L10de
            int r6 = kotlin.text.CharsKt.checkRadix(r6)     // Catch: java.lang.Throwable -> L10de
            long r16 = java.lang.Long.parseLong(r5, r6)     // Catch: java.lang.Throwable -> L10de
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L10de
            java.lang.String r5 = r5.m1230String$arg1$callEQEQ$cond$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L10de
            boolean r5 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r5)     // Catch: java.lang.Throwable -> L10de
            if (r5 == 0) goto L4a9
            r10 = r18
            r15 = r12
            r18 = r49
            r19 = r2
            r20 = r14
            r21 = r52
            vea.raceremote.control.UdpControlClient r5 = bench$connect(r15, r16, r18, r19, r20, r21)     // Catch: java.lang.Throwable -> L490
            r15 = r5
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L490
            int r5 = r5.m1080Int$arg0$callinput$branch$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L490
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L490
            int r6 = r6.m1104Int$arg1$callinput$branch$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L490
            r15.input(r5, r6)     // Catch: java.lang.Throwable -> L490
            vea.raceremote.UdpControlDeviceBenchTest$bench$3 r5 = vea.raceremote.UdpControlDeviceBenchTest.AnonymousClass3.INSTANCE     // Catch: java.lang.Throwable -> L490
            r18 = r5
            kotlin.jvm.functions.Function1 r18 = (kotlin.jvm.functions.Function1) r18     // Catch: java.lang.Throwable -> L490
            r5 = r56
            r6 = r12
            r7 = r10
            r8 = r13
            r9 = r14
            r60 = r10
            r10 = r52
            r61 = r12
            r12 = r18
            bench$awaitStatus(r5, r6, r7, r8, r9, r10, r12)     // Catch: java.lang.Throwable -> L4c0
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L4c0
            int r5 = r5.m1081Int$arg0$callinput1$branch$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L4c0
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L4c0
            int r6 = r6.m1105Int$arg1$callinput1$branch$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L4c0
            r15.input(r5, r6)     // Catch: java.lang.Throwable -> L4c0
            vea.raceremote.UdpControlDeviceBenchTest$bench$4 r5 = vea.raceremote.UdpControlDeviceBenchTest.AnonymousClass4.INSTANCE     // Catch: java.lang.Throwable -> L4c0
            r12 = r5
            kotlin.jvm.functions.Function1 r12 = (kotlin.jvm.functions.Function1) r12     // Catch: java.lang.Throwable -> L4c0
            r5 = r56
            r6 = r61
            r7 = r60
            r8 = r13
            r9 = r14
            r10 = r52
            bench$awaitStatus(r5, r6, r7, r8, r9, r10, r12)     // Catch: java.lang.Throwable -> L4c0
            r15.close()     // Catch: java.lang.Throwable -> L4c0
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L4c0
            java.lang.String r5 = r5.m1211String$arg0$callrecord$branch$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L4c0
            vea.raceremote.control.UdpControlSession$Snapshot r6 = r15.snapshot()     // Catch: java.lang.Throwable -> L4c0
            java.lang.String r6 = r6.toString()     // Catch: java.lang.Throwable -> L4c0
            r10 = r52
            bench$record(r14, r10, r5, r6)     // Catch: java.lang.Throwable -> L476
            vea.raceremote.UdpControlDeviceBenchTest$bench$5 r5 = vea.raceremote.UdpControlDeviceBenchTest.AnonymousClass5.INSTANCE     // Catch: java.lang.Throwable -> L476
            r12 = r5
            kotlin.jvm.functions.Function1 r12 = (kotlin.jvm.functions.Function1) r12     // Catch: java.lang.Throwable -> L476
            r5 = r56
            r6 = r61
            r7 = r60
            r8 = r13
            r9 = r14
            r52 = r10
            bench$awaitStatus(r5, r6, r7, r8, r9, r10, r12)     // Catch: java.lang.Throwable -> L4c0
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L4c0
            java.lang.String r5 = r5.m1140String$arg0$callassertEquals$branch$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L4c0
            vea.raceremote.control.UdpControlSession$Snapshot r6 = r15.snapshot()     // Catch: java.lang.Throwable -> L4c0
            java.lang.String r6 = r6.getReason()     // Catch: java.lang.Throwable -> L4c0
            org.junit.Assert.assertEquals(r5, r6)     // Catch: java.lang.Throwable -> L4c0
            r21 = r2
            r62 = r52
            r15 = r56
            r53 = r3
            r52 = r4
            r4 = r61
            r3 = r1
            r1 = r49
            goto Lfcb
        L476:
            r0 = move-exception
            r21 = r2
            r53 = r3
            r11 = r10
            r8 = r24
            r9 = r26
            r10 = r48
            r15 = r56
            r20 = r59
            r7 = r60
            r4 = r61
            r2 = r0
            r3 = r1
            r1 = r49
            goto L11bc
        L490:
            r0 = move-exception
            r21 = r2
            r7 = r10
            r4 = r12
            r8 = r24
            r9 = r26
            r10 = r48
            r11 = r52
            r15 = r56
            r20 = r59
            r2 = r0
            r53 = r3
            r3 = r1
            r1 = r49
            goto L11bc
        L4a9:
            r61 = r12
            r60 = r18
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L10c3
            java.lang.String r5 = r5.m1229String$arg1$callEQEQ$cond$when$cond$when$cond1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L10c3
            boolean r5 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r5)     // Catch: java.lang.Throwable -> L10c3
            if (r5 == 0) goto L4db
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L4c0
            boolean r5 = r5.m1057Boolean$branch$when$cond$when$cond1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L4c0
            goto L4e5
        L4c0:
            r0 = move-exception
            r21 = r2
            r8 = r24
            r9 = r26
            r10 = r48
            r11 = r52
            r15 = r56
            r20 = r59
            r7 = r60
            r4 = r61
            r2 = r0
            r53 = r3
            r3 = r1
            r1 = r49
            goto L11bc
        L4db:
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L10c3
            java.lang.String r5 = r5.m1232String$arg1$callEQEQ$else$when$cond$when$cond1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L10c3
            boolean r5 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r5)     // Catch: java.lang.Throwable -> L10c3
        L4e5:
            if (r5 == 0) goto L4ee
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L4c0
            boolean r5 = r5.m1058Boolean$branch$when$cond1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L4c0
            goto L4f8
        L4ee:
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L10c3
            java.lang.String r5 = r5.m1233String$arg1$callEQEQ$else$when$cond1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L10c3
            boolean r5 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r5)     // Catch: java.lang.Throwable -> L10c3
        L4f8:
            if (r5 == 0) goto Le05
            r5 = 0
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lde8
            int r6 = r6.m1114Int$valfailures$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lde8
            r5 = r6
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lde8
            java.lang.String r6 = r6.m1228String$arg1$callEQEQ$cond$if$valsessions$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lde8
            boolean r6 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r6)     // Catch: java.lang.Throwable -> Lde8
            if (r6 == 0) goto L515
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L4c0
            int r6 = r6.m1111Int$branch$if$valsessions$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L4c0
            goto L51b
        L515:
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lde8
            int r6 = r6.m1113Int$else$if$valsessions$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lde8
        L51b:
            r15 = r6
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lde8
            java.lang.String r6 = r6.m1227String$arg1$callEQEQ$cond$if$valdurationMs$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lde8
            boolean r6 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r6)     // Catch: java.lang.Throwable -> Lde8
            if (r6 == 0) goto L52f
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L4c0
            long r6 = r6.m1131Long$branch$if$valdurationMs$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L4c0
            goto L535
        L52f:
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lde8
            long r6 = r6.m1132Long$else$if$valdurationMs$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lde8
        L535:
            r10 = r6
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lde8
            java.lang.String r6 = r6.m1212String$arg0$callrecord$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lde8
            org.json.JSONObject r7 = new org.json.JSONObject     // Catch: java.lang.Throwable -> Lde8
            r7.<init>()     // Catch: java.lang.Throwable -> Lde8
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r8 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lde8
            java.lang.String r8 = r8.m1197String$arg0$callput$$this$callput$arg1$callrecord$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lde8
            org.json.JSONObject r7 = r7.put(r8, r15)     // Catch: java.lang.Throwable -> Lde8
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r8 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lde8
            java.lang.String r8 = r8.m1204String$arg0$callput$arg1$callrecord$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lde8
            org.json.JSONObject r7 = r7.put(r8, r10)     // Catch: java.lang.Throwable -> Lde8
            java.lang.String r8 = "JSONObject().put(\"sessio…\"durationMs\", durationMs)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r7, r8)     // Catch: java.lang.Throwable -> Lde8
            r8 = r52
            bench$record(r14, r8, r6, r7)     // Catch: java.lang.Throwable -> Ldcd
            r12 = r5
            r7 = r30
        L562:
            if (r7 >= r15) goto Ld5b
            r6 = r7
            r31 = 0
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Ldcd
            java.lang.String r5 = r5.m1226String$arg1$callEQEQ$cond$if$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Ldcd
            boolean r5 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r5)     // Catch: java.lang.Throwable -> Ldcd
            if (r5 == 0) goto L637
            int r5 = android.os.Build.VERSION.SDK_INT     // Catch: java.lang.Throwable -> L61d
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r18 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L61d
            r52 = r4
            int r4 = r18.m1106Int$arg1$callless$arg0$callrequire$branch$if$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L61d
            if (r5 >= r4) goto L582
            r4 = r29
            goto L584
        L582:
            r4 = r30
        L584:
            if (r4 == 0) goto L60c
            r23.release()     // Catch: java.lang.Throwable -> L61d
            r4 = 3
            java.lang.Integer[] r5 = new java.lang.Integer[r4]     // Catch: java.lang.Throwable -> L61d
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r18 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L61d
            int r18 = r18.m1069Int$0$vararg$arg0$calllistOf$$this$callcontains$cond$if$setlockMode$branch$if$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L61d
            java.lang.Integer r18 = java.lang.Integer.valueOf(r18)     // Catch: java.lang.Throwable -> L61d
            r5[r30] = r18     // Catch: java.lang.Throwable -> L61d
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r18 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L61d
            int r18 = r18.m1070Int$1$vararg$arg0$calllistOf$$this$callcontains$cond$if$setlockMode$branch$if$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L61d
            java.lang.Integer r18 = java.lang.Integer.valueOf(r18)     // Catch: java.lang.Throwable -> L61d
            r5[r29] = r18     // Catch: java.lang.Throwable -> L61d
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r18 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L61d
            int r18 = r18.m1071Int$2$vararg$arg0$calllistOf$$this$callcontains$cond$if$setlockMode$branch$if$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L61d
            java.lang.Integer r18 = java.lang.Integer.valueOf(r18)     // Catch: java.lang.Throwable -> L61d
            r19 = 2
            r5[r19] = r18     // Catch: java.lang.Throwable -> L61d
            java.util.List r5 = kotlin.collections.CollectionsKt.listOf(r5)     // Catch: java.lang.Throwable -> L61d
            java.lang.Integer r4 = java.lang.Integer.valueOf(r6)     // Catch: java.lang.Throwable -> L61d
            boolean r4 = r5.contains(r4)     // Catch: java.lang.Throwable -> L61d
            if (r4 == 0) goto L5c2
            r4 = 3
            goto L5c3
        L5c2:
            r4 = 4
        L5c3:
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L5f3
            java.lang.String r5 = r5.m1234String$arg1$callcreateWifiLock$setwifiLock$branch$if$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L5f3
            android.net.wifi.WifiManager$WifiLock r5 = r3.createWifiLock(r4, r5)     // Catch: java.lang.Throwable -> L5f3
            r5.acquire()     // Catch: java.lang.Throwable -> L5d8
            r77 = r5
            r5 = r4
            r4 = r77
            goto L63d
        L5d8:
            r0 = move-exception
            r21 = r2
            r53 = r3
            r23 = r5
            r11 = r8
            r9 = r26
            r10 = r48
            r15 = r56
            r20 = r59
            r7 = r60
            r2 = r0
            r3 = r1
            r8 = r4
            r1 = r49
            r4 = r61
            goto L11bc
        L5f3:
            r0 = move-exception
            r21 = r2
            r53 = r3
            r11 = r8
            r9 = r26
            r10 = r48
            r15 = r56
            r20 = r59
            r7 = r60
            r2 = r0
            r3 = r1
            r8 = r4
            r1 = r49
            r4 = r61
            goto L11bc
        L60c:
            r4 = 0
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L61d
            java.lang.String r5 = r5.m1239String$fun$anonymous$$arg1$callrequire$branch$if$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L61d
            java.lang.IllegalArgumentException r4 = new java.lang.IllegalArgumentException     // Catch: java.lang.Throwable -> L61d
            java.lang.String r5 = r5.toString()     // Catch: java.lang.Throwable -> L61d
            r4.<init>(r5)     // Catch: java.lang.Throwable -> L61d
            throw r4     // Catch: java.lang.Throwable -> L61d
        L61d:
            r0 = move-exception
            r21 = r2
            r53 = r3
            r11 = r8
            r8 = r24
            r9 = r26
            r10 = r48
            r15 = r56
            r20 = r59
            r7 = r60
            r4 = r61
            r2 = r0
            r3 = r1
            r1 = r49
            goto L11bc
        L637:
            r52 = r4
            r4 = r23
            r5 = r24
        L63d:
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r18 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Ld3a
            r53 = r3
            java.lang.String r3 = r18.m1217String$arg0$callrecord$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Ld1b
            r32 = r7
            org.json.JSONObject r7 = new org.json.JSONObject     // Catch: java.lang.Throwable -> Ld1b
            r7.<init>()     // Catch: java.lang.Throwable -> Ld1b
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r18 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Ld1b
            r33 = r12
            java.lang.String r12 = r18.m1188String$arg0$callput$$this$callput$$this$callput$$this$callput$arg1$callrecord$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Ld1b
            org.json.JSONObject r7 = r7.put(r12, r6)     // Catch: java.lang.Throwable -> Ld1b
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r12 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Ld1b
            java.lang.String r12 = r12.m1192String$arg0$callput$$this$callput$$this$callput$arg1$callrecord$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Ld1b
            org.json.JSONObject r7 = r7.put(r12, r5)     // Catch: java.lang.Throwable -> Ld1b
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r12 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Ld1b
            java.lang.String r12 = r12.m1198String$arg0$callput$$this$callput$arg1$callrecord$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Ld1b
            boolean r1 = r4.isHeld()     // Catch: java.lang.Throwable -> Ld1b
            org.json.JSONObject r1 = r7.put(r12, r1)     // Catch: java.lang.Throwable -> Ld1b
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Ld1b
            java.lang.String r7 = r7.m1205String$arg0$callput$arg1$callrecord$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Ld1b
            int r12 = android.os.Process.myUid()     // Catch: java.lang.Throwable -> Ld1b
            org.json.JSONObject r1 = r1.put(r7, r12)     // Catch: java.lang.Throwable -> Ld1b
            java.lang.String r7 = "JSONObject().put(\"trial\"…droid.os.Process.myUid())"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r7)     // Catch: java.lang.Throwable -> Ld1b
            bench$record(r14, r8, r3, r1)     // Catch: java.lang.Throwable -> Ld1b
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r1 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Ld1b
            boolean r1 = r1.m1061Boolean$valpassed$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Ld1b
            r18 = r61
            r19 = r16
            r21 = r49
            r22 = r2
            r23 = r14
            r24 = r8
            vea.raceremote.control.UdpControlClient r3 = bench$connect(r18, r19, r21, r22, r23, r24)     // Catch: java.lang.Throwable -> L9a7 java.lang.AssertionError -> L9be
            long r18 = android.os.SystemClock.elapsedRealtime()     // Catch: java.lang.Throwable -> L9a7 java.lang.AssertionError -> L9be
            long r18 = r18 + r10
        L6a3:
            long r20 = android.os.SystemClock.elapsedRealtime()     // Catch: java.lang.Throwable -> L9a7 java.lang.AssertionError -> L9be
            int r7 = (r20 > r18 ? 1 : (r20 == r18 ? 0 : -1))
            if (r7 >= 0) goto L6ef
            vea.raceremote.control.UdpControlSession$Snapshot r7 = r3.snapshot()     // Catch: java.lang.Throwable -> L6c1 java.lang.AssertionError -> L6d8
            vea.raceremote.control.UdpControlSession$Phase r7 = r7.getPhase()     // Catch: java.lang.Throwable -> L6c1 java.lang.AssertionError -> L6d8
            vea.raceremote.control.UdpControlSession$Phase r12 = vea.raceremote.control.UdpControlSession.Phase.ACTIVE     // Catch: java.lang.Throwable -> L6c1 java.lang.AssertionError -> L6d8
            if (r7 != r12) goto L6ef
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L6c1 java.lang.AssertionError -> L6d8
            long r20 = r7.m1122Long$arg0$callsleep$body$loop$try$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L6c1 java.lang.AssertionError -> L6d8
            android.os.SystemClock.sleep(r20)     // Catch: java.lang.Throwable -> L6c1 java.lang.AssertionError -> L6d8
            goto L6a3
        L6c1:
            r0 = move-exception
            r18 = r0
            r25 = r2
            r21 = r4
            r23 = r5
            r2 = r6
            r19 = r10
            r3 = r28
            r4 = r61
            r10 = r8
            r28 = r15
            r15 = r56
            goto Lbae
        L6d8:
            r0 = move-exception
            r21 = r4
            r23 = r5
            r7 = r6
            r19 = r10
            r11 = r28
            r18 = r32
            r4 = r33
            r3 = r49
            r10 = r56
            r12 = r61
            r5 = r0
            goto L9d3
        L6ef:
            vea.raceremote.control.UdpControlSession$Snapshot r7 = r3.snapshot()     // Catch: java.lang.Throwable -> L9a7 java.lang.AssertionError -> L9be
            vea.raceremote.control.UdpControlSession$Phase r7 = r7.getPhase()     // Catch: java.lang.Throwable -> L9a7 java.lang.AssertionError -> L9be
            vea.raceremote.control.UdpControlSession$Phase r12 = vea.raceremote.control.UdpControlSession.Phase.ACTIVE     // Catch: java.lang.Throwable -> L9a7 java.lang.AssertionError -> L9be
            if (r7 != r12) goto L6fe
            r7 = r29
            goto L700
        L6fe:
            r7 = r30
        L700:
            r1 = r7
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L976 java.lang.AssertionError -> L98f
            java.lang.String r7 = r7.m1220String$arg0$callrecord$try$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L976 java.lang.AssertionError -> L98f
            org.json.JSONObject r12 = new org.json.JSONObject     // Catch: java.lang.Throwable -> L976 java.lang.AssertionError -> L98f
            r12.<init>()     // Catch: java.lang.Throwable -> L976 java.lang.AssertionError -> L98f
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r20 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L976 java.lang.AssertionError -> L98f
            r21 = r4
            java.lang.String r4 = r20.m1189String$arg0$callput$$this$callput$$this$callput$$this$callput$arg1$callrecord$try$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L948 java.lang.AssertionError -> L95f
            org.json.JSONObject r4 = r12.put(r4, r6)     // Catch: java.lang.Throwable -> L948 java.lang.AssertionError -> L95f
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r12 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L948 java.lang.AssertionError -> L95f
            java.lang.String r12 = r12.m1193String$arg0$callput$$this$callput$$this$callput$arg1$callrecord$try$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L948 java.lang.AssertionError -> L95f
            org.json.JSONObject r4 = r4.put(r12, r1)     // Catch: java.lang.Throwable -> L948 java.lang.AssertionError -> L95f
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r12 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L948 java.lang.AssertionError -> L95f
            java.lang.String r12 = r12.m1199String$arg0$callput$$this$callput$arg1$callrecord$try$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L948 java.lang.AssertionError -> L95f
            org.json.JSONObject r4 = r4.put(r12, r5)     // Catch: java.lang.Throwable -> L948 java.lang.AssertionError -> L95f
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r12 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L948 java.lang.AssertionError -> L95f
            java.lang.String r12 = r12.m1206String$arg0$callput$arg1$callrecord$try$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L948 java.lang.AssertionError -> L95f
            vea.raceremote.control.UdpControlSession$Snapshot r20 = r3.snapshot()     // Catch: java.lang.Throwable -> L948 java.lang.AssertionError -> L95f
            r22 = r1
            java.lang.String r1 = r20.toString()     // Catch: java.lang.Throwable -> L91a java.lang.AssertionError -> L931
            org.json.JSONObject r1 = r4.put(r12, r1)     // Catch: java.lang.Throwable -> L91a java.lang.AssertionError -> L931
            java.lang.String r4 = "JSONObject().put(\"trial\"… c.snapshot().toString())"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r4)     // Catch: java.lang.Throwable -> L91a java.lang.AssertionError -> L931
            bench$record(r14, r8, r7, r1)     // Catch: java.lang.Throwable -> L91a java.lang.AssertionError -> L931
            r3 = r49
            java.lang.Object r1 = r3.element     // Catch: java.lang.Throwable -> L8fe
            vea.raceremote.control.UdpControlClient r1 = (vea.raceremote.control.UdpControlClient) r1     // Catch: java.lang.Throwable -> L8fe
            if (r1 == 0) goto L76f
            r1.close()     // Catch: java.lang.Throwable -> L756
            kotlin.Unit r1 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L756
            goto L76f
        L756:
            r0 = move-exception
            r1 = r3
            r11 = r8
            r23 = r21
            r9 = r26
            r10 = r48
            r15 = r56
            r20 = r59
            r7 = r60
            r4 = r61
            r3 = r79
            r21 = r2
            r8 = r5
            r2 = r0
            goto L11bc
        L76f:
            r1 = 0
            r3.element = r1     // Catch: java.lang.Throwable -> L8fe
            vea.raceremote.UdpControlDeviceBenchTest$bench$6$2 r1 = vea.raceremote.UdpControlDeviceBenchTest$bench$6$2.INSTANCE     // Catch: java.lang.Throwable -> L8fe
            r12 = r1
            kotlin.jvm.functions.Function1 r12 = (kotlin.jvm.functions.Function1) r12     // Catch: java.lang.Throwable -> L8fe
            r4 = r5
            r5 = r56
            r1 = r6
            r6 = r61
            r18 = r32
            r7 = r60
            r62 = r8
            r8 = r13
            r9 = r14
            r19 = r10
            r10 = r62
            r23 = r4
            r4 = r33
            bench$awaitStatus(r5, r6, r7, r8, r9, r10, r12)     // Catch: java.lang.Throwable -> L8e3
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L8e3
            java.lang.String r5 = r5.m1179String$arg0$callgetString$arg0$callEQEQ$cond$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L8e3
            java.lang.String r5 = r13.getString(r5)     // Catch: java.lang.Throwable -> L8e3
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L8e3
            java.lang.String r6 = r6.m1225String$arg1$callEQEQ$cond$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L8e3
            boolean r5 = kotlin.jvm.internal.Intrinsics.areEqual(r5, r6)     // Catch: java.lang.Throwable -> L8e3
            if (r5 == 0) goto L8c7
            okhttp3.Request$Builder r5 = new okhttp3.Request$Builder     // Catch: java.lang.Throwable -> L8e3
            r5.<init>()     // Catch: java.lang.Throwable -> L8e3
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L8e3
            r6.<init>()     // Catch: java.lang.Throwable -> L8e3
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L8e3
            java.lang.String r7 = r7.m1134String$0$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$valtrace$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L8e3
            java.lang.StringBuilder r6 = r6.append(r7)     // Catch: java.lang.Throwable -> L8e3
            r12 = r61
            java.lang.StringBuilder r6 = r6.append(r12)     // Catch: java.lang.Throwable -> L8ad
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L8ad
            java.lang.String r7 = r7.m1137String$2$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$valtrace$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L8ad
            java.lang.StringBuilder r6 = r6.append(r7)     // Catch: java.lang.Throwable -> L8ad
            java.lang.String r6 = r6.toString()     // Catch: java.lang.Throwable -> L8ad
            okhttp3.Request$Builder r5 = r5.url(r6)     // Catch: java.lang.Throwable -> L8ad
            okhttp3.Request r5 = r5.build()     // Catch: java.lang.Throwable -> L8ad
            r10 = r56
            okhttp3.Call r5 = r10.newCall(r5)     // Catch: java.lang.Throwable -> L894
            okhttp3.Response r5 = r5.execute()     // Catch: java.lang.Throwable -> L894
            java.io.Closeable r5 = (java.io.Closeable) r5     // Catch: java.lang.Throwable -> L894
            r6 = r5
            okhttp3.Response r6 = (okhttp3.Response) r6     // Catch: java.lang.Throwable -> L887
            r7 = 0
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r8 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L887
            int r8 = r8.m1074Int$arg0$callassertEquals$fun$anonymous$$arg0$calluse$valtrace$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L887
            java.lang.Integer r8 = java.lang.Integer.valueOf(r8)     // Catch: java.lang.Throwable -> L887
            int r9 = r6.code()     // Catch: java.lang.Throwable -> L887
            java.lang.Integer r9 = java.lang.Integer.valueOf(r9)     // Catch: java.lang.Throwable -> L887
            org.junit.Assert.assertEquals(r8, r9)     // Catch: java.lang.Throwable -> L887
            org.json.JSONObject r8 = new org.json.JSONObject     // Catch: java.lang.Throwable -> L887
            okhttp3.ResponseBody r9 = r6.body()     // Catch: java.lang.Throwable -> L887
            if (r9 == 0) goto L871
            java.lang.String r9 = r9.string()     // Catch: java.lang.Throwable -> L86a
            r8.<init>(r9)     // Catch: java.lang.Throwable -> L86a
            r6 = 0
            kotlin.io.CloseableKt.closeFinally(r5, r6)     // Catch: java.lang.Throwable -> L894
            r5 = r8
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L894
            int r6 = r6.m1073Int$arg0$callassertEquals$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L894
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch: java.lang.Throwable -> L894
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L894
            java.lang.String r7 = r7.m1166String$arg0$callgetInt$arg1$callassertEquals$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L894
            int r7 = r5.getInt(r7)     // Catch: java.lang.Throwable -> L894
            java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch: java.lang.Throwable -> L894
            org.junit.Assert.assertEquals(r6, r7)     // Catch: java.lang.Throwable -> L894
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L894
            java.lang.String r6 = r6.m1143String$arg0$callassertEquals1$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L894
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L894
            java.lang.String r7 = r7.m1183String$arg0$callgetString$arg1$callassertEquals1$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L894
            java.lang.String r7 = r5.getString(r7)     // Catch: java.lang.Throwable -> L894
            org.junit.Assert.assertEquals(r6, r7)     // Catch: java.lang.Throwable -> L894
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L894
            java.lang.String r6 = r6.m1209String$arg0$callrecord$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L894
            org.json.JSONObject r7 = new org.json.JSONObject     // Catch: java.lang.Throwable -> L894
            r7.<init>()     // Catch: java.lang.Throwable -> L894
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r8 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L894
            java.lang.String r8 = r8.m1196String$arg0$callput$$this$callput$arg1$callrecord$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L894
            org.json.JSONObject r7 = r7.put(r8, r1)     // Catch: java.lang.Throwable -> L894
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r8 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L894
            java.lang.String r8 = r8.m1203String$arg0$callput$arg1$callrecord$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L894
            org.json.JSONObject r7 = r7.put(r8, r5)     // Catch: java.lang.Throwable -> L894
            r11 = r28
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r7, r11)     // Catch: java.lang.Throwable -> L894
            r8 = r62
            bench$record(r14, r8, r6, r7)     // Catch: java.lang.Throwable -> L9ee
            r24 = r1
            goto L8d1
        L86a:
            r0 = move-exception
            r8 = r62
            r24 = r1
            r1 = r0
            goto L88d
        L871:
            r8 = r62
            java.lang.IllegalArgumentException r11 = new java.lang.IllegalArgumentException     // Catch: java.lang.Throwable -> L882
            r24 = r1
            java.lang.String r1 = r27.toString()     // Catch: java.lang.Throwable -> L87f
            r11.<init>(r1)     // Catch: java.lang.Throwable -> L87f
            throw r11     // Catch: java.lang.Throwable -> L87f
        L87f:
            r0 = move-exception
            r1 = r0
            goto L88d
        L882:
            r0 = move-exception
            r24 = r1
            r1 = r0
            goto L88d
        L887:
            r0 = move-exception
            r24 = r1
            r8 = r62
            r1 = r0
        L88d:
            throw r1     // Catch: java.lang.Throwable -> L88e
        L88e:
            r0 = move-exception
            r6 = r0
            kotlin.io.CloseableKt.closeFinally(r5, r1)     // Catch: java.lang.Throwable -> L9ee
            throw r6     // Catch: java.lang.Throwable -> L9ee
        L894:
            r0 = move-exception
            r1 = r3
            r15 = r10
            r4 = r12
            r8 = r23
            r9 = r26
            r10 = r48
            r20 = r59
            r7 = r60
            r11 = r62
            r3 = r79
            r23 = r21
            r21 = r2
            r2 = r0
            goto L11bc
        L8ad:
            r0 = move-exception
            r1 = r3
            r4 = r12
            r8 = r23
            r9 = r26
            r10 = r48
            r15 = r56
            r20 = r59
            r7 = r60
            r11 = r62
            r3 = r79
            r23 = r21
            r21 = r2
            r2 = r0
            goto L11bc
        L8c7:
            r24 = r1
            r11 = r28
            r10 = r56
            r12 = r61
            r8 = r62
        L8d1:
            r25 = r2
            r49 = r3
            r33 = r4
            r3 = r11
            r4 = r12
            r28 = r15
            r1 = r22
            r2 = r24
            r15 = r10
            r10 = r8
            goto Lb16
        L8e3:
            r0 = move-exception
            r1 = r3
            r8 = r23
            r9 = r26
            r10 = r48
            r15 = r56
            r20 = r59
            r7 = r60
            r4 = r61
            r11 = r62
            r3 = r79
            r23 = r21
            r21 = r2
            r2 = r0
            goto L11bc
        L8fe:
            r0 = move-exception
            r23 = r5
            r1 = r3
            r11 = r8
            r8 = r23
            r9 = r26
            r10 = r48
            r15 = r56
            r20 = r59
            r7 = r60
            r4 = r61
            r3 = r79
            r23 = r21
            r21 = r2
            r2 = r0
            goto L11bc
        L91a:
            r0 = move-exception
            r23 = r5
            r19 = r10
            r18 = r0
            r25 = r2
            r2 = r6
            r10 = r8
            r1 = r22
            r3 = r28
            r4 = r61
            r28 = r15
            r15 = r56
            goto Lbae
        L931:
            r0 = move-exception
            r23 = r5
            r19 = r10
            r11 = r28
            r18 = r32
            r4 = r33
            r3 = r49
            r10 = r56
            r12 = r61
            r5 = r0
            r7 = r6
            r1 = r22
            goto L9d3
        L948:
            r0 = move-exception
            r22 = r1
            r23 = r5
            r19 = r10
            r18 = r0
            r25 = r2
            r2 = r6
            r10 = r8
            r3 = r28
            r4 = r61
            r28 = r15
            r15 = r56
            goto Lbae
        L95f:
            r0 = move-exception
            r22 = r1
            r23 = r5
            r19 = r10
            r11 = r28
            r18 = r32
            r4 = r33
            r3 = r49
            r10 = r56
            r12 = r61
            r5 = r0
            r7 = r6
            goto L9d3
        L976:
            r0 = move-exception
            r22 = r1
            r21 = r4
            r23 = r5
            r19 = r10
            r18 = r0
            r25 = r2
            r2 = r6
            r10 = r8
            r3 = r28
            r4 = r61
            r28 = r15
            r15 = r56
            goto Lbae
        L98f:
            r0 = move-exception
            r22 = r1
            r21 = r4
            r23 = r5
            r19 = r10
            r11 = r28
            r18 = r32
            r4 = r33
            r3 = r49
            r10 = r56
            r12 = r61
            r5 = r0
            r7 = r6
            goto L9d3
        L9a7:
            r0 = move-exception
            r21 = r4
            r23 = r5
            r19 = r10
            r18 = r0
            r25 = r2
            r2 = r6
            r10 = r8
            r3 = r28
            r4 = r61
            r28 = r15
            r15 = r56
            goto Lbae
        L9be:
            r0 = move-exception
            r21 = r4
            r23 = r5
            r7 = r6
            r19 = r10
            r11 = r28
            r18 = r32
            r4 = r33
            r3 = r49
            r10 = r56
            r12 = r61
            r5 = r0
        L9d3:
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lb9c
            java.lang.String r6 = r6.m1213String$arg0$callrecord$catch$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lb9c
            r22 = r1
            java.lang.String r1 = r5.toString()     // Catch: java.lang.Throwable -> Lb89
            bench$record(r14, r8, r6, r1)     // Catch: java.lang.Throwable -> Lb89
            java.lang.Object r1 = r3.element     // Catch: java.lang.Throwable -> Lb71
            vea.raceremote.control.UdpControlClient r1 = (vea.raceremote.control.UdpControlClient) r1     // Catch: java.lang.Throwable -> Lb71
            if (r1 == 0) goto La06
            r1.close()     // Catch: java.lang.Throwable -> L9ee
            kotlin.Unit r1 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L9ee
            goto La06
        L9ee:
            r0 = move-exception
            r1 = r3
            r15 = r10
            r4 = r12
            r10 = r48
            r20 = r59
            r7 = r60
            r3 = r79
            r11 = r8
            r8 = r23
            r9 = r26
            r23 = r21
            r21 = r2
            r2 = r0
            goto L11bc
        La06:
            r1 = 0
            r3.element = r1     // Catch: java.lang.Throwable -> Lb71
            vea.raceremote.UdpControlDeviceBenchTest$bench$6$2 r1 = vea.raceremote.UdpControlDeviceBenchTest$bench$6$2.INSTANCE     // Catch: java.lang.Throwable -> Lb71
            kotlin.jvm.functions.Function1 r1 = (kotlin.jvm.functions.Function1) r1     // Catch: java.lang.Throwable -> Lb71
            r5 = r10
            r6 = r12
            r25 = r2
            r2 = r7
            r7 = r60
            r62 = r8
            r8 = r13
            r9 = r14
            r49 = r3
            r3 = r11
            r28 = r15
            r15 = r10
            r10 = r62
            r33 = r4
            r4 = r12
            r12 = r1
            bench$awaitStatus(r5, r6, r7, r8, r9, r10, r12)     // Catch: java.lang.Throwable -> Lb59
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r1 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lb59
            java.lang.String r1 = r1.m1179String$arg0$callgetString$arg0$callEQEQ$cond$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lb59
            java.lang.String r1 = r13.getString(r1)     // Catch: java.lang.Throwable -> Lb59
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lb59
            java.lang.String r5 = r5.m1225String$arg1$callEQEQ$cond$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lb59
            boolean r1 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r5)     // Catch: java.lang.Throwable -> Lb59
            if (r1 == 0) goto Lb12
            okhttp3.Request$Builder r1 = new okhttp3.Request$Builder     // Catch: java.lang.Throwable -> Lb59
            r1.<init>()     // Catch: java.lang.Throwable -> Lb59
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> Lb59
            r5.<init>()     // Catch: java.lang.Throwable -> Lb59
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lb59
            java.lang.String r6 = r6.m1134String$0$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$valtrace$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lb59
            java.lang.StringBuilder r5 = r5.append(r6)     // Catch: java.lang.Throwable -> Lb59
            java.lang.StringBuilder r5 = r5.append(r4)     // Catch: java.lang.Throwable -> Lb59
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lb59
            java.lang.String r6 = r6.m1137String$2$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$valtrace$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lb59
            java.lang.StringBuilder r5 = r5.append(r6)     // Catch: java.lang.Throwable -> Lb59
            java.lang.String r5 = r5.toString()     // Catch: java.lang.Throwable -> Lb59
            okhttp3.Request$Builder r1 = r1.url(r5)     // Catch: java.lang.Throwable -> Lb59
            okhttp3.Request r1 = r1.build()     // Catch: java.lang.Throwable -> Lb59
            okhttp3.Call r1 = r15.newCall(r1)     // Catch: java.lang.Throwable -> Lb59
            okhttp3.Response r1 = r1.execute()     // Catch: java.lang.Throwable -> Lb59
            java.io.Closeable r1 = (java.io.Closeable) r1     // Catch: java.lang.Throwable -> Lb59
            r5 = r1
            okhttp3.Response r5 = (okhttp3.Response) r5     // Catch: java.lang.Throwable -> Lb07
            r6 = 0
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lb07
            int r7 = r7.m1074Int$arg0$callassertEquals$fun$anonymous$$arg0$calluse$valtrace$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lb07
            java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch: java.lang.Throwable -> Lb07
            int r8 = r5.code()     // Catch: java.lang.Throwable -> Lb07
            java.lang.Integer r8 = java.lang.Integer.valueOf(r8)     // Catch: java.lang.Throwable -> Lb07
            org.junit.Assert.assertEquals(r7, r8)     // Catch: java.lang.Throwable -> Lb07
            org.json.JSONObject r7 = new org.json.JSONObject     // Catch: java.lang.Throwable -> Lb07
            okhttp3.ResponseBody r8 = r5.body()     // Catch: java.lang.Throwable -> Lb07
            if (r8 == 0) goto Laf8
            java.lang.String r8 = r8.string()     // Catch: java.lang.Throwable -> Lb07
            r7.<init>(r8)     // Catch: java.lang.Throwable -> Lb07
            r5 = 0
            kotlin.io.CloseableKt.closeFinally(r1, r5)     // Catch: java.lang.Throwable -> Lb59
            r1 = r7
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lb59
            int r5 = r5.m1073Int$arg0$callassertEquals$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lb59
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)     // Catch: java.lang.Throwable -> Lb59
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lb59
            java.lang.String r6 = r6.m1166String$arg0$callgetInt$arg1$callassertEquals$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lb59
            int r6 = r1.getInt(r6)     // Catch: java.lang.Throwable -> Lb59
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch: java.lang.Throwable -> Lb59
            org.junit.Assert.assertEquals(r5, r6)     // Catch: java.lang.Throwable -> Lb59
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lb59
            java.lang.String r5 = r5.m1143String$arg0$callassertEquals1$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lb59
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lb59
            java.lang.String r6 = r6.m1183String$arg0$callgetString$arg1$callassertEquals1$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lb59
            java.lang.String r6 = r1.getString(r6)     // Catch: java.lang.Throwable -> Lb59
            org.junit.Assert.assertEquals(r5, r6)     // Catch: java.lang.Throwable -> Lb59
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lb59
            java.lang.String r5 = r5.m1209String$arg0$callrecord$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lb59
            org.json.JSONObject r6 = new org.json.JSONObject     // Catch: java.lang.Throwable -> Lb59
            r6.<init>()     // Catch: java.lang.Throwable -> Lb59
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lb59
            java.lang.String r7 = r7.m1196String$arg0$callput$$this$callput$arg1$callrecord$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lb59
            org.json.JSONObject r6 = r6.put(r7, r2)     // Catch: java.lang.Throwable -> Lb59
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lb59
            java.lang.String r7 = r7.m1203String$arg0$callput$arg1$callrecord$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lb59
            org.json.JSONObject r6 = r6.put(r7, r1)     // Catch: java.lang.Throwable -> Lb59
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r6, r3)     // Catch: java.lang.Throwable -> Lb59
            r10 = r62
            bench$record(r14, r10, r5, r6)     // Catch: java.lang.Throwable -> Lb42
            goto Lb14
        Laf8:
            r10 = r62
            java.lang.IllegalArgumentException r3 = new java.lang.IllegalArgumentException     // Catch: java.lang.Throwable -> Lb04
            java.lang.String r7 = r27.toString()     // Catch: java.lang.Throwable -> Lb04
            r3.<init>(r7)     // Catch: java.lang.Throwable -> Lb04
            throw r3     // Catch: java.lang.Throwable -> Lb04
        Lb04:
            r0 = move-exception
            r3 = r0
            goto Lb0b
        Lb07:
            r0 = move-exception
            r10 = r62
            r3 = r0
        Lb0b:
            throw r3     // Catch: java.lang.Throwable -> Lb0c
        Lb0c:
            r0 = move-exception
            r5 = r0
            kotlin.io.CloseableKt.closeFinally(r1, r3)     // Catch: java.lang.Throwable -> Lb42
            throw r5     // Catch: java.lang.Throwable -> Lb42
        Lb12:
            r10 = r62
        Lb14:
            r1 = r22
        Lb16:
            if (r1 != 0) goto Lb1b
            int r12 = r33 + 1
            goto Lb1d
        Lb1b:
            r12 = r33
        Lb1d:
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lb42
            long r5 = r5.m1124Long$arg0$callsleep$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lb42
            android.os.SystemClock.sleep(r5)     // Catch: java.lang.Throwable -> Lb42
            int r7 = r18 + 1
            r1 = r79
            r61 = r4
            r8 = r10
            r56 = r15
            r10 = r19
            r24 = r23
            r2 = r25
            r15 = r28
            r4 = r52
            r28 = r3
            r23 = r21
            r3 = r53
            goto L562
        Lb42:
            r0 = move-exception
            r3 = r79
            r2 = r0
            r11 = r10
            r8 = r23
            r9 = r26
            r10 = r48
            r1 = r49
            r20 = r59
            r7 = r60
            r23 = r21
            r21 = r25
            goto L11bc
        Lb59:
            r0 = move-exception
            r3 = r79
            r2 = r0
            r8 = r23
            r9 = r26
            r10 = r48
            r1 = r49
            r20 = r59
            r7 = r60
            r11 = r62
            r23 = r21
            r21 = r25
            goto L11bc
        Lb71:
            r0 = move-exception
            r15 = r10
            r4 = r12
            r1 = r3
            r11 = r8
            r8 = r23
            r9 = r26
            r10 = r48
            r20 = r59
            r7 = r60
            r3 = r79
            r23 = r21
            r21 = r2
            r2 = r0
            goto L11bc
        Lb89:
            r0 = move-exception
            r25 = r2
            r49 = r3
            r33 = r4
            r2 = r7
            r3 = r11
            r4 = r12
            r28 = r15
            r15 = r10
            r10 = r8
            r18 = r0
            r1 = r22
            goto Lbae
        Lb9c:
            r0 = move-exception
            r22 = r1
            r25 = r2
            r49 = r3
            r33 = r4
            r2 = r7
            r3 = r11
            r4 = r12
            r28 = r15
            r15 = r10
            r10 = r8
            r18 = r0
        Lbae:
            r12 = r49
            java.lang.Object r5 = r12.element     // Catch: java.lang.Throwable -> Ld05
            vea.raceremote.control.UdpControlClient r5 = (vea.raceremote.control.UdpControlClient) r5     // Catch: java.lang.Throwable -> Ld05
            if (r5 == 0) goto Lbd2
            r5.close()     // Catch: java.lang.Throwable -> Lbbc
            kotlin.Unit r5 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> Lbbc
            goto Lbd2
        Lbbc:
            r0 = move-exception
            r3 = r79
            r2 = r0
            r1 = r12
            r8 = r23
            r9 = r26
            r20 = r59
            r7 = r60
            r11 = r10
            r23 = r21
            r21 = r25
            r10 = r48
            goto L11bc
        Lbd2:
            r5 = 0
            r12.element = r5     // Catch: java.lang.Throwable -> Ld05
            vea.raceremote.UdpControlDeviceBenchTest$bench$6$2 r5 = vea.raceremote.UdpControlDeviceBenchTest$bench$6$2.INSTANCE     // Catch: java.lang.Throwable -> Ld05
            r22 = r5
            kotlin.jvm.functions.Function1 r22 = (kotlin.jvm.functions.Function1) r22     // Catch: java.lang.Throwable -> Ld05
            r5 = r15
            r6 = r4
            r7 = r60
            r8 = r13
            r9 = r14
            r62 = r10
            r24 = r1
            r1 = r12
            r12 = r22
            bench$awaitStatus(r5, r6, r7, r8, r9, r10, r12)     // Catch: java.lang.Throwable -> Lcef
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lcef
            java.lang.String r5 = r5.m1179String$arg0$callgetString$arg0$callEQEQ$cond$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lcef
            java.lang.String r5 = r13.getString(r5)     // Catch: java.lang.Throwable -> Lcef
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lcef
            java.lang.String r6 = r6.m1225String$arg1$callEQEQ$cond$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lcef
            boolean r5 = kotlin.jvm.internal.Intrinsics.areEqual(r5, r6)     // Catch: java.lang.Throwable -> Lcef
            if (r5 == 0) goto Lcd6
            okhttp3.Request$Builder r5 = new okhttp3.Request$Builder     // Catch: java.lang.Throwable -> Lcef
            r5.<init>()     // Catch: java.lang.Throwable -> Lcef
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> Lcef
            r6.<init>()     // Catch: java.lang.Throwable -> Lcef
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lcef
            java.lang.String r7 = r7.m1134String$0$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$valtrace$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lcef
            java.lang.StringBuilder r6 = r6.append(r7)     // Catch: java.lang.Throwable -> Lcef
            java.lang.StringBuilder r6 = r6.append(r4)     // Catch: java.lang.Throwable -> Lcef
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lcef
            java.lang.String r7 = r7.m1137String$2$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$valtrace$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lcef
            java.lang.StringBuilder r6 = r6.append(r7)     // Catch: java.lang.Throwable -> Lcef
            java.lang.String r6 = r6.toString()     // Catch: java.lang.Throwable -> Lcef
            okhttp3.Request$Builder r5 = r5.url(r6)     // Catch: java.lang.Throwable -> Lcef
            okhttp3.Request r5 = r5.build()     // Catch: java.lang.Throwable -> Lcef
            okhttp3.Call r5 = r15.newCall(r5)     // Catch: java.lang.Throwable -> Lcef
            okhttp3.Response r5 = r5.execute()     // Catch: java.lang.Throwable -> Lcef
            java.io.Closeable r5 = (java.io.Closeable) r5     // Catch: java.lang.Throwable -> Lcef
            r6 = r5
            okhttp3.Response r6 = (okhttp3.Response) r6     // Catch: java.lang.Throwable -> Lccb
            r7 = 0
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r8 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lccb
            int r8 = r8.m1074Int$arg0$callassertEquals$fun$anonymous$$arg0$calluse$valtrace$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lccb
            java.lang.Integer r8 = java.lang.Integer.valueOf(r8)     // Catch: java.lang.Throwable -> Lccb
            int r9 = r6.code()     // Catch: java.lang.Throwable -> Lccb
            java.lang.Integer r9 = java.lang.Integer.valueOf(r9)     // Catch: java.lang.Throwable -> Lccb
            org.junit.Assert.assertEquals(r8, r9)     // Catch: java.lang.Throwable -> Lccb
            org.json.JSONObject r8 = new org.json.JSONObject     // Catch: java.lang.Throwable -> Lccb
            okhttp3.ResponseBody r9 = r6.body()     // Catch: java.lang.Throwable -> Lccb
            if (r9 != 0) goto Lc69
            java.lang.IllegalArgumentException r3 = new java.lang.IllegalArgumentException     // Catch: java.lang.Throwable -> Lc64
            java.lang.String r8 = r27.toString()     // Catch: java.lang.Throwable -> Lc64
            r3.<init>(r8)     // Catch: java.lang.Throwable -> Lc64
            throw r3     // Catch: java.lang.Throwable -> Lc64
        Lc64:
            r0 = move-exception
            r3 = r0
            r10 = r62
            goto Lccf
        Lc69:
            java.lang.String r9 = r9.string()     // Catch: java.lang.Throwable -> Lccb
            r8.<init>(r9)     // Catch: java.lang.Throwable -> Lccb
            r6 = 0
            kotlin.io.CloseableKt.closeFinally(r5, r6)     // Catch: java.lang.Throwable -> Lcef
            r5 = r8
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lcef
            int r6 = r6.m1073Int$arg0$callassertEquals$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lcef
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch: java.lang.Throwable -> Lcef
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lcef
            java.lang.String r7 = r7.m1166String$arg0$callgetInt$arg1$callassertEquals$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lcef
            int r7 = r5.getInt(r7)     // Catch: java.lang.Throwable -> Lcef
            java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch: java.lang.Throwable -> Lcef
            org.junit.Assert.assertEquals(r6, r7)     // Catch: java.lang.Throwable -> Lcef
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lcef
            java.lang.String r6 = r6.m1143String$arg0$callassertEquals1$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lcef
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r7 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lcef
            java.lang.String r7 = r7.m1183String$arg0$callgetString$arg1$callassertEquals1$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lcef
            java.lang.String r7 = r5.getString(r7)     // Catch: java.lang.Throwable -> Lcef
            org.junit.Assert.assertEquals(r6, r7)     // Catch: java.lang.Throwable -> Lcef
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lcef
            java.lang.String r6 = r6.m1209String$arg0$callrecord$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lcef
            org.json.JSONObject r7 = new org.json.JSONObject     // Catch: java.lang.Throwable -> Lcef
            r7.<init>()     // Catch: java.lang.Throwable -> Lcef
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r8 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lcef
            java.lang.String r8 = r8.m1196String$arg0$callput$$this$callput$arg1$callrecord$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lcef
            org.json.JSONObject r7 = r7.put(r8, r2)     // Catch: java.lang.Throwable -> Lcef
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r8 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lcef
            java.lang.String r8 = r8.m1203String$arg0$callput$arg1$callrecord$branch$if$finally$fun$anonymous$$arg1$callrepeat$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lcef
            org.json.JSONObject r7 = r7.put(r8, r5)     // Catch: java.lang.Throwable -> Lcef
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r7, r3)     // Catch: java.lang.Throwable -> Lcef
            r10 = r62
            bench$record(r14, r10, r6, r7)     // Catch: java.lang.Throwable -> Lcda
            goto Lcd8
        Lccb:
            r0 = move-exception
            r10 = r62
            r3 = r0
        Lccf:
            throw r3     // Catch: java.lang.Throwable -> Lcd0
        Lcd0:
            r0 = move-exception
            r6 = r0
            kotlin.io.CloseableKt.closeFinally(r5, r3)     // Catch: java.lang.Throwable -> Lcda
            throw r6     // Catch: java.lang.Throwable -> Lcda
        Lcd6:
            r10 = r62
        Lcd8:
            throw r18     // Catch: java.lang.Throwable -> Lcda
        Lcda:
            r0 = move-exception
            r3 = r79
            r2 = r0
            r11 = r10
            r8 = r23
            r9 = r26
            r10 = r48
            r20 = r59
            r7 = r60
            r23 = r21
            r21 = r25
            goto L11bc
        Lcef:
            r0 = move-exception
            r3 = r79
            r2 = r0
            r8 = r23
            r9 = r26
            r10 = r48
            r20 = r59
            r7 = r60
            r11 = r62
            r23 = r21
            r21 = r25
            goto L11bc
        Ld05:
            r0 = move-exception
            r1 = r12
            r3 = r79
            r2 = r0
            r11 = r10
            r8 = r23
            r9 = r26
            r10 = r48
            r20 = r59
            r7 = r60
            r23 = r21
            r21 = r25
            goto L11bc
        Ld1b:
            r0 = move-exception
            r21 = r4
            r23 = r5
            r1 = r49
            r15 = r56
            r4 = r61
            r3 = r79
            r11 = r8
            r8 = r23
            r9 = r26
            r10 = r48
            r20 = r59
            r7 = r60
            r23 = r21
            r21 = r2
            r2 = r0
            goto L11bc
        Ld3a:
            r0 = move-exception
            r53 = r3
            r21 = r4
            r23 = r5
            r1 = r49
            r15 = r56
            r4 = r61
            r3 = r79
            r11 = r8
            r8 = r23
            r9 = r26
            r10 = r48
            r20 = r59
            r7 = r60
            r23 = r21
            r21 = r2
            r2 = r0
            goto L11bc
        Ld5b:
            r25 = r2
            r53 = r3
            r52 = r4
            r19 = r10
            r33 = r12
            r28 = r15
            r1 = r49
            r15 = r56
            r4 = r61
            r10 = r8
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Ldba
            java.lang.String r2 = r2.m1223String$arg0$callrecord1$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Ldba
            org.json.JSONObject r3 = new org.json.JSONObject     // Catch: java.lang.Throwable -> Ldba
            r3.<init>()     // Catch: java.lang.Throwable -> Ldba
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Ldba
            java.lang.String r5 = r5.m1200String$arg0$callput$$this$callput$arg1$callrecord1$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Ldba
            r6 = r28
            org.json.JSONObject r3 = r3.put(r5, r6)     // Catch: java.lang.Throwable -> Ldba
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Ldba
            java.lang.String r5 = r5.m1207String$arg0$callput$arg1$callrecord1$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Ldba
            r12 = r33
            org.json.JSONObject r3 = r3.put(r5, r12)     // Catch: java.lang.Throwable -> Ldba
            java.lang.String r5 = "JSONObject().put(\"sessio…put(\"failures\", failures)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r3, r5)     // Catch: java.lang.Throwable -> Ldba
            bench$record(r14, r10, r2, r3)     // Catch: java.lang.Throwable -> Ldba
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Ldba
            java.lang.String r2 = r2.m1141String$arg0$callassertEquals$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Ldba
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r3 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Ldba
            int r3 = r3.m1103Int$arg1$callassertEquals$branch1$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Ldba
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch: java.lang.Throwable -> Ldba
            java.lang.Integer r5 = java.lang.Integer.valueOf(r12)     // Catch: java.lang.Throwable -> Ldba
            org.junit.Assert.assertEquals(r2, r3, r5)     // Catch: java.lang.Throwable -> Ldba
            r3 = r79
            r62 = r10
            r8 = r24
            r21 = r25
            goto Lfcd
        Ldba:
            r0 = move-exception
            r3 = r79
            r2 = r0
            r11 = r10
            r8 = r24
            r21 = r25
            r9 = r26
            r10 = r48
            r20 = r59
            r7 = r60
            goto L11bc
        Ldcd:
            r0 = move-exception
            r53 = r3
            r1 = r49
            r15 = r56
            r4 = r61
            r3 = r79
            r21 = r2
            r11 = r8
            r8 = r24
            r9 = r26
            r10 = r48
            r20 = r59
            r7 = r60
            r2 = r0
            goto L11bc
        Lde8:
            r0 = move-exception
            r1 = r49
            r10 = r52
            r15 = r56
            r4 = r61
            r53 = r3
            r3 = r79
            r21 = r2
            r11 = r10
            r8 = r24
            r9 = r26
            r10 = r48
            r20 = r59
            r7 = r60
            r2 = r0
            goto L11bc
        Le05:
            r25 = r2
            r1 = r49
            r10 = r52
            r15 = r56
            r53 = r3
            r52 = r4
            r4 = r61
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L10b0
            java.lang.String r2 = r2.m1231String$arg1$callEQEQ$cond2$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L10b0
            r3 = r79
            boolean r2 = kotlin.jvm.internal.Intrinsics.areEqual(r3, r2)     // Catch: java.lang.Throwable -> L10ae
            if (r2 == 0) goto Lfc7
            java.net.DatagramSocket r2 = new java.net.DatagramSocket     // Catch: java.lang.Throwable -> Lfb6
            r2.<init>()     // Catch: java.lang.Throwable -> Lfb6
            java.io.Closeable r2 = (java.io.Closeable) r2     // Catch: java.lang.Throwable -> Lfb6
            r5 = r2
            java.net.DatagramSocket r5 = (java.net.DatagramSocket) r5     // Catch: java.lang.Throwable -> Lf99
            r12 = r5
            r18 = 0
            r9 = r25
            r9.bindSocket(r12)     // Catch: java.lang.Throwable -> Lf92
            java.net.InetAddress r5 = java.net.InetAddress.getByName(r4)     // Catch: java.lang.Throwable -> Lf92
            r6 = 3334(0xd06, float:4.672E-42)
            r12.connect(r5, r6)     // Catch: java.lang.Throwable -> Lf92
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lf92
            int r5 = r5.m1089Int$arg0$callsetSoTimeout$fun$anonymous$$arg0$calluse$branch2$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lf92
            r12.setSoTimeout(r5)     // Catch: java.lang.Throwable -> Lf92
            vea.raceremote.control.UdpControlPacket r5 = new vea.raceremote.control.UdpControlPacket     // Catch: java.lang.Throwable -> Lf92
            r28 = 0
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lf92
            long r29 = r6.m1125Long$arg1$call$init$$valopen$fun$anonymous$$arg0$calluse$branch2$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lf92
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lf92
            long r31 = r6.m1126Long$arg2$call$init$$valopen$fun$anonymous$$arg0$calluse$branch2$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lf92
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lf92
            long r33 = r6.m1127Long$arg3$call$init$$valopen$fun$anonymous$$arg0$calluse$branch2$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lf92
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lf92
            int r35 = r6.m1107Int$arg4$call$init$$valopen$fun$anonymous$$arg0$calluse$branch2$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lf92
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lf92
            int r36 = r6.m1109Int$arg5$call$init$$valopen$fun$anonymous$$arg0$calluse$branch2$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lf92
            r39 = 0
            r41 = 128(0x80, float:1.8E-43)
            r42 = 0
            r27 = r5
            r37 = r16
            r27.<init>(r28, r29, r31, r33, r35, r36, r37, r39, r41, r42)     // Catch: java.lang.Throwable -> Lf92
            r33 = r5
            r27 = r12
            r28 = r16
            r30 = r14
            r31 = r10
            vea.raceremote.control.UdpControlPacket r5 = bench$lambda$11$exchange(r27, r28, r30, r31, r33)     // Catch: java.lang.Throwable -> Lf92
            r19 = r5
            r5 = 128(0x80, float:1.8E-43)
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)     // Catch: java.lang.Throwable -> Lf92
            int r6 = r19.getKind()     // Catch: java.lang.Throwable -> Lf92
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch: java.lang.Throwable -> Lf92
            org.junit.Assert.assertEquals(r5, r6)     // Catch: java.lang.Throwable -> Lf92
            r62 = 1
            r63 = 0
            long r65 = r19.getToken()     // Catch: java.lang.Throwable -> Lf92
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lf92
            long r67 = r5.m1128Long$arg3$callcopy$valarm$fun$anonymous$$arg0$calluse$branch2$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lf92
            r69 = 0
            r70 = 0
            r71 = 0
            r73 = 0
            r75 = 242(0xf2, float:3.39E-43)
            r76 = 0
            r61 = r33
            vea.raceremote.control.UdpControlPacket r40 = vea.raceremote.control.UdpControlPacket.copy$default(r61, r62, r63, r65, r67, r69, r70, r71, r73, r75, r76)     // Catch: java.lang.Throwable -> Lf92
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lf92
            long r5 = r5.m1115Long$arg0$callassertEquals1$fun$anonymous$$arg0$calluse$branch2$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lf92
            r34 = r12
            r35 = r16
            r37 = r14
            r38 = r10
            vea.raceremote.control.UdpControlPacket r7 = bench$lambda$11$exchange(r34, r35, r37, r38, r40)     // Catch: java.lang.Throwable -> Lf92
            long r7 = r7.getSequence()     // Catch: java.lang.Throwable -> Lf92
            org.junit.Assert.assertEquals(r5, r7)     // Catch: java.lang.Throwable -> Lf92
            r62 = 2
            r63 = 0
            r65 = 0
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lf92
            long r67 = r5.m1129Long$arg3$callcopy$valdrive$fun$anonymous$$arg0$calluse$branch2$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lf92
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lf92
            int r69 = r5.m1108Int$arg4$callcopy$valdrive$fun$anonymous$$arg0$calluse$branch2$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lf92
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lf92
            int r70 = r5.m1110Int$arg5$callcopy$valdrive$fun$anonymous$$arg0$calluse$branch2$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lf92
            r71 = 0
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lf92
            long r73 = r5.m1130Long$arg7$callcopy$valdrive$fun$anonymous$$arg0$calluse$branch2$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lf92
            r75 = 70
            r76 = 0
            r61 = r40
            vea.raceremote.control.UdpControlPacket r47 = vea.raceremote.control.UdpControlPacket.copy$default(r61, r62, r63, r65, r67, r69, r70, r71, r73, r75, r76)     // Catch: java.lang.Throwable -> Lf92
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lf92
            long r5 = r5.m1116Long$arg0$callassertEquals2$fun$anonymous$$arg0$calluse$branch2$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lf92
            r41 = r12
            r42 = r16
            r44 = r14
            r45 = r10
            vea.raceremote.control.UdpControlPacket r7 = bench$lambda$11$exchange(r41, r42, r44, r45, r47)     // Catch: java.lang.Throwable -> Lf92
            long r7 = r7.getSequence()     // Catch: java.lang.Throwable -> Lf92
            org.junit.Assert.assertEquals(r5, r7)     // Catch: java.lang.Throwable -> Lf92
            r5 = r15
            r6 = r4
            r7 = r60
            r8 = r13
            r21 = r9
            r9 = r14
            r62 = r10
            org.json.JSONObject r5 = bench$status(r5, r6, r7, r8, r9, r10)     // Catch: java.lang.Throwable -> Lf8f
            r10 = r5
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lf8f
            java.lang.String r5 = r5.m1156String$arg0$callgetBoolean$arg0$callassertTrue$fun$anonymous$$arg0$calluse$branch2$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lf8f
            boolean r5 = r10.getBoolean(r5)     // Catch: java.lang.Throwable -> Lf8f
            org.junit.Assert.assertTrue(r5)     // Catch: java.lang.Throwable -> Lf8f
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lf8f
            int r5 = r5.m1077Int$arg0$callassertEquals3$fun$anonymous$$arg0$calluse$branch2$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lf8f
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)     // Catch: java.lang.Throwable -> Lf8f
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lf8f
            java.lang.String r6 = r6.m1168String$arg0$callgetInt$arg1$callassertEquals3$fun$anonymous$$arg0$calluse$branch2$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lf8f
            int r6 = r10.getInt(r6)     // Catch: java.lang.Throwable -> Lf8f
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch: java.lang.Throwable -> Lf8f
            org.junit.Assert.assertEquals(r5, r6)     // Catch: java.lang.Throwable -> Lf8f
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lf8f
            java.lang.String r5 = r5.m1216String$arg0$callrecord$fun$anonymous$$arg0$calluse$branch2$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lf8f
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lf8f
            java.lang.String r6 = r6.m1237String$arg1$callrecord$fun$anonymous$$arg0$calluse$branch2$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lf8f
            r8 = r62
            bench$record(r14, r8, r5, r6)     // Catch: java.lang.Throwable -> Lf8a
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lf8a
            long r5 = r5.m1123Long$arg0$callsleep$fun$anonymous$$arg0$calluse$branch2$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lf8a
            android.os.SystemClock.sleep(r5)     // Catch: java.lang.Throwable -> Lf8a
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> Lf8a
            java.lang.String r11 = r5.m1147String$arg0$callassertTrue1$fun$anonymous$$arg0$calluse$branch2$when$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> Lf8a
            r5 = r15
            r6 = r4
            r7 = r60
            r62 = r8
            r8 = r13
            r9 = r14
            r20 = r10
            r22 = r12
            r12 = r11
            r10 = r62
            org.json.JSONObject r5 = bench$status(r5, r6, r7, r8, r9, r10)     // Catch: java.lang.Throwable -> Lf8f
            boolean r5 = bench$neutral(r5)     // Catch: java.lang.Throwable -> Lf8f
            org.junit.Assert.assertTrue(r12, r5)     // Catch: java.lang.Throwable -> Lf8f
            kotlin.Unit r5 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> Lf8f
            r5 = 0
            kotlin.io.CloseableKt.closeFinally(r2, r5)     // Catch: java.lang.Throwable -> Lfa6
            goto Lfcb
        Lf8a:
            r0 = move-exception
            r62 = r8
            r5 = r0
            goto Lf9f
        Lf8f:
            r0 = move-exception
            r5 = r0
            goto Lf9f
        Lf92:
            r0 = move-exception
            r21 = r9
            r62 = r10
            r5 = r0
            goto Lf9f
        Lf99:
            r0 = move-exception
            r62 = r10
            r21 = r25
            r5 = r0
        Lf9f:
            throw r5     // Catch: java.lang.Throwable -> Lfa0
        Lfa0:
            r0 = move-exception
            r6 = r0
            kotlin.io.CloseableKt.closeFinally(r2, r5)     // Catch: java.lang.Throwable -> Lfa6
            throw r6     // Catch: java.lang.Throwable -> Lfa6
        Lfa6:
            r0 = move-exception
            r2 = r0
            r8 = r24
            r9 = r26
            r10 = r48
            r20 = r59
            r7 = r60
            r11 = r62
            goto L11bc
        Lfb6:
            r0 = move-exception
            r21 = r25
            r2 = r0
            r11 = r10
            r8 = r24
            r9 = r26
            r10 = r48
            r20 = r59
            r7 = r60
            goto L11bc
        Lfc7:
            r62 = r10
            r21 = r25
        Lfcb:
            r8 = r24
        Lfcd:
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L10a0
            boolean r2 = r2.m1059Boolean$setcomplete$try$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L10a0
            java.lang.Object r5 = r1.element
            vea.raceremote.control.UdpControlClient r5 = (vea.raceremote.control.UdpControlClient) r5
            if (r5 == 0) goto Lfde
            r5.close()
            kotlin.Unit r5 = kotlin.Unit.INSTANCE
        Lfde:
            boolean r5 = r23.isHeld()
            if (r5 == 0) goto Lfe7
            r23.release()
        Lfe7:
            if (r59 == 0) goto Lfee
            r59.close()
            kotlin.Unit r5 = kotlin.Unit.INSTANCE
        Lfee:
            okhttp3.ConnectionPool r5 = r15.connectionPool()
            r5.evictAll()
            okhttp3.Dispatcher r5 = r15.dispatcher()
            java.util.concurrent.ExecutorService r5 = r5.executorService()
            r5.shutdown()
            org.json.JSONObject r5 = new org.json.JSONObject
            r5.<init>()
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r6 = r6.m1186String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$callput$$this$callput$valreport$finally$funbench$classUdpControlDeviceBenchTest()
            org.json.JSONObject r5 = r5.put(r6, r3)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r6 = r6.m1187String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$callput$valreport$finally$funbench$classUdpControlDeviceBenchTest()
            org.json.JSONObject r5 = r5.put(r6, r2)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r6 = r6.m1190String$arg0$callput$$this$callput$$this$callput$$this$callput$valreport$finally$funbench$classUdpControlDeviceBenchTest()
            long r9 = android.os.SystemClock.elapsedRealtime()
            r11 = r62
            long r9 = r9 - r11
            org.json.JSONObject r5 = r5.put(r6, r9)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r6 = r6.m1194String$arg0$callput$$this$callput$$this$callput$valreport$finally$funbench$classUdpControlDeviceBenchTest()
            org.json.JSONObject r5 = r5.put(r6, r4)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r6 = r6.m1201String$arg0$callput$$this$callput$valreport$finally$funbench$classUdpControlDeviceBenchTest()
            r7 = r60
            org.json.JSONObject r5 = r5.put(r6, r7)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r6 = r6.m1208String$arg0$callput$valreport$finally$funbench$classUdpControlDeviceBenchTest()
            org.json.JSONArray r9 = new org.json.JSONArray
            r10 = r48
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r14, r10)
            r10 = r14
            java.lang.Iterable r10 = (java.lang.Iterable) r10
            java.util.List r10 = kotlin.collections.CollectionsKt.toList(r10)
            java.util.Collection r10 = (java.util.Collection) r10
            r9.<init>(r10)
            org.json.JSONObject r5 = r5.put(r6, r9)
            java.io.File r6 = new java.io.File
            java.io.File r9 = r54.getFilesDir()
            java.lang.StringBuilder r10 = new java.lang.StringBuilder
            r10.<init>()
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r16 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            r17 = r2
            java.lang.String r2 = r16.m1136String$0$str$arg1$call$init$$$$this$callwriteText$finally$funbench$classUdpControlDeviceBenchTest()
            java.lang.StringBuilder r2 = r10.append(r2)
            java.lang.StringBuilder r2 = r2.append(r3)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r10 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r10 = r10.m1139String$2$str$arg1$call$init$$$$this$callwriteText$finally$funbench$classUdpControlDeviceBenchTest()
            java.lang.StringBuilder r2 = r2.append(r10)
            java.lang.String r2 = r2.toString()
            r6.<init>(r9, r2)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            int r2 = r2.m1091Int$arg0$calltoString$arg0$callwriteText$finally$funbench$classUdpControlDeviceBenchTest()
            java.lang.String r2 = r5.toString(r2)
            r9 = r26
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, r9)
            r9 = 2
            r10 = 0
            kotlin.io.FilesKt.writeText$default(r6, r2, r10, r9, r10)
            return
        L10a0:
            r0 = move-exception
            r9 = r26
            r10 = r48
            r7 = r60
            r11 = r62
            r2 = r0
            r20 = r59
            goto L11bc
        L10ae:
            r0 = move-exception
            goto L10b3
        L10b0:
            r0 = move-exception
            r3 = r79
        L10b3:
            r11 = r10
            r21 = r25
            r9 = r26
            r10 = r48
            r7 = r60
            r2 = r0
            r8 = r24
            r20 = r59
            goto L11bc
        L10c3:
            r0 = move-exception
            r21 = r2
            r9 = r26
            r10 = r48
            r11 = r52
            r15 = r56
            r7 = r60
            r4 = r61
            r53 = r3
            r3 = r1
            r1 = r49
            r2 = r0
            r8 = r24
            r20 = r59
            goto L11bc
        L10de:
            r0 = move-exception
            r21 = r2
            r4 = r12
            r7 = r18
            r9 = r26
            r10 = r48
            r11 = r52
            r15 = r56
            r53 = r3
            r3 = r1
            r1 = r49
            r2 = r0
            r8 = r24
            r20 = r59
            goto L11bc
        L10f8:
            r21 = r2
            r59 = r4
            r4 = r12
            r7 = r15
            r9 = r26
            r11 = r52
            r15 = r56
            r53 = r3
            r52 = r10
            r10 = r48
            r3 = r1
            r1 = r49
            java.lang.IllegalArgumentException r2 = new java.lang.IllegalArgumentException     // Catch: java.lang.Throwable -> L1117
            java.lang.String r5 = r16.toString()     // Catch: java.lang.Throwable -> L1117
            r2.<init>(r5)     // Catch: java.lang.Throwable -> L1117
            throw r2     // Catch: java.lang.Throwable -> L1117
        L1117:
            r0 = move-exception
            r2 = r0
            r8 = r24
            r20 = r59
            goto L11bc
        L111f:
            r0 = move-exception
            r21 = r2
            r59 = r4
            r4 = r12
            r7 = r15
            r9 = r26
            r10 = r48
            r11 = r52
            r15 = r56
            r53 = r3
            r3 = r1
            r1 = r49
            r2 = r0
            r8 = r24
            r20 = r59
            goto L11bc
        L113a:
            r0 = move-exception
            r23 = r3
            r59 = r4
            r14 = r7
            r54 = r9
            r53 = r10
            r4 = r12
            r7 = r15
            r51 = r17
            r55 = r19
            r24 = r21
            r9 = r26
            r10 = r48
            r3 = r1
            r21 = r2
            r15 = r11
            r1 = r49
            r11 = r5
            r2 = r0
            r8 = r24
            r20 = r59
            goto L11bc
        L115e:
            r0 = move-exception
            r21 = r2
            r23 = r3
            r59 = r4
            r14 = r7
            r24 = r8
            r54 = r9
            r53 = r10
            r4 = r12
            r7 = r15
            r51 = r17
            r55 = r19
            r9 = r26
            r10 = r48
            r3 = r1
            r15 = r11
            r1 = r49
            r11 = r5
            r2 = r0
            r20 = r59
            goto L11bc
        L117f:
            r0 = move-exception
            r21 = r2
            r23 = r3
            r14 = r7
            r24 = r8
            r54 = r9
            r53 = r10
            r4 = r12
            r7 = r15
            r55 = r19
            r9 = r26
            r10 = r48
            r59 = r51
            r3 = r1
            r15 = r11
            r51 = r17
            r1 = r49
            r11 = r5
            r2 = r0
            r20 = r59
            goto L11bc
        L11a0:
            r0 = move-exception
            r21 = r2
            r23 = r3
            r14 = r7
            r24 = r8
            r54 = r9
            r53 = r10
            r4 = r12
            r7 = r15
            r51 = r17
            r55 = r19
            r9 = r26
            r10 = r48
            r3 = r1
            r15 = r11
            r1 = r49
            r11 = r5
            r2 = r0
        L11bc:
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L11ca
            java.lang.String r5 = r5.m1214String$arg0$callrecord$catch$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L11ca
            java.lang.String r6 = r2.toString()     // Catch: java.lang.Throwable -> L11ca
            bench$record(r14, r11, r5, r6)     // Catch: java.lang.Throwable -> L11ca
            throw r2     // Catch: java.lang.Throwable -> L11ca
        L11ca:
            r0 = move-exception
            r2 = r0
            java.lang.Object r5 = r1.element
            vea.raceremote.control.UdpControlClient r5 = (vea.raceremote.control.UdpControlClient) r5
            if (r5 == 0) goto L11d7
            r5.close()
            kotlin.Unit r5 = kotlin.Unit.INSTANCE
        L11d7:
            r5 = r23
            android.net.wifi.WifiManager$WifiLock r5 = (android.net.wifi.WifiManager.WifiLock) r5
            boolean r5 = r5.isHeld()
            if (r5 == 0) goto L11e8
            r5 = r23
            android.net.wifi.WifiManager$WifiLock r5 = (android.net.wifi.WifiManager.WifiLock) r5
            r5.release()
        L11e8:
            if (r20 == 0) goto L11ef
            r20.close()
            kotlin.Unit r5 = kotlin.Unit.INSTANCE
        L11ef:
            okhttp3.ConnectionPool r5 = r15.connectionPool()
            r5.evictAll()
            okhttp3.Dispatcher r5 = r15.dispatcher()
            java.util.concurrent.ExecutorService r5 = r5.executorService()
            r5.shutdown()
            org.json.JSONObject r5 = new org.json.JSONObject
            r5.<init>()
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r6 = r6.m1186String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$callput$$this$callput$valreport$finally$funbench$classUdpControlDeviceBenchTest()
            org.json.JSONObject r5 = r5.put(r6, r3)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r6 = r6.m1187String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$callput$valreport$finally$funbench$classUdpControlDeviceBenchTest()
            r49 = r1
            r1 = r50
            org.json.JSONObject r5 = r5.put(r6, r1)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r6 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r6 = r6.m1190String$arg0$callput$$this$callput$$this$callput$$this$callput$valreport$finally$funbench$classUdpControlDeviceBenchTest()
            long r16 = android.os.SystemClock.elapsedRealtime()
            r18 = r2
            long r1 = r16 - r11
            org.json.JSONObject r1 = r5.put(r6, r1)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r2 = r2.m1194String$arg0$callput$$this$callput$$this$callput$valreport$finally$funbench$classUdpControlDeviceBenchTest()
            org.json.JSONObject r1 = r1.put(r2, r4)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r2 = r2.m1201String$arg0$callput$$this$callput$valreport$finally$funbench$classUdpControlDeviceBenchTest()
            org.json.JSONObject r1 = r1.put(r2, r7)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r2 = r2.m1208String$arg0$callput$valreport$finally$funbench$classUdpControlDeviceBenchTest()
            org.json.JSONArray r5 = new org.json.JSONArray
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r14, r10)
            r6 = r14
            java.lang.Iterable r6 = (java.lang.Iterable) r6
            java.util.List r6 = kotlin.collections.CollectionsKt.toList(r6)
            java.util.Collection r6 = (java.util.Collection) r6
            r5.<init>(r6)
            org.json.JSONObject r1 = r1.put(r2, r5)
            java.io.File r2 = new java.io.File
            java.io.File r5 = r54.getFilesDir()
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            r6.<init>()
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r10 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r10 = r10.m1136String$0$str$arg1$call$init$$$$this$callwriteText$finally$funbench$classUdpControlDeviceBenchTest()
            java.lang.StringBuilder r6 = r6.append(r10)
            java.lang.StringBuilder r6 = r6.append(r3)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r10 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r10 = r10.m1139String$2$str$arg1$call$init$$$$this$callwriteText$finally$funbench$classUdpControlDeviceBenchTest()
            java.lang.StringBuilder r6 = r6.append(r10)
            java.lang.String r6 = r6.toString()
            r2.<init>(r5, r6)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            int r5 = r5.m1091Int$arg0$calltoString$arg0$callwriteText$finally$funbench$classUdpControlDeviceBenchTest()
            java.lang.String r5 = r1.toString(r5)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r5, r9)
            r6 = 2
            r9 = 0
            kotlin.io.FilesKt.writeText$default(r2, r5, r9, r6, r9)
            throw r18
        L129d:
            r3 = r1
            r27 = r14
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = r27.toString()
            r1.<init>(r2)
            throw r1
        L12aa:
            r3 = r1
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = r16.toString()
            r1.<init>(r2)
            throw r1
        L12b5:
            r3 = r1
            r27 = r14
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = r27.toString()
            r1.<init>(r2)
            throw r1
        L12c2:
            r3 = r1
            r27 = r14
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = r27.toString()
            r1.<init>(r2)
            throw r1
    }

    private static final void bench$awaitStatus(okhttp3.OkHttpClient r4, java.lang.String r5, java.lang.String r6, android.os.Bundle r7, java.util.List<org.json.JSONObject> r8, long r9, kotlin.jvm.functions.Function1<? super org.json.JSONObject, java.lang.Boolean> r11) {
            long r0 = android.os.SystemClock.elapsedRealtime()
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            int r2 = r2.m1082Int$arg0$callplus$valend$funawaitStatus$funbench$classUdpControlDeviceBenchTest()
            long r2 = (long) r2
            long r0 = r0 + r2
        Lc:
            org.json.JSONObject r2 = bench$status(r4, r5, r6, r7, r8, r9)
            java.lang.Object r2 = r11.invoke(r2)
            java.lang.Boolean r2 = (java.lang.Boolean) r2
            boolean r2 = r2.booleanValue()
            if (r2 == 0) goto L1d
            return
        L1d:
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            long r2 = r2.m1120Long$arg0$callsleep$body$loop$funawaitStatus$funbench$classUdpControlDeviceBenchTest()
            android.os.SystemClock.sleep(r2)
            long r2 = android.os.SystemClock.elapsedRealtime()
            int r2 = (r2 > r0 ? 1 : (r2 == r0 ? 0 : -1))
            if (r2 < 0) goto Lc
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r2 = r2.m1154String$arg0$callfail$funawaitStatus$funbench$classUdpControlDeviceBenchTest()
            org.junit.Assert.fail(r2)
            return
    }

    private static final vea.raceremote.control.UdpControlClient bench$connect(java.lang.String r14, long r15, kotlin.jvm.internal.Ref.ObjectRef<vea.raceremote.control.UdpControlClient> r17, android.net.Network r18, java.util.List<org.json.JSONObject> r19, long r20) {
            vea.raceremote.control.UdpControlClient r9 = new vea.raceremote.control.UdpControlClient
            vea.raceremote.UdpControlDeviceBenchTest$bench$connect$c$1 r0 = new vea.raceremote.UdpControlDeviceBenchTest$bench$connect$c$1
            r10 = r18
            r0.<init>(r10)
            r4 = r0
            kotlin.jvm.functions.Function1 r4 = (kotlin.jvm.functions.Function1) r4
            vea.raceremote.UdpControlDeviceBenchTest$bench$connect$c$2 r0 = new vea.raceremote.UdpControlDeviceBenchTest$bench$connect$c$2
            r11 = r19
            r12 = r20
            r0.<init>(r11, r12)
            r5 = r0
            kotlin.jvm.functions.Function1 r5 = (kotlin.jvm.functions.Function1) r5
            r6 = 0
            r7 = 16
            r8 = 0
            r0 = r9
            r1 = r14
            r2 = r15
            r0.<init>(r1, r2, r4, r5, r6, r7, r8)
            r1 = r17
            r1.element = r0
            long r2 = android.os.SystemClock.elapsedRealtime()
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r4 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            int r4 = r4.m1083Int$arg0$callplus$valend$funconnect$try$funbench$classUdpControlDeviceBenchTest()
            long r4 = (long) r4
            long r2 = r2 + r4
        L32:
            vea.raceremote.control.UdpControlSession$Snapshot r4 = r0.snapshot()
            vea.raceremote.control.UdpControlSession$Phase r4 = r4.getPhase()
            vea.raceremote.control.UdpControlSession$Phase r5 = vea.raceremote.control.UdpControlSession.Phase.ACTIVE
            if (r4 == r5) goto L78
            long r4 = android.os.SystemClock.elapsedRealtime()
            int r4 = (r4 > r2 ? 1 : (r4 == r2 ? 0 : -1))
            if (r4 >= 0) goto L78
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r5 = r5.m1133String$0$str$arg0$callassertNotEquals$body$loop$funconnect$try$funbench$classUdpControlDeviceBenchTest()
            java.lang.StringBuilder r4 = r4.append(r5)
            vea.raceremote.control.UdpControlSession$Snapshot r5 = r0.snapshot()
            java.lang.StringBuilder r4 = r4.append(r5)
            java.lang.String r4 = r4.toString()
            vea.raceremote.control.UdpControlSession$Phase r5 = vea.raceremote.control.UdpControlSession.Phase.CLOSED
            vea.raceremote.control.UdpControlSession$Snapshot r6 = r0.snapshot()
            vea.raceremote.control.UdpControlSession$Phase r6 = r6.getPhase()
            org.junit.Assert.assertNotEquals(r4, r5, r6)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r4 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            long r4 = r4.m1121Long$arg0$callsleep$body$loop$funconnect$try$funbench$classUdpControlDeviceBenchTest()
            android.os.SystemClock.sleep(r4)
            goto L32
        L78:
            vea.raceremote.control.UdpControlSession$Phase r4 = vea.raceremote.control.UdpControlSession.Phase.ACTIVE
            vea.raceremote.control.UdpControlSession$Snapshot r5 = r0.snapshot()
            vea.raceremote.control.UdpControlSession$Phase r5 = r5.getPhase()
            org.junit.Assert.assertEquals(r4, r5)
            return r0
    }

    private static final vea.raceremote.control.UdpControlPacket bench$lambda$11$exchange(java.net.DatagramSocket r9, long r10, java.util.List<org.json.JSONObject> r12, long r13, vea.raceremote.control.UdpControlPacket r15) {
            byte[] r0 = r15.encode()
            java.net.DatagramPacket r1 = new java.net.DatagramPacket
            int r2 = r0.length
            r1.<init>(r0, r2)
            r9.send(r1)
            java.net.DatagramPacket r1 = new java.net.DatagramPacket
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            int r2 = r2.m1072Int$arg0$call$init$$arg0$call$init$$valresponse$funexchange$fun$anonymous$$arg0$calluse$branch2$when$try$funbench$classUdpControlDeviceBenchTest()
            byte[] r2 = new byte[r2]
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r3 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            int r3 = r3.m1092Int$arg1$call$init$$valresponse$funexchange$fun$anonymous$$arg0$calluse$branch2$when$try$funbench$classUdpControlDeviceBenchTest()
            r1.<init>(r2, r3)
            r9.receive(r1)
            vea.raceremote.control.UdpControlPacket$Companion r2 = vea.raceremote.control.UdpControlPacket.Companion
            byte[] r3 = r1.getData()
            java.lang.String r4 = "response.data"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r3, r4)
            int r4 = r1.getLength()
            byte[] r3 = java.util.Arrays.copyOf(r3, r4)
            java.lang.String r4 = "copyOf(this, newSize)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r3, r4)
            vea.raceremote.control.UdpControlPacket r2 = r2.decode(r3)
            if (r2 == 0) goto L64
            r3 = r2
            r4 = 0
            long r5 = r3.getChipId()
            org.junit.Assert.assertEquals(r10, r5)
            long r5 = r15.getAttempt()
            long r7 = r3.getAttempt()
            org.junit.Assert.assertEquals(r5, r7)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r5 = r5.m1215String$arg0$callrecord$fun$anonymous$$arg0$callalso$funexchange$fun$anonymous$$arg0$calluse$branch2$when$try$funbench$classUdpControlDeviceBenchTest()
            java.lang.String r6 = r3.toString()
            bench$record(r12, r13, r5, r6)
            return r2
        L64:
            java.lang.IllegalArgumentException r2 = new java.lang.IllegalArgumentException
            java.lang.String r3 = "Required value was null."
            java.lang.String r3 = r3.toString()
            r2.<init>(r3)
            throw r2
    }

    private static final void bench$lambda$6(vea.raceremote.app.MainActivity r2) {
            android.view.Window r0 = r2.getWindow()
            r1 = 128(0x80, float:1.8E-43)
            r0.addFlags(r1)
            return
    }

    private static final boolean bench$neutral(org.json.JSONObject r6) {
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r0 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r0 = r0.m1155String$arg0$callgetBoolean$$this$callnot$cond$funneutral$funbench$classUdpControlDeviceBenchTest()
            boolean r0 = r6.getBoolean(r0)
            r1 = 0
            if (r0 != 0) goto L55
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r0 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r0 = r0.m1172String$arg0$callgetJSONObject$$$this$calllet$branch$funneutral$funbench$classUdpControlDeviceBenchTest()
            org.json.JSONObject r0 = r6.getJSONObject(r0)
            r2 = 0
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r3 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r3 = r3.m1163String$arg0$callgetInt$arg0$callEQEQ$cond$cond$fun$anonymous$$arg0$calllet$branch$funneutral$funbench$classUdpControlDeviceBenchTest()
            int r3 = r0.getInt(r3)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r4 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            int r4 = r4.m1098Int$arg1$callEQEQ$cond$cond$fun$anonymous$$arg0$calllet$branch$funneutral$funbench$classUdpControlDeviceBenchTest()
            r5 = 1
            if (r3 != r4) goto L51
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r3 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r3 = r3.m1159String$arg0$callgetInt$arg0$callEQEQ$branch$cond$fun$anonymous$$arg0$calllet$branch$funneutral$funbench$classUdpControlDeviceBenchTest()
            int r3 = r0.getInt(r3)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r4 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            int r4 = r4.m1093Int$arg1$callEQEQ$branch$cond$fun$anonymous$$arg0$calllet$branch$funneutral$funbench$classUdpControlDeviceBenchTest()
            if (r3 != r4) goto L51
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r3 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r3 = r3.m1160String$arg0$callgetInt$arg0$callEQEQ$branch$fun$anonymous$$arg0$calllet$branch$funneutral$funbench$classUdpControlDeviceBenchTest()
            int r3 = r0.getInt(r3)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r4 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            int r4 = r4.m1094Int$arg1$callEQEQ$branch$fun$anonymous$$arg0$calllet$branch$funneutral$funbench$classUdpControlDeviceBenchTest()
            if (r3 != r4) goto L51
            r0 = r5
            goto L52
        L51:
            r0 = r1
        L52:
            if (r0 == 0) goto L55
            r1 = r5
        L55:
            return r1
    }

    private static final void bench$record(java.util.List<org.json.JSONObject> r4, long r5, java.lang.String r7, java.lang.Object r8) {
            org.json.JSONObject r0 = new org.json.JSONObject
            r0.<init>()
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r1 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r1 = r1.m1191String$arg0$callput$$this$callput$$this$callput$arg0$calladd$funrecord$funbench$classUdpControlDeviceBenchTest()
            long r2 = android.os.SystemClock.elapsedRealtime()
            long r2 = r2 - r5
            org.json.JSONObject r0 = r0.put(r1, r2)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r1 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r1 = r1.m1195String$arg0$callput$$this$callput$arg0$calladd$funrecord$funbench$classUdpControlDeviceBenchTest()
            org.json.JSONObject r0 = r0.put(r1, r7)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r1 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r1 = r1.m1202String$arg0$callput$arg0$calladd$funrecord$funbench$classUdpControlDeviceBenchTest()
            org.json.JSONObject r0 = r0.put(r1, r8)
            r4.add(r0)
            return
    }

    private static final org.json.JSONObject bench$status(okhttp3.OkHttpClient r8, java.lang.String r9, java.lang.String r10, android.os.Bundle r11, java.util.List<org.json.JSONObject> r12, long r13) {
            okhttp3.Request$Builder r0 = new okhttp3.Request$Builder
            r0.<init>()
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r2 = r2.m1135String$0$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$valvalue$funstatus$funbench$classUdpControlDeviceBenchTest()
            java.lang.StringBuilder r1 = r1.append(r2)
            java.lang.StringBuilder r1 = r1.append(r9)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r2 = r2.m1138String$2$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$valvalue$funstatus$funbench$classUdpControlDeviceBenchTest()
            java.lang.StringBuilder r1 = r1.append(r2)
            java.lang.String r1 = r1.toString()
            okhttp3.Request$Builder r0 = r0.url(r1)
            okhttp3.Request r0 = r0.build()
            okhttp3.Call r0 = r8.newCall(r0)
            okhttp3.Response r0 = r0.execute()
            java.io.Closeable r0 = (java.io.Closeable) r0
            r1 = r0
            okhttp3.Response r1 = (okhttp3.Response) r1     // Catch: java.lang.Throwable -> L150
            r2 = 0
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r3 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE     // Catch: java.lang.Throwable -> L150
            int r3 = r3.m1075Int$arg0$callassertEquals$fun$anonymous$$arg0$calluse$valvalue$funstatus$funbench$classUdpControlDeviceBenchTest()     // Catch: java.lang.Throwable -> L150
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch: java.lang.Throwable -> L150
            int r4 = r1.code()     // Catch: java.lang.Throwable -> L150
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)     // Catch: java.lang.Throwable -> L150
            org.junit.Assert.assertEquals(r3, r4)     // Catch: java.lang.Throwable -> L150
            org.json.JSONObject r3 = new org.json.JSONObject     // Catch: java.lang.Throwable -> L150
            okhttp3.ResponseBody r4 = r1.body()     // Catch: java.lang.Throwable -> L150
            if (r4 == 0) goto L144
            java.lang.String r4 = r4.string()     // Catch: java.lang.Throwable -> L150
            r3.<init>(r4)     // Catch: java.lang.Throwable -> L150
            r1 = 0
            kotlin.io.CloseableKt.closeFinally(r0, r1)
            r0 = r3
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r1 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r1 = r1.m1219String$arg0$callrecord$funstatus$funbench$classUdpControlDeviceBenchTest()
            bench$record(r12, r13, r1, r0)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r1 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r1 = r1.m1182String$arg0$callgetString$arg1$callassertEquals$funstatus$funbench$classUdpControlDeviceBenchTest()
            java.lang.String r1 = r0.getString(r1)
            org.junit.Assert.assertEquals(r10, r1)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r1 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r1 = r1.m1144String$arg0$callassertEquals1$funstatus$funbench$classUdpControlDeviceBenchTest()
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r2 = r2.m1184String$arg0$callgetString$arg1$callassertEquals1$funstatus$funbench$classUdpControlDeviceBenchTest()
            java.lang.String r2 = r0.getString(r2)
            org.junit.Assert.assertEquals(r1, r2)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r1 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            int r1 = r1.m1076Int$arg0$callassertEquals2$funstatus$funbench$classUdpControlDeviceBenchTest()
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r2 = r2.m1167String$arg0$callgetInt$arg1$callassertEquals2$funstatus$funbench$classUdpControlDeviceBenchTest()
            int r2 = r0.getInt(r2)
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            org.junit.Assert.assertEquals(r1, r2)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r1 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r1 = r1.m1185String$arg0$callgetString$valtmp0_safe_receiver$funstatus$funbench$classUdpControlDeviceBenchTest()
            java.lang.String r1 = r11.getString(r1)
            if (r1 == 0) goto Ld7
            r2 = 0
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r3 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r3 = r3.m1142String$arg0$callassertEquals$fun$anonymous$$arg0$calllet$else$when$funstatus$funbench$classUdpControlDeviceBenchTest()
            int r4 = java.lang.Integer.parseInt(r1)
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r5 = r5.m1169String$arg0$callgetInt$arg2$callassertEquals$fun$anonymous$$arg0$calllet$else$when$funstatus$funbench$classUdpControlDeviceBenchTest()
            int r5 = r0.getInt(r5)
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)
            org.junit.Assert.assertEquals(r3, r4, r5)
        Ld7:
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r1 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r1 = r1.m1145String$arg0$callassertFalse$funstatus$funbench$classUdpControlDeviceBenchTest()
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r2 = r2.m1158String$arg0$callgetBoolean$arg1$callassertFalse$funstatus$funbench$classUdpControlDeviceBenchTest()
            boolean r2 = r0.getBoolean(r2)
            org.junit.Assert.assertFalse(r1, r2)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r1 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r1 = r1.m1175String$arg0$callgetJSONObject$valplan$funstatus$funbench$classUdpControlDeviceBenchTest()
            org.json.JSONObject r1 = r0.getJSONObject(r1)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r2 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r2 = r2.m1171String$arg0$callgetInt$valfi$funstatus$funbench$classUdpControlDeviceBenchTest()
            int r2 = r1.getInt(r2)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r3 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r3 = r3.m1170String$arg0$callgetInt$valbi$funstatus$funbench$classUdpControlDeviceBenchTest()
            int r3 = r1.getInt(r3)
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r4 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            int r4 = r4.m1067Int$$this$callrangeTo$$this$callcontains$cond$cond$arg0$callassertTrue$funstatus$funbench$classUdpControlDeviceBenchTest()
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            int r5 = r5.m1088Int$arg0$callrangeTo$$this$callcontains$cond$cond$arg0$callassertTrue$funstatus$funbench$classUdpControlDeviceBenchTest()
            r6 = 1
            r7 = 0
            if (r2 > r5) goto L11c
            if (r4 > r2) goto L11c
            r4 = r6
            goto L11d
        L11c:
            r4 = r7
        L11d:
            if (r4 == 0) goto L13f
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r4 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            int r4 = r4.m1064Int$$this$callrangeTo$$this$callcontains$branch$cond$arg0$callassertTrue$funstatus$funbench$classUdpControlDeviceBenchTest()
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r5 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            int r5 = r5.m1085Int$arg0$callrangeTo$$this$callcontains$branch$cond$arg0$callassertTrue$funstatus$funbench$classUdpControlDeviceBenchTest()
            if (r3 > r5) goto L131
            if (r4 > r3) goto L131
            r4 = r6
            goto L132
        L131:
            r4 = r7
        L132:
            if (r4 == 0) goto L13f
            if (r2 == 0) goto L13e
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r4 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            int r4 = r4.m1102Int$arg1$callEQEQ$else$branch$arg0$callassertTrue$funstatus$funbench$classUdpControlDeviceBenchTest()
            if (r3 != r4) goto L13f
        L13e:
            goto L140
        L13f:
            r6 = r7
        L140:
            org.junit.Assert.assertTrue(r6)
            return r0
        L144:
            java.lang.String r3 = "Required value was null."
            java.lang.IllegalArgumentException r4 = new java.lang.IllegalArgumentException     // Catch: java.lang.Throwable -> L150
            java.lang.String r3 = r3.toString()     // Catch: java.lang.Throwable -> L150
            r4.<init>(r3)     // Catch: java.lang.Throwable -> L150
            throw r4     // Catch: java.lang.Throwable -> L150
        L150:
            r1 = move-exception
            throw r1     // Catch: java.lang.Throwable -> L152
        L152:
            r2 = move-exception
            kotlin.io.CloseableKt.closeFinally(r0, r1)
            throw r2
    }

    @org.junit.Test
    public final void driveAndStop() {
            r1 = this;
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r0 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r0 = r0.m1149String$arg0$callbench$fundriveAndStop$classUdpControlDeviceBenchTest()
            r1.bench(r0)
            return
    }

    @org.junit.Test
    public final void silenceExpiresOnBoard() {
            r1 = this;
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r0 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r0 = r0.m1150String$arg0$callbench$funsilenceExpiresOnBoard$classUdpControlDeviceBenchTest()
            r1.bench(r0)
            return
    }

    @org.junit.Test
    public final void sixNeutralSessions() {
            r1 = this;
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r0 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r0 = r0.m1151String$arg0$callbench$funsixNeutralSessions$classUdpControlDeviceBenchTest()
            r1.bench(r0)
            return
    }

    @org.junit.Test
    public final void sustainedNeutralSession() {
            r1 = this;
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r0 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r0 = r0.m1152String$arg0$callbench$funsustainedNeutralSession$classUdpControlDeviceBenchTest()
            r1.bench(r0)
            return
    }

    @org.junit.Test
    public final void wifiLockComparison() {
            r1 = this;
            vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt r0 = vea.raceremote.LiveLiterals$UdpControlDeviceBenchTestKt.INSTANCE
            java.lang.String r0 = r0.m1153String$arg0$callbench$funwifiLockComparison$classUdpControlDeviceBenchTest()
            r1.bench(r0)
            return
    }
}
