package vea.raceremote;

/* JADX INFO: compiled from: UdpControlScreenDeviceTest.kt */
/* JADX INFO: loaded from: classes4.dex */
@kotlin.Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\t\u001a\u00020\nH\u0007R%\u0010\u0003\u001a\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0004\u0012\u00020\u00060\u00048G¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b¨\u0006\u000b"}, d2 = {"Lvea/raceremote/UdpControlScreenDeviceTest;", "", "()V", "compose", "Landroidx/compose/ui/test/junit4/AndroidComposeTestRule;", "Landroidx/test/ext/junit/rules/ActivityScenarioRule;", "Lvea/raceremote/app/MainActivity;", "getCompose", "()Landroidx/compose/ui/test/junit4/AndroidComposeTestRule;", "controlsVideoFailureBackgroundStopAndExplicitReconnect", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class UdpControlScreenDeviceTest {
    public static final int $stable = 0;
    private final androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> compose;




    /* JADX INFO: renamed from: vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$12, reason: invalid class name */
    /* JADX INFO: compiled from: UdpControlScreenDeviceTest.kt */
    @kotlin.Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    /* synthetic */ class AnonymousClass12 extends kotlin.jvm.internal.FunctionReferenceImpl implements kotlin.jvm.functions.Function1<org.json.JSONObject, java.lang.Boolean> {
        public static final vea.raceremote.UdpControlScreenDeviceTest.AnonymousClass12 INSTANCE = null;

        static {
                vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$12 r0 = new vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$12
                r0.<init>()
                vea.raceremote.UdpControlScreenDeviceTest.AnonymousClass12.INSTANCE = r0
                return
        }

        AnonymousClass12() {
                r6 = this;
                r1 = 1
                java.lang.Class<kotlin.jvm.internal.Intrinsics$Kotlin> r2 = kotlin.jvm.internal.Intrinsics.Kotlin.class
                java.lang.String r3 = "neutral"
                java.lang.String r4 = "controlsVideoFailureBackgroundStopAndExplicitReconnect$neutral(Lorg/json/JSONObject;)Z"
                r5 = 0
                r0 = r6
                r0.<init>(r1, r2, r3, r4, r5)
                return
        }

        public final java.lang.Boolean invoke(org.json.JSONObject r2) {
                r1 = this;
                java.lang.String r0 = "p0"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                boolean r0 = vea.raceremote.UdpControlScreenDeviceTest.access$controlsVideoFailureBackgroundStopAndExplicitReconnect$neutral(r2)
                java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
                return r0
        }

        public /* bridge */ /* synthetic */ java.lang.Object invoke(java.lang.Object r2) {
                r1 = this;
                r0 = r2
                org.json.JSONObject r0 = (org.json.JSONObject) r0
                java.lang.Boolean r0 = r1.invoke(r0)
                return r0
        }
    }



    /* JADX INFO: renamed from: vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$15, reason: invalid class name */
    /* JADX INFO: compiled from: UdpControlScreenDeviceTest.kt */
    @kotlin.Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    /* synthetic */ class AnonymousClass15 extends kotlin.jvm.internal.FunctionReferenceImpl implements kotlin.jvm.functions.Function1<org.json.JSONObject, java.lang.Boolean> {
        public static final vea.raceremote.UdpControlScreenDeviceTest.AnonymousClass15 INSTANCE = null;

        static {
                vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$15 r0 = new vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$15
                r0.<init>()
                vea.raceremote.UdpControlScreenDeviceTest.AnonymousClass15.INSTANCE = r0
                return
        }

        AnonymousClass15() {
                r6 = this;
                r1 = 1
                java.lang.Class<kotlin.jvm.internal.Intrinsics$Kotlin> r2 = kotlin.jvm.internal.Intrinsics.Kotlin.class
                java.lang.String r3 = "neutral"
                java.lang.String r4 = "controlsVideoFailureBackgroundStopAndExplicitReconnect$neutral(Lorg/json/JSONObject;)Z"
                r5 = 0
                r0 = r6
                r0.<init>(r1, r2, r3, r4, r5)
                return
        }

        public final java.lang.Boolean invoke(org.json.JSONObject r2) {
                r1 = this;
                java.lang.String r0 = "p0"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                boolean r0 = vea.raceremote.UdpControlScreenDeviceTest.access$controlsVideoFailureBackgroundStopAndExplicitReconnect$neutral(r2)
                java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
                return r0
        }

        public /* bridge */ /* synthetic */ java.lang.Object invoke(java.lang.Object r2) {
                r1 = this;
                r0 = r2
                org.json.JSONObject r0 = (org.json.JSONObject) r0
                java.lang.Boolean r0 = r1.invoke(r0)
                return r0
        }
    }









    static {
            int r0 = androidx.compose.ui.test.junit4.AndroidComposeTestRule.$stable
            vea.raceremote.UdpControlScreenDeviceTest.$stable = r0
            return
    }

    public UdpControlScreenDeviceTest() {
            r2 = this;
            r2.<init>()
            r0 = 0
            java.lang.Class<vea.raceremote.app.MainActivity> r1 = vea.raceremote.app.MainActivity.class
            androidx.compose.ui.test.junit4.AndroidComposeTestRule r0 = androidx.compose.ui.test.junit4.AndroidComposeTestRule_androidKt.createAndroidComposeRule(r1)
            r2.compose = r0
            return
    }

    public static final /* synthetic */ boolean access$controlsVideoFailureBackgroundStopAndExplicitReconnect$neutral(org.json.JSONObject r1) {
            boolean r0 = controlsVideoFailureBackgroundStopAndExplicitReconnect$neutral(r1)
            return r0
    }

    private static final void controlsVideoFailureBackgroundStopAndExplicitReconnect$awaitStatus(okhttp3.OkHttpClient r4, java.lang.String r5, java.lang.String r6, org.json.JSONArray r7, long r8, kotlin.jvm.functions.Function1<? super org.json.JSONObject, java.lang.Boolean> r10) {
            long r0 = android.os.SystemClock.elapsedRealtime()
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r2 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            int r2 = r2.m1260Int$arg0$callplus$valuntil$funawaitStatus$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            long r2 = (long) r2
            long r0 = r0 + r2
        Lc:
            org.json.JSONObject r2 = controlsVideoFailureBackgroundStopAndExplicitReconnect$status(r4, r5, r6, r7, r8)
            java.lang.Object r2 = r10.invoke(r2)
            java.lang.Boolean r2 = (java.lang.Boolean) r2
            boolean r2 = r2.booleanValue()
            if (r2 == 0) goto L1d
            return
        L1d:
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r2 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            long r2 = r2.m1284Long$arg0$callsleep$body$loop$funawaitStatus$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            android.os.SystemClock.sleep(r2)
            long r2 = android.os.SystemClock.elapsedRealtime()
            int r2 = (r2 > r0 ? 1 : (r2 == r0 ? 0 : -1))
            if (r2 < 0) goto Lc
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r2 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r2 = r2.m1297String$arg0$callfail$funawaitStatus$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            org.junit.Assert.fail(r2)
            return
    }

    private static final void controlsVideoFailureBackgroundStopAndExplicitReconnect$connected(vea.raceremote.UdpControlScreenDeviceTest r4) {
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r4.compose
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r1 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            long r1 = r1.m1285Long$arg0$callwaitUntil$funconnected$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$connected$1 r3 = new vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$connected$1
            r3.<init>(r4)
            kotlin.jvm.functions.Function0 r3 = (kotlin.jvm.functions.Function0) r3
            r0.waitUntil(r1, r3)
            return
    }

    private static final org.json.JSONObject controlsVideoFailureBackgroundStopAndExplicitReconnect$get(okhttp3.OkHttpClient r5, java.lang.String r6, java.lang.String r7) {
            okhttp3.Request$Builder r0 = new okhttp3.Request$Builder
            r0.<init>()
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r2 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r2 = r2.m1287String$0$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$funget$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            java.lang.StringBuilder r1 = r1.append(r2)
            java.lang.StringBuilder r1 = r1.append(r6)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r2 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r2 = r2.m1288String$2$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$funget$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            java.lang.StringBuilder r1 = r1.append(r2)
            java.lang.StringBuilder r1 = r1.append(r7)
            java.lang.String r1 = r1.toString()
            okhttp3.Request$Builder r0 = r0.url(r1)
            okhttp3.Request r0 = r0.build()
            okhttp3.Call r0 = r5.newCall(r0)
            okhttp3.Response r0 = r0.execute()
            java.io.Closeable r0 = (java.io.Closeable) r0
            r1 = r0
            okhttp3.Response r1 = (okhttp3.Response) r1     // Catch: java.lang.Throwable -> L75
            r2 = 0
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L75
            int r3 = r3.m1254Int$arg0$callassertEquals$fun$anonymous$$arg0$calluse$funget$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L75
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch: java.lang.Throwable -> L75
            int r4 = r1.code()     // Catch: java.lang.Throwable -> L75
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)     // Catch: java.lang.Throwable -> L75
            org.junit.Assert.assertEquals(r3, r4)     // Catch: java.lang.Throwable -> L75
            org.json.JSONObject r3 = new org.json.JSONObject     // Catch: java.lang.Throwable -> L75
            okhttp3.ResponseBody r4 = r1.body()     // Catch: java.lang.Throwable -> L75
            if (r4 == 0) goto L69
            java.lang.String r4 = r4.string()     // Catch: java.lang.Throwable -> L75
            r3.<init>(r4)     // Catch: java.lang.Throwable -> L75
            r1 = 0
            kotlin.io.CloseableKt.closeFinally(r0, r1)
            return r3
        L69:
            java.lang.String r3 = "Required value was null."
            java.lang.IllegalArgumentException r4 = new java.lang.IllegalArgumentException     // Catch: java.lang.Throwable -> L75
            java.lang.String r3 = r3.toString()     // Catch: java.lang.Throwable -> L75
            r4.<init>(r3)     // Catch: java.lang.Throwable -> L75
            throw r4     // Catch: java.lang.Throwable -> L75
        L75:
            r1 = move-exception
            throw r1     // Catch: java.lang.Throwable -> L77
        L77:
            r2 = move-exception
            kotlin.io.CloseableKt.closeFinally(r0, r1)
            throw r2
    }

    private static final boolean controlsVideoFailureBackgroundStopAndExplicitReconnect$neutral(org.json.JSONObject r6) {
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r0 = r0.m1300String$arg0$callgetBoolean$$this$callnot$cond$funneutral$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            boolean r0 = r6.getBoolean(r0)
            r1 = 0
            if (r0 != 0) goto L55
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r0 = r0.m1322String$arg0$callgetJSONObject$$$this$calllet$branch$funneutral$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            org.json.JSONObject r0 = r6.getJSONObject(r0)
            r2 = 0
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r3 = r3.m1312String$arg0$callgetInt$arg0$callEQEQ$cond$cond$fun$anonymous$$arg0$calllet$branch$funneutral$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            int r3 = r0.getInt(r3)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r4 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            int r4 = r4.m1271Int$arg1$callEQEQ$cond$cond$fun$anonymous$$arg0$calllet$branch$funneutral$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            r5 = 1
            if (r3 != r4) goto L51
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r3 = r3.m1307String$arg0$callgetInt$arg0$callEQEQ$branch$cond$fun$anonymous$$arg0$calllet$branch$funneutral$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            int r3 = r0.getInt(r3)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r4 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            int r4 = r4.m1266Int$arg1$callEQEQ$branch$cond$fun$anonymous$$arg0$calllet$branch$funneutral$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            if (r3 != r4) goto L51
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r3 = r3.m1311String$arg0$callgetInt$arg0$callEQEQ$branch$fun$anonymous$$arg0$calllet$branch$funneutral$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            int r3 = r0.getInt(r3)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r4 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            int r4 = r4.m1270Int$arg1$callEQEQ$branch$fun$anonymous$$arg0$calllet$branch$funneutral$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            if (r3 != r4) goto L51
            r0 = r5
            goto L52
        L51:
            r0 = r1
        L52:
            if (r0 == 0) goto L55
            r1 = r5
        L55:
            return r1
    }

    private static final void controlsVideoFailureBackgroundStopAndExplicitReconnect$record(org.json.JSONArray r4, long r5, java.lang.String r7, java.lang.Object r8) {
            org.json.JSONObject r0 = new org.json.JSONObject
            r0.<init>()
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r1 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r1 = r1.m1354String$arg0$callput$$this$callput$$this$callput$arg0$callput$funrecord$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            long r2 = android.os.SystemClock.elapsedRealtime()
            long r2 = r2 - r5
            org.json.JSONObject r0 = r0.put(r1, r2)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r1 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r1 = r1.m1356String$arg0$callput$$this$callput$arg0$callput$funrecord$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            org.json.JSONObject r0 = r0.put(r1, r7)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r1 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r1 = r1.m1358String$arg0$callput$arg0$callput$funrecord$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            org.json.JSONObject r0 = r0.put(r1, r8)
            r4.put(r0)
            return
    }

    private static final org.json.JSONObject controlsVideoFailureBackgroundStopAndExplicitReconnect$status(okhttp3.OkHttpClient r5, java.lang.String r6, java.lang.String r7, org.json.JSONArray r8, long r9) {
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r0 = r0.m1298String$arg0$callget$$$this$callalso$funstatus$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            org.json.JSONObject r0 = controlsVideoFailureBackgroundStopAndExplicitReconnect$get(r5, r6, r0)
            r1 = r0
            r2 = 0
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r3 = r3.m1328String$arg0$callgetString$arg1$callassertEquals$fun$anonymous$$arg0$callalso$funstatus$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            java.lang.String r3 = r1.getString(r3)
            org.junit.Assert.assertEquals(r7, r3)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r3 = r3.m1290String$arg0$callassertFalse$fun$anonymous$$arg0$callalso$funstatus$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r4 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r4 = r4.m1302String$arg0$callgetBoolean$arg1$callassertFalse$fun$anonymous$$arg0$callalso$funstatus$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            boolean r4 = r1.getBoolean(r4)
            org.junit.Assert.assertFalse(r3, r4)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r3 = r3.m1289String$arg0$callassertEquals1$fun$anonymous$$arg0$callalso$funstatus$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r4 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r4 = r4.m1329String$arg0$callgetString$arg1$callassertEquals1$fun$anonymous$$arg0$callalso$funstatus$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            java.lang.String r4 = r1.getString(r4)
            org.junit.Assert.assertEquals(r3, r4)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r3 = r3.m1360String$arg0$callrecord$fun$anonymous$$arg0$callalso$funstatus$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            controlsVideoFailureBackgroundStopAndExplicitReconnect$record(r8, r9, r3, r1)
            return r0
    }

    private static final void controlsVideoFailureBackgroundStopAndExplicitReconnect$trace(okhttp3.OkHttpClient r18, java.lang.String r19, org.json.JSONArray r20, long r21, java.lang.String r23) {
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r0 = r0.m1299String$arg0$callget$valvalue$funtrace$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            r1 = r18
            r2 = r19
            org.json.JSONObject r0 = controlsVideoFailureBackgroundStopAndExplicitReconnect$get(r1, r2, r0)
            r3 = r20
            r4 = r21
            r6 = r23
            controlsVideoFailureBackgroundStopAndExplicitReconnect$record(r3, r4, r6, r0)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r7 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r7 = r7.m1321String$arg0$callgetJSONArray$valrows$funtrace$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            org.json.JSONArray r7 = r0.getJSONArray(r7)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r8 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r8 = r8.m1296String$arg0$callassertTrue$funtrace$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            int r9 = r9.m1253Int$$$this$calluntil$$$this$callany$arg1$callassertTrue$funtrace$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            int r10 = r7.length()
            kotlin.ranges.IntRange r9 = kotlin.ranges.RangesKt.until(r9, r10)
            java.lang.Iterable r9 = (java.lang.Iterable) r9
            r10 = 0
            boolean r11 = r9 instanceof java.util.Collection
            if (r11 == 0) goto L49
            r11 = r9
            java.util.Collection r11 = (java.util.Collection) r11
            boolean r11 = r11.isEmpty()
            if (r11 == 0) goto L49
            r17 = r0
            r12 = 0
            goto L85
        L49:
            java.util.Iterator r11 = r9.iterator()
        L4d:
            boolean r13 = r11.hasNext()
            if (r13 == 0) goto L82
            r13 = r11
            kotlin.collections.IntIterator r13 = (kotlin.collections.IntIterator) r13
            int r13 = r13.nextInt()
            r14 = r13
            r15 = 0
            org.json.JSONArray r12 = r7.getJSONArray(r14)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r16 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            r17 = r0
            int r0 = r16.m1257Int$arg0$callgetInt$arg0$callEQEQ$fun$anonymous$$arg0$callany$arg1$callassertTrue$funtrace$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            int r0 = r12.getInt(r0)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r12 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            int r12 = r12.m1274Int$arg1$callEQEQ$fun$anonymous$$arg0$callany$arg1$callassertTrue$funtrace$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            r16 = 1
            if (r0 != r12) goto L79
            r0 = r16
            goto L7a
        L79:
            r0 = 0
        L7a:
            if (r0 == 0) goto L7f
            r12 = r16
            goto L85
        L7f:
            r0 = r17
            goto L4d
        L82:
            r17 = r0
            r12 = 0
        L85:
            org.junit.Assert.assertTrue(r8, r12)
            return
    }

    @org.junit.Test
    public final void controlsVideoFailureBackgroundStopAndExplicitReconnect() {
            r28 = this;
            r1 = r28
            java.lang.String r2 = "JSONObject().put(\"comple…nts\", events).toString(2)"
            android.os.Bundle r3 = androidx.test.platform.app.InstrumentationRegistry.getArguments()
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r0 = r0.m1325String$arg0$callgetString$arg0$callEQEQ$arg0$callassumeTrue$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            java.lang.String r0 = r3.getString(r0)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r4 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r4 = r4.m1367String$arg1$callEQEQ$arg0$callassumeTrue$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r0, r4)
            org.junit.Assume.assumeTrue(r0)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r0 = r0.m1327String$arg0$callgetString$arg0$callrequireNotNull$valhost$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            java.lang.String r0 = r3.getString(r0)
            java.lang.String r4 = "Required value was null."
            if (r0 == 0) goto L665
            java.lang.String r5 = "requireNotNull(args.getString(\"driveBenchHost\"))"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r5)
            r5 = r0
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r0 = r0.m1326String$arg0$callgetString$arg0$callrequireNotNull$valexpectedCar$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            java.lang.String r8 = r3.getString(r0)
            if (r8 == 0) goto L65b
            java.lang.String r0 = "requireNotNull(args.getString(\"driveBenchCarId\"))"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r0)
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose
            androidx.activity.ComponentActivity r0 = r0.getActivity()
            r15 = r0
            vea.raceremote.app.MainActivity r15 = (vea.raceremote.app.MainActivity) r15
            java.lang.Class<android.net.ConnectivityManager> r0 = android.net.ConnectivityManager.class
            java.lang.Object r0 = r15.getSystemService(r0)
            r13 = r0
            android.net.ConnectivityManager r13 = (android.net.ConnectivityManager) r13
            android.net.Network[] r0 = r13.getAllNetworks()
            java.lang.String r6 = "cm.allNetworks"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r6)
            java.lang.Object[] r0 = (java.lang.Object[]) r0
            r6 = 0
            int r7 = r0.length
            r9 = 0
        L64:
            r12 = 1
            if (r9 >= r7) goto L89
            r11 = r0[r9]
            r10 = r11
            android.net.Network r10 = (android.net.Network) r10
            r17 = 0
            android.net.NetworkCapabilities r14 = r13.getNetworkCapabilities(r10)
            if (r14 == 0) goto L82
            boolean r14 = r14.hasTransport(r12)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r19 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            boolean r12 = r19.m1240Boolean$arg1$callEQEQ$fun$anonymous$$arg0$callfirstOrNull$arg0$callrequireNotNull$valwifi$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            if (r14 != r12) goto L82
            r10 = 1
            goto L83
        L82:
            r10 = 0
        L83:
            if (r10 == 0) goto L86
            goto L8a
        L86:
            int r9 = r9 + 1
            goto L64
        L89:
            r11 = 0
        L8a:
            if (r11 == 0) goto L651
            r4 = r11
            android.net.Network r4 = (android.net.Network) r4
            okhttp3.OkHttpClient$Builder r0 = new okhttp3.OkHttpClient$Builder
            r0.<init>()
            javax.net.SocketFactory r6 = r4.getSocketFactory()
            okhttp3.OkHttpClient$Builder r0 = r0.socketFactory(r6)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r6 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            long r6 = r6.m1282Long$arg0$callconnectTimeout$$this$callreadTimeout$$this$callcallTimeout$$this$callbuild$valhttp$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            java.util.concurrent.TimeUnit r9 = java.util.concurrent.TimeUnit.SECONDS
            okhttp3.OkHttpClient$Builder r0 = r0.connectTimeout(r6, r9)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r6 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            long r6 = r6.m1283Long$arg0$callreadTimeout$$this$callcallTimeout$$this$callbuild$valhttp$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            java.util.concurrent.TimeUnit r9 = java.util.concurrent.TimeUnit.SECONDS
            okhttp3.OkHttpClient$Builder r0 = r0.readTimeout(r6, r9)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r6 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            long r6 = r6.m1281Long$arg0$callcallTimeout$$this$callbuild$valhttp$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            java.util.concurrent.TimeUnit r9 = java.util.concurrent.TimeUnit.SECONDS
            okhttp3.OkHttpClient$Builder r0 = r0.callTimeout(r6, r9)
            okhttp3.OkHttpClient r6 = r0.build()
            org.json.JSONArray r0 = new org.json.JSONArray
            r0.<init>()
            r14 = r0
            long r10 = android.os.SystemClock.elapsedRealtime()
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            boolean r12 = r0.m1246Boolean$valcomplete$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            okhttp3.mockwebserver.MockWebServer r0 = new okhttp3.mockwebserver.MockWebServer
            r0.<init>()
            r9 = r0
            okhttp3.mockwebserver.MockResponse r0 = new okhttp3.mockwebserver.MockResponse
            r0.<init>()
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r7 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            int r7 = r7.m1261Int$arg0$callsetResponseCode$arg0$callenqueue$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            okhttp3.mockwebserver.MockResponse r0 = r0.setResponseCode(r7)
            r9.enqueue(r0)
            r9.start()
            r7 = 2
            r17 = r3
            r3 = r7
            r7 = r5
            r21 = r9
            r9 = r14
            r16 = r4
            r22 = r10
            r4 = 0
            org.json.JSONObject r0 = controlsVideoFailureBackgroundStopAndExplicitReconnect$status(r6, r7, r8, r9, r10)     // Catch: java.lang.Throwable -> L54f
            boolean r0 = controlsVideoFailureBackgroundStopAndExplicitReconnect$neutral(r0)     // Catch: java.lang.Throwable -> L54f
            org.junit.Assert.assertTrue(r0)     // Catch: java.lang.Throwable -> L54f
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose     // Catch: java.lang.Throwable -> L54f
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r0 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r0     // Catch: java.lang.Throwable -> L54f
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r7 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L54f
            java.lang.String r7 = r7.m1344String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L54f
            r9 = 0
            androidx.compose.ui.test.SemanticsNodeInteraction r0 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r0, r7, r9, r3, r4)     // Catch: java.lang.Throwable -> L54f
            androidx.compose.ui.test.TextActionsKt.performTextReplacement(r0, r5)     // Catch: java.lang.Throwable -> L54f
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose     // Catch: java.lang.Throwable -> L54f
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r0 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r0     // Catch: java.lang.Throwable -> L54f
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r7 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L54f
            java.lang.String r7 = r7.m1337String$arg0$callonNodeWithTag$$$this$callperformClick$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L54f
            r11 = 0
            androidx.compose.ui.test.SemanticsNodeInteraction r0 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r0, r7, r11, r3, r4)     // Catch: java.lang.Throwable -> L54f
            androidx.compose.ui.test.ActionsKt.performClick(r0)     // Catch: java.lang.Throwable -> L54f
            controlsVideoFailureBackgroundStopAndExplicitReconnect$connected(r28)     // Catch: java.lang.Throwable -> L54f
            vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$1 r0 = vea.raceremote.UdpControlScreenDeviceTest.AnonymousClass1.INSTANCE     // Catch: java.lang.Throwable -> L54f
            kotlin.jvm.functions.Function1 r0 = (kotlin.jvm.functions.Function1) r0     // Catch: java.lang.Throwable -> L54f
            r9 = r6
            r10 = r5
            r7 = r11
            r11 = r8
            r7 = r12
            r12 = r14
            r20 = r7
            r18 = r13
            r19 = r14
            r7 = 0
            r13 = r22
            r25 = r15
            r15 = r0
            controlsVideoFailureBackgroundStopAndExplicitReconnect$awaitStatus(r9, r10, r11, r12, r13, r15)     // Catch: java.lang.Throwable -> L547
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose     // Catch: java.lang.Throwable -> L547
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r0 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r0     // Catch: java.lang.Throwable -> L547
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L547
            java.lang.String r9 = r9.m1338String$arg0$callonNodeWithTag$$$this$callperformClick1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L547
            androidx.compose.ui.test.SemanticsNodeInteraction r0 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r0, r9, r7, r3, r4)     // Catch: java.lang.Throwable -> L547
            androidx.compose.ui.test.ActionsKt.performClick(r0)     // Catch: java.lang.Throwable -> L547
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose     // Catch: java.lang.Throwable -> L547
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r0 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r0     // Catch: java.lang.Throwable -> L547
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L547
            java.lang.String r9 = r9.m1345String$arg0$callonNodeWithTag$$$this$callperformTextReplacement1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L547
            androidx.compose.ui.test.SemanticsNodeInteraction r0 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r0, r9, r7, r3, r4)     // Catch: java.lang.Throwable -> L547
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L547
            java.lang.String r9 = r9.m1365String$arg0$callurl$$this$calltoString$arg0$callperformTextReplacement1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L547
            r15 = r21
            okhttp3.HttpUrl r9 = r15.url(r9)     // Catch: java.lang.Throwable -> L53f
            java.lang.String r9 = r9.toString()     // Catch: java.lang.Throwable -> L53f
            java.lang.String r10 = "video.url(\"/stream\").toString()"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r9, r10)     // Catch: java.lang.Throwable -> L53f
            androidx.compose.ui.test.TextActionsKt.performTextReplacement(r0, r9)     // Catch: java.lang.Throwable -> L53f
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose     // Catch: java.lang.Throwable -> L53f
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r0 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r0     // Catch: java.lang.Throwable -> L53f
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L53f
            java.lang.String r9 = r9.m1339String$arg0$callonNodeWithTag$$$this$callperformClick2$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L53f
            androidx.compose.ui.test.SemanticsNodeInteraction r0 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r0, r9, r7, r3, r4)     // Catch: java.lang.Throwable -> L53f
            androidx.compose.ui.test.ActionsKt.performClick(r0)     // Catch: java.lang.Throwable -> L53f
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose     // Catch: java.lang.Throwable -> L53f
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L53f
            long r9 = r9.m1286Long$arg0$callwaitUntil$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L53f
            vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$2 r11 = new vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$2     // Catch: java.lang.Throwable -> L53f
            r11.<init>(r1)     // Catch: java.lang.Throwable -> L53f
            kotlin.jvm.functions.Function0 r11 = (kotlin.jvm.functions.Function0) r11     // Catch: java.lang.Throwable -> L53f
            r0.waitUntil(r9, r11)     // Catch: java.lang.Throwable -> L53f
            controlsVideoFailureBackgroundStopAndExplicitReconnect$connected(r28)     // Catch: java.lang.Throwable -> L53f
            r9 = r6
            r10 = r5
            r11 = r8
            r12 = r19
            r13 = r22
            org.json.JSONObject r0 = controlsVideoFailureBackgroundStopAndExplicitReconnect$status(r9, r10, r11, r12, r13)     // Catch: java.lang.Throwable -> L53f
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L53f
            java.lang.String r9 = r9.m1301String$arg0$callgetBoolean$arg0$callassertTrue1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L53f
            boolean r0 = r0.getBoolean(r9)     // Catch: java.lang.Throwable -> L53f
            org.junit.Assert.assertTrue(r0)     // Catch: java.lang.Throwable -> L53f
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L53f
            java.lang.String r0 = r0.m1361String$arg0$callrecord$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L53f
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L53f
            boolean r9 = r9.m1243Boolean$arg1$callrecord$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L53f
            java.lang.Boolean r9 = java.lang.Boolean.valueOf(r9)     // Catch: java.lang.Throwable -> L53f
            r13 = r19
            r11 = r22
            controlsVideoFailureBackgroundStopAndExplicitReconnect$record(r13, r11, r0, r9)     // Catch: java.lang.Throwable -> L539
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose     // Catch: java.lang.Throwable -> L539
            vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$3 r9 = new vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$3     // Catch: java.lang.Throwable -> L539
            r14 = r25
            r9.<init>(r14)     // Catch: java.lang.Throwable -> L531
            kotlin.jvm.functions.Function0 r9 = (kotlin.jvm.functions.Function0) r9     // Catch: java.lang.Throwable -> L531
            r0.runOnIdle(r9)     // Catch: java.lang.Throwable -> L531
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose     // Catch: java.lang.Throwable -> L531
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r0 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r0     // Catch: java.lang.Throwable -> L531
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L531
            java.lang.String r9 = r9.m1340String$arg0$callonNodeWithTag$$$this$callperformClick3$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L531
            androidx.compose.ui.test.SemanticsNodeInteraction r0 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r0, r9, r7, r3, r4)     // Catch: java.lang.Throwable -> L531
            androidx.compose.ui.test.ActionsKt.performClick(r0)     // Catch: java.lang.Throwable -> L531
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose     // Catch: java.lang.Throwable -> L531
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r0 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r0     // Catch: java.lang.Throwable -> L531
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L531
            java.lang.String r9 = r9.m1349String$arg0$callonNodeWithTag$$this$callfetchSemanticsNode$$this$call$getboundsInRoot$$valgas$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L531
            androidx.compose.ui.test.SemanticsNodeInteraction r0 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r0, r9, r7, r3, r4)     // Catch: java.lang.Throwable -> L531
            r10 = 1
            androidx.compose.ui.semantics.SemanticsNode r0 = androidx.compose.ui.test.SemanticsNodeInteraction.fetchSemanticsNode$default(r0, r4, r10, r4)     // Catch: java.lang.Throwable -> L531
            androidx.compose.ui.geometry.Rect r0 = r0.getBoundsInRoot()     // Catch: java.lang.Throwable -> L531
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r9 = r1.compose     // Catch: java.lang.Throwable -> L531
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r9 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r9     // Catch: java.lang.Throwable -> L531
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r19 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L531
            java.lang.String r10 = r19.m1350String$arg0$callonNodeWithTag$$this$callfetchSemanticsNode$$this$call$getboundsInRoot$$valwheel$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L531
            androidx.compose.ui.test.SemanticsNodeInteraction r9 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r9, r10, r7, r3, r4)     // Catch: java.lang.Throwable -> L531
            r10 = 1
            androidx.compose.ui.semantics.SemanticsNode r9 = androidx.compose.ui.test.SemanticsNodeInteraction.fetchSemanticsNode$default(r9, r4, r10, r4)     // Catch: java.lang.Throwable -> L531
            androidx.compose.ui.geometry.Rect r9 = r9.getBoundsInRoot()     // Catch: java.lang.Throwable -> L531
            r10 = r9
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r9 = r1.compose     // Catch: java.lang.Throwable -> L531
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r9 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r9     // Catch: java.lang.Throwable -> L531
            r3 = 1
            androidx.compose.ui.test.SemanticsNodeInteraction r9 = androidx.compose.ui.test.FindersKt.onRoot$default(r9, r7, r3, r4)     // Catch: java.lang.Throwable -> L531
            vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$4 r3 = new vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$4     // Catch: java.lang.Throwable -> L531
            r3.<init>(r0, r10)     // Catch: java.lang.Throwable -> L531
            kotlin.jvm.functions.Function1 r3 = (kotlin.jvm.functions.Function1) r3     // Catch: java.lang.Throwable -> L531
            androidx.compose.ui.test.ActionsKt.performTouchInput(r9, r3)     // Catch: java.lang.Throwable -> L531
            vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$5 r3 = vea.raceremote.UdpControlScreenDeviceTest.AnonymousClass5.INSTANCE     // Catch: java.lang.Throwable -> L531
            kotlin.jvm.functions.Function1 r3 = (kotlin.jvm.functions.Function1) r3     // Catch: java.lang.Throwable -> L531
            r9 = r6
            r22 = r0
            r21 = r10
            r0 = 1
            r10 = r5
            r23 = r11
            r11 = r8
            r12 = r13
            r26 = r13
            r25 = r14
            r13 = r23
            r27 = r15
            r15 = r3
            controlsVideoFailureBackgroundStopAndExplicitReconnect$awaitStatus(r9, r10, r11, r12, r13, r15)     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r3 = r1.compose     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r3 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r3     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.SemanticsNodeInteraction r3 = androidx.compose.ui.test.FindersKt.onRoot$default(r3, r7, r0, r4)     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$6 r9 = vea.raceremote.UdpControlScreenDeviceTest.AnonymousClass6.INSTANCE     // Catch: java.lang.Throwable -> L52b
            kotlin.jvm.functions.Function1 r9 = (kotlin.jvm.functions.Function1) r9     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.ActionsKt.performTouchInput(r3, r9)     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$7 r3 = vea.raceremote.UdpControlScreenDeviceTest.AnonymousClass7.INSTANCE     // Catch: java.lang.Throwable -> L52b
            r15 = r3
            kotlin.jvm.functions.Function1 r15 = (kotlin.jvm.functions.Function1) r15     // Catch: java.lang.Throwable -> L52b
            r9 = r6
            r10 = r5
            r11 = r8
            r12 = r26
            r13 = r23
            controlsVideoFailureBackgroundStopAndExplicitReconnect$awaitStatus(r9, r10, r11, r12, r13, r15)     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r3 = r1.compose     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r3 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r3     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.SemanticsNodeInteraction r0 = androidx.compose.ui.test.FindersKt.onRoot$default(r3, r7, r0, r4)     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$8 r3 = vea.raceremote.UdpControlScreenDeviceTest.AnonymousClass8.INSTANCE     // Catch: java.lang.Throwable -> L52b
            kotlin.jvm.functions.Function1 r3 = (kotlin.jvm.functions.Function1) r3     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.ActionsKt.performTouchInput(r0, r3)     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$9 r0 = vea.raceremote.UdpControlScreenDeviceTest.AnonymousClass9.INSTANCE     // Catch: java.lang.Throwable -> L52b
            r15 = r0
            kotlin.jvm.functions.Function1 r15 = (kotlin.jvm.functions.Function1) r15     // Catch: java.lang.Throwable -> L52b
            r9 = r6
            r10 = r5
            r11 = r8
            r12 = r26
            r13 = r23
            controlsVideoFailureBackgroundStopAndExplicitReconnect$awaitStatus(r9, r10, r11, r12, r13, r15)     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r0 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r0     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L52b
            java.lang.String r3 = r3.m1347String$arg0$callonNodeWithTag$$$this$callperformTouchInput3$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L52b
            r9 = 2
            androidx.compose.ui.test.SemanticsNodeInteraction r0 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r0, r3, r7, r9, r4)     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$10 r3 = vea.raceremote.UdpControlScreenDeviceTest.AnonymousClass10.INSTANCE     // Catch: java.lang.Throwable -> L52b
            kotlin.jvm.functions.Function1 r3 = (kotlin.jvm.functions.Function1) r3     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.ActionsKt.performTouchInput(r0, r3)     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$11 r0 = vea.raceremote.UdpControlScreenDeviceTest.AnonymousClass11.INSTANCE     // Catch: java.lang.Throwable -> L52b
            r15 = r0
            kotlin.jvm.functions.Function1 r15 = (kotlin.jvm.functions.Function1) r15     // Catch: java.lang.Throwable -> L52b
            r9 = r6
            r10 = r5
            r11 = r8
            r12 = r26
            r13 = r23
            controlsVideoFailureBackgroundStopAndExplicitReconnect$awaitStatus(r9, r10, r11, r12, r13, r15)     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose     // Catch: java.lang.Throwable -> L52b
            org.junit.rules.TestRule r0 = r0.getActivityRule()     // Catch: java.lang.Throwable -> L52b
            androidx.test.ext.junit.rules.ActivityScenarioRule r0 = (androidx.test.ext.junit.rules.ActivityScenarioRule) r0     // Catch: java.lang.Throwable -> L52b
            androidx.test.core.app.ActivityScenario r0 = r0.getScenario()     // Catch: java.lang.Throwable -> L52b
            androidx.lifecycle.Lifecycle$State r3 = androidx.lifecycle.Lifecycle.State.STARTED     // Catch: java.lang.Throwable -> L52b
            r0.moveToState(r3)     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$12 r0 = vea.raceremote.UdpControlScreenDeviceTest.AnonymousClass12.INSTANCE     // Catch: java.lang.Throwable -> L52b
            r15 = r0
            kotlin.jvm.functions.Function1 r15 = (kotlin.jvm.functions.Function1) r15     // Catch: java.lang.Throwable -> L52b
            r9 = r6
            r10 = r5
            r11 = r8
            r12 = r26
            r13 = r23
            controlsVideoFailureBackgroundStopAndExplicitReconnect$awaitStatus(r9, r10, r11, r12, r13, r15)     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L52b
            java.lang.String r14 = r0.m1363String$arg0$calltrace$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L52b
            r9 = r6
            r10 = r5
            r11 = r26
            r12 = r23
            controlsVideoFailureBackgroundStopAndExplicitReconnect$trace(r9, r10, r11, r12, r14)     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose     // Catch: java.lang.Throwable -> L52b
            org.junit.rules.TestRule r0 = r0.getActivityRule()     // Catch: java.lang.Throwable -> L52b
            androidx.test.ext.junit.rules.ActivityScenarioRule r0 = (androidx.test.ext.junit.rules.ActivityScenarioRule) r0     // Catch: java.lang.Throwable -> L52b
            androidx.test.core.app.ActivityScenario r0 = r0.getScenario()     // Catch: java.lang.Throwable -> L52b
            androidx.lifecycle.Lifecycle$State r3 = androidx.lifecycle.Lifecycle.State.RESUMED     // Catch: java.lang.Throwable -> L52b
            r0.moveToState(r3)     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r0 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r0     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L52b
            java.lang.String r3 = r3.m1330String$arg0$callonNodeWithTag$$$this$callassertIsNotEnabled$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L52b
            r9 = 2
            androidx.compose.ui.test.SemanticsNodeInteraction r0 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r0, r3, r7, r9, r4)     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.AssertionsKt.assertIsNotEnabled(r0)     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r0 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r0     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L52b
            java.lang.String r3 = r3.m1334String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L52b
            r9 = 2
            androidx.compose.ui.test.SemanticsNodeInteraction r10 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r0, r3, r7, r9, r4)     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L52b
            java.lang.String r11 = r0.m1293String$arg0$callassertTextContains$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L52b
            boolean r12 = r0.m1242Boolean$arg1$callassertTextContains$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L52b
            r13 = 0
            r14 = 4
            r15 = 0
            androidx.compose.ui.test.AssertionsKt.assertTextContains$default(r10, r11, r12, r13, r14, r15)     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r0 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r0     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L52b
            java.lang.String r3 = r3.m1348String$arg0$callonNodeWithTag$$$this$callperformTouchInput4$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L52b
            r9 = 2
            androidx.compose.ui.test.SemanticsNodeInteraction r0 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r0, r3, r7, r9, r4)     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$13 r3 = vea.raceremote.UdpControlScreenDeviceTest.AnonymousClass13.INSTANCE     // Catch: java.lang.Throwable -> L52b
            kotlin.jvm.functions.Function1 r3 = (kotlin.jvm.functions.Function1) r3     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.ActionsKt.performTouchInput(r0, r3)     // Catch: java.lang.Throwable -> L52b
            r9 = r6
            r10 = r5
            r11 = r8
            r12 = r26
            r13 = r23
            org.json.JSONObject r0 = controlsVideoFailureBackgroundStopAndExplicitReconnect$status(r9, r10, r11, r12, r13)     // Catch: java.lang.Throwable -> L52b
            boolean r0 = controlsVideoFailureBackgroundStopAndExplicitReconnect$neutral(r0)     // Catch: java.lang.Throwable -> L52b
            org.junit.Assert.assertTrue(r0)     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r0 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r0     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L52b
            java.lang.String r3 = r3.m1341String$arg0$callonNodeWithTag$$$this$callperformClick4$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L52b
            r9 = 2
            androidx.compose.ui.test.SemanticsNodeInteraction r0 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r0, r3, r7, r9, r4)     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.ActionsKt.performClick(r0)     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r0 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r0     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L52b
            java.lang.String r3 = r3.m1342String$arg0$callonNodeWithTag$$$this$callperformClick5$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L52b
            r9 = 2
            androidx.compose.ui.test.SemanticsNodeInteraction r0 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r0, r3, r7, r9, r4)     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.ActionsKt.performClick(r0)     // Catch: java.lang.Throwable -> L52b
            controlsVideoFailureBackgroundStopAndExplicitReconnect$connected(r28)     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$14 r0 = vea.raceremote.UdpControlScreenDeviceTest.AnonymousClass14.INSTANCE     // Catch: java.lang.Throwable -> L52b
            r15 = r0
            kotlin.jvm.functions.Function1 r15 = (kotlin.jvm.functions.Function1) r15     // Catch: java.lang.Throwable -> L52b
            r9 = r6
            r10 = r5
            r11 = r8
            r12 = r26
            r13 = r23
            controlsVideoFailureBackgroundStopAndExplicitReconnect$awaitStatus(r9, r10, r11, r12, r13, r15)     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r0 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r0     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L52b
            java.lang.String r3 = r3.m1343String$arg0$callonNodeWithTag$$$this$callperformClick6$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L52b
            r9 = 2
            androidx.compose.ui.test.SemanticsNodeInteraction r0 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r0, r3, r7, r9, r4)     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.ActionsKt.performClick(r0)     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$15 r0 = vea.raceremote.UdpControlScreenDeviceTest.AnonymousClass15.INSTANCE     // Catch: java.lang.Throwable -> L52b
            r15 = r0
            kotlin.jvm.functions.Function1 r15 = (kotlin.jvm.functions.Function1) r15     // Catch: java.lang.Throwable -> L52b
            r9 = r6
            r10 = r5
            r11 = r8
            r12 = r26
            r13 = r23
            controlsVideoFailureBackgroundStopAndExplicitReconnect$awaitStatus(r9, r10, r11, r12, r13, r15)     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L52b
            java.lang.String r14 = r0.m1364String$arg0$calltrace1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L52b
            r9 = r6
            r10 = r5
            r11 = r26
            r12 = r23
            controlsVideoFailureBackgroundStopAndExplicitReconnect$trace(r9, r10, r11, r12, r14)     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r0 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r0     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L52b
            java.lang.String r3 = r3.m1331String$arg0$callonNodeWithTag$$$this$callassertIsNotEnabled1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L52b
            r9 = 2
            androidx.compose.ui.test.SemanticsNodeInteraction r0 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r0, r3, r7, r9, r4)     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.AssertionsKt.assertIsNotEnabled(r0)     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r0 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r0     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L52b
            java.lang.String r3 = r3.m1346String$arg0$callonNodeWithTag$$$this$callperformTextReplacement2$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L52b
            r9 = 2
            androidx.compose.ui.test.SemanticsNodeInteraction r0 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r0, r3, r7, r9, r4)     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L52b
            java.lang.String r3 = r3.m1351String$arg0$callperformTextReplacement2$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.TextActionsKt.performTextReplacement(r0, r3)     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r0 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r0     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L52b
            java.lang.String r3 = r3.m1335String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L52b
            r9 = 2
            androidx.compose.ui.test.SemanticsNodeInteraction r10 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r0, r3, r7, r9, r4)     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L52b
            java.lang.String r11 = r0.m1294String$arg0$callassertTextContains1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L52b
            r12 = 0
            r13 = 0
            r14 = 6
            r15 = 0
            androidx.compose.ui.test.AssertionsKt.assertTextContains$default(r10, r11, r12, r13, r14, r15)     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose     // Catch: java.lang.Throwable -> L52b
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r0 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r0     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L52b
            java.lang.String r3 = r3.m1336String$arg0$callonNodeWithTag$$$this$callassertTextContains2$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L52b
            r9 = 2
            androidx.compose.ui.test.SemanticsNodeInteraction r10 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r0, r3, r7, r9, r4)     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L52b
            java.lang.String r11 = r0.m1295String$arg0$callassertTextContains2$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L52b
            r12 = 0
            r13 = 0
            r14 = 6
            r15 = 0
            androidx.compose.ui.test.AssertionsKt.assertTextContains$default(r10, r11, r12, r13, r14, r15)     // Catch: java.lang.Throwable -> L52b
            r9 = r6
            r10 = r5
            r11 = r8
            r12 = r26
            r13 = r23
            org.json.JSONObject r0 = controlsVideoFailureBackgroundStopAndExplicitReconnect$status(r9, r10, r11, r12, r13)     // Catch: java.lang.Throwable -> L52b
            boolean r0 = controlsVideoFailureBackgroundStopAndExplicitReconnect$neutral(r0)     // Catch: java.lang.Throwable -> L52b
            org.junit.Assert.assertTrue(r0)     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L52b
            java.lang.String r0 = r0.m1362String$arg0$callrecord1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L52b
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L52b
            boolean r3 = r3.m1244Boolean$arg1$callrecord1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L52b
            java.lang.Boolean r3 = java.lang.Boolean.valueOf(r3)     // Catch: java.lang.Throwable -> L52b
            r9 = r23
            r7 = r26
            controlsVideoFailureBackgroundStopAndExplicitReconnect$record(r7, r9, r0, r3)     // Catch: java.lang.Throwable -> L529
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L529
            boolean r0 = r0.m1245Boolean$setcomplete$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L529
            r3 = r0
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose     // Catch: java.lang.Throwable -> L4c0
            org.junit.rules.TestRule r0 = r0.getActivityRule()     // Catch: java.lang.Throwable -> L4c0
            androidx.test.ext.junit.rules.ActivityScenarioRule r0 = (androidx.test.ext.junit.rules.ActivityScenarioRule) r0     // Catch: java.lang.Throwable -> L4c0
            androidx.test.core.app.ActivityScenario r0 = r0.getScenario()     // Catch: java.lang.Throwable -> L4c0
            androidx.lifecycle.Lifecycle$State r11 = androidx.lifecycle.Lifecycle.State.STARTED     // Catch: java.lang.Throwable -> L4c0
            r0.moveToState(r11)     // Catch: java.lang.Throwable -> L4c0
            java.io.File r0 = new java.io.File
            java.io.File r11 = r25.getFilesDir()
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r12 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r12 = r12.m1366String$arg1$call$init$$$$this$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            r0.<init>(r11, r12)
            org.json.JSONObject r11 = new org.json.JSONObject
            r11.<init>()
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r12 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r12 = r12.m1352String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            org.json.JSONObject r11 = r11.put(r12, r3)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r12 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r12 = r12.m1353String$arg0$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            org.json.JSONObject r11 = r11.put(r12, r5)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r12 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r12 = r12.m1355String$arg0$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            long r13 = android.os.SystemClock.elapsedRealtime()
            long r13 = r13 - r9
            org.json.JSONObject r11 = r11.put(r12, r13)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r12 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r12 = r12.m1357String$arg0$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            org.json.JSONObject r11 = r11.put(r12, r7)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r12 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            int r12 = r12.m1262Int$arg0$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            java.lang.String r11 = r11.toString(r12)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r11, r2)
            r2 = 2
            kotlin.io.FilesKt.writeText$default(r0, r11, r4, r2, r4)
            r27.shutdown()
            okhttp3.ConnectionPool r0 = r6.connectionPool()
            r0.evictAll()
            okhttp3.Dispatcher r0 = r6.dispatcher()
            java.util.concurrent.ExecutorService r0 = r0.executorService()
            r0.shutdown()
            return
        L4c0:
            r0 = move-exception
            java.io.File r11 = new java.io.File
            java.io.File r12 = r25.getFilesDir()
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r13 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r13 = r13.m1366String$arg1$call$init$$$$this$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            r11.<init>(r12, r13)
            org.json.JSONObject r12 = new org.json.JSONObject
            r12.<init>()
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r13 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r13 = r13.m1352String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            org.json.JSONObject r12 = r12.put(r13, r3)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r13 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r13 = r13.m1353String$arg0$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            org.json.JSONObject r12 = r12.put(r13, r5)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r13 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r13 = r13.m1355String$arg0$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            long r14 = android.os.SystemClock.elapsedRealtime()
            long r14 = r14 - r9
            org.json.JSONObject r12 = r12.put(r13, r14)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r13 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r13 = r13.m1357String$arg0$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            org.json.JSONObject r12 = r12.put(r13, r7)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r13 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            int r13 = r13.m1262Int$arg0$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            java.lang.String r12 = r12.toString(r13)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r12, r2)
            r2 = 2
            kotlin.io.FilesKt.writeText$default(r11, r12, r4, r2, r4)
            r27.shutdown()
            okhttp3.ConnectionPool r2 = r6.connectionPool()
            r2.evictAll()
            okhttp3.Dispatcher r2 = r6.dispatcher()
            java.util.concurrent.ExecutorService r2 = r2.executorService()
            r2.shutdown()
            throw r0
        L529:
            r0 = move-exception
            goto L55b
        L52b:
            r0 = move-exception
            r9 = r23
            r7 = r26
            goto L55b
        L531:
            r0 = move-exception
            r9 = r11
            r7 = r13
            r25 = r14
            r27 = r15
            goto L55b
        L539:
            r0 = move-exception
            r9 = r11
            r7 = r13
            r27 = r15
            goto L55b
        L53f:
            r0 = move-exception
            r27 = r15
            r7 = r19
            r9 = r22
            goto L55b
        L547:
            r0 = move-exception
            r7 = r19
            r27 = r21
            r9 = r22
            goto L55b
        L54f:
            r0 = move-exception
            r20 = r12
            r18 = r13
            r7 = r14
            r25 = r15
            r27 = r21
            r9 = r22
        L55b:
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L569
            java.lang.String r3 = r3.m1359String$arg0$callrecord$catch$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()     // Catch: java.lang.Throwable -> L569
            java.lang.String r11 = r0.toString()     // Catch: java.lang.Throwable -> L569
            controlsVideoFailureBackgroundStopAndExplicitReconnect$record(r7, r9, r3, r11)     // Catch: java.lang.Throwable -> L569
            throw r0     // Catch: java.lang.Throwable -> L569
        L569:
            r0 = move-exception
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r3 = r1.compose     // Catch: java.lang.Throwable -> L5e6
            org.junit.rules.TestRule r3 = r3.getActivityRule()     // Catch: java.lang.Throwable -> L5e6
            androidx.test.ext.junit.rules.ActivityScenarioRule r3 = (androidx.test.ext.junit.rules.ActivityScenarioRule) r3     // Catch: java.lang.Throwable -> L5e6
            androidx.test.core.app.ActivityScenario r3 = r3.getScenario()     // Catch: java.lang.Throwable -> L5e6
            androidx.lifecycle.Lifecycle$State r11 = androidx.lifecycle.Lifecycle.State.STARTED     // Catch: java.lang.Throwable -> L5e6
            r3.moveToState(r11)     // Catch: java.lang.Throwable -> L5e6
            java.io.File r3 = new java.io.File
            java.io.File r11 = r25.getFilesDir()
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r12 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r12 = r12.m1366String$arg1$call$init$$$$this$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            r3.<init>(r11, r12)
            org.json.JSONObject r11 = new org.json.JSONObject
            r11.<init>()
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r12 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r12 = r12.m1352String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            r13 = r20
            org.json.JSONObject r11 = r11.put(r12, r13)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r12 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r12 = r12.m1353String$arg0$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            org.json.JSONObject r11 = r11.put(r12, r5)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r12 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r12 = r12.m1355String$arg0$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            long r14 = android.os.SystemClock.elapsedRealtime()
            long r14 = r14 - r9
            org.json.JSONObject r11 = r11.put(r12, r14)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r12 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r12 = r12.m1357String$arg0$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            org.json.JSONObject r11 = r11.put(r12, r7)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r12 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            int r12 = r12.m1262Int$arg0$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            java.lang.String r11 = r11.toString(r12)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r11, r2)
            r2 = 2
            kotlin.io.FilesKt.writeText$default(r3, r11, r4, r2, r4)
            r27.shutdown()
            okhttp3.ConnectionPool r2 = r6.connectionPool()
            r2.evictAll()
            okhttp3.Dispatcher r2 = r6.dispatcher()
            java.util.concurrent.ExecutorService r2 = r2.executorService()
            r2.shutdown()
            throw r0
        L5e6:
            r0 = move-exception
            r13 = r20
            java.io.File r3 = new java.io.File
            java.io.File r11 = r25.getFilesDir()
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r12 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r12 = r12.m1366String$arg1$call$init$$$$this$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            r3.<init>(r11, r12)
            org.json.JSONObject r11 = new org.json.JSONObject
            r11.<init>()
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r12 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r12 = r12.m1352String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            org.json.JSONObject r11 = r11.put(r12, r13)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r12 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r12 = r12.m1353String$arg0$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            org.json.JSONObject r11 = r11.put(r12, r5)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r12 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r12 = r12.m1355String$arg0$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            long r14 = android.os.SystemClock.elapsedRealtime()
            long r14 = r14 - r9
            org.json.JSONObject r11 = r11.put(r12, r14)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r12 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            java.lang.String r12 = r12.m1357String$arg0$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            org.json.JSONObject r11 = r11.put(r12, r7)
            vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt r12 = vea.raceremote.LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE
            int r12 = r12.m1262Int$arg0$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()
            java.lang.String r11 = r11.toString(r12)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r11, r2)
            r2 = 2
            kotlin.io.FilesKt.writeText$default(r3, r11, r4, r2, r4)
            r27.shutdown()
            okhttp3.ConnectionPool r2 = r6.connectionPool()
            r2.evictAll()
            okhttp3.Dispatcher r2 = r6.dispatcher()
            java.util.concurrent.ExecutorService r2 = r2.executorService()
            r2.shutdown()
            throw r0
        L651:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r2 = r4.toString()
            r0.<init>(r2)
            throw r0
        L65b:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r2 = r4.toString()
            r0.<init>(r2)
            throw r0
        L665:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r2 = r4.toString()
            r0.<init>(r2)
            throw r0
    }

    @org.junit.Rule
    public final androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> getCompose() {
            r1 = this;
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose
            return r0
    }
}
