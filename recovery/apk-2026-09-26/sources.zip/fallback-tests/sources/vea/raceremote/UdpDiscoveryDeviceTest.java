package vea.raceremote;

/* JADX INFO: compiled from: UdpDiscoveryDeviceTest.kt */
/* JADX INFO: loaded from: classes4.dex */
@kotlin.Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\t\u001a\u00020\nH\u0007R%\u0010\u0003\u001a\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0004\u0012\u00020\u00060\u00048G¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b¨\u0006\u000b"}, d2 = {"Lvea/raceremote/UdpDiscoveryDeviceTest;", "", "()V", "compose", "Landroidx/compose/ui/test/junit4/AndroidComposeTestRule;", "Landroidx/test/ext/junit/rules/ActivityScenarioRule;", "Lvea/raceremote/app/MainActivity;", "getCompose", "()Landroidx/compose/ui/test/junit4/AndroidComposeTestRule;", "searchSelectWithoutArmThenConnectAndReportBusy", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class UdpDiscoveryDeviceTest {
    public static final int $stable = 0;
    private final androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> compose;





    static {
            int r0 = androidx.compose.ui.test.junit4.AndroidComposeTestRule.$stable
            vea.raceremote.UdpDiscoveryDeviceTest.$stable = r0
            return
    }

    public UdpDiscoveryDeviceTest() {
            r2 = this;
            r2.<init>()
            r0 = 0
            java.lang.Class<vea.raceremote.app.MainActivity> r1 = vea.raceremote.app.MainActivity.class
            androidx.compose.ui.test.junit4.AndroidComposeTestRule r0 = androidx.compose.ui.test.junit4.AndroidComposeTestRule_androidKt.createAndroidComposeRule(r1)
            r2.compose = r0
            return
    }

    private static final org.json.JSONObject searchSelectWithoutArmThenConnectAndReportBusy$get(okhttp3.OkHttpClient r5, java.lang.String r6, java.lang.String r7) {
            okhttp3.Request$Builder r0 = new okhttp3.Request$Builder
            r0.<init>()
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r2 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r2 = r2.m1395String$0$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$funget$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            java.lang.StringBuilder r1 = r1.append(r2)
            java.lang.StringBuilder r1 = r1.append(r6)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r2 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r2 = r2.m1396String$2$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$funget$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            java.lang.StringBuilder r1 = r1.append(r2)
            java.lang.StringBuilder r1 = r1.append(r7)
            java.lang.String r1 = r1.toString()
            okhttp3.Request$Builder r0 = r0.url(r1)
            okhttp3.Request r0 = r0.build()
            okhttp3.Call r0 = r5.newCall(r0)
            okhttp3.Response r0 = r0.execute()
            java.io.Closeable r0 = (java.io.Closeable) r0
            r1 = r0
            okhttp3.Response r1 = (okhttp3.Response) r1     // Catch: java.lang.Throwable -> L75
            r2 = 0
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L75
            int r3 = r3.m1374Int$arg0$callassertEquals$fun$anonymous$$arg0$calluse$funget$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L75
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch: java.lang.Throwable -> L75
            int r4 = r1.code()     // Catch: java.lang.Throwable -> L75
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)     // Catch: java.lang.Throwable -> L75
            org.junit.Assert.assertEquals(r3, r4)     // Catch: java.lang.Throwable -> L75
            org.json.JSONObject r3 = new org.json.JSONObject     // Catch: java.lang.Throwable -> L75
            okhttp3.ResponseBody r4 = r1.body()     // Catch: java.lang.Throwable -> L75
            if (r4 == 0) goto L69
            java.lang.String r4 = r4.string()     // Catch: java.lang.Throwable -> L75
            r3.<init>(r4)     // Catch: java.lang.Throwable -> L75
            r1 = 0
            kotlin.io.CloseableKt.closeFinally(r0, r1)
            return r3
        L69:
            java.lang.String r3 = "Required value was null."
            java.lang.IllegalArgumentException r4 = new java.lang.IllegalArgumentException     // Catch: java.lang.Throwable -> L75
            java.lang.String r3 = r3.toString()     // Catch: java.lang.Throwable -> L75
            r4.<init>(r3)     // Catch: java.lang.Throwable -> L75
            throw r4     // Catch: java.lang.Throwable -> L75
        L75:
            r1 = move-exception
            throw r1     // Catch: java.lang.Throwable -> L77
        L77:
            r2 = move-exception
            kotlin.io.CloseableKt.closeFinally(r0, r1)
            throw r2
    }

    private static final boolean searchSelectWithoutArmThenConnectAndReportBusy$neutral(org.json.JSONObject r6) {
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r0 = r0.m1406String$arg0$callgetBoolean$$this$callnot$cond$funneutral$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            boolean r0 = r6.getBoolean(r0)
            r1 = 0
            if (r0 != 0) goto L55
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r0 = r0.m1415String$arg0$callgetJSONObject$$$this$calllet$branch$funneutral$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            org.json.JSONObject r0 = r6.getJSONObject(r0)
            r2 = 0
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r3 = r3.m1412String$arg0$callgetInt$arg0$callEQEQ$cond$cond$fun$anonymous$$arg0$calllet$branch$funneutral$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            int r3 = r0.getInt(r3)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r4 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            int r4 = r4.m1384Int$arg1$callEQEQ$cond$cond$fun$anonymous$$arg0$calllet$branch$funneutral$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            r5 = 1
            if (r3 != r4) goto L51
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r3 = r3.m1410String$arg0$callgetInt$arg0$callEQEQ$branch$cond$fun$anonymous$$arg0$calllet$branch$funneutral$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            int r3 = r0.getInt(r3)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r4 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            int r4 = r4.m1382Int$arg1$callEQEQ$branch$cond$fun$anonymous$$arg0$calllet$branch$funneutral$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            if (r3 != r4) goto L51
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r3 = r3.m1411String$arg0$callgetInt$arg0$callEQEQ$branch$fun$anonymous$$arg0$calllet$branch$funneutral$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            int r3 = r0.getInt(r3)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r4 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            int r4 = r4.m1383Int$arg1$callEQEQ$branch$fun$anonymous$$arg0$calllet$branch$funneutral$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            if (r3 != r4) goto L51
            r0 = r5
            goto L52
        L51:
            r0 = r1
        L52:
            if (r0 == 0) goto L55
            r1 = r5
        L55:
            return r1
    }

    private static final void searchSelectWithoutArmThenConnectAndReportBusy$record(org.json.JSONArray r4, long r5, java.lang.String r7, java.lang.Object r8) {
            org.json.JSONObject r0 = new org.json.JSONObject
            r0.<init>()
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r1 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r1 = r1.m1434String$arg0$callput$$this$callput$$this$callput$arg0$callput$funrecord$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            long r2 = android.os.SystemClock.elapsedRealtime()
            long r2 = r2 - r5
            org.json.JSONObject r0 = r0.put(r1, r2)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r1 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r1 = r1.m1436String$arg0$callput$$this$callput$arg0$callput$funrecord$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            org.json.JSONObject r0 = r0.put(r1, r7)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r1 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r1 = r1.m1438String$arg0$callput$arg0$callput$funrecord$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            org.json.JSONObject r0 = r0.put(r1, r8)
            r4.put(r0)
            return
    }

    private static final org.json.JSONObject searchSelectWithoutArmThenConnectAndReportBusy$status(okhttp3.OkHttpClient r5, java.lang.String r6, java.lang.String r7, org.json.JSONArray r8, long r9) {
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r0 = r0.m1402String$arg0$callget$$$this$callalso$funstatus$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            org.json.JSONObject r0 = searchSelectWithoutArmThenConnectAndReportBusy$get(r5, r6, r0)
            r1 = r0
            r2 = 0
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r3 = r3.m1420String$arg0$callgetString$arg1$callassertEquals$fun$anonymous$$arg0$callalso$funstatus$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            java.lang.String r3 = r1.getString(r3)
            org.junit.Assert.assertEquals(r7, r3)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r3 = r3.m1407String$arg0$callgetBoolean$arg0$callassertFalse$fun$anonymous$$arg0$callalso$funstatus$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            boolean r3 = r1.getBoolean(r3)
            org.junit.Assert.assertFalse(r3)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r3 = r3.m1398String$arg0$callassertEquals1$fun$anonymous$$arg0$callalso$funstatus$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r4 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r4 = r4.m1421String$arg0$callgetString$arg1$callassertEquals1$fun$anonymous$$arg0$callalso$funstatus$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            java.lang.String r4 = r1.getString(r4)
            org.junit.Assert.assertEquals(r3, r4)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r3 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r3 = r3.m1440String$arg0$callrecord$fun$anonymous$$arg0$callalso$funstatus$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            searchSelectWithoutArmThenConnectAndReportBusy$record(r8, r9, r3, r1)
            return r0
    }

    @org.junit.Rule
    public final androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> getCompose() {
            r1 = this;
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose
            return r0
    }

    @org.junit.Test
    public final void searchSelectWithoutArmThenConnectAndReportBusy() {
            r34 = this;
            r1 = r34
            java.lang.String r2 = "JSONObject().put(\"comple…nts\", events).toString(2)"
            android.os.Bundle r3 = androidx.test.platform.app.InstrumentationRegistry.getArguments()
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r0 = r0.m1417String$arg0$callgetString$arg0$callEQEQ$arg0$callassumeTrue$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            java.lang.String r0 = r3.getString(r0)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r4 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r4 = r4.m1445String$arg1$callEQEQ$arg0$callassumeTrue$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r0, r4)
            org.junit.Assume.assumeTrue(r0)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r0 = r0.m1419String$arg0$callgetString$arg0$callrequireNotNull$valhost$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            java.lang.String r0 = r3.getString(r0)
            java.lang.String r4 = "Required value was null."
            if (r0 == 0) goto L6c5
            java.lang.String r5 = "requireNotNull(args.getString(\"driveBenchHost\"))"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r5)
            r5 = r0
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r0 = r0.m1418String$arg0$callgetString$arg0$callrequireNotNull$valcarId$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            java.lang.String r8 = r3.getString(r0)
            if (r8 == 0) goto L6bb
            java.lang.String r0 = "requireNotNull(args.getString(\"driveBenchCarId\"))"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r0)
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose
            androidx.activity.ComponentActivity r0 = r0.getActivity()
            r15 = r0
            vea.raceremote.app.MainActivity r15 = (vea.raceremote.app.MainActivity) r15
            java.lang.Class<android.net.ConnectivityManager> r0 = android.net.ConnectivityManager.class
            java.lang.Object r0 = r15.getSystemService(r0)
            r13 = r0
            android.net.ConnectivityManager r13 = (android.net.ConnectivityManager) r13
            android.net.Network[] r0 = r13.getAllNetworks()
            java.lang.String r6 = "cm.allNetworks"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r6)
            java.lang.Object[] r0 = (java.lang.Object[]) r0
            r6 = 0
            int r7 = r0.length
            r9 = 0
        L64:
            r12 = 1
            if (r9 >= r7) goto L89
            r11 = r0[r9]
            r10 = r11
            android.net.Network r10 = (android.net.Network) r10
            r17 = 0
            android.net.NetworkCapabilities r14 = r13.getNetworkCapabilities(r10)
            if (r14 == 0) goto L82
            boolean r14 = r14.hasTransport(r12)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r18 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            boolean r12 = r18.m1368Boolean$arg1$callEQEQ$fun$anonymous$$arg0$callfirstOrNull$arg0$callrequireNotNull$valwifi$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            if (r14 != r12) goto L82
            r10 = 1
            goto L83
        L82:
            r10 = 0
        L83:
            if (r10 == 0) goto L86
            goto L8a
        L86:
            int r9 = r9 + 1
            goto L64
        L89:
            r11 = 0
        L8a:
            if (r11 == 0) goto L6b1
            r4 = r11
            android.net.Network r4 = (android.net.Network) r4
            okhttp3.OkHttpClient$Builder r0 = new okhttp3.OkHttpClient$Builder
            r0.<init>()
            javax.net.SocketFactory r6 = r4.getSocketFactory()
            okhttp3.OkHttpClient$Builder r0 = r0.socketFactory(r6)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r6 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            long r6 = r6.m1387Long$arg0$callconnectTimeout$$this$callreadTimeout$$this$callcallTimeout$$this$callbuild$valhttp$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            java.util.concurrent.TimeUnit r9 = java.util.concurrent.TimeUnit.SECONDS
            okhttp3.OkHttpClient$Builder r0 = r0.connectTimeout(r6, r9)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r6 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            long r6 = r6.m1388Long$arg0$callreadTimeout$$this$callcallTimeout$$this$callbuild$valhttp$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            java.util.concurrent.TimeUnit r9 = java.util.concurrent.TimeUnit.SECONDS
            okhttp3.OkHttpClient$Builder r0 = r0.readTimeout(r6, r9)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r6 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            long r6 = r6.m1386Long$arg0$callcallTimeout$$this$callbuild$valhttp$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            java.util.concurrent.TimeUnit r9 = java.util.concurrent.TimeUnit.SECONDS
            okhttp3.OkHttpClient$Builder r0 = r0.callTimeout(r6, r9)
            okhttp3.OkHttpClient r0 = r0.build()
            r14 = r0
            org.json.JSONArray r0 = new org.json.JSONArray
            r0.<init>()
            r12 = r0
            long r10 = android.os.SystemClock.elapsedRealtime()
            vea.raceremote.control.CarDiscovery r0 = new vea.raceremote.control.CarDiscovery
            r0.<init>()
            r9 = r0
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            boolean r7 = r0.m1372Boolean$valcomplete$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            r6 = 2
            r17 = r3
            r3 = r6
            r6 = r14
            r20 = r7
            r7 = r5
            r21 = r9
            r9 = r12
            r16 = r2
            r22 = r10
            r2 = 0
            org.json.JSONObject r0 = searchSelectWithoutArmThenConnectAndReportBusy$status(r6, r7, r8, r9, r10)     // Catch: java.lang.Throwable -> L5a6
            boolean r6 = searchSelectWithoutArmThenConnectAndReportBusy$neutral(r0)     // Catch: java.lang.Throwable -> L5a6
            org.junit.Assert.assertTrue(r6)     // Catch: java.lang.Throwable -> L5a6
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r6 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L5a6
            java.lang.String r6 = r6.m1416String$arg0$callgetString$$$this$calltoLong$valchip$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L5a6
            java.lang.String r6 = r0.getString(r6)     // Catch: java.lang.Throwable -> L5a6
            java.lang.String r7 = "initial.getString(\"chipId\")"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r6, r7)     // Catch: java.lang.Throwable -> L5a6
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r7 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L5a6
            int r7 = r7.m1379Int$arg0$calltoLong$valchip$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L5a6
            int r7 = kotlin.text.CharsKt.checkRadix(r7)     // Catch: java.lang.Throwable -> L5a6
            long r6 = java.lang.Long.parseLong(r6, r7)     // Catch: java.lang.Throwable -> L5a6
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L5a6
            java.lang.String r9 = r9.m1404String$arg0$callget$$this$callgetJSONArray$$this$calltoString$valbefore$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L5a6
            org.json.JSONObject r9 = searchSelectWithoutArmThenConnectAndReportBusy$get(r14, r5, r9)     // Catch: java.lang.Throwable -> L5a6
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L5a6
            java.lang.String r10 = r10.m1414String$arg0$callgetJSONArray$$this$calltoString$valbefore$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L5a6
            org.json.JSONArray r9 = r9.getJSONArray(r10)     // Catch: java.lang.Throwable -> L5a6
            java.lang.String r9 = r9.toString()     // Catch: java.lang.Throwable -> L5a6
            java.lang.String r10 = "get(\"debug/udp-trace\").g…rray(\"events\").toString()"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r9, r10)     // Catch: java.lang.Throwable -> L5a6
            r11 = r9
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r9 = r1.compose     // Catch: java.lang.Throwable -> L5a6
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r9 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r9     // Catch: java.lang.Throwable -> L5a6
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L5a6
            java.lang.String r10 = r10.m1429String$arg0$callonNodeWithTag$$$this$callperformClick$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L5a6
            r18 = r0
            r0 = 0
            androidx.compose.ui.test.SemanticsNodeInteraction r9 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r9, r10, r0, r3, r2)     // Catch: java.lang.Throwable -> L5a6
            androidx.compose.ui.test.ActionsKt.performClick(r9)     // Catch: java.lang.Throwable -> L5a6
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r9 = r1.compose     // Catch: java.lang.Throwable -> L5a6
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L5a6
            long r2 = r10.m1390Long$arg0$callwaitUntil$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L5a6
            vea.raceremote.UdpDiscoveryDeviceTest$searchSelectWithoutArmThenConnectAndReportBusy$1 r10 = new vea.raceremote.UdpDiscoveryDeviceTest$searchSelectWithoutArmThenConnectAndReportBusy$1     // Catch: java.lang.Throwable -> L5a6
            r10.<init>(r1, r6)     // Catch: java.lang.Throwable -> L5a6
            kotlin.jvm.functions.Function0 r10 = (kotlin.jvm.functions.Function0) r10     // Catch: java.lang.Throwable -> L5a6
            r9.waitUntil(r2, r10)     // Catch: java.lang.Throwable -> L5a6
            r9 = r14
            r10 = r5
            r2 = r11
            r11 = r8
            r3 = r12
            r0 = 1
            r19 = r13
            r25 = r14
            r0 = 0
            r13 = r22
            org.json.JSONObject r9 = searchSelectWithoutArmThenConnectAndReportBusy$status(r9, r10, r11, r12, r13)     // Catch: java.lang.Throwable -> L598
            boolean r9 = searchSelectWithoutArmThenConnectAndReportBusy$neutral(r9)     // Catch: java.lang.Throwable -> L598
            org.junit.Assert.assertTrue(r9)     // Catch: java.lang.Throwable -> L598
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r9 = r1.compose     // Catch: java.lang.Throwable -> L598
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r9 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r9     // Catch: java.lang.Throwable -> L598
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L598
            r10.<init>()     // Catch: java.lang.Throwable -> L598
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r11 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L598
            java.lang.String r11 = r11.m1394String$0$str$arg0$callonNodeWithTag$$$this$callperformClick1$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L598
            java.lang.StringBuilder r10 = r10.append(r11)     // Catch: java.lang.Throwable -> L598
            java.lang.StringBuilder r10 = r10.append(r6)     // Catch: java.lang.Throwable -> L598
            java.lang.String r10 = r10.toString()     // Catch: java.lang.Throwable -> L598
            r11 = 2
            r12 = 0
            androidx.compose.ui.test.SemanticsNodeInteraction r9 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r9, r10, r0, r11, r12)     // Catch: java.lang.Throwable -> L598
            androidx.compose.ui.test.ActionsKt.performClick(r9)     // Catch: java.lang.Throwable -> L598
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r9 = r1.compose     // Catch: java.lang.Throwable -> L598
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r9 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r9     // Catch: java.lang.Throwable -> L598
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L598
            java.lang.String r10 = r10.m1426String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L598
            r11 = 2
            r12 = 0
            androidx.compose.ui.test.SemanticsNodeInteraction r9 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r9, r10, r0, r11, r12)     // Catch: java.lang.Throwable -> L598
            r11 = 0
            r12 = 0
            r13 = 6
            r14 = 0
            r10 = r5
            androidx.compose.ui.test.AssertionsKt.assertTextContains$default(r9, r10, r11, r12, r13, r14)     // Catch: java.lang.Throwable -> L598
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r9 = r1.compose     // Catch: java.lang.Throwable -> L598
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r9 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r9     // Catch: java.lang.Throwable -> L598
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L598
            java.lang.String r10 = r10.m1427String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L598
            r11 = 2
            r12 = 0
            androidx.compose.ui.test.SemanticsNodeInteraction r26 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r9, r10, r0, r11, r12)     // Catch: java.lang.Throwable -> L598
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L598
            int r9 = r9.m1380Int$arg0$calltoString$$$this$callpadStart$arg0$callassertTextContains1$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L598
            int r9 = kotlin.text.CharsKt.checkRadix(r9)     // Catch: java.lang.Throwable -> L598
            java.lang.String r9 = java.lang.Long.toString(r6, r9)     // Catch: java.lang.Throwable -> L598
            java.lang.String r10 = "toString(this, checkRadix(radix))"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r9, r10)     // Catch: java.lang.Throwable -> L598
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L598
            int r10 = r10.m1377Int$arg0$callpadStart$arg0$callassertTextContains1$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L598
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r11 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L598
            char r11 = r11.m1373Char$arg1$callpadStart$arg0$callassertTextContains1$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L598
            java.lang.String r27 = kotlin.text.StringsKt.padStart(r9, r10, r11)     // Catch: java.lang.Throwable -> L598
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L598
            boolean r28 = r9.m1369Boolean$arg1$callassertTextContains1$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L598
            r29 = 0
            r30 = 4
            r31 = 0
            androidx.compose.ui.test.AssertionsKt.assertTextContains$default(r26, r27, r28, r29, r30, r31)     // Catch: java.lang.Throwable -> L598
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r9 = r1.compose     // Catch: java.lang.Throwable -> L598
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r9 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r9     // Catch: java.lang.Throwable -> L598
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L598
            java.lang.String r10 = r10.m1423String$arg0$callonNodeWithTag$$$this$callassertIsNotEnabled$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L598
            r11 = 2
            r12 = 0
            androidx.compose.ui.test.SemanticsNodeInteraction r9 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r9, r10, r0, r11, r12)     // Catch: java.lang.Throwable -> L598
            androidx.compose.ui.test.AssertionsKt.assertIsNotEnabled(r9)     // Catch: java.lang.Throwable -> L598
            r9 = r25
            r10 = r5
            r11 = r8
            r12 = r3
            r13 = r22
            org.json.JSONObject r9 = searchSelectWithoutArmThenConnectAndReportBusy$status(r9, r10, r11, r12, r13)     // Catch: java.lang.Throwable -> L598
            boolean r9 = searchSelectWithoutArmThenConnectAndReportBusy$neutral(r9)     // Catch: java.lang.Throwable -> L598
            org.junit.Assert.assertTrue(r9)     // Catch: java.lang.Throwable -> L598
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L598
            java.lang.String r9 = r9.m1397String$arg0$callassertEquals$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L598
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L598
            java.lang.String r10 = r10.m1403String$arg0$callget$$this$callgetJSONArray$$this$calltoString$arg2$callassertEquals$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L598
            r13 = r25
            org.json.JSONObject r10 = searchSelectWithoutArmThenConnectAndReportBusy$get(r13, r5, r10)     // Catch: java.lang.Throwable -> L58b
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r11 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L58b
            java.lang.String r11 = r11.m1413String$arg0$callgetJSONArray$$this$calltoString$arg2$callassertEquals$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L58b
            org.json.JSONArray r10 = r10.getJSONArray(r11)     // Catch: java.lang.Throwable -> L58b
            java.lang.String r10 = r10.toString()     // Catch: java.lang.Throwable -> L58b
            org.junit.Assert.assertEquals(r9, r2, r10)     // Catch: java.lang.Throwable -> L58b
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L58b
            java.lang.String r9 = r9.m1441String$arg0$callrecord$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L58b
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L58b
            boolean r10 = r10.m1370Boolean$arg1$callrecord$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L58b
            java.lang.Boolean r10 = java.lang.Boolean.valueOf(r10)     // Catch: java.lang.Throwable -> L58b
            r11 = r22
            searchSelectWithoutArmThenConnectAndReportBusy$record(r3, r11, r9, r10)     // Catch: java.lang.Throwable -> L57f
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r9 = r1.compose     // Catch: java.lang.Throwable -> L57f
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r9 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r9     // Catch: java.lang.Throwable -> L57f
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L57f
            java.lang.String r10 = r10.m1430String$arg0$callonNodeWithTag$$$this$callperformClick2$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L57f
            r22 = r2
            r2 = 0
            r14 = 2
            androidx.compose.ui.test.SemanticsNodeInteraction r9 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r9, r10, r0, r14, r2)     // Catch: java.lang.Throwable -> L57f
            androidx.compose.ui.test.ActionsKt.performClick(r9)     // Catch: java.lang.Throwable -> L57f
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r2 = r1.compose     // Catch: java.lang.Throwable -> L57f
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L57f
            long r9 = r9.m1391Long$arg0$callwaitUntil1$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L57f
            vea.raceremote.UdpDiscoveryDeviceTest$searchSelectWithoutArmThenConnectAndReportBusy$2 r14 = new vea.raceremote.UdpDiscoveryDeviceTest$searchSelectWithoutArmThenConnectAndReportBusy$2     // Catch: java.lang.Throwable -> L57f
            r14.<init>(r1)     // Catch: java.lang.Throwable -> L57f
            kotlin.jvm.functions.Function0 r14 = (kotlin.jvm.functions.Function0) r14     // Catch: java.lang.Throwable -> L57f
            r2.waitUntil(r9, r14)     // Catch: java.lang.Throwable -> L57f
            r9 = r13
            r10 = r5
            r25 = r11
            r11 = r8
            r12 = r3
            r2 = r13
            r13 = r25
            org.json.JSONObject r9 = searchSelectWithoutArmThenConnectAndReportBusy$status(r9, r10, r11, r12, r13)     // Catch: java.lang.Throwable -> L573
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L573
            java.lang.String r10 = r10.m1408String$arg0$callgetBoolean$arg0$callassertTrue3$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L573
            boolean r9 = r9.getBoolean(r10)     // Catch: java.lang.Throwable -> L573
            org.junit.Assert.assertTrue(r9)     // Catch: java.lang.Throwable -> L573
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r9 = r1.compose     // Catch: java.lang.Throwable -> L573
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r9 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r9     // Catch: java.lang.Throwable -> L573
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L573
            java.lang.String r10 = r10.m1424String$arg0$callonNodeWithTag$$$this$callassertIsNotEnabled1$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L573
            r11 = 2
            r12 = 0
            androidx.compose.ui.test.SemanticsNodeInteraction r9 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r9, r10, r0, r11, r12)     // Catch: java.lang.Throwable -> L573
            androidx.compose.ui.test.AssertionsKt.assertIsNotEnabled(r9)     // Catch: java.lang.Throwable -> L573
            vea.raceremote.UdpDiscoveryDeviceTest$searchSelectWithoutArmThenConnectAndReportBusy$3 r9 = new vea.raceremote.UdpDiscoveryDeviceTest$searchSelectWithoutArmThenConnectAndReportBusy$3     // Catch: java.lang.Throwable -> L573
            r9.<init>(r4)     // Catch: java.lang.Throwable -> L573
            kotlin.jvm.functions.Function1 r9 = (kotlin.jvm.functions.Function1) r9     // Catch: java.lang.Throwable -> L573
            r13 = r21
            r10 = 1
            r11 = 0
            vea.raceremote.control.CarDiscovery.search$default(r13, r11, r9, r10, r11)     // Catch: java.lang.Throwable -> L568
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r9 = r1.compose     // Catch: java.lang.Throwable -> L568
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r11 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L568
            long r11 = r11.m1392Long$arg0$callwaitUntil2$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L568
            vea.raceremote.UdpDiscoveryDeviceTest$searchSelectWithoutArmThenConnectAndReportBusy$4 r14 = new vea.raceremote.UdpDiscoveryDeviceTest$searchSelectWithoutArmThenConnectAndReportBusy$4     // Catch: java.lang.Throwable -> L568
            r14.<init>(r13)     // Catch: java.lang.Throwable -> L568
            kotlin.jvm.functions.Function0 r14 = (kotlin.jvm.functions.Function0) r14     // Catch: java.lang.Throwable -> L568
            r9.waitUntil(r11, r14)     // Catch: java.lang.Throwable -> L568
            kotlinx.coroutines.flow.StateFlow r9 = r13.getState()     // Catch: java.lang.Throwable -> L568
            java.lang.Object r9 = r9.getValue()     // Catch: java.lang.Throwable -> L568
            vea.raceremote.control.DiscoveryState r9 = (vea.raceremote.control.DiscoveryState) r9     // Catch: java.lang.Throwable -> L568
            java.util.List r9 = r9.getCars()     // Catch: java.lang.Throwable -> L568
            java.lang.Iterable r9 = (java.lang.Iterable) r9     // Catch: java.lang.Throwable -> L568
            r11 = 0
            r12 = 0
            r14 = 0
            java.util.Iterator r21 = r9.iterator()     // Catch: java.lang.Throwable -> L568
        L2d6:
            boolean r23 = r21.hasNext()     // Catch: java.lang.Throwable -> L568
            if (r23 == 0) goto L31a
            java.lang.Object r23 = r21.next()     // Catch: java.lang.Throwable -> L30e
            r24 = r23
            vea.raceremote.control.DiscoveredCar r24 = (vea.raceremote.control.DiscoveredCar) r24     // Catch: java.lang.Throwable -> L30e
            r27 = 0
            long r28 = r24.getChipId()     // Catch: java.lang.Throwable -> L30e
            int r28 = (r28 > r6 ? 1 : (r28 == r6 ? 0 : -1))
            if (r28 != 0) goto L2fa
            java.lang.String r10 = r24.getHost()     // Catch: java.lang.Throwable -> L30e
            boolean r10 = kotlin.jvm.internal.Intrinsics.areEqual(r10, r5)     // Catch: java.lang.Throwable -> L30e
            if (r10 == 0) goto L2fa
            r10 = 1
            goto L2fb
        L2fa:
            r10 = r0
        L2fb:
            if (r10 == 0) goto L30c
            if (r14 != 0) goto L304
            r12 = r23
            r14 = 1
            r10 = 1
            goto L2d6
        L304:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.Throwable -> L30e
            java.lang.String r10 = "Collection contains more than one matching element."
            r0.<init>(r10)     // Catch: java.lang.Throwable -> L30e
            throw r0     // Catch: java.lang.Throwable -> L30e
        L30c:
            r10 = 1
            goto L2d6
        L30e:
            r0 = move-exception
            r23 = r4
            r4 = r13
            r13 = r16
            r16 = r5
            r5 = r25
            goto L5b5
        L31a:
            if (r14 == 0) goto L550
        L31d:
            r9 = r12
            vea.raceremote.control.DiscoveredCar r9 = (vea.raceremote.control.DiscoveredCar) r9     // Catch: java.lang.Throwable -> L544
            r21 = r9
            boolean r9 = r21.getBusy()     // Catch: java.lang.Throwable -> L544
            org.junit.Assert.assertTrue(r9)     // Catch: java.lang.Throwable -> L544
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L544
            java.lang.String r9 = r9.m1399String$arg0$callassertEquals1$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L544
            java.lang.String r10 = r21.getTransport()     // Catch: java.lang.Throwable -> L544
            org.junit.Assert.assertEquals(r9, r10)     // Catch: java.lang.Throwable -> L544
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L544
            int r9 = r9.m1375Int$arg0$callassertEquals2$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L544
            java.lang.Integer r9 = java.lang.Integer.valueOf(r9)     // Catch: java.lang.Throwable -> L544
            int r10 = r21.getPort()     // Catch: java.lang.Throwable -> L544
            java.lang.Integer r10 = java.lang.Integer.valueOf(r10)     // Catch: java.lang.Throwable -> L544
            org.junit.Assert.assertEquals(r9, r10)     // Catch: java.lang.Throwable -> L544
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L544
            int r9 = r9.m1376Int$arg0$callassertEquals3$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L544
            java.lang.Integer r9 = java.lang.Integer.valueOf(r9)     // Catch: java.lang.Throwable -> L544
            int r10 = r21.getDiscoveryVersion()     // Catch: java.lang.Throwable -> L544
            java.lang.Integer r10 = java.lang.Integer.valueOf(r10)     // Catch: java.lang.Throwable -> L544
            org.junit.Assert.assertEquals(r9, r10)     // Catch: java.lang.Throwable -> L544
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L544
            java.lang.String r9 = r9.m1442String$arg0$callrecord1$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L544
            java.lang.String r10 = r21.toString()     // Catch: java.lang.Throwable -> L544
            r11 = r25
            searchSelectWithoutArmThenConnectAndReportBusy$record(r3, r11, r9, r10)     // Catch: java.lang.Throwable -> L538
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r9 = r1.compose     // Catch: java.lang.Throwable -> L538
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r9 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r9     // Catch: java.lang.Throwable -> L538
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L538
            java.lang.String r10 = r10.m1428String$arg0$callonNodeWithTag$$$this$callassertTextContains2$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L538
            r23 = r4
            r4 = 0
            r14 = 2
            androidx.compose.ui.test.SemanticsNodeInteraction r24 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r9, r10, r0, r14, r4)     // Catch: java.lang.Throwable -> L52e
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r4 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L52e
            java.lang.String r25 = r4.m1401String$arg0$callassertTextContains2$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L52e
            r26 = 0
            r27 = 0
            r28 = 6
            r29 = 0
            androidx.compose.ui.test.AssertionsKt.assertTextContains$default(r24, r25, r26, r27, r28, r29)     // Catch: java.lang.Throwable -> L52e
            r9 = r2
            r10 = r5
            r25 = r11
            r11 = r8
            r12 = r3
            r4 = r13
            r13 = r25
            org.json.JSONObject r9 = searchSelectWithoutArmThenConnectAndReportBusy$status(r9, r10, r11, r12, r13)     // Catch: java.lang.Throwable -> L525
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L525
            java.lang.String r10 = r10.m1409String$arg0$callgetBoolean$arg0$callassertTrue5$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L525
            boolean r9 = r9.getBoolean(r10)     // Catch: java.lang.Throwable -> L525
            org.junit.Assert.assertTrue(r9)     // Catch: java.lang.Throwable -> L525
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r9 = r1.compose     // Catch: java.lang.Throwable -> L525
            androidx.compose.ui.test.SemanticsNodeInteractionsProvider r9 = (androidx.compose.ui.test.SemanticsNodeInteractionsProvider) r9     // Catch: java.lang.Throwable -> L525
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L525
            java.lang.String r10 = r10.m1431String$arg0$callonNodeWithTag$$$this$callperformClick3$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L525
            r11 = 2
            r12 = 0
            androidx.compose.ui.test.SemanticsNodeInteraction r0 = androidx.compose.ui.test.FindersKt.onNodeWithTag$default(r9, r10, r0, r11, r12)     // Catch: java.lang.Throwable -> L525
            androidx.compose.ui.test.ActionsKt.performClick(r0)     // Catch: java.lang.Throwable -> L525
            long r9 = android.os.SystemClock.elapsedRealtime()     // Catch: java.lang.Throwable -> L525
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L525
            int r0 = r0.m1378Int$arg0$callplus$valuntil$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L525
            long r11 = (long) r0     // Catch: java.lang.Throwable -> L525
            long r9 = r9 + r11
            r27 = r9
        L3cd:
            r9 = r2
            r10 = r5
            r11 = r8
            r12 = r3
            r13 = r25
            org.json.JSONObject r0 = searchSelectWithoutArmThenConnectAndReportBusy$status(r9, r10, r11, r12, r13)     // Catch: java.lang.Throwable -> L525
            boolean r0 = searchSelectWithoutArmThenConnectAndReportBusy$neutral(r0)     // Catch: java.lang.Throwable -> L525
            if (r0 != 0) goto L3f8
            long r9 = android.os.SystemClock.elapsedRealtime()     // Catch: java.lang.Throwable -> L3ef
            int r0 = (r9 > r27 ? 1 : (r9 == r27 ? 0 : -1))
            if (r0 >= 0) goto L3f8
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L3ef
            long r9 = r0.m1389Long$arg0$callsleep$body$loop$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L3ef
            android.os.SystemClock.sleep(r9)     // Catch: java.lang.Throwable -> L3ef
            goto L3cd
        L3ef:
            r0 = move-exception
            r13 = r16
            r16 = r5
            r5 = r25
            goto L5b5
        L3f8:
            r9 = r2
            r10 = r5
            r11 = r8
            r12 = r3
            r13 = r25
            org.json.JSONObject r0 = searchSelectWithoutArmThenConnectAndReportBusy$status(r9, r10, r11, r12, r13)     // Catch: java.lang.Throwable -> L525
            boolean r0 = searchSelectWithoutArmThenConnectAndReportBusy$neutral(r0)     // Catch: java.lang.Throwable -> L525
            org.junit.Assert.assertTrue(r0)     // Catch: java.lang.Throwable -> L525
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r0 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L525
            java.lang.String r0 = r0.m1405String$arg0$callget$valtrace$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L525
            org.json.JSONObject r0 = searchSelectWithoutArmThenConnectAndReportBusy$get(r2, r5, r0)     // Catch: java.lang.Throwable -> L525
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L525
            java.lang.String r9 = r9.m1443String$arg0$callrecord2$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L525
            r10 = r25
            searchSelectWithoutArmThenConnectAndReportBusy$record(r3, r10, r9, r0)     // Catch: java.lang.Throwable -> L51d
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L51d
            java.lang.String r9 = r9.m1422String$arg0$callhas$arg0$callassertTrue7$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L51d
            boolean r9 = r0.has(r9)     // Catch: java.lang.Throwable -> L51d
            org.junit.Assert.assertTrue(r9)     // Catch: java.lang.Throwable -> L51d
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L51d
            boolean r9 = r9.m1371Boolean$setcomplete$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L51d
            r6 = r9
            r4.close()
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r0 = r1.compose     // Catch: java.lang.Throwable -> L4b0
            org.junit.rules.TestRule r0 = r0.getActivityRule()     // Catch: java.lang.Throwable -> L4b0
            androidx.test.ext.junit.rules.ActivityScenarioRule r0 = (androidx.test.ext.junit.rules.ActivityScenarioRule) r0     // Catch: java.lang.Throwable -> L4b0
            androidx.test.core.app.ActivityScenario r0 = r0.getScenario()     // Catch: java.lang.Throwable -> L4b0
            androidx.lifecycle.Lifecycle$State r7 = androidx.lifecycle.Lifecycle.State.STARTED     // Catch: java.lang.Throwable -> L4b0
            r0.moveToState(r7)     // Catch: java.lang.Throwable -> L4b0
            java.io.File r0 = new java.io.File
            java.io.File r7 = r15.getFilesDir()
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r9 = r9.m1444String$arg1$call$init$$$$this$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            r0.<init>(r7, r9)
            org.json.JSONObject r7 = new org.json.JSONObject
            r7.<init>()
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r9 = r9.m1432String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            org.json.JSONObject r7 = r7.put(r9, r6)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r9 = r9.m1433String$arg0$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            org.json.JSONObject r7 = r7.put(r9, r5)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r9 = r9.m1435String$arg0$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            long r12 = android.os.SystemClock.elapsedRealtime()
            long r12 = r12 - r10
            org.json.JSONObject r7 = r7.put(r9, r12)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r9 = r9.m1437String$arg0$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            org.json.JSONObject r7 = r7.put(r9, r3)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r9 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            int r9 = r9.m1381Int$arg0$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            java.lang.String r7 = r7.toString(r9)
            r13 = r16
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r7, r13)
            r9 = 2
            r12 = 0
            kotlin.io.FilesKt.writeText$default(r0, r7, r12, r9, r12)
            okhttp3.ConnectionPool r0 = r2.connectionPool()
            r0.evictAll()
            okhttp3.Dispatcher r0 = r2.dispatcher()
            java.util.concurrent.ExecutorService r0 = r0.executorService()
            r0.shutdown()
            return
        L4b0:
            r0 = move-exception
            r13 = r16
            java.io.File r7 = new java.io.File
            java.io.File r9 = r15.getFilesDir()
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r12 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r12 = r12.m1444String$arg1$call$init$$$$this$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            r7.<init>(r9, r12)
            org.json.JSONObject r9 = new org.json.JSONObject
            r9.<init>()
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r12 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r12 = r12.m1432String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            org.json.JSONObject r9 = r9.put(r12, r6)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r12 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r12 = r12.m1433String$arg0$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            org.json.JSONObject r9 = r9.put(r12, r5)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r12 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r12 = r12.m1435String$arg0$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            long r20 = android.os.SystemClock.elapsedRealtime()
            r16 = r5
            r14 = r6
            long r5 = r20 - r10
            org.json.JSONObject r5 = r9.put(r12, r5)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r6 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r6 = r6.m1437String$arg0$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            org.json.JSONObject r5 = r5.put(r6, r3)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r6 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            int r6 = r6.m1381Int$arg0$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            java.lang.String r5 = r5.toString(r6)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r5, r13)
            r6 = 2
            r9 = 0
            kotlin.io.FilesKt.writeText$default(r7, r5, r9, r6, r9)
            okhttp3.ConnectionPool r5 = r2.connectionPool()
            r5.evictAll()
            okhttp3.Dispatcher r5 = r2.dispatcher()
            java.util.concurrent.ExecutorService r5 = r5.executorService()
            r5.shutdown()
            throw r0
        L51d:
            r0 = move-exception
            r13 = r16
            r16 = r5
            r5 = r10
            goto L5b5
        L525:
            r0 = move-exception
            r13 = r16
            r16 = r5
            r5 = r25
            goto L5b5
        L52e:
            r0 = move-exception
            r10 = r11
            r4 = r13
            r13 = r16
            r16 = r5
            r5 = r10
            goto L5b5
        L538:
            r0 = move-exception
            r23 = r4
            r10 = r11
            r4 = r13
            r13 = r16
            r16 = r5
            r5 = r10
            goto L5b5
        L544:
            r0 = move-exception
            r23 = r4
            r4 = r13
            r13 = r16
            r16 = r5
            r5 = r25
            goto L5b5
        L550:
            r23 = r4
            r4 = r13
            r13 = r16
            r16 = r5
            r32 = r6
            r5 = r25
            r24 = r32
            java.util.NoSuchElementException r0 = new java.util.NoSuchElementException     // Catch: java.lang.Throwable -> L565
            java.lang.String r7 = "Collection contains no element matching the predicate."
            r0.<init>(r7)     // Catch: java.lang.Throwable -> L565
            throw r0     // Catch: java.lang.Throwable -> L565
        L565:
            r0 = move-exception
            goto L5b5
        L568:
            r0 = move-exception
            r23 = r4
            r4 = r13
            r13 = r16
            r16 = r5
            r5 = r25
            goto L5b5
        L573:
            r0 = move-exception
            r23 = r4
            r13 = r16
            r4 = r21
            r16 = r5
            r5 = r25
            goto L5b5
        L57f:
            r0 = move-exception
            r23 = r4
            r2 = r13
            r13 = r16
            r4 = r21
            r16 = r5
            r5 = r11
            goto L5b5
        L58b:
            r0 = move-exception
            r2 = r13
            r13 = r16
            r16 = r5
            r5 = r22
            r23 = r4
            r4 = r21
            goto L5b5
        L598:
            r0 = move-exception
            r13 = r16
            r2 = r25
            r16 = r5
            r5 = r22
            r23 = r4
            r4 = r21
            goto L5b5
        L5a6:
            r0 = move-exception
            r3 = r12
            r19 = r13
            r2 = r14
            r13 = r16
            r16 = r5
            r5 = r22
            r23 = r4
            r4 = r21
        L5b5:
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r7 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE     // Catch: java.lang.Throwable -> L5c3
            java.lang.String r7 = r7.m1439String$arg0$callrecord$catch$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()     // Catch: java.lang.Throwable -> L5c3
            java.lang.String r9 = r0.toString()     // Catch: java.lang.Throwable -> L5c3
            searchSelectWithoutArmThenConnectAndReportBusy$record(r3, r5, r7, r9)     // Catch: java.lang.Throwable -> L5c3
            throw r0     // Catch: java.lang.Throwable -> L5c3
        L5c3:
            r0 = move-exception
            r4.close()
            androidx.compose.ui.test.junit4.AndroidComposeTestRule<androidx.test.ext.junit.rules.ActivityScenarioRule<vea.raceremote.app.MainActivity>, vea.raceremote.app.MainActivity> r7 = r1.compose     // Catch: java.lang.Throwable -> L645
            org.junit.rules.TestRule r7 = r7.getActivityRule()     // Catch: java.lang.Throwable -> L645
            androidx.test.ext.junit.rules.ActivityScenarioRule r7 = (androidx.test.ext.junit.rules.ActivityScenarioRule) r7     // Catch: java.lang.Throwable -> L645
            androidx.test.core.app.ActivityScenario r7 = r7.getScenario()     // Catch: java.lang.Throwable -> L645
            androidx.lifecycle.Lifecycle$State r9 = androidx.lifecycle.Lifecycle.State.STARTED     // Catch: java.lang.Throwable -> L645
            r7.moveToState(r9)     // Catch: java.lang.Throwable -> L645
            java.io.File r7 = new java.io.File
            java.io.File r9 = r15.getFilesDir()
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r10 = r10.m1444String$arg1$call$init$$$$this$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            r7.<init>(r9, r10)
            org.json.JSONObject r9 = new org.json.JSONObject
            r9.<init>()
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r10 = r10.m1432String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            r11 = r20
            org.json.JSONObject r9 = r9.put(r10, r11)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r10 = r10.m1433String$arg0$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            r12 = r16
            org.json.JSONObject r9 = r9.put(r10, r12)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r10 = r10.m1435String$arg0$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            long r20 = android.os.SystemClock.elapsedRealtime()
            r14 = r11
            long r11 = r20 - r5
            org.json.JSONObject r9 = r9.put(r10, r11)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r10 = r10.m1437String$arg0$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            org.json.JSONObject r9 = r9.put(r10, r3)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            int r10 = r10.m1381Int$arg0$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            java.lang.String r9 = r9.toString(r10)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r9, r13)
            r10 = 2
            r11 = 0
            kotlin.io.FilesKt.writeText$default(r7, r9, r11, r10, r11)
            okhttp3.ConnectionPool r7 = r2.connectionPool()
            r7.evictAll()
            okhttp3.Dispatcher r7 = r2.dispatcher()
            java.util.concurrent.ExecutorService r7 = r7.executorService()
            r7.shutdown()
            throw r0
        L645:
            r0 = move-exception
            r14 = r20
            java.io.File r7 = new java.io.File
            java.io.File r9 = r15.getFilesDir()
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r10 = r10.m1444String$arg1$call$init$$$$this$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            r7.<init>(r9, r10)
            org.json.JSONObject r9 = new org.json.JSONObject
            r9.<init>()
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r10 = r10.m1432String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            org.json.JSONObject r9 = r9.put(r10, r14)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r10 = r10.m1433String$arg0$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            r11 = r16
            org.json.JSONObject r9 = r9.put(r10, r11)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r10 = r10.m1435String$arg0$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            long r20 = android.os.SystemClock.elapsedRealtime()
            long r11 = r20 - r5
            org.json.JSONObject r9 = r9.put(r10, r11)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            java.lang.String r10 = r10.m1437String$arg0$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            org.json.JSONObject r9 = r9.put(r10, r3)
            vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt r10 = vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE
            int r10 = r10.m1381Int$arg0$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()
            java.lang.String r9 = r9.toString(r10)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r9, r13)
            r10 = 2
            r11 = 0
            kotlin.io.FilesKt.writeText$default(r7, r9, r11, r10, r11)
            okhttp3.ConnectionPool r7 = r2.connectionPool()
            r7.evictAll()
            okhttp3.Dispatcher r7 = r2.dispatcher()
            java.util.concurrent.ExecutorService r7 = r7.executorService()
            r7.shutdown()
            throw r0
        L6b1:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r2 = r4.toString()
            r0.<init>(r2)
            throw r0
        L6bb:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r2 = r4.toString()
            r0.<init>(r2)
            throw r0
        L6c5:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r2 = r4.toString()
            r0.<init>(r2)
            throw r0
    }
}
