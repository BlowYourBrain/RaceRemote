package vea.raceremote;

import androidx.activity.ComponentActivity;
import androidx.activity.compose.ComponentActivityKt;
import androidx.compose.foundation.BorderStroke;
import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.material.ButtonColors;
import androidx.compose.material.ButtonElevation;
import androidx.compose.material.ButtonKt;
import androidx.compose.material.Colors;
import androidx.compose.material.MaterialThemeKt;
import androidx.compose.material.Shapes;
import androidx.compose.material.Typography;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.CompositionContext;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.ui.platform.TestTagKt;
import androidx.compose.ui.test.ActionsKt;
import androidx.compose.ui.test.AssertionsKt;
import androidx.compose.ui.test.FindersKt;
import androidx.compose.ui.test.TextActionsKt;
import androidx.compose.ui.test.junit4.AndroidComposeTestRule;
import androidx.compose.ui.test.junit4.AndroidComposeTestRule_androidKt;
import androidx.lifecycle.Lifecycle;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.CharsKt;
import kotlin.text.StringsKt;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okhttp3.mockwebserver.Dispatcher;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import okio.ByteString;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import vea.raceremote.app.MainActivity;
import vea.raceremote.control.CarControlScreenKt;
import vea.raceremote.control.ControlPacket;
import vea.raceremote.control.DiscoveredCar;

/* JADX INFO: compiled from: CarIdentitySelectionTest.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\t\u001a\u00020\nH\u0007J\u0010\u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\rH\u0002J\b\u0010\u000e\u001a\u00020\nH\u0007R%\u0010\u0003\u001a\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0004\u0012\u00020\u00060\u00048G¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b¨\u0006\u000f"}, d2 = {"Lvea/raceremote/CarIdentitySelectionTest;", "", "()V", "compose", "Landroidx/compose/ui/test/junit4/AndroidComposeTestRule;", "Landroidx/test/ext/junit/rules/ActivityScenarioRule;", "Lvea/raceremote/app/MainActivity;", "getCompose", "()Landroidx/compose/ui/test/junit4/AndroidComposeTestRule;", "selectedCarMustConfirmItsIdentity", "", "selection", "matching", "", "wrongIdentityRequiresExplicitManualSelectionOfActualBoard", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class CarIdentitySelectionTest {
    public static final int $stable = AndroidComposeTestRule.$stable;
    private final AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity> compose = AndroidComposeTestRule_androidKt.createAndroidComposeRule(MainActivity.class);

    @Rule
    public final AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity> getCompose() {
        return this.compose;
    }

    @Test
    public final void selectedCarMustConfirmItsIdentity() throws IOException {
        selection(LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m511Boolean$arg0$callselection$funselectedCarMustConfirmItsIdentity$classCarIdentitySelectionTest());
    }

    @Test
    public final void wrongIdentityRequiresExplicitManualSelectionOfActualBoard() throws IOException {
        selection(LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m512Boolean$arg0$callselection$funwrongIdentityRequiresExplicitManualSelectionOfActualBoard$classCarIdentitySelectionTest());
    }

    private final void selection(final boolean matching) throws IOException {
        final long chip = LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m535Long$valchip$funselection$classCarIdentitySelectionTest();
        final long token = LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m536Long$valtoken$funselection$classCarIdentitySelectionTest();
        final long actualChip = matching ? chip : LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m533Long$arg0$callxor$else$if$valactualChip$funselection$classCarIdentitySelectionTest() ^ chip;
        final AtomicInteger drives = new AtomicInteger();
        final AtomicInteger arms = new AtomicInteger();
        MockWebServer server = new MockWebServer();
        server.setDispatcher(new Dispatcher() { // from class: vea.raceremote.CarIdentitySelectionTest.selection.1
            @Override // okhttp3.mockwebserver.Dispatcher
            public MockResponse dispatch(final RecordedRequest request) {
                Intrinsics.checkNotNullParameter(request, "request");
                if (Intrinsics.areEqual(request.getPath(), LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m559String$arg1$callEQEQ$cond$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest())) {
                    MockResponse mockResponse = new MockResponse();
                    StringBuilder sbAppend = new StringBuilder().append(LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m538String$0$str$arg0$callsetBody$branch$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest());
                    String string = Long.toString(actualChip, CharsKt.checkRadix(LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m523Int$arg0$calltoString$1$str$arg0$callsetBody$branch$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest()));
                    Intrinsics.checkNotNullExpressionValue(string, "toString(this, checkRadix(radix))");
                    MockResponse body = mockResponse.setBody(sbAppend.append(string).append(LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m539String$2$str$arg0$callsetBody$branch$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest()).toString());
                    Intrinsics.checkNotNullExpressionValue(body, "MockResponse().setBody(\n…lChip.toString(16)}\"}\"\"\")");
                    return body;
                }
                MockResponse mockResponse2 = new MockResponse();
                final boolean z = matching;
                final long j = token;
                final AtomicInteger atomicInteger = arms;
                final AtomicInteger atomicInteger2 = drives;
                MockResponse mockResponseWithWebSocketUpgrade = mockResponse2.withWebSocketUpgrade(new WebSocketListener() { // from class: vea.raceremote.CarIdentitySelectionTest$selection$1$dispatch$1
                    public void onOpen(WebSocket webSocket, Response response) {
                        Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                        Intrinsics.checkNotNullParameter(response, "response");
                        if (Intrinsics.areEqual(getPath(), "/control/identity")) {
                            Iterable $this$map$iv = StringsKt.chunked(LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m537String$$$this$callchunked$$$this$callmap$$$this$calltoByteArray$valbytes$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest(), LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m518Int$arg0$callchunked$$$this$callmap$$$this$calltoByteArray$valbytes$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest());
                            Collection destination$iv$iv = new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10));
                            for (Object item$iv$iv : $this$map$iv) {
                                String it = (String) item$iv$iv;
                                destination$iv$iv.add(Byte.valueOf((byte) Integer.parseInt(it, CharsKt.checkRadix(LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m522Int$arg0$calltoInt$$this$calltoByte$fun$anonymous$$arg0$callmap$$$this$calltoByteArray$valbytes$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest()))));
                            }
                            byte[] bytes = CollectionsKt.toByteArray((List) destination$iv$iv);
                            if (!z) {
                                bytes[LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m520Int$arg0$callset$branch$if$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest()] = (byte) (bytes[LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m519Int$arg0$callget$$this$calltoInt$$this$callxor$$this$calltoByte$arg1$callset$branch$if$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest()] ^ LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m524Int$arg0$callxor$$this$calltoByte$arg1$callset$branch$if$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest());
                            }
                            webSocket.send(ByteString.of(Arrays.copyOf(bytes, bytes.length)));
                        }
                        byte[] bArrEncode = new ControlPacket(128, j, LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m534Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest(), 0, 0, 24, (DefaultConstructorMarker) null).encode();
                        webSocket.send(ByteString.of(Arrays.copyOf(bArrEncode, bArrEncode.length)));
                    }

                    public void onMessage(WebSocket webSocket, ByteString bytes) {
                        Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                        Intrinsics.checkNotNullParameter(bytes, "bytes");
                        ControlPacket.Companion companion = ControlPacket.Companion;
                        byte[] byteArray = bytes.toByteArray();
                        Intrinsics.checkNotNullExpressionValue(byteArray, "bytes.toByteArray()");
                        ControlPacket p = companion.decode(byteArray);
                        Intrinsics.checkNotNull(p);
                        if (p.getKind() == 1) {
                            atomicInteger.incrementAndGet();
                        }
                        if (p.getKind() == 2) {
                            atomicInteger2.incrementAndGet();
                        }
                        if (p.getKind() != 3) {
                            byte[] bArrEncode = ControlPacket.copy$default(p, 129, 0L, 0L, 0, 0, 30, (Object) null).encode();
                            webSocket.send(ByteString.of(Arrays.copyOf(bArrEncode, bArrEncode.length)));
                        }
                    }
                });
                Intrinsics.checkNotNullExpressionValue(mockResponseWithWebSocketUpgrade, "matching: Boolean) {\n   …         }\n            })");
                return mockResponseWithWebSocketUpgrade;
            }
        });
        server.start(LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m521Int$arg0$callstart$funselection$classCarIdentitySelectionTest());
        try {
            runOnUiThread(new Function0<Unit>() { // from class: vea.raceremote.CarIdentitySelectionTest.selection.2
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                public /* bridge */ /* synthetic */ Object invoke() {
                    m483invoke();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: collision with other method in class */
                public final void m483invoke() {
                    ComponentActivity activity = CarIdentitySelectionTest.this.getCompose().getActivity();
                    final long j = chip;
                    ComponentActivityKt.setContent$default(activity, (CompositionContext) null, ComposableLambdaKt.composableLambdaInstance(-1270809877, true, new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.CarIdentitySelectionTest.selection.2.1
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(2);
                        }

                        public /* bridge */ /* synthetic */ Object invoke(Object p1, Object p2) {
                            invoke((Composer) p1, ((Number) p2).intValue());
                            return Unit.INSTANCE;
                        }

                        public final void invoke(Composer $composer, int $changed) {
                            ComposerKt.sourceInformation($composer, "C75@3668L377:CarIdentitySelectionTest.kt#njci4t");
                            if (($changed & 11) != 2 || !$composer.getSkipping()) {
                                if (ComposerKt.isTraceInProgress()) {
                                    ComposerKt.traceEventStart(-1270809877, $changed, -1, "vea.raceremote.CarIdentitySelectionTest.selection.<anonymous>.<anonymous> (CarIdentitySelectionTest.kt:74)");
                                }
                                final long j2 = j;
                                MaterialThemeKt.MaterialTheme((Colors) null, (Typography) null, (Shapes) null, ComposableLambdaKt.composableLambda($composer, -1276146281, true, new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.CarIdentitySelectionTest.selection.2.1.1
                                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                    {
                                        super(2);
                                    }

                                    public /* bridge */ /* synthetic */ Object invoke(Object p1, Object p2) {
                                        invoke((Composer) p1, ((Number) p2).intValue());
                                        return Unit.INSTANCE;
                                    }

                                    public final void invoke(Composer $composer2, int $changed2) {
                                        ComposerKt.sourceInformation($composer2, "C76@3708L315:CarIdentitySelectionTest.kt#njci4t");
                                        if (($changed2 & 11) != 2 || !$composer2.getSkipping()) {
                                            if (ComposerKt.isTraceInProgress()) {
                                                ComposerKt.traceEventStart(-1276146281, $changed2, -1, "vea.raceremote.CarIdentitySelectionTest.selection.<anonymous>.<anonymous>.<anonymous> (CarIdentitySelectionTest.kt:75)");
                                            }
                                            final long j3 = j2;
                                            CarControlScreenKt.CarControlScreen(ComposableLambdaKt.composableLambda($composer2, 1107980410, true, new Function4<Boolean, Function1<? super DiscoveredCar, ? extends Unit>, Composer, Integer, Unit>() { // from class: vea.raceremote.CarIdentitySelectionTest.selection.2.1.1.1
                                                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                                {
                                                    super(4);
                                                }

                                                public /* bridge */ /* synthetic */ Object invoke(Object p1, Object p2, Object p3, Object p4) {
                                                    invoke(((Boolean) p1).booleanValue(), (Function1<? super DiscoveredCar, Unit>) p2, (Composer) p3, ((Number) p4).intValue());
                                                    return Unit.INSTANCE;
                                                }

                                                public final void invoke(boolean enabled, final Function1<? super DiscoveredCar, Unit> function1, Composer $composer3, int $changed3) {
                                                    Object value$iv$iv;
                                                    Intrinsics.checkNotNullParameter(function1, "pick");
                                                    ComposerKt.sourceInformation($composer3, "C77@3820L55,77@3803L193:CarIdentitySelectionTest.kt#njci4t");
                                                    int $dirty = $changed3;
                                                    if (($changed3 & 14) == 0) {
                                                        $dirty |= $composer3.changed(enabled) ? 4 : 2;
                                                    }
                                                    if (($changed3 & 112) == 0) {
                                                        $dirty |= $composer3.changed(function1) ? 32 : 16;
                                                    }
                                                    int $dirty2 = $dirty;
                                                    if (($dirty2 & 731) == 146 && $composer3.getSkipping()) {
                                                        $composer3.skipToGroupEnd();
                                                        return;
                                                    }
                                                    if (ComposerKt.isTraceInProgress()) {
                                                        ComposerKt.traceEventStart(1107980410, $dirty2, -1, "vea.raceremote.CarIdentitySelectionTest.selection.<anonymous>.<anonymous>.<anonymous>.<anonymous> (CarIdentitySelectionTest.kt:76)");
                                                    }
                                                    Modifier modifierTestTag = TestTagKt.testTag(Modifier.Companion, LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m558String$arg0$calltestTag$valtmp0_modifier$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest());
                                                    Object key2$iv = Long.valueOf(j3);
                                                    final long j4 = j3;
                                                    int i = ($dirty2 >> 3) & 14;
                                                    $composer3.startReplaceableGroup(511388516);
                                                    ComposerKt.sourceInformation($composer3, "C(remember)P(1,2):Composables.kt#9igjgp");
                                                    boolean invalid$iv$iv = $composer3.changed(function1) | $composer3.changed(key2$iv);
                                                    Object it$iv$iv = $composer3.rememberedValue();
                                                    if (invalid$iv$iv || it$iv$iv == Composer.Companion.getEmpty()) {
                                                        value$iv$iv = (Function0) new Function0<Unit>() { // from class: vea.raceremote.CarIdentitySelectionTest$selection$2$1$1$1$1$1
                                                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                                            {
                                                                super(0);
                                                            }

                                                            public /* bridge */ /* synthetic */ Object invoke() {
                                                                m484invoke();
                                                                return Unit.INSTANCE;
                                                            }

                                                            /* JADX INFO: renamed from: invoke, reason: collision with other method in class */
                                                            public final void m484invoke() {
                                                                function1.invoke(new DiscoveredCar(LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m540String$arg0$call$init$$arg0$callinvoke$fun$anonymous$$arg0$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest(), LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m525Int$arg1$call$init$$arg0$callinvoke$fun$anonymous$$arg0$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest(), j4, LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m514Boolean$arg3$call$init$$arg0$callinvoke$fun$anonymous$$arg0$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest(), (String) null, 0, 48, (DefaultConstructorMarker) null));
                                                            }
                                                        };
                                                        $composer3.updateRememberedValue(value$iv$iv);
                                                    } else {
                                                        value$iv$iv = it$iv$iv;
                                                    }
                                                    $composer3.endReplaceableGroup();
                                                    Object key2$iv2 = value$iv$iv;
                                                    ButtonKt.Button((Function0) key2$iv2, modifierTestTag, enabled, (MutableInteractionSource) null, (ButtonElevation) null, (Shape) null, (BorderStroke) null, (ButtonColors) null, (PaddingValues) null, ComposableSingletons$CarIdentitySelectionTestKt.INSTANCE.m492getLambda1$app_debug(), $composer3, (($dirty2 << 6) & 896) | 805306368, 504);
                                                    if (ComposerKt.isTraceInProgress()) {
                                                        ComposerKt.traceEventEnd();
                                                    }
                                                }
                                            }), LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m526Int$arg1$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest(), $composer2, 6, 0);
                                            if (ComposerKt.isTraceInProgress()) {
                                                ComposerKt.traceEventEnd();
                                                return;
                                            }
                                            return;
                                        }
                                        $composer2.skipToGroupEnd();
                                    }
                                }), $composer, 3072, 7);
                                if (ComposerKt.isTraceInProgress()) {
                                    ComposerKt.traceEventEnd();
                                    return;
                                }
                                return;
                            }
                            $composer.skipToGroupEnd();
                        }
                    }), 1, (Object) null);
                }
            });
            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m553String$arg0$callonNodeWithTag$$$this$callperformClick$try$funselection$classCarIdentitySelectionTest(), false, 2, null));
            AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m550String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$funselection$classCarIdentitySelectionTest(), false, 2, null), LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m546String$arg0$callassertTextContains$try$funselection$classCarIdentitySelectionTest(), LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m513Boolean$arg1$callassertTextContains$try$funselection$classCarIdentitySelectionTest(), false, 4, null);
            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m554String$arg0$callonNodeWithTag$$$this$callperformClick1$try$funselection$classCarIdentitySelectionTest(), false, 2, null));
            String strM542String$arg0$callassertEquals$try$funselection$classCarIdentitySelectionTest = LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m542String$arg0$callassertEquals$try$funselection$classCarIdentitySelectionTest();
            RecordedRequest recordedRequestTakeRequest = server.takeRequest(LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m528Long$arg0$calltakeRequest$arg0$callCHECK_NOT_NULL$$this$callgetPath$arg1$callassertEquals$try$funselection$classCarIdentitySelectionTest(), TimeUnit.SECONDS);
            Intrinsics.checkNotNull(recordedRequestTakeRequest);
            Assert.assertEquals(strM542String$arg0$callassertEquals$try$funselection$classCarIdentitySelectionTest, recordedRequestTakeRequest.getPath());
            if (!matching) {
                waitUntil(LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m531Long$arg0$callwaitUntil$branch$if$try$funselection$classCarIdentitySelectionTest(), new Function0<Boolean>() { // from class: vea.raceremote.CarIdentitySelectionTest.selection.3
                    {
                        super(0);
                    }

                    /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                    public final Boolean m485invoke() {
                        Object obj;
                        CarIdentitySelectionTest $this$invoke_u24lambda_u240 = CarIdentitySelectionTest.this;
                        try {
                            Result.Companion companion = Result.Companion;
                            obj = Result.constructor-impl(AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default($this$invoke_u24lambda_u240.getCompose(), LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m549String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil$branch$if$try$funselection$classCarIdentitySelectionTest(), false, 2, null), LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m545String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil$branch$if$try$funselection$classCarIdentitySelectionTest(), false, false, 6, null));
                        } catch (Throwable th) {
                            Result.Companion companion2 = Result.Companion;
                            obj = Result.constructor-impl(ResultKt.createFailure(th));
                        }
                        return Boolean.valueOf(Result.isSuccess-impl(obj));
                    }
                });
                Assert.assertEquals(Integer.valueOf(LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m515Int$arg0$callassertEquals$branch$if$try$funselection$classCarIdentitySelectionTest()), Integer.valueOf(arms.get()));
                Assert.assertEquals(Integer.valueOf(LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m516Int$arg0$callassertEquals1$branch$if$try$funselection$classCarIdentitySelectionTest()), Integer.valueOf(server.getRequestCount()));
                TextActionsKt.performTextClearance(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m555String$arg0$callonNodeWithTag$$$this$callperformTextClearance$branch$if$try$funselection$classCarIdentitySelectionTest(), false, 2, null));
                TextActionsKt.performTextReplacement(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m556String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$branch$if$try$funselection$classCarIdentitySelectionTest(), false, 2, null), LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m557String$arg0$callperformTextReplacement$branch$if$try$funselection$classCarIdentitySelectionTest());
                AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m548String$arg0$callonNodeWithTag$$$this$callassertTextContains$branch$if$try$funselection$classCarIdentitySelectionTest(), false, 2, null), LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m544String$arg0$callassertTextContains$branch$if$try$funselection$classCarIdentitySelectionTest(), false, false, 6, null);
                ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m552String$arg0$callonNodeWithTag$$$this$callperformClick$branch$if$try$funselection$classCarIdentitySelectionTest(), false, 2, null));
                String strM543String$arg0$callassertEquals2$branch$if$try$funselection$classCarIdentitySelectionTest = LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m543String$arg0$callassertEquals2$branch$if$try$funselection$classCarIdentitySelectionTest();
                RecordedRequest recordedRequestTakeRequest2 = server.takeRequest(LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m530Long$arg0$calltakeRequest$arg0$callCHECK_NOT_NULL$$this$callgetPath$arg1$callassertEquals2$branch$if$try$funselection$classCarIdentitySelectionTest(), TimeUnit.SECONDS);
                Intrinsics.checkNotNull(recordedRequestTakeRequest2);
                Assert.assertEquals(strM543String$arg0$callassertEquals2$branch$if$try$funselection$classCarIdentitySelectionTest, recordedRequestTakeRequest2.getPath());
            }
            RecordedRequest recordedRequestTakeRequest3 = server.takeRequest(LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m529Long$arg0$calltakeRequest$arg0$callCHECK_NOT_NULL$$this$callgetPath$arg1$callassertEquals1$try$funselection$classCarIdentitySelectionTest(), TimeUnit.SECONDS);
            Intrinsics.checkNotNull(recordedRequestTakeRequest3);
            Assert.assertEquals("/control/identity", recordedRequestTakeRequest3.getPath());
            waitUntil(LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m532Long$arg0$callwaitUntil$try$funselection$classCarIdentitySelectionTest(), new Function0<Boolean>() { // from class: vea.raceremote.CarIdentitySelectionTest.selection.4
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                public final Boolean m486invoke() {
                    return Boolean.valueOf(drives.get() > LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m527Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$funselection$classCarIdentitySelectionTest());
                }
            });
            AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m551String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$funselection$classCarIdentitySelectionTest(), false, 2, null), LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m547String$arg0$callassertTextContains1$try$funselection$classCarIdentitySelectionTest(), false, false, 6, null);
            Assert.assertEquals(Integer.valueOf(LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m517Int$arg0$callassertEquals2$try$funselection$classCarIdentitySelectionTest()), Integer.valueOf(arms.get()));
            try {
                ((ActivityScenarioRule) getActivityRule()).getScenario().moveToState(Lifecycle.State.STARTED);
            } finally {
                server.shutdown();
            }
        } catch (Throwable th) {
            try {
                ((ActivityScenarioRule) getActivityRule()).getScenario().moveToState(Lifecycle.State.STARTED);
                throw th;
            } finally {
                server.shutdown();
            }
        }
    }
}
