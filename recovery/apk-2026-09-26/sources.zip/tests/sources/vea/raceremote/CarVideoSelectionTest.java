package vea.raceremote;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import androidx.compose.ui.geometry.Offset;
import androidx.compose.ui.test.ActionsKt;
import androidx.compose.ui.test.AssertionsKt;
import androidx.compose.ui.test.FindersKt;
import androidx.compose.ui.test.SemanticsNodeInteraction;
import androidx.compose.ui.test.TextActionsKt;
import androidx.compose.ui.test.junit4.AndroidComposeTestRule;
import androidx.compose.ui.test.junit4.AndroidComposeTestRule_androidKt;
import androidx.lifecycle.Lifecycle;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.io.CloseableKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okio.Buffer;
import okio.ByteString;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import vea.raceremote.app.MainActivity;
import vea.raceremote.control.ControlPacket;

/* JADX INFO: compiled from: CarVideoSelectionTest.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u001c\u0010\t\u001a\u00020\n2\u0012\u0010\u000b\u001a\u000e\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u000e0\fH\u0002J\b\u0010\u000f\u001a\u00020\nH\u0007J\u0010\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\rH\u0002R%\u0010\u0003\u001a\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0004\u0012\u00020\u00060\u00048G¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b¨\u0006\u0013"}, d2 = {"Lvea/raceremote/CarVideoSelectionTest;", "", "()V", "compose", "Landroidx/compose/ui/test/junit4/AndroidComposeTestRule;", "Landroidx/test/ext/junit/rules/ActivityScenarioRule;", "Lvea/raceremote/app/MainActivity;", "getCompose", "()Landroidx/compose/ui/test/junit4/AndroidComposeTestRule;", "awaitPixel", "", "matches", "Lkotlin/Function1;", "", "", "changingCarClearsPreviousVideoAndRequiresExplicitRestart", "stream", "Lokhttp3/mockwebserver/MockResponse;", "color", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class CarVideoSelectionTest {
    public static final int $stable = AndroidComposeTestRule.$stable;
    private final AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity> compose = AndroidComposeTestRule_androidKt.createAndroidComposeRule(MainActivity.class);

    @Rule
    public final AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity> getCompose() {
        return this.compose;
    }

    @Test
    public final void changingCarClearsPreviousVideoAndRequiresExplicitRestart() throws IOException {
        MockWebServer firstVideo = new MockWebServer();
        MockWebServer nextVideo = new MockWebServer();
        MockWebServer control = new MockWebServer();
        final AtomicInteger drives = new AtomicInteger();
        firstVideo.enqueue(stream(-16776961));
        nextVideo.enqueue(stream(-65536));
        ControlStatusFixtureKt.enqueueControlStatus(control);
        control.enqueue(new MockResponse().withWebSocketUpgrade(new WebSocketListener() { // from class: vea.raceremote.CarVideoSelectionTest.changingCarClearsPreviousVideoAndRequiresExplicitRestart.1
            public void onOpen(WebSocket webSocket, Response response) {
                Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                Intrinsics.checkNotNullParameter(response, "response");
                ControlStatusFixtureKt.sendFixtureIdentity(webSocket, LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m581Long$arg0$callsendFixtureIdentity$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue2$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest());
                byte[] bArrEncode = new ControlPacket(128, LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m585Long$arg1$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue2$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest(), LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m587Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue2$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest(), 0, 0, 24, (DefaultConstructorMarker) null).encode();
                webSocket.send(ByteString.of(Arrays.copyOf(bArrEncode, bArrEncode.length)));
            }

            public void onMessage(WebSocket webSocket, ByteString bytes) {
                Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                Intrinsics.checkNotNullParameter(bytes, "bytes");
                ControlPacket.Companion companion = ControlPacket.Companion;
                byte[] byteArray = bytes.toByteArray();
                Intrinsics.checkNotNullExpressionValue(byteArray, "bytes.toByteArray()");
                ControlPacket packet = companion.decode(byteArray);
                Intrinsics.checkNotNull(packet);
                if (packet.getKind() == 2) {
                    drives.incrementAndGet();
                }
                if (packet.getKind() != 3) {
                    byte[] bArrEncode = ControlPacket.copy$default(packet, 129, 0L, 0L, 0, 0, 30, (Object) null).encode();
                    webSocket.send(ByteString.of(Arrays.copyOf(bArrEncode, bArrEncode.length)));
                }
            }
        }));
        firstVideo.start();
        nextVideo.start();
        control.start(LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m567Int$arg0$callstart2$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest());
        try {
            runOnUiThread(new Function0<Unit>() { // from class: vea.raceremote.CarVideoSelectionTest.changingCarClearsPreviousVideoAndRequiresExplicitRestart.2
                {
                    super(0);
                }

                public /* bridge */ /* synthetic */ Object invoke() {
                    m490invoke();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: collision with other method in class */
                public final void m490invoke() {
                    ControlStatusFixtureKt.showControlFixture(CarVideoSelectionTest.this.getCompose().getActivity());
                }
            });
            TextActionsKt.performTextReplacement(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m606String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest(), false, 2, null), LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m611String$arg0$callperformTextReplacement$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest());
            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m602String$arg0$callonNodeWithTag$$$this$callperformClick$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest(), false, 2, null));
            SemanticsNodeInteraction semanticsNodeInteractionOnNodeWithTag$default = FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m607String$arg0$callonNodeWithTag$$$this$callperformTextReplacement1$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest(), false, 2, null);
            String string = firstVideo.url(LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m614String$arg0$callurl$$this$calltoString$arg0$callperformTextReplacement1$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest()).toString();
            Intrinsics.checkNotNullExpressionValue(string, "firstVideo.url(\"/stream\").toString()");
            TextActionsKt.performTextReplacement(semanticsNodeInteractionOnNodeWithTag$default, string);
            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m603String$arg0$callonNodeWithTag$$$this$callperformClick1$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest(), false, 2, null));
            awaitPixel(new Function1<Integer, Boolean>() { // from class: vea.raceremote.CarVideoSelectionTest.changingCarClearsPreviousVideoAndRequiresExplicitRestart.3
                public final Boolean invoke(int it) {
                    return Boolean.valueOf(Color.blue(it) > LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m571Int$arg1$callgreater$cond$fun$anonymous$$arg0$callawaitPixel$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest() && Color.red(it) < LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m576Int$arg1$callless$branch$fun$anonymous$$arg0$callawaitPixel$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest());
                }

                public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                    return invoke(((Number) p1).intValue());
                }
            });
            TextActionsKt.performTextReplacement(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m608String$arg0$callonNodeWithTag$$$this$callperformTextReplacement2$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest(), false, 2, null), LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m612String$arg0$callperformTextReplacement2$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest());
            AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m599String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest(), false, 2, null), LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m593String$arg0$callassertTextContains$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest(), false, false, 6, null);
            AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m600String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest(), false, 2, null), LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m594String$arg0$callassertTextContains1$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest(), false, false, 6, null);
            awaitPixel(new Function1<Integer, Boolean>() { // from class: vea.raceremote.CarVideoSelectionTest.changingCarClearsPreviousVideoAndRequiresExplicitRestart.4
                public final Boolean invoke(int it) {
                    return Boolean.valueOf(Color.red(it) < LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m580Int$arg1$callless$cond$cond$fun$anonymous$$arg0$callawaitPixel1$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest() && Color.green(it) < LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m575Int$arg1$callless$branch$cond$fun$anonymous$$arg0$callawaitPixel1$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest() && Color.blue(it) < LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m577Int$arg1$callless$branch$fun$anonymous$$arg0$callawaitPixel1$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest());
                }

                public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                    return invoke(((Number) p1).intValue());
                }
            });
            Assert.assertEquals(Integer.valueOf(LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m560Int$arg0$callassertEquals$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest()), Integer.valueOf(control.getRequestCount()));
            AssertionsKt.assertIsNotEnabled(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m598String$arg0$callonNodeWithTag$$$this$callassertIsNotEnabled$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest(), false, 2, null));
            SemanticsNodeInteraction semanticsNodeInteractionOnNodeWithTag$default2 = FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m609String$arg0$callonNodeWithTag$$$this$callperformTextReplacement3$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest(), false, 2, null);
            String string2 = nextVideo.url(LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m615String$arg0$callurl$$this$calltoString$arg0$callperformTextReplacement3$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest()).toString();
            Intrinsics.checkNotNullExpressionValue(string2, "nextVideo.url(\"/stream\").toString()");
            TextActionsKt.performTextReplacement(semanticsNodeInteractionOnNodeWithTag$default2, string2);
            waitForIdle();
            Assert.assertEquals(Integer.valueOf(LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m561Int$arg0$callassertEquals1$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest()), Integer.valueOf(nextVideo.getRequestCount()));
            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m604String$arg0$callonNodeWithTag$$$this$callperformClick2$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest(), false, 2, null));
            awaitPixel(new Function1<Integer, Boolean>() { // from class: vea.raceremote.CarVideoSelectionTest.changingCarClearsPreviousVideoAndRequiresExplicitRestart.5
                public final Boolean invoke(int it) {
                    return Boolean.valueOf(Color.red(it) > LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m572Int$arg1$callgreater$cond$fun$anonymous$$arg0$callawaitPixel2$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest() && Color.blue(it) < LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m578Int$arg1$callless$branch$fun$anonymous$$arg0$callawaitPixel2$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest());
                }

                public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                    return invoke(((Number) p1).intValue());
                }
            });
            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m605String$arg0$callonNodeWithTag$$$this$callperformClick3$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest(), false, 2, null));
            waitUntil(LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m583Long$arg0$callwaitUntil$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest(), new Function0<Boolean>() { // from class: vea.raceremote.CarVideoSelectionTest.changingCarClearsPreviousVideoAndRequiresExplicitRestart.6
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                public final Boolean m491invoke() {
                    return Boolean.valueOf(drives.get() > LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m574Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest());
                }
            });
            AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m601String$arg0$callonNodeWithTag$$$this$callassertTextContains2$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest(), false, 2, null), LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m595String$arg0$callassertTextContains2$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest(), false, false, 6, null);
            awaitPixel(new Function1<Integer, Boolean>() { // from class: vea.raceremote.CarVideoSelectionTest.changingCarClearsPreviousVideoAndRequiresExplicitRestart.7
                public final Boolean invoke(int it) {
                    return Boolean.valueOf(Color.red(it) > LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m573Int$arg1$callgreater$cond$fun$anonymous$$arg0$callawaitPixel3$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest() && Color.blue(it) < LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m579Int$arg1$callless$branch$fun$anonymous$$arg0$callawaitPixel3$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest());
                }

                public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                    return invoke(((Number) p1).intValue());
                }
            });
            Assert.assertEquals(Integer.valueOf(LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m562Int$arg0$callassertEquals2$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest()), Integer.valueOf(firstVideo.getRequestCount()));
            Assert.assertEquals(Integer.valueOf(LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m563Int$arg0$callassertEquals3$try$funchangingCarClearsPreviousVideoAndRequiresExplicitRestart$classCarVideoSelectionTest()), Integer.valueOf(nextVideo.getRequestCount()));
            try {
                ((ActivityScenarioRule) getActivityRule()).getScenario().moveToState(Lifecycle.State.STARTED);
                try {
                    control.shutdown();
                    try {
                        firstVideo.shutdown();
                    } finally {
                        nextVideo.shutdown();
                    }
                } catch (Throwable th) {
                    try {
                        firstVideo.shutdown();
                        throw th;
                    } finally {
                        nextVideo.shutdown();
                    }
                }
            } catch (Throwable th2) {
                try {
                    control.shutdown();
                    try {
                        firstVideo.shutdown();
                        throw th2;
                    } finally {
                        nextVideo.shutdown();
                    }
                } catch (Throwable th3) {
                    try {
                        firstVideo.shutdown();
                        throw th3;
                    } finally {
                        nextVideo.shutdown();
                    }
                }
            }
        } catch (Throwable th4) {
            try {
                ((ActivityScenarioRule) getActivityRule()).getScenario().moveToState(Lifecycle.State.STARTED);
                try {
                    control.shutdown();
                    try {
                        firstVideo.shutdown();
                        throw th4;
                    } finally {
                        nextVideo.shutdown();
                    }
                } catch (Throwable th5) {
                    try {
                        firstVideo.shutdown();
                        throw th5;
                    } finally {
                        nextVideo.shutdown();
                    }
                }
            } catch (Throwable th6) {
                try {
                    control.shutdown();
                    try {
                        firstVideo.shutdown();
                        throw th6;
                    } finally {
                        nextVideo.shutdown();
                    }
                } catch (Throwable th7) {
                    try {
                        firstVideo.shutdown();
                        throw th7;
                    } finally {
                        nextVideo.shutdown();
                    }
                }
            }
        }
    }

    private final void awaitPixel(final Function1<? super Integer, Boolean> matches) {
        runOnIdle(new Function0<Unit>() { // from class: vea.raceremote.CarVideoSelectionTest.awaitPixel.1
            {
                super(0);
            }

            public final Unit invoke() {
                View currentFocus = CarVideoSelectionTest.this.getCompose().getActivity().getCurrentFocus();
                if (currentFocus != null) {
                    currentFocus.clearFocus();
                }
                WindowInsetsController insetsController = CarVideoSelectionTest.this.getCompose().getActivity().getWindow().getInsetsController();
                if (insetsController == null) {
                    return null;
                }
                insetsController.hide(WindowInsets.Type.ime());
                return Unit.INSTANCE;
            }
        });
        waitUntil(LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m582Long$arg0$callwaitUntil$funawaitPixel$classCarVideoSelectionTest(), new Function0<Boolean>() { // from class: vea.raceremote.CarVideoSelectionTest.awaitPixel.2
            {
                super(0);
            }

            /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
            public final Boolean m488invoke() {
                return Boolean.valueOf(!CarVideoSelectionTest.this.getCompose().getActivity().getWindow().getDecorView().getRootWindowInsets().isVisible(WindowInsets.Type.ime()));
            }
        });
        final Ref.ObjectRef previous = new Ref.ObjectRef();
        waitUntil(LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m584Long$arg0$callwaitUntil1$funawaitPixel$classCarVideoSelectionTest(), new Function0<Boolean>() { // from class: vea.raceremote.CarVideoSelectionTest.awaitPixel.3
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            {
                super(0);
            }

            /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
            public final Boolean m489invoke() {
                long center = SemanticsNodeInteraction.fetchSemanticsNode$default(FindersKt.onNodeWithTag$default(CarVideoSelectionTest.this.getCompose(), LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m610String$arg0$callonNodeWithTag$$this$callfetchSemanticsNode$$this$call$getboundsInWindow$$$this$call$getcenter$$valcenter$fun$anonymous$$arg1$callwaitUntil1$funawaitPixel$classCarVideoSelectionTest(), false, 2, null), null, 1, null).getBoundsInWindow().getCenter-F1C5BW0();
                Bitmap screenshot = InstrumentationRegistry.getInstrumentation().getUiAutomation().takeScreenshot();
                if (screenshot == null) {
                    throw new IllegalArgumentException("Required value was null.".toString());
                }
                int pixel = screenshot.getPixel((int) Offset.getX-impl(center), (int) Offset.getY-impl(center));
                Integer num = (Integer) previous.element;
                if ((num == null || num.intValue() != pixel) && !((Boolean) matches.invoke(Integer.valueOf(pixel))).booleanValue()) {
                    File file = new File(CarVideoSelectionTest.this.getCompose().getActivity().getExternalFilesDir((String) null), LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m616String$arg1$call$init$$valfile$branch$if$fun$anonymous$$arg1$callwaitUntil1$funawaitPixel$classCarVideoSelectionTest());
                    FileOutputStream fileOutputStream = new FileOutputStream(file);
                    try {
                        FileOutputStream it = fileOutputStream;
                        screenshot.compress(Bitmap.CompressFormat.PNG, LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m569Int$arg1$callcompress$fun$anonymous$$arg0$calluse$branch$if$fun$anonymous$$arg1$callwaitUntil1$funawaitPixel$classCarVideoSelectionTest(), it);
                        CloseableKt.closeFinally(fileOutputStream, (Throwable) null);
                        Log.d(LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m596String$arg0$calld$branch$if$fun$anonymous$$arg1$callwaitUntil1$funawaitPixel$classCarVideoSelectionTest(), LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m589String$0$str$arg1$calld$branch$if$fun$anonymous$$arg1$callwaitUntil1$funawaitPixel$classCarVideoSelectionTest() + CarVideoSelectionTest.this.getCompose().getActivity().getWindow().getDecorView().getRootWindowInsets().isVisible(WindowInsets.Type.ime()));
                    } catch (Throwable th) {
                        try {
                            throw th;
                        } catch (Throwable th2) {
                            CloseableKt.closeFinally(fileOutputStream, th);
                            throw th2;
                        }
                    }
                }
                screenshot.recycle();
                Integer num2 = (Integer) previous.element;
                if (num2 == null || num2.intValue() != pixel) {
                    Log.d(LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m597String$arg0$calld$branch$if1$fun$anonymous$$arg1$callwaitUntil1$funawaitPixel$classCarVideoSelectionTest(), LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m590String$0$str$arg1$calld$branch$if1$fun$anonymous$$arg1$callwaitUntil1$funawaitPixel$classCarVideoSelectionTest() + Integer.toHexString(pixel) + LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m592String$2$str$arg1$calld$branch$if1$fun$anonymous$$arg1$callwaitUntil1$funawaitPixel$classCarVideoSelectionTest() + ((Object) Offset.toString-impl(center)));
                }
                previous.element = Integer.valueOf(pixel);
                return (Boolean) matches.invoke(Integer.valueOf(pixel));
            }
        });
    }

    private final MockResponse stream(int color) {
        Bitmap bitmap = Bitmap.createBitmap(LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m564Int$arg0$callcreateBitmap$valbitmap$funstream$classCarVideoSelectionTest(), LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m570Int$arg1$callcreateBitmap$valbitmap$funstream$classCarVideoSelectionTest(), Bitmap.Config.ARGB_8888);
        bitmap.eraseColor(color);
        ByteArrayOutputStream it = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m568Int$arg1$callcompress$fun$anonymous$$arg0$callalso$$this$calltoByteArray$valjpeg$funstream$classCarVideoSelectionTest(), it);
        byte[] jpeg = it.toByteArray();
        bitmap.recycle();
        Buffer body = new Buffer();
        int iM566Int$arg0$callrepeat$funstream$classCarVideoSelectionTest = LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m566Int$arg0$callrepeat$funstream$classCarVideoSelectionTest();
        for (int i = 0; i < iM566Int$arg0$callrepeat$funstream$classCarVideoSelectionTest; i++) {
            body.writeUtf8(LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m588String$0$str$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funstream$classCarVideoSelectionTest() + jpeg.length + LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m591String$2$str$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funstream$classCarVideoSelectionTest()).write(jpeg);
        }
        MockResponse mockResponseThrottleBody = new MockResponse().setHeader(LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m613String$arg0$callsetHeader$$this$callsetBody$$this$callthrottleBody$funstream$classCarVideoSelectionTest(), LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m617String$arg1$callsetHeader$$this$callsetBody$$this$callthrottleBody$funstream$classCarVideoSelectionTest()).setBody(body).throttleBody(((long) jpeg.length) + ((long) LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m565Int$arg0$callplus$arg0$callthrottleBody$funstream$classCarVideoSelectionTest()), LiveLiterals$CarVideoSelectionTestKt.INSTANCE.m586Long$arg1$callthrottleBody$funstream$classCarVideoSelectionTest(), TimeUnit.MILLISECONDS);
        Intrinsics.checkNotNullExpressionValue(mockResponseThrottleBody, "MockResponse().setHeader…0, TimeUnit.MILLISECONDS)");
        return mockResponseThrottleBody;
    }
}
