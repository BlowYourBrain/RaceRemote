package vea.raceremote;

import androidx.compose.foundation.layout.RowScope;
import androidx.compose.material.TextKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: CarIdentitySelectionTest.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
public final class ComposableSingletons$CarIdentitySelectionTestKt {
    public static final ComposableSingletons$CarIdentitySelectionTestKt INSTANCE = new ComposableSingletons$CarIdentitySelectionTestKt();

    /* JADX INFO: renamed from: lambda-1, reason: not valid java name */
    public static Function3<RowScope, Composer, Integer, Unit> f0lambda1 = ComposableLambdaKt.composableLambdaInstance(1491050122, false, new Function3<RowScope, Composer, Integer, Unit>() { // from class: vea.raceremote.ComposableSingletons$CarIdentitySelectionTestKt$lambda-1$1
        public /* bridge */ /* synthetic */ Object invoke(Object p1, Object p2, Object p3) {
            invoke((RowScope) p1, (Composer) p2, ((Number) p3).intValue());
            return Unit.INSTANCE;
        }

        public final void invoke(RowScope $this$Button, Composer $composer, int $changed) {
            Intrinsics.checkNotNullParameter($this$Button, "$this$Button");
            ComposerKt.sourceInformation($composer, "C78@3979L15:CarIdentitySelectionTest.kt#njci4t");
            if (($changed & 81) == 16 && $composer.getSkipping()) {
                $composer.skipToGroupEnd();
                return;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1491050122, $changed, -1, "vea.raceremote.ComposableSingletons$CarIdentitySelectionTestKt.lambda-1.<anonymous> (CarIdentitySelectionTest.kt:78)");
            }
            TextKt.Text-fLXpl1I(LiveLiterals$CarIdentitySelectionTestKt.INSTANCE.m541String$arg0$callText$fun$anonymous$$arg9$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest(), (Modifier) null, 0L, 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, (Function1) null, (TextStyle) null, $composer, 0, 0, 65534);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
    });

    /* JADX INFO: renamed from: getLambda-1$app_debug, reason: not valid java name */
    public final Function3<RowScope, Composer, Integer, Unit> m492getLambda1$app_debug() {
        return f0lambda1;
    }
}
