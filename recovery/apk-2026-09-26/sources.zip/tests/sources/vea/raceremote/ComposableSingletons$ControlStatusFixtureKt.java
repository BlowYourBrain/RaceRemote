package vea.raceremote;

import androidx.compose.material.Colors;
import androidx.compose.material.MaterialThemeKt;
import androidx.compose.material.Shapes;
import androidx.compose.material.Typography;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function4;
import vea.raceremote.control.CarControlScreenKt;

/* JADX INFO: compiled from: ControlStatusFixture.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
public final class ComposableSingletons$ControlStatusFixtureKt {
    public static final ComposableSingletons$ControlStatusFixtureKt INSTANCE = new ComposableSingletons$ControlStatusFixtureKt();

    /* JADX INFO: renamed from: lambda-1, reason: not valid java name */
    public static Function2<Composer, Integer, Unit> f1lambda1 = ComposableLambdaKt.composableLambdaInstance(1794563223, false, new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.ComposableSingletons$ControlStatusFixtureKt$lambda-1$1
        public /* bridge */ /* synthetic */ Object invoke(Object p1, Object p2) {
            invoke((Composer) p1, ((Number) p2).intValue());
            return Unit.INSTANCE;
        }

        public final void invoke(Composer $composer, int $changed) {
            ComposerKt.sourceInformation($composer, "C27@1077L35:ControlStatusFixture.kt#njci4t");
            if (($changed & 11) == 2 && $composer.getSkipping()) {
                $composer.skipToGroupEnd();
                return;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1794563223, $changed, -1, "vea.raceremote.ComposableSingletons$ControlStatusFixtureKt.lambda-1.<anonymous> (ControlStatusFixture.kt:27)");
            }
            CarControlScreenKt.CarControlScreen((Function4) null, LiveLiterals$ControlStatusFixtureKt.INSTANCE.m639Int$arg1$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$funshowControlFixture(), $composer, 0, 1);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
    });

    /* JADX INFO: renamed from: lambda-2, reason: not valid java name */
    public static Function2<Composer, Integer, Unit> f2lambda2 = ComposableLambdaKt.composableLambdaInstance(-1456970301, false, new Function2<Composer, Integer, Unit>() { // from class: vea.raceremote.ComposableSingletons$ControlStatusFixtureKt$lambda-2$1
        public /* bridge */ /* synthetic */ Object invoke(Object p1, Object p2) {
            invoke((Composer) p1, ((Number) p2).intValue());
            return Unit.INSTANCE;
        }

        public final void invoke(Composer $composer, int $changed) {
            ComposerKt.sourceInformation($composer, "C27@1061L53:ControlStatusFixture.kt#njci4t");
            if (($changed & 11) == 2 && $composer.getSkipping()) {
                $composer.skipToGroupEnd();
                return;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1456970301, $changed, -1, "vea.raceremote.ComposableSingletons$ControlStatusFixtureKt.lambda-2.<anonymous> (ControlStatusFixture.kt:27)");
            }
            MaterialThemeKt.MaterialTheme((Colors) null, (Typography) null, (Shapes) null, ComposableSingletons$ControlStatusFixtureKt.INSTANCE.m493getLambda1$app_debug(), $composer, 3072, 7);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
    });

    /* JADX INFO: renamed from: getLambda-1$app_debug, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m493getLambda1$app_debug() {
        return f1lambda1;
    }

    /* JADX INFO: renamed from: getLambda-2$app_debug, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m494getLambda2$app_debug() {
        return f2lambda2;
    }
}
