package vea.raceremote;

import java.io.IOException;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.text.StringsKt;
import okhttp3.OkHttpClient;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.Assert;
import org.junit.Test;
import vea.raceremote.control.ControlEndpoint;
import vea.raceremote.control.ControlEndpointProbe;

/* JADX INFO: compiled from: ControlEndpointProbeTest.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0007¨\u0006\u0005"}, d2 = {"Lvea/raceremote/ControlEndpointProbeTest;", "", "()V", "realJsonProbeRejectsRedirectOversizeAndInvalidStatus", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class ControlEndpointProbeTest {
    public static final int $stable = LiveLiterals$ControlEndpointProbeTestKt.INSTANCE.m622Int$classControlEndpointProbeTest();

    @Test
    public final void realJsonProbeRejectsRedirectOversizeAndInvalidStatus() throws IOException {
        Object obj;
        MockWebServer server = new MockWebServer();
        String valid = LiveLiterals$ControlEndpointProbeTestKt.INSTANCE.m633String$valvalid$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest();
        server.enqueue(new MockResponse().setBody(valid));
        server.enqueue(new MockResponse().setResponseCode(LiveLiterals$ControlEndpointProbeTestKt.INSTANCE.m621Int$arg0$callsetResponseCode$$this$callsetHeader$arg0$callenqueue1$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest()).setHeader(LiveLiterals$ControlEndpointProbeTestKt.INSTANCE.m630String$arg0$callsetHeader$arg0$callenqueue1$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest(), LiveLiterals$ControlEndpointProbeTestKt.INSTANCE.m632String$arg1$callsetHeader$arg0$callenqueue1$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest()));
        server.enqueue(new MockResponse().setBody(StringsKt.repeat(LiveLiterals$ControlEndpointProbeTestKt.INSTANCE.m624String$$$this$callrepeat$arg0$callsetBody$arg0$callenqueue2$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest(), LiveLiterals$ControlEndpointProbeTestKt.INSTANCE.m619Int$arg0$callrepeat$arg0$callsetBody$arg0$callenqueue2$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest())));
        server.enqueue(new MockResponse().setBody(StringsKt.replace$default(valid, LiveLiterals$ControlEndpointProbeTestKt.INSTANCE.m628String$arg0$callreplace$arg0$callsetBody$arg0$callenqueue3$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest(), LiveLiterals$ControlEndpointProbeTestKt.INSTANCE.m631String$arg1$callreplace$arg0$callsetBody$arg0$callenqueue3$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest(), false, 4, (Object) null)));
        server.enqueue(new MockResponse().setBody(LiveLiterals$ControlEndpointProbeTestKt.INSTANCE.m629String$arg0$callsetBody$arg0$callenqueue4$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest()));
        server.start();
        OkHttpClient http = new OkHttpClient();
        try {
            ControlEndpoint endpoint = ControlEndpointProbe.INSTANCE.load(LiveLiterals$ControlEndpointProbeTestKt.INSTANCE.m627String$arg0$callload$valendpoint$try$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest(), http, server.getPort());
            Assert.assertEquals(LiveLiterals$ControlEndpointProbeTestKt.INSTANCE.m625String$arg0$callassertEquals$try$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest(), endpoint.getTransport());
            Assert.assertEquals(LiveLiterals$ControlEndpointProbeTestKt.INSTANCE.m623Long$arg0$callassertEquals1$try$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest(), endpoint.getChipId());
            int iM620Int$arg0$callrepeat$try$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest = LiveLiterals$ControlEndpointProbeTestKt.INSTANCE.m620Int$arg0$callrepeat$try$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest();
            for (int i = 0; i < iM620Int$arg0$callrepeat$try$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest; i++) {
                try {
                    Result.Companion companion = Result.Companion;
                    ControlEndpointProbeTest controlEndpointProbeTest = this;
                    obj = Result.constructor-impl(ControlEndpointProbe.INSTANCE.load(LiveLiterals$ControlEndpointProbeTestKt.INSTANCE.m626String$arg0$callload$fun$anonymous$$arg0$callrunCatching$$this$call$getisFailure$$arg0$callassertTrue$fun$anonymous$$arg1$callrepeat$try$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest(), http, server.getPort()));
                } catch (Throwable th) {
                    Result.Companion companion2 = Result.Companion;
                    obj = Result.constructor-impl(ResultKt.createFailure(th));
                }
                Assert.assertTrue(Result.isFailure-impl(obj));
            }
            Assert.assertEquals(Integer.valueOf(LiveLiterals$ControlEndpointProbeTestKt.INSTANCE.m618Int$arg0$callassertEquals2$try$funrealJsonProbeRejectsRedirectOversizeAndInvalidStatus$classControlEndpointProbeTest()), Integer.valueOf(server.getRequestCount()));
            server.shutdown();
            http.dispatcher().executorService().shutdown();
            http.connectionPool().evictAll();
        } catch (Throwable th2) {
            server.shutdown();
            http.dispatcher().executorService().shutdown();
            http.connectionPool().evictAll();
            throw th2;
        }
    }
}
