package vea.raceremote;

import androidx.activity.ComponentActivity;
import androidx.activity.compose.ComponentActivityKt;
import androidx.compose.runtime.CompositionContext;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.WebSocket;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okio.ByteString;
import vea.raceremote.app.MainActivity;

/* JADX INFO: compiled from: ControlStatusFixture.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000 \n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\u001a\f\u0010\u0002\u001a\u00020\u0003*\u00020\u0004H\u0000\u001a\u0014\u0010\u0005\u001a\u00020\u0003*\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u0001H\u0000\u001a\f\u0010\b\u001a\u00020\u0003*\u00020\tH\u0000\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0080T¢\u0006\u0002\n\u0000¨\u0006\n"}, d2 = {"FIXTURE_CHIP", "", "enqueueControlStatus", "", "Lokhttp3/mockwebserver/MockWebServer;", "sendFixtureIdentity", "Lokhttp3/WebSocket;", "token", "showControlFixture", "Lvea/raceremote/app/MainActivity;", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class ControlStatusFixtureKt {
    public static final long FIXTURE_CHIP = 1193046;

    public static final void enqueueControlStatus(MockWebServer $this$enqueueControlStatus) {
        Intrinsics.checkNotNullParameter($this$enqueueControlStatus, "<this>");
        $this$enqueueControlStatus.enqueue(new MockResponse().setBody(LiveLiterals$ControlStatusFixtureKt.INSTANCE.m640String$arg0$callsetBody$arg0$callenqueue$funenqueueControlStatus()));
    }

    public static final void sendFixtureIdentity(WebSocket $this$sendFixtureIdentity, long token) {
        Intrinsics.checkNotNullParameter($this$sendFixtureIdentity, "<this>");
        byte[] bytes = ByteBuffer.allocate(LiveLiterals$ControlStatusFixtureKt.INSTANCE.m638Int$arg0$callallocate$$this$callorder$$this$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity()).order(ByteOrder.LITTLE_ENDIAN).put(new byte[]{LiveLiterals$ControlStatusFixtureKt.INSTANCE.m634Byte$0$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity(), LiveLiterals$ControlStatusFixtureKt.INSTANCE.m635Byte$1$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity(), LiveLiterals$ControlStatusFixtureKt.INSTANCE.m636Byte$2$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity(), (byte) LiveLiterals$ControlStatusFixtureKt.INSTANCE.m637Int$$this$calltoByte$3$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity()}).putInt((int) token).putLong(1193046L).array();
        $this$sendFixtureIdentity.send(ByteString.of(Arrays.copyOf(bytes, bytes.length)));
    }

    public static final void showControlFixture(MainActivity $this$showControlFixture) {
        Intrinsics.checkNotNullParameter($this$showControlFixture, "<this>");
        ComponentActivityKt.setContent$default((ComponentActivity) $this$showControlFixture, (CompositionContext) null, ComposableSingletons$ControlStatusFixtureKt.INSTANCE.m494getLambda2$app_debug(), 1, (Object) null);
    }
}
