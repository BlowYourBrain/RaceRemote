package vea.raceremote;

import android.os.SystemClock;
import java.io.Closeable;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.io.CloseableKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;
import vea.raceremote.app.MainActivity;
import vea.raceremote.control.CarControlClient;
import vea.raceremote.control.ControlPacket;

/* JADX INFO: compiled from: DriveDeviceBenchTest.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0007J\b\u0010\u0005\u001a\u00020\u0004H\u0007J\u0010\u0010\u0006\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\bH\u0002J\b\u0010\t\u001a\u00020\u0004H\u0007J\b\u0010\n\u001a\u00020\u0004H\u0007¨\u0006\u000b"}, d2 = {"Lvea/raceremote/DriveDeviceBenchTest;", "", "()V", "nativeClientDrivePlan", "", "neutralLinkComparison", "runBench", "scenario", "", "silentSocketTimesOut", "udpDiscoveryLatency", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class DriveDeviceBenchTest {
    public static final int $stable = LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m717Int$classDriveDeviceBenchTest();

    @Test
    public final void nativeClientDrivePlan() throws JSONException {
        runBench(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m878String$arg0$callrunBench$funnativeClientDrivePlan$classDriveDeviceBenchTest());
    }

    @Test
    public final void silentSocketTimesOut() throws JSONException {
        runBench(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m880String$arg0$callrunBench$funsilentSocketTimesOut$classDriveDeviceBenchTest());
    }

    @Test
    public final void neutralLinkComparison() throws JSONException {
        runBench(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m879String$arg0$callrunBench$funneutralLinkComparison$classDriveDeviceBenchTest());
    }

    @Test
    public final void udpDiscoveryLatency() throws JSONException {
        runBench(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m881String$arg0$callrunBench$funudpDiscoveryLatency$classDriveDeviceBenchTest());
    }

    /*  JADX ERROR: Type inference failed
        jadx.core.utils.exceptions.JadxOverflowException: Type inference error: updates count limit reached with updateSeq = 51591. Try increasing type updates limit count.
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:79)
        */
    private final void runBench(java.lang.String r67) throws org.json.JSONException {
        /*
            Method dump skipped, instruction units count: 5159
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: vea.raceremote.DriveDeviceBenchTest.runBench(java.lang.String):void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void runBench$record(List<JSONObject> list, long started, String kind, Object data) {
        list.add(new JSONObject().put(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m840String$arg0$callput$$this$callput$$this$callput$arg0$calladd$funrecord$funrunBench$classDriveDeviceBenchTest(), SystemClock.elapsedRealtime() - started).put(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m845String$arg0$callput$$this$callput$arg0$calladd$funrecord$funrunBench$classDriveDeviceBenchTest(), kind).put(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m852String$arg0$callput$arg0$calladd$funrecord$funrunBench$classDriveDeviceBenchTest(), data));
    }

    /* JADX WARN: Code duplicated, block: B:19:0x014c  */
    private static final JSONObject runBench$status(OkHttpClient http, String host, String carId, List<JSONObject> list, long started, String phase) throws JSONException {
        boolean z;
        long before = SystemClock.elapsedRealtime();
        Response response = (Closeable) http.newCall(new Request.Builder().url(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m747String$0$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$valjson$funstatus$funrunBench$classDriveDeviceBenchTest() + host + LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m755String$2$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$valjson$funstatus$funrunBench$classDriveDeviceBenchTest()).build()).execute();
        try {
            Response response2 = response;
            Assert.assertEquals(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m764String$arg0$callassertEquals$fun$anonymous$$arg0$calluse$valjson$funstatus$funrunBench$classDriveDeviceBenchTest(), Integer.valueOf(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m706Int$arg1$callassertEquals$fun$anonymous$$arg0$calluse$valjson$funstatus$funrunBench$classDriveDeviceBenchTest()), Integer.valueOf(response2.code()));
            ResponseBody responseBodyBody = response2.body();
            if (responseBodyBody == null) {
                try {
                    throw new IllegalArgumentException("Required value was null.".toString());
                } catch (Throwable th) {
                    th = th;
                }
            } else {
                JSONObject json = new JSONObject(responseBodyBody.string());
                CloseableKt.closeFinally(response, (Throwable) null);
                String strM872String$arg0$callrecord$funstatus$funrunBench$classDriveDeviceBenchTest = LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m872String$arg0$callrecord$funstatus$funrunBench$classDriveDeviceBenchTest();
                JSONObject jSONObjectPut = new JSONObject().put(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m842String$arg0$callput$$this$callput$$this$callput$arg1$callrecord$funstatus$funrunBench$classDriveDeviceBenchTest(), phase).put(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m849String$arg0$callput$$this$callput$arg1$callrecord$funstatus$funrunBench$classDriveDeviceBenchTest(), SystemClock.elapsedRealtime() - before).put(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m856String$arg0$callput$arg1$callrecord$funstatus$funrunBench$classDriveDeviceBenchTest(), json);
                Intrinsics.checkNotNullExpressionValue(jSONObjectPut, "JSONObject().put(\"phase\"…efore).put(\"value\", json)");
                runBench$record(list, started, strM872String$arg0$callrecord$funstatus$funrunBench$classDriveDeviceBenchTest, jSONObjectPut);
                Assert.assertEquals(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m766String$arg0$callassertEquals$funstatus$funrunBench$classDriveDeviceBenchTest(), carId, json.getString(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m829String$arg0$callgetString$arg2$callassertEquals$funstatus$funrunBench$classDriveDeviceBenchTest()));
                Assert.assertEquals(Integer.valueOf(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m672Int$arg0$callassertEquals1$funstatus$funrunBench$classDriveDeviceBenchTest()), Integer.valueOf(json.getInt(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m810String$arg0$callgetInt$arg1$callassertEquals1$funstatus$funrunBench$classDriveDeviceBenchTest())));
                Assert.assertFalse(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m770String$arg0$callassertFalse$funstatus$funrunBench$classDriveDeviceBenchTest(), json.getBoolean(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m794String$arg0$callgetBoolean$arg1$callassertFalse$funstatus$funrunBench$classDriveDeviceBenchTest()));
                JSONObject p = json.getJSONObject(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m822String$arg0$callgetJSONObject$valp$funstatus$funrunBench$classDriveDeviceBenchTest());
                int fi = p.getInt(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m814String$arg0$callgetInt$valfi$funstatus$funrunBench$classDriveDeviceBenchTest());
                int bi = p.getInt(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m813String$arg0$callgetInt$valbi$funstatus$funrunBench$classDriveDeviceBenchTest());
                String strM776String$arg0$callassertTrue$funstatus$funrunBench$classDriveDeviceBenchTest = LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m776String$arg0$callassertTrue$funstatus$funrunBench$classDriveDeviceBenchTest();
                if (fi <= LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m690Int$arg0$callrangeTo$$this$callcontains$cond$arg1$callassertTrue$funstatus$funrunBench$classDriveDeviceBenchTest() && LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m667Int$$this$callrangeTo$$this$callcontains$cond$arg1$callassertTrue$funstatus$funrunBench$classDriveDeviceBenchTest() <= fi) {
                    if (bi <= LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m687Int$arg0$callrangeTo$$this$callcontains$branch$arg1$callassertTrue$funstatus$funrunBench$classDriveDeviceBenchTest() && LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m664Int$$this$callrangeTo$$this$callcontains$branch$arg1$callassertTrue$funstatus$funrunBench$classDriveDeviceBenchTest() <= bi) {
                        z = true;
                    } else {
                        z = false;
                    }
                } else {
                    z = false;
                }
                Assert.assertTrue(strM776String$arg0$callassertTrue$funstatus$funrunBench$classDriveDeviceBenchTest, z);
                Assert.assertTrue(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m779String$arg0$callassertTrue1$funstatus$funrunBench$classDriveDeviceBenchTest(), fi == 0 || bi == LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m704Int$arg1$callEQEQ$else$arg1$callassertTrue1$funstatus$funrunBench$classDriveDeviceBenchTest());
                return json;
            }
        } catch (Throwable th2) {
            th = th2;
        }
        Throwable th3 = th;
        try {
            throw th3;
        } catch (Throwable th4) {
            CloseableKt.closeFinally(response, th3);
            throw th4;
        }
    }

    private static final JSONObject runBench$awaitStatus(CarControlClient client, OkHttpClient http, String host, String carId, List<JSONObject> list, long started, String phase, Function1<? super JSONObject, Boolean> function1) throws JSONException {
        long deadline = SystemClock.elapsedRealtime() + ((long) LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m684Int$arg0$callplus$valdeadline$funawaitStatus$funrunBench$classDriveDeviceBenchTest());
        do {
            JSONObject value = runBench$status(http, host, carId, list, started, phase);
            if (((Boolean) function1.invoke(value)).booleanValue()) {
                return value;
            }
            SystemClock.sleep(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m732Long$arg0$callsleep$body$loop$funawaitStatus$funrunBench$classDriveDeviceBenchTest());
        } while (SystemClock.elapsedRealtime() < deadline);
        throw new AssertionError(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m743String$0$str$arg0$call$init$$funawaitStatus$funrunBench$classDriveDeviceBenchTest() + phase + LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m754String$2$str$arg0$call$init$$funawaitStatus$funrunBench$classDriveDeviceBenchTest() + client.getState().getValue());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean runBench$zero(JSONObject value) throws JSONException {
        JSONObject it = value.getJSONObject(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m815String$arg0$callgetJSONObject$$$this$calllet$funzero$funrunBench$classDriveDeviceBenchTest());
        return it.getInt(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m807String$arg0$callgetInt$arg0$callEQEQ$cond$fun$anonymous$$arg0$calllet$funzero$funrunBench$classDriveDeviceBenchTest()) == LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m703Int$arg1$callEQEQ$cond$fun$anonymous$$arg0$calllet$funzero$funrunBench$classDriveDeviceBenchTest() && it.getInt(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m804String$arg0$callgetInt$arg0$callEQEQ$branch$fun$anonymous$$arg0$calllet$funzero$funrunBench$classDriveDeviceBenchTest()) == LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m698Int$arg1$callEQEQ$branch$fun$anonymous$$arg0$calllet$funzero$funrunBench$classDriveDeviceBenchTest();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void runBench$lambda$7(MainActivity it) {
        it.getWindow().addFlags(128);
    }

    private static final ControlPacket runBench$packet(LinkedBlockingQueue<ControlPacket> linkedBlockingQueue, int kind, long sequence) throws InterruptedException {
        ControlPacket controlPacketPoll = linkedBlockingQueue.poll(LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m728Long$arg0$callpoll$arg0$callrequireNotNull$valp$funpacket$branch$if4$try$funrunBench$classDriveDeviceBenchTest(), TimeUnit.SECONDS);
        if (controlPacketPoll == null) {
            throw new IllegalArgumentException((LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m753String$0$str$fun$anonymous$$arg1$callrequireNotNull$valp$funpacket$branch$if4$try$funrunBench$classDriveDeviceBenchTest() + kind + LiveLiterals$DriveDeviceBenchTestKt.INSTANCE.m761String$2$str$fun$anonymous$$arg1$callrequireNotNull$valp$funpacket$branch$if4$try$funrunBench$classDriveDeviceBenchTest() + sequence).toString());
        }
        ControlPacket p = controlPacketPoll;
        Assert.assertEquals(Integer.valueOf(kind), Integer.valueOf(p.getKind()));
        Assert.assertEquals(sequence, p.getSequence());
        return p;
    }
}
