package vea.raceremote;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import androidx.compose.ui.geometry.Offset;
import androidx.compose.ui.geometry.OffsetKt;
import androidx.compose.ui.geometry.Rect;
import androidx.compose.ui.graphics.AndroidImageBitmap_androidKt;
import androidx.compose.ui.semantics.SemanticsActions;
import androidx.compose.ui.semantics.SemanticsProperties;
import androidx.compose.ui.test.ActionsKt;
import androidx.compose.ui.test.AndroidImageHelpers_androidKt;
import androidx.compose.ui.test.AssertionsKt;
import androidx.compose.ui.test.FindersKt;
import androidx.compose.ui.test.SemanticsMatcher;
import androidx.compose.ui.test.SemanticsNodeInteraction;
import androidx.compose.ui.test.TextActionsKt;
import androidx.compose.ui.test.TouchInjectionScope;
import androidx.compose.ui.test.junit4.AndroidComposeTestRule;
import androidx.compose.ui.test.junit4.AndroidComposeTestRule_androidKt;
import androidx.lifecycle.Lifecycle;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.io.CloseableKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okio.Buffer;
import okio.ByteString;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import vea.raceremote.app.MainActivity;
import vea.raceremote.control.ControlPacket;

/* JADX INFO: compiled from: DrivingModeTest.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\t\u001a\u00020\nH\u0007J\u0010\u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\rH\u0002J\b\u0010\u000e\u001a\u00020\nH\u0007R%\u0010\u0003\u001a\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0004\u0012\u00020\u00060\u00048G¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b¨\u0006\u000f"}, d2 = {"Lvea/raceremote/DrivingModeTest;", "", "()V", "compose", "Landroidx/compose/ui/test/junit4/AndroidComposeTestRule;", "Landroidx/test/ext/junit/rules/ActivityScenarioRule;", "Lvea/raceremote/app/MainActivity;", "getCompose", "()Landroidx/compose/ui/test/junit4/AndroidComposeTestRule;", "backgroundDuringDragDoesNotResumeControl", "", "screenshot", "name", "", "twoThumbsCancelAndVideoSurviveModeChanges", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class DrivingModeTest {
    public static final int $stable = AndroidComposeTestRule.$stable;
    private final AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity> compose = AndroidComposeTestRule_androidKt.createAndroidComposeRule(MainActivity.class);

    @Rule
    public final AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity> getCompose() {
        return this.compose;
    }

    @Test
    public final void twoThumbsCancelAndVideoSurviveModeChanges() throws Throwable {
        MockWebServer control = new MockWebServer();
        MockWebServer video = new MockWebServer();
        final AtomicReference latest = new AtomicReference();
        final AtomicInteger drives = new AtomicInteger();
        ControlStatusFixtureKt.enqueueControlStatus(control);
        control.enqueue(new MockResponse().withWebSocketUpgrade(new WebSocketListener() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.1
            public void onOpen(WebSocket webSocket, Response response) {
                Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                Intrinsics.checkNotNullParameter(response, "response");
                ControlStatusFixtureKt.sendFixtureIdentity(webSocket, LiveLiterals$DrivingModeTestKt.INSTANCE.m979Long$arg0$callsendFixtureIdentity$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest());
                byte[] bArrEncode = new ControlPacket(128, LiveLiterals$DrivingModeTestKt.INSTANCE.m995Long$arg1$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), LiveLiterals$DrivingModeTestKt.INSTANCE.m998Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), 0, 0, 24, (DefaultConstructorMarker) null).encode();
                webSocket.send(ByteString.of(Arrays.copyOf(bArrEncode, bArrEncode.length)));
            }

            public void onMessage(WebSocket webSocket, ByteString bytes) {
                Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                Intrinsics.checkNotNullParameter(bytes, "bytes");
                ControlPacket.Companion companion = ControlPacket.Companion;
                byte[] byteArray = bytes.toByteArray();
                Intrinsics.checkNotNullExpressionValue(byteArray, "bytes.toByteArray()");
                ControlPacket p = companion.decode(byteArray);
                Intrinsics.checkNotNull(p);
                if (p.getKind() == 2) {
                    latest.set(p);
                    drives.incrementAndGet();
                }
                if (p.getKind() != 3) {
                    byte[] bArrEncode = ControlPacket.copy$default(p, 129, 0L, 0L, 0, 0, 30, (Object) null).encode();
                    webSocket.send(ByteString.of(Arrays.copyOf(bArrEncode, bArrEncode.length)));
                }
            }
        }));
        Bitmap bitmap = Bitmap.createBitmap(LiveLiterals$DrivingModeTestKt.INSTANCE.m926Int$arg0$callcreateBitmap$valbitmap$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), LiveLiterals$DrivingModeTestKt.INSTANCE.m960Int$arg1$callcreateBitmap$valbitmap$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), Bitmap.Config.ARGB_8888);
        Canvas $this$twoThumbsCancelAndVideoSurviveModeChanges_u24lambda_u242 = new Canvas(bitmap);
        $this$twoThumbsCancelAndVideoSurviveModeChanges_u24lambda_u242.drawColor(Color.rgb(LiveLiterals$DrivingModeTestKt.INSTANCE.m943Int$arg0$callrgb$arg0$calldrawColor$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), LiveLiterals$DrivingModeTestKt.INSTANCE.m970Int$arg1$callrgb$arg0$calldrawColor$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), LiveLiterals$DrivingModeTestKt.INSTANCE.m972Int$arg2$callrgb$arg0$calldrawColor$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest()));
        String strM1010String$arg0$calldrawText$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest = LiveLiterals$DrivingModeTestKt.INSTANCE.m1010String$arg0$calldrawText$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest();
        float fM921Float$arg1$calldrawText$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest = LiveLiterals$DrivingModeTestKt.INSTANCE.m921Float$arg1$calldrawText$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest();
        float fM923Float$arg2$calldrawText$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest = LiveLiterals$DrivingModeTestKt.INSTANCE.m923Float$arg2$calldrawText$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest();
        Paint $this$twoThumbsCancelAndVideoSurviveModeChanges_u24lambda_u242_u24lambda_u240 = new Paint();
        $this$twoThumbsCancelAndVideoSurviveModeChanges_u24lambda_u242_u24lambda_u240.setColor(-1);
        $this$twoThumbsCancelAndVideoSurviveModeChanges_u24lambda_u242_u24lambda_u240.setTextSize(LiveLiterals$DrivingModeTestKt.INSTANCE.m913Float$arg0$callsetTextSize$fun$anonymous$$arg0$callapply$arg3$calldrawText$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest());
        Unit unit = Unit.INSTANCE;
        $this$twoThumbsCancelAndVideoSurviveModeChanges_u24lambda_u242.drawText(strM1010String$arg0$calldrawText$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest, fM921Float$arg1$calldrawText$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest, fM923Float$arg2$calldrawText$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest, $this$twoThumbsCancelAndVideoSurviveModeChanges_u24lambda_u242_u24lambda_u240);
        float fM911Float$arg0$calldrawRect$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest = LiveLiterals$DrivingModeTestKt.INSTANCE.m911Float$arg0$calldrawRect$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest();
        float fM920Float$arg1$calldrawRect$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest = LiveLiterals$DrivingModeTestKt.INSTANCE.m920Float$arg1$calldrawRect$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest();
        float fM922Float$arg2$calldrawRect$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest = LiveLiterals$DrivingModeTestKt.INSTANCE.m922Float$arg2$calldrawRect$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest();
        float fM924Float$arg3$calldrawRect$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest = LiveLiterals$DrivingModeTestKt.INSTANCE.m924Float$arg3$calldrawRect$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest();
        Paint $this$twoThumbsCancelAndVideoSurviveModeChanges_u24lambda_u242_u24lambda_u241 = new Paint();
        $this$twoThumbsCancelAndVideoSurviveModeChanges_u24lambda_u242_u24lambda_u241.setColor(Color.rgb(LiveLiterals$DrivingModeTestKt.INSTANCE.m944Int$arg0$callrgb$arg0$callsetColor$fun$anonymous$$arg0$callapply$arg4$calldrawRect$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), LiveLiterals$DrivingModeTestKt.INSTANCE.m971Int$arg1$callrgb$arg0$callsetColor$fun$anonymous$$arg0$callapply$arg4$calldrawRect$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), LiveLiterals$DrivingModeTestKt.INSTANCE.m973Int$arg2$callrgb$arg0$callsetColor$fun$anonymous$$arg0$callapply$arg4$calldrawRect$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest()));
        Unit unit2 = Unit.INSTANCE;
        $this$twoThumbsCancelAndVideoSurviveModeChanges_u24lambda_u242.drawRect(fM911Float$arg0$calldrawRect$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest, fM920Float$arg1$calldrawRect$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest, fM922Float$arg2$calldrawRect$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest, fM924Float$arg3$calldrawRect$fun$anonymous$$arg0$callapply$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest, $this$twoThumbsCancelAndVideoSurviveModeChanges_u24lambda_u242_u24lambda_u241);
        ByteArrayOutputStream it = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, LiveLiterals$DrivingModeTestKt.INSTANCE.m958Int$arg1$callcompress$fun$anonymous$$arg0$callalso$$this$calltoByteArray$valjpeg$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), it);
        byte[] jpeg = it.toByteArray();
        bitmap.recycle();
        byte[] part = new Buffer().writeUtf8(LiveLiterals$DrivingModeTestKt.INSTANCE.m1000String$0$str$arg0$callwriteUtf8$$this$callwrite$$this$callreadByteArray$valpart$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest() + jpeg.length + LiveLiterals$DrivingModeTestKt.INSTANCE.m1002String$2$str$arg0$callwriteUtf8$$this$callwrite$$this$callreadByteArray$valpart$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest()).write(jpeg).readByteArray();
        Buffer $this$twoThumbsCancelAndVideoSurviveModeChanges_u24lambda_u245 = new Buffer();
        int iM942Int$arg0$callrepeat$fun$anonymous$$arg0$callapply$valbody$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest = LiveLiterals$DrivingModeTestKt.INSTANCE.m942Int$arg0$callrepeat$fun$anonymous$$arg0$callapply$valbody$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest();
        for (int i = 0; i < iM942Int$arg0$callrepeat$fun$anonymous$$arg0$callapply$valbody$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest; i++) {
            $this$twoThumbsCancelAndVideoSurviveModeChanges_u24lambda_u245.write(part);
        }
        video.enqueue(new MockResponse().setHeader(LiveLiterals$DrivingModeTestKt.INSTANCE.m1049String$arg0$callsetHeader$$this$callsetBody$$this$callthrottleBody$arg0$callenqueue1$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), LiveLiterals$DrivingModeTestKt.INSTANCE.m1053String$arg1$callsetHeader$$this$callsetBody$$this$callthrottleBody$arg0$callenqueue1$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest()).setBody($this$twoThumbsCancelAndVideoSurviveModeChanges_u24lambda_u245).throttleBody(part.length, LiveLiterals$DrivingModeTestKt.INSTANCE.m996Long$arg1$callthrottleBody$arg0$callenqueue1$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), TimeUnit.MILLISECONDS));
        control.start(LiveLiterals$DrivingModeTestKt.INSTANCE.m946Int$arg0$callstart$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest());
        video.start();
        try {
            runOnUiThread(new Function0<Unit>() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.3
                {
                    super(0);
                }

                public /* bridge */ /* synthetic */ Object invoke() {
                    m506invoke();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: collision with other method in class */
                public final void m506invoke() {
                    ControlStatusFixtureKt.showControlFixture(DrivingModeTest.this.getCompose().getActivity());
                }
            });
            TextActionsKt.performTextReplacement(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1036String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, 2, null), LiveLiterals$DrivingModeTestKt.INSTANCE.m1046String$arg0$callperformTextReplacement$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest());
            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1025String$arg0$callonNodeWithTag$$$this$callperformClick$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, 2, null));
            waitUntil(LiveLiterals$DrivingModeTestKt.INSTANCE.m981Long$arg0$callwaitUntil$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), new Function0<Boolean>() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.4
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                public final Boolean m507invoke() {
                    return Boolean.valueOf(drives.get() > LiveLiterals$DrivingModeTestKt.INSTANCE.m965Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest());
                }
            });
            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1027String$arg0$callonNodeWithTag$$$this$callperformClick1$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, 2, null));
            SemanticsNodeInteraction semanticsNodeInteractionOnNodeWithTag$default = FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1037String$arg0$callonNodeWithTag$$$this$callperformTextReplacement1$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, 2, null);
            String string = video.url(LiveLiterals$DrivingModeTestKt.INSTANCE.m1050String$arg0$callurl$$this$calltoString$arg0$callperformTextReplacement1$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest()).toString();
            Intrinsics.checkNotNullExpressionValue(string, "video.url(\"/stream\").toString()");
            TextActionsKt.performTextReplacement(semanticsNodeInteractionOnNodeWithTag$default, string);
            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1029String$arg0$callonNodeWithTag$$$this$callperformClick2$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, 2, null));
            waitUntil(LiveLiterals$DrivingModeTestKt.INSTANCE.m983Long$arg0$callwaitUntil1$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), new Function0<Boolean>() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.5
                {
                    super(0);
                }

                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                public final Boolean m508invoke() {
                    Object obj;
                    DrivingModeTest $this$invoke_u24lambda_u240 = DrivingModeTest.this;
                    try {
                        Result.Companion companion = Result.Companion;
                        obj = Result.constructor-impl(AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default($this$invoke_u24lambda_u240.getCompose(), LiveLiterals$DrivingModeTestKt.INSTANCE.m1018String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil1$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, 2, null), LiveLiterals$DrivingModeTestKt.INSTANCE.m1005String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil1$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), LiveLiterals$DrivingModeTestKt.INSTANCE.m905Boolean$arg1$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil1$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, 4, null));
                    } catch (Throwable th) {
                        Result.Companion companion2 = Result.Companion;
                        obj = Result.constructor-impl(ResultKt.createFailure(th));
                    }
                    return Boolean.valueOf(Result.isSuccess-impl(obj));
                }
            });
            Rect setup = SemanticsNodeInteraction.fetchSemanticsNode$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1043String$arg0$callonNodeWithTag$$this$callfetchSemanticsNode$$this$call$getboundsInRoot$$valsetup$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, 2, null), null, 1, null).getBoundsInRoot();
            screenshot(LiveLiterals$DrivingModeTestKt.INSTANCE.m1047String$arg0$callscreenshot$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest());
            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1030String$arg0$callonNodeWithTag$$$this$callperformClick3$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, 2, null));
            FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1040String$arg0$callonNodeWithTag$$this$callassertDoesNotExist$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, 2, null).assertDoesNotExist();
            Rect race = SemanticsNodeInteraction.fetchSemanticsNode$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1042String$arg0$callonNodeWithTag$$this$callfetchSemanticsNode$$this$call$getboundsInRoot$$valrace$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, 2, null), null, 1, null).getBoundsInRoot();
            Assert.assertTrue(LiveLiterals$DrivingModeTestKt.INSTANCE.m999String$0$str$arg0$callassertTrue$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest() + setup + LiveLiterals$DrivingModeTestKt.INSTANCE.m1001String$2$str$arg0$callassertTrue$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest() + race, race.getWidth() * race.getHeight() > (setup.getWidth() * setup.getHeight()) * LiveLiterals$DrivingModeTestKt.INSTANCE.m917Float$arg0$calltimes$arg1$callgreater$arg1$callassertTrue$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest());
            screenshot(LiveLiterals$DrivingModeTestKt.INSTANCE.m1048String$arg0$callscreenshot1$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest());
            final Rect gas = SemanticsNodeInteraction.fetchSemanticsNode$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1041String$arg0$callonNodeWithTag$$this$callfetchSemanticsNode$$this$call$getboundsInRoot$$valgas$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, 2, null), null, 1, null).getBoundsInRoot();
            final Rect wheel = SemanticsNodeInteraction.fetchSemanticsNode$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1044String$arg0$callonNodeWithTag$$this$callfetchSemanticsNode$$this$call$getboundsInRoot$$valwheel$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, 2, null), null, 1, null).getBoundsInRoot();
            try {
                final long gasForward = Offset.plus-MK-Hz9U(gas.getCenter-F1C5BW0(), OffsetKt.Offset(LiveLiterals$DrivingModeTestKt.INSTANCE.m910Float$arg0$callOffset$arg0$callplus$valgasForward$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), (-gas.getHeight()) * LiveLiterals$DrivingModeTestKt.INSTANCE.m916Float$arg0$calltimes$arg1$callOffset$arg0$callplus$valgasForward$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest()));
                try {
                    try {
                        final long wheelRight = Offset.plus-MK-Hz9U(wheel.getCenter-F1C5BW0(), OffsetKt.Offset(wheel.getWidth() * LiveLiterals$DrivingModeTestKt.INSTANCE.m914Float$arg0$calltimes$arg0$callOffset$arg0$callplus$valwheelRight$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), LiveLiterals$DrivingModeTestKt.INSTANCE.m919Float$arg1$callOffset$arg0$callplus$valwheelRight$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest()));
                        ActionsKt.performTouchInput(FindersKt.onRoot$default(this.compose, false, 1, null), new Function1<TouchInjectionScope, Unit>() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.6
                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            {
                                super(1);
                            }

                            public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                                invoke((TouchInjectionScope) p1);
                                return Unit.INSTANCE;
                            }

                            public final void invoke(TouchInjectionScope $this$performTouchInput) {
                                Intrinsics.checkNotNullParameter($this$performTouchInput, "$this$performTouchInput");
                                $this$performTouchInput.mo352downUv8p0NA(LiveLiterals$DrivingModeTestKt.INSTANCE.m927Int$arg0$calldown$fun$anonymous$$arg0$callperformTouchInput$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), gas.getCenter-F1C5BW0());
                                $this$performTouchInput.mo352downUv8p0NA(LiveLiterals$DrivingModeTestKt.INSTANCE.m931Int$arg0$calldown1$fun$anonymous$$arg0$callperformTouchInput$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), wheel.getCenter-F1C5BW0());
                                TouchInjectionScope.m350moveTod4ec7I$default($this$performTouchInput, LiveLiterals$DrivingModeTestKt.INSTANCE.m933Int$arg0$callmoveTo$fun$anonymous$$arg0$callperformTouchInput$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), gasForward, 0L, 4, null);
                                TouchInjectionScope.m350moveTod4ec7I$default($this$performTouchInput, LiveLiterals$DrivingModeTestKt.INSTANCE.m939Int$arg0$callmoveTo1$fun$anonymous$$arg0$callperformTouchInput$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), wheelRight, 0L, 4, null);
                            }
                        });
                        waitUntil(LiveLiterals$DrivingModeTestKt.INSTANCE.m986Long$arg0$callwaitUntil2$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), new Function0<Boolean>() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.7
                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            {
                                super(0);
                            }

                            /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                            public final Boolean m509invoke() {
                                ControlPacket it2 = latest.get();
                                boolean z = false;
                                if (it2 != null) {
                                    if ((it2.getThrottle() > LiveLiterals$DrivingModeTestKt.INSTANCE.m963Int$arg1$callgreater$cond$fun$anonymous$$arg0$calllet$else$when$arg0$callEQEQ$fun$anonymous$$arg1$callwaitUntil2$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest() && it2.getSteering() > LiveLiterals$DrivingModeTestKt.INSTANCE.m961Int$arg1$callgreater$branch$fun$anonymous$$arg0$calllet$else$when$arg0$callEQEQ$fun$anonymous$$arg1$callwaitUntil2$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest()) == LiveLiterals$DrivingModeTestKt.INSTANCE.m902Boolean$arg1$callEQEQ$fun$anonymous$$arg1$callwaitUntil2$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest()) {
                                        z = true;
                                    }
                                }
                                return Boolean.valueOf(z);
                            }
                        });
                        ActionsKt.performTouchInput(FindersKt.onRoot$default(this.compose, false, 1, null), new Function1<TouchInjectionScope, Unit>() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.8
                            public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                                invoke((TouchInjectionScope) p1);
                                return Unit.INSTANCE;
                            }

                            public final void invoke(TouchInjectionScope $this$performTouchInput) {
                                Intrinsics.checkNotNullParameter($this$performTouchInput, "$this$performTouchInput");
                                $this$performTouchInput.up(LiveLiterals$DrivingModeTestKt.INSTANCE.m947Int$arg0$callup$fun$anonymous$$arg0$callperformTouchInput1$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest());
                            }
                        });
                        waitUntil(LiveLiterals$DrivingModeTestKt.INSTANCE.m987Long$arg0$callwaitUntil3$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), new Function0<Boolean>() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.9
                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            {
                                super(0);
                            }

                            /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                            public final Boolean m510invoke() {
                                ControlPacket it2 = latest.get();
                                boolean z = false;
                                if (it2 != null) {
                                    if ((it2.getThrottle() == LiveLiterals$DrivingModeTestKt.INSTANCE.m952Int$arg1$callEQEQ$cond$fun$anonymous$$arg0$calllet$else$when$arg0$callEQEQ$fun$anonymous$$arg1$callwaitUntil3$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest() && it2.getSteering() > LiveLiterals$DrivingModeTestKt.INSTANCE.m962Int$arg1$callgreater$branch$fun$anonymous$$arg0$calllet$else$when$arg0$callEQEQ$fun$anonymous$$arg1$callwaitUntil3$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest()) == LiveLiterals$DrivingModeTestKt.INSTANCE.m903Boolean$arg1$callEQEQ$fun$anonymous$$arg1$callwaitUntil3$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest()) {
                                        z = true;
                                    }
                                }
                                return Boolean.valueOf(z);
                            }
                        });
                        ActionsKt.performTouchInput(FindersKt.onRoot$default(this.compose, false, 1, null), new Function1<TouchInjectionScope, Unit>() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.10
                            public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                                invoke((TouchInjectionScope) p1);
                                return Unit.INSTANCE;
                            }

                            public final void invoke(TouchInjectionScope $this$performTouchInput) {
                                Intrinsics.checkNotNullParameter($this$performTouchInput, "$this$performTouchInput");
                                TouchInjectionScope.cancel$default($this$performTouchInput, 0L, 1, null);
                            }
                        });
                        waitUntil(LiveLiterals$DrivingModeTestKt.INSTANCE.m988Long$arg0$callwaitUntil4$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), new Function0<Boolean>() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.11
                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            {
                                super(0);
                            }

                            /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                            public final Boolean m498invoke() {
                                ControlPacket it2 = latest.get();
                                boolean z = false;
                                if (it2 != null) {
                                    if ((it2.getThrottle() == LiveLiterals$DrivingModeTestKt.INSTANCE.m953Int$arg1$callEQEQ$cond$fun$anonymous$$arg0$calllet$else$when$arg0$callEQEQ$fun$anonymous$$arg1$callwaitUntil4$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest() && it2.getSteering() == LiveLiterals$DrivingModeTestKt.INSTANCE.m951Int$arg1$callEQEQ$branch$fun$anonymous$$arg0$calllet$else$when$arg0$callEQEQ$fun$anonymous$$arg1$callwaitUntil4$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest()) == LiveLiterals$DrivingModeTestKt.INSTANCE.m904Boolean$arg1$callEQEQ$fun$anonymous$$arg1$callwaitUntil4$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest()) {
                                        z = true;
                                    }
                                }
                                return Boolean.valueOf(z);
                            }
                        });
                        ActionsKt.performTouchInput(FindersKt.onRoot$default(this.compose, false, 1, null), new Function1<TouchInjectionScope, Unit>() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.12
                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            {
                                super(1);
                            }

                            public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                                invoke((TouchInjectionScope) p1);
                                return Unit.INSTANCE;
                            }

                            public final void invoke(TouchInjectionScope $this$performTouchInput) {
                                Intrinsics.checkNotNullParameter($this$performTouchInput, "$this$performTouchInput");
                                $this$performTouchInput.mo352downUv8p0NA(LiveLiterals$DrivingModeTestKt.INSTANCE.m928Int$arg0$calldown$fun$anonymous$$arg0$callperformTouchInput3$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), gas.getCenter-F1C5BW0());
                                TouchInjectionScope.m350moveTod4ec7I$default($this$performTouchInput, LiveLiterals$DrivingModeTestKt.INSTANCE.m934Int$arg0$callmoveTo$fun$anonymous$$arg0$callperformTouchInput3$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), gasForward, 0L, 4, null);
                            }
                        });
                        waitUntil(LiveLiterals$DrivingModeTestKt.INSTANCE.m989Long$arg0$callwaitUntil5$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), new Function0<Boolean>() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.13
                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            {
                                super(0);
                            }

                            /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                            public final Boolean m499invoke() {
                                ControlPacket controlPacket = latest.get();
                                return Boolean.valueOf((controlPacket != null ? controlPacket.getThrottle() : LiveLiterals$DrivingModeTestKt.INSTANCE.m976Int$branch$when$arg0$callgreater$fun$anonymous$$arg1$callwaitUntil5$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest()) > LiveLiterals$DrivingModeTestKt.INSTANCE.m968Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil5$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest());
                            }
                        });
                        ActionsKt.performTouchInput(FindersKt.onRoot$default(this.compose, false, 1, null), new Function1<TouchInjectionScope, Unit>() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.14
                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            {
                                super(1);
                            }

                            public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                                invoke((TouchInjectionScope) p1);
                                return Unit.INSTANCE;
                            }

                            public final void invoke(TouchInjectionScope $this$performTouchInput) {
                                Intrinsics.checkNotNullParameter($this$performTouchInput, "$this$performTouchInput");
                                TouchInjectionScope.m350moveTod4ec7I$default($this$performTouchInput, LiveLiterals$DrivingModeTestKt.INSTANCE.m935Int$arg0$callmoveTo$fun$anonymous$$arg0$callperformTouchInput4$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), OffsetKt.Offset(gas.getRight() + LiveLiterals$DrivingModeTestKt.INSTANCE.m912Float$arg0$callplus$arg0$callOffset$arg1$callmoveTo$fun$anonymous$$arg0$callperformTouchInput4$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), Offset.getY-impl(gas.getCenter-F1C5BW0())), 0L, 4, null);
                            }
                        });
                        waitUntil(LiveLiterals$DrivingModeTestKt.INSTANCE.m990Long$arg0$callwaitUntil6$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), new Function0<Boolean>() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.15
                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            {
                                super(0);
                            }

                            /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                            public final Boolean m500invoke() {
                                ControlPacket controlPacket = latest.get();
                                boolean z = false;
                                if (controlPacket != null && controlPacket.getThrottle() == LiveLiterals$DrivingModeTestKt.INSTANCE.m954Int$arg1$callEQEQ$fun$anonymous$$arg1$callwaitUntil6$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest()) {
                                    z = true;
                                }
                                return Boolean.valueOf(z);
                            }
                        });
                        ActionsKt.performTouchInput(FindersKt.onRoot$default(this.compose, false, 1, null), new Function1<TouchInjectionScope, Unit>() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.16
                            public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                                invoke((TouchInjectionScope) p1);
                                return Unit.INSTANCE;
                            }

                            public final void invoke(TouchInjectionScope $this$performTouchInput) {
                                Intrinsics.checkNotNullParameter($this$performTouchInput, "$this$performTouchInput");
                                $this$performTouchInput.up(LiveLiterals$DrivingModeTestKt.INSTANCE.m948Int$arg0$callup$fun$anonymous$$arg0$callperformTouchInput5$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest());
                            }
                        });
                        ActionsKt.performTouchInput(FindersKt.onRoot$default(this.compose, false, 1, null), new Function1<TouchInjectionScope, Unit>() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.17
                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            {
                                super(1);
                            }

                            public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                                invoke((TouchInjectionScope) p1);
                                return Unit.INSTANCE;
                            }

                            public final void invoke(TouchInjectionScope $this$performTouchInput) {
                                Intrinsics.checkNotNullParameter($this$performTouchInput, "$this$performTouchInput");
                                $this$performTouchInput.mo352downUv8p0NA(LiveLiterals$DrivingModeTestKt.INSTANCE.m929Int$arg0$calldown$fun$anonymous$$arg0$callperformTouchInput6$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), gas.getCenter-F1C5BW0());
                                TouchInjectionScope.m350moveTod4ec7I$default($this$performTouchInput, LiveLiterals$DrivingModeTestKt.INSTANCE.m936Int$arg0$callmoveTo$fun$anonymous$$arg0$callperformTouchInput6$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), gasForward, 0L, 4, null);
                                $this$performTouchInput.mo352downUv8p0NA(LiveLiterals$DrivingModeTestKt.INSTANCE.m932Int$arg0$calldown1$fun$anonymous$$arg0$callperformTouchInput6$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), Offset.plus-MK-Hz9U(gas.getCenter-F1C5BW0(), OffsetKt.Offset(LiveLiterals$DrivingModeTestKt.INSTANCE.m909Float$arg0$callOffset$arg0$callplus$arg1$calldown1$fun$anonymous$$arg0$callperformTouchInput6$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), LiveLiterals$DrivingModeTestKt.INSTANCE.m918Float$arg1$callOffset$arg0$callplus$arg1$calldown1$fun$anonymous$$arg0$callperformTouchInput6$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest())));
                            }
                        });
                        waitUntil(LiveLiterals$DrivingModeTestKt.INSTANCE.m991Long$arg0$callwaitUntil7$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), new Function0<Boolean>() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.18
                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            {
                                super(0);
                            }

                            /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                            public final Boolean m501invoke() {
                                ControlPacket controlPacket = latest.get();
                                return Boolean.valueOf((controlPacket != null ? controlPacket.getThrottle() : LiveLiterals$DrivingModeTestKt.INSTANCE.m977Int$branch$when$arg0$callgreater$fun$anonymous$$arg1$callwaitUntil7$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest()) > LiveLiterals$DrivingModeTestKt.INSTANCE.m969Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil7$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest());
                            }
                        });
                        ActionsKt.performTouchInput(FindersKt.onRoot$default(this.compose, false, 1, null), new Function1<TouchInjectionScope, Unit>() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.19
                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            {
                                super(1);
                            }

                            public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                                invoke((TouchInjectionScope) p1);
                                return Unit.INSTANCE;
                            }

                            public final void invoke(TouchInjectionScope $this$performTouchInput) {
                                Intrinsics.checkNotNullParameter($this$performTouchInput, "$this$performTouchInput");
                                $this$performTouchInput.up(LiveLiterals$DrivingModeTestKt.INSTANCE.m949Int$arg0$callup$fun$anonymous$$arg0$callperformTouchInput7$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest());
                                TouchInjectionScope.m350moveTod4ec7I$default($this$performTouchInput, LiveLiterals$DrivingModeTestKt.INSTANCE.m937Int$arg0$callmoveTo$fun$anonymous$$arg0$callperformTouchInput7$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), gasForward, 0L, 4, null);
                            }
                        });
                        waitUntil(LiveLiterals$DrivingModeTestKt.INSTANCE.m992Long$arg0$callwaitUntil8$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), new Function0<Boolean>() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.20
                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            {
                                super(0);
                            }

                            /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                            public final Boolean m502invoke() {
                                ControlPacket controlPacket = latest.get();
                                boolean z = false;
                                if (controlPacket != null && controlPacket.getThrottle() == LiveLiterals$DrivingModeTestKt.INSTANCE.m955Int$arg1$callEQEQ$fun$anonymous$$arg1$callwaitUntil8$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest()) {
                                    z = true;
                                }
                                return Boolean.valueOf(z);
                            }
                        });
                        final int neutralAt = drives.get();
                        waitUntil(LiveLiterals$DrivingModeTestKt.INSTANCE.m993Long$arg0$callwaitUntil9$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), new Function0<Boolean>() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.21
                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            {
                                super(0);
                            }

                            /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                            public final Boolean m503invoke() {
                                return Boolean.valueOf(drives.get() > neutralAt + LiveLiterals$DrivingModeTestKt.INSTANCE.m941Int$arg0$callplus$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil9$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest());
                            }
                        });
                        Assert.assertEquals(Integer.valueOf(LiveLiterals$DrivingModeTestKt.INSTANCE.m925Int$arg0$callassertEquals$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest()), Integer.valueOf(((ControlPacket) latest.get()).getThrottle()));
                        ActionsKt.performTouchInput(FindersKt.onRoot$default(this.compose, false, 1, null), new Function1<TouchInjectionScope, Unit>() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.22
                            public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                                invoke((TouchInjectionScope) p1);
                                return Unit.INSTANCE;
                            }

                            public final void invoke(TouchInjectionScope $this$performTouchInput) {
                                Intrinsics.checkNotNullParameter($this$performTouchInput, "$this$performTouchInput");
                                $this$performTouchInput.up(LiveLiterals$DrivingModeTestKt.INSTANCE.m950Int$arg0$callup$fun$anonymous$$arg0$callperformTouchInput8$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest());
                            }
                        });
                        ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1031String$arg0$callonNodeWithTag$$$this$callperformClick4$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, 2, null));
                        AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1020String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, 2, null), LiveLiterals$DrivingModeTestKt.INSTANCE.m1007String$arg0$callassertTextContains$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, false, 6, null);
                        AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1021String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, 2, null), LiveLiterals$DrivingModeTestKt.INSTANCE.m1008String$arg0$callassertTextContains1$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), LiveLiterals$DrivingModeTestKt.INSTANCE.m907Boolean$arg1$callassertTextContains1$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, 4, null);
                        AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1022String$arg0$callonNodeWithTag$$$this$callassertTextContains2$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, 2, null), LiveLiterals$DrivingModeTestKt.INSTANCE.m1009String$arg0$callassertTextContains2$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, false, 6, null);
                        Assert.assertEquals(LiveLiterals$DrivingModeTestKt.INSTANCE.m1004String$arg0$callassertEquals1$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), Integer.valueOf(LiveLiterals$DrivingModeTestKt.INSTANCE.m957Int$arg1$callassertEquals1$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest()), Integer.valueOf(video.getRequestCount()));
                        final int beforeVideoStop = drives.get();
                        try {
                            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1032String$arg0$callonNodeWithTag$$$this$callperformClick5$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, 2, null));
                            waitUntil(LiveLiterals$DrivingModeTestKt.INSTANCE.m984Long$arg0$callwaitUntil10$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), new Function0<Boolean>() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.23
                                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                {
                                    super(0);
                                }

                                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                                public final Boolean m504invoke() {
                                    return Boolean.valueOf(drives.get() > beforeVideoStop + LiveLiterals$DrivingModeTestKt.INSTANCE.m940Int$arg0$callplus$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil10$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest());
                                }
                            });
                            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1033String$arg0$callonNodeWithTag$$$this$callperformClick6$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, 2, null));
                            AssertionsKt.assertIsEnabled(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1014String$arg0$callonNodeWithTag$$$this$callassertIsEnabled$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, 2, null));
                            ActionsKt.performTouchInput(FindersKt.onRoot$default(this.compose, false, 1, null), new Function1<TouchInjectionScope, Unit>() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.24
                                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                {
                                    super(1);
                                }

                                public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                                    invoke((TouchInjectionScope) p1);
                                    return Unit.INSTANCE;
                                }

                                public final void invoke(TouchInjectionScope $this$performTouchInput) {
                                    Intrinsics.checkNotNullParameter($this$performTouchInput, "$this$performTouchInput");
                                    $this$performTouchInput.mo352downUv8p0NA(LiveLiterals$DrivingModeTestKt.INSTANCE.m930Int$arg0$calldown$fun$anonymous$$arg0$callperformTouchInput9$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), gas.getCenter-F1C5BW0());
                                    TouchInjectionScope.m350moveTod4ec7I$default($this$performTouchInput, LiveLiterals$DrivingModeTestKt.INSTANCE.m938Int$arg0$callmoveTo$fun$anonymous$$arg0$callperformTouchInput9$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), gasForward, 0L, 4, null);
                                }
                            });
                            waitUntil(LiveLiterals$DrivingModeTestKt.INSTANCE.m985Long$arg0$callwaitUntil11$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), new Function0<Boolean>() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.25
                                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                {
                                    super(0);
                                }

                                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                                public final Boolean m505invoke() {
                                    ControlPacket controlPacket = latest.get();
                                    return Boolean.valueOf((controlPacket != null ? controlPacket.getThrottle() : LiveLiterals$DrivingModeTestKt.INSTANCE.m975Int$branch$when$arg0$callgreater$fun$anonymous$$arg1$callwaitUntil11$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest()) > LiveLiterals$DrivingModeTestKt.INSTANCE.m967Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil11$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest());
                                }
                            });
                            ActionsKt.performSemanticsAction(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1034String$arg0$callonNodeWithTag$$$this$callperformSemanticsAction$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, 2, null), SemanticsActions.INSTANCE.getOnClick(), (Function1) new Function1<Function0<? extends Boolean>, Unit>() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.26
                                public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                                    invoke((Function0<Boolean>) p1);
                                    return Unit.INSTANCE;
                                }

                                public final void invoke(Function0<Boolean> function0) {
                                    Intrinsics.checkNotNullParameter(function0, "it");
                                    function0.invoke();
                                }
                            });
                            AssertionsKt.assertIsNotEnabled(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1016String$arg0$callonNodeWithTag$$$this$callassertIsNotEnabled$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, 2, null));
                            AssertionsKt.assertIsNotEnabled(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1017String$arg0$callonNodeWithTag$$$this$callassertIsNotEnabled1$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, 2, null));
                            AssertionsKt.assert$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1012String$arg0$callonNodeWithTag$$$this$callassert$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest(), false, 2, null), SemanticsMatcher.INSTANCE.expectValue(SemanticsProperties.INSTANCE.getStateDescription(), LiveLiterals$DrivingModeTestKt.INSTANCE.m1052String$arg1$callexpectValue$arg0$callassert$try$funtwoThumbsCancelAndVideoSurviveModeChanges$classDrivingModeTest()), null, 2, null);
                            ActionsKt.performTouchInput(FindersKt.onRoot$default(this.compose, false, 1, null), new Function1<TouchInjectionScope, Unit>() { // from class: vea.raceremote.DrivingModeTest.twoThumbsCancelAndVideoSurviveModeChanges.27
                                public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                                    invoke((TouchInjectionScope) p1);
                                    return Unit.INSTANCE;
                                }

                                public final void invoke(TouchInjectionScope $this$performTouchInput) {
                                    Intrinsics.checkNotNullParameter($this$performTouchInput, "$this$performTouchInput");
                                    TouchInjectionScope.cancel$default($this$performTouchInput, 0L, 1, null);
                                }
                            });
                            try {
                                ((ActivityScenarioRule) getActivityRule()).getScenario().moveToState(Lifecycle.State.STARTED);
                                try {
                                    control.shutdown();
                                } finally {
                                    video.shutdown();
                                }
                            } catch (Throwable th) {
                                try {
                                    control.shutdown();
                                    throw th;
                                } finally {
                                    video.shutdown();
                                }
                            }
                        } catch (Throwable th2) {
                            th = th2;
                            try {
                                ((ActivityScenarioRule) getActivityRule()).getScenario().moveToState(Lifecycle.State.STARTED);
                                try {
                                    control.shutdown();
                                    throw th;
                                } finally {
                                    video.shutdown();
                                }
                            } catch (Throwable th3) {
                                try {
                                    control.shutdown();
                                    throw th3;
                                } finally {
                                    video.shutdown();
                                }
                            }
                        }
                    } catch (Throwable th4) {
                        th = th4;
                    }
                } catch (Throwable th5) {
                    th = th5;
                }
            } catch (Throwable th6) {
                th = th6;
            }
        } catch (Throwable th7) {
            th = th7;
        }
    }

    @Test
    public final void backgroundDuringDragDoesNotResumeControl() throws IOException {
        MockWebServer control = new MockWebServer();
        final AtomicReference latest = new AtomicReference();
        final AtomicInteger drives = new AtomicInteger();
        ControlStatusFixtureKt.enqueueControlStatus(control);
        control.enqueue(new MockResponse().withWebSocketUpgrade(new WebSocketListener() { // from class: vea.raceremote.DrivingModeTest.backgroundDuringDragDoesNotResumeControl.1
            public void onOpen(WebSocket webSocket, Response response) {
                Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                Intrinsics.checkNotNullParameter(response, "response");
                ControlStatusFixtureKt.sendFixtureIdentity(webSocket, LiveLiterals$DrivingModeTestKt.INSTANCE.m978Long$arg0$callsendFixtureIdentity$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest());
                byte[] bArrEncode = new ControlPacket(128, LiveLiterals$DrivingModeTestKt.INSTANCE.m994Long$arg1$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest(), LiveLiterals$DrivingModeTestKt.INSTANCE.m997Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest(), 0, 0, 24, (DefaultConstructorMarker) null).encode();
                webSocket.send(ByteString.of(Arrays.copyOf(bArrEncode, bArrEncode.length)));
            }

            public void onMessage(WebSocket webSocket, ByteString bytes) {
                Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                Intrinsics.checkNotNullParameter(bytes, "bytes");
                ControlPacket.Companion companion = ControlPacket.Companion;
                byte[] byteArray = bytes.toByteArray();
                Intrinsics.checkNotNullExpressionValue(byteArray, "bytes.toByteArray()");
                ControlPacket p = companion.decode(byteArray);
                Intrinsics.checkNotNull(p);
                if (p.getKind() == 2) {
                    latest.set(p);
                    drives.incrementAndGet();
                }
                if (p.getKind() != 3) {
                    byte[] bArrEncode = ControlPacket.copy$default(p, 129, 0L, 0L, 0, 0, 30, (Object) null).encode();
                    webSocket.send(ByteString.of(Arrays.copyOf(bArrEncode, bArrEncode.length)));
                }
            }
        }));
        control.start(LiveLiterals$DrivingModeTestKt.INSTANCE.m945Int$arg0$callstart$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest());
        try {
            runOnUiThread(new Function0<Unit>() { // from class: vea.raceremote.DrivingModeTest.backgroundDuringDragDoesNotResumeControl.2
                {
                    super(0);
                }

                public /* bridge */ /* synthetic */ Object invoke() {
                    m495invoke();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: collision with other method in class */
                public final void m495invoke() {
                    ControlStatusFixtureKt.showControlFixture(DrivingModeTest.this.getCompose().getActivity());
                }
            });
            TextActionsKt.performTextReplacement(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1035String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$try$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest(), false, 2, null), LiveLiterals$DrivingModeTestKt.INSTANCE.m1045String$arg0$callperformTextReplacement$try$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest());
            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1024String$arg0$callonNodeWithTag$$$this$callperformClick$try$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest(), false, 2, null));
            waitUntil(LiveLiterals$DrivingModeTestKt.INSTANCE.m980Long$arg0$callwaitUntil$try$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest(), new Function0<Boolean>() { // from class: vea.raceremote.DrivingModeTest.backgroundDuringDragDoesNotResumeControl.3
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                public final Boolean m496invoke() {
                    return Boolean.valueOf(drives.get() > LiveLiterals$DrivingModeTestKt.INSTANCE.m964Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest());
                }
            });
            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1026String$arg0$callonNodeWithTag$$$this$callperformClick1$try$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest(), false, 2, null));
            ActionsKt.performTouchInput(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1038String$arg0$callonNodeWithTag$$$this$callperformTouchInput$try$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest(), false, 2, null), new Function1<TouchInjectionScope, Unit>() { // from class: vea.raceremote.DrivingModeTest.backgroundDuringDragDoesNotResumeControl.4
                public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                    invoke((TouchInjectionScope) p1);
                    return Unit.INSTANCE;
                }

                public final void invoke(TouchInjectionScope $this$performTouchInput) {
                    Intrinsics.checkNotNullParameter($this$performTouchInput, "$this$performTouchInput");
                    $this$performTouchInput.m353downk4lQ0M($this$performTouchInput.mo96getCenterF1C5BW0());
                    TouchInjectionScope.m349moveTo3MmeM6k$default($this$performTouchInput, Offset.plus-MK-Hz9U($this$performTouchInput.mo96getCenterF1C5BW0(), OffsetKt.Offset(LiveLiterals$DrivingModeTestKt.INSTANCE.m908Float$arg0$callOffset$arg0$callplus$arg0$callmoveTo$fun$anonymous$$arg0$callperformTouchInput$try$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest(), (-$this$performTouchInput.getHeight()) * LiveLiterals$DrivingModeTestKt.INSTANCE.m915Float$arg0$calltimes$arg1$callOffset$arg0$callplus$arg0$callmoveTo$fun$anonymous$$arg0$callperformTouchInput$try$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest())), 0L, 2, null);
                }
            });
            waitUntil(LiveLiterals$DrivingModeTestKt.INSTANCE.m982Long$arg0$callwaitUntil1$try$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest(), new Function0<Boolean>() { // from class: vea.raceremote.DrivingModeTest.backgroundDuringDragDoesNotResumeControl.5
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                public final Boolean m497invoke() {
                    ControlPacket controlPacket = latest.get();
                    return Boolean.valueOf((controlPacket != null ? controlPacket.getThrottle() : LiveLiterals$DrivingModeTestKt.INSTANCE.m974Int$branch$when$arg0$callgreater$fun$anonymous$$arg1$callwaitUntil1$try$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest()) > LiveLiterals$DrivingModeTestKt.INSTANCE.m966Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil1$try$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest());
                }
            });
            ((ActivityScenarioRule) getActivityRule()).getScenario().moveToState(Lifecycle.State.STARTED);
            ((ActivityScenarioRule) getActivityRule()).getScenario().moveToState(Lifecycle.State.RESUMED);
            AssertionsKt.assert$default(AssertionsKt.assertIsNotEnabled(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1015String$arg0$callonNodeWithTag$$$this$callassertIsNotEnabled$$$this$callassert$try$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest(), false, 2, null)), SemanticsMatcher.INSTANCE.expectValue(SemanticsProperties.INSTANCE.getStateDescription(), LiveLiterals$DrivingModeTestKt.INSTANCE.m1051String$arg1$callexpectValue$arg0$callassert$try$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest()), null, 2, null);
            AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1019String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest(), false, 2, null), LiveLiterals$DrivingModeTestKt.INSTANCE.m1006String$arg0$callassertTextContains$try$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest(), LiveLiterals$DrivingModeTestKt.INSTANCE.m906Boolean$arg1$callassertTextContains$try$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest(), false, 4, null);
            ActionsKt.performTouchInput(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1039String$arg0$callonNodeWithTag$$$this$callperformTouchInput1$try$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest(), false, 2, null), new Function1<TouchInjectionScope, Unit>() { // from class: vea.raceremote.DrivingModeTest.backgroundDuringDragDoesNotResumeControl.6
                public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                    invoke((TouchInjectionScope) p1);
                    return Unit.INSTANCE;
                }

                public final void invoke(TouchInjectionScope $this$performTouchInput) {
                    Intrinsics.checkNotNullParameter($this$performTouchInput, "$this$performTouchInput");
                    TouchInjectionScope.cancel$default($this$performTouchInput, 0L, 1, null);
                }
            });
            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1028String$arg0$callonNodeWithTag$$$this$callperformClick2$try$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest(), false, 2, null));
            AssertionsKt.assertIsEnabled(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1013String$arg0$callonNodeWithTag$$$this$callassertIsEnabled$try$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest(), false, 2, null));
            Assert.assertEquals(LiveLiterals$DrivingModeTestKt.INSTANCE.m1003String$arg0$callassertEquals$try$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest(), Integer.valueOf(LiveLiterals$DrivingModeTestKt.INSTANCE.m956Int$arg1$callassertEquals$try$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest()), Integer.valueOf(control.getRequestCount()));
        } finally {
            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$DrivingModeTestKt.INSTANCE.m1023String$arg0$callonNodeWithTag$$$this$callperformClick$finally$funbackgroundDuringDragDoesNotResumeControl$classDrivingModeTest(), false, 2, null));
            control.shutdown();
        }
    }

    private final void screenshot(String name) {
        File target = InstrumentationRegistry.getInstrumentation().getTargetContext().getExternalFilesDir(LiveLiterals$DrivingModeTestKt.INSTANCE.m1011String$arg0$callgetExternalFilesDir$arg0$callCHECK_NOT_NULL$valtarget$funscreenshot$classDrivingModeTest());
        Intrinsics.checkNotNull(target);
        FileOutputStream fileOutputStream = new FileOutputStream(new File(target, name));
        try {
            FileOutputStream it = fileOutputStream;
            AndroidImageBitmap_androidKt.asAndroidBitmap(AndroidImageHelpers_androidKt.captureToImage(FindersKt.onRoot$default(this.compose, false, 1, null))).compress(Bitmap.CompressFormat.PNG, LiveLiterals$DrivingModeTestKt.INSTANCE.m959Int$arg1$callcompress$fun$anonymous$$arg0$calluse$funscreenshot$classDrivingModeTest(), it);
            CloseableKt.closeFinally(fileOutputStream, (Throwable) null);
        } catch (Throwable th) {
            try {
                throw th;
            } catch (Throwable th2) {
                CloseableKt.closeFinally(fileOutputStream, th);
                throw th2;
            }
        }
    }
}
