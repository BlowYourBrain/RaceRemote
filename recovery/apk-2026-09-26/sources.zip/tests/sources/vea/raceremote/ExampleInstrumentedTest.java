package vea.raceremote;

import android.content.Context;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import junit.framework.Assert;
import kotlin.Metadata;
import org.junit.Test;
import org.junit.runner.RunWith;

/* JADX INFO: compiled from: ExampleInstrumentedTest.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0007¨\u0006\u0005"}, d2 = {"Lvea/raceremote/ExampleInstrumentedTest;", "", "()V", "useAppContext", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
@RunWith(AndroidJUnit4.class)
public final class ExampleInstrumentedTest {
    public static final int $stable = LiveLiterals$ExampleInstrumentedTestKt.INSTANCE.m1054Int$classExampleInstrumentedTest();

    @Test
    public final void useAppContext() {
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();
        Assert.assertEquals(LiveLiterals$ExampleInstrumentedTestKt.INSTANCE.m1055String$arg0$callassertEquals$funuseAppContext$classExampleInstrumentedTest(), appContext.getPackageName());
    }
}
