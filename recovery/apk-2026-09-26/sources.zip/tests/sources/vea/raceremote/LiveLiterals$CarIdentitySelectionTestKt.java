package vea.raceremote;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: CarIdentitySelectionTest.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/androidTest/java/vea/raceremote/CarIdentitySelectionTest.kt")
public final class LiveLiterals$CarIdentitySelectionTestKt {

    /* JADX INFO: renamed from: Boolean$arg-0$call-selection$fun-wrongIdentityRequiresExplicitManualSelectionOfActualBoard$class-CarIdentitySelectionTest, reason: not valid java name */
    private static boolean f4Boolean$arg0$callselection$funwrongIdentityRequiresExplicitManualSelectionOfActualBoard$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: Boolean$arg-3$call-$init$$arg-0$call-invoke$fun-$anonymous$$arg-0$call-Button$fun-$anonymous$$arg-0$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static boolean f6Boolean$arg3$call$init$$arg0$callinvoke$fun$anonymous$$arg0$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: Int$arg-0$call-assertEquals$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static int f7Int$arg0$callassertEquals$branch$if$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: Long$arg-2$call-$init$$$this$call-encode$0$vararg$arg-0$call-of$arg-0$call-send$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static long f26Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-selection$fun-selectedCarMustConfirmItsIdentity$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Boolean> f29State$Boolean$arg0$callselection$funselectedCarMustConfirmItsIdentity$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-selection$fun-wrongIdentityRequiresExplicitManualSelectionOfActualBoard$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Boolean> f30State$Boolean$arg0$callselection$funwrongIdentityRequiresExplicitManualSelectionOfActualBoard$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-assertTextContains$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Boolean> f31State$Boolean$arg1$callassertTextContains$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Boolean$arg-3$call-$init$$arg-0$call-invoke$fun-$anonymous$$arg-0$call-Button$fun-$anonymous$$arg-0$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Boolean> f32State$Boolean$arg3$call$init$$arg0$callinvoke$fun$anonymous$$arg0$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Int$arg-0$call-assertEquals$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Integer> f33State$Int$arg0$callassertEquals$branch$if$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Int$arg-0$call-assertEquals-1$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Integer> f34State$Int$arg0$callassertEquals1$branch$if$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Int$arg-0$call-assertEquals-2$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Integer> f35State$Int$arg0$callassertEquals2$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Int$arg-0$call-chunked$$$this$call-map$$$this$call-toByteArray$val-bytes$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Integer> f36State$Int$arg0$callchunked$$$this$callmap$$$this$calltoByteArray$valbytes$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Int$arg-0$call-get$$this$call-toInt$$this$call-xor$$this$call-toByte$arg-1$call-set$branch$if$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Integer> f37State$Int$arg0$callget$$this$calltoInt$$this$callxor$$this$calltoByte$arg1$callset$branch$if$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Int$arg-0$call-set$branch$if$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Integer> f38State$Int$arg0$callset$branch$if$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Int$arg-0$call-start$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Integer> f39State$Int$arg0$callstart$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Int$arg-0$call-toInt$$this$call-toByte$fun-$anonymous$$arg-0$call-map$$$this$call-toByteArray$val-bytes$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Integer> f40State$Int$arg0$calltoInt$$this$calltoByte$fun$anonymous$$arg0$callmap$$$this$calltoByteArray$valbytes$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Int$arg-0$call-toString$1$str$arg-0$call-setBody$branch$if$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Integer> f41State$Int$arg0$calltoString$1$str$arg0$callsetBody$branch$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Int$arg-0$call-xor$$this$call-toByte$arg-1$call-set$branch$if$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Integer> f42State$Int$arg0$callxor$$this$calltoByte$arg1$callset$branch$if$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Int$arg-1$call-$init$$arg-0$call-invoke$fun-$anonymous$$arg-0$call-Button$fun-$anonymous$$arg-0$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Integer> f43State$Int$arg1$call$init$$arg0$callinvoke$fun$anonymous$$arg0$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Int$arg-1$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Integer> f44State$Int$arg1$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Int$arg-1$call-greater$fun-$anonymous$$arg-1$call-waitUntil$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Integer> f45State$Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Long$arg-0$call-takeRequest$arg-0$call-CHECK_NOT_NULL$$this$call-getPath$arg-1$call-assertEquals$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Long> f46State$Long$arg0$calltakeRequest$arg0$callCHECK_NOT_NULL$$this$callgetPath$arg1$callassertEquals$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Long$arg-0$call-takeRequest$arg-0$call-CHECK_NOT_NULL$$this$call-getPath$arg-1$call-assertEquals-1$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Long> f47State$Long$arg0$calltakeRequest$arg0$callCHECK_NOT_NULL$$this$callgetPath$arg1$callassertEquals1$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Long$arg-0$call-takeRequest$arg-0$call-CHECK_NOT_NULL$$this$call-getPath$arg-1$call-assertEquals-2$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Long> f48State$Long$arg0$calltakeRequest$arg0$callCHECK_NOT_NULL$$this$callgetPath$arg1$callassertEquals2$branch$if$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Long$arg-0$call-waitUntil$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Long> f49State$Long$arg0$callwaitUntil$branch$if$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Long$arg-0$call-waitUntil$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Long> f50State$Long$arg0$callwaitUntil$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Long$arg-0$call-xor$else$if$val-actualChip$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Long> f51State$Long$arg0$callxor$else$if$valactualChip$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Long$arg-2$call-$init$$$this$call-encode$0$vararg$arg-0$call-of$arg-0$call-send$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Long> f52State$Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Long$val-chip$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Long> f53State$Long$valchip$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$Long$val-token$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<Long> f54State$Long$valtoken$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$String$$$this$call-chunked$$$this$call-map$$$this$call-toByteArray$val-bytes$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<String> f55State$String$$$this$callchunked$$$this$callmap$$$this$calltoByteArray$valbytes$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-setBody$branch$if$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<String> f56State$String$0$str$arg0$callsetBody$branch$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$String$2$str$arg-0$call-setBody$branch$if$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<String> f57State$String$2$str$arg0$callsetBody$branch$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$arg-0$call-invoke$fun-$anonymous$$arg-0$call-Button$fun-$anonymous$$arg-0$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<String> f58State$String$arg0$call$init$$arg0$callinvoke$fun$anonymous$$arg0$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-Text$fun-$anonymous$$arg-9$call-Button$fun-$anonymous$$arg-0$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<String> f59State$String$arg0$callText$fun$anonymous$$arg9$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-assertEquals$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<String> f60State$String$arg0$callassertEquals$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-assertEquals-2$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<String> f61State$String$arg0$callassertEquals2$branch$if$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-assertTextContains$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<String> f62State$String$arg0$callassertTextContains$branch$if$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<String> f63State$String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil$branch$if$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-assertTextContains$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<String> f64State$String$arg0$callassertTextContains$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-assertTextContains-1$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<String> f65State$String$arg0$callassertTextContains1$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<String> f66State$String$arg0$callonNodeWithTag$$$this$callassertTextContains$branch$if$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<String> f67State$String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil$branch$if$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<String> f68State$String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-1$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<String> f69State$String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-performClick$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<String> f70State$String$arg0$callonNodeWithTag$$$this$callperformClick$branch$if$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-performClick$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<String> f71State$String$arg0$callonNodeWithTag$$$this$callperformClick$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-performClick-1$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<String> f72State$String$arg0$callonNodeWithTag$$$this$callperformClick1$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-performTextClearance$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<String> f73State$String$arg0$callonNodeWithTag$$$this$callperformTextClearance$branch$if$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-performTextReplacement$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<String> f74State$String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$branch$if$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-performTextReplacement$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<String> f75State$String$arg0$callperformTextReplacement$branch$if$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-testTag$val-tmp0_modifier$fun-$anonymous$$arg-0$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<String> f76State$String$arg0$calltestTag$valtmp0_modifier$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest;

    /* JADX INFO: renamed from: State$String$arg-1$call-EQEQ$cond$if$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static State<String> f77State$String$arg1$callEQEQ$cond$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;
    public static final LiveLiterals$CarIdentitySelectionTestKt INSTANCE = new LiveLiterals$CarIdentitySelectionTestKt();

    /* JADX INFO: renamed from: Boolean$arg-0$call-selection$fun-selectedCarMustConfirmItsIdentity$class-CarIdentitySelectionTest, reason: not valid java name */
    private static boolean f3Boolean$arg0$callselection$funselectedCarMustConfirmItsIdentity$classCarIdentitySelectionTest = true;

    /* JADX INFO: renamed from: Long$val-chip$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static long f27Long$valchip$funselection$classCarIdentitySelectionTest = 176392807313608L;

    /* JADX INFO: renamed from: Long$val-token$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static long f28Long$valtoken$funselection$classCarIdentitySelectionTest = 305419896;

    /* JADX INFO: renamed from: Long$arg-0$call-xor$else$if$val-actualChip$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static long f25Long$arg0$callxor$else$if$valactualChip$funselection$classCarIdentitySelectionTest = 1;

    /* JADX INFO: renamed from: String$arg-1$call-EQEQ$cond$if$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static String f100String$arg1$callEQEQ$cond$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest = "/status";

    /* JADX INFO: renamed from: String$0$str$arg-0$call-setBody$branch$if$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static String f79String$0$str$arg0$callsetBody$branch$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest = "{\"protocol\":1,\"acceptingControl\":true,\"controlTransport\":\"websocket-v1\",\"controlPort\":1337,\"chipId\":\"";

    /* JADX INFO: renamed from: Int$arg-0$call-toString$1$str$arg-0$call-setBody$branch$if$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static int f15Int$arg0$calltoString$1$str$arg0$callsetBody$branch$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest = 16;

    /* JADX INFO: renamed from: String$2$str$arg-0$call-setBody$branch$if$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static String f80String$2$str$arg0$callsetBody$branch$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest = "\"}";

    /* JADX INFO: renamed from: String$$$this$call-chunked$$$this$call-map$$$this$call-toByteArray$val-bytes$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static String f78String$$$this$callchunked$$$this$callmap$$$this$calltoByteArray$valbytes$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest = "5243018278563412c8f09ea66da00000";

    /* JADX INFO: renamed from: Int$arg-0$call-chunked$$$this$call-map$$$this$call-toByteArray$val-bytes$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static int f10Int$arg0$callchunked$$$this$callmap$$$this$calltoByteArray$valbytes$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest = 2;

    /* JADX INFO: renamed from: Int$arg-0$call-toInt$$this$call-toByte$fun-$anonymous$$arg-0$call-map$$$this$call-toByteArray$val-bytes$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static int f14Int$arg0$calltoInt$$this$calltoByte$fun$anonymous$$arg0$callmap$$$this$calltoByteArray$valbytes$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest = 16;

    /* JADX INFO: renamed from: Int$arg-0$call-set$branch$if$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static int f12Int$arg0$callset$branch$if$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest = 8;

    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toInt$$this$call-xor$$this$call-toByte$arg-1$call-set$branch$if$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static int f11Int$arg0$callget$$this$calltoInt$$this$callxor$$this$calltoByte$arg1$callset$branch$if$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest = 8;

    /* JADX INFO: renamed from: Int$arg-0$call-xor$$this$call-toByte$arg-1$call-set$branch$if$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static int f16Int$arg0$callxor$$this$calltoByte$arg1$callset$branch$if$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest = 1;

    /* JADX INFO: renamed from: Int$arg-0$call-start$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static int f13Int$arg0$callstart$funselection$classCarIdentitySelectionTest = 1337;

    /* JADX INFO: renamed from: String$arg-0$call-testTag$val-tmp0_modifier$fun-$anonymous$$arg-0$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static String f99String$arg0$calltestTag$valtmp0_modifier$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest = "pick_fixture_car";

    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-0$call-invoke$fun-$anonymous$$arg-0$call-Button$fun-$anonymous$$arg-0$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static String f81String$arg0$call$init$$arg0$callinvoke$fun$anonymous$$arg0$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest = "127.0.0.1";

    /* JADX INFO: renamed from: Int$arg-1$call-$init$$arg-0$call-invoke$fun-$anonymous$$arg-0$call-Button$fun-$anonymous$$arg-0$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static int f17Int$arg1$call$init$$arg0$callinvoke$fun$anonymous$$arg0$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest = 1337;

    /* JADX INFO: renamed from: String$arg-0$call-Text$fun-$anonymous$$arg-9$call-Button$fun-$anonymous$$arg-0$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static String f82String$arg0$callText$fun$anonymous$$arg9$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest = "Выбрать";

    /* JADX INFO: renamed from: Int$arg-1$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static int f18Int$arg1$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest = 1337;

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performClick$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static String f94String$arg0$callonNodeWithTag$$$this$callperformClick$try$funselection$classCarIdentitySelectionTest = "pick_fixture_car";

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static String f91String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$funselection$classCarIdentitySelectionTest = "selected_car_identity";

    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static String f87String$arg0$callassertTextContains$try$funselection$classCarIdentitySelectionTest = "a06da69ef0c8";

    /* JADX INFO: renamed from: Boolean$arg-1$call-assertTextContains$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static boolean f5Boolean$arg1$callassertTextContains$try$funselection$classCarIdentitySelectionTest = true;

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performClick-1$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static String f95String$arg0$callonNodeWithTag$$$this$callperformClick1$try$funselection$classCarIdentitySelectionTest = "connect_car";

    /* JADX INFO: renamed from: String$arg-0$call-assertEquals$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static String f83String$arg0$callassertEquals$try$funselection$classCarIdentitySelectionTest = "/status";

    /* JADX INFO: renamed from: Long$arg-0$call-takeRequest$arg-0$call-CHECK_NOT_NULL$$this$call-getPath$arg-1$call-assertEquals$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static long f20Long$arg0$calltakeRequest$arg0$callCHECK_NOT_NULL$$this$callgetPath$arg1$callassertEquals$try$funselection$classCarIdentitySelectionTest = 3;

    /* JADX INFO: renamed from: Long$arg-0$call-waitUntil$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static long f23Long$arg0$callwaitUntil$branch$if$try$funselection$classCarIdentitySelectionTest = 5000;

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static String f90String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil$branch$if$try$funselection$classCarIdentitySelectionTest = "connection_status";

    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static String f86String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil$branch$if$try$funselection$classCarIdentitySelectionTest = "По этому адресу другая машинка";

    /* JADX INFO: renamed from: Int$arg-0$call-assertEquals-1$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static int f8Int$arg0$callassertEquals1$branch$if$try$funselection$classCarIdentitySelectionTest = 1;

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performTextClearance$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static String f96String$arg0$callonNodeWithTag$$$this$callperformTextClearance$branch$if$try$funselection$classCarIdentitySelectionTest = "car_address";

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performTextReplacement$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static String f97String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$branch$if$try$funselection$classCarIdentitySelectionTest = "car_address";

    /* JADX INFO: renamed from: String$arg-0$call-performTextReplacement$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static String f98String$arg0$callperformTextReplacement$branch$if$try$funselection$classCarIdentitySelectionTest = "127.0.0.1";

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static String f89String$arg0$callonNodeWithTag$$$this$callassertTextContains$branch$if$try$funselection$classCarIdentitySelectionTest = "selected_car_identity";

    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static String f85String$arg0$callassertTextContains$branch$if$try$funselection$classCarIdentitySelectionTest = "Ручной адрес · проверка машинки при подключении";

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performClick$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static String f93String$arg0$callonNodeWithTag$$$this$callperformClick$branch$if$try$funselection$classCarIdentitySelectionTest = "connect_car";

    /* JADX INFO: renamed from: String$arg-0$call-assertEquals-2$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static String f84String$arg0$callassertEquals2$branch$if$try$funselection$classCarIdentitySelectionTest = "/status";

    /* JADX INFO: renamed from: Long$arg-0$call-takeRequest$arg-0$call-CHECK_NOT_NULL$$this$call-getPath$arg-1$call-assertEquals-2$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static long f22Long$arg0$calltakeRequest$arg0$callCHECK_NOT_NULL$$this$callgetPath$arg1$callassertEquals2$branch$if$try$funselection$classCarIdentitySelectionTest = 3;

    /* JADX INFO: renamed from: Long$arg-0$call-takeRequest$arg-0$call-CHECK_NOT_NULL$$this$call-getPath$arg-1$call-assertEquals-1$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static long f21Long$arg0$calltakeRequest$arg0$callCHECK_NOT_NULL$$this$callgetPath$arg1$callassertEquals1$try$funselection$classCarIdentitySelectionTest = 3;

    /* JADX INFO: renamed from: Long$arg-0$call-waitUntil$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static long f24Long$arg0$callwaitUntil$try$funselection$classCarIdentitySelectionTest = 5000;

    /* JADX INFO: renamed from: Int$arg-1$call-greater$fun-$anonymous$$arg-1$call-waitUntil$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static int f19Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$funselection$classCarIdentitySelectionTest = 3;

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-1$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static String f92String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$funselection$classCarIdentitySelectionTest = "connection_status";

    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains-1$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static String f88String$arg0$callassertTextContains1$try$funselection$classCarIdentitySelectionTest = "Управление подключено";

    /* JADX INFO: renamed from: Int$arg-0$call-assertEquals-2$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    private static int f9Int$arg0$callassertEquals2$try$funselection$classCarIdentitySelectionTest = 1;

    @LiveLiteralInfo(key = "Boolean$arg-0$call-selection$fun-selectedCarMustConfirmItsIdentity$class-CarIdentitySelectionTest", offset = 1461)
    /* JADX INFO: renamed from: Boolean$arg-0$call-selection$fun-selectedCarMustConfirmItsIdentity$class-CarIdentitySelectionTest, reason: not valid java name */
    public final boolean m511Boolean$arg0$callselection$funselectedCarMustConfirmItsIdentity$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f3Boolean$arg0$callselection$funselectedCarMustConfirmItsIdentity$classCarIdentitySelectionTest;
        }
        State<Boolean> stateLiveLiteral = f29State$Boolean$arg0$callselection$funselectedCarMustConfirmItsIdentity$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-selection$fun-selectedCarMustConfirmItsIdentity$class-CarIdentitySelectionTest", Boolean.valueOf(f3Boolean$arg0$callselection$funselectedCarMustConfirmItsIdentity$classCarIdentitySelectionTest));
            f29State$Boolean$arg0$callselection$funselectedCarMustConfirmItsIdentity$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-selection$fun-wrongIdentityRequiresExplicitManualSelectionOfActualBoard$class-CarIdentitySelectionTest", offset = 1564)
    /* JADX INFO: renamed from: Boolean$arg-0$call-selection$fun-wrongIdentityRequiresExplicitManualSelectionOfActualBoard$class-CarIdentitySelectionTest, reason: not valid java name */
    public final boolean m512Boolean$arg0$callselection$funwrongIdentityRequiresExplicitManualSelectionOfActualBoard$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f4Boolean$arg0$callselection$funwrongIdentityRequiresExplicitManualSelectionOfActualBoard$classCarIdentitySelectionTest;
        }
        State<Boolean> stateLiveLiteral = f30State$Boolean$arg0$callselection$funwrongIdentityRequiresExplicitManualSelectionOfActualBoard$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-selection$fun-wrongIdentityRequiresExplicitManualSelectionOfActualBoard$class-CarIdentitySelectionTest", Boolean.valueOf(f4Boolean$arg0$callselection$funwrongIdentityRequiresExplicitManualSelectionOfActualBoard$classCarIdentitySelectionTest));
            f30State$Boolean$arg0$callselection$funwrongIdentityRequiresExplicitManualSelectionOfActualBoard$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-assertTextContains$try$fun-selection$class-CarIdentitySelectionTest", offset = 4253)
    /* JADX INFO: renamed from: Boolean$arg-1$call-assertTextContains$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final boolean m513Boolean$arg1$callassertTextContains$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f5Boolean$arg1$callassertTextContains$try$funselection$classCarIdentitySelectionTest;
        }
        State<Boolean> stateLiveLiteral = f31State$Boolean$arg1$callassertTextContains$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-assertTextContains$try$fun-selection$class-CarIdentitySelectionTest", Boolean.valueOf(f5Boolean$arg1$callassertTextContains$try$funselection$classCarIdentitySelectionTest));
            f31State$Boolean$arg1$callassertTextContains$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-3$call-$init$$arg-0$call-invoke$fun-$anonymous$$arg-0$call-Button$fun-$anonymous$$arg-0$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest", offset = 3866)
    /* JADX INFO: renamed from: Boolean$arg-3$call-$init$$arg-0$call-invoke$fun-$anonymous$$arg-0$call-Button$fun-$anonymous$$arg-0$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final boolean m514Boolean$arg3$call$init$$arg0$callinvoke$fun$anonymous$$arg0$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f6Boolean$arg3$call$init$$arg0$callinvoke$fun$anonymous$$arg0$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest;
        }
        State<Boolean> stateLiveLiteral = f32State$Boolean$arg3$call$init$$arg0$callinvoke$fun$anonymous$$arg0$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-3$call-$init$$arg-0$call-invoke$fun-$anonymous$$arg-0$call-Button$fun-$anonymous$$arg-0$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest", Boolean.valueOf(f6Boolean$arg3$call$init$$arg0$callinvoke$fun$anonymous$$arg0$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest));
            f32State$Boolean$arg3$call$init$$arg0$callinvoke$fun$anonymous$$arg0$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-assertEquals$branch$if$try$fun-selection$class-CarIdentitySelectionTest", offset = 4667)
    /* JADX INFO: renamed from: Int$arg-0$call-assertEquals$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final int m515Int$arg0$callassertEquals$branch$if$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f7Int$arg0$callassertEquals$branch$if$try$funselection$classCarIdentitySelectionTest;
        }
        State<Integer> stateLiveLiteral = f33State$Int$arg0$callassertEquals$branch$if$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-assertEquals$branch$if$try$fun-selection$class-CarIdentitySelectionTest", Integer.valueOf(f7Int$arg0$callassertEquals$branch$if$try$funselection$classCarIdentitySelectionTest));
            f33State$Int$arg0$callassertEquals$branch$if$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-assertEquals-1$branch$if$try$fun-selection$class-CarIdentitySelectionTest", offset = 4711)
    /* JADX INFO: renamed from: Int$arg-0$call-assertEquals-1$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final int m516Int$arg0$callassertEquals1$branch$if$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f8Int$arg0$callassertEquals1$branch$if$try$funselection$classCarIdentitySelectionTest;
        }
        State<Integer> stateLiveLiteral = f34State$Int$arg0$callassertEquals1$branch$if$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-assertEquals-1$branch$if$try$fun-selection$class-CarIdentitySelectionTest", Integer.valueOf(f8Int$arg0$callassertEquals1$branch$if$try$funselection$classCarIdentitySelectionTest));
            f34State$Int$arg0$callassertEquals1$branch$if$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-assertEquals-2$try$fun-selection$class-CarIdentitySelectionTest", offset = 5511)
    /* JADX INFO: renamed from: Int$arg-0$call-assertEquals-2$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final int m517Int$arg0$callassertEquals2$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f9Int$arg0$callassertEquals2$try$funselection$classCarIdentitySelectionTest;
        }
        State<Integer> stateLiveLiteral = f35State$Int$arg0$callassertEquals2$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-assertEquals-2$try$fun-selection$class-CarIdentitySelectionTest", Integer.valueOf(f9Int$arg0$callassertEquals2$try$funselection$classCarIdentitySelectionTest));
            f35State$Int$arg0$callassertEquals2$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-chunked$$$this$call-map$$$this$call-toByteArray$val-bytes$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest", offset = 2531)
    /* JADX INFO: renamed from: Int$arg-0$call-chunked$$$this$call-map$$$this$call-toByteArray$val-bytes$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final int m518Int$arg0$callchunked$$$this$callmap$$$this$calltoByteArray$valbytes$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f10Int$arg0$callchunked$$$this$callmap$$$this$calltoByteArray$valbytes$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;
        }
        State<Integer> stateLiveLiteral = f36State$Int$arg0$callchunked$$$this$callmap$$$this$calltoByteArray$valbytes$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-chunked$$$this$call-map$$$this$call-toByteArray$val-bytes$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest", Integer.valueOf(f10Int$arg0$callchunked$$$this$callmap$$$this$calltoByteArray$valbytes$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest));
            f36State$Int$arg0$callchunked$$$this$callmap$$$this$calltoByteArray$valbytes$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-get$$this$call-toInt$$this$call-xor$$this$call-toByte$arg-1$call-set$branch$if$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest", offset = 2635)
    /* JADX INFO: renamed from: Int$arg-0$call-get$$this$call-toInt$$this$call-xor$$this$call-toByte$arg-1$call-set$branch$if$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final int m519Int$arg0$callget$$this$calltoInt$$this$callxor$$this$calltoByte$arg1$callset$branch$if$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f11Int$arg0$callget$$this$calltoInt$$this$callxor$$this$calltoByte$arg1$callset$branch$if$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;
        }
        State<Integer> stateLiveLiteral = f37State$Int$arg0$callget$$this$calltoInt$$this$callxor$$this$calltoByte$arg1$callset$branch$if$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-get$$this$call-toInt$$this$call-xor$$this$call-toByte$arg-1$call-set$branch$if$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest", Integer.valueOf(f11Int$arg0$callget$$this$calltoInt$$this$callxor$$this$calltoByte$arg1$callset$branch$if$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest));
            f37State$Int$arg0$callget$$this$calltoInt$$this$callxor$$this$calltoByte$arg1$callset$branch$if$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-set$branch$if$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest", offset = 2623)
    /* JADX INFO: renamed from: Int$arg-0$call-set$branch$if$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final int m520Int$arg0$callset$branch$if$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f12Int$arg0$callset$branch$if$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;
        }
        State<Integer> stateLiveLiteral = f38State$Int$arg0$callset$branch$if$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-set$branch$if$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest", Integer.valueOf(f12Int$arg0$callset$branch$if$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest));
            f38State$Int$arg0$callset$branch$if$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-start$fun-selection$class-CarIdentitySelectionTest", offset = 3386)
    /* JADX INFO: renamed from: Int$arg-0$call-start$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final int m521Int$arg0$callstart$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f13Int$arg0$callstart$funselection$classCarIdentitySelectionTest;
        }
        State<Integer> stateLiveLiteral = f39State$Int$arg0$callstart$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-start$fun-selection$class-CarIdentitySelectionTest", Integer.valueOf(f13Int$arg0$callstart$funselection$classCarIdentitySelectionTest));
            f39State$Int$arg0$callstart$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-toInt$$this$call-toByte$fun-$anonymous$$arg-0$call-map$$$this$call-toByteArray$val-bytes$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest", offset = 2549)
    /* JADX INFO: renamed from: Int$arg-0$call-toInt$$this$call-toByte$fun-$anonymous$$arg-0$call-map$$$this$call-toByteArray$val-bytes$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final int m522Int$arg0$calltoInt$$this$calltoByte$fun$anonymous$$arg0$callmap$$$this$calltoByteArray$valbytes$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f14Int$arg0$calltoInt$$this$calltoByte$fun$anonymous$$arg0$callmap$$$this$calltoByteArray$valbytes$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;
        }
        State<Integer> stateLiveLiteral = f40State$Int$arg0$calltoInt$$this$calltoByte$fun$anonymous$$arg0$callmap$$$this$calltoByteArray$valbytes$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-toInt$$this$call-toByte$fun-$anonymous$$arg-0$call-map$$$this$call-toByteArray$val-bytes$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest", Integer.valueOf(f14Int$arg0$calltoInt$$this$calltoByte$fun$anonymous$$arg0$callmap$$$this$calltoByteArray$valbytes$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest));
            f40State$Int$arg0$calltoInt$$this$calltoByte$fun$anonymous$$arg0$callmap$$$this$calltoByteArray$valbytes$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-toString$1$str$arg-0$call-setBody$branch$if$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest", offset = 2208)
    /* JADX INFO: renamed from: Int$arg-0$call-toString$1$str$arg-0$call-setBody$branch$if$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final int m523Int$arg0$calltoString$1$str$arg0$callsetBody$branch$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f15Int$arg0$calltoString$1$str$arg0$callsetBody$branch$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;
        }
        State<Integer> stateLiveLiteral = f41State$Int$arg0$calltoString$1$str$arg0$callsetBody$branch$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-toString$1$str$arg-0$call-setBody$branch$if$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest", Integer.valueOf(f15Int$arg0$calltoString$1$str$arg0$callsetBody$branch$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest));
            f41State$Int$arg0$calltoString$1$str$arg0$callsetBody$branch$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-xor$$this$call-toByte$arg-1$call-set$branch$if$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest", offset = 2650)
    /* JADX INFO: renamed from: Int$arg-0$call-xor$$this$call-toByte$arg-1$call-set$branch$if$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final int m524Int$arg0$callxor$$this$calltoByte$arg1$callset$branch$if$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f16Int$arg0$callxor$$this$calltoByte$arg1$callset$branch$if$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;
        }
        State<Integer> stateLiveLiteral = f42State$Int$arg0$callxor$$this$calltoByte$arg1$callset$branch$if$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-xor$$this$call-toByte$arg-1$call-set$branch$if$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest", Integer.valueOf(f16Int$arg0$callxor$$this$calltoByte$arg1$callset$branch$if$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest));
            f42State$Int$arg0$callxor$$this$calltoByte$arg1$callset$branch$if$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-$init$$arg-0$call-invoke$fun-$anonymous$$arg-0$call-Button$fun-$anonymous$$arg-0$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest", offset = 3854)
    /* JADX INFO: renamed from: Int$arg-1$call-$init$$arg-0$call-invoke$fun-$anonymous$$arg-0$call-Button$fun-$anonymous$$arg-0$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final int m525Int$arg1$call$init$$arg0$callinvoke$fun$anonymous$$arg0$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f17Int$arg1$call$init$$arg0$callinvoke$fun$anonymous$$arg0$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest;
        }
        State<Integer> stateLiveLiteral = f43State$Int$arg1$call$init$$arg0$callinvoke$fun$anonymous$$arg0$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-$init$$arg-0$call-invoke$fun-$anonymous$$arg-0$call-Button$fun-$anonymous$$arg-0$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest", Integer.valueOf(f17Int$arg1$call$init$$arg0$callinvoke$fun$anonymous$$arg0$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest));
            f43State$Int$arg1$call$init$$arg0$callinvoke$fun$anonymous$$arg0$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest", offset = 3738)
    /* JADX INFO: renamed from: Int$arg-1$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final int m526Int$arg1$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f18Int$arg1$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest;
        }
        State<Integer> stateLiveLiteral = f44State$Int$arg1$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest", Integer.valueOf(f18Int$arg1$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest));
            f44State$Int$arg1$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-greater$fun-$anonymous$$arg-1$call-waitUntil$try$fun-selection$class-CarIdentitySelectionTest", offset = 5383)
    /* JADX INFO: renamed from: Int$arg-1$call-greater$fun-$anonymous$$arg-1$call-waitUntil$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final int m527Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f19Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$funselection$classCarIdentitySelectionTest;
        }
        State<Integer> stateLiveLiteral = f45State$Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-greater$fun-$anonymous$$arg-1$call-waitUntil$try$fun-selection$class-CarIdentitySelectionTest", Integer.valueOf(f19Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$funselection$classCarIdentitySelectionTest));
            f45State$Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-takeRequest$arg-0$call-CHECK_NOT_NULL$$this$call-getPath$arg-1$call-assertEquals$try$fun-selection$class-CarIdentitySelectionTest", offset = 4378)
    /* JADX INFO: renamed from: Long$arg-0$call-takeRequest$arg-0$call-CHECK_NOT_NULL$$this$call-getPath$arg-1$call-assertEquals$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final long m528Long$arg0$calltakeRequest$arg0$callCHECK_NOT_NULL$$this$callgetPath$arg1$callassertEquals$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f20Long$arg0$calltakeRequest$arg0$callCHECK_NOT_NULL$$this$callgetPath$arg1$callassertEquals$try$funselection$classCarIdentitySelectionTest;
        }
        State<Long> stateLiveLiteral = f46State$Long$arg0$calltakeRequest$arg0$callCHECK_NOT_NULL$$this$callgetPath$arg1$callassertEquals$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-takeRequest$arg-0$call-CHECK_NOT_NULL$$this$call-getPath$arg-1$call-assertEquals$try$fun-selection$class-CarIdentitySelectionTest", Long.valueOf(f20Long$arg0$calltakeRequest$arg0$callCHECK_NOT_NULL$$this$callgetPath$arg1$callassertEquals$try$funselection$classCarIdentitySelectionTest));
            f46State$Long$arg0$calltakeRequest$arg0$callCHECK_NOT_NULL$$this$callgetPath$arg1$callassertEquals$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-takeRequest$arg-0$call-CHECK_NOT_NULL$$this$call-getPath$arg-1$call-assertEquals-1$try$fun-selection$class-CarIdentitySelectionTest", offset = 5301)
    /* JADX INFO: renamed from: Long$arg-0$call-takeRequest$arg-0$call-CHECK_NOT_NULL$$this$call-getPath$arg-1$call-assertEquals-1$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final long m529Long$arg0$calltakeRequest$arg0$callCHECK_NOT_NULL$$this$callgetPath$arg1$callassertEquals1$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f21Long$arg0$calltakeRequest$arg0$callCHECK_NOT_NULL$$this$callgetPath$arg1$callassertEquals1$try$funselection$classCarIdentitySelectionTest;
        }
        State<Long> stateLiveLiteral = f47State$Long$arg0$calltakeRequest$arg0$callCHECK_NOT_NULL$$this$callgetPath$arg1$callassertEquals1$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-takeRequest$arg-0$call-CHECK_NOT_NULL$$this$call-getPath$arg-1$call-assertEquals-1$try$fun-selection$class-CarIdentitySelectionTest", Long.valueOf(f21Long$arg0$calltakeRequest$arg0$callCHECK_NOT_NULL$$this$callgetPath$arg1$callassertEquals1$try$funselection$classCarIdentitySelectionTest));
            f47State$Long$arg0$calltakeRequest$arg0$callCHECK_NOT_NULL$$this$callgetPath$arg1$callassertEquals1$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-takeRequest$arg-0$call-CHECK_NOT_NULL$$this$call-getPath$arg-1$call-assertEquals-2$branch$if$try$fun-selection$class-CarIdentitySelectionTest", offset = 5193)
    /* JADX INFO: renamed from: Long$arg-0$call-takeRequest$arg-0$call-CHECK_NOT_NULL$$this$call-getPath$arg-1$call-assertEquals-2$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final long m530Long$arg0$calltakeRequest$arg0$callCHECK_NOT_NULL$$this$callgetPath$arg1$callassertEquals2$branch$if$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f22Long$arg0$calltakeRequest$arg0$callCHECK_NOT_NULL$$this$callgetPath$arg1$callassertEquals2$branch$if$try$funselection$classCarIdentitySelectionTest;
        }
        State<Long> stateLiveLiteral = f48State$Long$arg0$calltakeRequest$arg0$callCHECK_NOT_NULL$$this$callgetPath$arg1$callassertEquals2$branch$if$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-takeRequest$arg-0$call-CHECK_NOT_NULL$$this$call-getPath$arg-1$call-assertEquals-2$branch$if$try$fun-selection$class-CarIdentitySelectionTest", Long.valueOf(f22Long$arg0$calltakeRequest$arg0$callCHECK_NOT_NULL$$this$callgetPath$arg1$callassertEquals2$branch$if$try$funselection$classCarIdentitySelectionTest));
            f48State$Long$arg0$calltakeRequest$arg0$callCHECK_NOT_NULL$$this$callgetPath$arg1$callassertEquals2$branch$if$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-waitUntil$branch$if$try$fun-selection$class-CarIdentitySelectionTest", offset = 4470)
    /* JADX INFO: renamed from: Long$arg-0$call-waitUntil$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final long m531Long$arg0$callwaitUntil$branch$if$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f23Long$arg0$callwaitUntil$branch$if$try$funselection$classCarIdentitySelectionTest;
        }
        State<Long> stateLiveLiteral = f49State$Long$arg0$callwaitUntil$branch$if$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-waitUntil$branch$if$try$fun-selection$class-CarIdentitySelectionTest", Long.valueOf(f23Long$arg0$callwaitUntil$branch$if$try$funselection$classCarIdentitySelectionTest));
            f49State$Long$arg0$callwaitUntil$branch$if$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-waitUntil$try$fun-selection$class-CarIdentitySelectionTest", offset = 5360)
    /* JADX INFO: renamed from: Long$arg-0$call-waitUntil$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final long m532Long$arg0$callwaitUntil$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f24Long$arg0$callwaitUntil$try$funselection$classCarIdentitySelectionTest;
        }
        State<Long> stateLiveLiteral = f50State$Long$arg0$callwaitUntil$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-waitUntil$try$fun-selection$class-CarIdentitySelectionTest", Long.valueOf(f24Long$arg0$callwaitUntil$try$funselection$classCarIdentitySelectionTest));
            f50State$Long$arg0$callwaitUntil$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-xor$else$if$val-actualChip$fun-selection$class-CarIdentitySelectionTest", offset = 1744)
    /* JADX INFO: renamed from: Long$arg-0$call-xor$else$if$val-actualChip$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final long m533Long$arg0$callxor$else$if$valactualChip$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f25Long$arg0$callxor$else$if$valactualChip$funselection$classCarIdentitySelectionTest;
        }
        State<Long> stateLiveLiteral = f51State$Long$arg0$callxor$else$if$valactualChip$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-xor$else$if$val-actualChip$fun-selection$class-CarIdentitySelectionTest", Long.valueOf(f25Long$arg0$callxor$else$if$valactualChip$funselection$classCarIdentitySelectionTest));
            f51State$Long$arg0$callxor$else$if$valactualChip$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-2$call-$init$$$this$call-encode$0$vararg$arg-0$call-of$arg-0$call-send$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest", offset = 2838)
    /* JADX INFO: renamed from: Long$arg-2$call-$init$$$this$call-encode$0$vararg$arg-0$call-of$arg-0$call-send$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final long m534Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f26Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;
        }
        State<Long> stateLiveLiteral = f52State$Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-2$call-$init$$$this$call-encode$0$vararg$arg-0$call-of$arg-0$call-send$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest", Long.valueOf(f26Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest));
            f52State$Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "Long$val-chip$fun-selection$class-CarIdentitySelectionTest", offset = 1638)
    /* JADX INFO: renamed from: Long$val-chip$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final long m535Long$valchip$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f27Long$valchip$funselection$classCarIdentitySelectionTest;
        }
        State<Long> stateLiveLiteral = f53State$Long$valchip$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$val-chip$fun-selection$class-CarIdentitySelectionTest", Long.valueOf(f27Long$valchip$funselection$classCarIdentitySelectionTest));
            f53State$Long$valchip$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "Long$val-token$fun-selection$class-CarIdentitySelectionTest", offset = 1674)
    /* JADX INFO: renamed from: Long$val-token$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final long m536Long$valtoken$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f28Long$valtoken$funselection$classCarIdentitySelectionTest;
        }
        State<Long> stateLiveLiteral = f54State$Long$valtoken$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$val-token$fun-selection$class-CarIdentitySelectionTest", Long.valueOf(f28Long$valtoken$funselection$classCarIdentitySelectionTest));
            f54State$Long$valtoken$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "String$$$this$call-chunked$$$this$call-map$$$this$call-toByteArray$val-bytes$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest", offset = 2489)
    /* JADX INFO: renamed from: String$$$this$call-chunked$$$this$call-map$$$this$call-toByteArray$val-bytes$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final String m537String$$$this$callchunked$$$this$callmap$$$this$calltoByteArray$valbytes$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f78String$$$this$callchunked$$$this$callmap$$$this$calltoByteArray$valbytes$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;
        }
        State<String> stateLiveLiteral = f55State$String$$$this$callchunked$$$this$callmap$$$this$calltoByteArray$valbytes$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$$$this$call-chunked$$$this$call-map$$$this$call-toByteArray$val-bytes$branch$if$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest", f78String$$$this$callchunked$$$this$callmap$$$this$calltoByteArray$valbytes$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest);
            f55State$String$$$this$callchunked$$$this$callmap$$$this$calltoByteArray$valbytes$branch$if$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-setBody$branch$if$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest", offset = 2085)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-setBody$branch$if$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final String m538String$0$str$arg0$callsetBody$branch$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f79String$0$str$arg0$callsetBody$branch$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;
        }
        State<String> stateLiveLiteral = f56State$String$0$str$arg0$callsetBody$branch$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-setBody$branch$if$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest", f79String$0$str$arg0$callsetBody$branch$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest);
            f56State$String$0$str$arg0$callsetBody$branch$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$arg-0$call-setBody$branch$if$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest", offset = 2212)
    /* JADX INFO: renamed from: String$2$str$arg-0$call-setBody$branch$if$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final String m539String$2$str$arg0$callsetBody$branch$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f80String$2$str$arg0$callsetBody$branch$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;
        }
        State<String> stateLiveLiteral = f57State$String$2$str$arg0$callsetBody$branch$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$arg-0$call-setBody$branch$if$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest", f80String$2$str$arg0$callsetBody$branch$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest);
            f57State$String$2$str$arg0$callsetBody$branch$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$arg-0$call-invoke$fun-$anonymous$$arg-0$call-Button$fun-$anonymous$$arg-0$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest", offset = 3842)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-0$call-invoke$fun-$anonymous$$arg-0$call-Button$fun-$anonymous$$arg-0$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final String m540String$arg0$call$init$$arg0$callinvoke$fun$anonymous$$arg0$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f81String$arg0$call$init$$arg0$callinvoke$fun$anonymous$$arg0$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest;
        }
        State<String> stateLiveLiteral = f58State$String$arg0$call$init$$arg0$callinvoke$fun$anonymous$$arg0$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$arg-0$call-invoke$fun-$anonymous$$arg-0$call-Button$fun-$anonymous$$arg-0$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest", f81String$arg0$call$init$$arg0$callinvoke$fun$anonymous$$arg0$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest);
            f58State$String$arg0$call$init$$arg0$callinvoke$fun$anonymous$$arg0$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-Text$fun-$anonymous$$arg-9$call-Button$fun-$anonymous$$arg-0$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest", offset = 3985)
    /* JADX INFO: renamed from: String$arg-0$call-Text$fun-$anonymous$$arg-9$call-Button$fun-$anonymous$$arg-0$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final String m541String$arg0$callText$fun$anonymous$$arg9$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f82String$arg0$callText$fun$anonymous$$arg9$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest;
        }
        State<String> stateLiveLiteral = f59State$String$arg0$callText$fun$anonymous$$arg9$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-Text$fun-$anonymous$$arg-9$call-Button$fun-$anonymous$$arg-0$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest", f82String$arg0$callText$fun$anonymous$$arg9$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest);
            f59State$String$arg0$callText$fun$anonymous$$arg9$callButton$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-assertEquals$try$fun-selection$class-CarIdentitySelectionTest", offset = 4349)
    /* JADX INFO: renamed from: String$arg-0$call-assertEquals$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final String m542String$arg0$callassertEquals$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f83String$arg0$callassertEquals$try$funselection$classCarIdentitySelectionTest;
        }
        State<String> stateLiveLiteral = f60State$String$arg0$callassertEquals$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-assertEquals$try$fun-selection$class-CarIdentitySelectionTest", f83String$arg0$callassertEquals$try$funselection$classCarIdentitySelectionTest);
            f60State$String$arg0$callassertEquals$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-assertEquals-2$branch$if$try$fun-selection$class-CarIdentitySelectionTest", offset = 5164)
    /* JADX INFO: renamed from: String$arg-0$call-assertEquals-2$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final String m543String$arg0$callassertEquals2$branch$if$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f84String$arg0$callassertEquals2$branch$if$try$funselection$classCarIdentitySelectionTest;
        }
        State<String> stateLiveLiteral = f61State$String$arg0$callassertEquals2$branch$if$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-assertEquals-2$branch$if$try$fun-selection$class-CarIdentitySelectionTest", f84String$arg0$callassertEquals2$branch$if$try$funselection$classCarIdentitySelectionTest);
            f61State$String$arg0$callassertEquals2$branch$if$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-assertTextContains$branch$if$try$fun-selection$class-CarIdentitySelectionTest", offset = 5016)
    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final String m544String$arg0$callassertTextContains$branch$if$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f85String$arg0$callassertTextContains$branch$if$try$funselection$classCarIdentitySelectionTest;
        }
        State<String> stateLiveLiteral = f62State$String$arg0$callassertTextContains$branch$if$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-assertTextContains$branch$if$try$fun-selection$class-CarIdentitySelectionTest", f85String$arg0$callassertTextContains$branch$if$try$funselection$classCarIdentitySelectionTest);
            f62State$String$arg0$callassertTextContains$branch$if$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil$branch$if$try$fun-selection$class-CarIdentitySelectionTest", offset = 4575)
    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final String m545String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil$branch$if$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f86String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil$branch$if$try$funselection$classCarIdentitySelectionTest;
        }
        State<String> stateLiveLiteral = f63State$String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil$branch$if$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil$branch$if$try$fun-selection$class-CarIdentitySelectionTest", f86String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil$branch$if$try$funselection$classCarIdentitySelectionTest);
            f63State$String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil$branch$if$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-assertTextContains$try$fun-selection$class-CarIdentitySelectionTest", offset = 4226)
    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final String m546String$arg0$callassertTextContains$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f87String$arg0$callassertTextContains$try$funselection$classCarIdentitySelectionTest;
        }
        State<String> stateLiveLiteral = f64State$String$arg0$callassertTextContains$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-assertTextContains$try$fun-selection$class-CarIdentitySelectionTest", f87String$arg0$callassertTextContains$try$funselection$classCarIdentitySelectionTest);
            f64State$String$arg0$callassertTextContains$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-assertTextContains-1$try$fun-selection$class-CarIdentitySelectionTest", offset = 5462)
    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains-1$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final String m547String$arg0$callassertTextContains1$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f88String$arg0$callassertTextContains1$try$funselection$classCarIdentitySelectionTest;
        }
        State<String> stateLiveLiteral = f65State$String$arg0$callassertTextContains1$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-assertTextContains-1$try$fun-selection$class-CarIdentitySelectionTest", f88String$arg0$callassertTextContains1$try$funselection$classCarIdentitySelectionTest);
            f65State$String$arg0$callassertTextContains1$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$branch$if$try$fun-selection$class-CarIdentitySelectionTest", offset = 4972)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final String m548String$arg0$callonNodeWithTag$$$this$callassertTextContains$branch$if$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f89String$arg0$callonNodeWithTag$$$this$callassertTextContains$branch$if$try$funselection$classCarIdentitySelectionTest;
        }
        State<String> stateLiveLiteral = f66State$String$arg0$callonNodeWithTag$$$this$callassertTextContains$branch$if$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$branch$if$try$fun-selection$class-CarIdentitySelectionTest", f89String$arg0$callonNodeWithTag$$$this$callassertTextContains$branch$if$try$funselection$classCarIdentitySelectionTest);
            f66State$String$arg0$callonNodeWithTag$$$this$callassertTextContains$branch$if$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil$branch$if$try$fun-selection$class-CarIdentitySelectionTest", offset = 4535)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final String m549String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil$branch$if$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f90String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil$branch$if$try$funselection$classCarIdentitySelectionTest;
        }
        State<String> stateLiveLiteral = f67State$String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil$branch$if$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil$branch$if$try$fun-selection$class-CarIdentitySelectionTest", f90String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil$branch$if$try$funselection$classCarIdentitySelectionTest);
            f67State$String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil$branch$if$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$try$fun-selection$class-CarIdentitySelectionTest", offset = 4182)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final String m550String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f91String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$funselection$classCarIdentitySelectionTest;
        }
        State<String> stateLiveLiteral = f68State$String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$try$fun-selection$class-CarIdentitySelectionTest", f91String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$funselection$classCarIdentitySelectionTest);
            f68State$String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-1$try$fun-selection$class-CarIdentitySelectionTest", offset = 5422)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-1$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final String m551String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f92String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$funselection$classCarIdentitySelectionTest;
        }
        State<String> stateLiveLiteral = f69State$String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-1$try$fun-selection$class-CarIdentitySelectionTest", f92String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$funselection$classCarIdentitySelectionTest);
            f69State$String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-performClick$branch$if$try$fun-selection$class-CarIdentitySelectionTest", offset = 5105)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performClick$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final String m552String$arg0$callonNodeWithTag$$$this$callperformClick$branch$if$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f93String$arg0$callonNodeWithTag$$$this$callperformClick$branch$if$try$funselection$classCarIdentitySelectionTest;
        }
        State<String> stateLiveLiteral = f70State$String$arg0$callonNodeWithTag$$$this$callperformClick$branch$if$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-performClick$branch$if$try$fun-selection$class-CarIdentitySelectionTest", f93String$arg0$callonNodeWithTag$$$this$callperformClick$branch$if$try$funselection$classCarIdentitySelectionTest);
            f70State$String$arg0$callonNodeWithTag$$$this$callperformClick$branch$if$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-performClick$try$fun-selection$class-CarIdentitySelectionTest", offset = 4113)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performClick$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final String m553String$arg0$callonNodeWithTag$$$this$callperformClick$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f94String$arg0$callonNodeWithTag$$$this$callperformClick$try$funselection$classCarIdentitySelectionTest;
        }
        State<String> stateLiveLiteral = f71State$String$arg0$callonNodeWithTag$$$this$callperformClick$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-performClick$try$fun-selection$class-CarIdentitySelectionTest", f94String$arg0$callonNodeWithTag$$$this$callperformClick$try$funselection$classCarIdentitySelectionTest);
            f71State$String$arg0$callonNodeWithTag$$$this$callperformClick$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-performClick-1$try$fun-selection$class-CarIdentitySelectionTest", offset = 4294)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performClick-1$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final String m554String$arg0$callonNodeWithTag$$$this$callperformClick1$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f95String$arg0$callonNodeWithTag$$$this$callperformClick1$try$funselection$classCarIdentitySelectionTest;
        }
        State<String> stateLiveLiteral = f72State$String$arg0$callonNodeWithTag$$$this$callperformClick1$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-performClick-1$try$fun-selection$class-CarIdentitySelectionTest", f95String$arg0$callonNodeWithTag$$$this$callperformClick1$try$funselection$classCarIdentitySelectionTest);
            f72State$String$arg0$callonNodeWithTag$$$this$callperformClick1$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-performTextClearance$branch$if$try$fun-selection$class-CarIdentitySelectionTest", offset = 4807)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performTextClearance$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final String m555String$arg0$callonNodeWithTag$$$this$callperformTextClearance$branch$if$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f96String$arg0$callonNodeWithTag$$$this$callperformTextClearance$branch$if$try$funselection$classCarIdentitySelectionTest;
        }
        State<String> stateLiveLiteral = f73State$String$arg0$callonNodeWithTag$$$this$callperformTextClearance$branch$if$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-performTextClearance$branch$if$try$fun-selection$class-CarIdentitySelectionTest", f96String$arg0$callonNodeWithTag$$$this$callperformTextClearance$branch$if$try$funselection$classCarIdentitySelectionTest);
            f73State$String$arg0$callonNodeWithTag$$$this$callperformTextClearance$branch$if$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-performTextReplacement$branch$if$try$fun-selection$class-CarIdentitySelectionTest", offset = 4883)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performTextReplacement$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final String m556String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$branch$if$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f97String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$branch$if$try$funselection$classCarIdentitySelectionTest;
        }
        State<String> stateLiveLiteral = f74State$String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$branch$if$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-performTextReplacement$branch$if$try$fun-selection$class-CarIdentitySelectionTest", f97String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$branch$if$try$funselection$classCarIdentitySelectionTest);
            f74State$String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$branch$if$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-performTextReplacement$branch$if$try$fun-selection$class-CarIdentitySelectionTest", offset = 4921)
    /* JADX INFO: renamed from: String$arg-0$call-performTextReplacement$branch$if$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final String m557String$arg0$callperformTextReplacement$branch$if$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f98String$arg0$callperformTextReplacement$branch$if$try$funselection$classCarIdentitySelectionTest;
        }
        State<String> stateLiveLiteral = f75State$String$arg0$callperformTextReplacement$branch$if$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-performTextReplacement$branch$if$try$fun-selection$class-CarIdentitySelectionTest", f98String$arg0$callperformTextReplacement$branch$if$try$funselection$classCarIdentitySelectionTest);
            f75State$String$arg0$callperformTextReplacement$branch$if$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-testTag$val-tmp0_modifier$fun-$anonymous$$arg-0$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest", offset = 3957)
    /* JADX INFO: renamed from: String$arg-0$call-testTag$val-tmp0_modifier$fun-$anonymous$$arg-0$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final String m558String$arg0$calltestTag$valtmp0_modifier$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f99String$arg0$calltestTag$valtmp0_modifier$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest;
        }
        State<String> stateLiveLiteral = f76State$String$arg0$calltestTag$valtmp0_modifier$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-testTag$val-tmp0_modifier$fun-$anonymous$$arg-0$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-$anonymous$$arg-0$call-runOnUiThread$try$fun-selection$class-CarIdentitySelectionTest", f99String$arg0$calltestTag$valtmp0_modifier$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest);
            f76State$String$arg0$calltestTag$valtmp0_modifier$fun$anonymous$$arg0$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$fun$anonymous$$arg0$callrunOnUiThread$try$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-1$call-EQEQ$cond$if$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest", offset = 2021)
    /* JADX INFO: renamed from: String$arg-1$call-EQEQ$cond$if$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest, reason: not valid java name */
    public final String m559String$arg1$callEQEQ$cond$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f100String$arg1$callEQEQ$cond$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;
        }
        State<String> stateLiveLiteral = f77State$String$arg1$callEQEQ$cond$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-1$call-EQEQ$cond$if$fun-dispatch$class-$no-name-provided$$arg-0$call-setDispatcher$fun-selection$class-CarIdentitySelectionTest", f100String$arg1$callEQEQ$cond$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest);
            f77State$String$arg1$callEQEQ$cond$if$fundispatch$class$nonameprovided$$arg0$callsetDispatcher$funselection$classCarIdentitySelectionTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }
}
