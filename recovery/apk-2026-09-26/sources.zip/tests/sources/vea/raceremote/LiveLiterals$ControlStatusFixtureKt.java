package vea.raceremote;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: ControlStatusFixture.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/androidTest/java/vea/raceremote/ControlStatusFixture.kt")
public final class LiveLiterals$ControlStatusFixtureKt {

    /* JADX INFO: renamed from: State$Byte$0$vararg$arg-0$call-byteArrayOf$arg-0$call-put$$this$call-putInt$$this$call-putLong$$this$call-array$val-bytes$fun-sendFixtureIdentity, reason: not valid java name */
    private static State<Byte> f255State$Byte$0$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity;

    /* JADX INFO: renamed from: State$Byte$1$vararg$arg-0$call-byteArrayOf$arg-0$call-put$$this$call-putInt$$this$call-putLong$$this$call-array$val-bytes$fun-sendFixtureIdentity, reason: not valid java name */
    private static State<Byte> f256State$Byte$1$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity;

    /* JADX INFO: renamed from: State$Byte$2$vararg$arg-0$call-byteArrayOf$arg-0$call-put$$this$call-putInt$$this$call-putLong$$this$call-array$val-bytes$fun-sendFixtureIdentity, reason: not valid java name */
    private static State<Byte> f257State$Byte$2$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity;

    /* JADX INFO: renamed from: State$Int$$this$call-toByte$3$vararg$arg-0$call-byteArrayOf$arg-0$call-put$$this$call-putInt$$this$call-putLong$$this$call-array$val-bytes$fun-sendFixtureIdentity, reason: not valid java name */
    private static State<Integer> f258State$Int$$this$calltoByte$3$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity;

    /* JADX INFO: renamed from: State$Int$arg-0$call-allocate$$this$call-order$$this$call-put$$this$call-putInt$$this$call-putLong$$this$call-array$val-bytes$fun-sendFixtureIdentity, reason: not valid java name */
    private static State<Integer> f259State$Int$arg0$callallocate$$this$callorder$$this$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity;

    /* JADX INFO: renamed from: State$Int$arg-1$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-showControlFixture, reason: not valid java name */
    private static State<Integer> f260State$Int$arg1$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$funshowControlFixture;

    /* JADX INFO: renamed from: State$String$arg-0$call-setBody$arg-0$call-enqueue$fun-enqueueControlStatus, reason: not valid java name */
    private static State<String> f261State$String$arg0$callsetBody$arg0$callenqueue$funenqueueControlStatus;
    public static final LiveLiterals$ControlStatusFixtureKt INSTANCE = new LiveLiterals$ControlStatusFixtureKt();

    /* JADX INFO: renamed from: String$arg-0$call-setBody$arg-0$call-enqueue$fun-enqueueControlStatus, reason: not valid java name */
    private static String f262String$arg0$callsetBody$arg0$callenqueue$funenqueueControlStatus = "{\"protocol\":1,\"acceptingControl\":true,\"controlTransport\":\"websocket-v1\",\"controlPort\":1337,\"chipId\":\"123456\"}";

    /* JADX INFO: renamed from: Int$arg-0$call-allocate$$this$call-order$$this$call-put$$this$call-putInt$$this$call-putLong$$this$call-array$val-bytes$fun-sendFixtureIdentity, reason: not valid java name */
    private static int f253Int$arg0$callallocate$$this$callorder$$this$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity = 16;

    /* JADX INFO: renamed from: Byte$0$vararg$arg-0$call-byteArrayOf$arg-0$call-put$$this$call-putInt$$this$call-putLong$$this$call-array$val-bytes$fun-sendFixtureIdentity, reason: not valid java name */
    private static byte f249Byte$0$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity = 82;

    /* JADX INFO: renamed from: Byte$1$vararg$arg-0$call-byteArrayOf$arg-0$call-put$$this$call-putInt$$this$call-putLong$$this$call-array$val-bytes$fun-sendFixtureIdentity, reason: not valid java name */
    private static byte f250Byte$1$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity = 67;

    /* JADX INFO: renamed from: Byte$2$vararg$arg-0$call-byteArrayOf$arg-0$call-put$$this$call-putInt$$this$call-putLong$$this$call-array$val-bytes$fun-sendFixtureIdentity, reason: not valid java name */
    private static byte f251Byte$2$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity = 1;

    /* JADX INFO: renamed from: Int$$this$call-toByte$3$vararg$arg-0$call-byteArrayOf$arg-0$call-put$$this$call-putInt$$this$call-putLong$$this$call-array$val-bytes$fun-sendFixtureIdentity, reason: not valid java name */
    private static int f252Int$$this$calltoByte$3$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity = 130;

    /* JADX INFO: renamed from: Int$arg-1$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-showControlFixture, reason: not valid java name */
    private static int f254Int$arg1$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$funshowControlFixture = 1337;

    @LiveLiteralInfo(key = "Byte$0$vararg$arg-0$call-byteArrayOf$arg-0$call-put$$this$call-putInt$$this$call-putLong$$this$call-array$val-bytes$fun-sendFixtureIdentity", offset = 795)
    /* JADX INFO: renamed from: Byte$0$vararg$arg-0$call-byteArrayOf$arg-0$call-put$$this$call-putInt$$this$call-putLong$$this$call-array$val-bytes$fun-sendFixtureIdentity, reason: not valid java name */
    public final byte m634Byte$0$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f249Byte$0$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity;
        }
        State<Byte> stateLiveLiteral = f255State$Byte$0$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Byte$0$vararg$arg-0$call-byteArrayOf$arg-0$call-put$$this$call-putInt$$this$call-putLong$$this$call-array$val-bytes$fun-sendFixtureIdentity", Byte.valueOf(f249Byte$0$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity));
            f255State$Byte$0$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).byteValue();
    }

    @LiveLiteralInfo(key = "Byte$1$vararg$arg-0$call-byteArrayOf$arg-0$call-put$$this$call-putInt$$this$call-putLong$$this$call-array$val-bytes$fun-sendFixtureIdentity", offset = 799)
    /* JADX INFO: renamed from: Byte$1$vararg$arg-0$call-byteArrayOf$arg-0$call-put$$this$call-putInt$$this$call-putLong$$this$call-array$val-bytes$fun-sendFixtureIdentity, reason: not valid java name */
    public final byte m635Byte$1$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f250Byte$1$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity;
        }
        State<Byte> stateLiveLiteral = f256State$Byte$1$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Byte$1$vararg$arg-0$call-byteArrayOf$arg-0$call-put$$this$call-putInt$$this$call-putLong$$this$call-array$val-bytes$fun-sendFixtureIdentity", Byte.valueOf(f250Byte$1$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity));
            f256State$Byte$1$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).byteValue();
    }

    @LiveLiteralInfo(key = "Byte$2$vararg$arg-0$call-byteArrayOf$arg-0$call-put$$this$call-putInt$$this$call-putLong$$this$call-array$val-bytes$fun-sendFixtureIdentity", offset = 803)
    /* JADX INFO: renamed from: Byte$2$vararg$arg-0$call-byteArrayOf$arg-0$call-put$$this$call-putInt$$this$call-putLong$$this$call-array$val-bytes$fun-sendFixtureIdentity, reason: not valid java name */
    public final byte m636Byte$2$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f251Byte$2$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity;
        }
        State<Byte> stateLiveLiteral = f257State$Byte$2$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Byte$2$vararg$arg-0$call-byteArrayOf$arg-0$call-put$$this$call-putInt$$this$call-putLong$$this$call-array$val-bytes$fun-sendFixtureIdentity", Byte.valueOf(f251Byte$2$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity));
            f257State$Byte$2$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).byteValue();
    }

    @LiveLiteralInfo(key = "Int$$this$call-toByte$3$vararg$arg-0$call-byteArrayOf$arg-0$call-put$$this$call-putInt$$this$call-putLong$$this$call-array$val-bytes$fun-sendFixtureIdentity", offset = 806)
    /* JADX INFO: renamed from: Int$$this$call-toByte$3$vararg$arg-0$call-byteArrayOf$arg-0$call-put$$this$call-putInt$$this$call-putLong$$this$call-array$val-bytes$fun-sendFixtureIdentity, reason: not valid java name */
    public final int m637Int$$this$calltoByte$3$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f252Int$$this$calltoByte$3$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity;
        }
        State<Integer> stateLiveLiteral = f258State$Int$$this$calltoByte$3$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$$this$call-toByte$3$vararg$arg-0$call-byteArrayOf$arg-0$call-put$$this$call-putInt$$this$call-putLong$$this$call-array$val-bytes$fun-sendFixtureIdentity", Integer.valueOf(f252Int$$this$calltoByte$3$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity));
            f258State$Int$$this$calltoByte$3$vararg$arg0$callbyteArrayOf$arg0$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-allocate$$this$call-order$$this$call-put$$this$call-putInt$$this$call-putLong$$this$call-array$val-bytes$fun-sendFixtureIdentity", offset = 735)
    /* JADX INFO: renamed from: Int$arg-0$call-allocate$$this$call-order$$this$call-put$$this$call-putInt$$this$call-putLong$$this$call-array$val-bytes$fun-sendFixtureIdentity, reason: not valid java name */
    public final int m638Int$arg0$callallocate$$this$callorder$$this$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f253Int$arg0$callallocate$$this$callorder$$this$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity;
        }
        State<Integer> stateLiveLiteral = f259State$Int$arg0$callallocate$$this$callorder$$this$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-allocate$$this$call-order$$this$call-put$$this$call-putInt$$this$call-putLong$$this$call-array$val-bytes$fun-sendFixtureIdentity", Integer.valueOf(f253Int$arg0$callallocate$$this$callorder$$this$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity));
            f259State$Int$arg0$callallocate$$this$callorder$$this$callput$$this$callputInt$$this$callputLong$$this$callarray$valbytes$funsendFixtureIdentity = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-showControlFixture", offset = 1107)
    /* JADX INFO: renamed from: Int$arg-1$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-showControlFixture, reason: not valid java name */
    public final int m639Int$arg1$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$funshowControlFixture() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f254Int$arg1$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$funshowControlFixture;
        }
        State<Integer> stateLiveLiteral = f260State$Int$arg1$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$funshowControlFixture;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-CarControlScreen$fun-$anonymous$$arg-3$call-MaterialTheme$fun-$anonymous$$arg-1$call-setContent$fun-showControlFixture", Integer.valueOf(f254Int$arg1$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$funshowControlFixture));
            f260State$Int$arg1$callCarControlScreen$fun$anonymous$$arg3$callMaterialTheme$fun$anonymous$$arg1$callsetContent$funshowControlFixture = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-setBody$arg-0$call-enqueue$fun-enqueueControlStatus", offset = 523)
    /* JADX INFO: renamed from: String$arg-0$call-setBody$arg-0$call-enqueue$fun-enqueueControlStatus, reason: not valid java name */
    public final String m640String$arg0$callsetBody$arg0$callenqueue$funenqueueControlStatus() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f262String$arg0$callsetBody$arg0$callenqueue$funenqueueControlStatus;
        }
        State<String> stateLiveLiteral = f261State$String$arg0$callsetBody$arg0$callenqueue$funenqueueControlStatus;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-setBody$arg-0$call-enqueue$fun-enqueueControlStatus", f262String$arg0$callsetBody$arg0$callenqueue$funenqueueControlStatus);
            f261State$String$arg0$callsetBody$arg0$callenqueue$funenqueueControlStatus = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }
}
