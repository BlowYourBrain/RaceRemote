package vea.raceremote;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: ExampleInstrumentedTest.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/androidTest/java/vea/raceremote/ExampleInstrumentedTest.kt")
public final class LiveLiterals$ExampleInstrumentedTestKt {

    /* JADX INFO: renamed from: Int$class-ExampleInstrumentedTest, reason: not valid java name */
    private static int f1089Int$classExampleInstrumentedTest;

    /* JADX INFO: renamed from: State$Int$class-ExampleInstrumentedTest, reason: not valid java name */
    private static State<Integer> f1090State$Int$classExampleInstrumentedTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-assertEquals$fun-useAppContext$class-ExampleInstrumentedTest, reason: not valid java name */
    private static State<String> f1091State$String$arg0$callassertEquals$funuseAppContext$classExampleInstrumentedTest;
    public static final LiveLiterals$ExampleInstrumentedTestKt INSTANCE = new LiveLiterals$ExampleInstrumentedTestKt();

    /* JADX INFO: renamed from: String$arg-0$call-assertEquals$fun-useAppContext$class-ExampleInstrumentedTest, reason: not valid java name */
    private static String f1092String$arg0$callassertEquals$funuseAppContext$classExampleInstrumentedTest = "vea.raceremote";

    @LiveLiteralInfo(key = "Int$class-ExampleInstrumentedTest", offset = -1)
    /* JADX INFO: renamed from: Int$class-ExampleInstrumentedTest, reason: not valid java name */
    public final int m1054Int$classExampleInstrumentedTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1089Int$classExampleInstrumentedTest;
        }
        State<Integer> stateLiveLiteral = f1090State$Int$classExampleInstrumentedTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-ExampleInstrumentedTest", Integer.valueOf(f1089Int$classExampleInstrumentedTest));
            f1090State$Int$classExampleInstrumentedTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-assertEquals$fun-useAppContext$class-ExampleInstrumentedTest", offset = 622)
    /* JADX INFO: renamed from: String$arg-0$call-assertEquals$fun-useAppContext$class-ExampleInstrumentedTest, reason: not valid java name */
    public final String m1055String$arg0$callassertEquals$funuseAppContext$classExampleInstrumentedTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1092String$arg0$callassertEquals$funuseAppContext$classExampleInstrumentedTest;
        }
        State<String> stateLiveLiteral = f1091State$String$arg0$callassertEquals$funuseAppContext$classExampleInstrumentedTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-assertEquals$fun-useAppContext$class-ExampleInstrumentedTest", f1092String$arg0$callassertEquals$funuseAppContext$classExampleInstrumentedTest);
            f1091State$String$arg0$callassertEquals$funuseAppContext$classExampleInstrumentedTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }
}
