package vea.raceremote;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: compiled from: VideoControlIsolationTest.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/Evgeny/orca/RaceRemote/app/src/androidTest/java/vea/raceremote/VideoControlIsolationTest.kt")
public final class LiveLiterals$VideoControlIsolationTestKt {

    /* JADX INFO: renamed from: Boolean$arg-0$call-response$arg-0$call-enqueue-2$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static boolean f1874Boolean$arg0$callresponse$arg0$callenqueue2$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: Int$arg-1$call-greater$fun-$anonymous$$arg-1$call-waitUntil-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static int f1895Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: Long$arg-2$call-$init$$$this$call-encode$0$vararg$arg-0$call-of$arg-0$call-send$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static long f1914Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: Long$arg-2$call-$init$$$this$call-encode$0$vararg$arg-0$call-of$arg-0$call-send$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static long f1915Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-response$arg-0$call-enqueue-1$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Boolean> f1916State$Boolean$arg0$callresponse$arg0$callenqueue1$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-response$arg-0$call-enqueue-2$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Boolean> f1917State$Boolean$arg0$callresponse$arg0$callenqueue2$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Boolean> f1918State$Boolean$arg1$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-4$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Boolean> f1919State$Boolean$arg1$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-assertTextContains-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Boolean> f1920State$Boolean$arg1$callassertTextContains1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Int$arg-0$call-assertEquals-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Integer> f1921State$Int$arg0$callassertEquals1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Int$arg-0$call-assertEquals-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Integer> f1922State$Int$arg0$callassertEquals2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Int$arg-0$call-createBitmap$val-bitmap$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Integer> f1923State$Int$arg0$callcreateBitmap$valbitmap$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Int$arg-0$call-plus$arg-0$call-throttleBody$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Integer> f1924State$Int$arg0$callplus$arg0$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Int$arg-0$call-plus$arg-1$call-greaterOrEqual$fun-$anonymous$$arg-1$call-waitUntil-3$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Integer> f1925State$Int$arg0$callplus$arg1$callgreaterOrEqual$fun$anonymous$$arg1$callwaitUntil3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Int$arg-0$call-plus$arg-1$call-greaterOrEqual$fun-$anonymous$$arg-1$call-waitUntil-3$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Integer> f1926State$Int$arg0$callplus$arg1$callgreaterOrEqual$fun$anonymous$$arg1$callwaitUntil3$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Int$arg-0$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Integer> f1927State$Int$arg0$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Int$arg-0$call-setResponseCode$arg-0$call-enqueue-1$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Integer> f1928State$Int$arg0$callsetResponseCode$arg0$callenqueue1$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Int$arg-0$call-start$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Integer> f1929State$Int$arg0$callstart$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Int$arg-0$call-start$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Integer> f1930State$Int$arg0$callstart$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$0$vararg$arg-1$call-format$branch$if$val-timestamp$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Integer> f1931State$Int$arg0$calltimes$0$vararg$arg1$callformat$branch$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Int$arg-0$call-times$0$vararg$arg-1$call-format$else$if$val-timestamp$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Integer> f1932State$Int$arg0$calltimes$0$vararg$arg1$callformat$else$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Int$arg-1$call-compress$fun-$anonymous$$arg-0$call-also$$this$call-toByteArray$val-jpeg$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Integer> f1933State$Int$arg1$callcompress$fun$anonymous$$arg0$callalso$$this$calltoByteArray$valjpeg$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Int$arg-1$call-createBitmap$val-bitmap$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Integer> f1934State$Int$arg1$callcreateBitmap$valbitmap$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Int$arg-1$call-greater$cond$cond$fun-isBlue$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Integer> f1935State$Int$arg1$callgreater$cond$cond$funisBlue$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Int$arg-1$call-greater$fun-$anonymous$$arg-1$call-waitUntil$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Integer> f1936State$Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Int$arg-1$call-greater$fun-$anonymous$$arg-1$call-waitUntil$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Integer> f1937State$Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Int$arg-1$call-greater$fun-$anonymous$$arg-1$call-waitUntil-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Integer> f1938State$Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Int$arg-1$call-less$branch$cond$fun-isBlue$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Integer> f1939State$Int$arg1$callless$branch$cond$funisBlue$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Int$arg-1$call-less$branch$fun-isBlue$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Integer> f1940State$Int$arg1$callless$branch$funisBlue$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Int$arg-1$call-minOf$$this$call-times$0$vararg$arg-1$call-format$branch$if$val-timestamp$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Integer> f1941State$Int$arg1$callminOf$$this$calltimes$0$vararg$arg1$callformat$branch$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Long$arg-0$call-sendFixtureIdentity$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Long> f1942State$Long$arg0$callsendFixtureIdentity$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Long$arg-0$call-sendFixtureIdentity$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Long> f1943State$Long$arg0$callsendFixtureIdentity$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Long$arg-0$call-waitUntil$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Long> f1944State$Long$arg0$callwaitUntil$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Long$arg-0$call-waitUntil$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Long> f1945State$Long$arg0$callwaitUntil$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Long$arg-0$call-waitUntil-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Long> f1946State$Long$arg0$callwaitUntil1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Long$arg-0$call-waitUntil-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Long> f1947State$Long$arg0$callwaitUntil1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Long$arg-0$call-waitUntil-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Long> f1948State$Long$arg0$callwaitUntil2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Long$arg-0$call-waitUntil-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Long> f1949State$Long$arg0$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Long$arg-0$call-waitUntil-3$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Long> f1950State$Long$arg0$callwaitUntil3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Long$arg-0$call-waitUntil-3$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Long> f1951State$Long$arg0$callwaitUntil3$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Long$arg-0$call-waitUntil-4$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Long> f1952State$Long$arg0$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Long$arg-0$call-waitUntil-5$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Long> f1953State$Long$arg0$callwaitUntil5$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Long$arg-1$call-$init$$$this$call-encode$0$vararg$arg-0$call-of$arg-0$call-send$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Long> f1954State$Long$arg1$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Long$arg-1$call-$init$$$this$call-encode$0$vararg$arg-0$call-of$arg-0$call-send$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Long> f1955State$Long$arg1$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Long$arg-1$call-throttleBody$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Long> f1956State$Long$arg1$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Long$arg-2$call-$init$$$this$call-encode$0$vararg$arg-0$call-of$arg-0$call-send$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Long> f1957State$Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$Long$arg-2$call-$init$$$this$call-encode$0$vararg$arg-0$call-of$arg-0$call-send$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<Long> f1958State$Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$$$this$call-format$branch$if$val-timestamp$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1959State$String$$$this$callformat$branch$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$$$this$call-format$else$if$val-timestamp$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1960State$String$$$this$callformat$else$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$0$str$$this$call-plus$arg-0$call-writeUtf8$$this$call-write$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1961State$String$0$str$$this$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-plus$arg-0$call-writeUtf8$$this$call-write$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1962State$String$0$str$arg0$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$0$str$arg-1$call-d$fun-centerPixel$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1963State$String$0$str$arg1$calld$funcenterPixel$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$2$str$$this$call-plus$arg-0$call-writeUtf8$$this$call-write$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1964State$String$2$str$$this$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$2$str$arg-0$call-plus$arg-0$call-writeUtf8$$this$call-write$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1965State$String$2$str$arg0$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$4$str$arg-0$call-plus$arg-0$call-writeUtf8$$this$call-write$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1966State$String$4$str$arg0$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-assertEquals$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1967State$String$arg0$callassertEquals$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1968State$String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1969State$String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-4$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1970State$String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-assertTextContains$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1971State$String$arg0$callassertTextContains$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-assertTextContains$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1972State$String$arg0$callassertTextContains$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-assertTextContains-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1973State$String$arg0$callassertTextContains1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-assertTextContains-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1974State$String$arg0$callassertTextContains1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-assertTextContains-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1975State$String$arg0$callassertTextContains2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-assertTextContains-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1976State$String$arg0$callassertTextContains2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-assertTextContains-3$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1977State$String$arg0$callassertTextContains3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-d$fun-centerPixel$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1978State$String$arg0$calld$funcenterPixel$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-assertIsEnabled$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1979State$String$arg0$callonNodeWithTag$$$this$callassertIsEnabled$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-assertIsEnabled$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1980State$String$arg0$callonNodeWithTag$$$this$callassertIsEnabled$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-assertIsEnabled-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1981State$String$arg0$callonNodeWithTag$$$this$callassertIsEnabled1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-assertIsEnabled-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1982State$String$arg0$callonNodeWithTag$$$this$callassertIsEnabled1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1983State$String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1984State$String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-4$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1985State$String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1986State$String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1987State$String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1988State$String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1989State$String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1990State$String$arg0$callonNodeWithTag$$$this$callassertTextContains2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1991State$String$arg0$callonNodeWithTag$$$this$callassertTextContains2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-3$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1992State$String$arg0$callonNodeWithTag$$$this$callassertTextContains3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-performClick$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1993State$String$arg0$callonNodeWithTag$$$this$callperformClick$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-performClick$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1994State$String$arg0$callonNodeWithTag$$$this$callperformClick$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-performClick-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1995State$String$arg0$callonNodeWithTag$$$this$callperformClick1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-performClick-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1996State$String$arg0$callonNodeWithTag$$$this$callperformClick1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-performClick-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1997State$String$arg0$callonNodeWithTag$$$this$callperformClick2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-performClick-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1998State$String$arg0$callonNodeWithTag$$$this$callperformClick2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-performClick-3$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f1999State$String$arg0$callonNodeWithTag$$$this$callperformClick3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-performTextReplacement$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f2000State$String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-performTextReplacement$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f2001State$String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-performTextReplacement-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f2002State$String$arg0$callonNodeWithTag$$$this$callperformTextReplacement1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$$this$call-performTextReplacement-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f2003State$String$arg0$callonNodeWithTag$$$this$callperformTextReplacement1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-onNodeWithTag$$this$call-fetchSemanticsNode$$this$call-$get-boundsInWindow$$$this$call-$get-center$$val-center$fun-centerPixel$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f2004State$String$arg0$callonNodeWithTag$$this$callfetchSemanticsNode$$this$call$getboundsInWindow$$$this$call$getcenter$$valcenter$funcenterPixel$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-performTextReplacement$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f2005State$String$arg0$callperformTextReplacement$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-performTextReplacement$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f2006State$String$arg0$callperformTextReplacement$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-setHeader$$this$call-setBody$$this$call-throttleBody$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f2007State$String$arg0$callsetHeader$$this$callsetBody$$this$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-url$$this$call-toString$arg-0$call-performTextReplacement-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f2008State$String$arg0$callurl$$this$calltoString$arg0$callperformTextReplacement1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-0$call-url$$this$call-toString$arg-0$call-performTextReplacement-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f2009State$String$arg0$callurl$$this$calltoString$arg0$callperformTextReplacement1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;

    /* JADX INFO: renamed from: State$String$arg-1$call-setHeader$$this$call-setBody$$this$call-throttleBody$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static State<String> f2010State$String$arg1$callsetHeader$$this$callsetBody$$this$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
    public static final LiveLiterals$VideoControlIsolationTestKt INSTANCE = new LiveLiterals$VideoControlIsolationTestKt();

    /* JADX INFO: renamed from: Long$arg-0$call-sendFixtureIdentity$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static long f1899Long$arg0$callsendFixtureIdentity$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = 43;

    /* JADX INFO: renamed from: Long$arg-1$call-$init$$$this$call-encode$0$vararg$arg-0$call-of$arg-0$call-send$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static long f1911Long$arg1$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = 43;

    /* JADX INFO: renamed from: Int$arg-0$call-createBitmap$val-bitmap$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static int f1880Int$arg0$callcreateBitmap$valbitmap$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = 16;

    /* JADX INFO: renamed from: Int$arg-1$call-createBitmap$val-bitmap$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static int f1891Int$arg1$callcreateBitmap$valbitmap$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = 16;

    /* JADX INFO: renamed from: Int$arg-1$call-compress$fun-$anonymous$$arg-0$call-also$$this$call-toByteArray$val-jpeg$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static int f1890Int$arg1$callcompress$fun$anonymous$$arg0$callalso$$this$calltoByteArray$valjpeg$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = 80;

    /* JADX INFO: renamed from: Int$arg-0$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static int f1884Int$arg0$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = 80;

    /* JADX INFO: renamed from: String$$$this$call-format$branch$if$val-timestamp$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2011String$$$this$callformat$branch$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "9000.%06d";

    /* JADX INFO: renamed from: Int$arg-1$call-minOf$$this$call-times$0$vararg$arg-1$call-format$branch$if$val-timestamp$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static int f1898Int$arg1$callminOf$$this$calltimes$0$vararg$arg1$callformat$branch$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = 9;

    /* JADX INFO: renamed from: Int$arg-0$call-times$0$vararg$arg-1$call-format$branch$if$val-timestamp$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static int f1888Int$arg0$calltimes$0$vararg$arg1$callformat$branch$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = 1000;

    /* JADX INFO: renamed from: String$$$this$call-format$else$if$val-timestamp$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2012String$$$this$callformat$else$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "0.%06d";

    /* JADX INFO: renamed from: Int$arg-0$call-times$0$vararg$arg-1$call-format$else$if$val-timestamp$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static int f1889Int$arg0$calltimes$0$vararg$arg1$callformat$else$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = 1000;

    /* JADX INFO: renamed from: String$0$str$$this$call-plus$arg-0$call-writeUtf8$$this$call-write$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2013String$0$str$$this$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "\r\n--frame\r\nContent-Type: image/jpeg\r\nContent-Length: ";

    /* JADX INFO: renamed from: String$2$str$$this$call-plus$arg-0$call-writeUtf8$$this$call-write$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2016String$2$str$$this$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "\r\n";

    /* JADX INFO: renamed from: String$0$str$arg-0$call-plus$arg-0$call-writeUtf8$$this$call-write$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2014String$0$str$arg0$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "X-Sequence: ";

    /* JADX INFO: renamed from: String$2$str$arg-0$call-plus$arg-0$call-writeUtf8$$this$call-write$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2017String$2$str$arg0$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "\r\nX-Timestamp: ";

    /* JADX INFO: renamed from: String$4$str$arg-0$call-plus$arg-0$call-writeUtf8$$this$call-write$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2018String$4$str$arg0$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "\r\n\r\n";

    /* JADX INFO: renamed from: String$arg-0$call-setHeader$$this$call-setBody$$this$call-throttleBody$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2059String$arg0$callsetHeader$$this$callsetBody$$this$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "Content-Type";

    /* JADX INFO: renamed from: String$arg-1$call-setHeader$$this$call-setBody$$this$call-throttleBody$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2062String$arg1$callsetHeader$$this$callsetBody$$this$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "multipart/x-mixed-replace;boundary=frame";

    /* JADX INFO: renamed from: Int$arg-0$call-plus$arg-0$call-throttleBody$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static int f1881Int$arg0$callplus$arg0$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = 110;

    /* JADX INFO: renamed from: Long$arg-1$call-throttleBody$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static long f1913Long$arg1$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = 100;

    /* JADX INFO: renamed from: Boolean$arg-0$call-response$arg-0$call-enqueue-1$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static boolean f1873Boolean$arg0$callresponse$arg0$callenqueue1$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = true;

    /* JADX INFO: renamed from: Int$arg-0$call-start$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static int f1886Int$arg0$callstart$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = 1337;

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performTextReplacement$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2052String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "car_address";

    /* JADX INFO: renamed from: String$arg-0$call-performTextReplacement$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2057String$arg0$callperformTextReplacement$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "127.0.0.1";

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performClick$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2045String$arg0$callonNodeWithTag$$$this$callperformClick$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "show_video";

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performTextReplacement-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2054String$arg0$callonNodeWithTag$$$this$callperformTextReplacement1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "video_address";

    /* JADX INFO: renamed from: String$arg-0$call-url$$this$call-toString$arg-0$call-performTextReplacement-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2060String$arg0$callurl$$this$calltoString$arg0$callperformTextReplacement1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "/stream";

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performClick-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2047String$arg0$callonNodeWithTag$$$this$callperformClick1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "connect_car";

    /* JADX INFO: renamed from: Long$arg-0$call-waitUntil$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static long f1901Long$arg0$callwaitUntil$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = 5000;

    /* JADX INFO: renamed from: Int$arg-1$call-greater$fun-$anonymous$$arg-1$call-waitUntil$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static int f1893Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = 3;

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2038String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "connection_status";

    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2023String$arg0$callassertTextContains$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "Управление подключено";

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performClick-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2049String$arg0$callonNodeWithTag$$$this$callperformClick2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "toggle_video";

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$this$call-fetchSemanticsNode$$this$call-$get-boundsInWindow$$$this$call-$get-center$$val-center$fun-centerPixel$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2056String$arg0$callonNodeWithTag$$this$callfetchSemanticsNode$$this$call$getboundsInWindow$$$this$call$getcenter$$valcenter$funcenterPixel$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "video_image";

    /* JADX INFO: renamed from: String$arg-0$call-d$fun-centerPixel$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2030String$arg0$calld$funcenterPixel$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "RaceRemoteVideoTest";

    /* JADX INFO: renamed from: String$0$str$arg-1$call-d$fun-centerPixel$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2015String$0$str$arg1$calld$funcenterPixel$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "Video center pixel=";

    /* JADX INFO: renamed from: Int$arg-1$call-greater$cond$cond$fun-isBlue$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static int f1892Int$arg1$callgreater$cond$cond$funisBlue$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = 64;

    /* JADX INFO: renamed from: Int$arg-1$call-less$branch$cond$fun-isBlue$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static int f1896Int$arg1$callless$branch$cond$funisBlue$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = 32;

    /* JADX INFO: renamed from: Int$arg-1$call-less$branch$fun-isBlue$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static int f1897Int$arg1$callless$branch$funisBlue$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = 32;

    /* JADX INFO: renamed from: Long$arg-0$call-waitUntil-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static long f1903Long$arg0$callwaitUntil1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = 3000;

    /* JADX INFO: renamed from: Long$arg-0$call-waitUntil-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static long f1905Long$arg0$callwaitUntil2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = 5000;

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2035String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "video_status";

    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2020String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "Нет свежего видео";

    /* JADX INFO: renamed from: String$arg-0$call-assertEquals$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2019String$arg0$callassertEquals$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "Expired frame must be cleared";

    /* JADX INFO: renamed from: Long$arg-0$call-waitUntil-3$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static long f1907Long$arg0$callwaitUntil3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = 3000;

    /* JADX INFO: renamed from: Int$arg-0$call-plus$arg-1$call-greaterOrEqual$fun-$anonymous$$arg-1$call-waitUntil-3$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static int f1882Int$arg0$callplus$arg1$callgreaterOrEqual$fun$anonymous$$arg1$callwaitUntil3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = 3;

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2040String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "connection_status";

    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2025String$arg0$callassertTextContains1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "Управление подключено";

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertIsEnabled$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2031String$arg0$callonNodeWithTag$$$this$callassertIsEnabled$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "throttle";

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertIsEnabled-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2033String$arg0$callonNodeWithTag$$$this$callassertIsEnabled1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "steering";

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performClick-3$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2051String$arg0$callonNodeWithTag$$$this$callperformClick3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "toggle_video";

    /* JADX INFO: renamed from: Long$arg-0$call-waitUntil-4$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static long f1909Long$arg0$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = 5000;

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-4$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2037String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "video_status";

    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-4$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2022String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "Принято";

    /* JADX INFO: renamed from: Boolean$arg-1$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-4$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static boolean f1876Boolean$arg1$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = true;

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2042String$arg0$callonNodeWithTag$$$this$callassertTextContains2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "toggle_video";

    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2027String$arg0$callassertTextContains2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "Выключить";

    /* JADX INFO: renamed from: Long$arg-0$call-waitUntil-5$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static long f1910Long$arg0$callwaitUntil5$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = 3000;

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-3$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2044String$arg0$callonNodeWithTag$$$this$callassertTextContains3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "connection_status";

    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains-3$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2029String$arg0$callassertTextContains3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = "Управление подключено";

    /* JADX INFO: renamed from: Int$arg-0$call-assertEquals-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static int f1878Int$arg0$callassertEquals1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = 2;

    /* JADX INFO: renamed from: Int$arg-0$call-assertEquals-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    private static int f1879Int$arg0$callassertEquals2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = 2;

    /* JADX INFO: renamed from: Long$arg-0$call-sendFixtureIdentity$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static long f1900Long$arg0$callsendFixtureIdentity$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = 42;

    /* JADX INFO: renamed from: Long$arg-1$call-$init$$$this$call-encode$0$vararg$arg-0$call-of$arg-0$call-send$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static long f1912Long$arg1$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = 42;

    /* JADX INFO: renamed from: Int$arg-0$call-setResponseCode$arg-0$call-enqueue-1$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static int f1885Int$arg0$callsetResponseCode$arg0$callenqueue1$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = 503;

    /* JADX INFO: renamed from: Int$arg-0$call-start$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static int f1887Int$arg0$callstart$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = 1337;

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performTextReplacement$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2053String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = "car_address";

    /* JADX INFO: renamed from: String$arg-0$call-performTextReplacement$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2058String$arg0$callperformTextReplacement$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = "127.0.0.1";

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performClick$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2046String$arg0$callonNodeWithTag$$$this$callperformClick$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = "connect_car";

    /* JADX INFO: renamed from: Long$arg-0$call-waitUntil$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static long f1902Long$arg0$callwaitUntil$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = 5000;

    /* JADX INFO: renamed from: Int$arg-1$call-greater$fun-$anonymous$$arg-1$call-waitUntil$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static int f1894Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = 3;

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performClick-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2048String$arg0$callonNodeWithTag$$$this$callperformClick1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = "show_video";

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performTextReplacement-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2055String$arg0$callonNodeWithTag$$$this$callperformTextReplacement1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = "video_address";

    /* JADX INFO: renamed from: String$arg-0$call-url$$this$call-toString$arg-0$call-performTextReplacement-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2061String$arg0$callurl$$this$calltoString$arg0$callperformTextReplacement1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = "/stream";

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performClick-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2050String$arg0$callonNodeWithTag$$$this$callperformClick2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = "toggle_video";

    /* JADX INFO: renamed from: Long$arg-0$call-waitUntil-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static long f1904Long$arg0$callwaitUntil1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = 5000;

    /* JADX INFO: renamed from: Long$arg-0$call-waitUntil-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static long f1906Long$arg0$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = 5000;

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2036String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = "video_status";

    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2021String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = "Видео недоступно";

    /* JADX INFO: renamed from: Boolean$arg-1$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static boolean f1875Boolean$arg1$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = true;

    /* JADX INFO: renamed from: Long$arg-0$call-waitUntil-3$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static long f1908Long$arg0$callwaitUntil3$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = 3000;

    /* JADX INFO: renamed from: Int$arg-0$call-plus$arg-1$call-greaterOrEqual$fun-$anonymous$$arg-1$call-waitUntil-3$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static int f1883Int$arg0$callplus$arg1$callgreaterOrEqual$fun$anonymous$$arg1$callwaitUntil3$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = 3;

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2039String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = "connection_status";

    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2024String$arg0$callassertTextContains$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = "Управление подключено";

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertIsEnabled$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2032String$arg0$callonNodeWithTag$$$this$callassertIsEnabled$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = "throttle";

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertIsEnabled-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2034String$arg0$callonNodeWithTag$$$this$callassertIsEnabled1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = "steering";

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2041String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = "connection_status";

    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2026String$arg0$callassertTextContains1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = "остановлено";

    /* JADX INFO: renamed from: Boolean$arg-1$call-assertTextContains-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static boolean f1877Boolean$arg1$callassertTextContains1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = true;

    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2043String$arg0$callonNodeWithTag$$$this$callassertTextContains2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = "video_status";

    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    private static String f2028String$arg0$callassertTextContains2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = "Видео выключено";

    @LiveLiteralInfo(key = "Boolean$arg-0$call-response$arg-0$call-enqueue-1$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 3232)
    /* JADX INFO: renamed from: Boolean$arg-0$call-response$arg-0$call-enqueue-1$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final boolean m1446Boolean$arg0$callresponse$arg0$callenqueue1$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1873Boolean$arg0$callresponse$arg0$callenqueue1$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Boolean> stateLiveLiteral = f1916State$Boolean$arg0$callresponse$arg0$callenqueue1$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-response$arg-0$call-enqueue-1$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Boolean.valueOf(f1873Boolean$arg0$callresponse$arg0$callenqueue1$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1916State$Boolean$arg0$callresponse$arg0$callenqueue1$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-response$arg-0$call-enqueue-2$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 3281)
    /* JADX INFO: renamed from: Boolean$arg-0$call-response$arg-0$call-enqueue-2$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final boolean m1447Boolean$arg0$callresponse$arg0$callenqueue2$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1874Boolean$arg0$callresponse$arg0$callenqueue2$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Boolean> stateLiveLiteral = f1917State$Boolean$arg0$callresponse$arg0$callenqueue2$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-response$arg-0$call-enqueue-2$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Boolean.valueOf(f1874Boolean$arg0$callresponse$arg0$callenqueue2$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1917State$Boolean$arg0$callresponse$arg0$callenqueue2$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 8254)
    /* JADX INFO: renamed from: Boolean$arg-1$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final boolean m1448Boolean$arg1$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1875Boolean$arg1$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<Boolean> stateLiveLiteral = f1918State$Boolean$arg1$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", Boolean.valueOf(f1875Boolean$arg1$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest));
            f1918State$Boolean$arg1$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-4$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 5863)
    /* JADX INFO: renamed from: Boolean$arg-1$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-4$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final boolean m1449Boolean$arg1$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1876Boolean$arg1$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Boolean> stateLiveLiteral = f1919State$Boolean$arg1$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-4$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Boolean.valueOf(f1876Boolean$arg1$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1919State$Boolean$arg1$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-assertTextContains-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 8889)
    /* JADX INFO: renamed from: Boolean$arg-1$call-assertTextContains-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final boolean m1450Boolean$arg1$callassertTextContains1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1877Boolean$arg1$callassertTextContains1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<Boolean> stateLiveLiteral = f1920State$Boolean$arg1$callassertTextContains1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-assertTextContains-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", Boolean.valueOf(f1877Boolean$arg1$callassertTextContains1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest));
            f1920State$Boolean$arg1$callassertTextContains1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-assertEquals-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 6180)
    /* JADX INFO: renamed from: Int$arg-0$call-assertEquals-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final int m1451Int$arg0$callassertEquals1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1878Int$arg0$callassertEquals1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Integer> stateLiveLiteral = f1921State$Int$arg0$callassertEquals1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-assertEquals-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Integer.valueOf(f1878Int$arg0$callassertEquals1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1921State$Int$arg0$callassertEquals1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-assertEquals-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 6245)
    /* JADX INFO: renamed from: Int$arg-0$call-assertEquals-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final int m1452Int$arg0$callassertEquals2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1879Int$arg0$callassertEquals2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Integer> stateLiveLiteral = f1922State$Int$arg0$callassertEquals2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-assertEquals-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Integer.valueOf(f1879Int$arg0$callassertEquals2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1922State$Int$arg0$callassertEquals2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-createBitmap$val-bitmap$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 2046)
    /* JADX INFO: renamed from: Int$arg-0$call-createBitmap$val-bitmap$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final int m1453Int$arg0$callcreateBitmap$valbitmap$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1880Int$arg0$callcreateBitmap$valbitmap$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Integer> stateLiveLiteral = f1923State$Int$arg0$callcreateBitmap$valbitmap$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-createBitmap$val-bitmap$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Integer.valueOf(f1880Int$arg0$callcreateBitmap$valbitmap$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1923State$Int$arg0$callcreateBitmap$valbitmap$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-plus$arg-0$call-throttleBody$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 3147)
    /* JADX INFO: renamed from: Int$arg-0$call-plus$arg-0$call-throttleBody$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final int m1454Int$arg0$callplus$arg0$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1881Int$arg0$callplus$arg0$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Integer> stateLiveLiteral = f1924State$Int$arg0$callplus$arg0$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-plus$arg-0$call-throttleBody$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Integer.valueOf(f1881Int$arg0$callplus$arg0$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1924State$Int$arg0$callplus$arg0$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-plus$arg-1$call-greaterOrEqual$fun-$anonymous$$arg-1$call-waitUntil-3$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 5419)
    /* JADX INFO: renamed from: Int$arg-0$call-plus$arg-1$call-greaterOrEqual$fun-$anonymous$$arg-1$call-waitUntil-3$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final int m1455Int$arg0$callplus$arg1$callgreaterOrEqual$fun$anonymous$$arg1$callwaitUntil3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1882Int$arg0$callplus$arg1$callgreaterOrEqual$fun$anonymous$$arg1$callwaitUntil3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Integer> stateLiveLiteral = f1925State$Int$arg0$callplus$arg1$callgreaterOrEqual$fun$anonymous$$arg1$callwaitUntil3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-plus$arg-1$call-greaterOrEqual$fun-$anonymous$$arg-1$call-waitUntil-3$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Integer.valueOf(f1882Int$arg0$callplus$arg1$callgreaterOrEqual$fun$anonymous$$arg1$callwaitUntil3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1925State$Int$arg0$callplus$arg1$callgreaterOrEqual$fun$anonymous$$arg1$callwaitUntil3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-plus$arg-1$call-greaterOrEqual$fun-$anonymous$$arg-1$call-waitUntil-3$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 8399)
    /* JADX INFO: renamed from: Int$arg-0$call-plus$arg-1$call-greaterOrEqual$fun-$anonymous$$arg-1$call-waitUntil-3$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final int m1456Int$arg0$callplus$arg1$callgreaterOrEqual$fun$anonymous$$arg1$callwaitUntil3$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1883Int$arg0$callplus$arg1$callgreaterOrEqual$fun$anonymous$$arg1$callwaitUntil3$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<Integer> stateLiveLiteral = f1926State$Int$arg0$callplus$arg1$callgreaterOrEqual$fun$anonymous$$arg1$callwaitUntil3$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-plus$arg-1$call-greaterOrEqual$fun-$anonymous$$arg-1$call-waitUntil-3$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", Integer.valueOf(f1883Int$arg0$callplus$arg1$callgreaterOrEqual$fun$anonymous$$arg1$callwaitUntil3$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest));
            f1926State$Int$arg0$callplus$arg1$callgreaterOrEqual$fun$anonymous$$arg1$callwaitUntil3$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 2384)
    /* JADX INFO: renamed from: Int$arg-0$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final int m1457Int$arg0$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1884Int$arg0$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Integer> stateLiveLiteral = f1927State$Int$arg0$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Integer.valueOf(f1884Int$arg0$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1927State$Int$arg0$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-setResponseCode$arg-0$call-enqueue-1$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 7454)
    /* JADX INFO: renamed from: Int$arg-0$call-setResponseCode$arg-0$call-enqueue-1$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final int m1458Int$arg0$callsetResponseCode$arg0$callenqueue1$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1885Int$arg0$callsetResponseCode$arg0$callenqueue1$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<Integer> stateLiveLiteral = f1928State$Int$arg0$callsetResponseCode$arg0$callenqueue1$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-setResponseCode$arg-0$call-enqueue-1$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", Integer.valueOf(f1885Int$arg0$callsetResponseCode$arg0$callenqueue1$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest));
            f1928State$Int$arg0$callsetResponseCode$arg0$callenqueue1$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-start$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 3311)
    /* JADX INFO: renamed from: Int$arg-0$call-start$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final int m1459Int$arg0$callstart$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1886Int$arg0$callstart$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Integer> stateLiveLiteral = f1929State$Int$arg0$callstart$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-start$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Integer.valueOf(f1886Int$arg0$callstart$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1929State$Int$arg0$callstart$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-start$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 7482)
    /* JADX INFO: renamed from: Int$arg-0$call-start$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final int m1460Int$arg0$callstart$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1887Int$arg0$callstart$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<Integer> stateLiveLiteral = f1930State$Int$arg0$callstart$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-start$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", Integer.valueOf(f1887Int$arg0$callstart$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest));
            f1930State$Int$arg0$callstart$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$0$vararg$arg-1$call-format$branch$if$val-timestamp$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 2680)
    /* JADX INFO: renamed from: Int$arg-0$call-times$0$vararg$arg-1$call-format$branch$if$val-timestamp$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final int m1461Int$arg0$calltimes$0$vararg$arg1$callformat$branch$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1888Int$arg0$calltimes$0$vararg$arg1$callformat$branch$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Integer> stateLiveLiteral = f1931State$Int$arg0$calltimes$0$vararg$arg1$callformat$branch$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$0$vararg$arg-1$call-format$branch$if$val-timestamp$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Integer.valueOf(f1888Int$arg0$calltimes$0$vararg$arg1$callformat$branch$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1931State$Int$arg0$calltimes$0$vararg$arg1$callformat$branch$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-0$call-times$0$vararg$arg-1$call-format$else$if$val-timestamp$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 2758)
    /* JADX INFO: renamed from: Int$arg-0$call-times$0$vararg$arg-1$call-format$else$if$val-timestamp$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final int m1462Int$arg0$calltimes$0$vararg$arg1$callformat$else$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1889Int$arg0$calltimes$0$vararg$arg1$callformat$else$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Integer> stateLiveLiteral = f1932State$Int$arg0$calltimes$0$vararg$arg1$callformat$else$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-0$call-times$0$vararg$arg-1$call-format$else$if$val-timestamp$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Integer.valueOf(f1889Int$arg0$calltimes$0$vararg$arg1$callformat$else$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1932State$Int$arg0$calltimes$0$vararg$arg1$callformat$else$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-compress$fun-$anonymous$$arg-0$call-also$$this$call-toByteArray$val-jpeg$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 2228)
    /* JADX INFO: renamed from: Int$arg-1$call-compress$fun-$anonymous$$arg-0$call-also$$this$call-toByteArray$val-jpeg$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final int m1463Int$arg1$callcompress$fun$anonymous$$arg0$callalso$$this$calltoByteArray$valjpeg$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1890Int$arg1$callcompress$fun$anonymous$$arg0$callalso$$this$calltoByteArray$valjpeg$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Integer> stateLiveLiteral = f1933State$Int$arg1$callcompress$fun$anonymous$$arg0$callalso$$this$calltoByteArray$valjpeg$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-compress$fun-$anonymous$$arg-0$call-also$$this$call-toByteArray$val-jpeg$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Integer.valueOf(f1890Int$arg1$callcompress$fun$anonymous$$arg0$callalso$$this$calltoByteArray$valjpeg$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1933State$Int$arg1$callcompress$fun$anonymous$$arg0$callalso$$this$calltoByteArray$valjpeg$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-createBitmap$val-bitmap$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 2050)
    /* JADX INFO: renamed from: Int$arg-1$call-createBitmap$val-bitmap$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final int m1464Int$arg1$callcreateBitmap$valbitmap$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1891Int$arg1$callcreateBitmap$valbitmap$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Integer> stateLiveLiteral = f1934State$Int$arg1$callcreateBitmap$valbitmap$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-createBitmap$val-bitmap$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Integer.valueOf(f1891Int$arg1$callcreateBitmap$valbitmap$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1934State$Int$arg1$callcreateBitmap$valbitmap$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-greater$cond$cond$fun-isBlue$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 4847)
    /* JADX INFO: renamed from: Int$arg-1$call-greater$cond$cond$fun-isBlue$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final int m1465Int$arg1$callgreater$cond$cond$funisBlue$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1892Int$arg1$callgreater$cond$cond$funisBlue$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Integer> stateLiveLiteral = f1935State$Int$arg1$callgreater$cond$cond$funisBlue$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-greater$cond$cond$fun-isBlue$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Integer.valueOf(f1892Int$arg1$callgreater$cond$cond$funisBlue$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1935State$Int$arg1$callgreater$cond$cond$funisBlue$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-greater$fun-$anonymous$$arg-1$call-waitUntil$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 3828)
    /* JADX INFO: renamed from: Int$arg-1$call-greater$fun-$anonymous$$arg-1$call-waitUntil$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final int m1466Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1893Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Integer> stateLiveLiteral = f1936State$Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-greater$fun-$anonymous$$arg-1$call-waitUntil$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Integer.valueOf(f1893Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1936State$Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-greater$fun-$anonymous$$arg-1$call-waitUntil$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 7795)
    /* JADX INFO: renamed from: Int$arg-1$call-greater$fun-$anonymous$$arg-1$call-waitUntil$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final int m1467Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1894Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<Integer> stateLiveLiteral = f1937State$Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-greater$fun-$anonymous$$arg-1$call-waitUntil$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", Integer.valueOf(f1894Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest));
            f1937State$Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-greater$fun-$anonymous$$arg-1$call-waitUntil-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 8093)
    /* JADX INFO: renamed from: Int$arg-1$call-greater$fun-$anonymous$$arg-1$call-waitUntil-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final int m1468Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1895Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<Integer> stateLiveLiteral = f1938State$Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-greater$fun-$anonymous$$arg-1$call-waitUntil-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", Integer.valueOf(f1895Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest));
            f1938State$Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-less$branch$cond$fun-isBlue$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 4905)
    /* JADX INFO: renamed from: Int$arg-1$call-less$branch$cond$fun-isBlue$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final int m1469Int$arg1$callless$branch$cond$funisBlue$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1896Int$arg1$callless$branch$cond$funisBlue$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Integer> stateLiveLiteral = f1939State$Int$arg1$callless$branch$cond$funisBlue$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-less$branch$cond$fun-isBlue$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Integer.valueOf(f1896Int$arg1$callless$branch$cond$funisBlue$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1939State$Int$arg1$callless$branch$cond$funisBlue$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-less$branch$fun-isBlue$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 4949)
    /* JADX INFO: renamed from: Int$arg-1$call-less$branch$fun-isBlue$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final int m1470Int$arg1$callless$branch$funisBlue$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1897Int$arg1$callless$branch$funisBlue$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Integer> stateLiveLiteral = f1940State$Int$arg1$callless$branch$funisBlue$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-less$branch$fun-isBlue$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Integer.valueOf(f1897Int$arg1$callless$branch$funisBlue$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1940State$Int$arg1$callless$branch$funisBlue$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-minOf$$this$call-times$0$vararg$arg-1$call-format$branch$if$val-timestamp$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 2675)
    /* JADX INFO: renamed from: Int$arg-1$call-minOf$$this$call-times$0$vararg$arg-1$call-format$branch$if$val-timestamp$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final int m1471Int$arg1$callminOf$$this$calltimes$0$vararg$arg1$callformat$branch$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1898Int$arg1$callminOf$$this$calltimes$0$vararg$arg1$callformat$branch$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Integer> stateLiveLiteral = f1941State$Int$arg1$callminOf$$this$calltimes$0$vararg$arg1$callformat$branch$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-minOf$$this$call-times$0$vararg$arg-1$call-format$branch$if$val-timestamp$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Integer.valueOf(f1898Int$arg1$callminOf$$this$calltimes$0$vararg$arg1$callformat$branch$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1941State$Int$arg1$callminOf$$this$calltimes$0$vararg$arg1$callformat$branch$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-sendFixtureIdentity$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 1476)
    /* JADX INFO: renamed from: Long$arg-0$call-sendFixtureIdentity$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final long m1472Long$arg0$callsendFixtureIdentity$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1899Long$arg0$callsendFixtureIdentity$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Long> stateLiveLiteral = f1942State$Long$arg0$callsendFixtureIdentity$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-sendFixtureIdentity$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Long.valueOf(f1899Long$arg0$callsendFixtureIdentity$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1942State$Long$arg0$callsendFixtureIdentity$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-sendFixtureIdentity$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 6912)
    /* JADX INFO: renamed from: Long$arg-0$call-sendFixtureIdentity$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final long m1473Long$arg0$callsendFixtureIdentity$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1900Long$arg0$callsendFixtureIdentity$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<Long> stateLiveLiteral = f1943State$Long$arg0$callsendFixtureIdentity$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-sendFixtureIdentity$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", Long.valueOf(f1900Long$arg0$callsendFixtureIdentity$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest));
            f1943State$Long$arg0$callsendFixtureIdentity$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-waitUntil$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 3805)
    /* JADX INFO: renamed from: Long$arg-0$call-waitUntil$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final long m1474Long$arg0$callwaitUntil$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1901Long$arg0$callwaitUntil$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Long> stateLiveLiteral = f1944State$Long$arg0$callwaitUntil$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-waitUntil$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Long.valueOf(f1901Long$arg0$callwaitUntil$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1944State$Long$arg0$callwaitUntil$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-waitUntil$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 7772)
    /* JADX INFO: renamed from: Long$arg-0$call-waitUntil$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final long m1475Long$arg0$callwaitUntil$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1902Long$arg0$callwaitUntil$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<Long> stateLiveLiteral = f1945State$Long$arg0$callwaitUntil$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-waitUntil$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", Long.valueOf(f1902Long$arg0$callwaitUntil$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest));
            f1945State$Long$arg0$callwaitUntil$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-waitUntil-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 4982)
    /* JADX INFO: renamed from: Long$arg-0$call-waitUntil-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final long m1476Long$arg0$callwaitUntil1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1903Long$arg0$callwaitUntil1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Long> stateLiveLiteral = f1946State$Long$arg0$callwaitUntil1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-waitUntil-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Long.valueOf(f1903Long$arg0$callwaitUntil1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1946State$Long$arg0$callwaitUntil1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-waitUntil-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 8064)
    /* JADX INFO: renamed from: Long$arg-0$call-waitUntil-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final long m1477Long$arg0$callwaitUntil1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1904Long$arg0$callwaitUntil1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<Long> stateLiveLiteral = f1947State$Long$arg0$callwaitUntil1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-waitUntil-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", Long.valueOf(f1904Long$arg0$callwaitUntil1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest));
            f1947State$Long$arg0$callwaitUntil1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-waitUntil-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 5044)
    /* JADX INFO: renamed from: Long$arg-0$call-waitUntil-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final long m1478Long$arg0$callwaitUntil2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1905Long$arg0$callwaitUntil2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Long> stateLiveLiteral = f1948State$Long$arg0$callwaitUntil2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-waitUntil-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Long.valueOf(f1905Long$arg0$callwaitUntil2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1948State$Long$arg0$callwaitUntil2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-waitUntil-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 8127)
    /* JADX INFO: renamed from: Long$arg-0$call-waitUntil-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final long m1479Long$arg0$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1906Long$arg0$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<Long> stateLiveLiteral = f1949State$Long$arg0$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-waitUntil-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", Long.valueOf(f1906Long$arg0$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest));
            f1949State$Long$arg0$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-waitUntil-3$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 5380)
    /* JADX INFO: renamed from: Long$arg-0$call-waitUntil-3$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final long m1480Long$arg0$callwaitUntil3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1907Long$arg0$callwaitUntil3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Long> stateLiveLiteral = f1950State$Long$arg0$callwaitUntil3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-waitUntil-3$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Long.valueOf(f1907Long$arg0$callwaitUntil3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1950State$Long$arg0$callwaitUntil3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-waitUntil-3$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 8360)
    /* JADX INFO: renamed from: Long$arg-0$call-waitUntil-3$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final long m1481Long$arg0$callwaitUntil3$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1908Long$arg0$callwaitUntil3$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<Long> stateLiveLiteral = f1951State$Long$arg0$callwaitUntil3$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-waitUntil-3$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", Long.valueOf(f1908Long$arg0$callwaitUntil3$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest));
            f1951State$Long$arg0$callwaitUntil3$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-waitUntil-4$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 5745)
    /* JADX INFO: renamed from: Long$arg-0$call-waitUntil-4$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final long m1482Long$arg0$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1909Long$arg0$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Long> stateLiveLiteral = f1952State$Long$arg0$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-waitUntil-4$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Long.valueOf(f1909Long$arg0$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1952State$Long$arg0$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-0$call-waitUntil-5$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 6007)
    /* JADX INFO: renamed from: Long$arg-0$call-waitUntil-5$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final long m1483Long$arg0$callwaitUntil5$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1910Long$arg0$callwaitUntil5$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Long> stateLiveLiteral = f1953State$Long$arg0$callwaitUntil5$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-0$call-waitUntil-5$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Long.valueOf(f1910Long$arg0$callwaitUntil5$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1953State$Long$arg0$callwaitUntil5$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-1$call-$init$$$this$call-encode$0$vararg$arg-0$call-of$arg-0$call-send$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 1561)
    /* JADX INFO: renamed from: Long$arg-1$call-$init$$$this$call-encode$0$vararg$arg-0$call-of$arg-0$call-send$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final long m1484Long$arg1$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1911Long$arg1$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Long> stateLiveLiteral = f1954State$Long$arg1$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-1$call-$init$$$this$call-encode$0$vararg$arg-0$call-of$arg-0$call-send$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Long.valueOf(f1911Long$arg1$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1954State$Long$arg1$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-1$call-$init$$$this$call-encode$0$vararg$arg-0$call-of$arg-0$call-send$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 6997)
    /* JADX INFO: renamed from: Long$arg-1$call-$init$$$this$call-encode$0$vararg$arg-0$call-of$arg-0$call-send$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final long m1485Long$arg1$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1912Long$arg1$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<Long> stateLiveLiteral = f1955State$Long$arg1$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-1$call-$init$$$this$call-encode$0$vararg$arg-0$call-of$arg-0$call-send$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", Long.valueOf(f1912Long$arg1$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest));
            f1955State$Long$arg1$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-1$call-throttleBody$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 3152)
    /* JADX INFO: renamed from: Long$arg-1$call-throttleBody$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final long m1486Long$arg1$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1913Long$arg1$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Long> stateLiveLiteral = f1956State$Long$arg1$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-1$call-throttleBody$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Long.valueOf(f1913Long$arg1$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1956State$Long$arg1$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-2$call-$init$$$this$call-encode$0$vararg$arg-0$call-of$arg-0$call-send$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 1565)
    /* JADX INFO: renamed from: Long$arg-2$call-$init$$$this$call-encode$0$vararg$arg-0$call-of$arg-0$call-send$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final long m1487Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1914Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<Long> stateLiveLiteral = f1957State$Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-2$call-$init$$$this$call-encode$0$vararg$arg-0$call-of$arg-0$call-send$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", Long.valueOf(f1914Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest));
            f1957State$Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-2$call-$init$$$this$call-encode$0$vararg$arg-0$call-of$arg-0$call-send$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 7001)
    /* JADX INFO: renamed from: Long$arg-2$call-$init$$$this$call-encode$0$vararg$arg-0$call-of$arg-0$call-send$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final long m1488Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f1915Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<Long> stateLiveLiteral = f1958State$Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-2$call-$init$$$this$call-encode$0$vararg$arg-0$call-of$arg-0$call-send$fun-onOpen$class-$no-name-provided$$arg-0$call-withWebSocketUpgrade$arg-0$call-enqueue$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", Long.valueOf(f1915Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest));
            f1958State$Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "String$$$this$call-format$branch$if$val-timestamp$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 2621)
    /* JADX INFO: renamed from: String$$$this$call-format$branch$if$val-timestamp$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1489String$$$this$callformat$branch$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2011String$$$this$callformat$branch$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1959State$String$$$this$callformat$branch$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$$$this$call-format$branch$if$val-timestamp$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2011String$$$this$callformat$branch$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1959State$String$$$this$callformat$branch$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$$$this$call-format$else$if$val-timestamp$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 2712)
    /* JADX INFO: renamed from: String$$$this$call-format$else$if$val-timestamp$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1490String$$$this$callformat$else$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2012String$$$this$callformat$else$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1960State$String$$$this$callformat$else$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$$$this$call-format$else$if$val-timestamp$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2012String$$$this$callformat$else$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1960State$String$$$this$callformat$else$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$$this$call-plus$arg-0$call-writeUtf8$$this$call-write$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 2796)
    /* JADX INFO: renamed from: String$0$str$$this$call-plus$arg-0$call-writeUtf8$$this$call-write$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1491String$0$str$$this$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2013String$0$str$$this$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1961State$String$0$str$$this$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$$this$call-plus$arg-0$call-writeUtf8$$this$call-write$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2013String$0$str$$this$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1961State$String$0$str$$this$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-plus$arg-0$call-writeUtf8$$this$call-write$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 2896)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-plus$arg-0$call-writeUtf8$$this$call-write$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1492String$0$str$arg0$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2014String$0$str$arg0$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1962State$String$0$str$arg0$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-plus$arg-0$call-writeUtf8$$this$call-write$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2014String$0$str$arg0$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1962State$String$0$str$arg0$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-1$call-d$fun-centerPixel$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 4517)
    /* JADX INFO: renamed from: String$0$str$arg-1$call-d$fun-centerPixel$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1493String$0$str$arg1$calld$funcenterPixel$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2015String$0$str$arg1$calld$funcenterPixel$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1963State$String$0$str$arg1$calld$funcenterPixel$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-1$call-d$fun-centerPixel$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2015String$0$str$arg1$calld$funcenterPixel$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1963State$String$0$str$arg1$calld$funcenterPixel$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$$this$call-plus$arg-0$call-writeUtf8$$this$call-write$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 2867)
    /* JADX INFO: renamed from: String$2$str$$this$call-plus$arg-0$call-writeUtf8$$this$call-write$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1494String$2$str$$this$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2016String$2$str$$this$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1964State$String$2$str$$this$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$$this$call-plus$arg-0$call-writeUtf8$$this$call-write$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2016String$2$str$$this$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1964State$String$2$str$$this$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$arg-0$call-plus$arg-0$call-writeUtf8$$this$call-write$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 2914)
    /* JADX INFO: renamed from: String$2$str$arg-0$call-plus$arg-0$call-writeUtf8$$this$call-write$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1495String$2$str$arg0$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2017String$2$str$arg0$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1965State$String$2$str$arg0$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$arg-0$call-plus$arg-0$call-writeUtf8$$this$call-write$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2017String$2$str$arg0$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1965State$String$2$str$arg0$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$4$str$arg-0$call-plus$arg-0$call-writeUtf8$$this$call-write$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 2941)
    /* JADX INFO: renamed from: String$4$str$arg-0$call-plus$arg-0$call-writeUtf8$$this$call-write$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1496String$4$str$arg0$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2018String$4$str$arg0$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1966State$String$4$str$arg0$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$4$str$arg-0$call-plus$arg-0$call-writeUtf8$$this$call-write$fun-$anonymous$$arg-1$call-repeat$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2018String$4$str$arg0$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1966State$String$4$str$arg0$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-assertEquals$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 5229)
    /* JADX INFO: renamed from: String$arg-0$call-assertEquals$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1497String$arg0$callassertEquals$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2019String$arg0$callassertEquals$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1967State$String$arg0$callassertEquals$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-assertEquals$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2019String$arg0$callassertEquals$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1967State$String$arg0$callassertEquals$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 5140)
    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1498String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2020String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1968State$String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2020String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1968State$String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 8223)
    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1499String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2021String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1969State$String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", f2021String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest);
            f1969State$String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-4$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 5841)
    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-4$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1500String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2022String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1970State$String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-4$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2022String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1970State$String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-assertTextContains$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 3907)
    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1501String$arg0$callassertTextContains$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2023String$arg0$callassertTextContains$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1971State$String$arg0$callassertTextContains$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-assertTextContains$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2023String$arg0$callassertTextContains$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1971State$String$arg0$callassertTextContains$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-assertTextContains$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 8478)
    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1502String$arg0$callassertTextContains$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2024String$arg0$callassertTextContains$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1972State$String$arg0$callassertTextContains$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-assertTextContains$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", f2024String$arg0$callassertTextContains$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest);
            f1972State$String$arg0$callassertTextContains$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-assertTextContains-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 5498)
    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1503String$arg0$callassertTextContains1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2025String$arg0$callassertTextContains1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1973State$String$arg0$callassertTextContains1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-assertTextContains-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2025String$arg0$callassertTextContains1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1973State$String$arg0$callassertTextContains1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-assertTextContains-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 8863)
    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1504String$arg0$callassertTextContains1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2026String$arg0$callassertTextContains1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1974State$String$arg0$callassertTextContains1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-assertTextContains-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", f2026String$arg0$callassertTextContains1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest);
            f1974State$String$arg0$callassertTextContains1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-assertTextContains-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 5965)
    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1505String$arg0$callassertTextContains2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2027String$arg0$callassertTextContains2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1975State$String$arg0$callassertTextContains2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-assertTextContains-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2027String$arg0$callassertTextContains2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1975State$String$arg0$callassertTextContains2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-assertTextContains-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 8965)
    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1506String$arg0$callassertTextContains2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2028String$arg0$callassertTextContains2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1976State$String$arg0$callassertTextContains2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-assertTextContains-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", f2028String$arg0$callassertTextContains2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest);
            f1976State$String$arg0$callassertTextContains2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-assertTextContains-3$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 6114)
    /* JADX INFO: renamed from: String$arg-0$call-assertTextContains-3$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1507String$arg0$callassertTextContains3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2029String$arg0$callassertTextContains3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1977State$String$arg0$callassertTextContains3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-assertTextContains-3$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2029String$arg0$callassertTextContains3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1977State$String$arg0$callassertTextContains3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-d$fun-centerPixel$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 4494)
    /* JADX INFO: renamed from: String$arg-0$call-d$fun-centerPixel$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1508String$arg0$calld$funcenterPixel$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2030String$arg0$calld$funcenterPixel$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1978State$String$arg0$calld$funcenterPixel$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-d$fun-centerPixel$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2030String$arg0$calld$funcenterPixel$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1978State$String$arg0$calld$funcenterPixel$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-assertIsEnabled$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 5557)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertIsEnabled$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1509String$arg0$callonNodeWithTag$$$this$callassertIsEnabled$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2031String$arg0$callonNodeWithTag$$$this$callassertIsEnabled$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1979State$String$arg0$callonNodeWithTag$$$this$callassertIsEnabled$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-assertIsEnabled$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2031String$arg0$callonNodeWithTag$$$this$callassertIsEnabled$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1979State$String$arg0$callonNodeWithTag$$$this$callassertIsEnabled$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-assertIsEnabled$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 8537)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertIsEnabled$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1510String$arg0$callonNodeWithTag$$$this$callassertIsEnabled$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2032String$arg0$callonNodeWithTag$$$this$callassertIsEnabled$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1980State$String$arg0$callonNodeWithTag$$$this$callassertIsEnabled$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-assertIsEnabled$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", f2032String$arg0$callonNodeWithTag$$$this$callassertIsEnabled$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest);
            f1980State$String$arg0$callonNodeWithTag$$$this$callassertIsEnabled$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-assertIsEnabled-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 5621)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertIsEnabled-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1511String$arg0$callonNodeWithTag$$$this$callassertIsEnabled1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2033String$arg0$callonNodeWithTag$$$this$callassertIsEnabled1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1981State$String$arg0$callonNodeWithTag$$$this$callassertIsEnabled1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-assertIsEnabled-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2033String$arg0$callonNodeWithTag$$$this$callassertIsEnabled1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1981State$String$arg0$callonNodeWithTag$$$this$callassertIsEnabled1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-assertIsEnabled-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 8601)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertIsEnabled-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1512String$arg0$callonNodeWithTag$$$this$callassertIsEnabled1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2034String$arg0$callonNodeWithTag$$$this$callassertIsEnabled1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1982State$String$arg0$callonNodeWithTag$$$this$callassertIsEnabled1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-assertIsEnabled-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", f2034String$arg0$callonNodeWithTag$$$this$callassertIsEnabled1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest);
            f1982State$String$arg0$callonNodeWithTag$$$this$callassertIsEnabled1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 5105)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1513String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2035String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1983State$String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2035String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1983State$String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 8188)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1514String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2036String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1984State$String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", f2036String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest);
            f1984State$String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-4$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 5806)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-4$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1515String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2037String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1985State$String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$fun-$anonymous$$arg-0$call-runCatching$$this$call-$get-isSuccess$$fun-$anonymous$$arg-1$call-waitUntil-4$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2037String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1985State$String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 3867)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1516String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2038String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1986State$String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2038String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1986State$String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 8438)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1517String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2039String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1987State$String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", f2039String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest);
            f1987State$String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 5458)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1518String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2040String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1988State$String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2040String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1988State$String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 8823)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1519String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2041String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1989State$String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", f2041String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest);
            f1989State$String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 5930)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1520String$arg0$callonNodeWithTag$$$this$callassertTextContains2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2042String$arg0$callonNodeWithTag$$$this$callassertTextContains2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1990State$String$arg0$callonNodeWithTag$$$this$callassertTextContains2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2042String$arg0$callonNodeWithTag$$$this$callassertTextContains2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1990State$String$arg0$callonNodeWithTag$$$this$callassertTextContains2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 8930)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1521String$arg0$callonNodeWithTag$$$this$callassertTextContains2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2043String$arg0$callonNodeWithTag$$$this$callassertTextContains2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1991State$String$arg0$callonNodeWithTag$$$this$callassertTextContains2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", f2043String$arg0$callonNodeWithTag$$$this$callassertTextContains2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest);
            f1991State$String$arg0$callonNodeWithTag$$$this$callassertTextContains2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-3$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 6074)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-3$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1522String$arg0$callonNodeWithTag$$$this$callassertTextContains3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2044String$arg0$callonNodeWithTag$$$this$callassertTextContains3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1992State$String$arg0$callonNodeWithTag$$$this$callassertTextContains3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-assertTextContains-3$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2044String$arg0$callonNodeWithTag$$$this$callassertTextContains3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1992State$String$arg0$callonNodeWithTag$$$this$callassertTextContains3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-performClick$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 3542)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performClick$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1523String$arg0$callonNodeWithTag$$$this$callperformClick$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2045String$arg0$callonNodeWithTag$$$this$callperformClick$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1993State$String$arg0$callonNodeWithTag$$$this$callperformClick$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-performClick$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2045String$arg0$callonNodeWithTag$$$this$callperformClick$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1993State$String$arg0$callonNodeWithTag$$$this$callperformClick$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-performClick$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 7713)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performClick$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1524String$arg0$callonNodeWithTag$$$this$callperformClick$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2046String$arg0$callonNodeWithTag$$$this$callperformClick$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1994State$String$arg0$callonNodeWithTag$$$this$callperformClick$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-performClick$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", f2046String$arg0$callonNodeWithTag$$$this$callperformClick$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest);
            f1994State$String$arg0$callonNodeWithTag$$$this$callperformClick$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-performClick-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 3746)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performClick-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1525String$arg0$callonNodeWithTag$$$this$callperformClick1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2047String$arg0$callonNodeWithTag$$$this$callperformClick1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1995State$String$arg0$callonNodeWithTag$$$this$callperformClick1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-performClick-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2047String$arg0$callonNodeWithTag$$$this$callperformClick1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1995State$String$arg0$callonNodeWithTag$$$this$callperformClick1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-performClick-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 7834)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performClick-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1526String$arg0$callonNodeWithTag$$$this$callperformClick1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2048String$arg0$callonNodeWithTag$$$this$callperformClick1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1996State$String$arg0$callonNodeWithTag$$$this$callperformClick1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-performClick-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", f2048String$arg0$callonNodeWithTag$$$this$callperformClick1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest);
            f1996State$String$arg0$callonNodeWithTag$$$this$callperformClick1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-performClick-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 3966)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performClick-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1527String$arg0$callonNodeWithTag$$$this$callperformClick2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2049String$arg0$callonNodeWithTag$$$this$callperformClick2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1997State$String$arg0$callonNodeWithTag$$$this$callperformClick2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-performClick-2$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2049String$arg0$callonNodeWithTag$$$this$callperformClick2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1997State$String$arg0$callonNodeWithTag$$$this$callperformClick2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-performClick-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 8004)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performClick-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1528String$arg0$callonNodeWithTag$$$this$callperformClick2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2050String$arg0$callonNodeWithTag$$$this$callperformClick2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1998State$String$arg0$callonNodeWithTag$$$this$callperformClick2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-performClick-2$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", f2050String$arg0$callonNodeWithTag$$$this$callperformClick2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest);
            f1998State$String$arg0$callonNodeWithTag$$$this$callperformClick2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-performClick-3$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 5685)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performClick-3$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1529String$arg0$callonNodeWithTag$$$this$callperformClick3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2051String$arg0$callonNodeWithTag$$$this$callperformClick3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f1999State$String$arg0$callonNodeWithTag$$$this$callperformClick3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-performClick-3$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2051String$arg0$callonNodeWithTag$$$this$callperformClick3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f1999State$String$arg0$callonNodeWithTag$$$this$callperformClick3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-performTextReplacement$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 3457)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performTextReplacement$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1530String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2052String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f2000State$String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-performTextReplacement$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2052String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f2000State$String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-performTextReplacement$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 7628)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performTextReplacement$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1531String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2053String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f2001State$String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-performTextReplacement$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", f2053String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest);
            f2001State$String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-performTextReplacement-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 3605)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performTextReplacement-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1532String$arg0$callonNodeWithTag$$$this$callperformTextReplacement1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2054String$arg0$callonNodeWithTag$$$this$callperformTextReplacement1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f2002State$String$arg0$callonNodeWithTag$$$this$callperformTextReplacement1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-performTextReplacement-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2054String$arg0$callonNodeWithTag$$$this$callperformTextReplacement1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f2002State$String$arg0$callonNodeWithTag$$$this$callperformTextReplacement1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$$this$call-performTextReplacement-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 7897)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$$this$call-performTextReplacement-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1533String$arg0$callonNodeWithTag$$$this$callperformTextReplacement1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2055String$arg0$callonNodeWithTag$$$this$callperformTextReplacement1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f2003State$String$arg0$callonNodeWithTag$$$this$callperformTextReplacement1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$$this$call-performTextReplacement-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", f2055String$arg0$callonNodeWithTag$$$this$callperformTextReplacement1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest);
            f2003State$String$arg0$callonNodeWithTag$$$this$callperformTextReplacement1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-onNodeWithTag$$this$call-fetchSemanticsNode$$this$call-$get-boundsInWindow$$$this$call-$get-center$$val-center$fun-centerPixel$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 4171)
    /* JADX INFO: renamed from: String$arg-0$call-onNodeWithTag$$this$call-fetchSemanticsNode$$this$call-$get-boundsInWindow$$$this$call-$get-center$$val-center$fun-centerPixel$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1534String$arg0$callonNodeWithTag$$this$callfetchSemanticsNode$$this$call$getboundsInWindow$$$this$call$getcenter$$valcenter$funcenterPixel$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2056String$arg0$callonNodeWithTag$$this$callfetchSemanticsNode$$this$call$getboundsInWindow$$$this$call$getcenter$$valcenter$funcenterPixel$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f2004State$String$arg0$callonNodeWithTag$$this$callfetchSemanticsNode$$this$call$getboundsInWindow$$$this$call$getcenter$$valcenter$funcenterPixel$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-onNodeWithTag$$this$call-fetchSemanticsNode$$this$call-$get-boundsInWindow$$$this$call-$get-center$$val-center$fun-centerPixel$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2056String$arg0$callonNodeWithTag$$this$callfetchSemanticsNode$$this$call$getboundsInWindow$$$this$call$getcenter$$valcenter$funcenterPixel$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f2004State$String$arg0$callonNodeWithTag$$this$callfetchSemanticsNode$$this$call$getboundsInWindow$$$this$call$getcenter$$valcenter$funcenterPixel$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-performTextReplacement$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 3495)
    /* JADX INFO: renamed from: String$arg-0$call-performTextReplacement$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1535String$arg0$callperformTextReplacement$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2057String$arg0$callperformTextReplacement$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f2005State$String$arg0$callperformTextReplacement$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-performTextReplacement$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2057String$arg0$callperformTextReplacement$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f2005State$String$arg0$callperformTextReplacement$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-performTextReplacement$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 7666)
    /* JADX INFO: renamed from: String$arg-0$call-performTextReplacement$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1536String$arg0$callperformTextReplacement$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2058String$arg0$callperformTextReplacement$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f2006State$String$arg0$callperformTextReplacement$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-performTextReplacement$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", f2058String$arg0$callperformTextReplacement$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest);
            f2006State$String$arg0$callperformTextReplacement$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-setHeader$$this$call-setBody$$this$call-throttleBody$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 3023)
    /* JADX INFO: renamed from: String$arg-0$call-setHeader$$this$call-setBody$$this$call-throttleBody$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1537String$arg0$callsetHeader$$this$callsetBody$$this$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2059String$arg0$callsetHeader$$this$callsetBody$$this$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f2007State$String$arg0$callsetHeader$$this$callsetBody$$this$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-setHeader$$this$call-setBody$$this$call-throttleBody$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2059String$arg0$callsetHeader$$this$callsetBody$$this$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f2007State$String$arg0$callsetHeader$$this$callsetBody$$this$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-url$$this$call-toString$arg-0$call-performTextReplacement-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 3655)
    /* JADX INFO: renamed from: String$arg-0$call-url$$this$call-toString$arg-0$call-performTextReplacement-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1538String$arg0$callurl$$this$calltoString$arg0$callperformTextReplacement1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2060String$arg0$callurl$$this$calltoString$arg0$callperformTextReplacement1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f2008State$String$arg0$callurl$$this$calltoString$arg0$callperformTextReplacement1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-url$$this$call-toString$arg-0$call-performTextReplacement-1$try$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2060String$arg0$callurl$$this$calltoString$arg0$callperformTextReplacement1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f2008State$String$arg0$callurl$$this$calltoString$arg0$callperformTextReplacement1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-url$$this$call-toString$arg-0$call-performTextReplacement-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", offset = 7947)
    /* JADX INFO: renamed from: String$arg-0$call-url$$this$call-toString$arg-0$call-performTextReplacement-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1539String$arg0$callurl$$this$calltoString$arg0$callperformTextReplacement1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2061String$arg0$callurl$$this$calltoString$arg0$callperformTextReplacement1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f2009State$String$arg0$callurl$$this$calltoString$arg0$callperformTextReplacement1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-url$$this$call-toString$arg-0$call-performTextReplacement-1$try$fun-unavailableVideoDoesNotStopControlAndBackgroundStopsBoth$class-VideoControlIsolationTest", f2061String$arg0$callurl$$this$calltoString$arg0$callperformTextReplacement1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest);
            f2009State$String$arg0$callurl$$this$calltoString$arg0$callperformTextReplacement1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-1$call-setHeader$$this$call-setBody$$this$call-throttleBody$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", offset = 3039)
    /* JADX INFO: renamed from: String$arg-1$call-setHeader$$this$call-setBody$$this$call-throttleBody$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest, reason: not valid java name */
    public final String m1540String$arg1$callsetHeader$$this$callsetBody$$this$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f2062String$arg1$callsetHeader$$this$callsetBody$$this$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        }
        State<String> stateLiveLiteral = f2010State$String$arg1$callsetHeader$$this$callsetBody$$this$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-1$call-setHeader$$this$call-setBody$$this$call-throttleBody$fun-response$fun-repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$class-VideoControlIsolationTest", f2062String$arg1$callsetHeader$$this$callsetBody$$this$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest);
            f2010State$String$arg1$callsetHeader$$this$callsetBody$$this$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }
}
