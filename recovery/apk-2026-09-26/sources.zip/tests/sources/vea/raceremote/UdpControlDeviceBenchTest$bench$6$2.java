package vea.raceremote;

import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;
import org.json.JSONObject;

/* JADX INFO: compiled from: UdpControlDeviceBenchTest.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
/* synthetic */ class UdpControlDeviceBenchTest$bench$6$2 extends FunctionReferenceImpl implements Function1<JSONObject, Boolean> {
    public static final UdpControlDeviceBenchTest$bench$6$2 INSTANCE = new UdpControlDeviceBenchTest$bench$6$2();

    UdpControlDeviceBenchTest$bench$6$2() {
        super(1, Intrinsics.Kotlin.class, "neutral", "bench$neutral(Lorg/json/JSONObject;)Z", 0);
    }

    public final Boolean invoke(JSONObject p0) {
        Intrinsics.checkNotNullParameter(p0, "p0");
        return Boolean.valueOf(UdpControlDeviceBenchTest.bench$neutral(p0));
    }
}
