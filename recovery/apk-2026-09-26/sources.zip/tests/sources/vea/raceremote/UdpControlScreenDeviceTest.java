package vea.raceremote;

import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import androidx.compose.ui.geometry.Offset;
import androidx.compose.ui.geometry.OffsetKt;
import androidx.compose.ui.geometry.Rect;
import androidx.compose.ui.test.ActionsKt;
import androidx.compose.ui.test.AssertionsKt;
import androidx.compose.ui.test.FindersKt;
import androidx.compose.ui.test.SemanticsNodeInteraction;
import androidx.compose.ui.test.TextActionsKt;
import androidx.compose.ui.test.TouchInjectionScope;
import androidx.compose.ui.test.junit4.AndroidComposeTestRule;
import androidx.compose.ui.test.junit4.AndroidComposeTestRule_androidKt;
import androidx.lifecycle.Lifecycle;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Collection;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.IntIterator;
import kotlin.io.CloseableKt;
import kotlin.io.FilesKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Assume;
import org.junit.Rule;
import org.junit.Test;
import vea.raceremote.app.MainActivity;

/* JADX INFO: compiled from: UdpControlScreenDeviceTest.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\t\u001a\u00020\nH\u0007R%\u0010\u0003\u001a\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0004\u0012\u00020\u00060\u00048G¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b¨\u0006\u000b"}, d2 = {"Lvea/raceremote/UdpControlScreenDeviceTest;", "", "()V", "compose", "Landroidx/compose/ui/test/junit4/AndroidComposeTestRule;", "Landroidx/test/ext/junit/rules/ActivityScenarioRule;", "Lvea/raceremote/app/MainActivity;", "getCompose", "()Landroidx/compose/ui/test/junit4/AndroidComposeTestRule;", "controlsVideoFailureBackgroundStopAndExplicitReconnect", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class UdpControlScreenDeviceTest {
    public static final int $stable = AndroidComposeTestRule.$stable;
    private final AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity> compose = AndroidComposeTestRule_androidKt.createAndroidComposeRule(MainActivity.class);

    @Rule
    public final AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity> getCompose() {
        return this.compose;
    }

    @Test
    public final void controlsVideoFailureBackgroundStopAndExplicitReconnect() throws JSONException, IOException {
        Object element$iv;
        boolean complete;
        JSONArray events;
        final MainActivity context;
        MockWebServer video;
        long started;
        File file;
        String string;
        Bundle args = InstrumentationRegistry.getArguments();
        Assume.assumeTrue(Intrinsics.areEqual(args.getString(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1325String$arg0$callgetString$arg0$callEQEQ$arg0$callassumeTrue$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()), LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1367String$arg1$callEQEQ$arg0$callassumeTrue$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()));
        String host = args.getString(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1327String$arg0$callgetString$arg0$callrequireNotNull$valhost$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest());
        if (host == null) {
            throw new IllegalArgumentException("Required value was null.".toString());
        }
        Intrinsics.checkNotNullExpressionValue(host, "requireNotNull(args.getString(\"driveBenchHost\"))");
        String expectedCar = args.getString(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1326String$arg0$callgetString$arg0$callrequireNotNull$valexpectedCar$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest());
        if (expectedCar == null) {
            throw new IllegalArgumentException("Required value was null.".toString());
        }
        Intrinsics.checkNotNullExpressionValue(expectedCar, "requireNotNull(args.getString(\"driveBenchCarId\"))");
        MainActivity context2 = getActivity();
        ConnectivityManager cm = (ConnectivityManager) context2.getSystemService(ConnectivityManager.class);
        Object[] allNetworks = cm.getAllNetworks();
        Intrinsics.checkNotNullExpressionValue(allNetworks, "cm.allNetworks");
        Object[] $this$firstOrNull$iv = allNetworks;
        int length = $this$firstOrNull$iv.length;
        int i = 0;
        while (true) {
            if (i >= length) {
                element$iv = null;
                break;
            }
            element$iv = $this$firstOrNull$iv[i];
            Network it = (Network) element$iv;
            NetworkCapabilities networkCapabilities = cm.getNetworkCapabilities(it);
            if (networkCapabilities != null && networkCapabilities.hasTransport(1) == LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1240Boolean$arg1$callEQEQ$fun$anonymous$$arg0$callfirstOrNull$arg0$callrequireNotNull$valwifi$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()) {
                break;
            } else {
                i++;
            }
        }
        if (element$iv == null) {
            throw new IllegalArgumentException("Required value was null.".toString());
        }
        Network wifi = (Network) element$iv;
        OkHttpClient http = new OkHttpClient.Builder().socketFactory(wifi.getSocketFactory()).connectTimeout(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1282Long$arg0$callconnectTimeout$$this$callreadTimeout$$this$callcallTimeout$$this$callbuild$valhttp$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), TimeUnit.SECONDS).readTimeout(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1283Long$arg0$callreadTimeout$$this$callcallTimeout$$this$callbuild$valhttp$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), TimeUnit.SECONDS).callTimeout(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1281Long$arg0$callcallTimeout$$this$callbuild$valhttp$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), TimeUnit.SECONDS).build();
        JSONArray events2 = new JSONArray();
        long started2 = SystemClock.elapsedRealtime();
        boolean complete2 = LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1246Boolean$valcomplete$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest();
        MockWebServer video2 = new MockWebServer();
        video2.enqueue(new MockResponse().setResponseCode(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1261Int$arg0$callsetResponseCode$arg0$callenqueue$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()));
        video2.start();
        try {
            Assert.assertTrue(controlsVideoFailureBackgroundStopAndExplicitReconnect$neutral(controlsVideoFailureBackgroundStopAndExplicitReconnect$status(http, host, expectedCar, events2, started2)));
            TextActionsKt.performTextReplacement(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1344String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, 2, null), host);
            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1337String$arg0$callonNodeWithTag$$$this$callperformClick$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, 2, null));
            controlsVideoFailureBackgroundStopAndExplicitReconnect$connected(this);
            complete = complete2;
            context = context2;
            try {
                controlsVideoFailureBackgroundStopAndExplicitReconnect$awaitStatus(http, host, expectedCar, events2, started2, new Function1<JSONObject, Boolean>() { // from class: vea.raceremote.UdpControlScreenDeviceTest.controlsVideoFailureBackgroundStopAndExplicitReconnect.1
                    public final Boolean invoke(JSONObject it2) {
                        Intrinsics.checkNotNullParameter(it2, "it");
                        return Boolean.valueOf(it2.getBoolean(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1303String$arg0$callgetBoolean$cond$cond$fun$anonymous$$arg0$callawaitStatus$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()) && it2.getInt(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1305String$arg0$callgetInt$arg0$callEQEQ$branch$cond$fun$anonymous$$arg0$callawaitStatus$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()) == LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1264Int$arg1$callEQEQ$branch$cond$fun$anonymous$$arg0$callawaitStatus$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest() && it2.getInt(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1308String$arg0$callgetInt$arg0$callEQEQ$branch$fun$anonymous$$arg0$callawaitStatus$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()) == LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1267Int$arg1$callEQEQ$branch$fun$anonymous$$arg0$callawaitStatus$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest());
                    }
                });
                ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1338String$arg0$callonNodeWithTag$$$this$callperformClick1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, 2, null));
                SemanticsNodeInteraction semanticsNodeInteractionOnNodeWithTag$default = FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1345String$arg0$callonNodeWithTag$$$this$callperformTextReplacement1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, 2, null);
                try {
                    String string2 = video2.url(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1365String$arg0$callurl$$this$calltoString$arg0$callperformTextReplacement1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()).toString();
                    Intrinsics.checkNotNullExpressionValue(string2, "video.url(\"/stream\").toString()");
                    TextActionsKt.performTextReplacement(semanticsNodeInteractionOnNodeWithTag$default, string2);
                    ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1339String$arg0$callonNodeWithTag$$$this$callperformClick2$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, 2, null));
                    waitUntil(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1286Long$arg0$callwaitUntil$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), new Function0<Boolean>() { // from class: vea.raceremote.UdpControlScreenDeviceTest.controlsVideoFailureBackgroundStopAndExplicitReconnect.2
                        {
                            super(0);
                        }

                        /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                        public final Boolean m1541invoke() {
                            Object obj;
                            UdpControlScreenDeviceTest $this$invoke_u24lambda_u240 = UdpControlScreenDeviceTest.this;
                            try {
                                Result.Companion companion = Result.Companion;
                                obj = Result.constructor-impl(AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default($this$invoke_u24lambda_u240.getCompose(), LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1333String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, 2, null), LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1292String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1241Boolean$arg1$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, 4, null));
                            } catch (Throwable th) {
                                Result.Companion companion2 = Result.Companion;
                                obj = Result.constructor-impl(ResultKt.createFailure(th));
                            }
                            return Boolean.valueOf(Result.isSuccess-impl(obj));
                        }
                    });
                    controlsVideoFailureBackgroundStopAndExplicitReconnect$connected(this);
                    Assert.assertTrue(controlsVideoFailureBackgroundStopAndExplicitReconnect$status(http, host, expectedCar, events2, started2).getBoolean(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1301String$arg0$callgetBoolean$arg0$callassertTrue1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()));
                    try {
                        controlsVideoFailureBackgroundStopAndExplicitReconnect$record(events2, started2, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1361String$arg0$callrecord$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), Boolean.valueOf(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1243Boolean$arg1$callrecord$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()));
                        try {
                            runOnIdle(new Function0<Unit>() { // from class: vea.raceremote.UdpControlScreenDeviceTest.controlsVideoFailureBackgroundStopAndExplicitReconnect.3
                                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                {
                                    super(0);
                                }

                                public final Unit invoke() {
                                    View currentFocus = context.getCurrentFocus();
                                    if (currentFocus != null) {
                                        currentFocus.clearFocus();
                                    }
                                    WindowInsetsController insetsController = context.getWindow().getInsetsController();
                                    if (insetsController == null) {
                                        return null;
                                    }
                                    insetsController.hide(WindowInsets.Type.ime());
                                    return Unit.INSTANCE;
                                }
                            });
                            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1340String$arg0$callonNodeWithTag$$$this$callperformClick3$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, 2, null));
                            final Rect gas = SemanticsNodeInteraction.fetchSemanticsNode$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1349String$arg0$callonNodeWithTag$$this$callfetchSemanticsNode$$this$call$getboundsInRoot$$valgas$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, 2, null), null, 1, null).getBoundsInRoot();
                            final Rect wheel = SemanticsNodeInteraction.fetchSemanticsNode$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1350String$arg0$callonNodeWithTag$$this$callfetchSemanticsNode$$this$call$getboundsInRoot$$valwheel$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, 2, null), null, 1, null).getBoundsInRoot();
                            ActionsKt.performTouchInput(FindersKt.onRoot$default(this.compose, false, 1, null), new Function1<TouchInjectionScope, Unit>() { // from class: vea.raceremote.UdpControlScreenDeviceTest.controlsVideoFailureBackgroundStopAndExplicitReconnect.4
                                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                {
                                    super(1);
                                }

                                public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                                    invoke((TouchInjectionScope) p1);
                                    return Unit.INSTANCE;
                                }

                                public final void invoke(TouchInjectionScope $this$performTouchInput) {
                                    Intrinsics.checkNotNullParameter($this$performTouchInput, "$this$performTouchInput");
                                    $this$performTouchInput.mo352downUv8p0NA(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1255Int$arg0$calldown$fun$anonymous$$arg0$callperformTouchInput$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), gas.getCenter-F1C5BW0());
                                    $this$performTouchInput.mo352downUv8p0NA(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1256Int$arg0$calldown1$fun$anonymous$$arg0$callperformTouchInput$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), wheel.getCenter-F1C5BW0());
                                    TouchInjectionScope.m350moveTod4ec7I$default($this$performTouchInput, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1258Int$arg0$callmoveTo$fun$anonymous$$arg0$callperformTouchInput$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), Offset.plus-MK-Hz9U(gas.getCenter-F1C5BW0(), OffsetKt.Offset(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1248Float$arg0$callOffset$arg0$callplus$arg1$callmoveTo$fun$anonymous$$arg0$callperformTouchInput$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), (-gas.getHeight()) * LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1251Float$arg0$calltimes$arg1$callOffset$arg0$callplus$arg1$callmoveTo$fun$anonymous$$arg0$callperformTouchInput$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest())), 0L, 4, null);
                                    TouchInjectionScope.m350moveTod4ec7I$default($this$performTouchInput, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1259Int$arg0$callmoveTo1$fun$anonymous$$arg0$callperformTouchInput$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), Offset.plus-MK-Hz9U(wheel.getCenter-F1C5BW0(), OffsetKt.Offset(wheel.getWidth() * LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1249Float$arg0$calltimes$arg0$callOffset$arg0$callplus$arg1$callmoveTo1$fun$anonymous$$arg0$callperformTouchInput$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1252Float$arg1$callOffset$arg0$callplus$arg1$callmoveTo1$fun$anonymous$$arg0$callperformTouchInput$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest())), 0L, 4, null);
                                }
                            });
                            context = context;
                            video = video2;
                            try {
                                controlsVideoFailureBackgroundStopAndExplicitReconnect$awaitStatus(http, host, expectedCar, events2, started2, new Function1<JSONObject, Boolean>() { // from class: vea.raceremote.UdpControlScreenDeviceTest.controlsVideoFailureBackgroundStopAndExplicitReconnect.5
                                    public final Boolean invoke(JSONObject it2) {
                                        Intrinsics.checkNotNullParameter(it2, "it");
                                        return Boolean.valueOf(it2.getInt(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1319String$arg0$callgetInt$arg0$callgreater$cond$cond$fun$anonymous$$arg0$callawaitStatus1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()) > LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1279Int$arg1$callgreater$cond$cond$fun$anonymous$$arg0$callawaitStatus1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest() && it2.getInt(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1315String$arg0$callgetInt$arg0$callgreater$branch$cond$fun$anonymous$$arg0$callawaitStatus1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()) > LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1275Int$arg1$callgreater$branch$cond$fun$anonymous$$arg0$callawaitStatus1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest() && it2.getJSONObject(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1323String$arg0$callgetJSONObject$$this$callgetInt$arg0$callgreater$branch$fun$anonymous$$arg0$callawaitStatus1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()).getInt(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1316String$arg0$callgetInt$arg0$callgreater$branch$fun$anonymous$$arg0$callawaitStatus1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()) > LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1276Int$arg1$callgreater$branch$fun$anonymous$$arg0$callawaitStatus1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest());
                                    }
                                });
                                ActionsKt.performTouchInput(FindersKt.onRoot$default(this.compose, false, 1, null), new Function1<TouchInjectionScope, Unit>() { // from class: vea.raceremote.UdpControlScreenDeviceTest.controlsVideoFailureBackgroundStopAndExplicitReconnect.6
                                    public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                                        invoke((TouchInjectionScope) p1);
                                        return Unit.INSTANCE;
                                    }

                                    public final void invoke(TouchInjectionScope $this$performTouchInput) {
                                        Intrinsics.checkNotNullParameter($this$performTouchInput, "$this$performTouchInput");
                                        $this$performTouchInput.up(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1263Int$arg0$callup$fun$anonymous$$arg0$callperformTouchInput1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest());
                                    }
                                });
                                controlsVideoFailureBackgroundStopAndExplicitReconnect$awaitStatus(http, host, expectedCar, events2, started2, new Function1<JSONObject, Boolean>() { // from class: vea.raceremote.UdpControlScreenDeviceTest.controlsVideoFailureBackgroundStopAndExplicitReconnect.7
                                    public final Boolean invoke(JSONObject it2) {
                                        Intrinsics.checkNotNullParameter(it2, "it");
                                        return Boolean.valueOf(it2.getInt(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1313String$arg0$callgetInt$arg0$callEQEQ$cond$fun$anonymous$$arg0$callawaitStatus2$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()) == LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1272Int$arg1$callEQEQ$cond$fun$anonymous$$arg0$callawaitStatus2$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest() && it2.getInt(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1317String$arg0$callgetInt$arg0$callgreater$branch$fun$anonymous$$arg0$callawaitStatus2$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()) > LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1277Int$arg1$callgreater$branch$fun$anonymous$$arg0$callawaitStatus2$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest());
                                    }
                                });
                                ActionsKt.performTouchInput(FindersKt.onRoot$default(this.compose, false, 1, null), new Function1<TouchInjectionScope, Unit>() { // from class: vea.raceremote.UdpControlScreenDeviceTest.controlsVideoFailureBackgroundStopAndExplicitReconnect.8
                                    public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                                        invoke((TouchInjectionScope) p1);
                                        return Unit.INSTANCE;
                                    }

                                    public final void invoke(TouchInjectionScope $this$performTouchInput) {
                                        Intrinsics.checkNotNullParameter($this$performTouchInput, "$this$performTouchInput");
                                        TouchInjectionScope.cancel$default($this$performTouchInput, 0L, 1, null);
                                    }
                                });
                                controlsVideoFailureBackgroundStopAndExplicitReconnect$awaitStatus(http, host, expectedCar, events2, started2, new Function1<JSONObject, Boolean>() { // from class: vea.raceremote.UdpControlScreenDeviceTest.controlsVideoFailureBackgroundStopAndExplicitReconnect.9
                                    public final Boolean invoke(JSONObject it2) {
                                        Intrinsics.checkNotNullParameter(it2, "it");
                                        return Boolean.valueOf(it2.getInt(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1314String$arg0$callgetInt$arg0$callEQEQ$cond$fun$anonymous$$arg0$callawaitStatus3$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()) == LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1273Int$arg1$callEQEQ$cond$fun$anonymous$$arg0$callawaitStatus3$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest() && it2.getInt(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1309String$arg0$callgetInt$arg0$callEQEQ$branch$fun$anonymous$$arg0$callawaitStatus3$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()) == LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1268Int$arg1$callEQEQ$branch$fun$anonymous$$arg0$callawaitStatus3$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest());
                                    }
                                });
                                ActionsKt.performTouchInput(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1347String$arg0$callonNodeWithTag$$$this$callperformTouchInput3$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, 2, null), new Function1<TouchInjectionScope, Unit>() { // from class: vea.raceremote.UdpControlScreenDeviceTest.controlsVideoFailureBackgroundStopAndExplicitReconnect.10
                                    public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                                        invoke((TouchInjectionScope) p1);
                                        return Unit.INSTANCE;
                                    }

                                    public final void invoke(TouchInjectionScope $this$performTouchInput) {
                                        Intrinsics.checkNotNullParameter($this$performTouchInput, "$this$performTouchInput");
                                        $this$performTouchInput.m353downk4lQ0M($this$performTouchInput.mo96getCenterF1C5BW0());
                                        TouchInjectionScope.m349moveTo3MmeM6k$default($this$performTouchInput, Offset.plus-MK-Hz9U($this$performTouchInput.mo96getCenterF1C5BW0(), OffsetKt.Offset(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1247Float$arg0$callOffset$arg0$callplus$arg0$callmoveTo$fun$anonymous$$arg0$callperformTouchInput3$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), $this$performTouchInput.getHeight() * LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1250Float$arg0$calltimes$arg1$callOffset$arg0$callplus$arg0$callmoveTo$fun$anonymous$$arg0$callperformTouchInput3$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest())), 0L, 2, null);
                                    }
                                });
                                controlsVideoFailureBackgroundStopAndExplicitReconnect$awaitStatus(http, host, expectedCar, events2, started2, new Function1<JSONObject, Boolean>() { // from class: vea.raceremote.UdpControlScreenDeviceTest.controlsVideoFailureBackgroundStopAndExplicitReconnect.11
                                    public final Boolean invoke(JSONObject it2) {
                                        Intrinsics.checkNotNullParameter(it2, "it");
                                        return Boolean.valueOf(it2.getInt(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1320String$arg0$callgetInt$arg0$callless$cond$fun$anonymous$$arg0$callawaitStatus4$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()) < LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1280Int$arg1$callless$cond$fun$anonymous$$arg0$callawaitStatus4$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest() && it2.getJSONObject(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1324String$arg0$callgetJSONObject$$this$callgetInt$arg0$callgreater$branch$fun$anonymous$$arg0$callawaitStatus4$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()).getInt(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1318String$arg0$callgetInt$arg0$callgreater$branch$fun$anonymous$$arg0$callawaitStatus4$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()) > LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1278Int$arg1$callgreater$branch$fun$anonymous$$arg0$callawaitStatus4$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest());
                                    }
                                });
                                ((ActivityScenarioRule) getActivityRule()).getScenario().moveToState(Lifecycle.State.STARTED);
                                controlsVideoFailureBackgroundStopAndExplicitReconnect$awaitStatus(http, host, expectedCar, events2, started2, AnonymousClass12.INSTANCE);
                                controlsVideoFailureBackgroundStopAndExplicitReconnect$trace(http, host, events2, started2, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1363String$arg0$calltrace$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest());
                                ((ActivityScenarioRule) getActivityRule()).getScenario().moveToState(Lifecycle.State.RESUMED);
                                AssertionsKt.assertIsNotEnabled(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1330String$arg0$callonNodeWithTag$$$this$callassertIsNotEnabled$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, 2, null));
                                AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1334String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, 2, null), LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1293String$arg0$callassertTextContains$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1242Boolean$arg1$callassertTextContains$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, 4, null);
                                ActionsKt.performTouchInput(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1348String$arg0$callonNodeWithTag$$$this$callperformTouchInput4$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, 2, null), new Function1<TouchInjectionScope, Unit>() { // from class: vea.raceremote.UdpControlScreenDeviceTest.controlsVideoFailureBackgroundStopAndExplicitReconnect.13
                                    public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                                        invoke((TouchInjectionScope) p1);
                                        return Unit.INSTANCE;
                                    }

                                    public final void invoke(TouchInjectionScope $this$performTouchInput) {
                                        Intrinsics.checkNotNullParameter($this$performTouchInput, "$this$performTouchInput");
                                        TouchInjectionScope.cancel$default($this$performTouchInput, 0L, 1, null);
                                    }
                                });
                                Assert.assertTrue(controlsVideoFailureBackgroundStopAndExplicitReconnect$neutral(controlsVideoFailureBackgroundStopAndExplicitReconnect$status(http, host, expectedCar, events2, started2)));
                                ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1341String$arg0$callonNodeWithTag$$$this$callperformClick4$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, 2, null));
                                ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1342String$arg0$callonNodeWithTag$$$this$callperformClick5$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, 2, null));
                                controlsVideoFailureBackgroundStopAndExplicitReconnect$connected(this);
                                controlsVideoFailureBackgroundStopAndExplicitReconnect$awaitStatus(http, host, expectedCar, events2, started2, new Function1<JSONObject, Boolean>() { // from class: vea.raceremote.UdpControlScreenDeviceTest.controlsVideoFailureBackgroundStopAndExplicitReconnect.14
                                    public final Boolean invoke(JSONObject it2) {
                                        Intrinsics.checkNotNullParameter(it2, "it");
                                        return Boolean.valueOf(it2.getBoolean(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1304String$arg0$callgetBoolean$cond$cond$fun$anonymous$$arg0$callawaitStatus6$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()) && it2.getInt(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1306String$arg0$callgetInt$arg0$callEQEQ$branch$cond$fun$anonymous$$arg0$callawaitStatus6$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()) == LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1265Int$arg1$callEQEQ$branch$cond$fun$anonymous$$arg0$callawaitStatus6$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest() && it2.getInt(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1310String$arg0$callgetInt$arg0$callEQEQ$branch$fun$anonymous$$arg0$callawaitStatus6$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()) == LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1269Int$arg1$callEQEQ$branch$fun$anonymous$$arg0$callawaitStatus6$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest());
                                    }
                                });
                                ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1343String$arg0$callonNodeWithTag$$$this$callperformClick6$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, 2, null));
                                controlsVideoFailureBackgroundStopAndExplicitReconnect$awaitStatus(http, host, expectedCar, events2, started2, AnonymousClass15.INSTANCE);
                                controlsVideoFailureBackgroundStopAndExplicitReconnect$trace(http, host, events2, started2, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1364String$arg0$calltrace1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest());
                                AssertionsKt.assertIsNotEnabled(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1331String$arg0$callonNodeWithTag$$$this$callassertIsNotEnabled1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, 2, null));
                                TextActionsKt.performTextReplacement(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1346String$arg0$callonNodeWithTag$$$this$callperformTextReplacement2$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, 2, null), LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1351String$arg0$callperformTextReplacement2$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest());
                                AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1335String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, 2, null), LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1294String$arg0$callassertTextContains1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, false, 6, null);
                                AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1336String$arg0$callonNodeWithTag$$$this$callassertTextContains2$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, 2, null), LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1295String$arg0$callassertTextContains2$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, false, 6, null);
                                Assert.assertTrue(controlsVideoFailureBackgroundStopAndExplicitReconnect$neutral(controlsVideoFailureBackgroundStopAndExplicitReconnect$status(http, host, expectedCar, events2, started2)));
                                started = started2;
                                events = events2;
                                try {
                                    controlsVideoFailureBackgroundStopAndExplicitReconnect$record(events, started, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1362String$arg0$callrecord1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), Boolean.valueOf(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1244Boolean$arg1$callrecord1$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()));
                                    boolean complete3 = LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1245Boolean$setcomplete$try$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest();
                                    try {
                                        ((ActivityScenarioRule) getActivityRule()).getScenario().moveToState(Lifecycle.State.STARTED);
                                    } finally {
                                        File file2 = new File(context.getFilesDir(), LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1366String$arg1$call$init$$$$this$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest());
                                        String string3 = new JSONObject().put(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1352String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), complete3).put(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1353String$arg0$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), host).put(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1355String$arg0$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), SystemClock.elapsedRealtime() - started).put(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1357String$arg0$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), events).toString(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1262Int$arg0$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest());
                                        Intrinsics.checkNotNullExpressionValue(string3, "JSONObject().put(\"comple…nts\", events).toString(2)");
                                        FilesKt.writeText$default(file2, string3, (Charset) null, 2, (Object) null);
                                        video.shutdown();
                                        http.connectionPool().evictAll();
                                        http.dispatcher().executorService().shutdown();
                                    }
                                } catch (Throwable th) {
                                    error = th;
                                    try {
                                        controlsVideoFailureBackgroundStopAndExplicitReconnect$record(events, started, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1359String$arg0$callrecord$catch$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), error.toString());
                                        throw error;
                                    } catch (Throwable error) {
                                        try {
                                            ((ActivityScenarioRule) getActivityRule()).getScenario().moveToState(Lifecycle.State.STARTED);
                                            file = new File(context.getFilesDir(), LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1366String$arg1$call$init$$$$this$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest());
                                            JSONObject jSONObject = new JSONObject();
                                            String strM1352String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest = LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1352String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest();
                                            boolean complete4 = complete;
                                            throw error;
                                        } finally {
                                            file = new File(context.getFilesDir(), LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1366String$arg1$call$init$$$$this$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest());
                                            string = new JSONObject().put(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1352String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), complete).put(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1353String$arg0$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), host).put(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1355String$arg0$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), SystemClock.elapsedRealtime() - started).put(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1357String$arg0$callput$$this$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), events).toString(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1262Int$arg0$calltoString$arg0$callwriteText$finally$finally$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest());
                                            Intrinsics.checkNotNullExpressionValue(string, "JSONObject().put(\"comple…nts\", events).toString(2)");
                                            FilesKt.writeText$default(file, string, (Charset) null, 2, (Object) null);
                                            video.shutdown();
                                            http.connectionPool().evictAll();
                                            http.dispatcher().executorService().shutdown();
                                        }
                                    }
                                }
                            } catch (Throwable th2) {
                                error = th2;
                                started = started2;
                                events = events2;
                            }
                        } catch (Throwable th3) {
                            error = th3;
                            started = started2;
                            events = events2;
                            context = context;
                            video = video2;
                        }
                    } catch (Throwable th4) {
                        error = th4;
                        started = started2;
                        events = events2;
                        video = video2;
                    }
                } catch (Throwable th5) {
                    error = th5;
                    video = video2;
                    events = events2;
                    started = started2;
                }
            } catch (Throwable th6) {
                error = th6;
                events = events2;
                video = video2;
                started = started2;
            }
        } catch (Throwable th7) {
            error = th7;
            complete = complete2;
            events = events2;
            context = context2;
            video = video2;
            started = started2;
        }
    }

    private static final void controlsVideoFailureBackgroundStopAndExplicitReconnect$record(JSONArray events, long started, String kind, Object value) {
        events.put(new JSONObject().put(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1354String$arg0$callput$$this$callput$$this$callput$arg0$callput$funrecord$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), SystemClock.elapsedRealtime() - started).put(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1356String$arg0$callput$$this$callput$arg0$callput$funrecord$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), kind).put(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1358String$arg0$callput$arg0$callput$funrecord$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), value));
    }

    private static final JSONObject controlsVideoFailureBackgroundStopAndExplicitReconnect$get(OkHttpClient http, String host, String path) {
        Response response = (Closeable) http.newCall(new Request.Builder().url(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1287String$0$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$funget$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest() + host + LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1288String$2$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$funget$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest() + path).build()).execute();
        try {
            Response it = response;
            Assert.assertEquals(Integer.valueOf(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1254Int$arg0$callassertEquals$fun$anonymous$$arg0$calluse$funget$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()), Integer.valueOf(it.code()));
            ResponseBody responseBodyBody = it.body();
            if (responseBodyBody != null) {
                JSONObject jSONObject = new JSONObject(responseBodyBody.string());
                CloseableKt.closeFinally(response, (Throwable) null);
                return jSONObject;
            }
            throw new IllegalArgumentException("Required value was null.".toString());
        } catch (Throwable th) {
            try {
                throw th;
            } catch (Throwable th2) {
                CloseableKt.closeFinally(response, th);
                throw th2;
            }
        }
    }

    private static final JSONObject controlsVideoFailureBackgroundStopAndExplicitReconnect$status(OkHttpClient http, String host, String expectedCar, JSONArray events, long started) {
        JSONObject it = controlsVideoFailureBackgroundStopAndExplicitReconnect$get(http, host, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1298String$arg0$callget$$$this$callalso$funstatus$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest());
        Assert.assertEquals(expectedCar, it.getString(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1328String$arg0$callgetString$arg1$callassertEquals$fun$anonymous$$arg0$callalso$funstatus$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()));
        Assert.assertFalse(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1290String$arg0$callassertFalse$fun$anonymous$$arg0$callalso$funstatus$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), it.getBoolean(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1302String$arg0$callgetBoolean$arg1$callassertFalse$fun$anonymous$$arg0$callalso$funstatus$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()));
        Assert.assertEquals(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1289String$arg0$callassertEquals1$fun$anonymous$$arg0$callalso$funstatus$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), it.getString(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1329String$arg0$callgetString$arg1$callassertEquals1$fun$anonymous$$arg0$callalso$funstatus$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()));
        controlsVideoFailureBackgroundStopAndExplicitReconnect$record(events, started, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1360String$arg0$callrecord$fun$anonymous$$arg0$callalso$funstatus$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), it);
        return it;
    }

    private static final void controlsVideoFailureBackgroundStopAndExplicitReconnect$awaitStatus(OkHttpClient http, String host, String expectedCar, JSONArray events, long started, Function1<? super JSONObject, Boolean> function1) {
        long until = SystemClock.elapsedRealtime() + ((long) LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1260Int$arg0$callplus$valuntil$funawaitStatus$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest());
        while (!((Boolean) function1.invoke(controlsVideoFailureBackgroundStopAndExplicitReconnect$status(http, host, expectedCar, events, started))).booleanValue()) {
            SystemClock.sleep(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1284Long$arg0$callsleep$body$loop$funawaitStatus$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest());
            if (SystemClock.elapsedRealtime() >= until) {
                Assert.fail(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1297String$arg0$callfail$funawaitStatus$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest());
                return;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean controlsVideoFailureBackgroundStopAndExplicitReconnect$neutral(JSONObject s) throws JSONException {
        if (s.getBoolean(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1300String$arg0$callgetBoolean$$this$callnot$cond$funneutral$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest())) {
            return false;
        }
        JSONObject it = s.getJSONObject(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1322String$arg0$callgetJSONObject$$$this$calllet$branch$funneutral$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest());
        return it.getInt(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1312String$arg0$callgetInt$arg0$callEQEQ$cond$cond$fun$anonymous$$arg0$calllet$branch$funneutral$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()) == LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1271Int$arg1$callEQEQ$cond$cond$fun$anonymous$$arg0$calllet$branch$funneutral$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest() && it.getInt(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1307String$arg0$callgetInt$arg0$callEQEQ$branch$cond$fun$anonymous$$arg0$calllet$branch$funneutral$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()) == LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1266Int$arg1$callEQEQ$branch$cond$fun$anonymous$$arg0$calllet$branch$funneutral$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest() && it.getInt(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1311String$arg0$callgetInt$arg0$callEQEQ$branch$fun$anonymous$$arg0$calllet$branch$funneutral$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()) == LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1270Int$arg1$callEQEQ$branch$fun$anonymous$$arg0$calllet$branch$funneutral$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest();
    }

    private static final void controlsVideoFailureBackgroundStopAndExplicitReconnect$connected(final UdpControlScreenDeviceTest this$0) {
        this$0.compose.waitUntil(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1285Long$arg0$callwaitUntil$funconnected$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), new Function0<Boolean>() { // from class: vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$connected$1
            {
                super(0);
            }

            /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
            public final Boolean m1543invoke() {
                Object obj;
                UdpControlScreenDeviceTest $this$invoke_u24lambda_u240 = this.this$0;
                try {
                    Result.Companion companion = Result.Companion;
                    obj = Result.constructor-impl(AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default($this$invoke_u24lambda_u240.getCompose(), LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1332String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil$funconnected$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, 2, null), LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1291String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil$funconnected$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), false, false, 6, null));
                } catch (Throwable th) {
                    Result.Companion companion2 = Result.Companion;
                    obj = Result.constructor-impl(ResultKt.createFailure(th));
                }
                return Boolean.valueOf(Result.isSuccess-impl(obj));
            }
        });
    }

    private static final void controlsVideoFailureBackgroundStopAndExplicitReconnect$trace(OkHttpClient http, String host, JSONArray events, long started, String label) throws JSONException {
        boolean z;
        JSONObject value = controlsVideoFailureBackgroundStopAndExplicitReconnect$get(http, host, LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1299String$arg0$callget$valvalue$funtrace$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest());
        controlsVideoFailureBackgroundStopAndExplicitReconnect$record(events, started, label, value);
        JSONArray rows = value.getJSONArray(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1321String$arg0$callgetJSONArray$valrows$funtrace$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest());
        String strM1296String$arg0$callassertTrue$funtrace$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest = LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1296String$arg0$callassertTrue$funtrace$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest();
        Iterable $this$any$iv = RangesKt.until(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1253Int$$$this$calluntil$$$this$callany$arg1$callassertTrue$funtrace$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest(), rows.length());
        if (($this$any$iv instanceof Collection) && ((Collection) $this$any$iv).isEmpty()) {
            z = false;
        } else {
            IntIterator it = $this$any$iv.iterator();
            while (it.hasNext()) {
                int element$iv = it.nextInt();
                JSONObject value2 = value;
                if (rows.getJSONArray(element$iv).getInt(LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1257Int$arg0$callgetInt$arg0$callEQEQ$fun$anonymous$$arg0$callany$arg1$callassertTrue$funtrace$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()) == LiveLiterals$UdpControlScreenDeviceTestKt.INSTANCE.m1274Int$arg1$callEQEQ$fun$anonymous$$arg0$callany$arg1$callassertTrue$funtrace$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest()) {
                    z = true;
                } else {
                    value = value2;
                }
            }
            z = false;
        }
        Assert.assertTrue(strM1296String$arg0$callassertTrue$funtrace$funcontrolsVideoFailureBackgroundStopAndExplicitReconnect$classUdpControlScreenDeviceTest, z);
    }

    /* JADX INFO: renamed from: vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$12, reason: invalid class name */
    /* JADX INFO: compiled from: UdpControlScreenDeviceTest.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    /* synthetic */ class AnonymousClass12 extends FunctionReferenceImpl implements Function1<JSONObject, Boolean> {
        public static final AnonymousClass12 INSTANCE = new AnonymousClass12();

        AnonymousClass12() {
            super(1, Intrinsics.Kotlin.class, "neutral", "controlsVideoFailureBackgroundStopAndExplicitReconnect$neutral(Lorg/json/JSONObject;)Z", 0);
        }

        public final Boolean invoke(JSONObject p0) {
            Intrinsics.checkNotNullParameter(p0, "p0");
            return Boolean.valueOf(UdpControlScreenDeviceTest.controlsVideoFailureBackgroundStopAndExplicitReconnect$neutral(p0));
        }
    }

    /* JADX INFO: renamed from: vea.raceremote.UdpControlScreenDeviceTest$controlsVideoFailureBackgroundStopAndExplicitReconnect$15, reason: invalid class name */
    /* JADX INFO: compiled from: UdpControlScreenDeviceTest.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    /* synthetic */ class AnonymousClass15 extends FunctionReferenceImpl implements Function1<JSONObject, Boolean> {
        public static final AnonymousClass15 INSTANCE = new AnonymousClass15();

        AnonymousClass15() {
            super(1, Intrinsics.Kotlin.class, "neutral", "controlsVideoFailureBackgroundStopAndExplicitReconnect$neutral(Lorg/json/JSONObject;)Z", 0);
        }

        public final Boolean invoke(JSONObject p0) {
            Intrinsics.checkNotNullParameter(p0, "p0");
            return Boolean.valueOf(UdpControlScreenDeviceTest.controlsVideoFailureBackgroundStopAndExplicitReconnect$neutral(p0));
        }
    }
}
