package vea.raceremote;

import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Bundle;
import android.os.SystemClock;
import androidx.compose.ui.test.ActionsKt;
import androidx.compose.ui.test.AssertionsKt;
import androidx.compose.ui.test.FindersKt;
import androidx.compose.ui.test.SemanticsNodeInteraction;
import androidx.compose.ui.test.SemanticsNodeInteractionCollection;
import androidx.compose.ui.test.junit4.AndroidComposeTestRule;
import androidx.compose.ui.test.junit4.AndroidComposeTestRule_androidKt;
import androidx.lifecycle.Lifecycle;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.net.DatagramSocket;
import java.nio.charset.Charset;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.io.CloseableKt;
import kotlin.io.FilesKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.CharsKt;
import kotlin.text.StringsKt;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Assume;
import org.junit.Rule;
import org.junit.Test;
import vea.raceremote.app.MainActivity;
import vea.raceremote.control.CarDiscovery;
import vea.raceremote.control.DiscoveredCar;
import vea.raceremote.control.DiscoveryState;

/* JADX INFO: compiled from: UdpDiscoveryDeviceTest.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\t\u001a\u00020\nH\u0007R%\u0010\u0003\u001a\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0004\u0012\u00020\u00060\u00048G¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b¨\u0006\u000b"}, d2 = {"Lvea/raceremote/UdpDiscoveryDeviceTest;", "", "()V", "compose", "Landroidx/compose/ui/test/junit4/AndroidComposeTestRule;", "Landroidx/test/ext/junit/rules/ActivityScenarioRule;", "Lvea/raceremote/app/MainActivity;", "getCompose", "()Landroidx/compose/ui/test/junit4/AndroidComposeTestRule;", "searchSelectWithoutArmThenConnectAndReportBusy", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class UdpDiscoveryDeviceTest {
    public static final int $stable = AndroidComposeTestRule.$stable;
    private final AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity> compose = AndroidComposeTestRule_androidKt.createAndroidComposeRule(MainActivity.class);

    @Rule
    public final AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity> getCompose() {
        return this.compose;
    }

    /* JADX WARN: Undo finally extract visitor
    jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r16v0 ??
    	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
    	at jadx.core.dex.instructions.args.RegisterArg.sameCodeVar(RegisterArg.java:193)
    	at jadx.core.dex.visitors.finaly.SameInstructionsStrategyImpl.isSameArgs(SameInstructionsStrategyImpl.java:66)
    	at jadx.core.dex.visitors.finaly.SameInstructionsStrategyImpl.sameInsns(SameInstructionsStrategyImpl.java:47)
    	at jadx.core.dex.visitors.finaly.traverser.visitors.comparator.InstructionBlockComparatorTraverserVisitor.visit(InstructionBlockComparatorTraverserVisitor.java:152)
    	at jadx.core.dex.visitors.finaly.traverser.handlers.InstructionActivePathTraverserHandler.handle(InstructionActivePathTraverserHandler.java:39)
    	at jadx.core.dex.visitors.finaly.traverser.handlers.AbstractActivePathTraverserHandler.process(AbstractActivePathTraverserHandler.java:19)
    	at jadx.core.dex.visitors.finaly.traverser.TraverserController.processHandlerImplementations(TraverserController.java:43)
    	at jadx.core.dex.visitors.finaly.traverser.TraverserController.advance(TraverserController.java:156)
    	at jadx.core.dex.visitors.finaly.traverser.TraverserController.process(TraverserController.java:79)
    	at jadx.core.dex.visitors.finaly.MarkFinallyVisitor.findCommonInsns(MarkFinallyVisitor.java:404)
    	at jadx.core.dex.visitors.finaly.MarkFinallyVisitor.extractFinally(MarkFinallyVisitor.java:284)
    	at jadx.core.dex.visitors.finaly.MarkFinallyVisitor.processTryBlock(MarkFinallyVisitor.java:202)
    	at jadx.core.dex.visitors.finaly.MarkFinallyVisitor.visit(MarkFinallyVisitor.java:135)
     */
    @Test
    public final void searchSelectWithoutArmThenConnectAndReportBusy() throws JSONException {
        Object element$iv;
        JSONArray events;
        OkHttpClient http;
        long started;
        CarDiscovery observer;
        Bundle args = InstrumentationRegistry.getArguments();
        Assume.assumeTrue(Intrinsics.areEqual(args.getString(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1417String$arg0$callgetString$arg0$callEQEQ$arg0$callassumeTrue$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()), LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1445String$arg1$callEQEQ$arg0$callassumeTrue$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()));
        String host = args.getString(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1419String$arg0$callgetString$arg0$callrequireNotNull$valhost$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest());
        if (host == null) {
            throw new IllegalArgumentException("Required value was null.".toString());
        }
        Intrinsics.checkNotNullExpressionValue(host, "requireNotNull(args.getString(\"driveBenchHost\"))");
        String carId = args.getString(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1418String$arg0$callgetString$arg0$callrequireNotNull$valcarId$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest());
        if (carId == null) {
            throw new IllegalArgumentException("Required value was null.".toString());
        }
        Intrinsics.checkNotNullExpressionValue(carId, "requireNotNull(args.getString(\"driveBenchCarId\"))");
        MainActivity context = getActivity();
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(ConnectivityManager.class);
        Object[] allNetworks = cm.getAllNetworks();
        Intrinsics.checkNotNullExpressionValue(allNetworks, "cm.allNetworks");
        Object[] $this$firstOrNull$iv = allNetworks;
        int length = $this$firstOrNull$iv.length;
        int i = 0;
        while (true) {
            if (i >= length) {
                element$iv = null;
                break;
            }
            element$iv = $this$firstOrNull$iv[i];
            NetworkCapabilities networkCapabilities = cm.getNetworkCapabilities((Network) element$iv);
            if (networkCapabilities != null && networkCapabilities.hasTransport(1) == LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1368Boolean$arg1$callEQEQ$fun$anonymous$$arg0$callfirstOrNull$arg0$callrequireNotNull$valwifi$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()) {
                break;
            } else {
                i++;
            }
        }
        if (element$iv == null) {
            throw new IllegalArgumentException("Required value was null.".toString());
        }
        final Network wifi = (Network) element$iv;
        OkHttpClient http2 = new OkHttpClient.Builder().socketFactory(wifi.getSocketFactory()).connectTimeout(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1387Long$arg0$callconnectTimeout$$this$callreadTimeout$$this$callcallTimeout$$this$callbuild$valhttp$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), TimeUnit.SECONDS).readTimeout(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1388Long$arg0$callreadTimeout$$this$callcallTimeout$$this$callbuild$valhttp$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), TimeUnit.SECONDS).callTimeout(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1386Long$arg0$callcallTimeout$$this$callbuild$valhttp$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), TimeUnit.SECONDS).build();
        JSONArray events2 = new JSONArray();
        long started2 = SystemClock.elapsedRealtime();
        final CarDiscovery observer2 = new CarDiscovery();
        boolean complete = LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1372Boolean$valcomplete$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest();
        try {
            JSONObject initial = searchSelectWithoutArmThenConnectAndReportBusy$status(http2, host, carId, events2, started2);
            Assert.assertTrue(searchSelectWithoutArmThenConnectAndReportBusy$neutral(initial));
            String string = initial.getString(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1416String$arg0$callgetString$$$this$calltoLong$valchip$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest());
            Intrinsics.checkNotNullExpressionValue(string, "initial.getString(\"chipId\")");
            final long chip = Long.parseLong(string, CharsKt.checkRadix(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1379Int$arg0$calltoLong$valchip$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()));
            String before = searchSelectWithoutArmThenConnectAndReportBusy$get(http2, host, LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1404String$arg0$callget$$this$callgetJSONArray$$this$calltoString$valbefore$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()).getJSONArray(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1414String$arg0$callgetJSONArray$$this$calltoString$valbefore$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()).toString();
            Intrinsics.checkNotNullExpressionValue(before, "get(\"debug/udp-trace\").g…rray(\"events\").toString()");
            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1429String$arg0$callonNodeWithTag$$$this$callperformClick$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), false, 2, null));
            waitUntil(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1390Long$arg0$callwaitUntil$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), new Function0<Boolean>() { // from class: vea.raceremote.UdpDiscoveryDeviceTest.searchSelectWithoutArmThenConnectAndReportBusy.1
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                public final Boolean m1544invoke() {
                    return Boolean.valueOf(SemanticsNodeInteractionCollection.fetchSemanticsNodes$default(FindersKt.onAllNodesWithTag$default(UdpDiscoveryDeviceTest.this.getCompose(), new StringBuilder().append(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1393String$0$str$arg0$callonAllNodesWithTag$$this$callfetchSemanticsNodes$$this$call$getsize$$arg0$callEQEQ$fun$anonymous$$arg1$callwaitUntil$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()).append(chip).toString(), false, 2, null), false, null, 3, null).size() == LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1385Int$arg1$callEQEQ$fun$anonymous$$arg1$callwaitUntil$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest());
                }
            });
            events = events2;
            try {
                Assert.assertTrue(searchSelectWithoutArmThenConnectAndReportBusy$neutral(searchSelectWithoutArmThenConnectAndReportBusy$status(http2, host, carId, events2, started2)));
                ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1394String$0$str$arg0$callonNodeWithTag$$$this$callperformClick1$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest() + chip, false, 2, null));
                AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1426String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), false, 2, null), host, false, false, 6, null);
                SemanticsNodeInteraction semanticsNodeInteractionOnNodeWithTag$default = FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1427String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), false, 2, null);
                String string2 = Long.toString(chip, CharsKt.checkRadix(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1380Int$arg0$calltoString$$$this$callpadStart$arg0$callassertTextContains1$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()));
                Intrinsics.checkNotNullExpressionValue(string2, "toString(this, checkRadix(radix))");
                AssertionsKt.assertTextContains$default(semanticsNodeInteractionOnNodeWithTag$default, StringsKt.padStart(string2, LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1377Int$arg0$callpadStart$arg0$callassertTextContains1$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1373Char$arg1$callpadStart$arg0$callassertTextContains1$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()), LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1369Boolean$arg1$callassertTextContains1$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), false, 4, null);
                AssertionsKt.assertIsNotEnabled(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1423String$arg0$callonNodeWithTag$$$this$callassertIsNotEnabled$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), false, 2, null));
                Assert.assertTrue(searchSelectWithoutArmThenConnectAndReportBusy$neutral(searchSelectWithoutArmThenConnectAndReportBusy$status(http2, host, carId, events, started2)));
                try {
                    Assert.assertEquals(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1397String$arg0$callassertEquals$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), before, searchSelectWithoutArmThenConnectAndReportBusy$get(http2, host, LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1403String$arg0$callget$$this$callgetJSONArray$$this$calltoString$arg2$callassertEquals$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()).getJSONArray(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1413String$arg0$callgetJSONArray$$this$calltoString$arg2$callassertEquals$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()).toString());
                    try {
                        searchSelectWithoutArmThenConnectAndReportBusy$record(events, started2, LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1441String$arg0$callrecord$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), Boolean.valueOf(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1370Boolean$arg1$callrecord$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()));
                        ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1430String$arg0$callonNodeWithTag$$$this$callperformClick2$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), false, 2, null));
                        waitUntil(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1391Long$arg0$callwaitUntil1$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), new Function0<Boolean>() { // from class: vea.raceremote.UdpDiscoveryDeviceTest.searchSelectWithoutArmThenConnectAndReportBusy.2
                            {
                                super(0);
                            }

                            /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                            public final Boolean m1545invoke() {
                                Object obj;
                                UdpDiscoveryDeviceTest $this$invoke_u24lambda_u240 = UdpDiscoveryDeviceTest.this;
                                try {
                                    Result.Companion companion = Result.Companion;
                                    obj = Result.constructor-impl(AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default($this$invoke_u24lambda_u240.getCompose(), LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1425String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil1$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), false, 2, null), LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1400String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil1$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), false, false, 6, null));
                                } catch (Throwable th) {
                                    Result.Companion companion2 = Result.Companion;
                                    obj = Result.constructor-impl(ResultKt.createFailure(th));
                                }
                                return Boolean.valueOf(Result.isSuccess-impl(obj));
                            }
                        });
                        http = http2;
                        try {
                            Assert.assertTrue(searchSelectWithoutArmThenConnectAndReportBusy$status(http2, host, carId, events, started2).getBoolean(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1408String$arg0$callgetBoolean$arg0$callassertTrue3$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()));
                            AssertionsKt.assertIsNotEnabled(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1424String$arg0$callonNodeWithTag$$$this$callassertIsNotEnabled1$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), false, 2, null));
                            try {
                                CarDiscovery.search$default(observer2, (List) null, new Function1<DatagramSocket, Unit>() { // from class: vea.raceremote.UdpDiscoveryDeviceTest.searchSelectWithoutArmThenConnectAndReportBusy.3
                                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                    {
                                        super(1);
                                    }

                                    public /* bridge */ /* synthetic */ Object invoke(Object p1) throws IOException {
                                        invoke((DatagramSocket) p1);
                                        return Unit.INSTANCE;
                                    }

                                    public final void invoke(DatagramSocket it) throws IOException {
                                        Intrinsics.checkNotNullParameter(it, "it");
                                        wifi.bindSocket(it);
                                    }
                                }, 1, (Object) null);
                                waitUntil(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1392Long$arg0$callwaitUntil2$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), new Function0<Boolean>() { // from class: vea.raceremote.UdpDiscoveryDeviceTest.searchSelectWithoutArmThenConnectAndReportBusy.4
                                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                    {
                                        super(0);
                                    }

                                    /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                                    public final Boolean m1546invoke() {
                                        return Boolean.valueOf(!((DiscoveryState) observer2.getState().getValue()).getSearching());
                                    }
                                });
                                Iterable $this$single$iv = ((DiscoveryState) observer2.getState().getValue()).getCars();
                                Object single$iv = null;
                                boolean found$iv = false;
                                for (Object element$iv2 : $this$single$iv) {
                                    try {
                                        DiscoveredCar it = (DiscoveredCar) element$iv2;
                                        if (it.getChipId() == chip && Intrinsics.areEqual(it.getHost(), host)) {
                                            if (found$iv) {
                                                throw new IllegalArgumentException("Collection contains more than one matching element.");
                                            }
                                            single$iv = element$iv2;
                                            found$iv = true;
                                        }
                                    } catch (Throwable th) {
                                        error = th;
                                        observer = observer2;
                                        started = started2;
                                    }
                                }
                                if (found$iv) {
                                    try {
                                        DiscoveredCar discovered = (DiscoveredCar) single$iv;
                                        Assert.assertTrue(discovered.getBusy());
                                        Assert.assertEquals(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1399String$arg0$callassertEquals1$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), discovered.getTransport());
                                        Assert.assertEquals(Integer.valueOf(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1375Int$arg0$callassertEquals2$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()), Integer.valueOf(discovered.getPort()));
                                        Assert.assertEquals(Integer.valueOf(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1376Int$arg0$callassertEquals3$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()), Integer.valueOf(discovered.getDiscoveryVersion()));
                                        try {
                                            searchSelectWithoutArmThenConnectAndReportBusy$record(events, started2, LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1442String$arg0$callrecord1$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), discovered.toString());
                                            try {
                                                AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1428String$arg0$callonNodeWithTag$$$this$callassertTextContains2$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), false, 2, null), LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1401String$arg0$callassertTextContains2$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), false, false, 6, null);
                                                observer = observer2;
                                                try {
                                                    Assert.assertTrue(searchSelectWithoutArmThenConnectAndReportBusy$status(http, host, carId, events, started2).getBoolean(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1409String$arg0$callgetBoolean$arg0$callassertTrue5$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()));
                                                    ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1431String$arg0$callonNodeWithTag$$$this$callperformClick3$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), false, 2, null));
                                                    long until = SystemClock.elapsedRealtime() + ((long) LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1378Int$arg0$callplus$valuntil$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest());
                                                    while (!searchSelectWithoutArmThenConnectAndReportBusy$neutral(searchSelectWithoutArmThenConnectAndReportBusy$status(http, host, carId, events, started2))) {
                                                        try {
                                                            if (SystemClock.elapsedRealtime() >= until) {
                                                                break;
                                                            } else {
                                                                SystemClock.sleep(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1389Long$arg0$callsleep$body$loop$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest());
                                                            }
                                                        } catch (Throwable th2) {
                                                            error = th2;
                                                            started = started2;
                                                        }
                                                    }
                                                    Assert.assertTrue(searchSelectWithoutArmThenConnectAndReportBusy$neutral(searchSelectWithoutArmThenConnectAndReportBusy$status(http, host, carId, events, started2)));
                                                    JSONObject trace = searchSelectWithoutArmThenConnectAndReportBusy$get(http, host, LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1405String$arg0$callget$valtrace$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest());
                                                    try {
                                                        searchSelectWithoutArmThenConnectAndReportBusy$record(events, started2, LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1443String$arg0$callrecord2$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), trace);
                                                        Assert.assertTrue(trace.has(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1422String$arg0$callhas$arg0$callassertTrue7$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()));
                                                        boolean complete2 = LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1371Boolean$setcomplete$try$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest();
                                                        observer.close();
                                                        try {
                                                            ((ActivityScenarioRule) getActivityRule()).getScenario().moveToState(Lifecycle.State.STARTED);
                                                            File file = new File(context.getFilesDir(), LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1444String$arg1$call$init$$$$this$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest());
                                                            String string3 = new JSONObject().put(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1432String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), complete2).put(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1433String$arg0$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), host).put(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1435String$arg0$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), SystemClock.elapsedRealtime() - started2).put(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1437String$arg0$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), events).toString(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1381Int$arg0$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest());
                                                            Intrinsics.checkNotNullExpressionValue(string3, "JSONObject().put(\"comple…nts\", events).toString(2)");
                                                            FilesKt.writeText$default(file, string3, (Charset) null, 2, (Object) null);
                                                            http.connectionPool().evictAll();
                                                            http.dispatcher().executorService().shutdown();
                                                            return;
                                                        } catch (Throwable th3) {
                                                            File file2 = new File(context.getFilesDir(), LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1444String$arg1$call$init$$$$this$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest());
                                                            String string4 = new JSONObject().put(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1432String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), complete2).put(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1433String$arg0$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), host).put(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1435String$arg0$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), SystemClock.elapsedRealtime() - started2).put(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1437String$arg0$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), events).toString(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1381Int$arg0$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest());
                                                            Intrinsics.checkNotNullExpressionValue(string4, "JSONObject().put(\"comple…nts\", events).toString(2)");
                                                            FilesKt.writeText$default(file2, string4, (Charset) null, 2, (Object) null);
                                                            http.connectionPool().evictAll();
                                                            http.dispatcher().executorService().shutdown();
                                                            throw th3;
                                                        }
                                                    } catch (Throwable th4) {
                                                        error = th4;
                                                        started = started2;
                                                    }
                                                } catch (Throwable th5) {
                                                    error = th5;
                                                    started = started2;
                                                }
                                            } catch (Throwable th6) {
                                                error = th6;
                                                observer = observer2;
                                                started = started2;
                                            }
                                        } catch (Throwable th7) {
                                            error = th7;
                                            observer = observer2;
                                            started = started2;
                                        }
                                    } catch (Throwable th8) {
                                        error = th8;
                                        observer = observer2;
                                        started = started2;
                                    }
                                } else {
                                    observer = observer2;
                                    started = started2;
                                    try {
                                        throw new NoSuchElementException("Collection contains no element matching the predicate.");
                                    } catch (Throwable th9) {
                                        error = th9;
                                    }
                                }
                            } catch (Throwable th10) {
                                error = th10;
                                observer = observer2;
                                started = started2;
                            }
                        } catch (Throwable th11) {
                            error = th11;
                            observer = observer2;
                            started = started2;
                        }
                    } catch (Throwable th12) {
                        error = th12;
                        http = http2;
                        observer = observer2;
                        started = started2;
                    }
                } catch (Throwable th13) {
                    error = th13;
                    http = http2;
                    started = started2;
                    observer = observer2;
                }
            } catch (Throwable th14) {
                error = th14;
                http = http2;
                started = started2;
                observer = observer2;
            }
        } catch (Throwable th15) {
            error = th15;
            events = events2;
            http = http2;
            started = started2;
            observer = observer2;
        }
        try {
            searchSelectWithoutArmThenConnectAndReportBusy$record(events, started, LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1439String$arg0$callrecord$catch$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), error.toString());
            throw error;
        } catch (Throwable error) {
            observer.close();
            try {
                ((ActivityScenarioRule) getActivityRule()).getScenario().moveToState(Lifecycle.State.STARTED);
                File file3 = new File(context.getFilesDir(), LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1444String$arg1$call$init$$$$this$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest());
                String string5 = new JSONObject().put(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1432String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), complete).put(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1433String$arg0$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), host).put(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1435String$arg0$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), SystemClock.elapsedRealtime() - started).put(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1437String$arg0$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), events).toString(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1381Int$arg0$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest());
                Intrinsics.checkNotNullExpressionValue(string5, "JSONObject().put(\"comple…nts\", events).toString(2)");
                FilesKt.writeText$default(file3, string5, (Charset) null, 2, (Object) null);
                http.connectionPool().evictAll();
                http.dispatcher().executorService().shutdown();
                throw error;
            } catch (Throwable th16) {
                File file4 = new File(context.getFilesDir(), LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1444String$arg1$call$init$$$$this$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest());
                String string6 = new JSONObject().put(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1432String$arg0$callput$$this$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), complete).put(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1433String$arg0$callput$$this$callput$$this$callput$$this$calltoString$arg0$callwriteText$finally$finally$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), 
                /*  JADX ERROR: Method code generation error
                    jadx.core.utils.exceptions.CodegenException: Error generate insn: 0x0692: INVOKE (r9v13 'string6' java.lang.String) = 
                      (wrap org.json.JSONObject:0x0688: INVOKE 
                      (wrap org.json.JSONObject:0x067e: INVOKE 
                      (wrap org.json.JSONObject:0x066e: INVOKE 
                      (wrap org.json.JSONObject:0x0662: INVOKE 
                      (wrap org.json.JSONObject:0x0659: CONSTRUCTOR  A[MD:():void (c), WRAPPED] call: org.json.JSONObject.<init>():void type: CONSTRUCTOR)
                      (wrap java.lang.String:0x065e: INVOKE 
                      (wrap vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt:0x065c: SGET  A[WRAPPED] vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt)
                     VIRTUAL call: vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.String$arg-0$call-put$$this$call-put$$this$call-put$$this$call-put$$this$call-toString$arg-0$call-writeText$finally$finally$fun-searchSelectWithoutArmThenConnectAndReportBusy$class-UdpDiscoveryDeviceTest():java.lang.String A[MD:():java.lang.String (m), WRAPPED])
                      (r7v1 'complete' boolean A[D('complete' boolean)])
                     VIRTUAL call: org.json.JSONObject.put(java.lang.String, boolean):org.json.JSONObject A[MD:(java.lang.String, boolean):org.json.JSONObject throws org.json.JSONException (c), WRAPPED])
                      (wrap java.lang.String:0x0668: INVOKE 
                      (wrap vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt:0x0666: SGET  A[WRAPPED] (LINE:102) vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt)
                     VIRTUAL call: vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.String$arg-0$call-put$$this$call-put$$this$call-put$$this$call-toString$arg-0$call-writeText$finally$finally$fun-searchSelectWithoutArmThenConnectAndReportBusy$class-UdpDiscoveryDeviceTest():java.lang.String A[MD:():java.lang.String (m), WRAPPED] (LINE:102))
                      (r5v1 java.lang.Object A[D('host' java.lang.String)])
                     VIRTUAL call: org.json.JSONObject.put(java.lang.String, java.lang.Object):org.json.JSONObject A[MD:(java.lang.String, java.lang.Object):org.json.JSONObject throws org.json.JSONException (c), WRAPPED] (LINE:102))
                      (wrap java.lang.String:0x0674: INVOKE 
                      (wrap vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt:0x0672: SGET  A[WRAPPED] vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt)
                     VIRTUAL call: vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.String$arg-0$call-put$$this$call-put$$this$call-toString$arg-0$call-writeText$finally$finally$fun-searchSelectWithoutArmThenConnectAndReportBusy$class-UdpDiscoveryDeviceTest():java.lang.String A[MD:():java.lang.String (m), WRAPPED])
                      (wrap long:0x067c: ARITH (wrap long:0x0678: INVOKE  STATIC call: android.os.SystemClock.elapsedRealtime():long A[MD:():long (c), WRAPPED]) - (r5v3 'started' long A[D('started' long)]) A[WRAPPED])
                     VIRTUAL call: org.json.JSONObject.put(java.lang.String, long):org.json.JSONObject A[MD:(java.lang.String, long):org.json.JSONObject throws org.json.JSONException (c), WRAPPED] (LINE:102))
                      (wrap java.lang.String:0x0684: INVOKE 
                      (wrap vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt:0x0682: SGET  A[WRAPPED] vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt)
                     VIRTUAL call: vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.String$arg-0$call-put$$this$call-toString$arg-0$call-writeText$finally$finally$fun-searchSelectWithoutArmThenConnectAndReportBusy$class-UdpDiscoveryDeviceTest():java.lang.String A[MD:():java.lang.String (m), WRAPPED])
                      (r3v3 'events' org.json.JSONArray A[D('events' org.json.JSONArray)])
                     VIRTUAL call: org.json.JSONObject.put(java.lang.String, java.lang.Object):org.json.JSONObject A[MD:(java.lang.String, java.lang.Object):org.json.JSONObject throws org.json.JSONException (c), WRAPPED] (LINE:102))
                      (wrap int:0x068e: INVOKE 
                      (wrap vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt:0x068c: SGET  A[WRAPPED] vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt)
                     VIRTUAL call: vea.raceremote.LiveLiterals$UdpDiscoveryDeviceTestKt.Int$arg-0$call-toString$arg-0$call-writeText$finally$finally$fun-searchSelectWithoutArmThenConnectAndReportBusy$class-UdpDiscoveryDeviceTest():int A[MD:():int (m), WRAPPED])
                     VIRTUAL call: org.json.JSONObject.toString(int):java.lang.String A[DECLARE_VAR, MD:(int):java.lang.String throws org.json.JSONException (c)] (LINE:102) in method: vea.raceremote.UdpDiscoveryDeviceTest.searchSelectWithoutArmThenConnectAndReportBusy():void, file: classes4.dex
                    	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:310)
                    	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:273)
                    	at jadx.core.codegen.RegionGen.makeSimpleBlock(RegionGen.java:94)
                    	at jadx.core.dex.nodes.IBlock.generate(IBlock.java:15)
                    	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                    	at jadx.core.dex.regions.Region.generate(Region.java:35)
                    	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                    	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:83)
                    	at jadx.core.codegen.RegionGen.makeCatchBlock(RegionGen.java:383)
                    	at jadx.core.codegen.RegionGen.makeTryCatch(RegionGen.java:335)
                    	at jadx.core.dex.regions.TryCatchRegion.generate(TryCatchRegion.java:85)
                    	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                    	at jadx.core.dex.regions.Region.generate(Region.java:35)
                    	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                    	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:83)
                    	at jadx.core.codegen.RegionGen.makeCatchBlock(RegionGen.java:383)
                    	at jadx.core.codegen.RegionGen.makeTryCatch(RegionGen.java:335)
                    	at jadx.core.dex.regions.TryCatchRegion.generate(TryCatchRegion.java:85)
                    	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                    	at jadx.core.dex.regions.Region.generate(Region.java:35)
                    	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                    	at jadx.core.dex.regions.Region.generate(Region.java:35)
                    	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                    	at jadx.core.dex.regions.Region.generate(Region.java:35)
                    	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                    	at jadx.core.dex.regions.Region.generate(Region.java:35)
                    	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                    	at jadx.core.dex.regions.Region.generate(Region.java:35)
                    	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                    	at jadx.core.dex.regions.Region.generate(Region.java:35)
                    	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                    	at jadx.core.dex.regions.Region.generate(Region.java:35)
                    	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                    	at jadx.core.codegen.MethodGen.addRegionInsns(MethodGen.java:291)
                    	at jadx.core.codegen.MethodGen.addInstructions(MethodGen.java:270)
                    	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:420)
                    	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:345)
                    	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:299)
                    	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(Unknown Source)
                    	at java.base/java.util.ArrayList.forEach(Unknown Source)
                    	at java.base/java.util.stream.SortedOps$RefSortingSink.end(Unknown Source)
                    	at java.base/java.util.stream.Sink$ChainedReference.end(Unknown Source)
                    	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(Unknown Source)
                    	at java.base/java.util.stream.AbstractPipeline.copyInto(Unknown Source)
                    	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(Unknown Source)
                    	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(Unknown Source)
                    	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(Unknown Source)
                    	at java.base/java.util.stream.AbstractPipeline.evaluate(Unknown Source)
                    	at java.base/java.util.stream.ReferencePipeline.forEach(Unknown Source)
                    	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:295)
                    	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:284)
                    	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:268)
                    	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:160)
                    	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:104)
                    	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
                    	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
                    	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
                    	at jadx.core.ProcessClass.process(ProcessClass.java:89)
                    	at jadx.core.ProcessClass.generateCode(ProcessClass.java:127)
                    	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
                    	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
                    	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
                    Caused by: jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r5v1 java.lang.Object
                    	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
                    */
                /*
                    Method dump skipped, instruction units count: 1743
                    To view this dump change 'Code comments level' option to 'DEBUG'
                */
                throw new UnsupportedOperationException("Method not decompiled: vea.raceremote.UdpDiscoveryDeviceTest.searchSelectWithoutArmThenConnectAndReportBusy():void");
            }

            private static final void searchSelectWithoutArmThenConnectAndReportBusy$record(JSONArray events, long started, String kind, Object value) {
                events.put(new JSONObject().put(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1434String$arg0$callput$$this$callput$$this$callput$arg0$callput$funrecord$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), SystemClock.elapsedRealtime() - started).put(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1436String$arg0$callput$$this$callput$arg0$callput$funrecord$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), kind).put(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1438String$arg0$callput$arg0$callput$funrecord$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), value));
            }

            private static final JSONObject searchSelectWithoutArmThenConnectAndReportBusy$get(OkHttpClient http, String host, String path) {
                Response response = (Closeable) http.newCall(new Request.Builder().url(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1395String$0$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$funget$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest() + host + LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1396String$2$str$arg0$callurl$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$funget$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest() + path).build()).execute();
                try {
                    Response it = response;
                    Assert.assertEquals(Integer.valueOf(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1374Int$arg0$callassertEquals$fun$anonymous$$arg0$calluse$funget$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()), Integer.valueOf(it.code()));
                    ResponseBody responseBodyBody = it.body();
                    if (responseBodyBody != null) {
                        JSONObject jSONObject = new JSONObject(responseBodyBody.string());
                        CloseableKt.closeFinally(response, (Throwable) null);
                        return jSONObject;
                    }
                    throw new IllegalArgumentException("Required value was null.".toString());
                } catch (Throwable th) {
                    try {
                        throw th;
                    } catch (Throwable th2) {
                        CloseableKt.closeFinally(response, th);
                        throw th2;
                    }
                }
            }

            private static final JSONObject searchSelectWithoutArmThenConnectAndReportBusy$status(OkHttpClient http, String host, String carId, JSONArray events, long started) {
                JSONObject it = searchSelectWithoutArmThenConnectAndReportBusy$get(http, host, LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1402String$arg0$callget$$$this$callalso$funstatus$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest());
                Assert.assertEquals(carId, it.getString(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1420String$arg0$callgetString$arg1$callassertEquals$fun$anonymous$$arg0$callalso$funstatus$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()));
                Assert.assertFalse(it.getBoolean(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1407String$arg0$callgetBoolean$arg0$callassertFalse$fun$anonymous$$arg0$callalso$funstatus$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()));
                Assert.assertEquals(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1398String$arg0$callassertEquals1$fun$anonymous$$arg0$callalso$funstatus$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), it.getString(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1421String$arg0$callgetString$arg1$callassertEquals1$fun$anonymous$$arg0$callalso$funstatus$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()));
                searchSelectWithoutArmThenConnectAndReportBusy$record(events, started, LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1440String$arg0$callrecord$fun$anonymous$$arg0$callalso$funstatus$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest(), it);
                return it;
            }

            private static final boolean searchSelectWithoutArmThenConnectAndReportBusy$neutral(JSONObject s) throws JSONException {
                if (s.getBoolean(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1406String$arg0$callgetBoolean$$this$callnot$cond$funneutral$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest())) {
                    return false;
                }
                JSONObject it = s.getJSONObject(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1415String$arg0$callgetJSONObject$$$this$calllet$branch$funneutral$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest());
                return it.getInt(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1412String$arg0$callgetInt$arg0$callEQEQ$cond$cond$fun$anonymous$$arg0$calllet$branch$funneutral$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()) == LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1384Int$arg1$callEQEQ$cond$cond$fun$anonymous$$arg0$calllet$branch$funneutral$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest() && it.getInt(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1410String$arg0$callgetInt$arg0$callEQEQ$branch$cond$fun$anonymous$$arg0$calllet$branch$funneutral$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()) == LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1382Int$arg1$callEQEQ$branch$cond$fun$anonymous$$arg0$calllet$branch$funneutral$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest() && it.getInt(LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1411String$arg0$callgetInt$arg0$callEQEQ$branch$fun$anonymous$$arg0$calllet$branch$funneutral$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest()) == LiveLiterals$UdpDiscoveryDeviceTestKt.INSTANCE.m1383Int$arg1$callEQEQ$branch$fun$anonymous$$arg0$calllet$branch$funneutral$funsearchSelectWithoutArmThenConnectAndReportBusy$classUdpDiscoveryDeviceTest();
            }
        }
