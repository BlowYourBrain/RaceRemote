package vea.raceremote;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.util.Log;
import androidx.compose.ui.geometry.Offset;
import androidx.compose.ui.test.ActionsKt;
import androidx.compose.ui.test.AssertionsKt;
import androidx.compose.ui.test.FindersKt;
import androidx.compose.ui.test.SemanticsNodeInteraction;
import androidx.compose.ui.test.TextActionsKt;
import androidx.compose.ui.test.junit4.AndroidComposeTestRule;
import androidx.compose.ui.test.junit4.AndroidComposeTestRule_androidKt;
import androidx.lifecycle.Lifecycle;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okio.Buffer;
import okio.ByteString;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import vea.raceremote.app.MainActivity;
import vea.raceremote.control.ControlPacket;

/* JADX INFO: compiled from: VideoControlIsolationTest.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\t\u001a\u00020\nH\u0007J\b\u0010\u000b\u001a\u00020\nH\u0007R%\u0010\u0003\u001a\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0004\u0012\u00020\u00060\u00048G¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b¨\u0006\f"}, d2 = {"Lvea/raceremote/VideoControlIsolationTest;", "", "()V", "compose", "Landroidx/compose/ui/test/junit4/AndroidComposeTestRule;", "Landroidx/test/ext/junit/rules/ActivityScenarioRule;", "Lvea/raceremote/app/MainActivity;", "getCompose", "()Landroidx/compose/ui/test/junit4/AndroidComposeTestRule;", "repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh", "", "unavailableVideoDoesNotStopControlAndBackgroundStopsBoth", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class VideoControlIsolationTest {
    public static final int $stable = AndroidComposeTestRule.$stable;
    private final AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity> compose = AndroidComposeTestRule_androidKt.createAndroidComposeRule(MainActivity.class);

    @Rule
    public final AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity> getCompose() {
        return this.compose;
    }

    @Test
    public final void repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh() throws IOException {
        MockWebServer control = new MockWebServer();
        MockWebServer video = new MockWebServer();
        final AtomicInteger drives = new AtomicInteger();
        ControlStatusFixtureKt.enqueueControlStatus(control);
        control.enqueue(new MockResponse().withWebSocketUpgrade(new WebSocketListener() { // from class: vea.raceremote.VideoControlIsolationTest.repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh.1
            public void onOpen(WebSocket webSocket, Response response) {
                Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                Intrinsics.checkNotNullParameter(response, "response");
                ControlStatusFixtureKt.sendFixtureIdentity(webSocket, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1472Long$arg0$callsendFixtureIdentity$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest());
                byte[] bArrEncode = new ControlPacket(128, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1484Long$arg1$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1487Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), 0, 0, 24, (DefaultConstructorMarker) null).encode();
                webSocket.send(ByteString.of(Arrays.copyOf(bArrEncode, bArrEncode.length)));
            }

            public void onMessage(WebSocket webSocket, ByteString bytes) {
                Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                Intrinsics.checkNotNullParameter(bytes, "bytes");
                ControlPacket.Companion companion = ControlPacket.Companion;
                byte[] byteArray = bytes.toByteArray();
                Intrinsics.checkNotNullExpressionValue(byteArray, "bytes.toByteArray()");
                ControlPacket packet = companion.decode(byteArray);
                Intrinsics.checkNotNull(packet);
                if (packet.getKind() == 2) {
                    drives.incrementAndGet();
                }
                if (packet.getKind() != 3) {
                    byte[] bArrEncode = ControlPacket.copy$default(packet, 129, 0L, 0L, 0, 0, 30, (Object) null).encode();
                    webSocket.send(ByteString.of(Arrays.copyOf(bArrEncode, bArrEncode.length)));
                }
            }
        }));
        Bitmap bitmap = Bitmap.createBitmap(LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1453Int$arg0$callcreateBitmap$valbitmap$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1464Int$arg1$callcreateBitmap$valbitmap$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), Bitmap.Config.ARGB_8888);
        bitmap.eraseColor(-16776961);
        ByteArrayOutputStream it = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1463Int$arg1$callcompress$fun$anonymous$$arg0$callalso$$this$calltoByteArray$valjpeg$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), it);
        byte[] jpeg = it.toByteArray();
        bitmap.recycle();
        video.enqueue(repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$response(jpeg, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1446Boolean$arg0$callresponse$arg0$callenqueue1$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest()));
        video.enqueue(repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$response(jpeg, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1447Boolean$arg0$callresponse$arg0$callenqueue2$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest()));
        control.start(LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1459Int$arg0$callstart$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest());
        video.start();
        try {
            runOnUiThread(new Function0<Unit>() { // from class: vea.raceremote.VideoControlIsolationTest.repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh.2
                {
                    super(0);
                }

                public /* bridge */ /* synthetic */ Object invoke() {
                    m1547invoke();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: collision with other method in class */
                public final void m1547invoke() {
                    ControlStatusFixtureKt.showControlFixture(VideoControlIsolationTest.this.getCompose().getActivity());
                }
            });
            TextActionsKt.performTextReplacement(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1530String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), false, 2, null), LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1535String$arg0$callperformTextReplacement$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest());
            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1523String$arg0$callonNodeWithTag$$$this$callperformClick$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), false, 2, null));
            SemanticsNodeInteraction semanticsNodeInteractionOnNodeWithTag$default = FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1532String$arg0$callonNodeWithTag$$$this$callperformTextReplacement1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), false, 2, null);
            String string = video.url(LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1538String$arg0$callurl$$this$calltoString$arg0$callperformTextReplacement1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest()).toString();
            Intrinsics.checkNotNullExpressionValue(string, "video.url(\"/stream\").toString()");
            TextActionsKt.performTextReplacement(semanticsNodeInteractionOnNodeWithTag$default, string);
            waitForIdle();
            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1525String$arg0$callonNodeWithTag$$$this$callperformClick1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), false, 2, null));
            waitUntil(LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1474Long$arg0$callwaitUntil$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), new Function0<Boolean>() { // from class: vea.raceremote.VideoControlIsolationTest.repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh.3
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                public final Boolean m1548invoke() {
                    return Boolean.valueOf(drives.get() > LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1466Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest());
                }
            });
            AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1516String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), false, 2, null), LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1501String$arg0$callassertTextContains$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), false, false, 6, null);
            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1527String$arg0$callonNodeWithTag$$$this$callperformClick2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), false, 2, null));
            waitUntil(LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1476Long$arg0$callwaitUntil1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), new Function0<Boolean>() { // from class: vea.raceremote.VideoControlIsolationTest.repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh.4
                {
                    super(0);
                }

                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                public final Boolean m1549invoke() {
                    return Boolean.valueOf(VideoControlIsolationTest.repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$isBlue(VideoControlIsolationTest.repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$centerPixel(VideoControlIsolationTest.this)));
                }
            });
            waitUntil(LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1478Long$arg0$callwaitUntil2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), new Function0<Boolean>() { // from class: vea.raceremote.VideoControlIsolationTest.repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh.5
                {
                    super(0);
                }

                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                public final Boolean m1550invoke() {
                    Object obj;
                    VideoControlIsolationTest $this$invoke_u24lambda_u240 = VideoControlIsolationTest.this;
                    try {
                        Result.Companion companion = Result.Companion;
                        obj = Result.constructor-impl(AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default($this$invoke_u24lambda_u240.getCompose(), LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1513String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), false, 2, null), LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1498String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), false, false, 6, null));
                    } catch (Throwable th) {
                        Result.Companion companion2 = Result.Companion;
                        obj = Result.constructor-impl(ResultKt.createFailure(th));
                    }
                    return Boolean.valueOf(Result.isSuccess-impl(obj));
                }
            });
            Assert.assertEquals(LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1497String$arg0$callassertEquals$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), (Object) (-16777216), (Object) Integer.valueOf(repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$centerPixel(this)));
            final int afterFailure = drives.get();
            waitUntil(LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1480Long$arg0$callwaitUntil3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), new Function0<Boolean>() { // from class: vea.raceremote.VideoControlIsolationTest.repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh.6
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                public final Boolean m1551invoke() {
                    return Boolean.valueOf(drives.get() >= afterFailure + LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1455Int$arg0$callplus$arg1$callgreaterOrEqual$fun$anonymous$$arg1$callwaitUntil3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest());
                }
            });
            AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1518String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), false, 2, null), LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1503String$arg0$callassertTextContains1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), false, false, 6, null);
            AssertionsKt.assertIsEnabled(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1509String$arg0$callonNodeWithTag$$$this$callassertIsEnabled$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), false, 2, null));
            AssertionsKt.assertIsEnabled(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1511String$arg0$callonNodeWithTag$$$this$callassertIsEnabled1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), false, 2, null));
            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1529String$arg0$callonNodeWithTag$$$this$callperformClick3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), false, 2, null));
            waitUntil(LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1482Long$arg0$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), new Function0<Boolean>() { // from class: vea.raceremote.VideoControlIsolationTest.repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh.7
                {
                    super(0);
                }

                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                public final Boolean m1552invoke() {
                    Object obj;
                    VideoControlIsolationTest $this$invoke_u24lambda_u240 = VideoControlIsolationTest.this;
                    try {
                        Result.Companion companion = Result.Companion;
                        obj = Result.constructor-impl(AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default($this$invoke_u24lambda_u240.getCompose(), LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1515String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), false, 2, null), LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1500String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1449Boolean$arg1$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil4$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), false, 4, null));
                    } catch (Throwable th) {
                        Result.Companion companion2 = Result.Companion;
                        obj = Result.constructor-impl(ResultKt.createFailure(th));
                    }
                    return Boolean.valueOf(Result.isSuccess-impl(obj));
                }
            });
            AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1520String$arg0$callonNodeWithTag$$$this$callassertTextContains2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), false, 2, null), LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1505String$arg0$callassertTextContains2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), false, false, 6, null);
            waitUntil(LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1483Long$arg0$callwaitUntil5$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), new Function0<Boolean>() { // from class: vea.raceremote.VideoControlIsolationTest.repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh.8
                {
                    super(0);
                }

                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                public final Boolean m1553invoke() {
                    return Boolean.valueOf(VideoControlIsolationTest.repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$isBlue(VideoControlIsolationTest.repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$centerPixel(VideoControlIsolationTest.this)));
                }
            });
            AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1522String$arg0$callonNodeWithTag$$$this$callassertTextContains3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), false, 2, null), LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1507String$arg0$callassertTextContains3$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), false, false, 6, null);
            Assert.assertEquals(Integer.valueOf(LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1451Int$arg0$callassertEquals1$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest()), Integer.valueOf(video.getRequestCount()));
            Assert.assertEquals(Integer.valueOf(LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1452Int$arg0$callassertEquals2$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest()), Integer.valueOf(control.getRequestCount()));
            try {
                ((ActivityScenarioRule) getActivityRule()).getScenario().moveToState(Lifecycle.State.STARTED);
                try {
                    control.shutdown();
                } finally {
                    video.shutdown();
                }
            } catch (Throwable th) {
                try {
                    control.shutdown();
                    throw th;
                } finally {
                    video.shutdown();
                }
            }
        } catch (Throwable th2) {
            try {
                ((ActivityScenarioRule) getActivityRule()).getScenario().moveToState(Lifecycle.State.STARTED);
                try {
                    control.shutdown();
                    throw th2;
                } finally {
                    video.shutdown();
                }
            } catch (Throwable th3) {
                try {
                    control.shutdown();
                    throw th3;
                } finally {
                    video.shutdown();
                }
            }
        }
    }

    private static final MockResponse repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$response(byte[] jpeg, boolean repeated) {
        String str;
        Buffer body = new Buffer();
        int iM1457Int$arg0$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest = LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1457Int$arg0$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest();
        for (int i = 0; i < iM1457Int$arg0$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest; i++) {
            int index = i;
            if (repeated) {
                str = String.format(Locale.ROOT, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1489String$$$this$callformat$branch$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), Arrays.copyOf(new Object[]{Integer.valueOf(Math.min(index, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1471Int$arg1$callminOf$$this$calltimes$0$vararg$arg1$callformat$branch$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest()) * LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1461Int$arg0$calltimes$0$vararg$arg1$callformat$branch$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest())}, 1));
                Intrinsics.checkNotNullExpressionValue(str, "format(locale, this, *args)");
            } else {
                str = String.format(Locale.ROOT, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1490String$$$this$callformat$else$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), Arrays.copyOf(new Object[]{Integer.valueOf(LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1462Int$arg0$calltimes$0$vararg$arg1$callformat$else$if$valtimestamp$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() * index)}, 1));
                Intrinsics.checkNotNullExpressionValue(str, "format(locale, this, *args)");
            }
            String timestamp = str;
            body.writeUtf8(LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1491String$0$str$$this$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() + jpeg.length + LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1494String$2$str$$this$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() + LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1492String$0$str$arg0$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() + index + LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1495String$2$str$arg0$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() + timestamp + LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1496String$4$str$arg0$callplus$arg0$callwriteUtf8$$this$callwrite$fun$anonymous$$arg1$callrepeat$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest()).write(jpeg);
        }
        MockResponse mockResponseThrottleBody = new MockResponse().setHeader(LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1537String$arg0$callsetHeader$$this$callsetBody$$this$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1540String$arg1$callsetHeader$$this$callsetBody$$this$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest()).setBody(body).throttleBody(((long) jpeg.length) + ((long) LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1454Int$arg0$callplus$arg0$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest()), LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1486Long$arg1$callthrottleBody$funresponse$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), TimeUnit.MILLISECONDS);
        Intrinsics.checkNotNullExpressionValue(mockResponseThrottleBody, "MockResponse().setHeader…0, TimeUnit.MILLISECONDS)");
        return mockResponseThrottleBody;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final int repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$centerPixel(VideoControlIsolationTest this$0) {
        long center = SemanticsNodeInteraction.fetchSemanticsNode$default(FindersKt.onNodeWithTag$default(this$0.compose, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1534String$arg0$callonNodeWithTag$$this$callfetchSemanticsNode$$this$call$getboundsInWindow$$$this$call$getcenter$$valcenter$funcenterPixel$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), false, 2, null), null, 1, null).getBoundsInWindow().getCenter-F1C5BW0();
        Bitmap image = InstrumentationRegistry.getInstrumentation().getUiAutomation().takeScreenshot();
        if (image == null) {
            throw new IllegalArgumentException("Required value was null.".toString());
        }
        int pixel = image.getPixel((int) Offset.getX-impl(center), (int) Offset.getY-impl(center));
        image.recycle();
        Log.d(LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1508String$arg0$calld$funcenterPixel$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest(), LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1493String$0$str$arg1$calld$funcenterPixel$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() + Integer.toHexString(pixel));
        return pixel;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean repeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$isBlue(int pixel) {
        return Color.blue(pixel) > LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1465Int$arg1$callgreater$cond$cond$funisBlue$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() && Color.red(pixel) < LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1469Int$arg1$callless$branch$cond$funisBlue$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest() && Color.green(pixel) < LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1470Int$arg1$callless$branch$funisBlue$try$funrepeatedCaptureTimesOutVideoWhileControlContinuesAndReconnectStartsFresh$classVideoControlIsolationTest();
    }

    @Test
    public final void unavailableVideoDoesNotStopControlAndBackgroundStopsBoth() throws IOException {
        MockWebServer control = new MockWebServer();
        final MockWebServer video = new MockWebServer();
        final AtomicInteger drives = new AtomicInteger();
        ControlStatusFixtureKt.enqueueControlStatus(control);
        control.enqueue(new MockResponse().withWebSocketUpgrade(new WebSocketListener() { // from class: vea.raceremote.VideoControlIsolationTest.unavailableVideoDoesNotStopControlAndBackgroundStopsBoth.1
            public void onOpen(WebSocket webSocket, Response response) {
                Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                Intrinsics.checkNotNullParameter(response, "response");
                ControlStatusFixtureKt.sendFixtureIdentity(webSocket, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1473Long$arg0$callsendFixtureIdentity$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest());
                byte[] bArrEncode = new ControlPacket(128, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1485Long$arg1$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest(), LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1488Long$arg2$call$init$$$this$callencode$0$vararg$arg0$callof$arg0$callsend$funonOpen$class$nonameprovided$$arg0$callwithWebSocketUpgrade$arg0$callenqueue$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest(), 0, 0, 24, (DefaultConstructorMarker) null).encode();
                webSocket.send(ByteString.of(Arrays.copyOf(bArrEncode, bArrEncode.length)));
            }

            public void onMessage(WebSocket webSocket, ByteString bytes) {
                Intrinsics.checkNotNullParameter(webSocket, "webSocket");
                Intrinsics.checkNotNullParameter(bytes, "bytes");
                ControlPacket.Companion companion = ControlPacket.Companion;
                byte[] byteArray = bytes.toByteArray();
                Intrinsics.checkNotNullExpressionValue(byteArray, "bytes.toByteArray()");
                ControlPacket p = companion.decode(byteArray);
                Intrinsics.checkNotNull(p);
                if (p.getKind() == 2) {
                    drives.incrementAndGet();
                }
                if (p.getKind() != 3) {
                    byte[] bArrEncode = ControlPacket.copy$default(p, 129, 0L, 0L, 0, 0, 30, (Object) null).encode();
                    webSocket.send(ByteString.of(Arrays.copyOf(bArrEncode, bArrEncode.length)));
                }
            }
        }));
        video.enqueue(new MockResponse().setResponseCode(LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1458Int$arg0$callsetResponseCode$arg0$callenqueue1$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest()));
        control.start(LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1460Int$arg0$callstart$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest());
        video.start();
        try {
            runOnUiThread(new Function0<Unit>() { // from class: vea.raceremote.VideoControlIsolationTest.unavailableVideoDoesNotStopControlAndBackgroundStopsBoth.2
                {
                    super(0);
                }

                public /* bridge */ /* synthetic */ Object invoke() {
                    m1554invoke();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: collision with other method in class */
                public final void m1554invoke() {
                    ControlStatusFixtureKt.showControlFixture(VideoControlIsolationTest.this.getCompose().getActivity());
                }
            });
            TextActionsKt.performTextReplacement(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1531String$arg0$callonNodeWithTag$$$this$callperformTextReplacement$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest(), false, 2, null), LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1536String$arg0$callperformTextReplacement$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest());
            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1524String$arg0$callonNodeWithTag$$$this$callperformClick$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest(), false, 2, null));
            waitUntil(LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1475Long$arg0$callwaitUntil$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest(), new Function0<Boolean>() { // from class: vea.raceremote.VideoControlIsolationTest.unavailableVideoDoesNotStopControlAndBackgroundStopsBoth.3
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                public final Boolean m1555invoke() {
                    return Boolean.valueOf(drives.get() > LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1467Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest());
                }
            });
            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1526String$arg0$callonNodeWithTag$$$this$callperformClick1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest(), false, 2, null));
            SemanticsNodeInteraction semanticsNodeInteractionOnNodeWithTag$default = FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1533String$arg0$callonNodeWithTag$$$this$callperformTextReplacement1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest(), false, 2, null);
            String string = video.url(LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1539String$arg0$callurl$$this$calltoString$arg0$callperformTextReplacement1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest()).toString();
            Intrinsics.checkNotNullExpressionValue(string, "video.url(\"/stream\").toString()");
            TextActionsKt.performTextReplacement(semanticsNodeInteractionOnNodeWithTag$default, string);
            ActionsKt.performClick(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1528String$arg0$callonNodeWithTag$$$this$callperformClick2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest(), false, 2, null));
            waitUntil(LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1477Long$arg0$callwaitUntil1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest(), new Function0<Boolean>() { // from class: vea.raceremote.VideoControlIsolationTest.unavailableVideoDoesNotStopControlAndBackgroundStopsBoth.4
                {
                    super(0);
                }

                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                public final Boolean m1556invoke() {
                    return Boolean.valueOf(getRequestCount() > LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1468Int$arg1$callgreater$fun$anonymous$$arg1$callwaitUntil1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest());
                }
            });
            waitUntil(LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1479Long$arg0$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest(), new Function0<Boolean>() { // from class: vea.raceremote.VideoControlIsolationTest.unavailableVideoDoesNotStopControlAndBackgroundStopsBoth.5
                {
                    super(0);
                }

                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                public final Boolean m1557invoke() {
                    Object obj;
                    VideoControlIsolationTest $this$invoke_u24lambda_u240 = VideoControlIsolationTest.this;
                    try {
                        Result.Companion companion = Result.Companion;
                        obj = Result.constructor-impl(AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default($this$invoke_u24lambda_u240.getCompose(), LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1514String$arg0$callonNodeWithTag$$$this$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest(), false, 2, null), LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1499String$arg0$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest(), LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1448Boolean$arg1$callassertTextContains$fun$anonymous$$arg0$callrunCatching$$this$call$getisSuccess$$fun$anonymous$$arg1$callwaitUntil2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest(), false, 4, null));
                    } catch (Throwable th) {
                        Result.Companion companion2 = Result.Companion;
                        obj = Result.constructor-impl(ResultKt.createFailure(th));
                    }
                    return Boolean.valueOf(Result.isSuccess-impl(obj));
                }
            });
            final int afterFailure = drives.get();
            waitUntil(LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1481Long$arg0$callwaitUntil3$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest(), new Function0<Boolean>() { // from class: vea.raceremote.VideoControlIsolationTest.unavailableVideoDoesNotStopControlAndBackgroundStopsBoth.6
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                public final Boolean m1558invoke() {
                    return Boolean.valueOf(drives.get() >= afterFailure + LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1456Int$arg0$callplus$arg1$callgreaterOrEqual$fun$anonymous$$arg1$callwaitUntil3$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest());
                }
            });
            AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1517String$arg0$callonNodeWithTag$$$this$callassertTextContains$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest(), false, 2, null), LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1502String$arg0$callassertTextContains$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest(), false, false, 6, null);
            AssertionsKt.assertIsEnabled(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1510String$arg0$callonNodeWithTag$$$this$callassertIsEnabled$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest(), false, 2, null));
            AssertionsKt.assertIsEnabled(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1512String$arg0$callonNodeWithTag$$$this$callassertIsEnabled1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest(), false, 2, null));
            ((ActivityScenarioRule) getActivityRule()).getScenario().moveToState(Lifecycle.State.STARTED);
            ((ActivityScenarioRule) getActivityRule()).getScenario().moveToState(Lifecycle.State.RESUMED);
            AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1519String$arg0$callonNodeWithTag$$$this$callassertTextContains1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest(), false, 2, null), LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1504String$arg0$callassertTextContains1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest(), LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1450Boolean$arg1$callassertTextContains1$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest(), false, 4, null);
            AssertionsKt.assertTextContains$default(FindersKt.onNodeWithTag$default(this.compose, LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1521String$arg0$callonNodeWithTag$$$this$callassertTextContains2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest(), false, 2, null), LiveLiterals$VideoControlIsolationTestKt.INSTANCE.m1506String$arg0$callassertTextContains2$try$fununavailableVideoDoesNotStopControlAndBackgroundStopsBoth$classVideoControlIsolationTest(), false, false, 6, null);
            try {
                ((ActivityScenarioRule) getActivityRule()).getScenario().moveToState(Lifecycle.State.STARTED);
                try {
                    control.shutdown();
                } finally {
                    video.shutdown();
                }
            } catch (Throwable th) {
                try {
                    control.shutdown();
                    throw th;
                } finally {
                    video.shutdown();
                }
            }
        } catch (Throwable th2) {
            try {
                ((ActivityScenarioRule) getActivityRule()).getScenario().moveToState(Lifecycle.State.STARTED);
                try {
                    control.shutdown();
                    throw th2;
                } finally {
                    video.shutdown();
                }
            } catch (Throwable th3) {
                try {
                    control.shutdown();
                    throw th3;
                } finally {
                    video.shutdown();
                }
            }
        }
    }
}
